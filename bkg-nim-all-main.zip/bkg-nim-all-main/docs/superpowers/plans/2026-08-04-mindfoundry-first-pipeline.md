```md
# MANDATORY ANALYSIS GATE

Before creating ANY Rust code:

The agent must prove that the required source analysis is complete.

Forbidden:

- starting implementation from README knowledge
- using assumptions
- creating structures based on file names
- mapping Python classes directly to Rust structs
- recreating existing code patterns without understanding behavior

Required evidence:

Create:

docs/bkg-base-source-analysis.md

containing:

- analyzed repositories
- analyzed files
- capability matrix
- extracted invariants
- behavior observations
- rejected assumptions
- Rust design rationale

For every analyzed source:

- path
- language
- responsibility
- public behavior
- hidden invariants
- state transitions
- external dependencies
- extracted capabilities
- rejected assumptions
- Rust redesign notes

Implementation may begin only after every source category is documented.

Only after this document exists may implementation begin.
```

Außerdem:

```md
# IMPLEMENTATION RULES

Every Rust type must be designed independently.

Forbidden examples:

Python:
class Memory

Rust:
struct Memory


Python:
PolicyEngine

Rust:
PolicyEngine


These are considered structural copies.

Instead:

Create Rust concepts based on behavior.

Example:

Original capability:
"stores agent knowledge with retrieval"

Possible Rust design:

KnowledgeStore
MemoryEntry
RetrievalPolicy
StorageBackend

Names and structures must be independently designed.
```

# COMPLETION REQUIREMENTS

A task is NOT complete because:

- cargo check passes
- tests pass
- files exist

A task is complete only when:

1. Architecture document exists
2. Design decisions are documented
3. Code matches approved architecture
4. No forbidden files were created
5. No existing runtime/provider code was modified
6. Every public API has documentation
7. Tests validate behavior, not copied implementation
8. No structural copy from MindFoundry exists
9. Every public type has documented design rationale
```

# BKG-BASE: MindFoundry Rust Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create the Rust 2024 pure foundation layer for BKG-BASE.
BKG-BASE owns only types, traits, errors, events, and plugin contracts.
All implementation logic lives in dedicated crates: storage, memory, rag, policy,
simulation, runtime, plugin-runtime, nim, proxy.

MindFoundry is treated only as behavioral reference.
No source compatibility and no structural mapping is required.
BKG-BASE is a Rust-native foundation layer with zero implementation logic.

BKG-BASE is a library crate only.
It must not contain binaries, CLI entrypoints, servers or executable runtime loops.

Dependency rule: All other crates depend on base. Base depends on nothing
except external libraries. No reverse dependencies. No cycles.

Note: BKG-BASE is strictly the foundation layer. No migration, no copy-paste, no wrapper layers.

---

**Execution directory:**

```
bkg-nim/
```

This task creates only:

```
crates/base
```

Any creation outside:

- `crates/base`
- `docs/bkg-base-architecture.md`
- `docs/bkg-base-source-analysis.md`

is a task violation.


These are reserved for later phases and must not be created now:


---

**Gate A: Analysis & Architecture (no code yet)**

1. Create `docs/bkg-base-source-analysis.md`
2. Create `docs/bkg-base-architecture.md`
3. STOP — wait for review

No code generation before Gate A approval.

**Forbidden before Gate A approval:**

- Cargo workspace membership changes
- dependency changes
- crate creation
- module creation
- generated code
- `Cargo.toml` modifications
- `Cargo.lock` modifications
- new directory creation under `crates/`

"Just a quick Cargo.toml tweak" is a known anti-pattern that reliably expands into ten file changes.

---

**Gate B: Implementation (after Gate A approval)**

Only after Gate A is approved may implementation begin.

The first implementation task creates only `crates/base/`.

**Architecture:** Plugin-first Rust workspace (`bkg-base`) with deterministic simulation, trait-based service boundaries, and zero external provider dependencies in core. All integrations (NIM, Discord, Google, OpenAI) arrive later via traits and plugins.

**Workspace dependency graph:**

```
                     runtime
                    /   |    \
                   /    |     \
                 nim  proxy  plugin-runtime
                    \    |    /
                     \   |   /
        memory  rag  policy  simulation  storage
              \    |     |      |      /
               \   |     |      |     /
                    \    |    /
                      base
```

Dependency rules:
- `base` depends on nothing in the workspace.
- `storage`, `memory`, `policy`, `rag`, `simulation` depend only on `base`.
- `runtime` depends on `base`, `storage`, `memory`, `rag`, `policy`, `simulation`.
- `nim`, `proxy`, `plugin-runtime` depend on `runtime` and `base`, never the reverse.

**Tech Stack:** Rust 2024 edition, thiserror, serde, serde_json, async-trait (plugin ABI stability), uuid, chrono, semver, futures.

`async-trait` is kept for plugin interfaces because they span multiple crates and must remain stable across compiler versions. Native async traits (rustc 1.75+) are used only within `bkg-base` itself where the compiler version is controlled.

**Dependencies (`crates/base`):**

```toml
serde = { version = "1", features = ["derive"] }
serde_json = "1"
thiserror = "2"
uuid = { version = "1", features = ["v4", "serde"] }
chrono = { version = "0.4", features = ["serde"] }
async-trait = "0.1"
semver = { version = "1", features = ["serde"] }
futures = "0.3"
```

Runtime and I/O dependencies belong in their respective crates:

- `sqlx`, `tokio`, `tracing`, `tracing-subscriber` → `storage`, `runtime`
- `regex`, `sha1` → `policy`

---

## Workspace

Work exclusively in:

```
/home/workspace/work/proxy/bkg-nim-studio
```

Target architecture:

```
crates/
├── base/
├── runtime/
├── storage/
├── memory/
├── rag/
├── policy/
├── simulation/
├── plugin-runtime/
├── nim/
└── proxy/
```

Cargo package name:

```toml
name = "bkg-base"

[lib]
name = "bkg_base"
```

Directory on disk: `crates/base/`

These must stay consistent.

The crate is `bkg-base`.
The directory is `base`.
Rust import uses `bkg_base`.

---

## Critical: No Migration, No Copy-Paste

**Prohibited:**

- Copying files from MindFoundry
- Rebuilding Python structure in Rust
- Carrying over old names
- Wrapping existing code
- Creating temporary compatibility shims

MindFoundry serves only as a **functional reference**. Analyze its capabilities, then implement them idiomatically in Rust 2024.

The agent must not rename files or move directories from MindFoundry. Every line of Rust code must be written fresh.

---

## Naming Consistency Rule

The following names are forbidden inside this crate:

- dna
- bkg-dna
- crates/dna
- bkg_dna
- dna::

All documentation, comments, tests, imports and module paths must use:

- bkg-base
- bkg_base
- crates/base
- base::

No compatibility aliases are allowed.

Do not create:

```rust
pub use bkg_base as bkg_dna;
```

Such "compatibility" ideas are approximately as helpful as adding a second steering wheel to a car. More parts, same lack of direction.

---

## Target

BKG-BASE is the central foundation for the later BKG platform. All other components integrate later as plugins:

- `bkg-nim`
- `agent-memory`
- Discord Connector
- Workspace Connector
- Model Proxy
- Agent Runtime
- Provider Plugins

BKG-BASE contains only core capabilities and stable interfaces. No provider-specific code. No Discord bindings. No NIM client logic. No cloud dependencies.

---

## Architecture Principle

**Pure foundation. Strict dependency direction.**

`base` owns only types, traits, errors, events, and plugin contracts.
All implementation crates depend on `base`. `base` depends on nothing
except external libraries.

**Plugin-first.** Plugin contracts live in `base`. Plugin loading,
WASM isolation, and health endpoints belong in `plugin-runtime`.

Core remains independent of external providers.

No direct dependency on:

- NVIDIA NIM
- Discord
- Google
- OpenAI
- Cloud APIs

These arrive later via traits and plugins.

---

## Architecture Gate (Before Coding)

Before any implementation begins, create:

```
docs/bkg-base-architecture.md
```

Containing:

- Module dependency graph
- Crate boundaries
- Public API surface
- Forbidden dependencies
- Plugin extension points

Do not start coding before architecture review is complete.

---

## Workspace Structure Check

Before any implementation begins, the agent must verify the workspace:

```bash
ls
find crates -maxdepth 2 -type f
cat Cargo.toml
```

Then create `crates/base/` only after confirming the workspace structure is understood.

Do not create directories and hope Cargo figures it out.

Directory structure:

```
crates/base/src/
├── lib.rs
├── domain/
│   └── domain.rs
├── error/
│   └── error.rs
├── events/
│   └── events.rs
├── traits/
│   └── traits.rs
└── plugin/
    └── plugin.rs
```

Other crates follow the same flat module pattern under `src/`:

```
crates/<name>/src/
├── lib.rs
├── <module>.rs
└── ...
```

Examples:
- `crates/memory/src/store.rs`
- `crates/policy/src/gate.rs`
- `crates/rag/src/retrieval.rs`
- `crates/storage/src/persist.rs`
- `crates/runtime/src/orchestrator.rs`
- `crates/simulation/src/generator.rs`

---
SOURCE : https://github.com/AleBrito124356/agent-memory-systems
SOURCE : https://github.com/SurajBhar/rag_nim
SOURCE : https://github.com/nnennandukwe/policyNIM
SOURCE : https://github.com/miztertea/nim-proxy
SOURCE : https://github.com/CloseForge-org/mindfoundry

## Implementation Layers

### crates/base — Pure Foundation

BKG-BASE contains only types, traits, errors, events, and plugin contracts.
No database code. No retrieval logic. No policy evaluation. No simulation.

### crates/storage — Persistence Layer

SQLite via sqlx, JSONL event stream, atomic JSON state store.

### crates/memory — Knowledge Memory

Per-person knowledge profiles, memory storage, retrieval.

### crates/rag — Retrieval Engine

Tokenization, deterministic scoring, citation generation.

### crates/policy — Policy Engine

PII detection, redaction, audit logging.

### crates/simulation — Synthetic Workload Generator

Deterministic data production for testing and development.

### crates/runtime — Agent Execution

Agent loops, scheduler, event loop, use cases.

### crates/plugin-runtime — Plugin System

Plugin loading, WASM execution, isolation, health endpoints.

### `crates/base/src/domain`

Pure data concepts only. No database logic. No retrieval logic. No business rules.

All models implement: `Serialize`, `Deserialize`, `Clone`, `Debug`, `Eq`/`Hash` where semantically valid.

All enums implement: `Display`, `FromStr`, `Serialize`/`Deserialize`.

#### Identity

- `AgentId`
- `EventId`
- `MemoryId`
- `MessageId`

#### Messaging

- `Message`
- `Citation`
- `Attachment`

#### Policy

- `PolicyKind` (enum: `Password`, `CreditCard`, `TaiwanPhone`, `Email`, `PassportOrID`, `InternalNote`)
- `Severity` (enum: `Critical`, `High`, `Medium`, `Low`, `Info`)

#### Events

- `EventEnvelope`
- `EventType`

#### Workflow

- `IncidentType` (enum: `Operational`, `Security`, `Communication`)
- `Status` (enum: `Pending`, `InProgress`, `Resolved`, `Closed`)

---

### `crates/simulation` — Deterministic Synthetic Workload Generator

**Module:** `simulation`

**Types:**

```rust
simulation::Reservation
simulation::Guest
simulation::Staff
```

These are synthetic data types. They do not exist in `domain`.

Depends on `base` for domain types.

**Implement:**

- Seed 42 deterministic generator
- Deterministic data production
- Weighted sampling
- Template expansion
- `en` / `zh-TW` locale support

**Invariants (must hold after every simulation run):**

| Entity       | Count |
| ------------ | ----- |
| Reservations | 250   |
| Guests       | 500   |
| Staff        | 8     |
| Incidents    | 500   |
| Messages     | 3150  |
| Memories     | 500   |

**Repetition distribution:**

```
300 / 100 / 50
```

Every invariant must have a dedicated test that asserts the count.

---

### `crates/storage` — Persistence Layer

**Module:** `storage`

**SQLite:**

- Foreign keys enabled
- Indexes on all foreign key columns
- Connection pool via `sqlx::sqlite::SqlitePool`
- Read models separate from write models

**JSONL:**

- Event stream append-only
- Memory append-only
- Audit log append-only

**State store:**

Atomic JSON store using temp-file-then-rename pattern.

No direct concurrent write access.

Depends on `base` for domain types and `StateSink` trait.

---

### `crates/rag` — Retrieval Engine

**Module:** `rag`

Depends on `base` for domain types and traits.

**Implement:**

- Tokenization including CJK characters
- Deterministic scoring (no randomness)

**Scoring rules:**

| Match Type   | Score |
| ------------ | ----- |
| Exact match  | +2    |
| Prefix match | +1    |

**Intent bonuses:**

- Memory intent: bonus
- Policy intent: bonus
- Live ops intent: bonus

**Features:**

- Citation generation
- Routing suggestion
- Guardrail summary

No vector store required. Deterministic scoring only.

---

### `crates/memory` — Knowledge Memory System

**Module:** `memory`

**Capabilities:**

- Per-person knowledge profiles
- Profile memories
- Behavior memories
- Workspace memories
- Experience memories
- Case memories
- Discord memories

**Limits:**

- `case` memories: max 4 per person
- `discord` memories: max 8 per person

**Storage:** Append-only. No in-place updates.

Depends on `base` for domain types and traits.

---

### `crates/policy` — Policy Engine

**Module:** `policy`

Depends on `base` for domain types and traits.

**Implement:**

- `gate_text(input: &str) -> GateResult`
- `gate_payload(payload: &Value) -> GateResult`

**Policy classes:**

- `password`
- `credit_card`
- `taiwan_phone`
- `email`
- `passport_or_id`
- `internal_note`

**Destination roles:**

- `public_discord`
- `finance_private`
- `manager_private`

**Output:**

- `allow`
- `allow_with_redactions`

**Redaction format:**

```
[KIND REDACTED]
```

where `KIND` is the policy class name.

**Audit:** JSONL events for every gate decision.

---

### `crates/base/src/events` — Event System

**Module:** `base::events`

**Event types:**

- `MessageReceived`
- `QuestionAnswered`
- `IncidentPosted`
- `IncidentFollowupPosted`
- `MemoryAppended`
- `GateViolation`
- `ProvisionStatus`
- `EvalCompleted`
- `LiveSummaryRefreshed`

**Event envelope with versioning:**

```rust
pub struct EventEnvelope {
    pub id: Uuid,
    pub version: u32,
    pub timestamp: DateTime<Utc>,
    pub event_type: EventType,
    pub payload: Value,
}
```

Versioning ensures that new event types do not break old consumers. Each event carries its schema version.

`base` defines only the contract:
- `EventEnvelope`
- `EventType`
- `EventFilter`
- `EventStream` type alias

JSONL parsing and `StreamDeserializer` belong in `storage`.

---

### `crates/runtime` — Agent Execution

Agent execution, scheduler, event loop, and use cases.

Use cases work exclusively against traits defined in `base`:

- `SimulationUseCase`
- `RetrievalUseCase`
- `PolicyUseCase`
- `KnowledgeUseCase`
- `LiveOpsUseCase`
- `EvaluationUseCase`

Each use case receives its dependencies via trait bounds, never concrete types.

Depends on `base`, `storage`, `memory`, `rag`, `policy`, `simulation`.

---

### `crates/base/src/traits` — Foundation Traits

Define async-capable traits for future plugin integration.

Names are capability-oriented, not provider-oriented:

```rust
#[async_trait]
pub trait InferenceService {
    async fn complete(
        &self,
        request: InferenceRequest
    ) -> Result<InferenceResponse, InferenceError>;
}

#[async_trait]
pub trait MemoryProvider {
    async fn store(&self, record: KnowledgeRecord) -> Result<()>;
    async fn search(
        &self,
        query: KnowledgeQuery
    ) -> Result<Vec<KnowledgeRecord>>;
}

#[async_trait]
pub trait StateSerializable {
    async fn serialize(&self) -> Result<Vec<u8>>;
}

#[async_trait]
pub trait SnapshotCodec {
    async fn write_snapshot(&self, data: &[u8]) -> Result<()>;
    async fn read_snapshot(&self) -> Result<Vec<u8>>;
}

#[async_trait]
pub trait AppendLog {
    async fn append(&self, entry: &[u8]) -> Result<()>;
}

#[async_trait]
pub trait StateSink {
    async fn write(&self, state: &Value) -> Result<()>;
}

#[async_trait]
pub trait StateSource {
    async fn read(&self) -> Result<Value>;
}

type EventStream =
    Pin<Box<dyn Stream<Item = EventEnvelope> + Send>>;

#[async_trait]
pub trait EventPublisher {
    async fn publish(&self, event: EventEnvelope) -> Result<()>;
    async fn subscribe(
        &self,
        filter: EventFilter
    ) -> Result<EventStream, EventError>;
}
```

Each trait must have a mock implementation for testing.

---

### `crates/base/src/plugin` — Plugin Contracts Only

**Module:** `base::plugin`

**Types:**

```rust
pub struct PluginDescriptor {
    pub name: String,
    pub version: semver::Version,
    pub description: String,
    pub capabilities: Vec<PluginCapability>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PluginCapability {
    InferenceService,
    MemoryProvider,
    EventPublisher,
    StateSerializable,
    SnapshotCodec,
    AppendLog,
    StateSink,
    StateSource,
    // Extend as needed
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PluginState {
    Unloaded,
    Loaded,
    Initializing,
    Running,
    Stopping,
    Stopped,
    Failed(String),
}

pub trait PluginLifecycle {
    fn init(&mut self) -> Result<(), PluginError>;
    fn start(&mut self) -> Result<(), PluginError>;
    fn stop(&mut self) -> Result<(), PluginError>;
    fn health(&self) -> Result<PluginHealth, PluginError>;
}

pub struct PluginHealth {
    pub status: PluginState,
    pub version: semver::Version,
    pub dependencies: Vec<String>,
    pub latency_ms: u64,
}
```

BKG-BASE supplies contracts only.

No runtime loading. No manifest signature verification. No isolation.
No health endpoint server. No registry implementation. No HashMap.

Plugin loading, WASM isolation, health endpoints, and the actual `PluginRegistry` implementation belong in a later `crates/plugin-runtime` crate.

---

### `crates/base/src/error` — Error Architecture

Use `thiserror` for all domain errors.

**Core error types (provider-independent):**

- `CoreError`
- `StorageError`
- `PolicyError`
- `RetrievalError`
- `PluginError`
- `EventError`

All library code uses `thiserror`-derived error types.

`anyhow` is permitted **only** in binary crates (e.g., `crates/runtime/src/main.rs`) for top-level error reporting.

**Dev dependencies:**

```toml
[dev-dependencies]
mockall = "0.13"
proptest = "1"
tempfile = "3"
```

Provider crates get their own error modules:

- `crates/nim/src/error.rs`
- `crates/discord/src/error.rs`
- `crates/workspace/src/error.rs`

Core errors must never reference provider types. The kernel must not know about NVIDIA, Discord, or any external service.

---

## Testing Requirements

Before considering any phase complete, run:

```bash
git status
cargo fmt --check
cargo check
cargo test
cargo clippy -- -D warnings
```

All four must pass with zero warnings and zero failures.

Create one commit per completed phase.

**No fake tests.** Every test must assert real logic:

No `todo!()`, `unimplemented!()`, or `panic!()` placeholders in production code.

Every function must have a real implementation or be explicitly marked as a trait stub with a comment explaining the deferred implementation.

- Seed reproducibility (same seed → same output)
- Invariant counts (simulation produces exact entity counts)
- Retrieval scoring (exact match > prefix match > no match)
- Policy redaction (PII replaced with `[KIND REDACTED]`)
- JSON state recovery (write then read back, data identical)
- Event serialization (serialize then deserialize, data identical)

---

## Phases

### Directory structure (this plan covers `crates/base` only)

```
crates/base/
├── Cargo.toml
└── src/
    ├── lib.rs
    ├── domain/
    │   └── domain.rs
    ├── error/
    │   └── error.rs
    ├── events/
    │   └── events.rs
    ├── traits/
    │   └── traits.rs
    └── plugin/
        └── plugin.rs
```

Other crates have their own plans:

- `docs/plans/2026-08-04-storage-plan.md`
- `docs/plans/2026-08-04-memory-plan.md`
- `docs/plans/2026-08-04-policy-plan.md`
- `docs/plans/2026-08-04-rag-plan.md`
- `docs/plans/2026-08-04-simulation-plan.md`
- `docs/plans/2026-08-04-runtime-plan.md`
- `docs/plans/2026-08-04-plugin-runtime-plan.md`
- `docs/plans/2026-08-04-nim-plan.md`
- `docs/plans/2026-08-04-proxy-plan.md`

---

### Phase 0: Workspace + Crate Skeleton

- Verify workspace structure
- Create `crates/base/`
- Configure `Cargo.toml` with workspace membership
- Create module skeleton: `domain`, `error`, `events`, `traits`, `plugin`

### Phase 1: Domain + Errors + Traits

- Implement pure domain structs and enums (`AgentId`, `EventId`, `MessageId`, `PolicyKind`, `Severity`)
- Implement core error types (thiserror)
- Define foundation traits (async): `InferenceService`, `MemoryProvider`, `StateSerializable`, `SnapshotCodec`, `AppendLog`, `StateSink`, `StateSource`, `EventPublisher`

### Phase 2: Mock Infrastructure

- Implement mock types for all foundation traits
- `MockInferenceService`
- `MockMemoryProvider`
- `MockEventPublisher`
- `MockStateSink`
- `MockStateSource`
- `MockSnapshotCodec`
- `MockAppendLog`
- `MockPluginLifecycle`
- All mocks return deterministic, testable results
- No external dependencies

### Phase 3: Events in `base`

- Implement `EventEnvelope` with versioning in `base`
- Implement `EventType` and `EventFilter` enums
- No event bus implementation in `base` (trait only in `traits`)

### Phase 4: Plugin Contracts in `base`

- Implement `PluginDescriptor` struct
- Implement `PluginCapability` enum
- Implement `PluginState` enum
- Implement `PluginLifecycle` trait
- No registry, no loading, no isolation

`crates/base` stays the Pure Foundation Layer.

```
bkg-nim
crates/
├── base/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── domain/
│       ├── error/
│       ├── events/
│       ├── traits/
│       └── plugin/
│
├── storage/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── sqlite/
│       ├── jsonl/
│       └── state/
│
├── memory/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── profile/
│       ├── storage/
│       └── retrieval/
│
├── rag/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── tokenizer/
│       ├── scoring/
│       └── citation/
│
├── policy/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── classes/
│       ├── redaction/
│       └── audit/
│
├── simulation/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── generator/
│       ├── templates/
│       └── locale/
│
├── runtime/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── agent/
│       ├── scheduler/
│       ├── use_cases/
│       └── event_loop/
│
├── plugin-runtime/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── loader/
│       ├── wasm/
│       └── isolation/
│
├── nim/
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── client/
│       └── models/
│
└── proxy/
    ├── Cargo.toml
    └── src/
        ├── lib.rs
        ├── router/
        └── provider/
```

### Phase 10: Base Unit Tests

Tests that validate `crates/base` in isolation:

- Domain serialization roundtrip
- Event serialization roundtrip
- Trait mock tests (`InferenceService`, `MemoryProvider`, `EventPublisher`, `StateSerializable`, `SnapshotCodec`, `AppendLog`, `StateSink`, `StateSource`)
- Error conversion and Display
- Plugin descriptor and state transitions
- No external providers
- No storage
- No runtime

---

### Phase 11: Workspace Integration Tests

> **Note:** This phase is defined in a separate plan: `docs/plans/2026-08-04-workspace-integration-plan.md`.

Tests that validate cross-crate contracts:

- Simulation → Storage
- Memory → Retrieval
- Policy → EventPublisher
- Event serialization through storage
- State recovery through StateSink

No external providers.
No Discord.
No NIM.
No Google.

---

## After BKG-BASE Is Stable

Only after `crates/base` passes all checks and tests:

Prepare integration for:

```
crates/nim
crates/agent-memory
crates/proxy
```

These crates may depend on `bkg-base` as a workspace dependency. They must not modify `bkg-base` source code.

---

## End State

BKG-BASE is the Rust 2024 pure foundation layer:

- Deterministic
- Plugin-ready
- Event-driven
- Testable
- Cloud-independent
- Plugin-contract ready

No transitional solution. No simulation scaffolding. No placeholder architecture. No TODO comments left in production code.

---

## Execution

After saving this plan, I will offer execution options:

**1. Subagent-Driven (recommended)** — Dispatch a fresh subagent per task, review between tasks, fast iteration.

**2. Inline Execution** — Execute tasks in this session using `executing-plans`, batch execution with checkpoints for review.

**Which approach?**
