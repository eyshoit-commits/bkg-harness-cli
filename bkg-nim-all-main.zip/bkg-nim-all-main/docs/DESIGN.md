# UI DESIGN PROMPT — CYBERPUNK NEON COMMAND CENTER

## Ausgangspunkt

Überarbeite das bestehende React/TypeScript UI **auf Basis des vorhandenen `App.tsx` Aufbaus und der bereits vorhandenen Komponenten**.

**WICHTIG:**
Die bestehende Informationsarchitektur, Navigation, Komponentenstruktur und Funktionalität bleiben erhalten.

Nicht neu erfinden.
Nicht vereinfachen.
Keine Tabs entfernen.
Keine vorhandenen Bereiche zusammenlegen.
Keine Fake-Features hinzufügen.
Keine Platzhalter verwenden.

Die Aufgabe ist primär eine **visuelle und responsive Überarbeitung**.

Das Ergebnis soll aussehen wie eine Mischung aus:

* Cyberpunk 2077
* futuristischem Hacker-Terminal
* Neon Command Center
* militärischem Operations-Dashboard
* hochentwickelter AI-Control-Station

Das UI soll wirken, als würde ein Entwickler eine echte autonome Multi-Agent-Infrastruktur aus einer futuristischen Kommandozentrale steuern.

---

# 1. GRUNDÄSTHETIK

Das gesamte Interface muss konsequent nach einem **Dark Cyberpunk Neon System** aussehen.

Kein normales modernes SaaS-Design.

Kein Material Design.

Keine weißen Cards.

Keine hellen Hintergründe.

Keine Pastellfarben.

Keine großen runden modernen Dashboard-Karten.

Keine übermäßigen Verläufe.

Keine „Startup Dashboard“-Optik.

Die Oberfläche muss technisch, dicht, präzise und leicht aggressiv wirken.

Visuelle Referenz:

> Futuristic AI engineering workstation / cyberpunk netrunner command console / neon infrastructure control room.

---

# 2. FARBSYSTEM

Verwende ein fest definiertes globales Farbsystem.

### Background

Primärer Hintergrund:

```css
--cyber-bg: #05070a;
--cyber-bg-deep: #020407;
--cyber-panel: #080d12;
--cyber-panel-2: #0b1118;
--cyber-panel-3: #0e151d;
```

Die Oberfläche darf niemals flach schwarz wirken.

Es soll mehrere sehr dunkle Ebenen geben.

Beispiel:

```text
#020407
   ↓
#05070A
   ↓
#080D12
   ↓
#0B1118
   ↓
#0E151D
```

Dadurch entsteht echte räumliche Tiefe.

---

# 3. NEON-FARBEN

## Primärfarbe: CYAN

Cyan ist die dominante Systemfarbe.

```css
--neon-cyan: #00f6ff;
--neon-cyan-bright: #5cffff;
--neon-cyan-dark: #007f87;
```

Verwendung:

* aktive Navigation
* aktive Tabs
* Fokus
* Borders
* technische Linien
* Statusanzeigen
* Netzwerkverbindungen
* Agent-Kommunikation
* Charts
* Terminal-Prompts
* Primary Actions

Cyan darf glühen.

Aber nicht alles soll leuchten.

---

## Sekundärfarbe: MAGENTA

```css
--neon-magenta: #ff00e5;
--neon-magenta-bright: #ff5cf2;
--neon-magenta-dark: #850078;
```

Verwendung:

* AI / Agent-Systeme
* Routing
* Model-Systeme
* virtuelle Modelle
* spezielle Aktionen
* aktive AI-Prozesse
* wichtige Interaktionspunkte

Magenta soll Cyan ergänzen, nicht ersetzen.

---

## WARNING: AMBER

```css
--neon-amber: #ffb000;
--neon-amber-bright: #ffd166;
```

Verwendung:

* Warning
* Queue Pressure
* Rate Limits
* Pending
* Aufmerksamkeit erforderlich

---

## ERROR: RED

```css
--neon-red: #ff1744;
--neon-red-bright: #ff4d6d;
```

Verwendung:

* Fehler
* fehlgeschlagene Verification Gates
* Provider Failure
* Agent Error
* Security Alert
* Blocked Operations

---

## SUCCESS: ACID GREEN

```css
--neon-green: #39ff14;
--neon-green-bright: #7cff5c;
```

Verwendung:

* Success
* Healthy
* Passed
* Connected
* Verification OK
* Agent Ready

---

# 4. GLOW SYSTEM

Neon darf nicht einfach durch normale `box-shadow` überall draufgeklatscht werden.

Es braucht unterschiedliche Intensitäten.

### Subtle

```css
box-shadow:
  0 0 4px rgba(0,246,255,.25);
```

### Active

```css
box-shadow:
  0 0 8px rgba(0,246,255,.45),
  inset 0 0 8px rgba(0,246,255,.08);
```

### Strong

```css
box-shadow:
  0 0 12px rgba(0,246,255,.55),
  0 0 28px rgba(0,246,255,.18);
```

Glow ausschließlich bei wichtigen Elementen verwenden.

Das Interface soll wie echte Elektronik aussehen, nicht wie eine Neonröhre explodiert wäre.

---

# 5. HEADER

Der vorhandene `HeaderBar` bleibt erhalten.

Er bekommt einen futuristischen Command-Center-Look.

Layout:

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ BKG // CODE                    ● ORCHESTRATOR       MODEL       CONTEXT       │
│ WORKSPACE / cargo-auth         STATUS: EXECUTING    QWEN...     42.8K/128K   │
└──────────────────────────────────────────────────────────────────────────────┘
```

Header:

* sehr dunkel
* 1px Cyan Border
* dünne technische Linien
* leichte Glow-Kante
* kompakte Typografie
* Monospace
* kleine Uppercase Labels
* Status LEDs

Keine riesigen Header-Texte.

Der Header soll wie ein Kontrollsystem aussehen.

---

# 6. SIDEBAR

Die bestehende `TabNavigation` bleibt erhalten.

Sie wird zur Cyberpunk-Systemnavigation.

Jede Navigationseinheit:

```text
[ICON] WORKSPACE
       TERMINAL
       CODE
       DIFF
```

oder:

```text
◆ WORKSPACE
  ├─ TERMINAL
  ├─ CODE
  ├─ DIFF
  └─ PLAN
```

Aktiver Menüpunkt:

* schwarzer/dunkler Hintergrund
* Cyan link border
* Cyan text
* leichter Cyan glow
* kleine aktive Statuslinie

Beispiel:

```text
│
│  TERMINAL
│
│  █ GOVERNOR
│
│  AGENTS
│
│  ROUTER
```

Die aktive Position muss sofort erkennbar sein.

Gruppen bekommen kleine technische Section Labels.

---

# 7. MAIN WORKSPACE

Der vorhandene Main Workspace bleibt bestehen.

Er bekommt:

```css
background:
  radial-gradient(
    circle at 50% 0%,
    rgba(0,246,255,.035),
    transparent 45%
  ),
  #080b10;
```

Zusätzlich sehr dezente Grid-Linien:

```text
┼──────┼──────┼──────┼
│      │      │      │
├──────┼──────┼──────┤
│      │      │      │
┼──────┼──────┼──────┼
```

Grid extrem subtil.

Keine sichtbare „Minecraft-Hintergrundtapete“.

---

# 8. PANELS

Alle vorhandenen Panels erhalten ein gemeinsames Cyberpunk Panel System.

```css
background: #080d12;
border: 1px solid #17252d;
```

Hover:

```css
border-color: #007f87;
```

Active:

```css
border-color: #00f6ff;
box-shadow:
  0 0 8px rgba(0,246,255,.25),
  inset 0 0 12px rgba(0,246,255,.035);
```

Panel Header:

```text
┌─ SYSTEM STATUS ────────────────────────────────┐
│                                                │
```

Nicht:

```text
System Status
[modern rounded card]
```

---

# 9. CORNERS

Nicht überall große `border-radius`.

Cyberpunk UI soll überwiegend kantig sein.

Standard:

```css
border-radius: 2px;
```

oder:

```css
border-radius: 0;
```

Nur Dialoge oder bestimmte Controls dürfen 4px bis maximal 6px verwenden.

Keine Pill-UI für alles.

Status-Badges dürfen kompakt sein.

---

# 10. TYPOGRAPHY

Primär:

```text
JetBrains Mono
IBM Plex Mono
Fira Code
monospace
```

Textfarben:

```css
--text-primary: #d7faff;
--text-secondary: #78909c;
--text-muted: #40515b;
```

Headings:

* uppercase
* letter spacing
* technisch
* kompakt

Beispiel:

```text
MODEL ROUTING CONTROL
AGENT EXECUTION STATUS
VERIFICATION GATE
WORKSPACE TELEMETRY
```

Keine riesigen Marketing-Überschriften.

---

# 11. TERMINAL

`TerminalStream` soll wie ein echtes Cyberpunk-Terminal aussehen.

Beispiel:

```text
13:42:08  ORCHESTRATOR  >
13:42:08  ARCHITECT     [ANALYZE]
13:42:09  CODER         [EXECUTE]
13:42:10  TESTER        [VERIFY]
13:42:11  REVIEWER      [PASS]
```

Farben:

* Timestamp = muted cyan
* Agent = cyan/magenta abhängig vom Agent
* command = white
* success = green
* warning = amber
* error = red

Commands bekommen einen kleinen Glow.

Cursor:

```text
█
```

oder blinkend:

```text
_
```

---

# 12. AGENTS

`MultiAgentTopology` muss visuell wie ein neuronales Cyberpunk-Netzwerk wirken.

Agent Nodes:

```text
        ┌───────────────┐
        │ ORCHESTRATOR  │
        │ ● ACTIVE      │
        └───────┬───────┘
                │
       ┌────────┼────────┐
       │        │        │
   ARCHITECT   CODER   TESTER
```

Verbindungen:

* Cyan = normal
* Magenta = AI communication
* Green = successful execution
* Amber = waiting
* Red = failure

Aktiver Agent:

* pulsing border
* subtle glow
* animated connection line

Idle Agent:

* dark gray
* minimal glow

Busy:

* animated cyan/magenta indicator

Error:

* red glow

---

# 13. GOVERNOR DASHBOARD

`GovernorDashboard` soll wie ein echtes System-Telemetriezentrum aussehen.

Keine normalen Bootstrap-Balken.

Usage bars:

```text
API KEY / PROVIDER
████████████████████░░ 82%
```

Farben dynamisch:

```text
0-60%    GREEN
60-80%   CYAN
80-90%   AMBER
90-100%  RED
```

Queue Pressure:

```text
REQUEST QUEUE

ACTIVE      14
WAITING     32
SPILLING    7

██████████████████░░
```

Wenn Requests gespillt werden:

* amber/red pulse
* „SPILLING ACTIVE“
* animierte Queue-Indikatoren

---

# 14. ROUTER

Der Router soll wie ein Netzwerk-Routing-Control-System aussehen.

Provider:

```text
NVIDIA NIM        ● HEALTHY
OPENROUTER        ● HEALTHY
GEMINI            ● DEGRADED
KILO              ● OFFLINE
```

Verbindungen als dünne Neonlinien.

Routing Priorities:

```text
MODEL
  ↓
ROUTING POLICY
  ↓
PROVIDER
  ↓
API KEY
  ↓
REQUEST
```

Virtual Models müssen klar als solche markiert werden.

Beispiel:

```text
VM / CODER-FAST
VM / CODER-REASONING
VM / REVIEWER
VM / ARCHITECT
```

Virtuelle Modelle erhalten einen leichten Magenta-Ton.

---

# 15. AGENT MODEL MAPPING

Für Agent Routing eine visuelle Matrix verwenden:

```text
AGENT             VIRTUAL MODEL             PROVIDER

ORCHESTRATOR  →   VM/ORCHESTRATOR       →   QWEN
ARCHITECT     →   VM/ARCHITECT          →   GEMMA
CODER         →   VM/CODER              →   QWEN
TESTER        →   VM/TESTER             →   MELLUM
REVIEWER      →   VM/REVIEWER           →   GEMMA
```

Aktive Zeilen bekommen Cyan Glow.

Virtual Models bekommen Magenta Accent.

Provider Status bekommt Green/Amber/Red.

---

# 16. TABLES

Tabellen sollen nicht wie normale Business Tables aussehen.

Header:

```text
┌────────────┬──────────────┬──────────┬─────────┐
│ AGENT      │ MODEL        │ STATUS   │ LATENCY │
├────────────┼──────────────┼──────────┼─────────┤
```

Rows:

* sehr dunkler Hintergrund
* dünne Borders
* Hover Glow
* monospace
* kompakte Höhe

Keine zebra-striped Bootstrap Tables.

---

# 17. BUTTONS

Buttons:

```text
[ EXECUTE ]
[ VERIFY ]
[ ROUTE ]
[ COMMIT ]
[ PUSH ]
```

Cyberpunk style:

* dark background
* 1px border
* uppercase
* monospace
* cyan accent

Hover:

* cyan text
* cyan border
* subtle glow

Danger:

* red

AI:

* magenta

Success:

* green

---

# 18. INPUTS

Inputs:

```text
┌─────────────────────────────────────────┐
│ > enter command...                      │
└─────────────────────────────────────────┘
```

Kein weißes Input-Feld.

```css
background: #030609;
color: #d7faff;
border: 1px solid #1a3138;
```

Focus:

```css
border-color: #00f6ff;
box-shadow: 0 0 8px rgba(0,246,255,.25);
```

---

# 19. STATUS INDICATORS

Alle Statusanzeigen als kleine Cyberpunk LEDs.

```text
● ONLINE
● BUSY
● IDLE
● ERROR
● DEGRADED
```

Farben:

* ONLINE = green
* BUSY = cyan
* AI ACTIVE = magenta
* IDLE = muted gray
* WARNING = amber
* ERROR = red

LEDs dürfen leicht pulsieren.

---

# 20. CODE EDITOR

`FileEditorView` soll wie ein futuristischer IDE Editor wirken.

Dark background.

Syntax highlighting.

Zeilennummern:

```text
001 │ use crate::auth;
002 │
003 │ pub fn authorize(...)
```

Modified file:

```text
● main.rs
```

Modified indicator = amber.

Active file = cyan.

Diff:

```text
- removed
+ added
```

Red/Green nur für tatsächliche Diff-Bedeutung verwenden.

---

# 21. DIFF VIEW

Cyberpunk Git interface.

```text
MODIFIED
crates/auth/src/jwt.rs

- old implementation
+ new implementation
```

Änderungsmarker an der linken Seite.

Keine riesigen Karten.

---

# 22. VERIFICATION GATE

Verification muss wie eine Security Control Station aussehen.

Beispiel:

```text
╔════════════════════════════════════════════════════╗
║ VERIFICATION GATE                                  ║
╠════════════════════════════════════════════════════╣
║                                                    ║
║ cargo fmt             ● PASS                       ║
║ cargo check           ● PASS                       ║
║ cargo test            ● PASS                       ║
║ cargo clippy          ● PASS                       ║
║                                                    ║
║ QUALITY GATE                  100 / 100             ║
╚════════════════════════════════════════════════════╝
```

PASS = green.

FAIL = red.

RUNNING = cyan animated.

---

# 23. AUDIT LOG

Audit Log muss wie Security Forensics aussehen.

```text
13:42:11
AGENT: CODER
TOOL: cargo_check
PERMISSION: workspace-write
STATUS: SUCCESS
DURATION: 380ms
```

Security-relevante Informationen visuell hervorheben.

---

# 24. CONFIGURATION

Config View:

```text
SYSTEM CONFIGURATION
────────────────────────────────────

ROUTER
SECURITY
ENVIRONMENT
API KEYS
POLICIES
```

Secrets niemals visuell als normalen Klartext hervorheben.

Secret fields:

```text
••••••••••••••••
SHA256: 8f31...
```

---

# 25. MODALS

Command Palette:

```text
╔══════════════════════════════════════════════╗
║ > search command...                          ║
╠══════════════════════════════════════════════╣
║ TERMINAL                                     ║
║ GOVERNOR                                     ║
║ ROUTER                                       ║
║ AGENTS                                       ║
║ VERIFICATION                                 ║
╚══════════════════════════════════════════════╝
```

Modal bekommt:

* dark glass-like background
* cyan border
* cyan glow
* backdrop dimming
* sharp corners

---

# 26. RESPONSIVE DESIGN

Die vorhandene responsive Struktur muss verbessert werden.

Desktop:

```text
┌──────────────────────────────────────────────────────┐
│ HEADER                                                │
├────────────┬─────────────────────────────────────────┤
│ SIDEBAR    │ MAIN WORKSPACE                          │
│            │                                         │
│            │                                         │
└────────────┴─────────────────────────────────────────┘
```

Tablet:

Sidebar kompakter.

Mobile:

Sidebar wird zu einem collapsible navigation drawer.

Main Content bekommt volle Breite.

Keine horizontalen Overflow-Balken.

Keine abgeschnittenen Panels.

Tables müssen horizontal scrollen können.

Charts müssen sich automatisch anpassen.

Header darf nicht überlaufen.

---

# 27. RESPONSIVE TYPOGRAPHY

Desktop:

```text
10px → 14px
```

Mobile:

```text
9px → 12px
```

Keine riesigen mobilen Überschriften.

Cyberpunk UI lebt von Informationsdichte.

---

# 28. ANIMATIONEN

Nur subtile technische Animationen.

Erlaubt:

* LED pulse
* glow pulse
* scanning line
* data flow
* agent connection pulse
* terminal cursor
* progress animation
* queue activity

Keine:

* übertriebene Bounce Animation
* große Kartenbewegungen
* unnötige 3D Rotation
* langsame Marketing-Animationen

Animationen sollen sich wie Hardware/Netzwerk-Telemetrie anfühlen.

---

# 29. SCANLINE / CRT EFFECT

Sehr subtil.

Optional:

```css
background-image:
  repeating-linear-gradient(
    to bottom,
    rgba(255,255,255,.012) 0px,
    rgba(255,255,255,.012) 1px,
    transparent 1px,
    transparent 4px
  );
```

Nur als sehr schwacher Layer.

Das UI darf nicht aussehen wie ein kaputter Fernseher von 1987.

---

# 30. TECHNISCHE DEKORATION

Verwende kleine technische Elemente:

```text
SYS://CORE
NODE://07
ROUTE://ACTIVE
AGENT://CODER
QUEUE://14
MEM://42.8K
```

Diese Elemente dürfen in Panel Headers oder Statusleisten erscheinen.

Sie dienen der visuellen Atmosphäre, dürfen aber niemals echte Informationen ersetzen.

---

# 31. ICONS

Icons minimal und technisch.

Bevorzugt:

* Terminal
* Code
* Git
* Network
* CPU
* Shield
* Brain
* Database
* Activity
* Route
* Settings
* Alert

Icons in normalem Zustand muted.

Aktiv Cyan.

AI-bezogen Magenta.

---

# 32. VISUELLE HIERARCHIE

Die wichtigsten Dinge müssen zuerst auffallen:

1. aktueller Systemstatus
2. aktiver Agent
3. aktive Model Route
4. Fehler / Warnings
5. Queue Pressure
6. Verification
7. Logs
8. Detailinformationen

Nicht jede UI-Komponente darf gleichzeitig schreien.

Cyberpunk bedeutet kontrollierte Informationsüberlastung, nicht einfach 47 leuchtende Buttons.

---

# 33. DESIGN TOKEN SYSTEM

Alle Farben zentralisieren.

Keine zufällig verteilten Hex-Werte in Komponenten.

Beispiel:

```css
:root {
  --cyber-bg: #05070a;
  --cyber-panel: #080d12;
  --cyber-panel-hover: #0d151d;

  --neon-cyan: #00f6ff;
  --neon-magenta: #ff00e5;
  --neon-green: #39ff14;
  --neon-amber: #ffb000;
  --neon-red: #ff1744;

  --text-primary: #d7faff;
  --text-secondary: #78909c;
  --text-muted: #40515b;

  --border: #17252d;
  --border-active: #00f6ff;
}
```

Alle bestehenden Komponenten sollen diese Tokens verwenden.

---

# 34. WICHTIG: FUNKTIONALITÄT NICHT ZERSTÖREN

Die bestehende React-Logik muss erhalten bleiben.

Insbesondere:

* `activeTab`
* `openNavGroup`
* `isNavCollapsed`
* Agent Status
* Router Configuration
* Model Routing
* Virtual Models
* Agent Routing
* Governor
* Git
* Branches
* Commits
* Stashes
* Hooks
* Checkpoints
* Audit Logs
* Context Memory
* Verification
* Planning
* Pipelines
* Sandbox
* Simulation
* Agent Chat
* Command Palette
* Keyboard Shortcuts

dürfen durch die Designüberarbeitung nicht kaputtgehen.

Keine Mock-Daten als Ersatz für echte State-Logik einführen.

Keine bestehenden Event Handler entfernen.

Keine Komponenten entfernen, nur weil sie schwieriger zu stylen sind.

---

# 35. COMPONENT-SCOPE

Überarbeite insbesondere:

```text
HeaderBar
TabNavigation
TerminalStream
FileEditorView
DiffViewer
MultiAgentTopology
GovernorDashboard
RouterCentralView
PlanTrackerView
VerificationGateView
ToolSystemView
ContextMemoryView
AuditLogView
ConfigRouterView
NvidiaNimRouterView
GoogleGeminiRouterView
OpenRouterView
KiloCodeRouterView
ParallelSimulationView
PredictiveArchitectureView
ZeroTrustSandboxView
CommandPaletteModal
CheckpointsModal
CheatSheetModal
AgentChatPanel
AgentPerformanceView
GitGraphView
PipelinesView
PlanningStudioView
```

Alle Komponenten müssen sich wie Teile **eines einzigen Cyberpunk-Systems** anfühlen.

Nicht jede Komponente darf ihren eigenen Designstil besitzen.

---

# 36. ENDRESULTAT

Das Endergebnis soll aussehen wie:

> Eine professionelle Cyberpunk-AI-Entwicklerkonsole, mit der ein autonomes Multi-Agent-System, Model Router, Provider, Git Workspace, Verification Pipeline und AI Execution Engine überwacht und gesteuert werden.

Visuell:

```text
DARK
   +
CYAN NEON
   +
MAGENTA AI
   +
GREEN HEALTH
   +
AMBER WARNING
   +
RED FAILURE
   +
MONOSPACE
   +
TECHNICAL GRID
   +
SUBTLE GLOW
   +
DENSE INFORMATION
   =
CYBERPUNK AI COMMAND CENTER
```

Das Design muss **hochwertig, technisch und konsistent** wirken.

Nicht verspielt.

Nicht cartoonartig.

Nicht wie ein Gaming-Menü.

Nicht wie ein gewöhnliches Admin-Dashboard.

Sondern wie eine echte futuristische Entwickler- und AI-Operations-Konsole.
