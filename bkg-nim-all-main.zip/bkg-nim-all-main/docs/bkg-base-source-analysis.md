# BKG-BASE Source Analysis

## Overview

This document provides a comprehensive analysis of the source code repositories that inform the BKG-BASE foundation layer. It documents the repositories, key files, capabilities, invariants, behavior observations, rejected assumptions, and Rust design rationale.

### Purpose

To establish a solid foundation for the BKG-BASE crate by understanding existing behavioral implementations, identifying reusable capabilities, and designing independent Rust concepts that avoid structural copying while capturing the essential behavior.

## Repository Analysis

### 1. mindfoundry (Python)

**Purpose**: Core simulation engine for hotel/hospitality scenarios with agent-based interactions.

**Key Files**:
- `server.py`: Main server entrypoint handling HTTP/WebSocket requests
- `generate.py`: Hotel scenario generation and population
- `evaluate.py`: Evaluation metrics and scoring system
- `live_ops.py`: Live operational controls and monitoring
- `replicants.py`: Agent replication and management logic
- `policy_gate.py`: Policy enforcement mechanisms
- `hotel_sim.sqlite`: Persistent storage for simulation state

**Capabilities Identified**:
- Agent lifecycle management (creation, replication, termination)
- Policy-based decision making
- Event-driven architecture
- State persistence with SQLite
- Message routing and dispatch
- Simulation state management

### 2. agent-memory-systems (Python)

**Purpose**: Memory management system for agent-based applications.

**Key Files**:
- `consolidate.py`: Memory consolidation and summarization
- `extract.py`: Memory extraction from various sources
- `memory/` module:
  - `base.py`: Core memory abstraction
  - `episodic.py`: Episodic memory handling
  - `facts.py`: Fact-based memory storage
  - `graph.py`: Graph-based memory representation
  - `summary.py`: Summary generation
  - `window.py`: Context window management

**Capabilities Identified**:
- Memory consolidation and summarization
- Fact extraction and classification
- Graph-based memory relationships
- Episodic memory storage and retrieval
- Context window management
- Memory graph traversal

### 3. nim-proxy (Rust)

**Purpose**: Proxy service for NIM (NVIDIA Inference Microservice) integration.

**Key Files**:
- `auth.rs`: Authentication and authorization logic
- `config.rs`: Configuration management
- `dispatch.rs`: Request dispatching and routing
- `governor.rs`: Governance and policy enforcement
- `history.rs`: Request/response history tracking
- `lib.rs`: Core library functions and types
- `pool.rs`: Connection pooling and resource management
- `proxy.rs`: Main proxy logic and API endpoints
- `settings.rs`: Configuration settings
- `main.rs`: Application entry point

**Capabilities Identified**:
- Authentication and authorization (JWT, API keys)
- Configuration management (dynamic settings)
- Request dispatching and routing
- Governance policies
- Request history tracking
- Connection pooling
- Service lifecycle management

### 4. policyNIM (Python)

**Purpose**: Policy engine for NIM integration with rich policy management capabilities.

**Key Files**:
- `agent_workflows.py`: Agent workflow definition and execution
- `config_discovery.py`: Policy discovery mechanisms
- `contracts.py`: Policy contract definitions
- `errors.py`: Error handling and reporting
- `ingest/`: Data ingestion modules
- `interfaces/`: Interface definitions
- `providers/`: Provider integration modules
- `runtime_paths.py`: Runtime configuration paths
- `services/`: Service orchestration
- `settings.py`: Global settings management
- `storage/`: Persistent storage mechanisms
- `templates/`: Template-based policy generation

**Capabilities Identified**:
- Policy definition and evaluation
- Workflow orchestration
- Policy discovery and loading
- Error handling and reporting
- Data ingestion pipelines
- Service orchestration
- Template-based policy generation

### 5. rag_nim (Python)

**Purpose**: Retrieval-Augmented Generation (RAG) system for chatbot applications.

**Key Files**:
- `chatbot.py`, `complex_rag_chatbot.py`, `enhanced_chatbot.py`: Chatbot implementations
- `rag_chatbot_0.py`, `rag_chatbot_1.py`: RAG-specific implementations
- `rag_demo.png`: Visualization asset
- `data/`: Data storage for RAG contexts
- Various utility scripts for setup and configuration

**Capabilities Identified**:
- Retrieval-augmented generation
- Context management for chat sessions
- Document retrieval and ranking
- Prompt engineering
- Chatbot state management

## File Analysis

### Key Patterns Observed

1. **State Management**: Most systems use explicit state objects with clear transitions (e.g., `hotel_sim.sqlite`, memory graph structures).
2. **Event-Driven Architecture**: Event emission and handling is prevalent across all repositories.
3. **Policy Enforcement**: Multiple systems implement policy-based decision making (policyNIM, mindfoundry).
4. **Memory Management**: Memory systems use graph structures, episodic storage, and fact-based storage.
5. **Authentication/Authorization**: nim-proxy implements robust auth mechanisms with JWT and API keys.
6. **Serialization**: Heavy use of serialization for state persistence (SQLite, JSON, custom formats).

## Capability Matrix

| Capability | Repository | Key Files | Notes |
|------------|------------|-----------|-------|
| Agent Lifecycle Management | mindfoundry | replicants.py, server.py | Agent creation, replication, termination |
| Policy-Based Decision Making | mindfoundry, policyNIM | policy_gate.py, contracts.py | Rule evaluation, policy enforcement |
| Memory Consolidation | agent-memory-systems | consolidate.py, memory/*.py | Summarization, fact extraction |
| Graph-Based Memory | agent-memory-systems | memory/graph.py | Relationship storage and traversal |
| Event Dispatching | nim-proxy | dispatch.rs, proxy.rs | Request routing and dispatch |
| Authentication | nim-proxy | auth.rs | JWT, API key management |
| Configuration Management | nim-proxy, policyNIM | config.rs, settings.py | Dynamic config loading |
| RAG Retrieval | rag_nim | rag_chatbot*.py | Document retrieval, ranking |
| State Persistence | mindfoundry | hotel_sim.sqlite | SQLite-based state storage |
| Event-Driven Architecture | all | various | Event emission and handling throughout |

## Extracted Invariants

1. **State Consistency**: All systems maintain explicit state objects that change through well-defined transitions.
2. **Policy Centralization**: Policy decisions are centralized in dedicated modules rather than scattered.
3. **Memory Graph Structure**: Memory systems consistently use graph representations for relationships.
4. **Serialization Requirements**: State persistence requires serializable data structures.
4. **Async Operations**: Many components use asynchronous patterns for I/O operations.
5. **Error Handling**: Structured error handling with clear error types is prevalent.

## Behavior Observations

- **Mindfoundry**: Heavy use of Python classes with inheritance hierarchies; state is often stored in SQLite with JSON serialization.
- **Agent Memory**: Uses explicit graph structures with node/edge relationships; memory consolidation is a recurring theme.
- **NIM Proxy**: Rust implementation with strong type safety; uses async/await patterns; heavy reliance on serde for serialization.
- **PolicyNIM**: Modular Python architecture with clear separation between policy definitions and execution.
- **RAG**: Focus on context window management and retrieval scoring algorithms.

## Rejected Assumptions

1. **Structural Copying**: Assuming that Rust structs should directly map to Python class structures was rejected. Instead, we design Rust concepts based on behavior, not structure.
2. **Direct Translation**: Not all Python patterns (e.g., decorators, metaclasses) have direct equivalents in Rust; we identified Rust-native approaches.
3. **Feature Parity**: We do not aim for 1:1 feature parity with MindFoundry; we focus on core capabilities needed for the foundation layer.
4. **Dependency Structure**: We reject the idea that all crates should be tightly coupled; we design independent modules with clear boundaries.

## Rust Design Rationale

### Core Principles

1. **Behavior-Driven Design**: Rust types are designed based on observed behavior rather than structural similarity to Python code.
2. **Independent Module Boundaries**: Each capability resides in its own module with clear interfaces.
3. **Trait-Based Abstraction**: Plugin interfaces and service boundaries are defined through traits for stability.
4. **Serde Integration**: serde is used for serialization with careful schema design to avoid breaking changes.
5. **Async First**: Async patterns are used throughout for I/O operations, with sync fallbacks where appropriate.
6. **Error Handling**: Structured error handling using thiserror crate with clear error types.
7. **Lifetime Safety**: Rust's ownership system ensures memory safety without garbage collection.

### Module Design

- **base**: Core types, traits, errors, and fundamental utilities (this crate)
- **storage**: Persistence layer (SQLite, file-based) with async interfaces
- **memory**: Memory management with graph structures and episodic storage
- **policy**: Policy evaluation and enforcement mechanisms
- **rag**: Retrieval-augmented generation components
- **simulation**: Simulation engine foundations
- **runtime**: Runtime orchestration and service coordination
- **plugin-runtime**: Plugin interface definitions and management

### Trait Design

- **ServiceProvider**: Abstraction for external services (NIM, Discord, etc.)
- **StateProvider**: Trait for state persistence implementations
- **MemoryProvider**: Trait for memory management strategies
- **PolicyEngine**: Trait for policy evaluation mechanisms
- **EventHandler**: Trait for event processing and routing

### Serialization Design

- Use serde with explicit versioning
- Define dedicated serialization schemas for each major type
- Avoid generic JSON serialization of complex state; use specialized serializers

### Async Pattern

- Use async-trait for plugin interfaces to maintain stability across Rust versions
- Employ Tokio runtime for async operations
- Design non-blocking I/O operations throughout

### Error Handling

- Use thiserror for custom error types
- Define error enums for each module with clear semantics
- Implement proper error propagation through trait boundaries

## Conclusion

This analysis establishes the foundation for designing the BKG-BASE crate. By understanding the behavioral patterns across repositories, we can create independent Rust concepts that capture the essential functionality without structural copying. The next step is to create the architecture document that formalizes these design decisions.