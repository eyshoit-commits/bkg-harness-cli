# Gap Analysis: Current State vs. Target Architecture

## Summary
Current implementation is a **skeleton** with structural issues that prevent compilation.

## Critical Compilation Errors

### 1. base/src/lib.rs vs. actual file layout
**Current**: `base/src/lib.rs` declares:
```rust
pub mod domain;    // expects src/domain/mod.rs or src/domain.rs
pub mod error;     // expects src/error/mod.rs or src/error.rs
pub mod events;    // expects src/events/mod.rs or src/events.rs
pub mod traits;    // expects src/traits/mod.rs or src/traits.rs
pub mod plugin;    // expects src/plugin/mod.rs or src/plugin.rs
```

**Actual files**:
```
base/src/domain.rs      ← matches pub mod domain;
base/src/error.rs       ← matches pub mod error;
base/src/events.rs      ← matches pub mod events;
base/src/traits.rs      ← matches pub mod traits;
base/src/plugin.rs      ← matches pub mod plugin;
```

**Status**: Compiles correctly (flat module files).

### 2. runtime/src/orchestrator.rs imports non-existent modules
```rust
use crate::memory::*;   // runtime has NO memory module
use crate::policy::*;   // runtime has NO policy module
use crate::sim::*;      // runtime has NO sim module
```

**Status**: Does **not** compile. Needs:
```rust
use base::{Memory, Policy, ...};  // or specific crate imports
```

### 3. base/src/traits.rs imports non-existent modules
```rust
use crate::memory::*;   // base has NO memory module
use crate::policy::*;   // base has NO policy module
```

**Status**: Does **not** compile. Needs removal or proper path.

## Missing Crates

| Crate | Status | Cargo.toml | Source |
|-------|--------|------------|--------|
| nim | Empty directory | ❌ Missing | ❌ Missing |
| proxy | Empty directory | ❌ Missing | ❌ Missing |

## Missing Dependencies

### base/Cargo.toml
```toml
[package]
name = "bkg-base"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = { version = "1", features = ["derive"] }
thiserror = "1"
chrono = "0.4"
uuid = { version = "1", features = ["v4"] }
async-trait = "0.1"
async-std = "1.10"
rand = "0.8"
```
**Current**: Only lists `rand` and `async-std` without `[package]` header. Missing `serde`, `thiserror`, `chrono`, `uuid`, `async-trait`.

### memory/Cargo.toml
```toml
[package]
name = "bkg-memory"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
serde = { version = "1", features = ["derive"] }
chrono = "0.4"
```
**Current**: Only has `[package]` section, no `[dependencies]`.

### policy/Cargo.toml
```toml
[package]
name = "bkg-policy"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
serde = { version = "1", features = ["derive"] }
thiserror = "1"
```
**Current**: Only has `[package]` section, no `[dependencies]`.

### rag/Cargo.toml
```toml
[package]
name = "bkg-rag"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
serde = { version = "1", features = ["derive"] }
```
**Current**: Only has `[package]` section, no `[dependencies]`.

### storage/Cargo.toml
```toml
[package]
name = "bkg-storage"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
serde = { version = "1", features = ["derive"] }
sqlx = { version = "0.7", features = ["runtime-tokio", "sqlite"] }
tokio = { version = "1", features = ["full"] }
```
**Current**: Only has `[package]` section, no `[dependencies]`.

### simulation/Cargo.toml
```toml
[package]
name = "bkg-simulation"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
rand = "0.8"
chrono = "0.4"
```
**Current**: Only has `[package]` section, no `[dependencies]`.

### runtime/Cargo.toml
```toml
[package]
name = "bkg-runtime"
version = "0.1.0"
edition = "2021"

[dependencies]
bkg-base = { path = "../base" }
bkg-memory = { path = "../memory" }
bkg-policy = { path = "../policy" }
bkg-rag = { path = "../rag" }
bkg-simulation = { path = "../simulation" }
bkg-storage = { path = "../storage" }
async-trait = "0.1"
tokio = { version = "1", features = ["full"] }
```
**Current**: Only has `[package]` section, no `[dependencies]`.

## Type Duplication Violations

### PolicyKind
- **Defined in**: `base/src/domain.rs` (Zeile 347-354)
- **Also defined in**: `policy/src/gate.rs` (Zeile 7-14)
- **Violation**: Gemeinsamer Typ sollte nur in `base` existieren

### MemoryType
- **Defined in**: `base/src/events.rs` (Zeile 102-106) — als Payload-Teil
- **Also defined in**: `memory/src/store.rs` (Zeile 25-29)
- **Violation**: Gemeinsamer Typ sollte nur in `base` existieren

### Memory (struct)
- **Defined in**: `base/src/domain.rs` (Zeile 59-66)
- **Also defined in**: `memory/src/store.rs` (nicht exakt gleich, aber ähnlich als `MemoryEntry`)
- **Violation**: `Memory` gehört nur nach `base`

### Status, Role
- **Defined in**: `base/src/domain.rs` (Zeile 240-245, 311-315)
- **Also defined in**: `simulation/src/generator.rs` (indirekt über `Reservation.status` und `Staff.role` als Feldtypen)
- **Violation**: Enums gehören nur nach `base`

## Missing Module Files (per Target Design)

### memory/src/
- ❌ `profile.rs` — nicht vorhanden
- ❌ `entry.rs` — nicht vorhanden
- ❌ `backend.rs` — nicht vorhanden
- ✅ `store.rs` — vorhanden

### policy/src/
- ✅ `gate.rs` — vorhanden

### rag/src/
- ✅ `retrieval.rs` — vorhanden

### storage/src/
- ❌ `backend.rs` — nicht vorhanden (nur `persist.rs` vorhanden)
- ✅ `persist.rs` — vorhanden

### simulation/src/
- ✅ `generator.rs` — vorhanden

### runtime/src/
- ✅ `orchestrator.rs` — vorhanden

## Runtime Violations

### runtime/src/orchestrator.rs
```rust
use crate::memory::*;   // ❌ Verstößt gegen Abhängigkeitsregel
use crate::policy::*;   // ❌ Verstößt gegen Abhängigkeitsregel
use crate::sim::*;      // ❌ Verstößt gegen Abhängigkeitsregel + Modul existiert nicht
```

**Sollte sein**:
```rust
use bkg_base::{Memory, Policy, ...};
// oder spezifische Crate-Imports
use bkg_memory::MemoryStore;
use bkg_policy::PolicyEngine;
```

## Simulation Violations

### simulation/src/generator.rs
- Definiert domänenspezifische Typen (`Reservation`, `Guest`, `Staff`)
- Diese gehören nach `base/src/domain.rs` als gemeinsame Typen
- `Status` und `Role` sind bereits in `base` definiert, werden hier aber als Feldtypen verwendet ohne Import

## Nim / Proxy
- Beide Crates existieren nicht (keine Cargo.toml, kein src/)
- Gemäß Target-Design müssen sie erstellt werden

## Empfohlene Priorisierung

1. **P0 — Kompilierbar machen**:
   - `base/Cargo.toml` dependencies ergänzen
   - `runtime/src/orchestrator.rs` Imports reparieren
   - `base/src/traits.rs` Imports reparieren
   - Alle anderen `Cargo.toml` dependencies ergänzen

2. **P1 — Type Consolidation**:
   - `PolicyKind` aus `policy/src/gate.rs` entfernen (existiert in `base`)
   - `MemoryType` aus `memory/src/store.rs` entfernen (existiert in `base/events.rs`)
   - `MemoryEntry` / `ReplicantMemory` nach `base` verschieben oder entfernen
   - `Status`, `Role` Import aus `base` in `simulation` hinzufügen

3. **P2 — Neue Module**:
   - `memory/src/profile.rs`, `entry.rs`, `backend.rs` erstellen
   - `storage/src/backend.rs` erstellen

4. **P3 — Neue Crates**:
   - `nim/` erstellen
   - `proxy/` erstellen
