# BKG-BASE Architecture

## Overview

This document defines the architecture of the BKG-BASE foundation layer, which provides core types, traits, errors, events, and plugin contracts for the BKG ecosystem. The architecture is designed to be independent, modular, and plugin-ready.

### Design Goals

1. **Independence**: Base crate has no dependencies on other BKG crates or external providers
2. **Modularity**: Clear separation of concerns with well-defined module boundaries
3. **Plugin Stability**: Plugin interfaces remain stable across Rust compiler versions
4. **Testability**: Components are designed for easy testing and isolation
5. **Type Safety**: Rust's type system ensures memory safety and compile-time guarantees

## Module Structure

The BKG-BASE architecture consists of the following modules:

### 1. Core Types and Traits (`base`)

- **Primitive Types**: Fundamental Rust types extended with domain-specific functionality
- **Error Types**: Structured error handling with thiserror
- **Event Types**: Standardized event definitions for event-driven architecture
- **Trait Definitions**: Core traits that enable plugin architecture and service boundaries

### 2. Memory Management (`memory`)

- **Memory Provider Trait**: Abstraction for different memory storage strategies
- **Graph-Based Memory**: Node-edge relationship storage with traversal capabilities
- **Episodic Memory**: Time-series memory storage with expiration policies
- **Fact Storage**: Fact-based storage for semantic information
- **Serialization**: Custom serde serializers for memory types

### 2. Policy Engine (`policy`)

- **Policy Definition Language**: DSL for expressing policies
- **Policy Evaluation**: Runtime evaluation of policy conditions
- **Policy Caching**: Efficient policy evaluation with caching mechanisms
- **Policy Versioning**: Support for policy version management

### 3. Event System (`events`)

- **Event Types**: Standardized event definitions
- **Event Bus**: Asynchronous event routing system
- **Event Handling**: Decoupled event processing
- **Event Serialization**: Efficient event serialization format

### 4. Simulation Foundation (`simulation`)

- **Simulation State**: Base state representation
- **Step Logic**: Simulation step execution pattern
- **Determinism**: Guarantees for reproducible simulation results
- **Event Emission**: Built-in event emission during simulation steps

### 5. Runtime Orchestration (`runtime`)

- **Service Discovery**: Dynamic service discovery mechanisms
- **Lifecycle Management**: Component lifecycle tracking
- **Dependency Injection**: Constructor-based dependency management
- **Concurrency**: Thread-safe operations and synchronization primitives

## Trait Design

### Service Provider Trait

```rust
trait ServiceProvider {
    async fn request(&self, method: &str, path: &str, body: Option<&[u8]>) -> Result<Response, Error>;
    async fn subscribe(&self, topic: &str, handler: impl Fn(Message) + Send + 'static);
}
```

### State Provider Trait

```rust
trait StateProvider {
    async fn save_state(&self, state: &State) -> Result<(), Error>;
    async fn load_state(&self, id: &str) -> Result<State, Error>;
    async fn clear_state(&self, id: &str) -> Result<(), Error>;
}
```

### Memory Provider Trait

```rust
trait MemoryProvider {
    async fn store(&self, key: &str, value: &MemoryEntry) -> Result<(), Error>;
    async fn retrieve(&self, key: &str) -> Result<Option<MemoryEntry>, Error>;
    async fn delete(&self, key: &str) -> Result<(), Error>;
    async fn list_keys(&self) -> Result<Vec<String>, Error>;
}
```

### Policy Engine Trait

```rust
trait PolicyEngine {
    async fn evaluate(&self, context: &Context) -> Result<bool, Error>;
    async fn load_policy(&self, path: &str) -> Result<Policy, Error>;
    async fn cache_policy(&self, policy: &Policy) -> Result<(), Error>;
}
```

## Dependency Graph

```
base
├── storage
│   └── sqlx (runtime dependency)
├── memory
│   └── serde (serde dependency)
├── policy
│   └── thiserror, serde
├── events
│   └── futures, tokio
└── simulation
    └── chrono, uuid
```

## Implementation Rules

1. **No External Provider Dependencies**: Base crate must not depend on NIM, Discord, Google, or other external services
2. **Plugin Compatibility**: Plugin interfaces must use async-trait for cross-version compatibility
3. **Zero-Copy Design**: Avoid unnecessary data copying; use references where possible
4. **Minimal Dependencies**: Only include dependencies that are absolutely necessary
4. **Type Safety**: Ensure all public APIs have proper error handling and type safety
5. **Documentation**: All public items must have comprehensive documentation

## Error Handling Strategy

- Use thiserror crate for custom error types
- Define error enums per module with clear semantics
- Implement proper error propagation through trait boundaries
- Provide descriptive error messages for debugging

## Serialization Strategy

- Use serde with explicit versioning
- Define dedicated serialization schemas for complex types
- Avoid generic JSON serialization of state objects
- Implement custom serializers for memory-efficient storage

## Testing Approach

- All public APIs must have unit tests
- Mock-based testing for trait implementations
- Integration tests for module interactions
- Property-based testing for critical algorithms

## Future Extensibility

The architecture is designed to accommodate future expansion:

- New modules can be added without breaking existing dependencies
- Trait extensions can be made backward compatible
- Plugin interfaces can evolve while maintaining compatibility
- The crate can be split into smaller crates if needed

## Conclusion

The BKG-BASE architecture provides a solid foundation for building plugin-based applications with clear boundaries, type safety, and plugin compatibility. The design emphasizes independence, modularity, and testability while maintaining compatibility with future extensions.