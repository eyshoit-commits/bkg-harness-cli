# Spec: base-spec

Scope: feature

# BKG-BASE Feature Specification

## Description
Implement the BKG-BASE foundation layer as an independent Rust crate that provides core types, error handling, service provider traits, and plugin interfaces. The crate must be completely self-contained with no dependencies on external provider services (NIM, Discord, Google, etc.) and must follow the architectural guidelines defined in the BKG-BASE architecture document.

## Functional Requirements
- Define core data types (e.g., MemoryEntry, Event, State) with serde support.
- Implement custom error types using the `thiserror` crate.
- Create and implement the following service provider traits:
  - `ServiceProvider` for external service interactions.
  - `StateProvider` for state persistence.
  - `MemoryProvider` for memory management strategies.
  - `PolicyEngine` for policy evaluation.
- Implement a plugin interface using `async-trait` to ensure cross-version compatibility.
- Provide comprehensive documentation comments for all public items.
- Ensure the crate builds successfully with `cargo check` and has no external provider dependencies.

## Non-Functional Requirements
- Maintain zero external provider dependencies in the base crate.
- Use async-trait for plugin ABI stability across Rust compiler versions.
- Follow Rust 2024 edition conventions and style guidelines.
- Ensure all public APIs are well-documented and type-safe.
- Keep the dependency list minimal, including only `serde`, `serde_json`, `thiserror`, `uuid`, `chrono`, `async-trait`, `semver`, and `futures`.

## Acceptance Criteria
1. All core types compile without external provider dependencies.
2. Custom error types are defined and usable throughout the crate.
3. All required service provider traits are implemented and documented.
4. Plugin interface using `async-trait` is defined and compiles.
4. Comprehensive documentation comments are present for all public items.
5. `cargo check` passes without errors.
6. No external provider crates (e.g., NIM, Discord) are directly depended on in `Cargo.toml`.

## Out of Scope
- Implementation of runtime services (e.g., tokio, sqlx, tracing).
- Integration with other BKG crates (memory, rag, simulation, etc.).
- User interface or command-line tools.
- External library integrations beyond the specified dependencies.