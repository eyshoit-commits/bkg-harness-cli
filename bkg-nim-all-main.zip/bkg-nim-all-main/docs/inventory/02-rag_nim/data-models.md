# Datenmodell-Analyse: rag_nim

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

## Datenmodelle im Überblick

| Modell | Definition (belegt) | Persistenz |
|---|---|---|
| LangChain-Dokument | `page_content`, `metadata` (aus `PyPDFDirectoryLoader`) | nur Session-State |
| Chunk | Ausgabe von `RecursiveCharacterTextSplitter(700/50)` | nur Session-State |
| Embedding | Ausgabe von `NVIDIAEmbeddings()`; Vektor je Chunk | nur im FAISS-Index (Session) |
| FAISS-Index (`vectors`) | `FAISS.from_documents(final_documents, embeddings)` | In-Memory (Session) |
| Retriever | `vectors.as_retriever()` | abgeleitet, kein eigener Zustand |
| Conversation/History | `history`-Liste von `{"question", "answer"}` | nur Session-State |
| Konfiguration | `NVIDIA_API_KEY` (`.env`), Modell-String, Splitter-Parameter, Sampling-Parameter | `.env` (Datei), Rest im Code |
| Verlaufs-Export | `search_history.json` (via `st.download_button`) | Browser-Download, keine Speicherung |

---

## LangChain-Dokument

- **Bedeutung:** Zentrale Einheit der Ingest-Phase: ein PDF (bzw. ein PDF-Abschnitt) als Text plus Metadaten. Belegt durch `PyPDFDirectoryLoader` → `docs` → `final_documents` und Zugriffe auf `doc.page_content`/`doc.metadata` (rag_chatbot_0.py, chatbot.py).
- **Lebenszyklus:** Entsteht beim Laden aus `./data` oder Upload; wird zu Chunks gespalten; Chunks werden zu Embeddings und in FAISS gespeichert; nach der Session verworfen.
- **Ownership:** Gehalten im Streamlit-Session-State (`st.session_state.docs`, `st.session_state.final_documents`); pro Browser-Session.
- **Beziehungen:** Dokument → N Chunks (via Splitter); Chunk → 1 Embedding (via `NVIDIAEmbeddings`); Chunk → Eintrag im FAISS-Index. Metadaten (`source`) werden für Punkt-Labels der t-SNE-Visualisierung genutzt (chatbot.py, complex_rag_chatbot.py: `metadata[idx].get('source', 'Unknown')`).
- **Persistenz:** Keine; nur Session-State. PDF-Quelldateien liegen im Dateisystem unter `data/` (Attention.pdf, Raptor.pdf).
- **Validierung:** Keine Validierung im Code (keine leeren-Seite-Prüfung, keine Textlängen-Prüfung).
- **Mutationen:** `page_content` wird nicht mutiert; `final_documents` wird durch Truncation zur Laufzeit in eine gekürzte Liste überführt (`truncate_documents_for_token_limit`).
- **Thread-Sicherheit:** Kein nebenläufiger Zugriff; Streamlit-Reruns laufen im Event-Loop des Streamlit-Servers (Threading-Verhalten des Frameworks, im Quellcode nicht behandelt).
- **Benötigte Rust-Konzepte:** `struct Document { content: String, metadata: HashMap<String, String> }`; Ownership klar (jeweils eine Stelle); Persistenz optional als serialisierbare Struktur (serde).

## Chunk

- **Bedeutung:** Segment eines Dokuments mit fester Größenordnung; ist die Retrieval-Einheit (ein Chunk = ein FAISS-Eintrag).
- **Lebenszyklus:** Entsteht im Splitter (`RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)`); lebt bis Session-Ende; wird beim Retrieve als Kontext an das LLM gegeben.
- **Ownership:** `st.session_state.final_documents`; nach Indexierung dupliziert FAISS den Text (FAISS speichert Embedding + Dokumenttext als `Document`-Liste — belegt durch `FAISS.from_documents`).
- **Beziehungen:** Chunk → 1 Embedding; Chunk → 1 Index-Eintrag; N Chunks → LLM-Prompt (Stuff-Chain).
- **Persistenz:** Keine.
- **Validierung:** Keine; auch die Kappung auf `docs[:40]` (rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py) ist eine Mengen-, keine Inhaltsvalidierung.
- **Mutationen:** Keine inhaltlichen; Listenbildung/Tranchen über Splitter.
- **Thread-Sicherheit:** Keine nebenläufige Nutzung belegt.
- **Benötigte Rust-Konzepte:** Chunker als eigenständige Einheit mit deterministischer Ausgabe (pure Funktion: `&str → Vec<Chunk>`); Chunk mit `source`-Metadatum; Testbarkeit der Grenzfälle (700/50).

## Embedding

- **Bedeutung:** Numerische Vektor-Repräsentation eines Chunks; Grundlage der Ähnlichkeitssuche.
- **Lebenszyklus:** Erzeugt im Embedding-Aufruf (`NVIDIAEmbeddings()`), unmittelbar in FAISS gespeichert; Rekonstruktion nur für Visualisierung (`vectors.index.reconstruct(i)`).
- **Ownership:** FAISS-Index; für die Visualisierung in ein `numpy`-Array kopiert (`np.array([...])`).
- **Beziehungen:** 1:1 zum Chunk (über `from_documents`).
- **Persistenz:** Nur In-Memory; kein Speichern/Laden des Index (kein `save_local`/`load_local` im Code).
- **Validierung:** Keine (Dimension/Fehler des Embedding-Dienstes werden nicht geprüft).
- **Mutationen:** Keine nach Erzeugung; t-SNE projiziert Kopien.
- **Thread-Sicherheit:** Keine nebenläufige Nutzung belegt.
- **Benötigte Rust-Konzepte:** `Vec<f32>`-Vektoren; Batch-Verarbeitung async; Fehlerbehandlung der Embedding-API (Rate Limits, Validierung der Dimension); Caching-Überlegung für wiederholte Anfragen.

## FAISS-Index (`vectors`)

- **Bedeutung:** In-Memory-Vektor-Datenbank mit Ähnlichkeitssuche; zentrale Abfragequelle der Chat-Phase.
- **Lebenszyklus:** Entsteht in `vector_embedding()` via `FAISS.from_documents(...)`; lebt bis Session-Ende; wird nur gelesen (`as_retriever()`, `index.ntotal`, `index.reconstruct`).
- **Ownership:** `st.session_state.vectors`; FAISS intern (Index + Dokument-Store).
- **Beziehungen:** Retriever-Konfiguration hängt am Index; Antwort-`context` (Retrieved Chunks) stammt aus dem Index.
- **Persistenz:** Keine; ein Session-Restart erfordert einen neuen Embedding-Build.
- **Validierung:** `None`-Prüfung als Chat-Vorbedingung (alle Chatbot-Varianten außer rag_langchain_nim_1.py).
- **Mutationen:** Keine nach dem Build (kein Hinzufügen/Entfernen zur Laufzeit belegt).
- **Thread-Sicherheit:** Keine nebenläufige Nutzung belegt; Streamlit-Session-Isolation via Framework.
- **Benötigte Rust-Konzepte:** Eigener Vektor-Index-Typ mit `ntotal`-/`reconstruct`-äquivalenten Operationen oder Crate (z.B. auf HNSW/bruteforce-Basis); `Option<Index>` statt `None`-Sentinel; Serialisierung für Persistenz als Designentscheidung.

## Retriever-Konfiguration

- **Bedeutung:** Abstraktion, die die Ähnlichkeitssuche für die Retrieval-Chain bereitstellt.
- **Lebenszyklus:** Wird pro Chat-Anfrage erzeugt (`vectors.as_retriever()`) — kein gespeicherter Zustand.
- **Ownership:** Wegwerf-Objekt je Anfrage.
- **Beziehungen:** Retriever → FAISS-Index; Retrieval-Chain → Retriever + Stuff-Chain.
- **Persistenz:** Keine.
- **Validierung:** Keine Parameter (kein `k`/top-k, keine Score-Schwelle im Code belegt).
- **Mutationen:** Keine.
- **Thread-Sicherheit:** Keine relevant.
- **Benötigte Rust-Konzepte:** `Retriever`-Trait mit `retrieve(query) -> Result<Vec<RetrievedChunk>>`; Top-k und Score-Metrik als explizite Konfiguration.

## Conversation/History

- **Bedeutung:** Frage/Antwort-Verlauf der Session; Grundlage für Verlaufsanzeige und JSON-Export.
- **Lebenszyklus:** Entsteht mit jedem Chat (`history.append({"question": ..., "answer": ...})`); nur in rag_chatbot_0.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py vorhanden.
- **Ownership:** `st.session_state["history"]` (Liste).
- **Beziehungen:** Kein Bezug zum Retrieval (kein Multi-Turn-Kontext an das LLM belegt — die Stuff-Chain erhält nur die Frage und den Dokumentenkontext).
- **Persistenz:** Nur Session; Export als JSON via `st.download_button` (Dateiname `search_history.json`).
- **Validierung:** Keine (Längenbegrenzung, PII-Filterung fehlen).
- **Mutationen:** Append-only.
- **Thread-Sicherheit:** Pro Session; keine Nebenläufigkeit.
- **Benötigte Rust-Konzepte:** `ConversationTurn { question, answer }` mit serde-Serialisierung; explizite Entscheidung, ob History als LLM-Kontext genutzt wird (im Python-Code nicht der Fall); Größenbegrenzung als Designentscheidung.

## Konfiguration

- **Bedeutung:** Betriebsparameter: API-Key, LLM-Modell, Splitter-Parameter, Sampling-Parameter, Datenpfad.
- **Lebenszyklus:** Statisch beim Start (Umgebungsvariable aus `.env`; Modell- und Splitter-Parameter hart kodiert).
- **Ownership:** Prozess-Umgebung (`os.environ`) bzw. Code-Literale.
- **Beziehungen:** Key → alle NVIDIA-Aufrufe; Modell-String → `ChatNVIDIA`; Pfad `./data` → Loader.
- **Persistenz:** `.env`-Datei (belegt durch README.md, load_dotenv); hart kodierte Werte im Quellcode.
- **Validierung:** Keine (fehlender Key wird nicht geprüft → TypeError bei `None`-Zuweisung, belegt in allen Python-Dateien).
- **Mutationen:** Key wird von `.env` in `os.environ` kopiert.
- **Thread-Sicherheit:** Keine relevant.
- **Benötigte Rust-Konzepte:** Typisierte Konfiguration (z.B. `Config`-Struct mit `dotenvy`), Defaults für Modell/Splitter; Fehler beim fehlenden Key als Startfehler (statt TypeError); keine hart kodierten Werte.

## Verlaufs-Export (search_history.json)

- **Bedeutung:** Ergebnisartefakt der Session; Nutzer-seitig herunterladbar.
- **Lebenszyklus:** Wird bei Button-Klick als String serialisiert (`json.dumps(history, indent=4)`), im Browser-Download angeboten; keine Server-Speicherung.
- **Ownership:** Browser (nach Download).
- **Beziehungen:** 1:1-Abbild von `history`.
- **Persistenz:** Nutzer-seitig.
- **Validierung:** Keine.
- **Mutationen:** Keine.
- **Thread-Sicherheit:** Keine relevant.
- **Benötigte Rust-Konzepte:** Serialisierung via serde_json; Datei-Ausgabe als API-Rückgabe statt Browser-Download.

---

## Übergreifende Beobachtungen

- **Kein persistenter Speicher:** Sämtliche Datenmodelle (außer `.env` und PDFs) leben ausschließlich im Streamlit-Session-State; ein Neustart der App verliert Index und Verlauf (belegt: kein Speicher-/Lade-Code für FAISS oder History im Repo).
- **Kein Multi-Turn-Kontext:** Die History wird nie in den LLM-Prompt injiziert; jede Frage ist kontextlos bzgl. vorheriger Antworten (belegt durch Prompt-Templates ohne History-Platzhalter).
- **Kein Ranking jenseits des Retriever-Defaults:** Top-k, Score-Schwellen oder Re-Ranking sind im Code nicht konfiguriert (Nicht nachweisbar; SDK-Defaults).
- **Thread-Sicherheit:** Überall unkritisch, da keine Shared-State-Nebenläufigkeit im Quellcode; Streamlit übernimmt Session-Isolation.
