# Datei-Dokumentation: rag_nim (alle 14 Dateien)

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

---

## .gitignore

- **Zweck:** Ausschlussliste für Versionskontrolle: verhindert, dass Geheimnisse und Arbeitsartefakte eingecheckt werden.
- **Verantwortlichkeit:** Definiert drei Ausschlüsse: `.env` (API-Key-Datei), `implementation.txt` (Notizdatei), `nvidia_nim_rag/` (Verzeichnis). Keiner der drei ausgeschlossenen Einträge existiert im Arbeitsbaum (belegt durch `find`-Ergebnis).
- **Eingaben:** Keine. Statische Konfiguration.
- **Ausgaben:** Wirkt als Filter auf `git add`/`git commit`; beobachtbare Ausgabe ist das Ausbleiben der aufgelisteten Pfade im Repo-Zustand.
- **Datenfluss:** Kein Laufzeit-Datenfluss; wirkt ausschließlich auf die Versionskontrolle.
- **Persistenz:** Die Datei selbst ist persistiert; die ausgeschlossenen Pfade werden nicht persistiert.
- **Zustände:** Keine.
- **APIs:** Keine.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Schützt Secrets vor Versionskontrolle, sofern der Nutzer die Datei nicht gewaltsam hinzufügt (nicht abgesichert).
- **Fehlerfälle:** Keine im Code definierten; `.env` fehlt → API-Key-Ausfall zur Laufzeit (siehe README.md: "Add your NVIDIA API key to the .env file").
- **Sicherheitsrelevanz:** Hoch: `.env` ist das einzige Schutzmittel für den NVIDIA-API-Key.
- **Geschäftslogik:** Keine.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Keine.
- **Abhängigkeiten:** Keine.
- **Rust-Relevanz:** Ein Rust-Pendant benötigt eine äquivalente Secret-Ausschlusskonvention (z.B. `.env`/`.env.*` und Build-Artefakte wie `target/`); die Anforderung "API-Key niemals in die Versionskontrolle" ist direkt übertragbar.

---

## LICENSE

- **Zweck:** Rechtliche Lizenzbedingungen des Repos (MIT License, Copyright (c) 2025 Suraj Bhardwaj).
- **Verantwortlichkeit:** Gewährt Nutzungs-, Kopier-, Modifikations- und Verteilungsrechte unter Namensnennung und Haftungsausschluss ("AS IS", ohne Gewähr).
- **Eingaben:** Keine.
- **Ausgaben:** Keine Laufzeit-Ausgaben; rechtlicher Rahmen.
- **Datenfluss:** Keiner.
- **Persistenz:** Datei persistiert.
- **Zustände:** Keine.
- **APIs:** Keine.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Keine technischen.
- **Fehlerfälle:** Keine.
- **Sicherheitsrelevanz:** Klarstellung der Haftung; keine Security-Funktion.
- **Geschäftslogik:** Keine.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Keine.
- **Abhängigkeiten:** Keine.
- **Rust-Relevanz:** Die MIT-Bedingungen (Copyright-Vermerk, Haftungsausschluss) sind sprachunabhängig; eine spätere eigenständige Rust-Neuentwicklung darf keinen Quellcode übernehmen, muss aber die Lizenzbedingungen der Referenz beachten (dokumentarischer Beleg des Ursprungs).

---

## README.md

- **Zweck:** Projektbeschreibung, Demo-Verweis (`rag_demo.png`), Feature-Liste, Nutzungsanleitung, Installationsanleitung, Verzeichnisstruktur, Contributing-Hinweis.
- **Verantwortlichkeit:** Beschreibt das Produkt: "RAG Chatbot using NVIDIA NIM" — Streamlit-Anwendung mit PDF-Upload, NVIDIA-Embeddings, Chat-Interface, streamlined Workflow.
- **Eingaben:** Dokumentation; referenziert Dateien des Repos (rag_demo.png, rag_chatbot_1.py, complex_rag_chatbot.py, requirements.txt, .env, data/).
- **Ausgaben:** Keine Laufzeit-Ausgaben; Nutzer-Wissenstransfer.
- **Datenfluss:** Verweist auf den Workflow: Upload (optional) → "Generate Document Embeddings"-Button → Fragen stellen → Antworten (Schritte 1–4 der "How to Use"-Sektion).
- **Persistenz:** Datei persistiert; dokumentiert `.env` als Konfigurationspfad.
- **Zustände:** Keine.
- **APIs:** Keine; dokumentiert `NVIDIA_API_KEY` als erforderliche Umgebungsvariable.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Keine.
- **Fehlerfälle:** Keine dokumentierten; Installations-Schritte setzen Python 3.10 (conda) und Python 3.9+ voraus ("Python 3.9 or higher").
- **Sicherheitsrelevanz:** Dokumentiert Secret-Handling: `.env`-Datei im Root, API-Key-Eintrag `NVIDIA_API_KEY='your_api_key'`.
- **Geschäftslogik:** Beschreibt die Produkt-Fähigkeiten: Dokument-Upload, Embeddings-Erzeugung, Chat-Interface, streamlined Workflow.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Keine.
- **Abhängigkeiten:** Verweist auf requirements.txt; Dokumentation referenziert `langchain_nvidia_ai_endpoints`.
- **Rust-Relevanz:** Belegt die erwartete Produkt-Capability-Liste (Upload → Embeddings → Chat) und den Betriebsmodus (Streamlit-Web-App), die für die Rust-UI-/Service-Planung maßgeblich sind. Der dokumentierte `./data`-Standard-Korpus und die `.env`-Konfiguration definieren die Konfigurationsanforderungen der Rust-Version.

---

## requirements.txt

- **Zweck:** Ungepinnte Python-Abhängigkeitsliste für die Installation (`pip install -r requirements.txt`).
- **Verantwortlichkeit:** Deklariert 13 Pakete: streamlit, openai, langchain, langchain_nvidia_ai_endpoints, langchain_community, scikit-learn, matplotlib, numpy, pypdf2, umap-learn, faiss-cpu, python-dotenv, watchdog.
- **Eingaben:** Keine.
- **Ausgaben:** Installationsanweisung für den Paketmanager.
- **Datenfluss:** Paket-Deklaration → pip → Python-Umgebung.
- **Persistenz:** Datei persistiert.
- **Zustände:** Keine.
- **APIs:** Deklariert die Pakete, deren APIs im Code genutzt werden.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Installation zieht transitive Abhängigkeiten (z.B. faiss-cpu → numpy) nach; keine Versions-Pins (Reproduzierbarkeit nicht abgesichert).
- **Fehlerfälle:** Keine im Code; Versionskonflikte durch fehlende Pins möglich (Nicht nachweisbar konkret).
- **Sicherheitsrelevanz:** Keine direkte; Supply-Chain-Risiko durch fehlende Versionsfestlegung.
- **Geschäftslogik:** Keine.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Keine.
- **Abhängigkeiten:** Siehe Liste selbst.
- **Rust-Relevanz:** Mappt auf benötigte Rust-Capabilities: Web-UI (Streamlit → Web-Frontend/HTTP), OpenAI-kompatibler Client (openai → reqwest-basierter NIM-Client), Vektor-Suche (faiss-cpu → Vektor-Index-Crate), Embeddings/LLM (langchain_nvidia_ai_endpoints → NIM-HTTP-Clients), PDF-Extraktion (pypdf2 → PDF-Parser-Crate), Konfiguration (python-dotenv → dotenvy), Visualisierung (matplotlib/scikit-learn/umap-learn → Plot-/Dimensionalitätsreduktions-Crates, falls gewünscht). `pypdf2`, `umap-learn`, `watchdog` sind im Quellcode der 7 Python-Dateien nicht als Import belegt.

---

## rag_chatbot_0.py

- **Zweck:** Erste Streamlit-RAG-Variante ("Context-aware RAG: NVIDIA NIM") ohne Sidebar: Embedding-Button in der Hauptfläche, optionale Dokument-Zusammenfassung, Chat, Verlauf, JSON-Download, Antwortzeit-Anzeige, "Similarity Search"-Expander.
- **Verantwortlichkeit:** Demonstriert die komplette RAG-Pipeline in einer einzigen Datei inklusive Token-Limit-Truncation (8192) und Verlaufs-Export.
- **Eingaben:** PDF-Upload via `st.file_uploader(..., accept_multiple_files=True)`; Klick "Document Embedding"; Klick "Summarize Documents"; Chat-Frage als `st.text_input`; Klick "Download Results".
- **Ausgaben:** LLM-Antwort (`response['answer']`), Antwortzeit in Sekunden (`time.process_time()`), Quell-Chunks im Expander, Verlauf im Expander "Search History", JSON-Download (`search_history.json`).
- **Datenfluss:** Upload → `st.session_state.loader` → `vector_embedding()` lädt `./data` via `PyPDFDirectoryLoader` → `docs` → `RecursiveCharacterTextSplitter(700/50)` → `final_documents` (gekappt auf `docs[:40]`) → `NVIDIAEmbeddings` → `FAISS.from_documents` → `vectors` → `as_retriever()` → `create_retrieval_chain` → Antwort; Verlauf in `history`.
- **Persistenz:** Keine; alles im Streamlit-Session-State. JSON-Download als Datei-Export über `st.download_button`.
- **Zustände:** `vectors` (None → FAISS-Index), `history` ([] → Einträge), `loader` (None → Loader). Chat nur bei `vectors != None` (Fehlermeldung sonst).
- **APIs:** NVIDIA NIM via `ChatNVIDIA`/`NVIDIAEmbeddings`; LangChain `create_stuff_documents_chain`/`create_retrieval_chain`/`load_summarize_chain`.
- **Ereignisse:** Button-Klicks (Embedding, Summarize, Download), Text-Eingabe, Upload.
- **Nebenwirkungen:** Erzeugt pro Session einen NVIDIA-API-Aufruf je Embedding-Batch und je Chat-/Summarize-Anfrage; schreibt API-Key in `os.environ`.
- **Fehlerfälle:** `PyPDFDirectoryLoader(uploaded_files)` — `st.file_uploader` liefert bei `accept_multiple_files=True` eine Liste von `UploadedFile`-Objekten, der Loader erwartet einen Verzeichnispfad; der Upload-Pfad ist damit funktional fehlerhaft (belegt durch Zeile `st.session_state.loader = PyPDFDirectoryLoader(uploaded_files)`). Fehlende `.env` → `os.getenv` liefert `None` → `os.environ['NVIDIA_API_KEY'] = None` wirft beim Start. Summarize/Retrieval-Fehler werden als `st.error` ausgegeben.
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Regeln: (1) Chat erst nach Embedding erlaubt; (2) Kontext nur aus den Dokumenten ("Answer the questions based on the provided context only"); (3) Wortzahl-Truncation auf 8192; (4) Verlauf speicherbar/exportierbar.
- **Algorithmen:** Rekursives Chunking (LangChain `RecursiveCharacterTextSplitter`), Embedding-Erzeugung (NVIDIA), Vektor-Ähnlichkeitssuche (FAISS), Stuff-Kontext-Assemblierung, Wortzahl-Zählung (`len(doc.page_content.split())`) statt echter Token-Zählung.
- **verwendete Datenmodelle:** LangChain-Dokumente (`page_content`, `metadata`), FAISS-Index, Session-State (`vectors`, `history`, `loader`, `embeddings`, `docs`, `text_splitter`, `final_documents`).
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, langchain_core, python-dotenv, faiss-cpu (indirekt).
- **Rust-Relevanz:** Belegt die Kern-Capabilities (PDF-Ingestion, Chunking, Embedding, FAISS-Retrieval, Prompt-Assemblierung, Chat, Export) und zeigt Fehlerfälle, die in Rust explizit behandelt werden müssen (Upload-Validierung, fehlender API-Key, Token-Budget).

---

## rag_chatbot_1.py

- **Zweck:** Minimalste RAG-Variante ("Chat with Your Documents"): Sidebar mit Upload und "Generate Document Embeddings", Chat-Eingabe, Antwortausgabe. Kein Verlauf, keine Zusammenfassung, keine Visualisierung, kein Download.
- **Verantwortlichkeit:** Reduzierte Demonstrations-Variante; Einführung des `docs_loaded`-Flags, damit der Upload-Zustand beim erneuten Embedding-Build nicht verloren geht.
- **Eingaben:** PDF-Upload (Sidebar), "Generate Document Embeddings"-Button, Chat-Frage (Text).
- **Ausgaben:** Bot-Antwort (`st.markdown`), Erfolgsmeldungen, Fehlermeldung bei fehlendem Embedding.
- **Datenfluss:** Upload → `docs_loaded=True` + `docs` sofort geladen → `vector_embedding()` nutzt wegen `docs_loaded` die bereits geladenen `docs` (kein erneutes Laden von `./data`) → Splitter → FAISS → Chat.
- **Persistenz:** Keine; Session-State (`vectors`, `docs_loaded`).
- **Zustände:** `vectors` (None → Index), `docs_loaded` (False → True nach Upload).
- **APIs:** NVIDIA NIM via `ChatNVIDIA`/`NVIDIAEmbeddings`; LangChain-Chains.
- **Ereignisse:** Upload, Button-Klick, Text-Eingabe (Auslösung nur bei nicht-leerer Eingabe via `if user_query.strip():`).
- **Nebenwirkungen:** NVIDIA-API-Aufrufe für Embeddings und Chat pro Session.
- **Fehlerfälle:** Gleicher Upload-Bug wie rag_chatbot_0.py (`PyPDFDirectoryLoader(uploaded_files)` mit UploadedFile-Liste); fehlende `.env` → `os.environ`-Zuweisung von `None`; generischer `except Exception as e: st.error(f"Error: {e}")`.
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Regeln: Chat nur bei vorhandenem `vectors`; leere Eingabe wird ignoriert (keine Warnung).
- **Algorithmen:** Wie rag_chatbot_0.py (rekursives Chunking, NVIDIA-Embeddings, FAISS-Suche, Wortzahl-Truncation 8192 — hier ohne Einfluss, da `context` von der Retrieval-Chain überschrieben wird, siehe nim.md).
- **verwendete Datenmodelle:** LangChain-Dokumente, FAISS-Index, Session-State (`vectors`, `docs_loaded`, `loader`, `docs`, `text_splitter`, `final_documents`, `embeddings`).
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, python-dotenv, numpy (Import vorhanden, keine direkte Nutzung belegt).
- **Rust-Relevanz:** Belegt das einfachste Capability-Set (Ingest → Embed → Ask) und das Guard-Muster "kein Chat ohne Index" — in Rust als Zustandsmaschine mit explizitem `Option<Index>`-Modell abbildbar.

---

## chatbot.py

- **Zweck:** Funktionsreichste Variante: Sidebar mit Upload, "Generate Document Embeddings", Summarize (High-Level/Detailed-Auswahl), "Visualize Embeddings", Chat mit Verlaufsanzeige in der Hauptfläche.
- **Verantwortlichkeit:** Gesamt-Demonstration der RAG-Capabilities inklusive Verlaufsdarstellung und t-SNE-Embedding-Visualisierung mit Chunk-Metadaten-Labels (Quell-Dateiname pro Punkt).
- **Eingaben:** PDF-Upload, Buttons (Embeddings, Summarize, Visualize), Selectbox "Summarization Type", Chat-Frage.
- **Ausgaben:** LLM-Antwort, Verlauf (User/Bot-Markdown), Zusammenfassung, t-SNE-Plot (`st.pyplot`), Erfolgs-/Fehlermeldungen.
- **Datenfluss:** Standard wie oben; Besonderheit: `visualize_embeddings` rekonstruiert alle Embeddings aus dem FAISS-Index (`vectors.index.reconstruct(i)` für `range(vectors.index.ntotal)`) und reduziert sie mit t-SNE (2 Komponenten, `random_state=42`, `perplexity=30`); Metadaten (`source`) als Punkt-Labels.
- **Persistenz:** Keine; Session-State inkl. `history`.
- **Zustände:** `vectors`, `history`, `loader` (Default `PyPDFDirectoryLoader("./data")`), `docs_loaded`.
- **APIs:** Wie zuvor; zusätzlich scikit-learn `TSNE`, matplotlib `plt`.
- **Ereignisse:** Upload, Button-Klicks, Selectbox-Änderung, Text-Eingabe.
- **Nebenwirkungen:** API-Aufrufe (Embeddings, Chat, Summarize pro Chunk); Plot-Erzeugung; keine Datei-Schreibvorgänge.
- **Fehlerfälle:** Gleicher Upload-Bug; Summarize iteriert über alle `final_documents` und erwartet bei `chunk_summary.get("text", ...)` ein Dict mit `text`-Schlüssel; Fehler werden als `st.error` abgefangen; fehlende `.env`-Problematik wie überall.
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Summarize-Regel: "detailed" → "Summarize this in detail", sonst "Provide a high-level overview" (belegt durch `summary_type == "detailed"`-Verzweigung); Chat-Regeln wie zuvor.
- **Algorithmen:** t-SNE-Dimensionalitätsreduktion (scikit-learn, perplexity 30, random_state 42), FAISS-Rekonstruktion (`index.reconstruct`), rekursives Chunking, NVIDIA-Embeddings, Wortzahl-Truncation.
- **verwendete Datenmodelle:** LangChain-Dokumente mit `metadata.source`, FAISS-Index (`ntotal`, `reconstruct`), Session-State, `history`-Liste von Frage/Antwort-Dicts.
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, langchain_core, scikit-learn, matplotlib, numpy, python-dotenv.
- **Rust-Relevanz:** Belegt zusätzliche Capabilities: Embedding-Rekonstruktion aus dem Index (Rust: direkter Vektor-Zugriff im eigenen Index), t-SNE-Analogie (Rust-Crate für Dimensionalitätsreduktion, falls UI-Bedarf), Verlaufsdarstellung, Metadaten-Labels je Chunk.

---

## complex_rag_chatbot.py

- **Zweck:** Variante laut README "under develeopment phase": wie chatbot.py, aber ohne Summarize; Antwortauslösung explizit über "Submit"-Button statt Enter-only; Warnung bei leerer Frage.
- **Verantwortlichkeit:** Demonstrationsvariante mit expliziter Eingabevalidierung und Button-basiertem Chat-Flow.
- **Eingaben:** PDF-Upload, "Generate Document Embeddings", "Visualize Embeddings", Chat-Frage, "Submit"-Button.
- **Ausgaben:** LLM-Antwort, Verlauf, t-SNE-Plot, Warnung/Fehlermeldungen.
- **Datenfluss:** Wie chatbot.py (ohne Summarize-Zweig).
- **Persistenz:** Keine; Session-State.
- **Zustände:** Wie chatbot.py; zusätzlich Validierungszustände: leere Eingabe → `st.warning`, fehlende Vektoren → `st.error`.
- **APIs:** Wie chatbot.py (ohne Summarize-Chain).
- **Ereignisse:** Upload, Button-Klicks (Embeddings, Visualize, Submit).
- **Nebenwirkungen:** NVIDIA-API-Aufrufe; Plot-Erzeugung.
- **Fehlerfälle:** Upload-Bug wie zuvor; explizite Validierung: `if not user_query.strip(): st.warning(...)` (einzige Datei mit Leer-Eingabe-Warnung); generischer Exception-Handler.
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Regelkette Submit: nicht-leere Frage → vorhandener Index → Truncation → Retrieval → Antwort → Verlauf.
- **Algorithmen:** Wie chatbot.py (t-SNE mit `metadata['source']`-Labels, FAISS-Rekonstruktion, rekursives Chunking, Wortzahl-Truncation).
- **verwendete Datenmodelle:** Wie chatbot.py.
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, langchain_core, scikit-learn, matplotlib, numpy, python-dotenv.
- **Rust-Relevanz:** Belegt das Validierungs-Capability (leere Eingaben, fehlender Index) und button-getriebenen Chat-Flow — in Rust als explizite Eingabevalidierung vor dem Service-Aufruf abbildbar.

---

## enhanced_chatbot.py

- **Zweck:** "Erweiterte" Variante: Sidebar mit Upload, "Document Embedding", "Summarize Documents", "Visualize Embeddings" (ohne Metadaten-Labels), "Download Search History", zusätzliche "How to Use"-Anleitung; Chat in der Hauptfläche mit Antwortzeit und `trigger_refresh`.
- **Verantwortlichkeit:** Bündelt die meisten Funktionen (Embedding, Summarize, Visualize, Download, Anleitung, Antwortzeit) in einer Sidebar-gesteuerten UI.
- **Eingaben:** PDF-Upload, Buttons (Document Embedding, Summarize, Visualize, Download), Chat-Frage.
- **Ausgaben:** LLM-Antwort, Antwortzeit, Zusammenfassung, t-SNE-Plot (ohne Labels), Verlauf, JSON-Download.
- **Datenfluss:** Wie chatbot.py; Visualisierung nutzt ebenfalls FAISS-Rekonstruktion, plottet aber nur die Punkte ohne Metadaten-Labels; `docs[:40]`-Kappung wie in rag_chatbot_0.py.
- **Persistenz:** Keine; Session-State.
- **Zustände:** Wie chatbot.py; zusätzlich wird `st.session_state["trigger_refresh"] = time.time()` nach jeder Antwort gesetzt — dieser Schlüssel wird nirgends sonst gelesen (toter Zustand, belegt durch Code-Durchsicht).
- **APIs:** Wie chatbot.py.
- **Ereignisse:** Upload, Button-Klicks, Text-Eingabe.
- **Nebenwirkungen:** NVIDIA-API-Aufrufe; Plot-Erzeugung; Session-State-Mutation (`trigger_refresh`).
- **Fehlerfälle:** Upload-Bug wie zuvor; Summarize-Fehler → `st.error` mit `summary_text`-Fallback `""`; fehlende `.env`-Problematik.
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Wie rag_chatbot_0.py (kontextbasierte Antworten, Truncation 8192); Summarize ohne Typ-Auswahl (immer "stuff"-Kette über alle final_documents).
- **Algorithmen:** Wie chatbot.py (t-SNE ohne Labels, FAISS-Rekonstruktion, rekursives Chunking, Wortzahl-Truncation).
- **verwendete Datenmodelle:** Wie chatbot.py; zusätzlich toter Schlüssel `trigger_refresh`.
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, langchain_core, scikit-learn, matplotlib, numpy, python-dotenv.
- **Rust-Relevanz:** Belegt die Notwendigkeit expliziter State-Definition (toter Zustand `trigger_refresh` ist in Rust durch Typisierung ausgeschlossen) sowie UI-Anleitung, Antwortzeit-Messung und Export-Capability.

---

## rag_langchain_nim_1.py

- **Zweck:** Skriptorientierte RAG-Variante mit Besonderheiten: Embedding-Build läuft nur einmalig (`if "vectors" not in st.session_state`), Chunking auf `docs[:40]`, Antwortzeit nur per `print`, keine Truncation, kein Fehler-Guard vor dem Retrieval, mehrere ungenutzte Importe.
- **Verantwortlichkeit:** Zeigt eine reduzierte, einmalige Pipeline und belegt damit bewusst weggelassene Schutzmechanismen der anderen Varianten.
- **Eingaben:** "Documents Embedding"-Button, Chat-Frage (Text).
- **Ausgaben:** LLM-Antwort (`st.write`), Quell-Chunks im Expander, Antwortzeit über `print("Response time :", ...)` (nur Konsole).
- **Datenfluss:** `vector_embedding()` nur bei erstem Aufruf (Session-State-Guard) → `./data` → `docs[:40]` → Splitter → FAISS → Retrieval-Chain.
- **Persistenz:** Keine; Session-State (`vectors`, `embeddings`, `loader`, `docs`, `text_splitter`, `final_documents`).
- **Zustände:** `vectors` fehlt initial; nach Build vorhanden. Kein expliziter `None`-Zustand.
- **APIs:** Wie zuvor; importiert zusätzlich (ungeneriert) `OllamaEmbeddings`, `WebBaseLoader`, `StrOutputParser`.
- **Ereignisse:** Button-Klick, Text-Eingabe.
- **Nebenwirkungen:** NVIDIA-API-Aufrufe; Konsole-Ausgabe der Antwortzeit.
- **Fehlerfälle:** **Kein Guard vor `st.session_state.vectors.as_retriever()`**: Bei gesetzter Frage ohne zuvor erzeugte Embeddings schlägt der Zugriff auf `None` fehl (AttributeError), da der `if prompt_in:`-Block keine Existenzprüfung enthält (belegt durch Code). Kein `try/except` um Retrieval/Inferenz. Fehlende `.env`-Problematik wie überall. Ungenutzte Importe deuten auf Copy-Paste-Herkunft hin (belegt durch Importliste, keine Verwendung).
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Einmalige Pipeline-Erstellung; kein Token-Budget-Handling (im Gegensatz zu den anderen Varianten); Kontext-Regel identisch ("Answer the questions based on the provided context only").
- **Algorithmen:** Rekursives Chunking, NVIDIA-Embeddings, FAISS-Suche; keine Truncation.
- **verwendete Datenmodelle:** Wie zuvor; `vectors`-Zustand ohne Default.
- **Abhängigkeiten:** streamlit, langchain, langchain_nvidia_ai_endpoints, langchain_community, langchain_core, python-dotenv; (tote Importe: langchain.embeddings.OllamaEmbeddings, WebBaseLoader, StrOutputParser).
- **Rust-Relevanz:** Belegt die Fehlerfälle, die eine Rust-Implementierung durch Kompilierzeit erzwingt: kein Zugriff auf nicht existenten Index (Rust: `Option<Index>`), keine unbehandelten AttributeErrors (Rust: `Result`), sowie die Notwendigkeit, Kontext-Budget-Verwaltung explizit zu modellieren.

---

## nim_simple_app.py

- **Zweck:** Minimaler Nicht-LangChain-Demonstrator: direkter Chat-Aufruf gegen NVIDIA NIM über das OpenAI-Python-SDK mit Streaming.
- **Verantwortlichkeit:** Belegt den OpenAI-kompatiblen HTTP-Zugang von NVIDIA NIM (`base_url = "https://integrate.api.nvidia.com/v1"`), Modell `meta/llama3-70b-instruct`, Sampling-Parameter und SSE-Streaming.
- **Eingaben:** Feste Testfrage "What is a LLM?" (im Code hart kodiert); API-Key aus `.env`.
- **Ausgaben:** Streaming-Ausgabe der Antwort auf der Konsole (`print(chunk.choices[0].delta.content, end="")`).
- **Datenfluss:** `load_dotenv()` → OpenAI-Client mit base_url und Key → `chat.completions.create(model, messages, temperature=0.5, top_p=1, max_tokens=1024, stream=True)` → Iteration über Completion-Chunks → Konsolenausgabe.
- **Persistenz:** Keine.
- **Zustände:** Keine expliziten; Streaming-Iterator-Zustand.
- **APIs:** OpenAI-Chat-Completions-API gegen NVIDIA NIM (belegt durch SDK-Aufruf `client.chat.completions.create`); konkreter HTTP-Endpunkt ergibt sich aus base_url `/v1` (belegt durch base_url-Wert); exakter Pfad (`/v1/chat/completions`) ist im Quellcode nicht als String belegt (Nicht nachweisbar als Quelltext-Zeichenkette).
- **Ereignisse:** Chunk-Ereignisse des Streams; Ausgabe nur bei `chunk.choices[0].delta.content is not None`.
- **Nebenwirkungen:** Ein LLM-Inferenz-Aufruf je Skriptlauf; keine Datei-Effekte.
- **Fehlerfälle:** Keine behandelt: kein Retry, kein Timeout, kein Fehler-Handler; fehlende `.env` → `api_key=None` wird an den SDK-Client übergeben (belegt durch `api_key = os.getenv(...)` ohne Prüfung).
- **Sicherheitsrelevanz:** API-Key aus `.env`; keine weitere Absicherung.
- **Geschäftslogik:** Einzige Regel: Testfrage beantworten; Sampling-Konfiguration (temperature 0.5, top_p 1, max_tokens 1024) fest im Code.
- **Algorithmen:** Keine über das SDK hinaus.
- **verwendete Datenmodelle:** OpenAI-Request-Modell (messages mit `role`/`content`), Completion-Chunk-Modell (choices[0].delta.content).
- **Abhängigkeiten:** openai, python-dotenv.
- **Rust-Relevanz:** Belegt die benötigte Chat-Streaming-Capability und das Request-Schema (messages-Array, Modell-String, temperature/top_p/max_tokens, stream-Flag) sowie die OpenAI-kompatible NIM-Basis-URL — direkt übertragbar auf einen reqwest/eventsource-basierten Rust-Client.

---

## rag_demo.png

- **Zweck:** Demo-Bild der Anwendung; vom README als `![Chatbot Demo](rag_demo.png)` referenziert.
- **Verantwortlichkeit:** Visuelle Demonstration der Streamlit-Oberfläche.
- **Eingaben:** Keine zur Laufzeit.
- **Ausgaben:** Bilddarstellung im README/Markdown.
- **Datenfluss:** Statische Asset-Datei.
- **Persistenz:** Datei persistiert (534.616 Bytes).
- **Zustände:** Keine.
- **APIs:** Keine.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Keine.
- **Fehlerfälle:** Keine.
- **Sicherheitsrelevanz:** Keine.
- **Geschäftslogik:** Keine.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Keine.
- **Abhängigkeiten:** Keine (eingebettet in README).
- **Technische Eigenschaften (belegt durch Byte-/Chunk-Analyse):** Gültige PNG-Signatur; 5080×1924 Pixel; 8-Bit; Farbtyp 6 (RGBA); nicht interlaced; Chunks: IHDR, iCCP (345 Bytes, Farbprofil), eXIf (138 Bytes), pHYs (9 Bytes), iTXt (472 Bytes, XMP mit `exif:UserComment>Screenshot`), 39 IDAT-Blöcke (je 16384 Bytes bzw. 9247/15972 Bytes), IEND. Das eXIf-Tag `0x9286` (UserComment) trägt den Wert "Screenshot"; XMP bestätigt `exif:UserComment` = "Screenshot" und PixelX/YDimension 5080/1924. **Inhalt visuell:** Die Bild-Pixel können im Rahmen dieser Analyse nicht interpretiert werden (kein Bildverständnis verfügbar); der Bildinhalt im Detail ist daher Nicht nachweisbar. Belegt ist: Es handelt sich laut eingebetteten Exif/XMP-Metadaten um einen Screenshot, und das README verwendet ihn als Chatbot-Demo.
- **Rust-Relevanz:** Dient als UI-Referenz der erwarteten Oberfläche (Screenshot-Beleg des Chatbot-Flows); für die Rust-Version als Dokumentations-Asset nutzbar, nicht als Code-Input.

---

## data/Attention.pdf

- **Zweck:** Standard-Korpus-Dokument im `data/`-Verzeichnis; wird durch `PyPDFDirectoryLoader("./data")` geladen (belegt in allen Chatbot-Dateien, z.B. rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py).
- **Verantwortlichkeit:** Liefert den Default-Inhalt für die RAG-Demonstration, wenn kein Upload erfolgt (belegt durch README.md: "the app will process documents from the default ./data directory").
- **Eingaben:** Keine zur Laufzeit; statisches Asset.
- **Ausgaben:** Textseiten für die PDF-Text-Extraktion durch den Loader.
- **Datenfluss:** Dateisystem `data/` → `PyPDFDirectoryLoader` → LangChain-Dokumente → Chunks → Embeddings → FAISS.
- **Persistenz:** Datei persistiert (2.215.244 Bytes).
- **Zustände:** Keine.
- **APIs:** Keine direkt; wird über den Loader konsumiert.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Verursacht bei jedem Embedding-Build NVIDIA-API-Aufrufe für alle extrahierten Chunks.
- **Fehlerfälle:** Extraktionsfehler durch den Loader sind nicht im Quellcode behandelt.
- **Sicherheitsrelevanz:** Dokumentinhalt wird ungefiltert in den LLM-Kontext injiziert.
- **Geschäftslogik:** Keine eigene; dient als Demo-Korpus.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** PDF-Seiten → Text (über Loader); Metadaten des Loaders (z.B. `source`) werden in den Chatbot-Varianten teilweise für Labels genutzt (belegt durch `metadata[idx].get('source', 'Unknown')` in chatbot.py, complex_rag_chatbot.py).
- **Abhängigkeiten:** pypdf2 (in requirements.txt; direkte Nutzung im Quellcode nicht belegt — der Loader übernimmt die Extraktion).
- **Technische Eigenschaften (belegt durch Byte-Analyse):** PDF-Version 1.5; erzeugt mit LaTeX/hyperref (Creator), pdfTeX-1.40.25 (Producer); CreationDate `D:20240410211143Z`; ModDate identisch; Root-/Pages-Objekt `/Count 15` und 15 einzelne `/Type /Page`-Objekte → **15 Seiten**; die Metadatenfelder Title/Author/Subject/Keywords sind leer. Der exakte Dokumenttitel und -inhalt ist aus den Metadaten nicht ableitbar (Nicht nachweisbar); die Datei heißt nur `Attention.pdf`.
- **Rust-Relevanz:** Belegt die Anforderung einer PDF-Text-Extraktion in der Rust-Version (z.B. via pdf-Crate); dokumentiert, dass Diagramme/Bilder des PDFs durch den Loader nicht erfasst werden (nur Text) — dieselbe Einschränkung gilt für einen reinen Text-Extraktor in Rust.

---

## data/Raptor.pdf

- **Zweck:** Standard-Korpus-Dokument im `data/`-Verzeichnis; wird durch `PyPDFDirectoryLoader("./data")` geladen (belegt in allen Chatbot-Dateien, z.B. rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py).
- **Verantwortlichkeit:** Wie Attention.pdf: Default-Inhalt für die RAG-Demonstration ohne Upload (belegt durch README.md).
- **Eingaben:** Keine zur Laufzeit.
- **Ausgaben:** Textseiten für die PDF-Text-Extraktion.
- **Datenfluss:** Wie Attention.pdf.
- **Persistenz:** Datei persistiert (2.547.113 Bytes).
- **Zustände:** Keine.
- **APIs:** Keine direkt.
- **Ereignisse:** Keine.
- **Nebenwirkungen:** Wie Attention.pdf.
- **Fehlerfälle:** Wie Attention.pdf.
- **Sicherheitsrelevanz:** Wie Attention.pdf.
- **Geschäftslogik:** Keine eigene.
- **Algorithmen:** Keine.
- **verwendete Datenmodelle:** Wie Attention.pdf.
- **Abhängigkeiten:** Wie Attention.pdf.
- **Technische Eigenschaften (belegt durch Byte-Analyse):** PDF-Version 1.5; erzeugt mit LaTeX/hyperref (Creator), pdfTeX-1.40.25 (Producer); CreationDate `D:20240201014546Z`; ModDate identisch; Root-/Pages-Objekt `/Count 23` und 23 einzelne `/Type /Page`-Objekte → **23 Seiten**; Metadatenfelder Title/Author/Subject/Keywords leer. Exakter Dokumenttitel/-inhalt Nicht nachweisbar.
- **Rust-Relevanz:** Wie Attention.pdf: PDF-Text-Extraktion als benötigte Rust-Capability; reine Text-Extraktion erfasst keine Diagramme.

---

## Zusammenfassung der Datei-Beziehungen

- Alle 7 Python-Dateien teilen sich den Kern-Stack (ChatNVIDIA llama3-70b-instruct, NVIDIAEmbeddings, RecursiveCharacterTextSplitter 700/50, FAISS, Stuff-Chain) — belegt durch identische Import- und Aufrufstrukturen.
- Unterschiede in Reihenfolge: **nim_simple_app.py** (kein LangChain, OpenAI-SDK, Streaming), **rag_langchain_nim_1.py** (kein Guard, tote Importe, einmaliger Build), **rag_chatbot_1.py** (minimal, docs_loaded), **rag_chatbot_0.py** (keine Sidebar, Summarize+Download), **complex_rag_chatbot.py** (Submit-Button, Warnung), **enhanced_chatbot.py** (alle Features, toter trigger_refresh), **chatbot.py** (funktionsreichster Stand).
- `data/` (Attention.pdf, Raptor.pdf) ist der Default-Korpus; `rag_demo.png` ist das README-Demo-Bild; `requirements.txt`/`README.md`/`LICENSE`/`.gitignore` sind Meta-Dateien.
