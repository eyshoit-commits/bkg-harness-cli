# Test-Analyse: rag_nim

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

## Bestand an Testdateien

**Es existieren keine dedizierten Testdateien** in diesem Repo (belegt durch `find`-Ergebnis: keine `test_*`/`*_test.py`/`tests/`-Einträge). requirements.txt enthält keine Test-Frameworks (kein pytest/unittest belegt).

## Im Quellcode beobachtbare Annahmen und Edge-Cases (statt Tests)

Die folgenden Annahmen werden durch die Beispieldateien aufgestellt, aber nirgends automatisiert geprüft:

1. **Vorbedingung Embedding-Index (Guard-Pfad):**
   - Anforderung: Chat-Frage ohne erzeugte `vectors` wird abgelehnt. Belegt durch `if not st.session_state["vectors"]: st.error(...)` in rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py.
   - Annahme: Nach erfolgreichem `vector_embedding()` ist `vectors` garantiert gesetzt.
   - Edge-Case-Versagen: rag_langchain_nim_1.py prüft nicht → Zugriff auf `None` (`vectors.as_retriever()`).

2. **Leere Nutzereingabe:**
   - complex_rag_chatbot.py warnt bei `not user_query.strip()` (`st.warning`).
   - rag_chatbot_1.py ignoriert leere Eingaben still (`if user_query.strip():`).
   - Die übrigen Dateien prüfen Leere nicht explizit.

3. **Token-Budget (8192):**
   - `truncate_documents_for_token_limit(documents, max_tokens=8192)` in 5 Dateien.
   - Annahme: `max_tokens` wird eingehalten, indem Wörter gezählt und gierig gesammelt werden; Abbruch beim ersten überschreitenden Dokument.
   - Invariante, die ungeprüft bleibt: Die gekürzte Liste wird tatsächlich als LLM-Kontext verwendet (Wirkung Nicht nachweisbar, siehe functions.md).

4. **API-Key-Verfügbarkeit:**
   - Annahme: `.env` existiert und enthält `NVIDIA_API_KEY`.
   - Unbehandelter Fehlerfall: `os.getenv` liefert `None` → `os.environ[...] = None` → TypeError beim Start (alle Python-Dateien).

5. **Upload-Pfad:**
   - Annahme: `st.file_uploader`-Ergebnis ist ein Verzeichnispfad für `PyPDFDirectoryLoader`.
   - Tatsächlich: Liste von `UploadedFile`-Objekten → fehlerhafter Aufruf in rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py.

6. **Antwortstruktur des LLM:**
   - Annahme: Chain-Ergebnis enthält `response['answer']` (alle Chatbot-Dateien) und für Summarize einen `text`-Schlüssel (chatbot.py: `chunk_summary.get("text", "No summary available")`).

7. **FAISS-Index-Eigenschaften:**
   - Annahme: `index.ntotal` entspricht der Anzahl der Chunks und `index.reconstruct(i)` liefert das Embedding von Chunk `i` (chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
   - t-SNE-Parameter `perplexity=30` setzen voraus, dass mindestens ~30 Chunks existieren (kein Guard belegt).

8. **Streaming-Chunk-Struktur:**
   - nim_simple_app.py: `chunk.choices[0].delta.content is not None`; Annahme, dass pro Chunk mindestens ein `choice` existiert (keine Leer-Prüfung).

9. **Modellverfügbarkeit:**
   - Annahme: `meta/llama3-70b-instruct` ist auf dem NIM-Endpunkt verfügbar (alle Chatbot-Dateien + nim_simple_app.py).

## Invarianten, die aus den Beispielen ableitbar sind (sollten in Rust-Tests gefasst werden)

- Nach `vector_embedding()` gilt: `len(final_documents) == vectors.index.ntotal` (Chunk-Anzahl = Index-Größe) — ableitbar aus dem Datenfluss (belegt durch `FAISS.from_documents(final_documents, ...)` + `index.ntotal`-Nutzung).
- Chunk-Größenordnung: kein Chunk überlappt um mehr als 50 Zeichen bzw. ist größer als 700 Zeichen (Splitter-Konfiguration; Einhaltung durch das SDK nicht im Quellcode verifizierbar — Nicht nachweisbar, ob der Splitter diese Grenzen exakt einhält).
- Truncation-Monotonie: `len(truncate(docs)) <= len(docs)` (gierige Sammellogik).
- Prompt-Struktur: Antworten referenzieren nur den gegebenen Kontext (Prompt-Regel "based on the provided context only") — als LLM-Verhalten nicht automatisiert testbar ohne NIM-Endpunkt.

## Benötigte Rust-Tests (für die spätere Neuentwicklung)

1. **Chunker-Tests:** deterministische Aufteilung bei 700/50; Grenzfälle: Text kürzer als 700, exakt 700, überlappende Abschnitte, leere Eingaben, Unicodeweite Grenzen; Invariante: Rekombination überlappender Chunks deckt den Quelltext ab.
2. **Embedding-Pipeline-Tests:** Mock des NVIDIA-Embedding-Endpunkts; Batch-Aufteilung; Fehlerfälle (HTTP-Fehler, Rate Limit, ungültige Dimension); Konsistenz Vektor-Dimension über alle Chunks.
3. **Retriever-Tests:** Ähnlichkeitssuche liefert erwartete Top-k-Treffer auf Fixture-Embeddings; deterministische Reihenfolge; Verhalten bei leerem Index; Score-Monotonie.
4. **NIM-Client-Tests (Chat):** Request-Schema (messages, model, sampling-Parameter, stream-Flag) gegen Mock-Server; Streaming-Parsing (SSE, Chunk-Delta-Verarbeitung, Abschluss-Signal); Fehlerbehandlung (HTTP-Status, Timeout, unvollständiger Stream, leere choices).
5. **Konfigurations-Tests:** Fehlender `NVIDIA_API_KEY` → definierter Konfigurationsfehler (statt TypeError); Defaults für Modell/Splitter.
6. **Kontext-Budget-Tests:** Truncation respektiert das Limit; identische Ergebnisse bei wiederholter Ausführung (Determinismus); korrekte Behandlung von Chunks mit Wortzahl = Grenzwert.
7. **Export-Tests:** History-Serialisierung (JSON) rundet Fehlerfrei; Feldstruktur `{question, answer}` bleibt erhalten.
8. **Guard-/Zustands-Tests:** Abfrage ohne Index → definierter Fehlerzustand; Leer-Eingabe → Validierungsfehler (statt stiller Ignorierung).

## Gate-Hinweis

Da keine Tests existieren, können keine Test-Ergebnisse zitiert werden; die obige Liste ist die aus dem Quellcode abgeleitete Testanforderung (belegt durch die jeweils genannten Code-Stellen).
