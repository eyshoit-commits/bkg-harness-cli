# NVIDIA-NIM-Interaktion: rag_nim

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

## Zugangswege

Es existieren zwei belegte Zugangswege zu NVIDIA NIM:

1. **LangChain-Integration** (`langchain_nvidia_ai_endpoints`): `ChatNVIDIA` (Chat) und `NVIDIAEmbeddings` (Embeddings) — genutzt in allen 6 Chatbot-Dateien (rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py, rag_langchain_nim_1.py).
2. **OpenAI-kompatibles SDK**: `OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key=...)` und `client.chat.completions.create(...)` — genutzt in nim_simple_app.py. Die Basis-URL `https://integrate.api.nvidia.com/v1` ist der einzige explizit im Quellcode belegte NIM-Endpunkt-String.

## Chat

- **Modell:** `meta/llama3-70b-instruct` — belegt in allen 7 Python-Dateien (`ChatNVIDIA(model="meta/llama3-70b-instruct")` bzw. `model="meta/llama3-70b-instruct"` in nim_simple_app.py).
- **LangChain-Pfad:** `llm = ChatNVIDIA(model="meta/llama3-70b-instruct")`; die Antwort wird über `retrieval_chain.invoke({...})` bzw. `summary_chain.invoke({...})` erzeugt; Ergebnis-Zugriff über `response['answer']` (alle Chatbot-Dateien).
- **Direkter Pfad (nim_simple_app.py):**
  - Request: `messages=[{"role":"user","content":"What is a LLM?"}]` (Rolle `user`, Inhalt als String).
  - Sampling-Parameter: `temperature=0.5`, `top_p=1`, `max_tokens=1024`, `stream=True`.
  - Response: Iteration über Completion-Chunks; Text je Chunk unter `chunk.choices[0].delta.content`; Ausgabe nur bei `content is not None`.
  - Die Chatbot-Dateien setzen keine Sampling-Parameter (SDK-Defaults — Werte Nicht nachweisbar).

## Embeddings

- **Aufruf:** `NVIDIAEmbeddings()` ohne Parameter (alle 6 Chatbot-Dateien).
- **Konkretes Embedding-Modell:** Im Quellcode nicht angegeben — Nicht nachweisbar.
- **Verwendung:** `FAISS.from_documents(final_documents, embeddings)` — Vektoren werden direkt in den Index überführt; ein direkter Vektor-Zugriff erfolgt nur zur Visualisierung über FAISS (`vectors.index.reconstruct(i)`, `vectors.index.ntotal`; chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
- **Embedding-Dimension:** Nicht im Code belegt — Nicht nachweisbar.

## Streaming

- **Belegt nur in nim_simple_app.py:** `stream=True` + `for chunk in completion:`; `chunk.choices[0].delta.content`.
- **In den Chatbot-Dateien:** Kein Streaming-Parameter bei `ChatNVIDIA` belegt; Antworten werden vollständig abgewartet (Spinner, dann `st.write`).

## Tool Calling

- **Nicht im Quellcode vorhanden:** keine Tool-/Function-Definitionen, kein `tools`-Parameter, keine Tool-Ausführung — Nicht nachweisbar.

## Request-/Response-Aufbau

Belegte Bausteine (aus allen Dateien aggregiert):

- **Basis-URL:** `https://integrate.api.nvidia.com/v1` (nim_simple_app.py). Der konkrete HTTP-Pfad (z.B. `/v1/chat/completions`) erscheint im Quellcode nicht als Zeichenkette (SDK-intern — Nicht nachweisbar).
- **Endpunkt-Zugriff:** OpenAI-SDK-Client `client.chat.completions.create(...)` (nim_simple_app.py); LangChain-`ChatNVIDIA`/`NVIDIAEmbeddings` (Chatbot-Dateien).
- **Auth:** `api_key` aus `os.getenv("NVIDIA_API_KEY")` (nim_simple_app.py) bzw. `os.environ['NVIDIA_API_KEY']` (alle Chatbot-Dateien, befüllt via `load_dotenv()` + `os.getenv`).
- **Request-Felder (belegt):** `model` (String), `messages` (Array aus `{"role","content"}`-Objekten), `temperature`, `top_p`, `max_tokens`, `stream` (nim_simple_app.py). Im LangChain-Pfad: Prompt-Template-Inhalte `{context}`/`{input}` (alle Chatbot-Dateien).
- **Response-Felder (belegt):** `choices[0].delta.content` im Streaming (nim_simple_app.py); `response['answer']` der Retrieval-Chain (alle Chatbot-Dateien); `chunk_summary.get("text", ...)` der Summarize-Chain (chatbot.py).
- **JSON-Schemas:** Im Quellcode sind keine JSON-Schema-Definitionen vorhanden; die Feldstrukturen ergeben sich aus den SDK-Objekten (Nicht nachweisbar als Schemadatei).

## Retry / Rate Limits / Fehlerbehandlung

- **Retry:** Kein Retry-Code in allen 7 Dateien — Nicht nachweisbar (SDK-interne Defaults nicht im Quellcode).
- **Rate Limits:** Keine Behandlung belegt (keine Backoff-/Retry-Logik) — Nicht nachweisbar.
- **Fehlerbehandlung:**
  - Chatbot-Dateien: generischer `except Exception as e: st.error(...)` um `retrieval_chain.invoke` (rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py); Summarize-Fehler separat in rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py.
  - rag_langchain_nim_1.py: keine Fehlerbehandlung (unbehandelte Exceptions propagieren).
  - nim_simple_app.py: keine Fehlerbehandlung (kein try/except, kein Timeout).
  - Konfigurationsfehler (fehlende `.env`): unbehandelt → `os.environ`-Zuweisung von `None` (alle Python-Dateien).

## Model Routing

- **Kein explizites Routing:** Alle Dateien verwenden hart kodiert `meta/llama3-70b-instruct`; es gibt keine Modell-Auswahl, kein Fallback, keine Routing-Logik — Nicht nachweisbar als Feature. (Belegt: kein zweiter Modell-String im Repo.)

## API-Key-Handling

- **Quelle:** `.env`-Datei (README.md: `NVIDIA_API_KEY='your_api_key'`).
- **Ladepfad:** `load_dotenv()` → `os.environ['NVIDIA_API_KEY'] = os.getenv("NVIDIA_API_KEY")` (alle 7 Python-Dateien, identische Struktur).
- **Nutzung:** LangChain liest die Umgebungsvariable (SDK-intern — Nicht nachweisbar im Quellcode, aber Key-Name `NVIDIA_API_KEY` ist belegt); OpenAI-SDK erhält den Key explizit als `api_key`-Parameter (nim_simple_app.py).
- **Geheimnisschutz:** `.env` ist in .gitignore ausgeschlossen (belegt).
- **Schwäche (belegt):** Fehlender Key wird nicht validiert; `os.getenv` ohne Default liefert `None`; die `os.environ`-Zuweisung von `None` wirft beim Start (alle Chatbot-Dateien); in nim_simple_app.py wird `None` ungeprüft als `api_key` übergeben.

## Aggregierte Faktenmatrix

| Aspekt | Belegter Wert | Datei |
|---|---|---|
| NIM-Basis-URL | `https://integrate.api.nvidia.com/v1` | nim_simple_app.py |
| Chat-Modell | `meta/llama3-70b-instruct` | alle 7 Dateien |
| Embedding-Modell | Nicht angegeben (Nicht nachweisbar) | alle 6 Chatbot-Dateien |
| Streaming | `stream=True`, `choices[0].delta.content` | nim_simple_app.py |
| Sampling | temperature 0.5, top_p 1, max_tokens 1024 | nim_simple_app.py |
| Auth | `NVIDIA_API_KEY` aus `.env` | README.md, alle Dateien |
| Retry/Rate-Limit | Nicht vorhanden (Nicht nachweisbar) | alle |
| Tool Calling | Nicht vorhanden (Nicht nachweisbar) | alle |
| Model Routing | Nicht vorhanden (Nicht nachweisbar) | alle |
