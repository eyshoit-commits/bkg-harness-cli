# Repo-Übersicht: rag_nim

## Zweck

Das Repository `rag_nim` demonstriert einen Retrieval-Augmented-Generation-(RAG)-Chatbot, der mit NVIDIA NIM (NVIDIA Inference Microservices) über die LangChain-Integration und die OpenAI-kompatible API betrieben wird. Nutzer laden PDF-Dokumente hoch (oder nutzen den Standard-Korpus unter `data/`), erzeugen Embeddings über NVIDIA, fragen die Dokumente ab und erhalten kontextbasierte Antworten (belegt durch README.md, rag_chatbot_0.py).

Das Repo ist eine Sammlung von **Beispiel-Varianten** desselben Konzepts mit unterschiedlichem Funktionsumfang und Reifegrad. Der README.md bezeichnet die Dateien als "different versions of the chatbot" und `complex_rag_chatbot.py` explizit als "under develeopment phase" (Original-Schreibweise im README).

## Verantwortlichkeit

- Demonstration einer vollständigen RAG-Pipeline: PDF-Ingestion → Chunking → Embedding-Erzeugung → Vektor-Index → Retrieval → Prompt-Konstruktion → LLM-Inferenz (belegt durch rag_chatbot_0.py, chatbot.py).
- Demonstration zweier Zugriffswege auf NVIDIA NIM:
  1. LangChain-Integration `ChatNVIDIA` / `NVIDIAEmbeddings` (alle Chatbot-Dateien).
  2. Direkter OpenAI-SDK-Aufruf gegen `https://integrate.api.nvidia.com/v1` (belegt durch nim_simple_app.py).
- Bereitstellung einer Streamlit-Web-UI mit Upload, Embedding-Auslösung, Chat, Verlauf, Zusammenfassung, Embedding-Visualisierung und JSON-Download (belegt durch chatbot.py, enhanced_chatbot.py).

## Komponenten

| Komponente | Beleg | Rolle |
|---|---|---|
| Streamlit-Web-UI | chatbot.py, rag_chatbot_0.py u.a. | Oberfläche: Upload, Buttons, Chat-Eingabe, Expander, Session-State |
| PDF-Ingestion | `PyPDFDirectoryLoader("./data")` in allen Chatbot-Dateien | Lädt alle PDFs eines Verzeichnisses als Dokumente |
| Text-Splitter | `RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)` in allen Chatbot-Dateien | Rekursive, überlappende Chunk-Erzeugung |
| Embedding-Dienst | `NVIDIAEmbeddings()` in allen Chatbot-Dateien | Erzeugt Vektor-Repräsentationen über NVIDIA NIM |
| Vektor-Store | `FAISS.from_documents(...)` in allen Chatbot-Dateien | In-Memory-Index mit Ähnlichkeitssuche |
| Retriever | `vectors.as_retriever()` in allen Chatbot-Dateien | Kandidatengewinnung für den Kontext |
| Dokument-Kombinations-Chain | `create_stuff_documents_chain` in allen Chatbot-Dateien | Packt alle Chunks in das Prompt-Template |
| Retrieval-Chain | `create_retrieval_chain` in allen Chatbot-Dateien | Verdrahtet Retriever → Kontext → LLM |
| LLM-Inferenz | `ChatNVIDIA(model="meta/llama3-70b-instruct")` in allen Chatbot-Dateien | Antwortgenerierung über NVIDIA NIM |
| Direkter NIM-Client | nim_simple_app.py | OpenAI-kompatibler Chat-Stream ohne LangChain |
| Summarizer | `load_summarize_chain` in rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py | Dokumentzusammenfassung über das LLM |
| Embedding-Visualisierung | `TSNE` in chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py | 2D-Projektion der Embeddings via scikit-learn/matplotlib |
| Token-Limit-Truncation | `truncate_documents_for_token_limit` in rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py | Wortzahl-basierte Kappung auf 8192 |

## Datenfluss

1. **Ingestion**: PDFs aus `./data` (Standard) oder Upload → `PyPDFDirectoryLoader` → Dokumentobjekte mit `page_content` und `metadata` (belegt durch rag_chatbot_0.py, chatbot.py).
2. **Chunking**: `RecursiveCharacterTextSplitter(700/50)` → Chunk-Liste; in rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py auf die ersten 40 Dokumente begrenzt (`docs[:40]`).
3. **Embedding**: `NVIDIAEmbeddings()` erzeugt pro Chunk einen Vektor über den NVIDIA-Embedding-Dienst.
4. **Indexierung**: `FAISS.from_documents` baut In-Memory-Index mit den Embeddings.
5. **Retrieval**: Query → `as_retriever()` → ähnlichste Chunks aus dem FAISS-Index.
6. **Kontext-Injektion**: Retrieval-Chain stellt den Kontext in das Prompt-Template (Platzhalter `{context}`; belegt in allen Chatbot-Dateien).
7. **Inferenz**: `ChatNVIDIA(model="meta/llama3-70b-instruct")` erzeugt die Antwort.
8. **Präsentation**: Antwort + Quell-Chunks im Expander "Similarity Search" + Verlauf + optionaler JSON-Download (belegt durch rag_chatbot_0.py).

## Persistenz

- **Keine dauerhafte Persistenz**. Der FAISS-Index, die Embeddings, die Chunks und der Chat-Verlauf leben ausschließlich im Streamlit-Session-State (`st.session_state`) pro Browser-Sitzung (belegt durch rag_chatbot_0.py, chatbot.py).
- Einzige persistenznahe Funktion: Download des Chat-Verlaufs als JSON über `st.download_button` (belegt durch rag_chatbot_0.py) — der Download ist ein Browser-Download, keine Speicherung.
- Der API-Key kommt aus einer `.env`-Datei (belegt durch README.md, .gitignore, `load_dotenv()` in allen Python-Dateien).

## Abhängigkeiten

Laut requirements.txt (ohne Versions-Pins):
`streamlit`, `openai`, `langchain`, `langchain_nvidia_ai_endpoints`, `langchain_community`, `scikit-learn`, `matplotlib`, `numpy`, `pypdf2`, `umap-learn`, `faiss-cpu`, `python-dotenv`, `watchdog`.

Nutzung im Code belegt:
- `streamlit` — UI (alle Chatbot-Dateien)
- `langchain_nvidia_ai_endpoints` — `NVIDIAEmbeddings`, `ChatNVIDIA` (alle Chatbot-Dateien)
- `langchain_community` — `PyPDFDirectoryLoader`, `FAISS` (alle Chatbot-Dateien)
- `langchain` — `create_stuff_documents_chain`, `create_retrieval_chain`, `load_summarize_chain`, `RecursiveCharacterTextSplitter`
- `langchain_core` — `ChatPromptTemplate`, `StrOutputParser` (rag_langchain_nim_1.py)
- `openai` — direkter NIM-Chat (nim_simple_app.py)
- `scikit-learn` — `TSNE` (chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py)
- `matplotlib` — Plot-Erzeugung (chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py)
- `numpy` — Embedding-Array-Konversion (rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py)
- `python-dotenv` — `load_dotenv()` (alle Python-Dateien)
- `faiss-cpu` — FAISS-Vektor-Store (via langchain_community)

Nicht im Code verwendete requirements: `pypdf2`, `umap-learn`, `watchdog` — keine Import- oder Aufruf-Belege in den 7 Python-Dateien (Nicht nachweisbar, wofür sie vorgesehen waren).

## Eingaben / Ausgaben

- **Eingaben (Benutzer)**: PDF-Uploads (optional), Button-Auslösung "Document Embedding"/"Generate Document Embeddings", Chat-Frage (Text), optional Summarize-/Visualize-Auslösung (belegt durch chatbot.py).
- **Eingaben (System)**: `NVIDIA_API_KEY` aus `.env` (belegt durch README.md, load_dotenv in allen Python-Dateien); PDFs unter `./data` (belegt durch `PyPDFDirectoryLoader("./data")`).
- **Ausgaben**: LLM-Antwort, aufbereitete Antwortzeit, Quell-Chunks im Expander, Verlauf (Frage/Antwort), JSON-Download, t-SNE-Plot, Zusammenfassung (belegt durch rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py).
- **Ausgaben (Konsole)**: Streaming-Ausgabe des Chatverlaufs (nim_simple_app.py), `print("Response time ...")` (rag_langchain_nim_1.py).

## Zustände

Zustandsmodell pro Streamlit-Session (belegt durch Session-State-Initialisierungen):

- **`vectors`**: `None` → FAISS-Index (nach erfolgreichem Embedding).
- **`docs_loaded`**: `False` → `True` nach Upload (nur rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
- **`loader`**: `None` (nur rag_chatbot_0.py) oder Default-`PyPDFDirectoryLoader("./data")` (chatbot.py u.a.).
- **`history`**: leere Liste → Liste von `{"question": ..., "answer": ...}`-Einträgen.
- **`trigger_refresh`**: nur enhanced_chatbot.py setzt `time.time()`; kein anderer Code liest diesen Schlüssel (toter Zustand).

Gültigkeitsregel, die alle Chatbot-Dateien durchsetzen: Chat-Fragen sind nur bei vorhandenem `vectors` erlaubt, sonst Fehlermeldung (belegt durch `if not st.session_state["vectors"]` in rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py; rag_langchain_nim_1.py prüft dies nicht).

## Sicherheitsrelevanz

- Der API-Key `NVIDIA_API_KEY` wird aus `.env` geladen und in die Umgebung geschrieben; `.env` ist in .gitignore ausgeschlossen (belegt durch .gitignore, README.md, load_dotenv in allen Python-Dateien).
- Bei fehlender `.env` liefert `os.getenv("NVIDIA_API_KEY")` `None`; die Zuweisung `os.environ['NVIDIA_API_KEY'] = None` würde beim Skriptstart einen `TypeError` auslösen (belegt durch Code in allen Python-Dateien) — der Fehlerfall wird nicht behandelt.
- Keine weitere Authentifizierung, keine Autorisierung, keine Rate-Limit-, PII- oder Guard-Rail-Behandlung im Code (Nicht nachweisbar).
- Die Dokumente werden ungefiltert in den LLM-Kontext injiziert; keine Content-Policy-Prüfung (belegt durch Prompt-Templates ohne Filterung).

## Rust-Relevanz

Das Repo definiert die vollständige Capability-Liste einer künftigen Rust-Neuentwicklung: PDF-Text-Extraktion, rekursives Chunking, Embedding-Client (NVIDIA NIM), In-Memory-Vektor-Index mit Ähnlichkeitssuche, Retrieval, Prompt-Assemblierung, LLM-Chat-Client (OpenAI-kompatibel), Streaming, Session-Verwaltung und Ergebnis-Export. Für die Ableitung der Rust-Anforderungen siehe `rust-foundation.md`.
