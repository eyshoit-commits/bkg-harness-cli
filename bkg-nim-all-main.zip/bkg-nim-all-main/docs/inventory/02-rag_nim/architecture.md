# Architektur-Analyse: rag_nim

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

## Komponenten und Module

Das Repo ist eine Sammlung eigenständiger Skripte ohne Paketstruktur; jede Datei ist ein ausführbares Streamlit-Skript (Ausnahme: nim_simple_app.py ist ein Konsolen-Skript). Es gibt keine gemeinsame Bibliothek, keine Konfigurationsmodule, keine Tests.

| Komponente | Dateien | Beleg |
|---|---|---|
| UI-Layer (Streamlit) | alle Chatbot-Dateien | `st.title`, `st.sidebar`, `st.button`, `st.text_input` etc. |
| Konfigurations-Layer | `.env` + load_dotenv | `load_dotenv()`, `os.getenv("NVIDIA_API_KEY")` |
| NIM-Client-Layer (LLM) | `ChatNVIDIA` in allen Chatbot-Dateien; OpenAI-SDK in nim_simple_app.py | `ChatNVIDIA(model="meta/llama3-70b-instruct")`; `OpenAI(base_url=..., api_key=...)` |
| NIM-Client-Layer (Embeddings) | alle Chatbot-Dateien | `NVIDIAEmbeddings()` |
| Ingest-Layer | alle Chatbot-Dateien | `PyPDFDirectoryLoader`, `RecursiveCharacterTextSplitter` |
| Index-Layer | alle Chatbot-Dateien | `FAISS.from_documents` |
| Retrieval-Layer | alle Chatbot-Dateien | `create_retrieval_chain`, `vectors.as_retriever()` |
| Ausgabe-Layer | Chatbot-Dateien | `st.write`, `st.markdown`, `st.expander`, `st.download_button`, `st.pyplot` |
| Zusatzfunktionen | Summarize (3 Dateien), Visualize (3 Dateien) | `load_summarize_chain`, `TSNE` |

## Layer-Modell

1. **Präsentations-Layer (Streamlit):** Buttons, Eingaben, Spinner, Expander, Erfolgs-/Fehlermeldungen, Verlauf, Plot, Download. (belegt durch UI-Aufrufe in allen Chatbot-Dateien)
2. **Anwendungs-Layer (Skript-Logik):** Orchestriert Ingest→Index→Retrieval→Inferenz; Session-State-Verwaltung. (belegt durch `vector_embedding()` und Chat-Blöcke)
3. **Service-Layer (LangChain-Chains):** `create_stuff_documents_chain`, `create_retrieval_chain`, `load_summarize_chain`. (belegt durch Aufrufe)
4. **NIM-Client-Layer:** `ChatNVIDIA`, `NVIDIAEmbeddings` bzw. OpenAI-SDK. (belegt durch Aufrufe)
5. **Infrastruktur-Layer:** `.env`-Key-Loading, FAISS, Dateisystem (`./data`). (belegt durch load_dotenv, `PyPDFDirectoryLoader("./data")`)

## Datenfluss (Dokument → Chunk → Embedding → Index → Retrieve → Prompt → NIM → Antwort)

1. **Dokument:** `PyPDFDirectoryLoader("./data")` liest alle PDFs des Verzeichnisses (Attention.pdf, Raptor.pdf) → Dokumentobjekte mit `page_content`/`metadata` (belegt durch rag_chatbot_0.py; README belegt `./data` als Default).
2. **Chunk:** `RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)` → `final_documents` (in rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py auf `docs[:40]` gekappt).
3. **Embedding:** `NVIDIAEmbeddings()` erzeugt je Chunk einen Vektor (Remote-Aufruf an NVIDIA NIM).
4. **Index:** `FAISS.from_documents(final_documents, embeddings)` → In-Memory-Index.
5. **Retrieve:** `vectors.as_retriever()` → `create_retrieval_chain` → Ähnlichkeitssuche zur Query; Treffer werden zum Kontext (belegt durch `create_retrieval_chain(retriever, document_chain)`).
6. **Prompt:** Stuff-Chain packt den Kontext in das Template mit `{context}`/`{input}`-Platzhaltern (Template in allen Chatbot-Dateien; rag_chatbot_0.py/enhanced_chatbot.py/rag_langchain_nim_1.py: "Answer the questions based on the provided context only"; rag_chatbot_1.py/chatbot.py/complex_rag_chatbot.py: "Use the context below to answer the question.").
7. **NIM-Inferenz:** `ChatNVIDIA(model="meta/llama3-70b-instruct")` erzeugt die Antwort (alle Chatbot-Dateien).
8. **Antwort:** Anzeige (`st.write`/`st.markdown`), Antwortzeit (`time.process_time()`), Quell-Chunks im Expander, Verlauf, JSON-Download (rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py).

Alternativer Fluss ohne RAG (belegt durch nim_simple_app.py): Frage (hart kodiert) → OpenAI-SDK → `chat.completions.create(...)` mit `stream=True` → Chunk-Iteration → Konsole.

## Eventfluss (Streamlit-Interaktionen)

- **Upload-Ereignis:** `uploaded_files` vorhanden → `st.session_state.loader`/`docs` setzen, `docs_loaded=True` (rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
- **Embedding-Button:** → `vector_embedding()` → Erfolgsmeldung (alle Chatbot-Dateien).
- **Chat-Eingabe (Enter) bzw. Submit-Button:** → Guard (`vectors`) → Truncation → Chain-Invoke → Antwort/Verlauf (alle Varianten; complex_rag_chatbot.py mit explizitem Submit-Button und Leer-Warnung).
- **Summarize-Button:** → `load_summarize_chain` (rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py).
- **Visualize-Button:** → t-SNE-Plot (chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
- **Download-Button:** → `st.download_button` mit JSON (rag_chatbot_0.py, enhanced_chatbot.py).
- **Fehlerereignisse:** `st.error`/`st.warning` in allen Varianten; rag_langchain_nim_1.py ohne Fehlerbehandlung.

## APIs

- **NVIDIA NIM (Chat):** `ChatNVIDIA(model="meta/llama3-70b-instruct")` (alle Chatbot-Dateien); direkter OpenAI-kompatibler Aufruf: `base_url = "https://integrate.api.nvidia.com/v1"`, `client.chat.completions.create(model=..., messages=[{"role":"user","content":...}], temperature=0.5, top_p=1, max_tokens=1024, stream=True)` (nim_simple_app.py).
- **NVIDIA NIM (Embeddings):** `NVIDIAEmbeddings()` (alle Chatbot-Dateien); Modell im Code nicht angegeben (Nicht nachweisbar).
- **LangChain:** `PyPDFDirectoryLoader`, `RecursiveCharacterTextSplitter`, `create_stuff_documents_chain`, `create_retrieval_chain`, `load_summarize_chain`, `ChatPromptTemplate`, `FAISS`, `as_retriever`.
- **scikit-learn/matplotlib:** `TSNE`, `plt.scatter`, `st.pyplot`.
- **OpenAI-SDK:** `OpenAI(base_url, api_key)`, `chat.completions.create` (nim_simple_app.py).

## Pipelines

- **Indexing-Pipeline** (belegt durch `vector_embedding()`): Load → Split (700/50) → Embed → FAISS.
- **Inference-Pipeline** (belegt durch Chat-Blöcke): Query → Retrieve → Stuff-Kontext → Prompt → NIM → Antwort.
- **Summarize-Pipeline** (rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py): Chunks → `load_summarize_chain(stuff)` → Text.
- **Visualization-Pipeline** (chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py): FAISS-Rekonstruktion → t-SNE → Plot.

## State Machines

Explizite Zustandsmaschine im Code nicht vorhanden; es existieren zwei beobachtbare Zustandsübergänge (belegt durch Guards):
- `vectors == None` → Chat abgelehnt (`st.error`) → nach Embedding-Button: `vectors != None` → Chat erlaubt.
- `docs_loaded == False` → `vector_embedding()` lädt `./data`; `docs_loaded == True` → Upload-Dokumente werden wiederverwendet (rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).

## Scheduler / Worker / Background Jobs / Queues

Keine im Quellcode (Nicht nachweisbar). Alle Verarbeitung ist synchron und benutzerinitiiert; Streamlit-Rerun-Modell übernimmt die Ausführung.

## Memory-Systeme

- **Short Memory:** Streamlit-Session-State `history` (Frage/Antwort) — reine Anzeige, kein LLM-Kontext (belegt durch fehlende History-Injektion in alle Prompt-Templates).
- **Long/Episodic/Semantic Memory, Facts, Knowledge Graph, Consolidation, Ranking:** Nicht im Code vorhanden (Nicht nachweisbar). Es existieren keine Memory-Crates, keine DB, kein Knowledge Graph; der einzige "Wissensspeicher" ist der FAISS-Index der Session.
- **Retrieval:** FAISS-Ähnlichkeitssuche über `as_retriever()` mit SDK-Defaults (Top-k/Score nicht im Code konfiguriert — Nicht nachweisbar).

## RAG-Detail

- **Chunking-Strategien:** Einzige Strategie: `RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)` (alle Chatbot-Dateien). Keine alternativen Strategien.
- **Retrieval-Methoden:** Einzige Methode: FAISS-Ähnlichkeitssuche über den Default-Retriever (keine Parameter).
- **Ranking/Re-ranking:** Keine im Code; Reihenfolge = Retriever-Default (Nicht nachweisbar).
- **Context-Injection:** Stuff-Strategie: alle (bzw. truncierten) Chunks in das Prompt-Template; Platzhalter `{context}` und `{input}` (alle Chatbot-Dateien); die übergebene `context`-Liste an `invoke` wird durch die Retrieval-Chain verwaltet (Detail Nicht nachweisbar, siehe functions.md).
- **Prompt-Templates:**
  - rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py: "Answer the questions based on the provided context only. Please provide the most accurate response based on the question." + `<context>{context}</context>` + `Questions:{input}`.
  - rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py: "Use the context below to answer the question." + `<context>{context}</context>` + `Question: {input}`.
- **Tool Calling:** Nicht im Code (keine Tool-Definitionen, kein `tools`-Parameter belegt) — Nicht nachweisbar.
- **Streaming:** Nur nim_simple_app.py nutzt Streaming (`stream=True`, Chunk-Iteration); alle Chatbot-Dateien warten auf die vollständige Antwort (kein Streaming-Parameter bei `ChatNVIDIA` belegt).
- **Kontext-Budget:** Wortzahl-Truncation 8192 in 5 Dateien (Wirkung auf LLM-Kontext Nicht nachweisbar, siehe functions.md).

## Persistenz und Memory

Siehe data-models.md: ausschließlich In-Memory/Session; keine Datenbank, kein Object Store, keine Datei-Persistenz außer `.env` und den PDF-Quellen.

## Sicherheits-/Policy-Aspekte

- Keine Policy-Komponente, keine Permissions, keine Audit-Logik, keine PII-Filterung, keine Guard Rails (Nicht nachweisbar — kein entsprechender Code).
- Einzige Sicherheitsmaßnahme: API-Key-Auslagerung nach `.env` mit .gitignore-Ausschluss (belegt durch .gitignore, README.md).
- Schwachstellen (belegt): fehlende Key-Validierung (TypeError bei fehlender `.env`), ungefilterte Dokument-Injektion, kein Rate-Limit-Handling, Upload-Pfad-Fehlbedienung.

## Abhängigkeiten der Komponenten

Alle Chatbot-Dateien hängen von `langchain_nvidia_ai_endpoints` (NIM-Client), `langchain_community` (Loader/FAISS), `langchain` (Chains/Splitter), `langchain_core` (Prompt), `streamlit` (UI), `python-dotenv` (Key) ab (belegt durch Importe). nim_simple_app.py hängt nur von `openai` und `python-dotenv` ab.
