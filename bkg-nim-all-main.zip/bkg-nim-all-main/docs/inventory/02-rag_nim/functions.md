# Funktionsanalyse: rag_nim

Beleg-Regel: Jede Aussage ist durch die genannte Quelldatei gedeckt. Nicht Belegbares: "Nicht nachweisbar."

## Übersicht der analysierten Funktionen

| Funktion | Datei(en) |
|---|---|
| `vector_embedding()` | rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py, rag_langchain_nim_1.py |
| `truncate_documents_for_token_limit(documents, max_tokens=8192)` | rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py |
| `summarize_documents(...)` | rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py |
| `visualize_embeddings(vectors)` | chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py |
| Skript-Logik `nim_simple_app.py` (Chat-Stream) | nim_simple_app.py |
| Modul-Level Code (Key-Load, LLM-Erzeugung, UI-Bausteine) | alle Dateien |

---

## vector_embedding()

**Vorkommen:** rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py, rag_langchain_nim_1.py (mit Varianten).

**Warum existiert sie:** Bündelt die Ingest-Phase der RAG-Pipeline: PDFs laden, chunken, embedden und indexieren, damit die Chat-Phase auf einen Vektor-Index zugreifen kann.

**Welches Problem löst sie:** Überführt unstrukturierte PDFs in einen durchsuchbaren Vektor-Index; verhindert, dass der Nutzer die mehrstufige Pipeline manuell ausführen muss.

**Welche Regeln implementiert sie:**
- Verwendet `NVIDIAEmbeddings()` als Embedder (alle Dateien).
- Verwendet `RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)` (alle Dateien).
- Lädt den Korpus aus `./data` via `PyPDFDirectoryLoader` (alle Dateien); in rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py wird bei bereits geladenen Uploads (`docs_loaded == True`) nicht erneut geladen.
- Kappt die Dokumentenliste auf die ersten 40 (`docs[:40]`) in rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py.
- Baut den Index über `FAISS.from_documents(final_documents, embeddings)`.
- In rag_langchain_nim_1.py wird die gesamte Funktion nur beim ersten Session-Aufruf ausgeführt (`if "vectors" not in st.session_state`).

**Welche Daten verändert sie:** Mutiert `st.session_state`: setzt `embeddings`, `loader`, `docs`, `text_splitter`, `final_documents`, `vectors`.

**Welche Zustände entstehen:** `vectors` wechselt von `None`/nicht vorhanden zu FAISS-Index; alle Chat-Varianten prüfen diesen Zustand als Vorbedingung für Chat-Anfragen.

**Welche Algorithmen werden verwendet:**
- PDF-Text-Extraktion (durch `PyPDFDirectoryLoader`, SDK-intern; Details Nicht nachweisbar).
- Rekursives Chunking mit 700-Zeichen-Chunks und 50-Zeichen-Überlappung (LangChain-Splitter).
- Embedding-Erzeugung über NVIDIA NIM (`NVIDIAEmbeddings`; das konkrete Embedding-Modell ist im Code nicht angegeben — Nicht nachweisbar).
- Vektor-Indexierung via FAISS (exakter Index-Typ/Similarity-Metrik SDK-Default — Nicht nachweisbar).

**Welche Fehler behandelt sie:** Keine interne Fehlerbehandlung in allen sechs Vorkommen; Fehler propagieren an den Button-Handler (in den Streamlit-Varianten) bzw. sind in rag_langchain_nim_1.py unbehandelt.

**Welche Seiteneffekte besitzt sie:** Löst NVIDIA-API-Aufrufe für jeden Chunk (Embedding-Batch) aus; schreibt Session-State; bei Upload-Fehlpfad (UploadedFile-Liste statt Pfad) schlägt der Loader fehl.

---

## truncate_documents_for_token_limit(documents, max_tokens=8192)

**Vorkommen:** rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py.

**Warum existiert sie:** Soll verhindern, dass die Stuff-Chain das Token-Limit des LLM überschreitet (in rag_chatbot_0.py wird dem Nutzer ein Limit von 8192 Token kommuniziert).

**Welches Problem löst sie:** Begrenzt den Kontextumfang vor der LLM-Anfrage.

**Welche Regeln implementiert sie:**
- Zählt Tokens als Wortzahl: `doc_tokens = len(doc.page_content.split())` — Wörter, nicht echte Tokens.
- Bricht beim ersten Dokument ab, das das Budget überschreiten würde (gierige Präfix-Auswahl ohne Re-Ranking).

**Welche Daten verändert sie:** Keine Mutation; erzeugt eine neue, gekürzte Dokumentenliste.

**Welche Zustände entstehen:** Keine Zustandsänderung; reine Transformationsfunktion.

**Welche Algorithmen werden verwendet:** Wortzählung über Whitespace-Splitting; gierige inkrementelle Summe mit Abbruchbedingung.

**Welche Fehler behandelt sie:** Keine; bei leerer Liste ist das Ergebnis eine leere Liste.

**Welche Seiteneffekte besitzt sie:** Keine direkten. **Einschränkung (belegt):** Die gekürzte Liste wird als `"context"`-Key an `retrieval_chain.invoke(...)` übergeben; die Retrieval-Chain setzt den Kontext selbst aus dem Retriever. Ob das SDK das übergebene `context` verwendet oder überschreibt, ist aus dem Quellcode nicht bestimmbar (Nicht nachweisbar). Die Funktion erzeugt daher keinen belegbaren Effekt auf den tatsächlichen LLM-Kontext.

---

## summarize_documents(...)

**Vorkommen:** rag_chatbot_0.py (kein Parameter), chatbot.py (Parameter `summary_type="high_level"`, Werte "detailed"/sonst), enhanced_chatbot.py (kein Parameter).

**Warum existiert sie:** Bietet eine optionale, LLM-generierte Zusammenfassung der eingebetteten Dokumente.

**Welches Problem löst sie:** Komprimiert große Dokumentmengen in einen Überblick, ohne dass der Nutzer alle Chunks lesen muss.

**Welche Regeln implementiert sie:**
- Verwendet `load_summarize_chain(llm, chain_type="stuff")` — die gesamte Dokumentenmenge wird in einem LLM-Aufruf verarbeitet (Stuff-Strategie).
- rag_chatbot_0.py/enhanced_chatbot.py: ein Aufruf über `{"input_documents": st.session_state.final_documents}`.
- chatbot.py: ein Aufruf **pro Chunk** (`for doc in st.session_state.final_documents`), Prompt variiert nach Typ: "detailed" → "Summarize this in detail", sonst "Provide a high-level overview"; Ergebnis-Strings werden mit `"\n".join(...)` verkettet; Zugriff auf den Antwort-`text`-Schlüssel mit Fallback "No summary available".

**Welche Daten verändert sie:** Keine Session-State-Mutation in chatbot.py/enhanced_chatbot.py; in rag_chatbot_0.py wird das Ergebnis lediglich zurückgegeben und angezeigt.

**Welche Zustände entstehen:** Keine dauerhaften.

**Welche Algorithmen werden verwendet:** Stuff-Summarization (alle Chunks in einem Kontext); in chatbot.py zusätzlich Chunk-Serienverarbeitung mit Verkettung.

**Welche Fehler behandelt sie:** `except Exception` → `st.error`; rag_chatbot_0.py/enhanced_chatbot.py geben danach eine leere/Fehler-Zeichenkette zurück; chatbot.py gibt "Failed to summarize documents." zurück. `chunk_summary.get("text", ...)` behandelt fehlende `text`-Schlüssel.

**Welche Seiteneffekte besitzt sie:** Ein (rag_chatbot_0, enhanced) bzw. N (chatbot.py, pro Chunk) LLM-Inferenz-Aufrufe; Token-Budget-Risiko bei großen Korpora (Stuff-Strategie), das in chatbot.py über die Chunk-Serienverarbeitung reduziert wird.

---

## visualize_embeddings(vectors)

**Vorkommen:** chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py.

**Warum existiert sie:** Macht die Embedding-Qualität/Verteilung der Dokumente sichtbar; dient der Inspektion, ob der Korpus sinnvoll eingebettet ist.

**Welches Problem löst sie:** Reduziert hochdimensionale Embeddings auf 2D für die Darstellung im Browser.

**Welche Regeln implementiert sie:**
- Rekonstruiert alle Vektoren aus dem FAISS-Index: `vectors.index.reconstruct(i)` für `i in range(vectors.index.ntotal)`.
- t-SNE mit `n_components=2`, `random_state=42`, `perplexity=30` (sklearn).
- chatbot.py/complex_rag_chatbot.py: Punkt-Labels aus `metadata.get('source', 'Unknown')` (Quelldatei je Chunk); enhanced_chatbot.py: nur Punkte ohne Labels.
- Voraussetzung: `vectors` existiert (in allen drei Dateien vor Button-Aufruf geprüft).

**Welche Daten verändert sie:** Keine; rein lesende Funktion. Erzeugt einen matplotlib-Plot.

**Welche Zustände entstehen:** Keine.

**Welche Algorithmen werden verwendet:** Vektor-Rekonstruktion aus FAISS (`reconstruct`, `ntotal`), t-SNE-Dimensionalitätsreduktion (perplexity 30, deterministischer Seed 42), Streudiagramm-Darstellung.

**Welche Fehler behandelt sie:** Keine interne Fehlerbehandlung; Fehler bei zu wenigen Samples/Perplexity (z.B. weniger Punkte als Perplexity) sind nicht abgefangen (Nicht nachweisbar konkret, da keine Fehlerbehandlung existiert).

**Welche Seiteneffekte besitzt sie:** CPU-intensive t-SNE-Berechnung auf allen Embeddings je Klick; Plot-Rendering im Browser.

---

## Nim-Simple-App-Skriptlogik (nim_simple_app.py)

**Warum existiert sie:** Beweist, dass NVIDIA NIM ohne LangChain über das OpenAI-SDK erreichbar ist — Grundlage der Chat-Capability der übrigen Dateien.

**Welches Problem löst sie:** Reduziert die NIM-Interaktion auf das Minimum (ein Chat-Aufruf, ein Streaming).

**Welche Regeln implementiert sie:**
- `base_url = "https://integrate.api.nvidia.com/v1"` und `api_key` aus `.env`.
- Modell `meta/llama3-70b-instruct`, `temperature=0.5`, `top_p=1`, `max_tokens=1024`, `stream=True`.
- Ausgabe nur bei `chunk.choices[0].delta.content is not None`.

**Welche Daten verändert sie:** Keine; gibt Streaming-Chunks auf der Konsole aus.

**Welche Zustände entstehen:** Streaming-Iterator-Zustand der Completion.

**Welche Algorithmen werden verwendet:** Keine über das SDK hinaus.

**Welche Fehler behandelt sie:** Keine (kein try/except, kein Retry, kein Timeout); fehlender API-Key wird ungeprüft an den Client gegeben (`api_key = os.getenv(...)`).

**Welche Seiteneffekte besitzt sie:** Ein LLM-Inferenz-Aufruf je Lauf; Konsolenausgabe.

---

## Modul-Level Code (alle Dateien)

**Warum existiert er:** Initialisiert Umgebung, LLM und UI einmalig beim Skriptstart.

**Welche Regeln implementiert er:**
- `load_dotenv()` + `os.environ['NVIDIA_API_KEY'] = os.getenv("NVIDIA_API_KEY")` (alle Python-Dateien): lädt den Key aus `.env` und stellt ihn der Umgebung bereit.
- `llm = ChatNVIDIA(model="meta/llama3-70b-instruct")` (alle Chatbot-Dateien): ein LLM-Client pro Prozess.
- Session-State-Initialisierung (Varianten: siehe files.md).

**Welche Daten verändert er:** `os.environ` (API-Key); `st.session_state` (Defaults).

**Welche Zustände entstehen:** Prozessweite LLM-Client-Instanz; Session-Defaults (`vectors=None`, `history=[]`, `loader=...`, `docs_loaded=False`).

**Welche Algorithmen werden verwendet:** Keine.

**Welche Fehler behandelt er:** Keine; bei fehlender `.env` schlägt die `os.environ`-Zuweisung von `None` fehl (TypeError beim Start, in allen Dateien gleiche Struktur).

**Welche Seiteneffekte besitzt er:** Umgebungsvariablen-Mutation; bei Streamlit pro Session-Rerun erneut ausgeführt (Idempotenz über Session-State-Checks).

---

## Fehlerfall-Matrix (belegt durch Quellcode)

| Fehlerfall | Datei | Verhalten |
|---|---|---|
| Upload liefert UploadedFile-Liste an `PyPDFDirectoryLoader` | rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py | Loader erwartet Pfad → funktional fehlerhafter Upload-Pfad |
| `.env` fehlt → `os.getenv` liefert `None` | alle Python-Dateien | `os.environ['NVIDIA_API_KEY'] = None` → TypeError beim Start |
| Frage ohne erzeugte Embeddings | rag_langchain_nim_1.py | kein Guard → Zugriff auf `None` (`vectors.as_retriever()`) |
| Frage ohne erzeugte Embeddings | rag_chatbot_0.py, rag_chatbot_1.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py | `st.error`-Meldung, Abbruch |
| Leere Frage | complex_rag_chatbot.py | `st.warning("Please enter a valid question.")`; rag_chatbot_1.py ignoriert still |
| Summarize-/Chat-Fehler | rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py u.a. | `except Exception` → `st.error` |
| Token-Budget | 5 Dateien | Wortzahl-Truncation (Wirkung auf LLM-Kontext Nicht nachweisbar) |
