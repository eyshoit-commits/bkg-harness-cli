# Rust-Rewrite-Foundation: rag_nim

Abgeleitet ausschließlich aus der Quellcode-Analyse der 7 Python-Dateien, der Meta-Dateien und der Assets. Jede Capability ist durch die genannte Quelldatei belegt. Die Rust-Implementierung wird vollständig neu entwickelt (keine Code-Übernahme).

## Benötigte Capability

1. **Konfigurationsladung:** `NVIDIA_API_KEY` aus `.env` laden und validieren (belegt durch load_dotenv/`os.getenv` in allen 7 Python-Dateien; README.md).
2. **PDF-Korpus-Ingestion:** Alle PDFs eines Verzeichnisses laden (belegt durch `PyPDFDirectoryLoader("./data")` in allen 6 Chatbot-Dateien; Korpus: data/Attention.pdf, data/Raptor.pdf).
3. **Text-Chunking:** Rekursive Aufteilung mit 700-Zeichen-Chunks und 50-Zeichen-Überlappung (belegt durch `RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50)` in allen 6 Chatbot-Dateien); optionale Dokumenten-Obergrenze (belegt durch `docs[:40]` in rag_chatbot_0.py, enhanced_chatbot.py, rag_langchain_nim_1.py).
4. **Embedding-Erzeugung:** Remote-Embedding je Chunk über NVIDIA NIM (belegt durch `NVIDIAEmbeddings()` in allen 6 Chatbot-Dateien).
5. **Vektor-Indexierung und Ähnlichkeitssuche:** In-Memory-Index mit `ntotal`-/`reconstruct`-artigen Operationen und Retrieval zur Query (belegt durch `FAISS.from_documents`, `index.ntotal`, `index.reconstruct`, `as_retriever()`).
6. **Kontext-Assemblierung (Stuff):** Retried Chunks + Prompt-Template mit `{context}`/`{input}` an das LLM (belegt durch `create_stuff_documents_chain`/`create_retrieval_chain` in allen 6 Chatbot-Dateien).
7. **LLM-Chat-Inferenz:** Chat-Aufruf gegen `meta/llama3-70b-instruct` über NVIDIA NIM (belegt in allen 7 Dateien).
8. **Chat-Streaming:** Chunk-weises Ausgeben von Antwort-Tokens (belegt durch `stream=True`, `choices[0].delta.content` in nim_simple_app.py).
9. **Kontext-Budget-Verwaltung:** Wortzahlbasierte Kappung (belegt durch `truncate_documents_for_token_limit` in 5 Dateien; Budget 8192).
10. **Dokument-Zusammenfassung:** Stuff-Summarization (belegt durch `load_summarize_chain` in rag_chatbot_0.py, chatbot.py, enhanced_chatbot.py).
11. **Embedding-Visualisierung:** Rekonstruktion der Vektoren und 2D-Projektion (belegt durch `index.reconstruct`/`TSNE` in chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
12. **Session-/Verlaufsverwaltung:** Frage/Antwort-Verlauf pro Nutzer-Sitzung inkl. JSON-Export (belegt durch `st.session_state["history"]`, `st.download_button` in rag_chatbot_0.py, chatbot.py, complex_rag_chatbot.py, enhanced_chatbot.py).
13. **Fehlerbehandlung und Guards:** Chat nur bei existierendem Index; Leer-Eingabe-Validierung; Fehlermeldungen statt Abstürze (belegt durch Guards in 5 Chatbot-Dateien; rag_langchain_nim_1.py demonstriert die Folgen fehlender Guards).

## Benötigte Rust Traits

- `Embedder`: asynchrone Vektor-Erzeugung `fn embed(&self, chunks: &[Chunk]) -> Result<Vec<Embedding>>` (Capability 4).
- `Retriever`: `fn retrieve(&self, query: &str, top_k: usize) -> Result<Vec<ScoredChunk>>` (Capability 5, 6).
- `Chunker`: pure Funktion `fn split(text: &str, config: &ChunkConfig) -> Vec<Chunk>` (Capability 3).
- `ChatClient`: `fn chat(&self, request: &ChatRequest) -> Result<ChatResponse>` sowie Streaming-Variante `fn chat_stream(...) -> impl Stream<Item = Result<String>>` (Capability 7, 8).
- `DocumentLoader`: `fn load(&self, path: &Path) -> Result<Vec<Document>>` (Capability 2).
- `ConversationStore`: append + serialize des Verlaufs (Capability 12).
- `Error`-Trait für den zentralen Fehlertyp (Capability 13).

## Benötigte Module

- `config`: .env-/Umgebungsvariablen-Laden, typisierte Konfiguration (Modell, Splitter-Parameter, Budget, Datenpfad).
- `document`: `Document`/`Chunk`-Strukturen mit Metadaten (`source`), Serde.
- `ingestion`: PDF-Verzeichnis-Loader.
- `chunking`: rekursiver Splitter mit Konfiguration.
- `embedding`: NIM-Embedding-Client (Request/Response, Batch).
- `index`: In-Memory-Vektor-Index (Insert, `total`, `reconstruct`, Search).
- `retrieval`: Query-Verarbeitung, Top-k, Scored-Chunks.
- `prompt`: Template-Verwaltung (Kontext/Question), Stuff-Assemblierung.
- `chat`: NIM-Chat-Client, Streaming, Sampling-Parameter.
- `summarize`: Stuff-Summarization-Service.
- `visualize`: Embedding-Projektion (optional, UI-abhängig).
- `session`: Verlauf/State pro Sitzung, JSON-Export.
- `error`: zentrale Fehlertypen.

## Benötigte Services

- `IngestService`: orchestriert Laden → Chunking → Embedding → Index-Aufbau (entspricht `vector_embedding()`).
- `ChatService`: orchestriert Retrieval → Kontext-Budget → Prompt → NIM-Inferenz → Antwort (entspricht den Chat-Blöcken).
- `SummarizeService`: Stuff-Zusammenfassung.
- `ConfigService`: Key-/Parameter-Bereitstellung mit Validierung.
- `ExportService`: Verlaufs-Serialisierung.

## Benötigte Events

- `DocumentsLoaded { count, sources }` (Capability 2).
- `IndexBuilt { chunk_count }` (Capability 5).
- `QuerySubmitted { question }` / `QueryCompleted { question, answer, response_time }` (Capability 7, 12).
- `EmbeddingBatchCompleted { batch_size }` (Capability 4).
- `StreamChunk { delta }` / `StreamEnded` (Capability 8).
- `ErrorOccurred { phase, error }` (Capability 13).
- `HistoryExported { format }` (Capability 12).

## Benötigte Storage Layer

- `SessionState`: In-Memory pro Sitzung (Index, Chunks, Verlauf) — entspricht `st.session_state` (Persistenz: keine, wie im Python-Code).
- `ConfigStorage`: `.env`-Datei / Umgebung (read-only).
- `CorpusStorage`: Dateisystem (data/*.pdf).
- Optional (Designentscheidung, im Python-Code nicht vorhanden): persistente Index-/Verlaufs-Speicherung als Erweiterung — nicht aus dem Quellcode abgeleitet, da dort keine Persistenz existiert (Nicht nachweisbar als Anforderung).

## Benötigte Async-Komponenten

- Async-HTTP-Clients für Chat, Streaming und Embeddings (Tokio-basiert) mit Timeout-/Retry-Kontrolle.
- Stream-Verarbeitung der SSE-Antworten (Chunk-Delta-Parsing, Ende-Erkennung) — entspricht dem `for chunk in completion`-Iterationsmodell (nim_simple_app.py).
- Parallele Batch-Embedding-Verarbeitung mit begrenzter Konkurrenz (Capability 4; im Python-Code sequenziell, Parallelität ist Neudesign).
- Keine Scheduler/Worker/Queues erforderlich (im Quellcode nicht vorhanden).

## Benötigte Error Types

- `ConfigError` (fehlender/invalid API-Key — ersetzt den TypeError bei `os.environ`-Zuweisung von `None`).
- `IngestionError` (PDF-Lese-/Parsefehler; Upload-Validierungsfehler — ersetzt den defekten `PyPDFDirectoryLoader(uploaded_files)`-Pfad).
- `EmbeddingError` (HTTP-Fehler, Rate Limit, Dimensionsfehler).
- `IndexError` (leerer Index, nicht rekonstruierbarer Eintrag).
- `RetrievalError` (leere Ergebnisse, fehlender Index — ersetzt den `None`-Zugriff in rag_langchain_nim_1.py).
- `ChatError` (HTTP-Status, Timeout, Stream-Abbruch, leere `choices`).
- `ValidationError` (leere Eingabe, Budget-Überschreitung).
- `ExportError` (Serialisierung).

## Benötigte Crates

- `tokio` — Async-Runtime (Async-Komponenten).
- `reqwest` (+ `rustls`/native-tls) — HTTP-Client für NIM.
- `serde` / `serde_json` — Request/Response, Verlaufs-Export, Konfiguration.
- `eventsource-stream` oder SSE-Parser (z.B. `reqwest-eventsource`) — Streaming-Parsing.
- `dotenvy` — `.env`-Laden.
- `pdf-extract` oder `pdf` — PDF-Text-Extraktion.
- `thiserror` / `anyhow` — Error Types.
- Eigenes Index-Modul (bruteforce/HNSW) oder Crate (z.B. `hnsw_rs` / `space`/`simsimd` für Distanzberechnung) — Ähnlichkeitssuche.
- Optional UI: `axum`/`maud`/Web-Frontend (ersetzt Streamlit) — Designentscheidung; `plotters`/`chart`-Crate für Visualisierung, `ndarray`/`linfa` für t-SNE-Analog.
- `async-stream` — Streaming-Schnittstellen.
- `tracing` — Logging/Audit.

## Architekturentscheidung

- **Modularer Service-Stack statt monolithischer Skripte:** Die Python-Varianten duplizieren die Pipeline je Datei (belegt durch identische Struktur in 6 Chatbot-Dateien). Die Rust-Version kapselt Ingest-, Chat-, Summarize- und Export-Fähigkeiten in getrennten Modulen mit einem zentralen `ChatService`-Orchestrator.
- **Explizite Zustände durch Typen:** `None`-Sentinel-Zustände (`vectors`, `loader`) und tote Schlüssel (`trigger_refresh` in enhanced_chatbot.py) werden durch `Option<Index>`/typisierte State-Machines ersetzt; Zustandsübergänge (kein Index → Chat abgelehnt) werden zur Kompilierzeit abgesichert.
- **Fehler statt Abstürze:** Alle im Python-Code unbehandelten Fehlerfälle (fehlender Key, fehlender Index, Upload-Typfehler, Stream-Abbruch) werden in einem zentralen Error-Typ abgebildet und an der Service-Grenze behandelt.
- **Strict-Streaming-fähiger NIM-Client:** Ein Client mit einheitlicher Request-Definition (Modell, messages, Sampling, stream) für Chat und Embeddings; OpenAI-kompatible Basis-URL `https://integrate.api.nvidia.com/v1` als Konfiguration (belegt durch nim_simple_app.py).
- **Kontext-Budget als explizite Pipeline-Stufe:** Die Wortzahl-Truncation (8192) wird zu einer nachweisbaren Verarbeitungsstufe mit echten Token-Zählung (im Python-Code unzuverlässig, siehe functions.md) und Tests.
- **Persistenz als bewusste Entscheidung:** Die Python-Basis hat keine Persistenz; die Rust-Version startet bewusst ebenfalls sessionbasiert und bietet persistente Speicherung nur als optionale, klar getrennte Erweiterung (keine aus dem Quellcode abgeleitete Pflicht).
- **Kein Tool Calling / Model Routing in v1:** Beide Fähigkeiten sind im Quellcode nicht vorhanden (Nicht nachweisbar) und werden daher nicht als Anforderung übernommen; die Client-Schnittstellen lassen sie als spätere Erweiterung zu (Request-Struktur mit optionalen Feldern).
