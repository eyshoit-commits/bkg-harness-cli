# Architektur: agent-memory-systems

## Komponenten

Das Repo besteht aus drei ausführbaren Einstiegspunkten und einem Bibliothekspaket (belegt durch die Dateiliste und README.md "Project structure"):

1. demo_chat.py — interaktive CLI-REPL mit Memory-Anreicherung.
2. benchmark.py — Replay-Benchmark über alle Backends.
3. src/consolidate.py (ausführbar als Modul) — Offline-Konsolidierung ("sleep").
4. Bibliothekspaket src/ mit:
   - src/nim.py — NIM-Client (Chat + Embeddings).
   - src/extract.py — LLM-Triple-Extraktion.
   - src/util.py — Normalisierung + Keyword-Extraktion.
   - src/memory/ — fünf Backends + Vertrag + Factory.

## Module und Layer

Layering (Aufrufrichtung, belegt durch die Importe):

- Einstiegslayer (demo_chat.py, benchmark.py, src/consolidate.py CLI) → spricht ausschließlich die Backend-Schnittstelle (remember/recall/stats/wipe) und die NIM-Chat-Funktion an.
- Vertragslayer: src/memory/base.py (MemoryBackend-ABC, Turn).
- Backend-Layer: src/memory/window.py, summary.py, episodic.py, facts.py, graph.py — jeweils unabhängig voneinander, nur über den Vertrag gekoppelt.
- Gemeinsame Dienste: src/nim.py (extern), src/extract.py (von facts/graph/consolidate genutzt), src/util.py (von facts/graph genutzt).
- Fabrik-Layer: src/memory/__init__.py (make_backend) verdrahtet Namen → Implementierung und leitet Speicherpfade ab.

## Datenfluss (Hauptpfad Chat)

1. Nutzereingabe in demo_chat.py → Kommando-Check → respond().
2. build_context(): für jedes Backend recall(query, k=6) → Snippet-Liste → Blöcke "[name]\n- …" → MEMORY-Abschnitt.
3. respond(): Nachrichtenliste (System mit MEMORY + Nutzertext) → src/nim.py chat() → LLM-Antwort.
4. Antwort zurück an Nutzer; user- und assistant-Turn (Indizes i, i+1) werden an jedes Backend via remember() übergeben (belegt durch demo_chat.py, Funktion respond).

## Datenfluss (Benchmark)

1. load_script(data/script.json) → Liste.
2. Pro Backend: make_backend + wipe → Replay: turns → remember (Latenzmessung), probes → recall + chat(temperature=0.0, max_tokens=120) → Substring-Hit-Wertung.
3. Aggregation → Tabelle/Analyse → optional JSON (belegt durch benchmark.py, run_backend/main).

## Datenfluss (Konsolidierung)

1. EpisodicMemory + FactMemory aus dem Store-Verzeichnis laden; Importance-Cache laden.
2. Promotion: Kosinus-Cluster-Größe >= 3 → extract_triples → facts.upsert.
3. Dedupe: Paar-Similarität >= 0.93 → drop.
4. Prune: Importance < 0.35 (LLM-Scores, 20er-Batches, SHA1-Cache) → drop.
5. Cache + Stores speichern (außer dry_run); Bericht als JSON (belegt durch src/consolidate.py, consolidate).

## Eventfluss

- Es existieren keine expliziten Event-/PubSub-Mechanismen, Callbacks, Message Queues oder Signal-Handler im Code (keine entsprechenden Konstrukte nachweisbar).
- Ereignisartige Abläufe sind rein sequenziell in den Einstiegspunkten: interaktive Eingaben (demo_chat), Skript-Items (benchmark), Konsolidierungsschritte (consolidate).
- Einziger "Abbruch-Event": fehlender API-Key → Meldung + Prozessende (src/nim.py, require_key).

## APIs

Interne API-Oberflächen:
- MemoryBackend: remember(turn), recall(query, k=5), stats(), wipe(), inspect() (src/memory/base.py).
- Turn: role, content, ts, index, meta; as_line() (src/memory/base.py).
- make_backend(name, store_dir="data", model=None, **kwargs) → MemoryBackend (src/memory/__init__.py).
- src/nim.py: require_key(), get_client(), chat(messages, model, temperature, max_tokens), embed(texts, input_type, model).
- src/extract.py: extract_triples(text, speaker="user", model).
- src/util.py: normalize_name(name), keywords(text, min_len=3).
- src/memory/episodic.py: zusätzlich drop(indices).
- src/memory/facts.py: zusätzlich upsert(subject, predicate, obj, source_turn).
- src/consolidate.py: dedupe(ep, threshold), score_importance(texts, cache), consolidate(store, …).

Externe API: NVIDIA NIM OpenAI-kompatibler Endpoint (https://integrate.api.nvidia.com/v1) — Chat-Completions und Embeddings (src/nim.py). Keine weiteren externen APIs.

## State Machines

- Es existiert keine explizite State-Machine-Definition (keine Zustandsautomaten-Bibliothek, keine Zustands-Diagramme im Code).
- De-facto-Zustandslogik:
  - Window: Fensterinhalt + Evictions-Zähler (src/memory/window.py).
  - Summary: Puffer-Größe triggert Kompression (Zustandsübergang bei 2 * keep_last) (src/memory/summary.py).
  - Facts: aktiv ↔ verdrängt (active-Flag, superseded_by) (src/memory/facts.py).
  - Konsolidierung: dry_run-Schalter beeinflusst alle Mutationspfade (src/consolidate.py).

## Scheduler / Worker / Pipelines / Background Jobs / Queues

- Keine Scheduler, Worker, Background-Jobs, Queues oder asynchronen Pipelines vorhanden (keine entsprechenden Konstrukte im Code).
- Die Konsolidierung ist ein explizit manuell gestarteter Offline-Job (README: "Between sessions, run the consolidation job", Aufruf per `python -m src.consolidate`); ein Zeitplan (z.B. Nightly) ist nur als Empfehlung im README dokumentiert, nicht implementiert.
- Die einzige "Pipeline" ist die sequenzielle Abfolge Promotion → Dedupe → Prune in consolidate().

## Memory-Systeme

Abdeckung der fünf Backends (belegt durch README.md Backend-Tabelle und die Backend-Dateien):

- Short Memory / Working Memory: Window-Backend (token-budgetierter Verlauf, keine Persistenz) — src/memory/window.py.
- Long Memory (komprimierend): Summary-Backend (Rolling Summary, konstante Größe) — src/memory/summary.py.
- Episodic Memory: Episodic-Backend (Vektor-Store, Relevanz + Recency) — src/memory/episodic.py.
- Semantic Memory / Facts: Facts-Backend (SQLite, Supersession, Audit-Historie) — src/memory/facts.py.
- Knowledge Graph: Graph-Backend (networkx-Multigraph, Ego-Graph-Recall) — src/memory/graph.py.
- Consolidation: src/consolidate.py — dedupe (Kosinus >= 0.93), promote (Cluster >= 3 → Fakten), prune (Importance < 0.35).
- Ranking: Episodic (gewichteter Score aus Kosinus + exponentieller Recency), Facts (Keyword-Überlappung + Zeitstempel), Graph (Ego-Graph-Expansion), Window/Summary (nicht query-basiert).
- Retrieval: Episodic (Vektor-Ähnlichkeit), Facts (Keyword + LIKE), Graph (Keyword-Seeds → Ego-Graph), Window/Summary (vollständiger Kontext).
- RAG: Kein vollständiger RAG-Stack; das Muster "Recall → Kontextblock → LLM" (demo_chat.py/benchmark.py) ist ein minimalistisches Retrieval-Augmented-Generation-Schema ohne Chunking/Dokumentpipeline.

## Policy

- Kein eigenständiges Policy-System vorhanden (keine Regeln-, Evaluierungs-, Audit-, Permission-, Validierungs- oder PII-Module nachweisbar).
- De-facto-Regeln im Prompt-Bereich:
  - Antwort-Regel des Agenten: bei fehlender Memory-Antwort "weiß nicht" sagen statt raten (demo_chat.py, SYSTEM).
  - Benchmark-Probe-Regel: ausschließlich MEMORY-Block nutzen, exakt "I don't know" bei fehlender Antwort (benchmark.py, PROBE_SYSTEM).
  - Extraktions-Regeln für stabile Fakten (src/extract.py, TRIPLE_PROMPT).
  - Kompressions-Regeln für die Zusammenfassung (src/memory/summary.py, COMPRESSION_PROMPT).
  - Wichtigkeits-Scoring-Regeln (src/consolidate.py, IMPORTANCE_PROMPT).
- Guard Rails: Nur die LLM-Prompt-Anweisungen; keine programmatischen Filter gegen Schad- oder PII-Inhalte.

## NVIDIA-NIM-Anbindung

- OpenAI-kompatibler Client (openai-SDK) gegen https://integrate.api.nvidia.com/v1 (src/nim.py).
- Chat: model "meta/llama-3.3-70b-instruct" (Default; override via NIM_MODEL oder Parameter), temperature/max_tokens pro Aufruf einstellbar.
- Embeddings: "nvidia/nv-embedqa-e5-v5" mit input_type ("passage" gespeichert / "query" Abfrage) und truncate="END" (src/nim.py, embed).
- Kein Streaming, kein Tool Calling, kein Retry, kein Rate-Limit-Handling, kein Model Routing über mehrere Modelle hinweg im Code (Details in nim.md).

## Tool Calling

- Nicht vorhanden: keine Tool-Definitionen, keine tool-Calls, kein function-calling im Code (belegt durch vollständige Durchsicht; src/nim.py chat sendet nur messages/temperature/max_tokens).

## Streaming

- Nicht vorhanden: keine Stream-Parameter, keine SSE-Verarbeitung, keine Token-Stream-Konsumierung (belegt durch src/nim.py; kein stream-Aufruf).

## Konfiguration

- Umgebung: NVIDIA_API_KEY (Pflicht, Präfix-Validierung), NIM_MODEL (optional) (src/nim.py, .env.example).
- CLI: --memory/--store (demo_chat), --script/--only/--store/--json (benchmark), --store/--dedupe-threshold/--prune-threshold/--repeat-promote/--dry-run (consolidate).
- Konstruktionsparameter: token_budget (window, Default 800), keep_last (summary, Default 6), half_life_turns/relevance_weight (episodic, 40/0.7), radius (graph, 1), Schwellwerte (consolidate, 0.93/0.35/3).

## Persistenzorte (Übersicht)

- data/ (Standard für demo_chat): episodic.npz, episodic.jsonl, facts.db, graph.graphml, importance_cache.json (nach Konsolidierung).
- results/bench/<backend> (Standard für benchmark): je Backend eigene Stores.
- data/script.json: committete Fixture.
- .gitignore grenzt generierte Dateien aus.

## Sicherheitsarchitektur

- Credential-Handling: API-Key nur aus Umgebung/.env; .env ignoriert; Platzhalter-Prüfung (src/nim.py, require_key).
- Keine Verschlüsselung at rest, keine Zugriffskontrolle auf Stores, keine Netzwerk-Exposition.
- LLM-Ausgaben werden strukturell, nicht inhaltlich gefiltert (src/extract.py).
- SQLite-Zugriffe verwenden parametrisierte Abfragen (src/memory/facts.py, recall mit Platzhaltern) — schützt vor SQL-Injection über Query-Strings.
