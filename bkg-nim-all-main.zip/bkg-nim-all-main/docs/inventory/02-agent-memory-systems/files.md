# Dateidokumentation: agent-memory-systems

Für jede der 20 Nicht-Git-Dateien des Repos ein Abschnitt mit den verbindlichen Feldern. Belegstellen beziehen sich auf Dateipfade relativ zu `source/agent-memory-systems/`.

---

## .env.example

- Zweck: Vorlage für die Umgebungskonfiguration; dokumentiert die zwei unterstützten Umgebungsvariablen samt Beispielwerten und Kommentaren (belegt durch .env.example).
- Verantwortlichkeit: Definiert den Vertrag für die Laufzeitkonfiguration des Repos: Pflicht-API-Key für NVIDIA NIM und optionales Chat-Modell.
- Eingaben: Keine (reine Textvorlage). Dargestellte Werte: `NVIDIA_API_KEY` mit Platzhalter `nvapi-XXXXXXXXXXXXXXXXXXXXXXXX`, `NIM_MODEL` mit `meta/llama-3.3-70b-instruct`.
- Ausgaben: Keine.
- Datenfluss: Die Werte werden vom Nutzer in eine lokale `.env` kopiert; src/nim.py lädt sie zur Laufzeit (Aufruf von load_dotenv, Funktion require_key liest `NVIDIA_API_KEY`; Funktion chat liest optional `NIM_MODEL`).
- Persistenz: Die Vorlage selbst ist committet; die daraus erzeugte `.env` ist in .gitignore als ignoriert gelistet.
- Zustände: Nicht nachweisbar (reine Textdatei ohne Laufzeitlogik).
- APIs: Keine. Dokumentierte Konfigurationsschnittstellen: Umgebungsvariable `NVIDIA_API_KEY`, `NIM_MODEL`.
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Ein fehlender oder mit `nvapi-XXXX` beginnender Key führt beim ersten Client-Aufruf zu einer Abbruchmeldung mit Setup-Anleitung (belegt durch src/nim.py, Funktion require_key).
- Sicherheitsrelevanz: Die Datei enthält keinen echten Key; die Regel, den Key nicht ins Repo zu committen, wird durch .gitignore (.env) und durch die Platzhalterprüfung in src/nim.py abgesichert.
- Geschäftslogik: Keine.
- Algorithmen: Keine.
- verwendete Datenmodelle: Schlüssel-Wert-Umgebungsvariablen im dotenv-Format (Variablennamen, Werte, Kommentare).
- Abhängigkeiten: python-dotenv (belegt durch requirements.txt und src/nim.py Import).
- Rust-Relevanz: Die Capability "Konfiguration über Umgebungsvariablen mit Beispielvorlage und Platzhaltervalidierung" muss in Rust nachgebaut werden (Config-Layer, z.B. dotenvy/figment-Crate, mit Validierung des Key-Präfixes).

---

## .gitignore

- Zweck: Legt fest, welche Dateien und Verzeichnisse nicht versioniert werden (belegt durch .gitignore).
- Verantwortlichkeit: Verhindert das Einchecken von Python-Artefakten, Secrets, generierten Speicher-Stores, Benchmark-/Laufzeit-Ausgaben und Editor-/OS-Dateien.
- Eingaben: Keine.
- Ausgaben: Keine.
- Datenfluss: Keine.
- Persistenz: Betrifft den Git-Index des Repos; legt die Grenze zwischen committeten Quelldateien und generierten Artefakten fest. Explizit NICHT ignoriert ist `data/script.json` (Kommentar "script.json is committed and NOT ignored").
- Zustände: Nicht nachweisbar.
- APIs: Keine.
- Ereignisse: Keine.
- Nebenwirkungen: Generierte Speicherdateien (`*.db`, `data/*.npz`, `data/*.jsonl`, `data/*.graphml`, `data/importance_cache.json`), Ergebnisverzeichnisse (`results/`, `out/`, `logs/`, `.store/`) und `.env` bleiben außerhalb der Versionskontrolle.
- Fehlerfälle: Nicht nachweisbar (keine Laufzeitlogik).
- Sicherheitsrelevanz: Schützt Secrets (`env/`, `.env`) und die Python-Bytecode-Caches vor dem Einchecken.
- Geschäftslogik: Keine.
- Algorithmen: Keine.
- verwendete Datenmodelle: Glob-Musterliste.
- Abhängigkeiten: Git.
- Rust-Relevanz: Die Capability "Repo-Hygiene: generierte Stores und Secrets aus der Versionskontrolle ausschließen" muss im neuen Rust-Workspace fortgeführt werden (analoge Muster, ergänzt um `target/` und Cargo-Artefakte).

---

## LICENSE

- Zweck: Legt die Nutzungsrechte des Repos fest; MIT-Lizenz (belegt durch LICENSE).
- Verantwortlichkeit: Rechteeinräumung für Nutzung, Kopie, Modifikation, Fusion und Verkauf der Software; Haftungsausschluss ("AS IS", ohne Gewährleistung).
- Eingaben: Keine.
- Ausgaben: Keine.
- Datenfluss: Keine.
- Persistenz: Keine.
- Zustände: Nicht nachweisbar.
- APIs: Keine.
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Nicht nachweisbar.
- Sicherheitsrelevanz: Keine funktionale Sicherheitswirkung; Rechtswirkung: kein Gewährleistungs- oder Haftungsschutz für Urheber (Copyright-Inhaber laut Datei: Alejandro Brito, 2026).
- Geschäftslogik: Keine.
- Algorithmen: Keine.
- verwendete Datenmodelle: Freitext-Lizenzvertrag (MIT-Volltext).
- Abhängigkeiten: Keine.
- Rust-Relevanz: Die Lizenzentscheidung (MIT) und der Copyright-Vermerk müssen in die Cargo.toml und LICENSE-Datei der Rust-Neuentwicklung übernommen werden (rechtliche Capability, kein Code).

---

## README.md

- Zweck: Zentrale Projektdokumentation: Motivation, die fünf Backends, Quickstart, Nutzungsbeispiele, Benchmark-Erklärung, Konsolidierungsanleitung, Projektstruktur, Produktionshinweise und Verweise auf verwandte Repos (belegt durch README.md).
- Verantwortlichkeit: Vermittelt das Verständnis der Architektur, der Trade-offs der Backends, der Einrichtung (NIM-Key) und der Betriebskommandos.
- Eingaben: Keine (Dokumentation). Beispielhafte CLI-Aufrufe: `python demo_chat.py --memory facts`, `python benchmark.py`, `python -m src.consolidate --store data --dry-run`.
- Ausgaben: Keine (Dokumentation).
- Datenfluss: Beschreibt den Datenfluss als Mermaid-Diagramme (Turn → Backends → Kontext → LLM; Produktions-Stack mit Window/Writer/Retriever/Consolidation).
- Persistenz: Keine.
- Zustände: Nicht nachweisbar.
- APIs: Dokumentiert die CLI-Kommandos der enthaltenen Skripte und die vier Backend-Methoden (remember, recall, stats, wipe).
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Dokumentiert das Verhalten bei fehlendem Key ("short setup message, not a stack trace") und die Nicht-Determinismus-Einschränkung der Benchmark-Zahlen.
- Sicherheitsrelevanz: Enthält Anweisungen, den API-Key über .env zu setzen und nicht zu teilen; keine Secrets im Dokument.
- Geschäftslogik: Fasst die Nutzungsregeln der Backends: window immer behalten, facts für korrekte Werte (Supersession), episodic für Fuzzy-Recall, graph für relationale Fragen, summary als Budget-Option, Konsolidierung auf Zeitplan (Abschnitt "Combining backends in production").
- Algorithmen: Keine (nur Beschreibung; nennt u.a. Kosinus-Ähnlichkeit, Ego-Graph, Supersession als Konzepte).
- verwendete Datenmodelle: Keine; nennt die Persistenzformate (npz/jsonl, SQLite, GraphML).
- Abhängigkeiten: Keine.
- Rust-Relevanz: Die Capability "verständliche Architektur- und Betriebsdokumentation" muss für das Rust-Projekt neu erstellt werden; die im README genannten Trade-offs und Betriebsmuster (Five-Backend-Stack, Nightly-Consolidation) sind fachliche Anforderungen an die Neuentwicklung.

---

## benchmark.py

- Zweck: Benchmark-Harness: repliziert das skriptete Gespräch aus data/script.json gegen jedes (oder ausgewählte) Backend und misst Recall-Genauigkeit, durchschnittliche Kontext-Token pro Probe und durchschnittliche Wanduhr-Latenz pro repliziertem Turn (belegt durch benchmark.py, Modul-Docstring und Funktion run_backend).
- Verantwortlichkeit: Führt den Vergleich der fünf Backends unter identischen Bedingungen durch, erzeugt eine Tabelle, eine Analyse und optional eine JSON-Detaildatei.
- Eingaben: Skript-Datei (Standard data/script.json, Format mit `script`-Array aus turn-/probe-Einträgen); CLI-Parameter `--script`, `--only`, `--store`, `--json`; Umgebungsvariable `NVIDIA_API_KEY`.
- Ausgaben: Konsolen-Tabelle (backend, accuracy, probes, ctx_tok, turn_s), Analyse-Block, optional JSON-Datei mit Detailergebnissen je Probe (question, expected, reply, hit).
- Datenfluss: Skript wird geladen → je Backend wird eine frische Instanz erzeugt und geleert → Turns werden via remember zugeführt (Latenz je Turn gemessen), Probes werden via recall + NIM-Chat beantwortet (Kontext-Token je Probe gemessen) → Treffer werden per Substring-Matching gegen die Erwartungsliste gewertet → Ergebnisse aggregiert (benchmark.py, Funktionen load_script, run_backend, answer_probe).
- Persistenz: Schreibt optionale JSON-Ausgabedatei; Backend-Stores entstehen unter dem Store-Verzeichnis (Standard results/bench/<backend>), das von .gitignore abgedeckt ist.
- Zustände: Backend-Instanzen werden pro Lauf erzeugt und sofort geleert (wipe vor Replay); Zähler für correct/probes/ctx_tokens/turn_times während des Replays; Ergebnis-Dictionaries je Backend.
- APIs: Kommandozeile (argparse); verwendet die Backend-Schnittstelle (remember/recall/wipe), die Token-Schätzung approx_tokens und die NIM-Chat-Funktion mit temperature=0.0 und max_tokens=120 bei Probes.
- Ereignisse: Pro-Turn- und Pro-Probe-Ereignisse innerhalb des Replays; keine externen Events.
- Nebenwirkungen: Erzeugt/generiert Store-Verzeichnisse und Dateien der persistenten Backends; verbraucht NIM-Credits (Chat-Calls je Probe, Embedding-/LLM-Calls je Turn bei persistenten Backends).
- Fehlerfälle: Fehlende Skriptdatei führt zu Dateifehler; fehlender API-Key bricht über src/nim.py (require_key) ab; nicht-diskriminierende Substring-Wertung kann falsch-positive Treffer erzeugen (belegt durch die hit-Berechnung als Substring-Prüfung der kleingeschriebenen Antwort gegen die Erwartung).
- Sicherheitsrelevanz: Keine besondere; verarbeitet keine Nutzereingaben, verwendet den API-Key aus der Umgebung.
- Geschäftslogik: Wertet "erinnert das Backend früh gepflanzte Fakten spät noch?"; das Window-Backend erhält ein bewusst kleines Budget (Konstante WINDOW_BUDGET = 250), damit frühe Fakten den Rahmen verlassen; die Analyse gibt feste Erwartungen aus (z.B. facts löst Kontradiktion, window verliert frühe Fakten), die an die laufenden Zahlen gekoppelt sind.
- Algorithmen: Recall-Wertung per Erwartungs-Substring-Matching über kleingeschriebene Antworten; Durchschnittsbildung über Kontext-Token und Turn-Latenzen; Sortierung nach Accuracy für die Analyse.
- verwendete Datenmodelle: Ergebnis-Dictionary mit backend, accuracy, correct, probes, avg_ctx_tokens, avg_turn_latency, details (Liste aus question/expected/reply/hit).
- Abhängigkeiten: json, os, time, argparse; src.memory (make_backend, BACKEND_NAMES, Turn), src.memory.window (approx_tokens), src.nim (chat); NIM-Endpoint; data/script.json.
- Rust-Relevanz: Die Capability "Benchmark-Harness mit skriptetem Replay, Recall-Wertung und Metrik-Aggregation" muss in Rust als Integrationstest/Benchmark-Suite (criterion oder Test-Harness) entstehen; die Proben-Wertung und die Metrik-Berechnung sind dort reproduzierbar nachzubilden.

---

## data/script.json

- Zweck: Benchmark-Fixture: ein 40-Turn-Onboarding-Gespräch mit 10 früh gepflanzten Fakten, einer Smalltalk-Strecke, einer Faktenänderung (Auto) und 8 späten Probes; inklusive Beschreibungstext (belegt durch data/script.json).
- Verantwortlichkeit: Liefert das identische Gesprächsmaterial für alle Backend-Läufe und definiert die Erwartungswerte, an denen Recall gemessen wird.
- Eingaben: Keine (statische Datendatei).
- Ausgaben: Keine direkt; wird von benchmark.py (Funktion load_script) konsumiert.
- Datenfluss: benchmark.py lädt das JSON, liest das Feld `script` und iteriert die Einträge; `turn`-Einträge gehen an remember, `probe`-Einträge an answer_probe.
- Persistenz: Datei ist committet (explizit von .gitignore ausgenommen).
- Zustände: Nicht nachweisbar (statische Daten).
- APIs: Keine; dokumentiertes Format: Top-Level-Objekt mit `description` und `script`-Array; Turn-Einträge mit kind/role/content; Probe-Einträge mit kind/question/expect (Array von akzeptierten Substrings).
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Nicht nachweisbar; Formatfehler würden beim JSON-Laden in benchmark.py scheitern.
- Sicherheitsrelevanz: Enthält synthetische Personendaten (Name, Allergie, Arbeitsort, Familienmitglied); keine echten Geheimnisse.
- Geschäftslogik: Kodiert das Testdesign: Fakten früh pflanzen, sie durch Smalltalk verdrängen, eine Tatsache aktualisieren (blauer Mazda → rotes Tesla), dann gezielt nach frühen Fakten fragen, inklusive der Kontradiktions-Probe (Auto) und einer faktenübergreifenden Probe (Schwester als Kardiologin).
- Algorithmen: Keine (Datendatei).
- verwendete Datenmodelle: JSON-Objekt mit script-Array; zwei Eintragsarten (turn/probe) mit rollenspezifischen Feldern.
- Abhängigkeiten: Keine.
- Rust-Relevanz: Das Fixture-Format (bzw. ein äquivalentes serde-Schema mit kind/role/content/question/expect) muss als Testdatenmodell der Rust-Benchmark-Suite fortbestehen; die Proben-Inhalte dienen als invariante Testfälle.

---

## demo_chat.py

- Zweck: Interaktives CLI-Chat-Programm, das mit einem oder mehreren Memory-Backends spricht und In-Chat-Kommandos bietet (belegt durch demo_chat.py, Modul-Docstring).
- Verantwortlichkeit: Bedienoberfläche: Backend-Auswahl per `--memory` (ein Backend, Komma-Liste oder "all"), Store-Verzeichnis per `--store`; Aufbau des MEMORY-Kontexts aus Recall-Snippets; Absetzen der NIM-Chat-Antwort; Speichern des Turns in allen Backends; Verarbeitung der Kommandos /inspect, /stats, /wipe, /quit.
- Eingaben: Konsoleneingaben (input), CLI-Parameter `--memory` (Standard "window"), `--store` (Standard "data"); System-Prompt-Konstante SYSTEM mit Verhaltensregel ("If the memory does not contain the answer, say you don't know instead of guessing").
- Ausgaben: Chat-Antworten (bot>), Backend-Inspektionen und Statistiken auf stdout, Wipe-Bestätigung.
- Datenfluss: Eingabe → ggf. Kommando → build_context (recall aller Backends mit k=6) → respond (System+Memory+User an chat) → Antwort ausgeben → remember(user-Turn) + remember(assistant-Turn) für jedes Backend (belegt durch demo_chat.py, Funktionen build_context und respond).
- Persistenz: Keine eigene; delegiert an die persistenten Backends (episodic/facts/graph) über deren remember-Aufrufe.
- Zustände: Laufender Turn-Index (erhöht sich pro Austausch um 2), Backend-Instanzen; Abbruch bei EOFError/KeyboardInterrupt oder /quit.
- APIs: CLI (argparse); nutzt src.memory.make_backend, src.memory.base.Turn und src.nim.chat.
- Ereignisse: Keine externen Events.
- Nebenwirkungen: Schreibt über die persistenten Backends auf Disk; verbraucht NIM-Credits pro Austausch (Chat-Call und je Backend ggf. Embedding-/Extraktions-Calls).
- Fehlerfälle: EOF/Strg-C beenden die Schleife sauber; leere Eingaben werden übersprungen; fehlender API-Key bricht über src/nim.py ab; unbekannte Backend-Namen führen zu einem Fehler aus make_backend.
- Sicherheitsrelevanz: Keine besondere; verarbeitet beliebigen Nutzertext, der ungefiltert an das LLM und die Backends geht.
- Geschäftslogik: Implementiert das Agenten-Muster "Kontext aus Gedächtnis anreichern, Antwort erzeugen, Verlauf zurück in Gedächtnis schreiben"; die System-Prompt-Regel verlangt explizites "weiß nicht" statt Raten.
- Algorithmen: Keine über die Backend-Recalls hinaus; k=6 für alle Recalls fest verdrahtet.
- verwendete Datenmodelle: Turn-Dataclass (role, content, index); Kontext als verkettete Backend-Blöcke im MEMORY-Abschnitt.
- Abhängigkeiten: argparse; src.memory, src.memory.base, src.nim; NIM-Endpoint.
- Rust-Relevanz: Die Capability "interaktive CLI-REPL mit Memory-Anreicherung und Kommandos" muss in Rust als interaktiver Binär (clap + stdin-Leseschleife mit async NIM-Client) entstehen; das Verhalten "nicht raten, wenn Memory die Antwort nicht enthält" ist eine System-Prompt-Regel.

---

## requirements.txt

- Zweck: Deklariert die Laufzeit-Paketabhängigkeiten mit Mindestversionen (belegt durch requirements.txt).
- Verantwortlichkeit: Stellt die Installation der Abhängigkeiten für die Nutzung des Repos sicher.
- Eingaben: Keine.
- Ausgaben: Keine.
- Datenfluss: Keine.
- Persistenz: Keine.
- Zustände: Nicht nachweisbar.
- APIs: Keine; deklariert Module: openai (>=1.30.0), python-dotenv (>=1.0.0), numpy (>=1.26.0), networkx (>=3.2).
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Nicht nachweisbar.
- Sicherheitsrelevanz: Keine; die Abhängigkeiten werden von den jeweiligen Paketquellen bezogen.
- Geschäftslogik: Keine.
- Algorithmen: Keine.
- verwendete Datenmodelle: Zeilenformat mit Paketname und Versionsbedingung.
- Abhängigkeiten: pip/Python-Ökosystem.
- Rust-Relevanz: Die Capability "deklarierte Abhängigkeitsverwaltung" wird in Rust durch Cargo.toml mit entsprechenden Crates abgebildet (reqwest, serde, dotenvy, ndarray, rusqlite, petgraph u.a., siehe rust-foundation.md).

---

## src/__init__.py

- Zweck: Kennzeichnet `src` als Python-Paket und trägt die Paketversion (belegt durch src/__init__.py).
- Verantwortlichkeit: Versionsdefinition (`__version__ = "0.1.0"`) und Paket-Metadaten.
- Eingaben: Keine.
- Ausgaben: Keine.
- Datenfluss: Keine.
- Persistenz: Keine.
- Zustände: Nicht nachweisbar.
- APIs: Attribut `__version__`.
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Nicht nachweisbar.
- Sicherheitsrelevanz: Keine.
- Geschäftslogik: Keine.
- Algorithmen: Keine.
- verwendete Datenmodelle: Keine.
- Abhängigkeiten: Keine.
- Rust-Relevanz: Die Capability "Paketkennzeichnung mit Version" entspricht in Rust dem `version`-Feld in Cargo.toml; kein Codeübernahmebedarf.

---

## src/nim.py

- Zweck: Dünner OpenAI-kompatibler Client für NVIDIA NIM; zentraler Zugangspunkt für alle LLM- und Embedding-Calls der Backends (belegt durch src/nim.py, Modul-Docstring und Funktionen chat/embed).
- Verantwortlichkeit: Schlüsselverwaltung (Umgebung/.env), Client-Konstruktion (einmalig, gecacht), Chat-Completions und Embeddings gegen den NIM-Endpoint; freundliche Abbruchmeldung bei fehlendem Key.
- Eingaben: Nachrichtenliste (role/content) für chat; Text oder Textliste plus input_type für embed; optionale Modell-Override; Umgebungsvariablen `NVIDIA_API_KEY`, `NIM_MODEL`.
- Ausgaben: Assistenten-Text aus chat; Embedding-Vektoren (Liste von Float-Listen) aus embed.
- Datenfluss: load_dotenv beim Modulimport → require_key validiert → get_client (lru_cache) erzeugt OpenAI-Client mit BASE_URL https://integrate.api.nvidia.com/v1 → chat bzw. embed ruft die OpenAI-SDK-Komplettions-/Embeddings-Endpunkte.
- Persistenz: Keine.
- Zustände: Modulkonstanten (BASE_URL, DEFAULT_MODEL "meta/llama-3.3-70b-instruct", EMBED_MODEL "nvidia/nv-embedqa-e5-v5"); gecachter Client (maxsize=1); Abbruch-Zustand bei fehlendem/Platzhalter-Key.
- APIs: Funktionen require_key(), get_client(), chat(messages, model, temperature=0.2, max_tokens=1024), embed(texts, input_type="passage", model). Bei Embeddings werden die Zusatzparameter `input_type` und `truncate: "END"` im Request-Body mitgesendet.
- Ereignisse: Keine.
- Nebenwirkungen: Netzwerk-Calls an NVIDIA NIM; API-Key aus der Umgebung wird an den Client übergeben; Prozessabbruch (sys.exit(1)) bei fehlendem Key.
- Fehlerfälle: Fehlender oder mit `nvapi-XXXX` beginnender Key → Abbruch mit Anleitung auf stderr; leere Antworten werden als leere Strings normalisiert; HTTP-/Netzwerkfehler des SDK werden nicht gesondert behandelt (kein Retry-Code vorhanden).
- Sicherheitsrelevanz: Key-Handling über Umgebung statt Quellcode; Abbruch bei Platzhaltern; keine Key-Logging-Stellen vorhanden.
- Geschäftslogik: Modellwahl-Hierarchie (Parameter > NIM_MODEL > DEFAULT_MODEL); input_type-Disziplin ("passage" für gespeicherte Dokumente, "query" für Suchanfragen), die die Retrieval-Qualität verbessert (belegt durch den Docstring der Funktion embed).
- Algorithmen: Keine (Client-Weiterleitung); einheitliche Normalisierung der Antwort.
- verwendete Datenmodelle: OpenAI-kompatible Nachrichten (role/content), Chat-Completion-Antwort (choices[0].message.content), Embedding-Antwort (data-Liste mit embedding).
- Abhängigkeiten: openai, python-dotenv, os, sys, functools.
- Rust-Relevanz: Die Capability "OpenAI-kompatibler HTTP-Client für Chat und Embeddings mit Konfiguration und Key-Validierung" muss in Rust mit reqwest + serde entstehen; die input_type/truncate-Parameter, Modell-Konstanten und die Abbruchlogik sind fachliche Vorgaben (Details in nim.md).

---

## src/extract.py

- Zweck: LLM-basierte Triple-Extraktion: wandelt eine natürlichsprachliche Nachricht in (Subjekt, Prädikat, Objekt)-Tripel um; gemeinsame Grundlage für facts-, graph-Backend und Konsolidierung (belegt durch src/extract.py, Modul-Docstring).
- Verantwortlichkeit: Stellt die extraktive Geschäftslogik bereit: Prompt-Konstruktion, Chat-Aufruf mit deterministischen Einstellungen, defensives Parsen der LLM-Antwort, Validierung und Normalisierung der Tripel.
- Eingaben: Nachrichtentext, optionaler Sprechername (Standard "user"), optionales Modell.
- Ausgaben: Liste von Tripeln (subject, predicate, object); leere Liste bei nichts Extraktionswürdigem.
- Datenfluss: Prompt (TRIPLE_PROMPT) wird mit Sprecher und Text gefüllt → chat (temperature=0.0, max_tokens=400) → _parse_array extrahiert das erste JSON-Array aus Antworten mit Code-Fences oder Prosa → Filterung auf nicht-leere, getrimmte Werte mit kleingeschriebenem Prädikat.
- Persistenz: Keine.
- Zustände: Keine (stateless).
- APIs: extract_triples(text, speaker, model); interne _parse_array.
- Ereignisse: Keine.
- Nebenwirkungen: NIM-Chat-Call pro Aufruf; verbraucht Credits.
- Fehlerfälle: Nicht-JSON-Antworten oder nicht-Array-Parsing führen zu leeren Ergebnissen (defensive Rückgabe); ungültige Einträge (kein Dict, leere Felder) werden übersprungen; fehlender Key bricht über src/nim.py ab.
- Sicherheitsrelevanz: LLM-Ausgabe wird strukturell validiert, aber inhaltlich ungefiltert übernommen; Prompt-Injection über Nutzertext ist möglich (kein Guard-Code vorhanden).
- Geschäftslogik: Extraktionsregeln laut Prompt: nur stabile Fakten (Identitäten, Beziehungen, Rollen, Orte, Daten, Präferenzen, Besitz, Entscheidungen), Sprecher-Auflösung auf bekannten Namen, kurze Subjekte/Objekte, kleingeschriebene Prädikate, keine Fragen/Smalltalk/Meinungen, JSON-Array-Format, leeres Array wenn nichts zu speichern ist.
- Algorithmen: Regex-basierte Extraktion des ersten JSON-Arrays (Code-Fence-Erkennung, erstes '[' bis letztes ']'), JSON-Parsing mit Rückfall auf leere Liste.
- verwendete Datenmodelle: Tripel (3-Tupel aus Strings); LLM-JSON-Objekt mit Schlüsseln subject/predicate/object.
- Abhängigkeiten: json, re; src.nim.chat; NIM-Endpoint.
- Rust-Relevanz: Die Capability "LLM-gestützte strukturierte Extraktion mit defensivem Parsen von Modellausgaben" muss in Rust als eigenständiger Extractions-Service (serde_json-basierter Parser mit Fence-/Prosa-Toleranz) entstehen; die Extraktionsregeln sind als Prompt-Konstante fachliche Vorgabe.

---

## src/util.py

- Zweck: Kleine gemeinsame Helfer für alle Backends: Namensnormalisierung und Keyword-Extraktion (belegt durch src/util.py).
- Verantwortlichkeit: Liefert kanonische Entity-Schlüssel für Merging und Inhaltsterme für den Keyword-Recall.
- Eingaben: Namen bzw. Text für normalize_name/keywords.
- Ausgaben: Normalisierte Namensstrings bzw. Listen von Content-Wörtern.
- Datenfluss: normalize_name wird von facts (upsert) und graph (_add_entity, _blob) genutzt; keywords von facts (recall) und graph (_seeds).
- Persistenz: Keine.
- Zustände: Modulkonstante STOPWORDS (konservative englische Stoppwortliste).
- APIs: normalize_name(name), keywords(text, min_len=3).
- Ereignisse: Keine.
- Nebenwirkungen: Keine.
- Fehlerfälle: Leere Werte werden durch `(name or "")`-Handling zu leerem Ergebnis normalisiert.
- Sicherheitsrelevanz: Keine.
- Geschäftslogik: Namensvereinheitlichung als Basis für Entity-Supersession und Graph-Merging ("Bogota warehouse" ≡ "the Bogota warehouse"); Keyword-Extraktion für den Recall-Matching.
- Algorithmen: Whitespace-Kollapsierung + Lowercase für Namen; Regex-Wortextraktion, Längenfilter (>= min_len), Stoppwort-Filter, Deduplizierung unter Erhalt der Reihenfolge.
- verwendete Datenmodelle: Strings und String-Listen; Stoppwort-Set.
- Abhängigkeiten: re; Standardbibliothek.
- Rust-Relevanz: Die Capability "kanonische Normalisierung und Keyword-Extraktion" muss in Rust als Utility-Modul entstehen (z.B. regex-Crate, HashSet-Stoppwörter, Unicode-bewusste Wortmuster).

---

## src/consolidate.py

- Zweck: Offline-Konsolidierung ("sleep"): bereinigt episodisches Gedächtnis durch Deduplikation, Beförderung wiederkehrender Episoden zu dauerhaften Fakten und Entfernung unwichtiger Episoden (belegt durch src/consolidate.py, Modul-Docstring und Funktion consolidate).
- Verantwortlichkeit: Orchestriert den Konsolidierungslauf über episodischen und Fakten-Store eines Verzeichnisses; verwaltet den Importance-Cache; erzeugt einen JSON-Bericht.
- Eingaben: Store-Verzeichnis (`--store`), Schwellwerte `--dedupe-threshold` (0.93), `--prune-threshold` (0.35), `--repeat-promote` (3), `--dry-run`; LLM-Calls für Importance-Scoring und Triple-Extraktion.
- Ausgaben: Konsolidierungsbericht (JSON) mit start_episodes, promoted_triples, deduped, pruned, end_episodes, dry_run.
- Datenfluss: EpisodicMemory und FactMemory aus dem Store laden → 1) Promotion: Kosinus-Cluster-Größe je Episode >= repeat_promote → extract_triples → facts.upsert → 2) Dedupe: paarweise Kosinus-Similaritätsmatrix >= Threshold → spätere Duplikate droppen → 3) Prune: Importance-Scores (LLM, 20er-Batches, gecacht per SHA1-Inhaltshash) < prune_threshold → drop → Cache speichern → Bericht.
- Persistenz: Liest/schreibt episodic.npz/jsonl (via EpisodicMemory), facts.db (via FactMemory), importance_cache.json (via _load_cache/_save_cache).
- Zustände: dry_run beeinflusst, ob Mutationen (drop/upsert/Cache-Speichern) ausgeführt werden; Berichts-Dictionary; Cache-Dictionary.
- APIs: CLI (argparse); Funktionen dedupe(ep, threshold), score_importance(texts, cache), consolidate(store, ...), main; interne _hash, _load_cache, _save_cache, _parse_scores.
- Ereignisse: Keine externen Events.
- Nebenwirkungen: Schreibt veränderte Stores und Cache (nicht bei dry_run); verbraucht NIM-Credits (Importance-Scoring je Batch, Extraktion je zu befördernder Episode).
- Fehlerfälle: Fehlende Stores werden mit leerem Zustand behandelt (EpisodicMemory ohne Dateien → leere Listen, ohne Vektoren → dedupe/promote überspringen); LLM-Score-Antworten mit fehlerhaften Zahlen werden auf 0.5 zurückgesetzt bzw. ergänzt (Clamping auf [0,1]).
- Sicherheitsrelevanz: Keine besondere; verarbeitet gespeicherte Gesprächsinhalte.
- Geschäftslogik: Implementiert das Sleep-Modell: Deduplizierung (Kosinus >= 0.93), Promotion (Cluster-Größe >= 3 → Fakten), Prune (Importance < 0.35), einmaliges LLM-Scoring mit Cache nach Inhaltshash für billige Wiederholungsläufe.
- Algorithmen: SHA1-Inhaltshash; Kosinus-Similarität als Matrizenprodukt normalisierter Vektoren; Cluster-Größenbestimmung über Schwellwert-Zählung je Zeile; paarweises Greedy-Dedupe (frühere Episode gewinnt); Regex-Zahlenextraktion mit Clamping für Scores.
- verwendete Datenmodelle: Episoden (texts/metas/vecs, siehe EpisodicMemory), Fakten (siehe FactMemory), Cache (JSON: Hash → Score), Bericht (Dictionary).
- Abhängigkeiten: hashlib, json, os, re, argparse; src.extract, src.memory.episodic, src.memory.facts; NIM-Endpoint.
- Rust-Relevanz: Die Capability "Offline-Konsolidierungspipeline mit Dedupe/Promote/Prune, LLM-Importance-Scoring und persistentem Score-Cache" muss in Rust als eigenständiger Batch-Service (CLI oder Scheduler-Job) entstehen; Vektor-Mathematik mit ndarray, Cache als JSON-Datei, Bericht als serde-Struktur.

---

## src/memory/__init__.py

- Zweck: Bündelt die Backends, definiert die registrierten Backend-Namen und stellt die Factory make_backend bereit (belegt durch src/memory/__init__.py).
- Verantwortlichkeit: Verdrahtet Backend-Namen mit konkreten Implementierungen und leitet Speicherpfade aus einem Store-Verzeichnis ab; erstellt das Verzeichnis bei Bedarf.
- Eingaben: Backend-Name, Store-Verzeichnis (Standard "data"), optionales Modell, optionale Konstruktor-Kwargs (z.B. token_budget, keep_last).
- Ausgaben: Instanz des gewünschten Backend-Typs.
- Datenfluss: Namensauflösung → Konstruktion mit abgeleiteten Pfaden (episodic → <store>/episodic, facts → <store>/facts.db, graph → <store>/graph.graphml) oder ohne Persistenz (window, summary).
- Persistenz: Legt das Store-Verzeichnis an (mkdir, exist_ok); die Pfadableitung bestimmt, wo die persistenten Backends speichern.
- Zustände: Keine (stateless Factory); Konstante BACKEND_NAMES listet die fünf gültigen Namen.
- APIs: make_backend(name, store_dir, model, **kwargs); Exportliste __all__; BACKEND_NAMES.
- Ereignisse: Keine.
- Nebenwirkungen: Erzeugt Verzeichnisse auf Disk.
- Fehlerfälle: Unbekannter Backend-Name führt zu einem ValueError mit der Liste gültiger Namen.
- Sicherheitsrelevanz: Keine.
- Geschäftslogik: Default-Werte für Konstruktorparameter (window: token_budget=800, summary: keep_last=6); Registrierung exakt fünf Backends.
- Algorithmen: Keine.
- verwendete Datenmodelle: Keine.
- Abhängigkeiten: os; die fünf Backend-Module; base (MemoryBackend, Turn).
- Rust-Relevanz: Die Capability "registrierte Backend-Factory mit Pfadableitung und Konstruktionsparametern" muss in Rust als Factory/Registry entstehen (z.B. enum BackendKind + match-Konstruktion oder Trait-Objekt-Erzeugung); Default-Werte und Pfadableitung sind fachliche Vorgaben.

---

## src/memory/base.py

- Zweck: Definiert den gemeinsamen Vertrag aller Memory-Backends (ABC MemoryBackend) und das Turn-Datenmodell für eine einzelne Nachricht (belegt durch src/memory/base.py).
- Verantwortlichkeit: Abstraktion der Speicher- und Abruffähigkeiten: remember (Turn aufnehmen), recall (bis zu k Snippets zur Query), stats (Zustandsbeschreibung), wipe (alles löschen), inspect (menschenlesbarer Dump, Default über stats).
- Eingaben: Turn-Objekte (role, content, ts, index, meta) bzw. Query-Strings mit k.
- Ausgaben: None bei remember/wipe; String-Listen bei recall; Dictionary bei stats; String bei inspect.
- Datenfluss: Agentencode (demo_chat.py, benchmark.py) spricht ausschließlich diese Schnittstelle an; die Backends implementieren die Speicher- und Retrievaldetails.
- Persistenz: Keine im Vertrag selbst; abhängig von der Implementierung.
- Zustände: Turn trägt role, content, Zeitstempel (Default: Aufnahmezeitpunkt), optionalen Index und optionale Metadaten; die as_line-Methode serialisiert einen Turn zu einer Zeile für Kontext/Inspektion.
- APIs: MemoryBackend (remember, recall, stats, wipe, inspect), Turn (as_line); Turn ist eine Dataclass.
- Ereignisse: Keine.
- Nebenwirkungen: Keine im Vertrag; Implementierungen definieren ihre eigenen.
- Fehlerfälle: Nicht spezifiziert (abstrakt); konkrete Backends regeln eigene Fehlerfälle.
- Sicherheitsrelevanz: Keine im Vertrag.
- Geschäftslogik: Vertrag legt fest, dass recall Snippets "most useful for responding to query" zurückgibt (Docstring); k begrenzt die Menge.
- Algorithmen: Keine im Vertrag.
- verwendete Datenmodelle: Turn-Dataclass (role, content, ts, index, meta).
- Abhängigkeiten: abc, dataclasses, time, typing (Standardbibliothek).
- Rust-Relevanz: Die Capability "abstrakter Speichervertrag" muss in Rust als Trait entstehen (z.B. MemoryBackend mit remember/recall/stats/wipe/inspect); das Turn-Modell als struct mit serde; diese Trait-Definition ist die zentrale Abstraktion der Neuentwicklung.

---

## src/memory/window.py

- Zweck: Token-budgetierter Sliding-Window-Speicher: hält jüngste Turns wörtlich, evakuiert älteste Turns bei Überschreitung des Budgets; keine LLM-Calls, keine Persistenz (belegt durch src/memory/window.py, Modul-Docstring).
- Verantwortlichkeit: Liefert die "Working-Memory"-Ebene mit O(1) amortisiertem Aufwand pro Turn und eine tiktoken-freie Token-Schätzung (approx_tokens).
- Eingaben: Turn-Objekte via remember; Query via recall (wird ignoriert, da das Fenster nicht query-adressierbar ist).
- Ausgaben: recall liefert alle gehaltenen Turn-Zeilen (k wird ignoriert); stats liefert Zähler und Token-Schätzung; inspect liefert formatierten Dump.
- Datenfluss: remember hängt Turn an und evakuiert; recall gibt den gesamten aktuellen Fensterinhalt zurück; keine Persistenz.
- Persistenz: Keine (In-Memory; wipe leert die Liste).
- Zustände: Liste gehaltener Turns; Zähler evictierter Turns; Token-Budget als Konstruktionsparameter (Default 800).
- APIs: approx_tokens(text) als Modul-Funktion; WindowMemory mit remember/recall/stats/wipe/inspect.
- Ereignisse: Keine.
- Nebenwirkungen: Keine externen (keine API-Calls).
- Fehlerfälle: Nicht nachweisbar; bei leerem Fenster liefert recall eine leere Liste.
- Sicherheitsrelevanz: Keine.
- Geschäftslogik: Eviction-Regel: solange mehr als ein Turn gehalten wird und die Token-Schätzung das Budget übersteigt, wird der älteste Turn entfernt und der Evictions-Zähler erhöht.
- Algorithmen: Token-Schätzung als Mischung aus Zeichen-Heuristik (~4 Zeichen/Token) und Wort-Heuristik (~1.33 Token/Wort), gemittelt und gerundet (laut Docstring innerhalb ~15% eines BPE-Tokenizers); Eviction als Schleife über den Fensteranfang.
- verwendete Datenmodelle: Turn-Liste; as_line-Serialisierung.
- Abhängigkeiten: base (MemoryBackend, Turn).
- Rust-Relevanz: Die Capability "token-budgetierter Ring-/Sliding-Buffer ohne externe Abhängigkeiten" muss in Rust als VecDeque-basierter Speicher entstehen; die Token-Schätzung ist eine eigenständige Funktion; keine async-Komponenten nötig.

---

## src/memory/summary.py

- Zweck: Rolling-Summary-Speicher: hält die letzten N Turns wörtlich, komprimiert ältere Turns per LLM-Call in eine laufende Zusammenfassung; konstanter Speicherfußabdruck (belegt durch src/memory/summary.py, Modul-Docstring).
- Verantwortlichkeit: Budgetfreundliche Langzeitgedächtnis-Option für lange Einzel-Chats: ein LLM-Call alle N Turns, verlustbehaftete Kompression mit expliziter Regel zur Erhaltung dauerhafter Fakten.
- Eingaben: Turn-Objekte via remember; Query via recall (wird ignoriert, nicht query-adressierbar); LLM-Chat für die Kompression.
- Ausgaben: recall liefert die laufende Zusammenfassung plus den wörtlichen Tail; stats liefert Pufferlänge, Kompressionszahl und Token-Schätzung der Zusammenfassung; inspect liefert Dump.
- Datenfluss: remember hängt Turn an; sobald der Puffer 2 * keep_last erreicht, werden die ältesten keep_last Turns per COMPRESSION_PROMPT + chat (temperature=0.1, max_tokens=400) in die Zusammenfassung gefaltet; kein Persistenzpfad.
- Persistenz: Keine (In-Memory; wipe setzt Puffer, Zusammenfassung und Zähler zurück).
- Zustände: wörtlicher Puffer recent; laufende Zusammenfassung summary; Kompressionszähler n_compressions.
- APIs: SummaryMemory mit remember/recall/stats/wipe/inspect; Modul-Konstante COMPRESSION_PROMPT.
- Ereignisse: Keine.
- Nebenwirkungen: NIM-Chat-Call pro Kompression; verbraucht Credits.
- Fehlerfälle: Nicht nachweisbar (Kompression ist reiner LLM-Aufruf; Fehler werden nicht gesondert behandelt).
- Sicherheitsrelevanz: Keine besondere; Zusammenfassung enthält ggf. personenbezogene Fakten aus dem Gespräch.
- Geschäftslogik: Kompressionsregeln laut Prompt: alle dauerhaften Fakten über Nutzer, Arbeit, Personen, Daten, Präferenzen, Entscheidungen erhalten; Smalltalk verwerfen; dritte Person, unter 180 Wörter; Verlust ist Design-Eigenschaft.
- Algorithmen: Keine über die Puffer-Trigger-Logik hinaus (Schwellwert 2 * keep_last).
- verwendete Datenmodelle: Turn-Liste recent; Zusammenfassungs-String.
- Abhängigkeiten: chat (src.nim), approx_tokens (window), base.
- Rust-Relevanz: Die Capability "LLM-gestützte rollierende Zusammenfassung mit wörtlichem Tail und Schwellwert-Trigger" muss in Rust als State-Machine-artiger Speicher entstehen (Puffer + Summary + Zähler); der Kompressions-Prompt ist eine fachliche Prompt-Konstante; async NIM-Call in remember.

---

## src/memory/episodic.py

- Zweck: Vektor-episodisches Gedächtnis: jeder Turn wird mit NVIDIA-Embeddings vektorisiert und zusammen mit Text und Metadaten gespeichert; Recall bewertet Kandidaten über eine Mischung aus Kosinus-Relevanz und exponentieller Aktualität (belegt durch src/memory/episodic.py, Modul-Docstring).
- Verantwortlichkeit: Fuzzy-Recall vergangener Gespräche ("worüber haben wir gesprochen?"), Persistenz als npz (Vektoren) + jsonl (Text/Metadaten), Unterstützung der Konsolidierung über drop.
- Eingaben: Turn-Objekte via remember (Embedding mit input_type="passage"); Query via recall (Embedding mit input_type="query"); Indizes via drop.
- Ausgaben: recall liefert bis zu k formatierte Snippet-Zeilen mit Relevanz-/Aktualitäts-Scores; stats liefert Episodenzahl, Dimension und Parameter; inspect liefert nummerierten Dump.
- Datenfluss: remember → Embedding → Normalisierung → Vektor an Matrix anhängen → Text/Metadaten anhängen → sofortige Persistenz (jsonl + npz); recall → Query-Embedding → Kosinus zur Matrix → Recency-Faktor → gewichtete Punktzahl → Top-k.
- Persistenz: Zwei Dateien unter einem Basis-Pfad (Standard data/episodic): `.npz` (Vektoren) und `.jsonl` (Text + Metadaten, ensure_ascii=False); _load beim Start, _save nach jeder Änderung; wipe löscht beide Dateien.
- Zustände: texts (Liste), metas (Liste), vecs (Optionale Matrix); Parameter half_life_turns (Default 40), relevance_weight (Default 0.7).
- APIs: remember/recall/stats/wipe/inspect; drop(indices) für die Konsolidierung; interne _load/_save/_normalize.
- Ereignisse: Keine.
- Nebenwirkungen: NIM-Embedding-Calls pro Turn und pro Query; Schreibt Dateien auf Disk nach jedem remember/drop.
- Fehlerfälle: Fehlende Dateien beim Laden → leerer Zustand; leeres Fenster → recall liefert leere Liste; Nullvektor wird unverändert übernommen (Division nur bei Norm > 0).
- Sicherheitsrelevanz: Gespeicherte Episoden enthalten Gesprächsinhalte unverschlüsselt auf Disk.
- Geschäftslogik: Score = relevance_weight * Kosinus + (1 - relevance_weight) * Recency; Recency halbiert sich alle half_life Turns seit der neuesten Episode (Ankunftsreihenfolge aus metas).
- Algorithmen: Vektor-Normalisierung (L2), Kosinus-Similarität als Skalarprodukt normalisierter Vektoren, exponentielle Recency-Halbwertzeit, argsort-Auswahl der Top-k.
- verwendete Datenmodelle: Episoden-Tripel (text, meta, vec); meta enthält role, ts, order (1-basierte Ankunftsreihenfolge).
- Abhängigkeiten: numpy, json, os; embed (src.nim); base.
- Rust-Relevanz: Die Capability "Vektor-Episodenspeicher mit gewichteter Relevanz-/Aktualitätsbewertung und Dual-Datei-Persistenz" muss in Rust entstehen: Matrix als ndarray, Kosinus via dot, Persistenz als Binär-/JSON-Format (z.B. bincode + serde_json), Embedding-Call async über den NIM-Client.

---

## src/memory/facts.py

- Zweck: Strukturiertes semantisches Gedächtnis auf SQLite: jeder Turn wird per LLM in Tripel zerlegt; eine neue Tatsache zum gleichen Subjekt+Prädikat verdrängt die aktive alte (Supersession), die alte Zeile bleibt mit active=0 und superseded_by erhalten (belegt durch src/memory/facts.py, Modul-Docstring).
- Verantwortlichkeit: Beantwortet "was ist aktuell wahr" deterministisch, kostengünstig und auditierbar; Keyword+LIKE-Recall über aktive Fakten; Kontradiktionsbehandlung.
- Eingaben: Turn-Objekte via remember (LLM-Triple-Extraktion mit Sprecher-Zuordnung); Query via recall; Tripel via upsert (auch von der Konsolidierung genutzt).
- Ausgaben: recall liefert bis zu k Fakten-Zeilen (subjekt prädikat objekt) nach Überlappungs- und Aktualitäts-Sortierung; stats liefert aktive/verdrängte Zähler und DB-Pfad; inspect liefert aktiv/superseded-Dump; wipe leert die Tabelle.
- Datenfluss: remember → extract_triples(mit speaker=user/assistant) → upsert je Tripel → SQLite-Transaktionen; recall → keyword-Extraktion → LIKE-Abfrage auf aktive Fakten → Überlappungs-Scoring.
- Persistenz: SQLite-Datenbank (Standard data/facts.db) mit Tabelle facts und Indizes (idx_active, idx_sp); _init_db legt Schema an.
- Zustände: SQLite-Verbindung (row_factory); Faktenzeilen mit Aktiv-Flag; Supersession-Verkettung über superseded_by.
- APIs: remember/recall/stats/wipe/inspect; upsert(subject, predicate, obj, source_turn); interne _init_db.
- Ereignisse: Keine.
- Nebenwirkungen: LLM-Extraktions-Call pro Turn; SQLite-Schreibtransaktionen; erzeugt die DB-Datei.
- Fehlerfälle: Identische aktive Tatsache (normalisierte Werte gleich) → kein Schreibvorgang; fehlende Keywords → recall liefert alle aktiven Fakten; SQLite-Fehler werden nicht gesondert behandelt.
- Sicherheitsrelevanz: DB enthält personenbezogene Fakten unverschlüsselt; keine Zugriffskontrolle.
- Geschäftslogik: Supersession-Regel: aktive Tatsache zu (subject_norm, predicate_norm) wird bei neuem Wert auf active=0 gesetzt und mit superseded_by auf die neue Zeile verlinkt; Audit-Historie bleibt vollständig; Recall sortiert nach Keyword-Überlappung (primär) und Zeitstempel (sekundär, neuer zuerst).
- Algorithmen: Namensnormalisierung als Merge-Schlüssel; Keyword-Überlappungszählung pro Fakten-Blob; LIKE-Wildcard-Matching über Subjekt/Prädikat/Objekt.
- verwendete Datenmodelle: SQLite-Tabelle facts (id, subject, predicate, object, subject_norm, predicate_norm, ts, source_turn, active, superseded_by).
- Abhängigkeiten: sqlite3, os, time; extract (extract_triples), util (keywords, normalize_name), base.
- Rust-Relevanz: Die Capability "SQLite-gestützter Fakten-Store mit Supersession und Keyword-Recall" muss in Rust mit rusqlite/sqlx entstehen: Schema als Migrations-DDL, Upsert-Logik in einer Transaktion, LIKE-Query mit parametrisierten Wildcards (Injection-sicher), Keyword-Extraktion aus util.

---

## src/memory/graph.py

- Zweck: Wissensgraph-Gedächtnis auf networkx: Turns werden in Tripel zerlegt und in einen gerichteten Multigraphen gefaltet; Entitäten werden über normalisierte Namen gemerged; Recall liefert den Ego-Graphen um die in der Query genannten Entitäten (belegt durch src/memory/graph.py, Modul-Docstring).
- Verantwortlichkeit: Beantwortet relationale/mehrstufige Fragen über lokale Nachbarschaften; GraphML-Serialisierung für externe Werkzeuge (Gephi/Cytoscape laut Docstring).
- Eingaben: Turn-Objekte via remember (LLM-Triple-Extraktion); Query via recall; nichts für wipe.
- Ausgaben: recall liefert bis zu k Kanten-Zeilen aus dem Ego-Graphen (label prädikat label, dedupliziert); stats liefert Entitäten-/Relationszahlen; inspect liefert Kanten-Dump.
- Datenfluss: remember → extract_triples → Entity-Knoten anlegen/mergen → Kante mit Prädikat als Kanten-Key und Zeitstempel hinzufügen → bei Änderung GraphML speichern; recall → Keywords → Blob-Matching je Knoten → Seeds → ungerichteter Ego-Graph (radius=1) → Kanten der Originalrichtungsmatrix filtern.
- Persistenz: GraphML-Datei (Standard data/graph.graphml); _load beim Start, _save bei jeder Änderung; wipe entfernt die Datei.
- Zustände: networkx MultiDiGraph inklusive Knoten-Labels und Kanten-Attributen (predicate, ts).
- APIs: remember/recall/stats/wipe/inspect; interne _load/_save/_add_entity/_blob/_seeds.
- Ereignisse: Keine.
- Nebenwirkungen: LLM-Extraktions-Call pro Turn; Schreibt GraphML nach jeder Änderung.
- Fehlerfälle: Leerer Graph → recall liefert leere Liste; keine Seed-Treffer → leere Liste; fehlende GraphML-Datei → leerer Graph.
- Sicherheitsrelevanz: Gespeicherte Tripel unverschlüsselt in GraphML.
- Geschäftslogik: Entity-Merging über normalize_name (Knoten-Key = normalisierter Name, Label = Original); Recall-Mehrstufenlogik: Keyword-Match gegen Knoten-Blob (Label + ein-/ausgehende Relationen), dann Ego-Graph-Expansion mit Radius, dann Kanten-Deduplizierung; keine eingebaute Supersession (laut README bewusst).
- Algorithmen: Ego-Graph-Konstruktion (networkx ego_graph auf ungerichteter Ansicht), Keyword-Substring-Matching gegen normalisierte Blobs, Kanten-Deduplizierung über gesetzte Zeilen.
- verwendete Datenmodelle: Gerichteter Multigraph: Knoten mit label, Kanten mit key=predicate und Attributen predicate/ts.
- Abhängigkeiten: networkx, os, time; extract (extract_triples), util (keywords, normalize_name), base.
- Rust-Relevanz: Die Capability "Graph-Gedächtnis mit Entity-Merging, Ego-Graph-Recall und GraphML-Persistenz" muss in Rust mit petgraph entstehen: MultiDiGraph-Typ, normalisierte Knoten-Keys, Ego-Graph über Nachbarschaftssuche, GraphML über ein Serialisierungs-Crate; Recall-Pipeline als reine Funktion testbar.
