# Testanalyse: agent-memory-systems

## Vorbefund

Das Repo enthält keine klassischen Testdateien (keine test_*.py, keine tests/-Verzeichnisse, kein Testframework in requirements.txt — belegt durch die Dateiliste und requirements.txt). Die einzige qualitätsmessende Komponente ist benchmark.py zusammen mit der Fixture data/script.json. Diese wird hier vollständig analysiert.

## benchmark.py + data/script.json als Testsystem

### Was wird getestet

- Es wird die Fähigkeit jedes der fünf Memory-Backends gemessen, früh gepflanzte Fakten über eine lange Konversation hinweg so zu behalten, dass ein LLM späte Fragen korrekt beantworten kann (belegt durch benchmark.py, Funktionen run_backend/answer_probe, und data/script.json, description).
- Konkret werden drei Metriken je Backend erzeugt: Recall-Accuracy (Anteil korrekt beantworteter Probes), durchschnittliche Kontext-Token je Probe, durchschnittliche Wanduhr-Latenz je repliziertem Turn (belegt durch run_backend, Rückgabestruktur).
- Das Testdesign deckt fünf Fähigkeiten ab:
  1. Fakten-Retention über Distanz (Fakten in den ersten 20 Turns, Probes spät).
  2. Verdrängung durch Smalltalk (Fakten müssen aus einem kleinen Window herausfallen).
  3. Kontradiktionsbehandlung (Auto-Wechsel: blauer Mazda → rotes Tesla, Probe erwartet Tesla/red).
  4. Mehrwort-/Substring-Toleranz der Wertung (Erwartungslisten mit Alternativen, z.B. "Bogota"/"Bogotá", "September 30"/"Sept 30").
  5. Kosten-/Latenzverhalten (Kontext-Token, Turn-Latenz).

### Welche Annahmen gelten

- Das LLM beantwortet die Probe korrekt, wenn der Recall-Kontext die richtige Information enthält (belegt durch PROBE_SYSTEM: Antwort ausschließlich aus MEMORY-Block; exakte Antwort "I don't know" bei fehlender Antwort).
- Die Substring-Prüfung ist ein hinreichendes Korrektheitskriterium (belegt durch die hit-Berechnung).
- Das Window-Backend soll absichtlich scheitern: das Budget (Konstante WINDOW_BUDGET = 250) ist bewusst klein gewählt, damit frühe Fakten das Fenster verlassen (belegt durch Kommentar im Code).
- Die Persistenz der Backends ist pro Lauf isoliert: jedes Backend bekommt ein eigenes Store-Unterverzeichnis und wird vor dem Replay geleert (wipe).
- Modelle sind nicht-deterministisch; Zahlen variieren von Lauf zu Lauf, Trends bleiben (belegt durch print_analysis und README-Hinweis).

### Welche Edge Cases existieren

- Backend ohne Probes: Division durch 0 bei der Accuracy wird durch bedingte Mittelung abgesichert (run_backend, "if probes else 0.0").
- Backend ohne Turns: Latenz-Mittelung bedingt (turn_times leer → 0).
- Backend ohne Recall-Treffer: Kontext wird zu "(empty)" und die Probe soll trotzdem mit "I don't know" beantwortet werden (answer_probe).
- Erwartungslisten mit mehreren akzeptierten Substrings (data/script.json: Bogota/Bogotá, Tesla/red, mehrere Datumsvarianten).
- Falsch-positive Wertung: Die Substring-Prüfung kann Treffer liefern, auch wenn das Backend den Kontext nicht lieferte, solange das LLM den Erwartungs-Substring aus eigenem Wissen nennt — nicht diskriminiert (belegt durch die hit-Logik; kein Negativkontroll-Pfad vorhanden).

### Welche Invarianten werden geprüft

- Explizit geprüfte Invarianten gibt es nicht (keine Assertions; das System ist eine Messung, kein Assertion-Test).
- Implizite Invarianten des Testaufbaus: Backends sind vor dem Replay leer (wipe); identisches Skript für alle Backends; je Backend eigene Stores.
- Die Analyse-Funktion prüft zwei erwartete Relationen zur Laufzeit: window-Accuracy < beste Accuracy → Meldung über Window-Schwäche; facts-Backend vorhanden → Meldung über Kontradiktionsstärke (print_analysis). Diese Meldungen sind an die Laufzahlen gekoppelt, keine harten Assertions.

### Welche Rust-Tests später entstehen müssen

1. Unit-Tests für reinen Kernlogik:
   - Token-Schätzung (approx_tokens) gegen Referenzwerte (leerer Text → 0, Budget-Verhalten).
   - Normalisierung (normalize_name) und Keyword-Extraktion (keywords): Stoppwort-Ausschluss, min_len, Deduplizierung, Unicode-Muster.
   - Defensives JSON-Parsing (Fences, Prosa, kaputtes JSON → leere Liste).
   - Recency-Formel und gewichteter Score des episodischen Recall (Kosinus + Recency, Top-k).
   - Supersession-Logik des Fakten-Stores: identischer Wert → kein Schreibvorgang; neuer Wert → alte Zeile aktiv=0 mit Verlinkung.
   - Ego-Graph-Recall: Seed-Auflösung, Radius-Expansion, Kanten-Deduplizierung.
   - Dedupe-/Promote-/Prune-Algorithmen der Konsolidierung inklusive Score-Parsing-Clamping.
2. Integrationstests mit Fake-LLM/Fake-Embedding (trait-basierter NIM-Client mockbar):
   - Backend-Contract-Tests: remember → recall liefert Snippets; stats; wipe.
   - Persistenz-Roundtrip: episodic (jsonl+npz-Äquivalent), facts (SQLite), graph (GraphML) — speichern, neu laden, Inhalt identisch.
   - Konsolidierungspipeline: dry_run verändert nichts; realer Lauf verändert Stores wie berichtet.
3. Fixture-basierte Replay-Tests: data/script.json als eingebettete Fixture; Replay ohne Netzwerk, indem der NIM-Client durch einen Stub ersetzt wird, der deterministische Antworten (Triples, Scores, Proben-Antworten) liefert.
4. Benchmark-Harness-Tests: Skript-Parsing, Metrik-Aggregation, JSON-Export, Substring-Hit-Wertung inklusive Edge Cases (leere Probes, leere Antworten, Groß-/Kleinschreibung).
5. Property-basierte Tests (z.B. proptest) für die Token-Schätzung (Monotonie bei Textverlängerung) und die Normalisierung (Idempotenz: normalize(normalize(x)) == normalize(x)).
6. Fuzz-artige Parser-Tests für _parse_array-Äquivalent: beliebige Bytefolgen dürfen nie panicken, sondern liefern leere Listen.

## Konsolidierungs- und Backend-invariante Annahmen (belegt)

- Konsolidierung misst Promotion vor Dedupe, damit Cluster-Größen nicht durch Entfernen schrumpfen (Kommentar in src/consolidate.py).
- Dry-run-Semantik: alle Berichtszähler werden auch im dry-run berechnet; Mutationen (drop/upsert/Cache-Speicherung) unterbleiben (src/consolidate.py, consolidate).
- Persistenz-Timing: episodic und graph speichern write-through nach jeder Mutation; facts committet je upsert (src/memory/episodic.py, graph.py, facts.py).

## Fehlende Testabdeckung (im Quellcode nachweisbar)

- Es gibt keine Tests für: fehlende/ungültige API-Keys, Netzwerkfehler, Zeitüberschreitungen, Rate Limits, leere/nichtige Turn-Inhalte über alle Backends, SQLite-Korruption, fehlende GraphML-Dateien mit defektem Inhalt, gleichzeitige Prozesse auf denselben Stores.
