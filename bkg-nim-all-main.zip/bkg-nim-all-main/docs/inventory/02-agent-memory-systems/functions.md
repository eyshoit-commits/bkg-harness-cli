# Funktionsanalyse: agent-memory-systems

Für jede relevante Funktion/Methode: Warum existiert sie, welches Problem löst sie, welche Regeln implementiert sie, welche Daten verändert sie, welche Zustände entstehen, welche Algorithmen, welche Fehler behandelt sie, welche Seiteneffekte. Beschreibung der Fähigkeit, nicht des Codes. Belege nennen Datei und Funktionsnamen.

---

## src/nim.py

### require_key()

- Warum: Stellt sicher, dass ein gültiger NIM-API-Key existiert, bevor Netzwerk-Calls erfolgen; verhindert kryptische SDK-Fehler.
- Problem: Fehlende Konfiguration soll verständlich erklärt werden statt mit Stacktrace zu scheitern.
- Regeln: Key muss gesetzt sein und darf nicht mit dem Platzhalter-Präfix beginnen; bei Verletzung Abbruch mit Anleitung (Free-Tier-Registrierung) auf stderr und Exit-Code 1.
- Daten: Liest die Umgebungsvariable; verändert keine Daten.
- Zustände: Prozessabbruch bei ungültigem Key.
- Algorithmen: Präfix-Prüfung.
- Fehler: Fehlender/Platzhalter-Key.
- Seiteneffekte: Ausgabe einer Setup-Anleitung; Prozessbeendigung.

### get_client()

- Warum: Erzeugt genau einen OpenAI-kompatiblen Client für den NIM-Endpoint und teilt ihn über alle Aufrufe.
- Problem: Vermeidet wiederholte Client-Initialisierung (Konfiguration, Key-Prüfung).
- Regeln: Client wird einmalig erzeugt (Cache-Größe 1); Basis-URL ist der NIM-Endpoint.
- Daten: Keine.
- Zustände: Gecachte Client-Instanz.
- Algorithmen: LRU-Cache mit Kapazität 1.
- Fehler: Delegiert die Key-Validierung an require_key.
- Seiteneffekte: Erste Nutzung triggert die Key-Prüfung.

### chat(messages, model, temperature, max_tokens)

- Warum: Zentraler Chat-Einstieg für alle Backends und Einstiegspunkte (demo_chat, benchmark, extract, summary, consolidate).
- Problem: Einheitlicher Chat-Completion-Aufruf mit Modellwahl und Temperatursteuerung.
- Regeln: Modellwahl-Hierarchie Parameter > Umgebungsvariable > Default-Modell; Defaults temperature=0.2, max_tokens=1024; Rückgabe des Assistenten-Texts, leere Antworten werden zu leerem String normalisiert.
- Daten: Sendet die übergebene Nachrichtenliste; verändert keine lokalen Daten.
- Zustände: Keine.
- Algorithmen: Keine (Client-Weiterleitung).
- Fehler: SDK-/Netzwerkfehler werden nicht gesondert behandelt.
- Seiteneffekte: Netzwerk-Call an NVIDIA NIM (Credit-Verbrauch).

### embed(texts, input_type, model)

- Warum: Einheitlicher Embedding-Einstieg für den episodischen Speicher.
- Problem: Korrekte input_type-Disziplin für NVIDIA-Retrieval-Modelle ("passage" für zu speichernde Dokumente, "query" für Suchanfragen) zur Retrieval-Qualität.
- Regeln: Einzeltext wird in eine Ein-Element-Liste gewandelt; Modell-Default ist das Embedding-Modell; Request trägt input_type und Truncation-Richtung.
- Daten: Sendet Texte; verändert keine lokalen Daten.
- Zustände: Keine.
- Algorithmen: Keine.
- Fehler: Nicht gesondert behandelt.
- Seiteneffekte: Netzwerk-Call (Credit-Verbrauch).

---

## src/extract.py

### extract_triples(text, speaker, model)

- Warum: Wandelt eine natürlichsprachliche Nachricht in speicherbare Fakten-Tripel um; gemeinsame Basis für facts-, graph-Backend und Konsolidierung.
- Problem: Unstrukturierten Gesprächstext in strukturierte (Subjekt, Prädikat, Objekt)-Tripel überführen, die deterministisch speicherbar sind.
- Regeln: Leerer Text ergibt leere Liste; Prompt verlangt nur stabile Fakten, Sprecher-Auflösung, kurze Subjekte/Objekte, kleingeschriebene Prädikate, JSON-Array-Antwort, leeres Array bei nichts Extraktionswürdigem; Chat mit temperature=0.0 und max_tokens=400.
- Daten: Keine lokalen Mutationen; erzeugt Tripel-Liste.
- Zustände: Keine (stateless).
- Algorithmen: Regex-basierte JSON-Array-Extraktion aus Fence-/Prosa-Antworten, JSON-Parsing mit Rückfall auf leere Liste, Filterung auf nicht-leere getrimmte Werte.
- Fehler: Nicht-JSON-Antworten und ungültige Einträge führen zu defensiv leeren bzw. gefilterten Ergebnissen.
- Seiteneffekte: NIM-Chat-Call pro Aufruf.

### _parse_array(raw)

- Warum: Interne Verteidigung gegen unzuverlässige LLM-Antwortformate.
- Problem: Modelle liefern JSON manchmal in Code-Fences oder mit Prosa drumherum.
- Regeln: Fences werden entfernt; das erste '[' bis zum letzten ']' wird extrahiert; Ergebnis muss eine Liste sein, sonst leere Liste.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Regex-Fence-Erkennung, Slice-Extraktion, JSON-Parsing.
- Fehler: JSONDecodeError wird zu leerer Liste.
- Seiteneffekte: Keine.

---

## src/util.py

### normalize_name(name)

- Warum: Erzeugt den kanonischen Schlüssel für Entity-/Subjekt-Merging über Backends hinweg.
- Problem: "Bogota warehouse" und "the Bogota warehouse" müssen als dieselbe Entität erkennbar sein (Supersession im facts-, Knoten-Merging im graph-Backend).
- Regeln: Leere Werte zu leerem String; Lowercase; Whitespace-Kollapsierung.
- Daten: Keine Mutationen.
- Zustände: Keine.
- Algorithmen: Regex-Whitespace-Ersetzung, strip, lower.
- Fehler: None/leere Eingabe → leerer String.
- Seiteneffekte: Keine.

### keywords(text, min_len)

- Warum: Liefert die inhaltsragenden Terme einer Query für den Keyword-Recall (facts, graph).
- Problem: Stoppwörter und kurze Wörter verrauschen das Matching.
- Regeln: Lowercase; Wörter ab min_len (Default 3); Stoppwort-Ausschluss über feste konservative englische Liste; Deduplizierung unter Erhalt der Reihenfolge.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Regex-Wortextraktion, Set-basierte Deduplizierung.
- Fehler: Keine speziellen (leerer Text → leere Liste).
- Seiteneffekte: Keine.

---

## src/consolidate.py

### dedupe(ep, threshold)

- Warum: Entfernt nahezu identische Episoden aus dem episodischen Speicher ("Schlaf"-Bereinigung).
- Problem: Wiederholte Gesprächsinhalte blähen den Vektor-Store auf und verlangsamen Retrieval.
- Regeln: Paarweise Kosinus-Similarität >= Schwellwert (Default 0.93); die frühere Episode gewinnt, spätere werden zum Verwerfen markiert; ohne Vektoren oder bei < 2 Episoden keine Aktion.
- Daten: Erzeugt Indizes zu entfernender Episoden; verändert selbst nichts.
- Zustände: Keine dauerhaften; Ergebnisliste von Drop-Indizes.
- Algorithmen: Similaritätsmatrix als Matrizenprodukt, Greedy-paarweiser Vergleich.
- Fehler: Leerer/1-Element-Zustand → leere Liste.
- Seiteneffekte: Keine (Drop wird vom Aufrufer ausgeführt).

### score_importance(texts, cache)

- Warum: Bewertet die Langzeit-Wichtigkeit jeder Episode für das Pruning.
- Problem: Welche Episoden sind unwichtig (Smalltalk) und dürfen verworfen werden? Einmaliges LLM-Scoring soll über Wiederholungsläufe gecacht werden.
- Regeln: Unbekannte Texte werden in Batches à 20 per LLM bewertet; Score-Skala 0.0–1.0; Cache-Schlüssel ist der SHA1-Inhaltshash; bekannte Hashes werden ohne LLM-Call übernommen; fehlende/ungültige Scores fallen auf 0.5 zurück, Clamping auf [0,1].
- Daten: Befüllt und liest den Cache; verändert keine Stores.
- Zustände: Cache-Wachstum über Läufe.
- Algorithmen: SHA1-Hashing, Batch-Komposition, Regex-Zahlenextraktion mit Clamping/Padding.
- Fehler: Ungültige LLM-Zahlen → 0.5; zu wenige Zahlen → Auffüllen mit 0.5.
- Seiteneffekte: NIM-Chat-Calls für unbekannte Texte; Cache-Mutation im Speicher (persistiert vom Aufrufer).

### consolidate(store, dedupe_threshold, prune_threshold, repeat_promote, dry_run)

- Warum: Orchestriert den vollständigen "Schlaf"-Lauf über den episodischen und Fakten-Store.
- Problem: Drei Reinigungsziele in der richtigen Reihenfolge: wiederkehrende Episoden zu Fakten befördern (vor Dedupe gemessen), Duplikate kollabieren, Unwichtiges prunen.
- Regeln: Promotion bei Cluster-Größe >= repeat_promote (Default 3); Dedupe bei Similarität >= dedupe_threshold; Prune bei Importance < prune_threshold; dry_run unterdrückt alle Mutationen und Cache-Persistenz; Bericht mit Zählern.
- Daten: Episodischer Store (drop), Fakten-Store (upsert), Importance-Cache (Datei).
- Zustände: Berichts-Dictionary als Laufprotokoll.
- Algorithmen: Kosinus-Cluster-Zählung je Zeile, Triple-Extraktion je zu befördernder Episode, Delegation an dedupe/score_importance.
- Fehler: Fehlende Stores → leerer Ausgangszustand; Vektorbedingung überspringt Promotion/Dedupe.
- Seiteneffekte: Disk-Schreibzugriffe auf alle drei Persistenzen (außer dry_run); NIM-Credits.

### _parse_scores(raw, n) / _hash / _load_cache / _save_cache

- Warum: Hilfsfähigkeiten des Konsolidierungslaufs.
- Problem: LLM-Score-Antworten robust in Zahlen überführen; Hashes erzeugen; Cache lesen/schreiben.
- Regeln: _parse_scores extrahiert Zahlen per Regex, clamp auf [0,1], füllt auf n auf (Default 0.5); _hash erzeugt SHA1-Hexdigest; _save_cache schreibt JSON mit Einrückung.
- Daten: Cache-Datei.
- Zustände: Cache im Speicher und auf Disk.
- Algorithmen: Regex, SHA1, JSON-Serialisierung.
- Fehler: Ungültige Zahlen → 0.5.
- Seiteneffekte: Datei-I/O beim Cache.

---

## src/memory/base.py

### Turn.as_line()

- Warum: Einheitliche Zeilenserialisierung eines Turns für Kontext-Build, Inspektion und Kompression.
- Problem: Rolle und Inhalt müssen überall im selben Format erscheinen.
- Regeln: Format "rolle: inhalt".
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Keine.
- Fehler: Keine.
- Seiteneffekte: Keine.

### MemoryBackend (Vertrag: remember, recall, stats, wipe, inspect)

- Warum: Gemeinsame Schnittstelle, damit Agentencode (demo_chat, benchmark) backendspezifisch unverändert bleibt.
- Problem: Fünf Architekturen hinter einer austauschbaren API (One-Word-Switch laut README).
- Regeln: remember nimmt Turn auf; recall liefert bis zu k zur Query relevante Snippets; stats liefert Zustandsdictionary; wipe löscht alles; inspect liefert menschenlesbaren Dump (Default aus stats).
- Daten: Keine eigenen; vertragliche Signatur für Implementierungen.
- Zustände: Implementierungsabhängig.
- Algorithmen: Keine (abstrakt).
- Fehler: Nicht spezifiziert.
- Seiteneffekte: Implementierungsabhängig.

---

## src/memory/window.py

### approx_tokens(text)

- Warum: Tiktoken-freie Token-Schätzung für Budgetierung ohne Abhängigkeiten/Modell-Downloads.
- Problem: Grobe Budgetkontrolle für das Fenster und Kontext-Messung im Benchmark.
- Regeln: Mischung aus Zeichen- (~4 Zeichen/Token) und Wortheurstik (~1.33 Token/Wort), gemittelt, gerundet, Minimum 1; leerer Text → 0; laut Docstring ~15% Genauigkeit gegenüber BPE.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Formel aus Zeichen-/Wortzählung.
- Fehler: Leerer Text → 0.
- Seiteneffekte: Keine.

### WindowMemory.remember / _evict / recall / stats / wipe / inspect

- Warum: Token-budgetiertes Sliding Window als einfachstes Backend und "Working-Memory"-Tier.
- Problem: Jüngste Konversation wörtlich behalten, älteste verdrängen, Budget nie überschreiten.
- Regeln: remember hängt Turn an und evakuiert; _evict entfernt den ältesten Turn solange Budget überschritten und mehr als ein Turn gehalten; recall ist nicht query-adressierbar (Fensterinhalt ist der Kontext; k ignoriert); wipe leert Liste und Zähler.
- Daten: Turn-Liste, Evictions-Zähler.
- Zustände: Fensterinhalt + Zähler.
- Algorithmen: Token-Summe, Vorne-Pop-Schleife.
- Fehler: Keine besonderen.
- Seiteneffekte: Keine API-Calls (billigstes Backend).

---

## src/memory/summary.py

### SummaryMemory.remember / _compress / recall / stats / wipe / inspect

- Warum: Rolling Summary für lange Einzel-Chats mit konstantem Fußabdruck.
- Problem: Ältere Turns sollen nicht wörtlich gehalten werden; Kompression darf dauerhafte Fakten nicht verlieren.
- Regeln: Puffer bis 2 * keep_last; danach werden die ältesten keep_last Turns per Prompt + chat (temperature=0.1, max_tokens=400) in die laufende Zusammenfassung gefaltet; Kompressions-Prompt verlangt Erhalt aller dauerhaften Fakten, Verwerfen von Smalltalk, dritte Person, unter 180 Wörter; recall liefert Zusammenfassung + wörtlichen Tail (nicht query-adressierbar).
- Daten: recent-Puffer, summary-String, Kompressionszähler.
- Zustände: Drei Zustandsattribute, die durch remember mutiert werden.
- Algorithmen: Schwellwert-Trigger.
- Fehler: Nicht gesondert behandelt.
- Seiteneffekte: NIM-Chat-Call je Kompression.

---

## src/memory/episodic.py

### EpisodicMemory.remember / recall / stats / wipe / inspect / drop

- Warum: Vektor-episodisches Gedächtnis mit Relevanz-Aktualitäts-Balance und Persistenz.
- Problem: Fuzzy-Recall ("worüber sprachen wir zu X") mit Blick auf beide Dimensionen: Ähnlichkeit und Neuheit.
- Regeln: remember embeddet mit input_type="passage", normalisiert L2, hängt Vektor/Text/Metadaten an und persistiert sofort; recall embeddet Query mit input_type="query", bewertet score = weight*cos + (1-weight)*recency (recency = 0.5^(Alter/half_life) mit Ankunftsordnung), liefert Top-k mit Score-Annotation; drop entfernt Positionen und persistiert (ohne Vektoren → None); wipe löscht Dateien.
- Daten: texts, metas, vecs.
- Zustände: Matrix und Listen; Parameter half_life_turns (40), relevance_weight (0.7).
- Algorithmen: L2-Normalisierung, Kosinus via Skalarprodukt, exponentielle Halbwertzeit, argsort-Top-k.
- Fehler: Leerer Store → leere Liste; Nullvektor-Idempotenz.
- Seiteneffekte: Embedding-Calls pro Turn/Query; Datei-I/O nach jeder Mutation.

### EpisodicMemory._load / _save

- Warum: Persistenz der Episoden über Prozessgrenzen.
- Problem: Neustart muss Erinnerungen behalten; zwei Formate für zwei Datentypen.
- Regeln: jsonl (Text+Meta, UTF-8, ein Datensatz pro Zeile), npz (Vektoren); Laden nur vorhandener Dateien; Speichern schreibt beide.
- Daten: Dateien.
- Zustände: In-Memory-Äquivalente.
- Algorithmen: JSON-Line-Serialisierung, npz-Binärformat.
- Fehler: Fehlende Datei → leerer Zustand.
- Seiteneffekte: Datei-I/O.

### EpisodicMemory._normalize

- Warum: L2-Normalisierung der Vektoren als Voraussetzung für Kosinus via Skalarprodukt.
- Problem: Embedding-Vektoren müssen auf Einheitslänge gebracht werden.
- Regeln: Division durch Norm, nur wenn Norm > 0.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: L2-Norm.
- Fehler: Nullvektor bleibt unverändert.
- Seiteneffekte: Keine.

---

## src/memory/facts.py

### FactMemory._init_db

- Warum: Stellt das Schema und die Indizes sicher.
- Problem: Tabellenstruktur und Zugriffspfade für aktive Fakten und Supersession müssen existieren.
- Regeln: Tabelle facts mit den Spalten id, subject, predicate, object, subject_norm, predicate_norm, ts, source_turn, active, superseded_by; Indizes auf active und (subject_norm, predicate_norm).
- Daten: SQLite-Schema.
- Zustände: DB-Verbindung mit row_factory.
- Algorithmen: DDL.
- Fehler: Nicht gesondert behandelt.
- Seiteneffekte: Erzeugt DB-Datei.

### FactMemory.upsert

- Warum: Kern der Kontradiktionsbehandlung: neue Tatsache verdrängt aktive alte.
- Problem: "Was ist aktuell wahr" statt "alles je Gesagte"; Historie muss auditierbar bleiben.
- Regeln: Normalisierter Merge-Schlüssel (subject_norm, predicate_norm); identischer normalisierter Objektwert → keine Aktion; sonst neue aktive Zeile, alte aktive Zeile wird auf active=0 gesetzt und per superseded_by verlinkt; source_turn wird übernommen.
- Daten: SQLite-Zeilen.
- Zustände: Aktiv/verdrängt-Status der Fakten.
- Algorithmen: Normalisierungsvergleich, transaktionale Update/Insert-Folge.
- Fehler: Keine besonderen.
- Seiteneffekte: DB-Commits.

### FactMemory.remember / recall / stats / wipe / inspect

- Warum: Turn-Aufnahme (Extraktion + upsert) und deterministischer Keyword-Recall.
- Problem: Strukturierte Antworten auf "was ist wahr?" bei minimalen Kosten.
- Regeln: remember setzt Sprecher (user/assistant) und extrahiert Tripel; recall nutzt keywords: bei Treffern LIKE-Query über aktive Fakten (Subjekt/Prädikat/Objekt je Keyword, OR-verknüpft), ohne Keywords alle aktiven Fakten; Sortierung nach Keyword-Überlappung (primär) und Zeitstempel (sekundär, neuer zuerst); wipe löscht alle Zeilen.
- Daten: SQLite.
- Zustände: Faktenbestand.
- Algorithmen: Keyword-Überlappungszählung pro Fakten-Blob, LIKE-Wildcards mit parametrisierten Werten.
- Fehler: Keine besonderen.
- Seiteneffekte: LLM-Extraktions-Calls in remember.

---

## src/memory/graph.py

### GraphMemory._add_entity / remember / _save

- Warum: Entitäten zusammenführen und Tripel als Kanten in den Multigraphen falten.
- Problem: "Bogota warehouse" und "the Bogota warehouse" sollen ein Knoten sein; wiederholte Tripel als parallele Kanten mit Prädikat-Key.
- Regeln: Knoten-Key = normalisierter Name, Label = Original; Kante mit key=Prädikat und Attributen predicate/ts; Speichern nur bei Änderung; GraphML-Read beim Start.
- Daten: MultiDiGraph.
- Zustände: Graph mit Knoten/Kanten.
- Algorithmen: Normalisierung, Multigraph-Kanten.
- Fehler: Fehlende GraphML-Datei → leerer Graph.
- Seiteneffekte: LLM-Extraktions-Call pro Turn; Datei-I/O bei Änderung.

### GraphMemory._blob / _seeds / recall

- Warum: Mehrstufiger Ego-Graph-Recall für relationale Fragen.
- Problem: Query nennt Entitäten/Relationen; Antwort liegt in der lokalen Nachbarschaft (Multi-Hop).
- Regeln: _blob baut einen durchsuchbaren Text aus Label plus ein-/ausgehenden Relationen; _seeds findet Knoten per Keyword-Substring-Matching; recall expandiert um jeden Seed den ungerichteten Ego-Graphen mit Radius (Default 1), sammelt Kanten mit Endpunkt in der Nachbarschaft, dedupliziert Zeilen, begrenzt auf k.
- Daten: Graph (nur lesend).
- Zustände: Keine.
- Algorithmen: Blob-Komposition, Keyword-Matching, Ego-Graph-Expansion, Set-Deduplizierung.
- Fehler: Leerer Graph oder keine Seeds → leere Liste.
- Seiteneffekte: Keine.

### GraphMemory.stats / wipe / inspect

- Warum: Zustandsauskunft und Reset.
- Problem: Anzahl Entitäten/Relationen anzeigen; Graph vollständig zurücksetzen.
- Regeln: stats zählt Knoten/Kanten und nennt Pfad; wipe ersetzt Graph durch leeren und entfernt die Datei; inspect listet Kanten mit Label und Prädikat.
- Daten: Graph.
- Zustände: Graph-Zustand.
- Algorithmen: Zählung, Iteration.
- Fehler: Keine besonderen.
- Seiteneffekte: wipe löscht die GraphML-Datei.

---

## src/memory/__init__.py

### make_backend(name, store_dir, model, **kwargs)

- Warum: Backend-Konstruktion nach Namen; einzige Verdrahtung zwischen CLI und Implementierungen.
- Problem: Wechsel per One-Word-Flag; Pfade konsistent aus einem Store-Verzeichnis ableiten.
- Regeln: window → token_budget (Default 800); summary → keep_last (Default 6); episodic → <store>/episodic; facts → <store>/facts.db; graph → <store>/graph.graphml; unbekannter Name → Fehler mit gültiger Liste; Store-Verzeichnis wird angelegt.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Namens-Dispatch.
- Fehler: Unbekannter Name → ValueError.
- Seiteneffekte: Verzeichniserzeugung; Instanziierung persistenter Backends lädt vorhandene Daten.

---

## demo_chat.py

### build_context(backends, query)

- Warum: Sammelt die Recall-Snippets aller aktiven Backends in einen Kontextblock für das LLM.
- Problem: Mehrere Backends zu einem MEMORY-Abschnitt mit klarer Herkunftskennzeichnung bündeln.
- Regeln: recall mit k=6 je Backend; Blöcke als "[name]\n- snippet" je Backend; leere Gesamtheit → "(empty)".
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Konkatenation.
- Fehler: Keine besonderen.
- Seiteneffekte: Backend-Recalls (bei episodic Embedding-Call).

### respond(backends, user_msg, index)

- Warum: Ein Austausch: Kontext bauen, LLM befragen, Verlauf in alle Backends schreiben.
- Problem: Agenten-Muster "anreichern → antworten → merken" an einem Ort.
- Regeln: System-Prompt (SYSTEM) verlangt, bei fehlender Memory-Antwort "weiß nicht" zu sagen statt zu raten; nach der Antwort werden user- und assistant-Turn mit index bzw. index+1 gespeichert.
- Daten: Backend-Stores via remember.
- Zustände: Turn-Indizes.
- Algorithmen: Keine.
- Fehler: Nicht gesondert behandelt.
- Seiteneffekte: NIM-Chat-Call; Backend-Schreibzugriffe (inkl. Embedding-/Extraktions-Calls).

### main()

- Warum: Interaktive REPL mit Kommandoverarbeitung.
- Problem: Bedienbarkeit über Konsole; Backend-Auswahl, Inspektion, Reset.
- Regeln: "--memory all" → alle Backends; Komma-Listen werden gesplittet; /inspect, /stats, /wipe, /quit; leere Eingaben übersprungen; Index steigt um 2 pro Austausch; EOF/Strg-C beendet sauber.
- Daten: Backend-Stores via Kommandos.
- Zustände: Turn-Index, Backend-Instanzen.
- Algorithmen: Kommando-Dispatch.
- Fehler: EOFError/KeyboardInterrupt → sauberer Ausstieg.
- Seiteneffekte: Konsolen-I/O; Backend-Mutationen; NIM-Credits.

---

## benchmark.py

### load_script(path)

- Warum: Benchmark-Skript laden.
- Problem: Fixture aus JSON lesen.
- Regeln: JSON-Objekt mit Feld "script"; Liste wird zurückgegeben.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: JSON-Deserialisierung.
- Fehler: Datei-/JSON-Fehler propagieren.
- Seiteneffekte: Datei-I/O.

### answer_probe(backend, question)

- Warum: Eine Probe beantworten: Recall-Kontext → LLM-Frage → Kontext-Token messen.
- Problem: Messung, ob das Backend genug Kontext für die richtige Antwort liefert.
- Regeln: recall mit k=6; Kontext als "- snippet"-Zeilen oder "(empty)"; PROBE_SYSTEM verlangt ausschließliche Nutzung des MEMORY-Blocks, exakte Antwort "I don't know" bei fehlender Antwort, eine kurze Antwort; chat mit temperature=0.0 und max_tokens=120; Token-Schätzung über approx_tokens des Kontexts.
- Daten: Keine.
- Zustände: Keine.
- Algorithmen: Kontext-Komposition.
- Fehler: Nicht gesondert behandelt.
- Seiteneffekte: Backend-Recall (ggf. Embedding-Call); NIM-Chat-Call.

### run_backend(name, script, store_dir)

- Warum: Ein Backend komplett gegen das Skript fahren.
- Problem: Vergleichbarkeit: frische Instanz, identisches Replay, Metriken sammeln.
- Regeln: window erhält das kleine WINDOW_BUDGET (250); wipe vor Replay; turns → remember mit fortlaufendem Index und Latenzmessung; probes → answer_probe und Substring-Hit-Wertung gegen die Erwartungsliste; Aggregation zu Accuracy, durchschnittlichen Token und Latenz; Details je Probe.
- Daten: Backend-Stores unter <store>/<name>.
- Zustände: Zähler und Ergebnislisten.
- Algorithmen: Substring-Matching (kleingeschriebene Antwort gegen Erwartungen), Durchschnittsbildung.
- Fehler: Keine besonderen (division durch 0 bei fehlenden Probes wird abgesichert).
- Seiteneffekte: Store-Dateien; NIM-Credits.

### print_table / print_analysis / main

- Warum: Ergebnisdarstellung und Zusammenfassung.
- Problem: Lesbare Tabelle und kontextualisierte Analyse.
- Regeln: Tabelle mit backend/accuracy/probes/ctx_tok/turn_s; Analyse nennt Best-/Weakest-Recall, window-Schwäche (nur falls accuracy < beste), facts-Kontradiktions-Stärke, Kosten-Hinweis und Nicht-Determinismus-Hinweis; main verarbeitet --script/--only/--store/--json, erzeugt Verzeichnisse und schreibt optionale JSON-Details.
- Daten: Ergebnisstrukturen.
- Zustände: Keine.
- Algorithmen: Sortierung nach Accuracy.
- Fehler: Keine besonderen.
- Seiteneffekte: Konsolen-Ausgabe; optionale JSON-Datei; Store-Verzeichnisse.
