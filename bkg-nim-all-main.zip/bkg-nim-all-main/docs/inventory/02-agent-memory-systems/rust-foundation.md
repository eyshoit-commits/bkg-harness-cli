# Rust-Rewrite-Foundation: agent-memory-systems

Die Neuentwicklung bildet die nachfolgend aus dem Quellcode belegten Fähigkeiten vollständig neu ab. Keine Übernahme von Code, Namen als Beleg nur, wo sie die fachliche Anforderung präzisieren.

## Benötigte Capability

1. Polymorpher Speichervertrag: Aufnahme eines Konversations-Turns, Abruf von bis zu k zur Query passenden Snippets, Zustandsstatistik, Komplettlöschung, Inspektion — austauschbar zwischen fünf Implementierungen ohne Änderung des Agentencodes (belegt durch src/memory/base.py).
2. Fünf Speicherarchitekturen:
   - Token-budgetierter Sliding Window mit ältester-Erst-Eviction und tiktoken-freier Token-Schätzung (src/memory/window.py).
   - Rollierende LLM-Komprimierung mit wörtlichem Tail und Schwellwert-Trigger (src/memory/summary.py).
   - Vektor-Episodenspeicher mit Embedding-Aufnahme, Kosinus-Recall und exponentieller Recency-Gewichtung, Dual-Datei-Persistenz (src/memory/episodic.py).
   - SQLite-Faktenstore mit Triple-Extraktion, Supersession bei Wertänderung, Historie/auditierbare verdrängte Zeilen und Keyword-Recall (src/memory/facts.py).
   - Wissensgraph auf Multigraph-Basis mit Entity-Merging über normalisierte Namen, Ego-Graph-Recall und GraphML-Persistenz (src/memory/graph.py).
3. LLM-gestützte Triple-Extraktion mit defensivem Parsen unzuverlässiger Modellantworten (Fences/Prosa) und Validierungsfilter (src/extract.py).
4. Namensnormalisierung und Keyword-Extraktion als gemeinsame Recall-Grundlagen (src/util.py).
5. Offline-Konsolidierungspipeline: Dedupe (Kosinus-Schwellwert), Promote (Cluster-Größe → Fakten), Prune (LLM-Importance mit Inhalts-Hash-Cache), dry-run-Modus und JSON-Bericht (src/consolidate.py).
6. OpenAI-kompatibler NIM-Client für Chat und Embeddings inklusive Key-Validierung mit freundlicher Abbruchmeldung und input_type-Disziplin (src/nim.py).
7. Interaktive CLI-REPL mit Memory-Anreicherung und Kommandos (demo_chat.py).
8. Benchmark-Harness mit skriptetem Replay, Substring-Hit-Wertung, Metrik-Aggregation (Accuracy, Kontext-Token, Latenz) und optionalem JSON-Export (benchmark.py).
9. Konfiguration über Umgebungsvariablen (Pflicht-Key, optionales Modell) mit Vorlage (src/nim.py, .env.example).

## Benötigte Rust Traits

- `MemoryBackend` (Kernvertrag): remember(Turn), recall(query, k) → Vec<String>, stats() → Stats, wipe(), inspect() → String. Für die Fabrik zusätzlich Namenskonstante.
- `Embedder`: embed(texts, input_type) → Vec<Vec<f32>>; wird vom Episodenspeicher konsumiert.
- `ChatClient` / `CompletionClient`: chat(messages, temperature, max_tokens) → String; wird von Extraktion, Komprimierung, Scoring, Agenten und Benchmark konsumiert.
- `TokenEstimator`: approx_tokens(text) → usize (eigenständige, testbare Funktion; Trait für austauschbare Budget-Schätzer).
- `Normalizer` (oder freie Funktionen): normalize_name, keywords — als reine Funktionen testbar; Trait optional für Test-Doubles.
- `MemoryFactory`: make_backend(name, store_dir, params) → Box<dyn MemoryBackend> (mit enum BackendKind zur Validierung unbekannter Namen).
- `Persistence` (pro persistentem Backend): Load/Save-Operationen; durch konkrete Typen wie EpisodicStore, FactStore, GraphStore implementiert.
- Fehler: `std::error::Error`-kompatibler `MemoryError` mit Varianten (siehe Error Types).

## Benötigte Module

- `memory::contract` — Vertrag, Turn-Modell, Stats.
- `memory::window` — Sliding-Window-Speicher + Token-Schätzer.
- `memory::summary` — Rollierende Komprimierung + Prompt-Konstanten.
- `memory::episodic` — Vektorspeicher, Recency-Scoring, Dual-Persistenz.
- `memory::facts` — SQLite-Schema, Upsert/Supersession, Keyword-Recall.
- `memory::graph` — Multigraph, Entity-Merging, Ego-Graph-Recall, GraphML.
- `memory::factory` — Namens-Registry und Konstruktion.
- `nlp::extract` — Triple-Extraktion und defensives Array-Parsing.
- `nlp::util` — Normalisierung und Keywords (inkl. Stoppwort-Set).
- `nim::client` — HTTP-Client, Chat-/Embedding-Requests, Key-Validierung, Modell-Konstanten.
- `consolidate::job` — Pipeline (promote/dedupe/prune), Score-Cache, Bericht.
- `cli::chat` — interaktive REPL (demo_chat-Äquivalent).
- `bench::runner` — Replay-Harness, Wertung, Metrik-Aggregation, JSON-Export.
- `config` — Umgebungsvariablen, Platzhalter-Prüfung, Modell-Defaults.

## Benötigte Services

- NimService: gekapselte HTTP-Kommunikation (Chat + Embeddings), einmalige Client-Initialisierung, Key-Validierung; async.
- ExtractionService: LLM-Triple-Extraktion mit Prompt-Bau und defensivem Parsen.
- SummaryService: Komprimierung mit laufender Zusammenfassung (Zustand: Puffer + Summary + Zähler).
- ImportanceScorer: LLM-basierte Wichtigkeitsbewertung mit Inhalts-Hash-Cache (SHA1), Batch-Verarbeitung (20er) und Score-Clamping.
- ConsolidationJob: Orchestrierung promote → dedupe → prune mit dry-run-Semantik und Berichtserstellung.
- BenchmarkRunner: Backend-Replay, Probe-Wertung, Metriken.
- ChatOrchestrator: Context-Build (Recall aller Backends), LLM-Antwort, Rückschreiben der Turns (demo_chat-Fähigkeit).

## Benötigte Events

- Aus dem Quellcode sind keine expliziten Events ableitbar (siehe architecture.md). Für die Neuentwicklung sinnvolle, aus den Abläufen abgeleitete Ereignistypen (als Beleg der Ablaufschritte):
  - `TurnRemembered { backend, turn_index }` (nach remember).
  - `RecallCompleted { backend, query, snippet_count }`.
  - `CompressionTriggered { turns_compressed, new_summary_tokens }`.
  - `FactSuperseded { fact_id, superseded_by }` (aus upsert-Logik ableitbar).
  - `ConsolidationRun { report }` mit Unterereignissen Promote/Dedupe/Prune.
  - `EmbeddingFailure` / `ChatFailure` (aus der Fehlerfreiheits-Lücke abgeleitet, siehe nim.md).
- Diese sind als Instrumentierungs- bzw. Observability-Events der Neuentwicklung zu verstehen, nicht als Übernahme vorhandener Strukturen.

## Benötigte Storage Layer

- EpisodicStore: Vektoren (Binär, z.B. bincode oder eigenes npz-Äquivalent) + Texte/Metadaten (JSON-Lines) — zwei Dateien mit write-through nach jeder Mutation (belegt durch src/memory/episodic.py).
- FactStore: SQLite-Datenbank mit Tabelle inkl. normalisierter Merge-Schlüssel, Aktiv-Flag, Supersession-Verlinkung und Indizes; parametrisierte Abfragen (src/memory/facts.py).
- GraphStore: GraphML-Datei, geladen beim Start, geschrieben bei jeder Änderung (src/memory/graph.py).
- ImportanceCache: JSON-Datei (Hash → Score) mit Load-on-Start/Save-on-Mutation (src/consolidate.py).
- Kein Storage für window/summary (rein flüchtig, belegt durch src/memory/window.py und summary.py).

## Benötigte Async-Komponenten

- Async HTTP-Client für NIM (Chat + Embeddings) — Basis: tokio + reqwest; alle Aufrufe über await; Backend-Methoden remember/recall werden dadurch async (bzw. interne Services async mit Synchronisierungsschicht, falls Vertrag synchron bleiben soll).
- Konsolidierungslauf: Batch-LLM-Calls (Importance-Scoring) können parallelisiert werden (20er-Batches; Reihenfolge des Caches muss deterministisch bleiben — belegt durch die Batch-Logik in src/consolidate.py, score_importance).
- CLI-REPL: async-Eingabeschleife, die auf LLM-Antworten wartet.
- Keine Hintergrund-Worker/Queues im Quellcode vorhanden; die Neuentwicklung kann Consolidation als geplanten Job (z.B. tokio-scheduler oder externer Cron) ausführen — als Architekturentscheidung, nicht als Übernahme.

## Benötigte Error Types

- `NimError`: MissingKey / PlaceholderKey (mit Setup-Anleitung), Http { status, body }, Network, Timeout, Parse (ungültige Response) — belegt durch src/nim.py: nur Key-Fehler explizit behandelt; Transport-/Parse-Fehler fehlen und müssen neu definiert werden.
- `ExtractionError`: ChatFailure, JsonParseFailure → Rückfall auf leere Liste (belegt durch src/extract.py, _parse_array).
- `StorageError`: Io, JsonSerialization, Sqlite, GraphmlParse, CorruptStore — für die Persistenzen.
- `FactoryError`: UnknownBackend { name, valid: Vec<String> } (belegt durch src/memory/__init__.py, make_backend).
- `ConsolidationError`: CacheFailure, ScoringFailure (mit 0.5-Rückfall), StoreAccess — abgeleitet aus src/consolidate.py.
- App-Ebene: from-Implementierungen, damit alle Fehler zu einem gemeinsamen Fehler-Typ konvergieren; Display-Implementierungen für die freundliche Key-Meldung.

## Benötigte Crates

- reqwest + tokio: async HTTP-Client und Runtime.
- serde / serde_json: Nachrichten, Persistenz, Cache, Berichte, Fixtures.
- dotenvy: .env-Laden (belegt durch python-dotenv-Nutzung).
- ndarray (oder nalgebra): Vektor-Matrix, Kosinus, Matrizenprodukt (belegt durch numpy-Nutzung).
- rusqlite (oder sqlx): SQLite-Faktenstore (belegt durch sqlite3-Nutzung).
- petgraph: Multigraph (belegt durch networkx-Nutzung).
- regex: Wortextraktion, JSON-Array-Extraktion, Score-Parsing (belegt durch re-Nutzung).
- sha1 (oder sha2): Inhalts-Hash-Cache (belegt durch hashlib.sha1-Nutzung).
- clap: CLI-Parameter aller drei Einstiegspunkte (belegt durch argparse-Nutzung).
- chrono / std::time: Zeitstempel (belegt durch time.time-Nutzung).
- anyhow / thiserror: Fehlerhierarchie.
- GraphML: eigenes serde-Mapping oder Crate (graphml_parser o.ä.) — belegt durch networkx GraphML-Serialisierung.
- optional: criterion für Benchmark-Tests, proptest für Property-Tests (siehe tests.md).

## Architekturentscheidung

- Wiederverwendbare Bibliothek (Crates: `memory-core` mit Vertrag/Backends/Util, `nim-client`, `consolidation`) plus zwei dünne Binär-Crates (`chat-cli`, `bench-cli`) — spiegelt die Trennung zwischen Bibliothekspaket (src/) und Einstiegspunkten (demo_chat.py, benchmark.py, src/consolidate.py) des Quellcodes.
- Vertrag zuerst: `MemoryBackend`-Trait als einzige Kopplung zwischen Agentencode und Speicherimplementierungen; Factory als enum-basierter Dispatch mit Validierung unbekannter Namen.
- Persistenz als write-through (episodic/graph) bzw. transaktional (facts) mit klarer Trennung von In-Memory-Zustand und Storage-Layer; Konsistenz wie im Quellcode: nach jeder Mutation gespeichert.
- Synchroner Vertrag mit internem async: Backend-API kann synchron bleiben, indem sie intern einen Runtime-Handle (oder eine blockierende Bridge) nutzt; alternative Entscheidung: vollständig async Vertrag. Empfehlung aus den Aufrufmustern (sequenzielle Nutzung in CLI/Benchmark, Batch-Parallelisierung nur im Scoring): async-Interna mit synchroner Fassade für die Einstiegspunkte, falls Vertragseinheitlichkeit gewünscht ist — als explizite Architekturentscheidung der Neuentwicklung.
- Kein Streaming/Tool-Calling in der Erstversion (im Quellcode nicht vorhanden, belegt durch nim.md); der NIM-Client wird so gebaut, dass stream/tools später ergänzbar sind (Request-Strukturen erweiterbar).
- Teststrategie: trait-basierte Test-Doubles für NIM (deterministische Chat-/Embedding-Antworten), damit alle Backends und die Konsolidierung ohne Netzwerk testbar sind; Fixture data/script.json als eingebettete Testdaten (siehe tests.md).
