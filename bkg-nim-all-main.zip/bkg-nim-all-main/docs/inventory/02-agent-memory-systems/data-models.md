# Datenmodelle: agent-memory-systems

Für jedes Datenmodell: Bedeutung, Lebenszyklus, Ownership, Beziehungen, Persistenz, Validierung, Mutationen, Thread-Sicherheit, benötigte Rust-Konzepte.

---

## Turn

- Bedeutung: Eine einzelne Nachricht in einer Konversation; das universelle Eingabemodell für alle Backends (belegt durch src/memory/base.py, Dataclass Turn).
- Lebenszyklus: Wird von Aufrufern (demo_chat.py, benchmark.py) erzeugt, beim Speichern an remember übergeben und von den Backends konsumiert; nach der Übergabe kein weiterer Lebenszyklus im Backend (ausgenommen as_line-Serialisierung und Speicherung von Inhalt/Metadaten).
- Ownership: Der Aufrufer erzeugt und besitzt die Instanz; Backends lesen Felder und extrahieren Werte (content, role, index, ts, meta).
- Beziehungen: role ∈ {user, assistant} (belegt durch die Aufrufe in demo_chat.py und benchmark.py); index verweist auf die Position im Gespräch; meta ist ein frei formbares Dictionary (im episodischen Backend werden role/ts/order hineingeschrieben — belegt durch src/memory/episodic.py).
- Persistenz: Nicht selbst persistent; serialisiert als Zeile via as_line (window/summary/episodic) oder inhaltlich zerlegt (facts/graph: nur der Text geht in die Extraktion).
- Validierung: Keine Feldvalidierung im Modell (belegt durch die Dataclass-Definition ohne Validatoren); leere content-Werte führen in extract_triples zu leeren Ergebnissen (src/extract.py).
- Mutationen: Nach Erzeugung unverändert; Backends kopieren Werte in ihre eigenen Formate.
- Thread-Sicherheit: Nicht relevant — die Programme sind single-threaded (keine Threads im Code nachweisbar); Dataclass ist ohne Sync-Primitive.
- benötigte Rust-Konzepte: struct Turn mit serde (Deserialize aus CLI/Test-Skript), Display-Darstellung für die Zeilenserialisierung, Default-Zeitstempel via chrono/std::time.

---

## Window-Speicher (Fensterinhalt)

- Bedeutung: Token-budgetierter Verlauf der jüngsten Turns (belegt durch src/memory/window.py, Attribute turns und token_budget).
- Lebenszyklus: In-Memory über die Prozesslaufzeit; beginnt leer, wächst mit remember, schrumpft durch Eviction; wipe setzt zurück; keine Persistenz.
- Ownership: Die WindowMemory-Instanz.
- Beziehungen: Enthält Turn-Objekte (als Zeilen serialisiert); keine externen Referenzen.
- Persistenz: Keine (belegt durch fehlende Datei-I/O in src/memory/window.py).
- Validierung: Budget-Schranke über Token-Schätzung (approx_tokens); mindestens ein Turn bleibt immer erhalten (Eviction-Schleife bricht bei len > 1 ab).
- Mutationen: append (remember), pop(0) (Eviction), clear (wipe), Zähler evicted.
- Thread-Sicherheit: Single-threaded; keine Locks.
- benötigte Rust-Konzepte: VecDeque<Turn> (effizientes pop-front), Token-Budget-Schätzer als Funktion, evictions-Zähler.

---

## Summary-Speicher

- Bedeutung: Rollierende Zusammenfassung plus wörtlicher Tail (belegt durch src/memory/summary.py, Attribute recent, summary, n_compressions).
- Lebenszyklus: In-Memory; beginnt leer; wächst durch remember; Kompressionstrigger bei Puffergröße 2 * keep_last; wipe setzt zurück; keine Persistenz.
- Ownership: Die SummaryMemory-Instanz.
- Beziehungen: recent hält Turn-Objekte; summary ist ein vom LLM erzeugter Freitext; n_compressions zählt Kompressionen.
- Persistenz: Keine.
- Validierung: Kompressionsantwort wird getrimmt; keine Strukturvalidierung.
- Mutationen: append, Slice-Verschiebung des Puffers, summary-Überschreibung durch LLM-Antwort, Zähler-Inkrement.
- Thread-Sicherheit: Single-threaded.
- benötigte Rust-Konzepte: Vec<Turn> mit Splice-Operationen, String summary, Zustandstransitionen (Trigger-Logik) — als einfache Struktur ohne Trait-Anforderungen.

---

## Episodischer Speicher (Episoden)

- Bedeutung: Gespeicherte Gesprächszeilen mit Vektoren und Metadaten (belegt durch src/memory/episodic.py, Attribute texts, metas, vecs).
- Lebenszyklus: Wird beim Instanzieren aus Dateien geladen (_load); wächst pro remember; schrumpft durch drop (Konsolidierung) und wipe; jeder Zustandswechsel wird sofort persistiert.
- Ownership: Die EpisodicMemory-Instanz; Dateien episodisch.npz und episodisch.jsonl sind die persistenten Abbilder.
- Beziehungen: Drei parallele Collections mit identischer Reihenfolge/Indizierung: texts (Zeile), metas (role, ts, order), vecs (Float32-Matrix Zeile = normalisierter Embedding-Vektor); order ist die 1-basierte Ankunftsreihenfolge.
- Persistenz: jsonl (Text + Meta, UTF-8, ein JSON-Objekt je Zeile) + npz (Vektoren) — belegt durch _load/_save.
- Validierung: Keine strikte; beim Laden werden Datensätze direkt übernommen (fehlende Felder würden zu Fehlern beim Zugriff führen — nicht gesondert abgefangen); Normalisierung der Vektoren bei Aufnahme.
- Mutationen: Anhängen (remember), Entfernen von Positionen (drop), Komplettlöschung (wipe).
- Thread-Sicherheit: Single-threaded; Matrix-Zugriffe ohne Locks.
- benötigte Rust-Konzepte: Vec<String>, Vec<Meta>, Array2<f32> (ndarray) mit identischer Indizierung (ggf. ein gemeinsamer Struct-Vektor), serde für jsonl, bincode/npz-Äquivalent für Vektoren, Normalisierung als reine Funktion.

---

## Fakten-Store (SQLite-Tabelle facts)

- Bedeutung: Strukturierte Fakten mit Supersession-Historie (belegt durch src/memory/facts.py, Tabelle facts).
- Lebenszyklus: DB-Datei wird beim Instanzieren erzeugt (Schema via _init_db); Zeilen entstehen durch upsert/remember; Verdrängung setzt active=0; wipe löscht alle Zeilen.
- Ownership: Die FactMemory-Instanz hält die SQLite-Verbindung; die DB-Datei ist das persistente Abbild.
- Beziehungen: subject_norm/predicate_norm sind Merge-Schlüssel (abgeleitet via normalize_name); superseded_by verweist auf die verdrängende Zeilen-id; source_turn verweist auf den Turn-Index.
- Persistenz: SQLite-Datei facts.db; Schema: id, subject, predicate, object, subject_norm, predicate_norm, ts, source_turn, active, superseded_by; Indizes idx_active und idx_sp.
- Validierung: NOT-NULL-Constraints auf Kerntextfeldern; keine inhaltliche Validierung; Objektgleichheit wird über Normalisierung geprüft.
- Mutationen: INSERT (neue aktive Fakten), UPDATE (active=0 + superseded_by), DELETE (wipe); keine Änderung bestehender Werte.
- Thread-Sicherheit: SQLite-Verbindung ohne explizites Locking; bei parallelen Prozessen wären Schreibkonflikte möglich (nicht behandelt); single-threaded Nutzung.
- benötigte Rust-Konzepte: rusqlite/sqlx-Struktur mit Prepared Statements (parametrisierte LIKE-Abfragen gegen Injection), Migrations-DDL, Transaktions-Semantik für upsert, Row-Mapping auf struct Fact.

---

## Wissensgraph (networkx MultiDiGraph)

- Bedeutung: Entitäten und Relationen als gerichteter Multigraph (belegt durch src/memory/graph.py, Attribut g).
- Lebenszyklus: Wird beim Instanzieren aus GraphML geladen (_load); wächst pro remember (Knoten + Kanten); wipe ersetzt durch leeren Graphen und löscht die Datei.
- Ownership: Die GraphMemory-Instanz; GraphML-Datei ist das persistente Abbild.
- Beziehungen: Knoten: Key = normalisierter Name, Attribut label = Originalname; Kanten: Key = Prädikat, Attribute predicate und ts; Mehrfachkanten zwischen gleichen Knoten sind möglich (Multigraph).
- Persistenz: GraphML via networkx-Serialisierung (_save nach jeder Änderung).
- Validierung: Keine strikte; Seed-Auflösung über Blob-Substring-Matching; Kanten-Deduplizierung nur bei Recall-Ausgabe, nicht im Graphen.
- Mutationen: add_node, add_edge, Komplettersetzung (wipe).
- Thread-Sicherheit: Single-threaded.
- benötigte Rust-Konzepte: petgraph::Graph mit MultiEdge (oder DiGraph mit EdgeIndex), HashMap<normalisierter Name, NodeIndex> als Index für O(1)-Entity-Lookup, GraphML-Serialisierung (serde-basiertes Format oder eigenes Mapping), Ego-Graph-Berechnung über BFS mit Radius.

---

## Importance-Cache (JSON: Hash → Score)

- Bedeutung: Persistenter Cache für LLM-Wichtigkeitsbewertungen (belegt durch src/consolidate.py, _load_cache/_save_cache und score_importance).
- Lebenszyklus: Wird beim Konsolidierungslauf geladen (falls vorhanden), wächst mit unbekannten Texten, wird bei Mutationen gespeichert; wipe-Konzept existiert nicht für den Cache.
- Ownership: Die Konsolidierungslauf-Instanz (im Speicher) und die Datei importance_cache.json (Disk).
- Beziehungen: Schlüssel = SHA1-Hexdigest des Episode-Texts; Wert = Score-Float.
- Persistenz: JSON-Datei mit Einrückung.
- Validierung: Scores werden auf [0,1] geclampt; fehlende Einträge fallen beim Zugriff auf 0.5 zurück.
- Mutationen: Hinzufügen neuer Hash→Score-Paare (im Speicher), Überschreiben der Datei.
- Thread-Sicherheit: Single-threaded; parallele Konsolidierungsläufe auf denselben Cache wären konfliktbehaftet (nicht behandelt).
- benötigte Rust-Konzepte: HashMap<String, f32> mit serde_json-Persistenz, SHA1 via sha1-Crate, atomare Datei-Ersetzung (write-temp-then-rename) zur Vermeidung korrupter Cache-Dateien.

---

## Benchmark-Skript (data/script.json)

- Bedeutung: Test-Fixture mit Turns und Probes (belegt durch data/script.json und benchmark.py, load_script).
- Lebenszyklus: Statisch committet; wird pro Benchmark-Lauf gelesen.
- Ownership: Repository.
- Beziehungen: Top-Level: description + script-Array; Einträge vom Typ turn (kind, role, content) und probe (kind, question, expect[]).
- Persistenz: Committete JSON-Datei (explizit nicht ignoriert).
- Validierung: Keine Schemavalidierung; benchmark.py erwartet die Felder bei der Iteration.
- Mutationen: Keine.
- Thread-Sicherheit: Read-only.
- benötigte Rust-Konzepte: serde-Denum (untagged enum ScriptItem: Turn { role, content } | Probe { question, expect }), als Testdaten inkludiert (include_str! oder tests/fixtures).

---

## Benchmark-Ergebnisstruktur

- Bedeutung: Aggregierte und Detail-Metriken je Backend-Lauf (belegt durch benchmark.py, run_backend/answer_probe).
- Lebenszyklus: Entsteht pro Backend während des Replays; wird in der Tabelle/Analyse konsumiert und optional als JSON-Datei persistiert.
- Ownership: Die main-Routine.
- Beziehungen: Aggregat (backend, accuracy, correct, probes, avg_ctx_tokens, avg_turn_latency, details) mit Details je Probe (question, expected, reply, hit).
- Persistenz: Optional JSON-Datei (--json).
- Validierung: Division durch 0 bei fehlenden Probes/Turns wird durch bedingte Mittelung abgesichert.
- Mutationen: Akkumulation während des Replays.
- Thread-Sicherheit: Single-threaded.
- benötigte Rust-Konzepte: struct BenchmarkResult mit serde-Serialize, f64-Metriken, Option für leere Listen.

---

## Konsolidierungsbericht

- Bedeutung: Protokoll eines Konsolidierungslaufs (belegt durch src/consolidate.py, consolidate/main).
- Lebenszyklus: Entsteht pro Lauf; wird auf stdout als JSON ausgegeben; nicht dauerhaft gespeichert (kein Schreibpfad nachweisbar).
- Ownership: Der Lauf.
- Beziehungen: start_episodes, promoted_triples, deduped, pruned, end_episodes, dry_run.
- Persistenz: Keine (nur Konsolenausgabe).
- Validierung: Keine.
- Mutationen: Akkumulation im Lauf.
- Thread-Sicherheit: Single-threaded.
- benötigte Rust-Konzepte: struct ConsolidationReport mit serde-Serialize (bzw. Serialize für die JSON-Ausgabe), dry_run als bool.

---

## Übergreifende Thread-Sicherheits- und Ownership-Aussagen

- Alle Backends und Prozesse sind durchgängig single-threaded; es existieren keine Threads, Locks, Queues oder geteilten Zustände zwischen Prozessen (belegt durch das Fehlen entsprechender Konstrukte im gesamten Quellcode).
- Ownership-Muster: Aufrufer (CLI/Benchmark) erzeugen Backends via Factory; Backends besitzen ihre internen Zustände und Persistenzen; die Konsolidierung öffnet EpisodicMemory und FactMemory desselben Store-Verzeichnisses gleichzeitig — parallele Schreibprozesse auf denselben Store sind nicht vorgesehen.
- Persistenz-Konsistenz: Episodic und Graph schreiben bei jeder Mutation (write-through); Facts committet je upsert; Window/Summary sind rein flüchtig.
