# Repo-Übersicht: agent-memory-systems

## Zweck

Das Repository implementiert fünf austauschbare Langzeitgedächtnis-Architekturen (Backends) für LLM-Agenten hinter einer gemeinsamen Schnittstelle sowie einen Benchmark, der messbar macht, welche Architektur welche Fakten über eine lange Konversation hinweg tatsächlich behält (belegt durch README.md, Zeile 3: "Five memory architectures for LLM agents behind one interface … with a benchmark that measures which actually remembers").

Grundproblem, das das Repo adressiert (belegt durch README.md, Abschnitt "Why"): Ein LLM hat kein eigenes Gedächtnis; pro Turn ist nur der Kontext im Kontextfenster verfügbar. "Langzeitgedächtnis" ist eine Engineering-Entscheidung darüber, was gespeichert, wie abgerufen und was verworfen wird. Die im Repo dokumentierten bekannten Schwächen der naiven Antworten:
- "gesamtes Transkript behalten" bricht, sobald die Konversation das Kontextfenster übersteigt (lineare Kosten, Latenz, Verlust früher Inhalte).
- "alles in eine Vektordatenbank" liefert bereits korrigierte Fakten zurück und kann keine Fakten verknüpfen.

## Verantwortlichkeit

Das Repo ist verantwortlich für:
- Ein einheitliches Vertragsmodell für Gedächtnis-Backends mit vier Kernmethoden (belegt durch src/memory/base.py, Klasse MemoryBackend: remember, recall, stats, wipe; README.md Zeile 49).
- Fünf konkrete Backends: Window, Summary, Episodic, Facts, Graph (belegt durch src/memory/__init__.py, BACKEND_NAMES).
- Ein interaktives CLI zum Chatten mit einem oder mehreren Backends (belegt durch demo_chat.py).
- Ein Benchmark-System, das ein skriptetes Gespräch (data/script.json) gegen jedes Backend repliziert und Recall-Genauigkeit, Kontext-Token und Latenz misst (belegt durch benchmark.py).
- Eine Offline-Konsolidierungsaufgabe ("sleep"), die episodisches Gedächtnis dedupliziert, wiederkehrende Episoden zu Fakten befördert und unwichtige Episoden entfernt (belegt durch src/consolidate.py).
- Eine OpenAI-kompatible Anbindung an NVIDIA NIM für Chat und Embeddings (belegt durch src/nim.py).

## Komponenten

| Komponente | Datei | Aufgabe |
|---|---|---|
| NIM-Client | src/nim.py | OpenAI-kompatibler Client für Chat-Completions und Embeddings gegen NVIDIA NIM; Schlüsselprüfung mit freundlicher Fehlermeldung |
| Triple-Extraktion | src/extract.py | LLM-basierte Umwandlung von Nachrichtentext in (Subjekt, Prädikat, Objekt)-Tripel; defensives JSON-Parsing |
| Gemeinsame Utilities | src/util.py | Namensnormalisierung (Entity-Merging-Schlüssel), Stoppwort-Kennwort-Extraktion für Keyword-Recall |
| Abstrakte Schnittstelle | src/memory/base.py | MemoryBackend-ABC (remember, recall, stats, wipe, inspect) + Turn-Dataclass |
| Factory | src/memory/__init__.py | Backend-Konstruktion nach Name, Ableitung der Speicherpfade aus einem Store-Verzeichnis |
| Window-Backend | src/memory/window.py | Token-budgetierter Sliding Window, älteste Turns werden zuerst evakuiert; keine API-Calls, keine Persistenz |
| Summary-Backend | src/memory/summary.py | Rolling Summary: ältere Turns werden per LLM-Call komprimiert, die letzten N Turns bleiben wörtlich |
| Episodic-Backend | src/memory/episodic.py | Vektor-Store: NIM-Embeddings + Kosinus, rekency-gewichtet; Persistenz als npz + jsonl |
| Facts-Backend | src/memory/facts.py | SQLite-gestützte Tripel; neue Fakten überschreiben aktive Fakten (Supersession), Historie bleibt auditierbar |
| Graph-Backend | src/memory/graph.py | networkx-Multigraph; Entity-Merging über normalisierte Namen; Ego-Graph-Recall; GraphML-Serialisierung |
| Konsolidierung | src/consolidate.py | Offline-Job: dedupe / promote / prune episodischer Erinnerungen; Importance-Scoring per LLM mit Inhalts-Hash-Cache |
| CLI-Chat | demo_chat.py | Interaktive REPL; /inspect, /stats, /wipe, /quit; beliebige Backend-Kombination |
| Benchmark | benchmark.py | Replay von data/script.json gegen alle/ausgewählte Backends; Metriken Accuracy, Kontext-Token, Latenz |
| Benchmark-Daten | data/script.json | 40-Turn-Gespräch mit 10 gepflanzten Fakten, Smalltalk-Strecke, einer Faktenänderung und 8 Probes |

## Datenfluss

1. Nutzer-Turn (CLI, demo_chat.py) bzw. skripteter Turn (benchmark.py) erreicht ein oder mehrere Backends über die gemeinsame Schnittstelle (belegt durch demo_chat.py, Funktion respond: `b.remember(Turn(...))`).
2. Bei Recall wird eine Query an jedes aktive Backend gestellt (demo_chat.py, Funktion build_context: `b.recall(query, k=6)`); die zurückgegebenen Snippets werden pro Backend als Block in einen MEMORY-Kontextblock zusammengesetzt.
3. Der Kontextblock wird zusammen mit einem System-Prompt und der Nutzer-Nachricht an den NIM-Chat-Endpunkt geschickt (demo_chat.py, Funktion respond; src/nim.py, Funktion chat).
4. Die Antwort des Modells wird zurückgegeben und — zusammen mit der Nutzer-Nachricht — erneut jedem Backend zum Speichern übergeben (demo_chat.py, Funktion respond).
5. Persistente Backends schreiben ihre Zustände: episodic in `*.npz`/`*.jsonl` (src/memory/episodic.py, _save), facts in SQLite `facts.db` (src/memory/facts.py, _init_db/upsert), graph in GraphML (src/memory/graph.py, _save). Window und Summary sind flüchtig (src/memory/window.py, src/memory/summary.py — keine Persistenzmethoden).
6. Die Offline-Konsolidierung liest den episodischen Store und den Fakten-Store eines Store-Verzeichnisses, erzeugt einen Bericht und verändert optional beide Stores (src/consolidate.py, Funktion consolidate).
7. Der Benchmark repliziert das Skript gegen jedes Backend getrennt (mit je eigenem Store-Unterverzeichnis), wertet Probes gegen erwartete Substrings aus und schreibt optional die Detailergebnisse als JSON (benchmark.py, Funktionen run_backend und main).

## Persistenz

- Episodic: `episodic.npz` (normalisierte Vektoren) + `episodic.jsonl` (Text und Metadaten, UTF-8, ein JSON-Objekt pro Zeile) — belegt durch src/memory/episodic.py (Attribute npz_path/jsonl_path, Methoden _load/_save).
- Facts: SQLite-Datenbank `facts.db` mit Tabelle `facts` (id, subject, predicate, object, subject_norm, predicate_norm, ts, source_turn, active, superseded_by) plus Indizes — belegt durch src/memory/facts.py (Methode _init_db).
- Graph: GraphML-Datei `graph.graphml` — belegt durch src/memory/graph.py (Methode _save, Pfadparameter).
- Importance-Cache: JSON-Datei `importance_cache.json` mit Inhalts-Hash → Score — belegt durch src/consolidate.py (Methoden _load_cache/_save_cache, Pfadaufbau in consolidate).
- .gitignore definiert die Grenze zwischen committeten und generierten Daten: `data/script.json` ist committet, `*.db`, `data/*.npz`, `data/*.jsonl`, `data/*.graphml`, `data/importance_cache.json`, `results/`, `out/`, `logs/`, `.store/` sind ignoriert (belegt durch .gitignore).
- Window und Summary persistieren nichts (belegt durch src/memory/window.py und src/memory/summary.py: ausschließlich In-Memory-Listen/Attribute).

## Abhängigkeiten

- Laufzeit-Pakete (belegt durch requirements.txt): openai >= 1.30.0 (LLM + Embeddings über NIM-Endpoint), python-dotenv >= 1.0.0 (.env-Laden), numpy >= 1.26.0 (Vektor-Store, Kosinus, npz-Persistenz), networkx >= 3.2 (Wissensgraph + GraphML).
- Externe Dienste: NVIDIA NIM OpenAI-kompatibler Endpoint (https://integrate.api.nvidia.com/v1) mit API-Key `NVIDIA_API_KEY` (belegt durch src/nim.py).
- Standardbibliothek: sqlite3, json, hashlib, re, argparse, os, sys, time, functools.lru_cache, dataclasses, abc, typing (belegt durch die jeweiligen src-Dateien).
- Kein Testframework, keine CI-Konfiguration, keine Docker-Dateien, keine SQL-/YAML-/TOML-/HTML-/CSS-Dateien im Repo (belegt durch die Dateiliste).

## Eingaben / Ausgaben auf Repo-Ebene

Eingaben:
- Umgebungsvariablen: `NVIDIA_API_KEY` (Pflicht für alle Backends außer window), optional `NIM_MODEL` (Chat-Modell-Override) — belegt durch .env.example und src/nim.py.
- CLI-Parameter von demo_chat.py: `--memory` (Backend-Auswahl, Standard "window"), `--store` (Store-Verzeichnis, Standard "data") — belegt durch demo_chat.py.
- CLI-Parameter von benchmark.py: `--script` (Standard data/script.json), `--only` (Backend-Subset), `--store` (Standard results/bench), `--json` (optionaler Detail-Export) — belegt durch benchmark.py.
- CLI-Parameter von src.consolidate: `--store` (Standard "data"), `--dedupe-threshold` (Standard 0.93), `--prune-threshold` (Standard 0.35), `--repeat-promote` (Standard 3), `--dry-run` — belegt durch src/consolidate.py.
- Interaktive Konsoleneingaben im Chat-Modus einschließlich der Kommandos /inspect, /stats, /wipe, /quit — belegt durch demo_chat.py.
- Benchmark-Skriptdaten im Format data/script.json (Einträge `{"kind": "turn"|"probe", ...}) — belegt durch benchmark.py (Funktion load_script) und data/script.json.

Ausgaben:
- Chat-Antworten des LLM auf stdout (demo_chat.py).
- Backend-Inspektionen (inspect/stats) auf stdout (demo_chat.py).
- Benchmark-Tabelle, Analyse und optionale JSON-Detaildatei (benchmark.py, main).
- Konsolidierungsbericht als JSON auf stdout (src/consolidate.py, main).
- Persistente Artefakte: episodic.npz, episodic.jsonl, facts.db, graph.graphml, importance_cache.json (siehe Persistenz).

## Zustände

- Pro Backend-Instanz: gespeicherter Inhalt, evtl. Zähler (z.B. evicted, n_compressions, active/superseded facts, Episodenzahl, Knoten-/Kantenanzahl) — belegt durch die stats-Methoden der Backends.
- Window: Liste gehaltener Turns + Zähler evictierter Turns (src/memory/window.py).
- Summary: wörtlicher Puffer `recent`, laufende Zusammenfassung `summary`, Kompressionszähler (src/memory/summary.py).
- Episodic: drei parallele Listen/Arrays (texts, metas, vecs) im Speicher, synchron auf Disk persistiert (src/memory/episodic.py).
- Facts: SQLite-Zeilen mit Aktiv-Flag; Supersession markiert alte Zeilen mit active=0 und verknüpft sie per superseded_by (src/memory/facts.py).
- Graph: in-memory MultiDiGraph, bei jeder Änderung als GraphML gespeichert (src/memory/graph.py).
- Konsolidierung: Berichtsdictionary mit start_episodes, promoted_triples, deduped, pruned, end_episodes, dry_run (src/consolidate.py).
- Fehlzustand "API-Key fehlt oder Platzhalter": Prozess terminiert mit Anleitung statt Stacktrace (src/nim.py, Funktion require_key).

## Sicherheitsrelevanz

- Der API-Key `NVIDIA_API_KEY` wird ausschließlich aus der Umgebung bzw. .env gelesen; .env ist in .gitignore ausgeschlossen (belegt durch .gitignore Zeile 11 und src/nim.py Funktion require_key). Der Key beginnt laut .env.example mit dem Präfix `nvapi-`; Platzhalterwerte, die mit `nvapi-XXXX` beginnen, führen zu einem Abbruch mit Anleitung (src/nim.py).
- Keine weiteren Credentials, keine Nutzer-Authentifizierung, keine Netzwerk-Exposition des Repos selbst (nur ausgehende Calls an den NIM-Endpoint; belegt durch src/nim.py, BASE_URL).
- Persistierte Daten können persönliche Informationen aus Gesprächen enthalten (z.B. Name, Allergien, Arbeitsort — siehe data/script.json); das Repo implementiert keine Verschlüsselung, keine Zugriffskontrolle und keine PII-Klassifizierung (kein entsprechender Code vorhanden). Wipe-Methoden löschen die Stores aller Backends, bei episodic auch die Dateien auf Disk (belegt durch die jeweiligen wipe-Methoden).
- Das LLM-Prompting ist nicht gegen Prompt-Injection gehärtet; extrahierte Tripel werden ungefiltert gespeichert und bei Recall ungefiltert in den Kontext eingesetzt (belegt durch src/extract.py und die recall-Methoden).

## Rust-Relevanz (Repo-Ebene)

Das gesamte Repo bildet eine geschlossene Capability-Menge ab, die in einer Rust-2024-Neuentwicklung 1:1 nachgebaut werden muss: ein polymorphes MemoryBackend-Vertrag (Rust-Trait), fünf konkrete Implementierungen, ein Factory-Muster, eine OpenAI-kompatible HTTP-Anbindung an NVIDIA NIM (reqwest/async), Token-Budgetierung, Embedding-Speicherung (ndarray/nalgebra), SQLite-Persistenz (rusqlite/sqlx), Graph-Persistenz (petgraph + GraphML), eine Offline-Konsolidierungspipeline und ein Benchmark-Harness. Details in rust-foundation.md.
