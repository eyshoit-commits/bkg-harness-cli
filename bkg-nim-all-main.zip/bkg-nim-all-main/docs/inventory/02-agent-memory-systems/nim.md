# NVIDIA-NIM-Interaktion: agent-memory-systems

Sämtliche Aussagen beruhen auf src/nim.py sowie den Aufrufstellen in src/extract.py, src/memory/summary.py, src/memory/episodic.py, src/memory/facts.py, src/memory/graph.py, src/consolidate.py, demo_chat.py und benchmark.py.

## Grundkonfiguration

- Endpoint-Basis-URL: https://integrate.api.nvidia.com/v1 (Modulkonstante BASE_URL in src/nim.py).
- Zugang über das OpenAI-SDK (openai >= 1.30.0, belegt durch requirements.txt) mit base_url-Override und api_key aus der Umgebung (src/nim.py, get_client).
- Authentifizierung ausschließlich über den API-Key `NVIDIA_API_KEY`; Schlüssel-Präfix laut .env.example: `nvapi-`.
- .env-Laden erfolgt beim Modulimport via python-dotenv (load_dotenv, src/nim.py).
- Key-Validierung: fehlender Key oder Platzhalter-Präfix (`nvapi-XXXX`) → Abbruch mit Setup-Anleitung auf stderr und Exit-Code 1 (src/nim.py, require_key).

## Chat

- Funktion: chat(messages, model, temperature, max_tokens) (src/nim.py).
- Request-Aufbau: OpenAI-Chat-Completions-Request mit den Feldern model, messages, temperature, max_tokens. Es werden keine weiteren Parameter (stream, tools, tool_choice, response_format, seed u.a.) gesendet.
- Modellwahl: Parameter > Umgebungsvariable `NIM_MODEL` > Default `meta/llama-3.3-70b-instruct` (src/nim.py, chat).
- Default-Einstellungen: temperature=0.2, max_tokens=1024 (src/nim.py, chat).
- Response-Verarbeitung: Rückgabe von choices[0].message.content; leere Antworten werden zu leerem String normalisiert (src/nim.py, chat).
- Aufrufprofile:
  - demo_chat.py respond: Default-Temperatur (0.2) und Default-max_tokens; Kontext als System-Nachricht mit MEMORY-Block.
  - benchmark.py answer_probe: temperature=0.0, max_tokens=120; deterministische Proben-Antworten gewünscht.
  - src/extract.py extract_triples: temperature=0.0, max_tokens=400; JSON-Triple-Antworten.
  - src/memory/summary.py _compress: temperature=0.1, max_tokens=400; Zusammenfassungstext.
  - src/consolidate.py score_importance: temperature=0.0, max_tokens=300; JSON-Score-Array.

## Embeddings

- Funktion: embed(texts, input_type, model) (src/nim.py).
- Modell-Default: `nvidia/nv-embedqa-e5-v5` (Modulkonstante EMBED_MODEL).
- Request-Aufbau: OpenAI-Embeddings-Request mit model, input (String oder Liste), und Zusatzparametern `input_type` und `truncate: "END"` im Request-Body (src/nim.py, embed).
- input_type-Disziplin: `"passage"` für zu speichernde Dokumente, `"query"` für Suchanfragen — laut Docstring verbessert die korrekte Zuordnung die Retrieval-Qualität messbar (src/nim.py, embed).
- Aufrufprofile:
  - Episodic remember: input_type="passage", Einzeltext (src/memory/episodic.py).
  - Episodic recall: input_type="query", Query (src/memory/episodic.py).
- Response-Verarbeitung: Rückgabe der Embedding-Listen aus der data-Liste; Vektoren werden als Float32 übernommen und L2-normalisiert (src/memory/episodic.py, _normalize/remember).
- Keine Embedding-Batch-Verarbeitung über den Einzeltextfall hinaus nachweisbar (embed akzeptiert Listen, wird aber nur mit Einzeltexten aufgerufen — belegt durch die Aufrufstellen).

## Streaming

- Nicht vorhanden: Es wird kein Stream-Parameter gesendet und keine SSE-/Chunk-Verarbeitung implementiert (belegt durch src/nim.py, chat-Aufruf ohne stream; keine Stream-Verarbeitung im gesamten Code).

## Tool Calling

- Nicht vorhanden: Keine Tool-Definitionen, keine tool-Parameter, keine Funktion-Call-Verarbeitung (belegt durch src/nim.py, chat-Request ohne tools; keine Tool-Handling-Stellen im Code).

## Request-/Response-Aufbau (Zusammenfassung)

- Chat-Request: {model, messages: [{role, content}, …], temperature, max_tokens}.
- Chat-Response-Nutzung: choices[0].message.content (String; leere Antwort → "").
- Embedding-Request: {model, input, input_type, truncate}.
- Embedding-Response-Nutzung: data[i].embedding (Float-Liste).
- Nachrichtenformate: role ∈ {system, user} bei Aufrufen (extract/summary/consolidate verwenden nur user-Rollen mit Prompt; demo_chat/benchmark verwenden system+user) — belegt durch die jeweiligen Aufrufstellen. Eine assistant-Rolle wird nie an NIM gesendet (belegt durch Durchsicht aller chat-Aufrufe).

## Retry

- Kein Retry-Mechanismus vorhanden: Fehler aus dem OpenAI-SDK (HTTP, Netzwerk, Timeout, Serverfehler) werden nicht abgefangen und nicht wiederholt (belegt durch src/nim.py ohne try/except um die SDK-Aufrufe).

## Fehlerbehandlung

- Einzige explizite Fehlerbehandlung: Key-Prüfung mit Abbruch (require_key, src/nim.py).
- SDK-Ausnahmen propagieren an die Aufrufer; es gibt keine Fehlerübersetzung in benutzerfreundliche Meldungen und keine partiellen Antworten.
- Defensive Behandlung auf Anwendungsebene nur für LLM-Inhalte (JSON-Parsing in src/extract.py und src/consolidate.py mit Rückfallwerten), nicht für Transportfehler.

## Rate Limits

- Kein Rate-Limit-Handling vorhanden: keine Retry-After-Verarbeitung, keine Backoff-Logik, keine Begrenzung der parallelen Calls (belegt durch src/nim.py und die sequenziellen Aufrufmuster).
- Der README weist lediglich darauf hin, dass die Free-Tier-Latenz variiert (README.md, Benchmark-Hinweis) — keine technische Maßnahme.

## Model Routing

- Kein Routing über mehrere Modelle/Endpoints zur Laufzeit; Modellwahl ist fix pro Funktion: Chat-Default (ggf. NIM_MODEL-Override) bzw. Embedding-Default (src/nim.py).
- Keine Fallback-Modelle, keine Lastverteilung, kein konfigurierbares Mapping von Aufgaben zu Modellen über die beiden Konstanten hinaus.

## Credit-/Nebenwirkungsprofil

- Jeder chat()-Aufruf verbraucht Credits; je Konversationsturn im Chat-Modus: 1 Chat-Call (respond) plus je Backend ggf. 1 Embedding-Call (episodic) bzw. 1 Extraktions-Call (facts/graph) bzw. 1 Kompressions-Call alle 2*keep_last Turns (summary) — belegt durch die Aufrufstellen.
- Im Benchmark: 1 Chat-Call je Probe + je Turn die Backend-spezifischen Calls.
- In der Konsolidierung: 1 Chat-Call je 20 unbekannter Episoden (Importance) + 1 Extraktions-Call je zu befördernder Episode (src/consolidate.py).

## Belegte Nicht-Interaktionen

- Keine Auth-Endpoints, keine Model-Listing-Endpoints, keine Batch-API, keine Datei-Uploads, keine Assistants-/Threads-API — nur Chat-Completions und Embeddings werden genutzt (belegt durch src/nim.py, einzige SDK-Aufrufe).
