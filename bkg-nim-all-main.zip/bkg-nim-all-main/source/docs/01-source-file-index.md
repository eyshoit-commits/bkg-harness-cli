File-ID: FILE-000001
Repository: mindfoundry
Path: /home/workspace/work/proxy/bkg-nim-studio/source/mindfoundry/README.md
File type: Markdown
Language: English
Lines: 180
Purpose: Project overview and documentation
Imported by: All project files
Configuration: NVIDIA Agent Hackathon entry · NeMo Lodge demo · powered by Nemotron · NemoClaw · NVIDIA NIM · OpenClaw
Status: READING