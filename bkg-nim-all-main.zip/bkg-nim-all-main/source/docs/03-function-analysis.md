File-ID: FILE-000005
Repository: mindfoundry
Path: /home/workspace/work/proxy/bkg-nim-studio/source/mindfoundry/hotel_sim/policy_gate.py
File type: Python
Language: Python
Lines: 86
Purpose: Enforces privacy and security policies through text redaction
Imported by: api/server.py, hotel_sim/live_ops.py
Configuration: Reads policy rules from YAML files in data/policies/
Dependencies: json, re, dataclasses, pathlib
Important types: GateResult, PATTERNS, ROLE_PERMISSIONS, ALLOW_EMAILS
Important functions: gate_text(), gate_payload(), _redact_match()
Persistence: policy-gate-events.jsonl (audit log)
External APIs: None
Rust-Relevance: None
Status: READING