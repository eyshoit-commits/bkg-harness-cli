File-ID: FILE-000002
Repository: mindfoundry
Path: /home/workspace/work/proxy/bkg-nim-studio/source/mindfoundry/api/server.py
File type: Python
Language: Python
Lines: 97
Purpose: Local retrieval API server that handles all query endpoints
Imported by: hotel_sim/replicants.py, hotel_sim/live_ops.py
Configuration: Runs on port 8765 (configurable via HOTELSIM_PORT env var)
Dependencies: sqlite3, json, urllib.parse, http.server
Important types: Incident, Reservation, Room, Staff, Policy
Important functions: rows(), one(), send_json(), send_file(), do_GET(), log_message()
Persistence: SQLite database (hotel_sim.sqlite)
External APIs: None (local server)
Rust-Relevance: None
Status: READING