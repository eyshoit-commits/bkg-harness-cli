# BKG — Master Tasks & State

> Last updated: 2026-08-14. This file is the authoritative checkpoint. Read it
> before continuing. Follow the Global Agent Engineering Policy: no fake,
> verify everything, honest status.

---

## 1. Mission

Merge all inventory features (MindFoundry, RAG-NIM, Agent Memory Systems,
NIM-Proxy, PolicyNIM) from zero (NO copied code) into ONE Rust app:
`bkg`. MindFoundry is renamed to `crates/base` (foundation), everything else
is a plugin with hot reload. Must have Dioxus CLI + web dashboard. Gateway
(named `gateway`, NOT `proxy`) with OpenAI-compatible API on port 666.

## 2. Hard Requirements (user, verbatim intent)

- **No hardcoded ports in code** — all via Docker secrets / env. Never
  3000/8000/8080. Scheme: API=666, dashboard=7666, NIM upstream=8066,
  Postgres=5433.
- **No hardcoded IPs/URLs/keys in code** — all via env/Docker secrets.
- Stack uses **static internal IPv4** (172.28.0.0/16 bridge): caddy=.10,
  gateway=.20, dashboard=.21, postgres=.31, NIM GPU host=.30.
- **Domains**: `api.eysho.info` → gateway (API), `adb.eysho.info` → dashboard.
  Caddy reverse proxy, Let's Encrypt TLS (auto).
- **Crate is named `gateway`, not `proxy`** (already renamed).
- **Auth**: login/passwords. **PostgreSQL / Supabase** installed in the
  docker stack. Build **db, auth, RAG over it**. Use the **Rust version**
  (sqlx, argon2 — NOT JS supabase client).
- User grants effectively unlimited tokens; work must not stop until
  everything is coded AND tested.
- Forbidden names: `dna`. Use `bkg-base` / `bkg_base` / `base::`.
- base is library-only, depends on nothing in workspace.

## 3. Current Status (honest)

| Component | Status |
|---|---|
| Root workspace Cargo.toml | DONE (11 crates) |
| crates/base | CODED, tests pass (30) |
| crates/plugin-runtime | CODED, tests pass (3) |
| crates/nim | CODED, tests pass (7) |
| crates/gateway (was proxy) | CODED, tests pass (**24**), clippy clean. **Generic provider registry (`BKG_PROVIDERS`)**: add ANY provider by name, one upstream each, key pools via `P_API_KEYS_FILE` (one key per line = one lane, no cap, 1000-key verified) or numbered `P_API_KEY[_N]`; NO artificial rate limit (counter-only load spreading, nim-proxy least-loaded + cooldown bench on upstream 429/5xx → auto failover to next key); `ProviderKind` enum removed (dynamic `String`). **Dashboard = nim-proxy SPA refactored** (`src/dashboard.html`, embedded single file, no build step, CSP headers, `esc()` XSS discipline, polls `/api/dashboard/now`): BKG cyberpunk style, KPI cards (lanes/providers/allowed/benched), live lanes table (used/rpm loadbar, allowed/limited/errors/latency, READY/BENCH/FAULT LEDs), uptime+clock, 2s auto-refresh, offline banner. Smoke-tested: /health, /v1/models (5 lanes), chat to real Google API, / (HTML+CSP), /api/dashboard/now live snapshot, /metrics + HTML |
| crates/storage (Postgres rewrite) | CODED, builds clean, tests pass |
| crates/memory | **IN PROGRESS — BUILD FAILS** (1 error E0382 moved value `person_id`, see §5) |
| crates/rag | CODED, builds clean |
| crates/policy | **IN PROGRESS — BUILD FAILS** (unresolved `crate::error`, missing Status/Loyalty/Role) |
| crates/simulation | **IN PROGRESS — BUILD FAILS** (missing Status/Loyalty/Role) |
| crates/runtime | CODED, builds clean |
| crates/app (Dioxus CLI+web) | Cargo.toml exists, **NO src/** — TODO |
| deploy/ docker stack | WRITTEN (compose, Caddyfile, .env.example, secrets.example, Dockerfiles, postgres init SQL) — needs binary builds to run |
| Full verification (fmt/check/test/clippy) | NOT YET RUN |
| Git commits | NOT YET DONE (crates untracked) |

## 4. Architecture / Key Files

- Root: `/home/workspace/work/proxy/bkg-nim-studio/`
- `Cargo.toml` — workspace, members incl. `crates/gateway`
- `crates/base/` — domain (identity/messaging/policy/workflow), error
  (core/storage/policy/retrieval/plugin/event), events (9 EventTypes),
  traits (service/memory/persistence/events/mocks), plugin
- `crates/gateway/` — auth.rs (SHA-256 key records), config.rs
  (`GatewayConfig::from_env` + `secret()` reads `X_KEY_FILE` Docker secrets),
  lane.rs (ProviderKind Nim/Gemini/Opencode, SlidingWindowLimiter, Lane),
  metrics.rs (LaneMetrics), server.rs (LaneRouter + RouteDecision),
  main.rs (axum: POST /v1/chat/completions, GET /v1/models, /health;
  dashboard / + /metrics on separate bind; model→provider routing)
- `crates/plugin-runtime/` — registry.rs, hot_reload.rs (`*.plugin.json` watcher)
- `crates/nim/` — client.rs (reqwest, rustls-tls), error.rs
- `crates/storage/` — persist.rs (Postgres sqlx: state_store, event_stream,
  rag_documents/embeddings pgvector, usage_ledger, PgStateSink/Source/
  AppendLog/SnapshotCodec impls), auth.rs (argon2id, sessions, token
  hashing), lib.rs
- `deploy/` — docker-compose.yml, Caddyfile, .env.example,
  secrets.example/, Dockerfile.gateway, Dockerfile.dashboard,
  postgres/init/001_bkg.sql
- opencode config: `~/.config/opencode/opencode.json` — provider `nim`
  baseURL **http://localhost:666/v1**, key `npk_3618a774a6b64a3226715fe83ba12758`
  (NOTE: 666 needs root to bind on host; docker runs as root, fine)

## 5. IMMEDIATE BUILD ERRORS (crates/memory + policy + simulation)

```
error[E0382]: use of moved value: `person_id`            → crates/memory/src/... (build fails)
error[E0425]: cannot find type `Status`/`Loyalty`/`Role`  → crates/policy, crates/simulation
error[E0432]: unresolved import `crate::error`           → crates/policy (derive macro Error missing)
```

## 6. TODOs (ordered)

- [ ] FIX memory build (`person_id` moved) → `cargo build -p bkg-memory` clean, tests pass
- [ ] FIX policy build (`crate::error` import + missing Status/Loyalty/Role) → clean
- [ ] FIX simulation build (missing Status/Loyalty/Role) → clean
- [ ] Rewrite crates/memory (store.rs): knowledge profiles, append-only,
      case≤4 / discord≤8 limits (from inventory 02-agent-memory-systems)
- [ ] Rewrite crates/rag (retrieval.rs): CJK tokenizer, exact +2/prefix +1
      scoring, citations; wire to Postgres pgvector (storage crate)
- [ ] Rewrite crates/policy (gate.rs): gate_text/gate_payload, `[KIND REDACTED]`,
      audit via JSONL (from inventory 04-policyNIM)
- [ ] Rewrite crates/simulation (generator.rs): seed 42, invariants
      250/500/8/500/3150/500, en/zh-TW (from inventory 02)
- [ ] Rewrite crates/runtime (orchestrator.rs): use cases against base traits
      (from inventory 01-mindfoundry)
- [ ] crates/app: src/lib.rs + src/main.rs — Dioxus CLI (`dx`) + web
      dashboard; consumes base+storage+rag+policy+runtime+gateway; binary `bkg`
- [ ] Gateway: add Postgres-backed auth endpoints (POST /v1/auth/register,
      /v1/auth/login, /v1/auth/logout, GET /v1/auth/me) using crates/storage Auth
- [ ] Dashboard (crates/app): login page + lanes/usage table from Postgres
      usage_ledger. NOTE: dashboard BASICS are already running — the gateway
      serves the refactored nim-proxy SPA on DASHBOARD_BIND (see §3);
      compose `dashboard` service still needs the `bkg` binary from crates/app.
- [ ] Full verification: `cargo fmt --check`, `cargo check`, `cargo test`,
      `cargo clippy -- -D warnings` across workspace
- [ ] Docker build check: `docker compose config` (syntax), then build images
- [ ] Git: add + commit per phase (crates untracked — commit incrementally)

## 7. Tested Facts (do not re-derive)

- Rust 1.97.1 available; cargo network OK.
- `cargo build -p bkg-base -p bkg-plugin-runtime -p bkg-nim -p bkg-gateway` passes.
- Gateway binary smoke test (env-provided binds, high ports 9666/9667 since
  666 needs root on dev box):
  - `GET /health` → `{"status":"ok"}`
  - `GET /v1/models` + `Authorization: Bearer npk_test` → `{"data":[{"id":"nim",...}]}`
  - no/bad auth → 401 `{"error":{"code":"invalid_api_key",...}}`
  - chat → upstream unreachable → 502 (routing works)
  - dashboard `/` → HTML table; `/metrics` → `{}`
- Commands used: `GATEWAY_BIND=127.0.0.1:9666 DASHBOARD_BIND=127.0.0.1:9667
  API_KEY=npk_test NIM_UPSTREAM=http://127.0.0.1:59999/v1 ./target/debug/bkg-gateway`
- Dashboard SPA smoke test (2026-08-14): `/` serves embedded HTML with CSP
  headers; `/api/dashboard/now` returns live snapshot (lanes with
  used/cooldown/metrics, providers, uptime); after a routed chat request the
  lane's `used`/`allowed` counters increment on next poll.

## 8. Reference Inventories (source of truth, read-only)

- `docs/inventory/01-mindfoundry/` — mindfoundry features → runtime/base
- `docs/inventory/02-rag_nim/` + `02-agent-memory-systems/` — memory/simulation
- `docs/inventory/03-nim-proxy/` — gateway design (already done)
- `docs/inventory/04-policyNIM/` — policy gate
- `docs/bkg-base-source-analysis.md`, `docs/bkg-base-architecture.md` — Gate A docs

## 9. Deploy Stack Facts

- Caddy: Let's Encrypt auto-TLS, static IPs, env-substituted Caddyfile
  (`{$API_DOMAIN}`, `{$GATEWAY_IP}`, `{$GATEWAY_PORT}` …)
- Postgres: `pgvector/pgvector:pg16`, static IP .31, port 5433, secret
  `postgres_password`, init SQL at deploy/postgres/init/001_bkg.sql
  (auth_users, auth_sessions, state_store, event_stream, rag_documents,
  rag_embeddings VECTOR(1536), usage_ledger)
- Secrets dir `deploy/secrets/` (gitignored — create from secrets.example/)
- Dockerfiles expect binaries: `bkg-gateway` (DONE), `bkg` dashboard app (TODO)
