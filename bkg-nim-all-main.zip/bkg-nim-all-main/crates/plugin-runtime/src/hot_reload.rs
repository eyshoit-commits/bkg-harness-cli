//! Hot reload: watches a plugin directory and reloads plugins on change.
//!
//! The reload loop watches a directory of plugin manifests (`*.plugin.json`).
//! When a manifest appears, disappears or changes, the registry is updated
//! accordingly. This provides config-level hot reload; WASM module
//! replacement can be layered on later.

use bkg_base::error::PluginResult;
use bkg_base::plugin::{PluginCapability, PluginDescriptor, PluginLifecycle};
use semver::Version;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::time::Duration;
use tokio::sync::mpsc;

use crate::registry::PluginRegistry;

/// A parsed plugin manifest.
#[derive(Debug, Clone, serde::Deserialize)]
pub struct PluginManifest {
    pub name: String,
    #[serde(default = "default_version")]
    pub version: String,
    pub description: String,
    #[serde(default)]
    pub capabilities: Vec<String>,
}

fn default_version() -> String {
    "0.1.0".to_string()
}

impl PluginManifest {
    pub fn to_descriptor(&self) -> PluginResult<PluginDescriptor> {
        let version = Version::parse(&self.version)
            .map_err(|e| bkg_base::error::PluginError::LoadFailed(format!("bad version: {e}")))?;
        let mut caps = Vec::new();
        for c in &self.capabilities {
            let capability = match c.as_str() {
                "inference_service" => PluginCapability::InferenceService,
                "memory_provider" => PluginCapability::MemoryProvider,
                "event_publisher" => PluginCapability::EventPublisher,
                "state_serializable" => PluginCapability::StateSerializable,
                "snapshot_codec" => PluginCapability::SnapshotCodec,
                "append_log" => PluginCapability::AppendLog,
                "state_sink" => PluginCapability::StateSink,
                "state_source" => PluginCapability::StateSource,
                other => {
                    return Err(bkg_base::error::PluginError::LoadFailed(format!(
                        "unknown capability: {other}"
                    )))
                }
            };
            caps.push(capability);
        }
        Ok(PluginDescriptor::new(
            self.name.clone(),
            version,
            self.description.clone(),
            caps,
        ))
    }
}

/// Hot reload events emitted by the watcher.
#[derive(Debug, Clone)]
pub enum ReloadEvent {
    PluginAdded(String),
    PluginRemoved(String),
    PluginChanged(String),
}

/// The hot reload driver.
///
/// Polls the plugin directory for manifest changes and applies them to the
/// registry. Manifest-only reload: registered instances are placeholders
/// that are stopped/removed/added by name. A real loader would re-instantiate
/// the plugin implementation; the factory below makes that explicit.
pub struct HotReload {
    registry: PluginRegistry,
    dir: PathBuf,
    factory: Box<dyn PluginFactory>,
}

/// Factory that turns a descriptor into a plugin instance.
pub trait PluginFactory: Send + Sync {
    fn create(&self, descriptor: &PluginDescriptor) -> PluginResult<Box<dyn PluginLifecycle>>;
}

impl HotReload {
    pub fn new(dir: impl Into<PathBuf>, factory: Box<dyn PluginFactory>) -> Self {
        Self {
            registry: PluginRegistry::new(),
            dir: dir.into(),
            factory,
        }
    }

    /// Scan the plugin directory once and apply all manifests.
    pub fn scan(&mut self) -> PluginResult<Vec<ReloadEvent>> {
        let manifests = read_manifests(&self.dir)?;
        let mut events = Vec::new();

        // Remove plugins whose manifests disappeared.
        let known: Vec<String> = self.registry.names();
        for name in known {
            if !manifests.contains_key(&name) {
                self.registry.unregister(&name)?;
                events.push(ReloadEvent::PluginRemoved(name));
            }
        }

        // Add or replace plugins.
        for (name, manifest) in manifests {
            let descriptor = manifest.to_descriptor()?;
            let exists = self.registry.descriptor(&name).is_some();
            if exists {
                // Changed: stop, unregister, re-register.
                let _ = self.registry.unregister(&name);
                let instance = self.factory.create(&descriptor)?;
                self.registry.register(descriptor, instance)?;
                self.registry.start(&name)?;
                events.push(ReloadEvent::PluginChanged(name.clone()));
            } else {
                let instance = self.factory.create(&descriptor)?;
                self.registry.register(descriptor, instance)?;
                self.registry.start(&name)?;
                events.push(ReloadEvent::PluginAdded(name.clone()));
            }
        }
        Ok(events)
    }

    /// Run the scan loop until the shutdown channel closes.
    pub async fn run(
        &mut self,
        mut shutdown: mpsc::Receiver<()>,
        poll_interval: Duration,
    ) -> PluginResult<()> {
        let mut tick = tokio::time::interval(poll_interval);
        loop {
            tokio::select! {
                _ = tick.tick() => {
                    self.scan()?;
                }
                _ = shutdown.recv() => {
                    for name in self.registry.names() {
                        let _ = self.registry.stop(&name);
                    }
                    return Ok(());
                }
            }
        }
    }

    pub fn registry(&self) -> &PluginRegistry {
        &self.registry
    }

    pub fn registry_mut(&mut self) -> &mut PluginRegistry {
        &mut self.registry
    }
}

/// Read all `*.plugin.json` manifests in a directory into a name→manifest map.
pub fn read_manifests(dir: &Path) -> PluginResult<HashMap<String, PluginManifest>> {
    let mut out = HashMap::new();
    let entries = std::fs::read_dir(dir)
        .map_err(|e| bkg_base::error::PluginError::LoadFailed(format!("read dir {dir:?}: {e}")))?;
    for entry in entries {
        let entry = entry
            .map_err(|e| bkg_base::error::PluginError::LoadFailed(format!("read entry: {e}")))?;
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        if !path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or_default()
            .ends_with(".plugin.json")
        {
            continue;
        }
        let text = std::fs::read_to_string(&path).map_err(|e| {
            bkg_base::error::PluginError::LoadFailed(format!("read {}: {e}", path.display()))
        })?;
        let manifest: PluginManifest = serde_json::from_str(&text).map_err(|e| {
            bkg_base::error::PluginError::LoadFailed(format!("parse {}: {e}", path.display()))
        })?;
        out.insert(manifest.name.clone(), manifest);
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use bkg_base::plugin::PluginState;

    #[derive(Default)]
    struct FakePlugin {
        descriptor: Option<PluginDescriptor>,
    }

    impl PluginLifecycle for FakePlugin {
        fn init(&mut self) -> PluginResult<()> {
            Ok(())
        }
        fn start(&mut self) -> PluginResult<()> {
            Ok(())
        }
        fn stop(&mut self) -> PluginResult<()> {
            Ok(())
        }
        fn health(&self) -> PluginResult<bkg_base::plugin::PluginHealth> {
            Ok(bkg_base::plugin::PluginHealth {
                status: PluginState::Running,
                version: self
                    .descriptor
                    .as_ref()
                    .map(|d| d.version.clone())
                    .unwrap_or_else(|| Version::new(0, 0, 0)),
                dependencies: vec![],
                latency_ms: 0,
            })
        }
    }

    struct FakeFactory;

    impl PluginFactory for FakeFactory {
        fn create(&self, descriptor: &PluginDescriptor) -> PluginResult<Box<dyn PluginLifecycle>> {
            let mut p = FakePlugin::default();
            p.descriptor = Some(descriptor.clone());
            Ok(Box::new(p))
        }
    }

    fn write_manifest(dir: &Path, name: &str, version: &str) {
        let manifest = serde_json::json!({
            "name": name,
            "version": version,
            "description": "test",
            "capabilities": ["memory_provider"],
        });
        std::fs::write(
            dir.join(format!("{name}.plugin.json")),
            serde_json::to_string_pretty(&manifest).unwrap(),
        )
        .unwrap();
    }

    #[test]
    fn manifest_parse_and_descriptor() {
        let m: PluginManifest = serde_json::from_str(
            r#"{"name":"x","version":"1.0.0","description":"d","capabilities":["state_sink"]}"#,
        )
        .unwrap();
        let d = m.to_descriptor().unwrap();
        assert_eq!(d.name, "x");
        assert!(d.provides(PluginCapability::StateSink));
    }

    #[test]
    fn read_manifests_filters_files() {
        let dir = tempfile::tempdir().unwrap();
        write_manifest(dir.path(), "alpha", "0.1.0");
        std::fs::write(dir.path().join("ignore.json"), "{}").unwrap();
        let manifests = read_manifests(dir.path()).unwrap();
        assert_eq!(manifests.len(), 1);
        assert!(manifests.contains_key("alpha"));
    }

    #[test]
    fn scan_adds_removes_changes() {
        let dir = tempfile::tempdir().unwrap();
        let mut reload = HotReload::new(dir.path().to_path_buf(), Box::new(FakeFactory));

        write_manifest(dir.path(), "alpha", "0.1.0");
        let events = reload.scan().unwrap();
        assert_eq!(events.len(), 1);
        assert!(matches!(events[0], ReloadEvent::PluginAdded(_)));
        assert_eq!(reload.registry().len(), 1);

        // Change version -> PluginChanged
        write_manifest(dir.path(), "alpha", "0.2.0");
        let events = reload.scan().unwrap();
        assert!(matches!(events[0], ReloadEvent::PluginChanged(_)));

        // Remove manifest -> PluginRemoved
        std::fs::remove_file(dir.path().join("alpha.plugin.json")).unwrap();
        let events = reload.scan().unwrap();
        assert!(matches!(events[0], ReloadEvent::PluginRemoved(_)));
        assert!(reload.registry().is_empty());
    }
}
