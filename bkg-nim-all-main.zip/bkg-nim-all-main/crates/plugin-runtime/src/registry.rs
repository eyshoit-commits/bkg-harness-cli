//! Plugin registry: holds descriptors and lifecycle state.

use bkg_base::error::PluginResult;
use bkg_base::plugin::{PluginDescriptor, PluginHealth, PluginLifecycle, PluginState};
use std::collections::HashMap;

/// A registered plugin instance: descriptor plus lifecycle handle.
pub struct RegisteredPlugin {
    pub descriptor: PluginDescriptor,
    pub instance: Box<dyn PluginLifecycle>,
    pub state: PluginState,
}

/// The plugin registry.
///
/// Owns plugin instances and their lifecycle state. Does not perform file
/// loading or isolation — that is the loader's job.
#[derive(Default)]
pub struct PluginRegistry {
    plugins: HashMap<String, RegisteredPlugin>,
}

impl PluginRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    /// Register and initialize a plugin.
    pub fn register(
        &mut self,
        descriptor: PluginDescriptor,
        instance: Box<dyn PluginLifecycle>,
    ) -> PluginResult<()> {
        if self.plugins.contains_key(&descriptor.name) {
            return Err(bkg_base::error::PluginError::InvalidState(format!(
                "already registered: {}",
                descriptor.name
            )));
        }
        let mut plugin = RegisteredPlugin {
            descriptor,
            instance,
            state: PluginState::Loaded,
        };
        plugin.instance.init()?;
        plugin.state = PluginState::Initializing;
        self.plugins.insert(plugin.descriptor.name.clone(), plugin);
        Ok(())
    }

    /// Start a plugin by name.
    pub fn start(&mut self, name: &str) -> PluginResult<()> {
        let plugin = self
            .plugins
            .get_mut(name)
            .ok_or_else(|| bkg_base::error::PluginError::NotFound(name.to_string()))?;
        plugin.instance.start()?;
        plugin.state = PluginState::Running;
        Ok(())
    }

    /// Start all registered plugins.
    pub fn start_all(&mut self) -> PluginResult<()> {
        let names: Vec<String> = self.plugins.keys().cloned().collect();
        for name in names {
            self.start(&name)?;
        }
        Ok(())
    }

    /// Stop a plugin by name.
    pub fn stop(&mut self, name: &str) -> PluginResult<()> {
        let plugin = self
            .plugins
            .get_mut(name)
            .ok_or_else(|| bkg_base::error::PluginError::NotFound(name.to_string()))?;
        plugin.instance.stop()?;
        plugin.state = PluginState::Stopped;
        Ok(())
    }

    /// Remove a plugin by name (stopping it first if running).
    pub fn unregister(&mut self, name: &str) -> PluginResult<RegisteredPlugin> {
        if let Some(plugin) = self.plugins.get_mut(name) {
            if plugin.state.is_running() {
                plugin.instance.stop()?;
                plugin.state = PluginState::Stopped;
            }
        }
        self.plugins
            .remove(name)
            .ok_or_else(|| bkg_base::error::PluginError::NotFound(name.to_string()))
    }

    /// Health snapshot for a plugin.
    pub fn health(&self, name: &str) -> PluginResult<PluginHealth> {
        let plugin = self
            .plugins
            .get(name)
            .ok_or_else(|| bkg_base::error::PluginError::NotFound(name.to_string()))?;
        plugin.instance.health()
    }

    /// All registered plugin names, sorted.
    pub fn names(&self) -> Vec<String> {
        let mut names: Vec<String> = self.plugins.keys().cloned().collect();
        names.sort();
        names
    }

    /// Descriptor lookup by name.
    pub fn descriptor(&self, name: &str) -> Option<&PluginDescriptor> {
        self.plugins.get(name).map(|p| &p.descriptor)
    }

    /// Current state of a plugin.
    pub fn state(&self, name: &str) -> Option<&PluginState> {
        self.plugins.get(name).map(|p| &p.state)
    }

    pub fn len(&self) -> usize {
        self.plugins.len()
    }

    pub fn is_empty(&self) -> bool {
        self.plugins.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bkg_base::error::PluginResult;
    use bkg_base::plugin::{PluginDescriptor, PluginHealth, PluginLifecycle};
    use semver::Version;

    #[derive(Default)]
    struct TestPlugin {
        init_calls: u32,
        start_calls: u32,
        stop_calls: u32,
    }

    impl PluginLifecycle for TestPlugin {
        fn init(&mut self) -> PluginResult<()> {
            self.init_calls += 1;
            Ok(())
        }
        fn start(&mut self) -> PluginResult<()> {
            self.start_calls += 1;
            Ok(())
        }
        fn stop(&mut self) -> PluginResult<()> {
            self.stop_calls += 1;
            Ok(())
        }
        fn health(&self) -> PluginResult<PluginHealth> {
            Ok(PluginHealth {
                status: PluginState::Running,
                version: Version::new(0, 1, 0),
                dependencies: vec![],
                latency_ms: 0,
            })
        }
    }

    fn descriptor(name: &str) -> PluginDescriptor {
        PluginDescriptor::new(name, Version::new(0, 1, 0), "test", vec![])
    }

    #[test]
    fn register_start_stop_unregister() {
        let mut registry = PluginRegistry::new();
        registry
            .register(descriptor("alpha"), Box::new(TestPlugin::default()))
            .unwrap();
        assert_eq!(registry.len(), 1);
        registry.start("alpha").unwrap();
        assert_eq!(registry.state("alpha"), Some(&PluginState::Running));
        registry.stop("alpha").unwrap();
        assert_eq!(registry.state("alpha"), Some(&PluginState::Stopped));
        let removed = registry.unregister("alpha").unwrap();
        assert_eq!(removed.descriptor.name, "alpha");
        assert!(registry.is_empty());
    }

    #[test]
    fn duplicate_register_rejected() {
        let mut registry = PluginRegistry::new();
        registry
            .register(descriptor("alpha"), Box::new(TestPlugin::default()))
            .unwrap();
        let err = registry.register(descriptor("alpha"), Box::new(TestPlugin::default()));
        assert!(err.is_err());
    }

    #[test]
    fn start_missing_rejected() {
        let mut registry = PluginRegistry::new();
        assert!(registry.start("missing").is_err());
    }

    #[test]
    fn names_sorted() {
        let mut registry = PluginRegistry::new();
        registry
            .register(descriptor("beta"), Box::new(TestPlugin::default()))
            .unwrap();
        registry
            .register(descriptor("alpha"), Box::new(TestPlugin::default()))
            .unwrap();
        assert_eq!(registry.names(), vec!["alpha", "beta"]);
    }
}
