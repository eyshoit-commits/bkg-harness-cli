//! Plugin runtime: registry, lifecycle management, and hot reload.
//!
//! This crate implements the plugin system behind the contracts defined in
//! [`bkg_base::plugin`]. It owns the actual [`PluginRegistry`], loading and
//! unloading, and a file-watching hot reload loop.

pub mod hot_reload;
pub mod registry;

pub use hot_reload::*;
pub use registry::*;
