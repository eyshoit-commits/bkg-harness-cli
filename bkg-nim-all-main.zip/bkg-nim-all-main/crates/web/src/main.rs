//! BKG admin UI — a Dioxus web app compiled directly to WebAssembly.
//!
//! Served by the gateway at `/` (static assets from `BKG_UI_DIR`) and
//! talks to the gateway's JSON API on the same origin, so the admin
//! session cookie flows naturally. Screens (nim-proxy feature parity):
//!
//! - Setup wizard (`POST /setup`, `POST /setup/validate-key`): claims the
//!   superuser, records initial provider keys/upstreams, optionally mints a
//!   first client key;
//! - Login (`POST /api/login`, `POST /api/logout`);
//! - Dashboard (`GET /api/dashboard/now`, polling every 2s): KPI cards +
//!   live lanes table;
//! - Settings (`GET /api/config`, `POST /api/settings/{keys,clients,account}`):
//!   provider key pools, client keys, password change.
//!
//! Cyberpunk Neon Pixel-Tech design system: void dark, cyan primary,
//! electric blue secondary, violet accent, fixed status colors, mono font.

use dioxus::prelude::*;
use gloo_timers::callback::Interval;
use serde::de::DeserializeOwned;
use serde::Deserialize;
use serde_json::{Value, json};

// ---------------------------------------------------------------------------
// Design system (Cyberpunk Neon Pixel-Tech)
// ---------------------------------------------------------------------------

const CSS: &str = r#"
:root {
  --void: #030308;
  --panel: #0A0A14;
  --line: #1A1A2E;
  --cyan: #00F5FF;
  --blue: #008CFF;
  --violet: #8A2BE2;
  --success: #00FF41;
  --warning: #FFF000;
  --critical: #FF1744;
  --offline: #526273;
  --text: #C7D3E3;
  --dim: #526273;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: var(--void); color: var(--text); font-family: "JetBrains Mono","IBM Plex Mono","Space Mono",ui-monospace,monospace; }
body { min-height: 100vh;
  background-image: linear-gradient(rgba(0,245,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(0,245,255,0.035) 1px, transparent 1px);
  background-size: 32px 32px; }
.wrap { max-width: 1280px; margin: 0 auto; padding: 24px; }
.boot { display: flex; align-items: center; justify-content: center; min-height: 60vh; font-size: 26px; letter-spacing: 6px; color: var(--cyan); text-shadow: 0 0 12px rgba(0,245,255,0.7); }
.panel { position: relative; border: 1px solid var(--line); background: var(--panel); padding: 22px; margin-bottom: 22px; }
.panel::before, .panel::after { content: ""; position: absolute; width: 12px; height: 12px; border: 2px solid var(--cyan); }
.panel::before { top: -2px; left: -2px; border-right: 0; border-bottom: 0; box-shadow: 0 0 8px rgba(0,245,255,0.6); }
.panel::after { bottom: -2px; right: -2px; border-left: 0; border-top: 0; box-shadow: 0 0 8px rgba(0,245,255,0.6); }
.title { color: var(--cyan); font-size: 15px; letter-spacing: 3px; text-transform: uppercase; margin-bottom: 16px; text-shadow: 0 0 10px rgba(0,245,255,0.5); }
.sub { color: var(--dim); font-size: 12px; letter-spacing: 2px; text-transform: uppercase; margin: 18px 0 10px; border-bottom: 1px solid var(--line); padding-bottom: 6px; }
label { display: block; color: var(--dim); font-size: 11px; letter-spacing: 2px; text-transform: uppercase; margin: 12px 0 4px; }
input, textarea { width: 100%; background: #05050C; color: var(--text); border: 1px solid var(--line); padding: 10px 12px; font-family: inherit; font-size: 13px; outline: none; }
input:focus, textarea:focus { border-color: var(--cyan); box-shadow: 0 0 10px rgba(0,245,255,0.25); }
textarea { min-height: 90px; resize: vertical; }
.row { display: flex; gap: 12px; }
.row > * { flex: 1; }
.btn { background: transparent; color: var(--cyan); border: 1px solid var(--cyan); font-family: inherit; font-size: 12px; letter-spacing: 2px; text-transform: uppercase; padding: 10px 16px; cursor: pointer; }
.btn:hover { background: rgba(0,245,255,0.12); box-shadow: 0 0 12px rgba(0,245,255,0.4); }
.btn:disabled { color: var(--offline); border-color: var(--offline); cursor: not-allowed; box-shadow: none; background: transparent; }
.btn.active { background: rgba(0,245,255,0.18); }
.btn.danger { color: var(--critical); border-color: var(--critical); }
.btn.danger:hover { background: rgba(255,23,68,0.12); box-shadow: 0 0 12px rgba(255,23,68,0.4); }
.btn.violet { color: var(--violet); border-color: var(--violet); }
.btn.violet:hover { background: rgba(138,43,226,0.15); box-shadow: 0 0 12px rgba(138,43,226,0.4); }
.top { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--line); padding-bottom: 14px; margin-bottom: 22px; }
.brand { color: var(--cyan); letter-spacing: 5px; font-size: 18px; text-shadow: 0 0 12px rgba(0,245,255,0.7); }
.top-actions { display: flex; align-items: center; gap: 10px; }
.user { color: var(--violet); font-size: 12px; letter-spacing: 2px; padding: 0 8px; }
.kpis { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 22px; }
.kpi { border: 1px solid var(--line); background: var(--panel); padding: 16px; }
.k-label { color: var(--dim); font-size: 10px; letter-spacing: 2px; text-transform: uppercase; }
.k-value { color: var(--cyan); font-size: 26px; margin-top: 6px; text-shadow: 0 0 12px rgba(0,245,255,0.5); }
.k-value.ok { color: var(--success); text-shadow: 0 0 12px rgba(0,255,65,0.5); }
.k-value.warn { color: var(--warning); text-shadow: 0 0 12px rgba(255,240,0,0.5); }
.k-value.crit { color: var(--critical); text-shadow: 0 0 12px rgba(255,23,68,0.6); }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
th { color: var(--dim); font-size: 10px; letter-spacing: 2px; text-transform: uppercase; text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--line); }
td { padding: 8px 10px; border-bottom: 1px solid #111122; vertical-align: middle; }
.lane-name { color: var(--cyan); }
.lane-upstream { color: var(--dim); font-size: 11px; word-break: break-all; }
.bar { width: 120px; height: 8px; background: #0C0C18; border: 1px solid var(--line); position: relative; }
.bar-fill { height: 100%; background: linear-gradient(90deg, var(--blue), var(--cyan)); box-shadow: 0 0 8px rgba(0,245,255,0.6); }
.led { display: inline-block; padding: 2px 8px; font-size: 10px; letter-spacing: 1px; border: 1px solid; }
.led.ready { color: var(--success); border-color: var(--success); box-shadow: 0 0 8px rgba(0,255,65,0.5); }
.led.bench { color: var(--warning); border-color: var(--warning); box-shadow: 0 0 8px rgba(255,240,0,0.5); }
.led.fault { color: var(--critical); border-color: var(--critical); box-shadow: 0 0 8px rgba(255,23,68,0.6); }
.led.off { color: var(--offline); border-color: var(--offline); }
.chip { display: inline-block; font-size: 10px; letter-spacing: 1px; padding: 2px 8px; margin-right: 6px; border: 1px solid var(--violet); color: var(--violet); }
.chip.env { border-color: var(--blue); color: var(--blue); }
.msg { margin-top: 12px; font-size: 12px; padding: 10px 12px; border: 1px solid; }
.msg.ok { color: var(--success); border-color: var(--success); }
.msg.err { color: var(--critical); border-color: var(--critical); }
.msg.info { color: var(--warning); border-color: var(--warning); }
.secret { display: block; margin-top: 8px; padding: 10px; background: #05050C; border: 1px dashed var(--success); color: var(--success); font-size: 12px; word-break: break-all; }
.muted { color: var(--dim); font-size: 11px; }
.hint { color: var(--dim); font-size: 11px; margin-top: 4px; }
"#;

// ---------------------------------------------------------------------------
// API client
// ---------------------------------------------------------------------------

async fn api<T: DeserializeOwned>(method: &str, path: &str, body: Option<Value>) -> Result<T, String> {
    let client = reqwest::Client::new();
    let mut req = client.request(
        reqwest::Method::from_bytes(method.as_bytes()).unwrap(),
        path,
    );
    if let Some(b) = body {
        req = req.json(&b);
    }
    #[cfg(target_arch = "wasm32")]
    let req = req.fetch_credentials_include();
    let resp = req.send().await.map_err(|e| format!("request failed: {e}"))?;
    let status = resp.status();
    let text = resp.text().await.map_err(|e| format!("read failed: {e}"))?;
    if !status.is_success() {
        let msg = serde_json::from_str::<Value>(&text)
            .ok()
            .and_then(|v| {
                v.get("error")
                    .and_then(|e| e.get("message"))
                    .and_then(|m| m.as_str())
                    .map(String::from)
            })
            .unwrap_or_else(|| format!("HTTP {status}: {}", text.chars().take(200).collect::<String>()));
        return Err(msg);
    }
    serde_json::from_str(&text).map_err(|e| format!("invalid response: {e}"))
}

// ---------------------------------------------------------------------------
// Wire models (mirror the gateway JSON API)
// ---------------------------------------------------------------------------

#[derive(Deserialize, Clone, Default, PartialEq)]
struct ApiConfig {
    #[serde(default)]
    setup_required: bool,
    #[serde(default)]
    version: String,
    #[serde(default)]
    providers: Vec<ProviderInfo>,
    #[serde(default)]
    clients: Vec<ClientInfo>,
    #[serde(default)]
    users: Vec<UserInfo>,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct ProviderInfo {
    #[serde(default)]
    name: String,
    #[serde(default)]
    upstream: String,
    #[serde(default)]
    keys: Vec<KeyInfo>,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct KeyInfo {
    #[serde(default)]
    source: String,
    #[serde(default)]
    name: String,
    #[serde(default)]
    fingerprint: String,
    #[serde(default)]
    last4: String,
    #[serde(default)]
    enabled: bool,
    #[serde(default)]
    rpm: usize,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct ClientInfo {
    #[serde(default)]
    id: String,
    #[serde(default)]
    last4: String,
    #[serde(default)]
    owner: String,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct UserInfo {
    #[serde(default)]
    username: String,
    #[serde(default)]
    role: String,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct DashboardNow {
    #[serde(default)]
    version: String,
    #[serde(default)]
    sampled_at: u64,
    #[serde(default)]
    uptime_secs: u64,
    #[serde(default)]
    providers: Vec<String>,
    #[serde(default)]
    lanes: Vec<LaneSnap>,
    #[serde(default)]
    totals: Totals,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct LaneSnap {
    #[serde(default)]
    name: String,
    #[serde(default)]
    provider: String,
    #[serde(default)]
    upstream_base_url: String,
    #[serde(default)]
    enabled: bool,
    #[serde(default)]
    rate_limit_per_window: usize,
    #[serde(default)]
    window_secs: u64,
    #[serde(default)]
    used: usize,
    #[serde(default)]
    cooldown_remaining_secs: u64,
    #[serde(default)]
    metrics: LaneMetrics,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct LaneMetrics {
    #[serde(default)]
    requests: u64,
    #[serde(default)]
    allowed: u64,
    #[serde(default)]
    rate_limited: u64,
    #[serde(default)]
    errors: u64,
    #[serde(default)]
    avg_latency_ms: u64,
}

#[derive(Deserialize, Clone, Default, PartialEq)]
struct Totals {
    #[serde(default)]
    lanes: usize,
    #[serde(default)]
    benched: usize,
    #[serde(default)]
    allowed: u64,
    #[serde(default)]
    rate_limited: u64,
    #[serde(default)]
    errors: u64,
}

#[derive(Deserialize, Clone, Default)]
struct ClientSecret {
    #[serde(default)]
    name: String,
    #[serde(default)]
    secret: String,
}

#[derive(Deserialize, Clone, Default)]
struct SetupResp {
    #[serde(default)]
    ok: bool,
    #[serde(default)]
    client_key: Option<ClientSecret>,
}

#[derive(Deserialize, Clone, Default)]
struct MintResp {
    #[serde(default)]
    ok: bool,
    #[serde(default)]
    client_key: Option<ClientSecret>,
}

#[derive(Deserialize, Clone, Default)]
struct ValidateResp {
    #[serde(default)]
    ok: bool,
    #[serde(default)]
    error: String,
    #[serde(default)]
    models: Vec<String>,
    #[serde(default)]
    provider: String,
}

// ---------------------------------------------------------------------------
// App shell
// ---------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq)]
enum Screen {
    Loading,
    Setup,
    Login,
    Dashboard,
    Settings,
}

fn main() {
    dioxus::launch(App);
}

fn App() -> Element {
    let mut screen = use_signal(|| Screen::Loading);
    let mut user = use_signal(|| String::new());

    // Boot probe: the gateway tells us whether setup is still pending.
    use_effect(move || {
        let mut screen = screen.clone();
        spawn(async move {
            match api::<ApiConfig>("GET", "/api/config", None).await {
                Ok(cfg) => {
                    screen.set(if cfg.setup_required { Screen::Setup } else { Screen::Dashboard });
                }
                Err(_) => screen.set(Screen::Login),
            }
        });
    });

    rsx! {
        style { "{CSS}" }
        div { class: "wrap",
            match screen() {
                Screen::Loading => rsx! { div { class: "boot", "BKG GATEWAY" } },
                Screen::Setup => rsx! { SetupWizard { on_done: move |_| screen.set(Screen::Dashboard) } },
                Screen::Login => rsx! { LoginScreen { on_ok: move |u| { user.set(u); screen.set(Screen::Dashboard); } } },
                Screen::Dashboard => rsx! {
                    Header { user: user(), screen: screen }
                    DashboardScreen {}
                },
                Screen::Settings => rsx! {
                    Header { user: user(), screen: screen }
                    SettingsScreen {}
                },
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Header + navigation
// ---------------------------------------------------------------------------

#[component]
fn Header(user: String, mut screen: Signal<Screen>) -> Element {
    let busy = use_signal(|| false);
    let msg = use_signal(|| None::<String>);
    rsx! {
        header { class: "top",
            div { class: "brand", "BKG GATEWAY" }
            div { class: "top-actions",
                button { class: if screen() == Screen::Dashboard { "btn active" } else { "btn" },
                    onclick: move |_| screen.set(Screen::Dashboard), "DASHBOARD" }
                button { class: if screen() == Screen::Settings { "btn active" } else { "btn" },
                    onclick: move |_| screen.set(Screen::Settings), "SETTINGS" }
                span { class: "user", "{user}" }
                button { class: "btn danger", disabled: busy(),
                    onclick: move |_| {
                        let mut screen = screen.clone();
                        let mut busy = busy.clone();
                        let mut msg = msg.clone();
                        spawn(async move {
                            busy.set(true);
                            match api::<Value>("POST", "/api/logout", None).await {
                                Ok(_) => screen.set(Screen::Login),
                                Err(e) => msg.set(Some(e)),
                            }
                            busy.set(false);
                        });
                    },
                    "LOGOUT" }
            }
        }
        if let Some(e) = msg() {
            div { class: "msg err", "{e}" }
        }
    }
}

// ---------------------------------------------------------------------------
// Setup wizard (first run)
// ---------------------------------------------------------------------------

#[derive(Clone)]
struct ProviderForm {
    name: String,
    upstream: String,
    keys_text: String,
    rpm: String,
    validate_ok: bool,
    validate_msg: String,
}

impl ProviderForm {
    fn new(name: String, upstream: String) -> Self {
        Self {
            name,
            upstream,
            keys_text: String::new(),
            rpm: String::new(),
            validate_ok: false,
            validate_msg: String::new(),
        }
    }
}

#[derive(Clone)]
struct SetupForm {
    username: String,
    password: String,
    create_client: bool,
    client_name: String,
    seeded: bool,
    providers: Vec<ProviderForm>,
}

impl Default for SetupForm {
    fn default() -> Self {
        Self {
            username: String::new(),
            password: String::new(),
            create_client: false,
            client_name: String::new(),
            seeded: false,
            providers: Vec::new(),
        }
    }
}

#[derive(Clone, PartialEq)]
enum WizardStatus {
    Idle,
    Busy,
    Err(String),
    Done(Option<String>), // minted client secret, if any
}

#[component]
fn SetupWizard(on_done: EventHandler<()>) -> Element {
    let form = use_signal(SetupForm::default);
    let status = use_signal(|| WizardStatus::Idle);
    let cfg = use_resource(|| async move { api::<ApiConfig>("GET", "/api/config", None).await });

    // Seed the provider list from the registry once it arrives.
    use_effect(move || {
        if let Some(Ok(c)) = cfg.value()() {
            let mut f = form.write();
            if !f.seeded {
                f.seeded = true;
                f.providers = c
                    .providers
                    .iter()
                    .map(|p| ProviderForm::new(p.name.clone(), p.upstream.clone()))
                    .collect();
            }
        }
    });

    let validate_provider = move |idx: usize| {
        let mut status = status.clone();
        let mut form = form.clone();
        spawn(async move {
            status.set(WizardStatus::Busy);
            let snapshot = form.read().clone();
            let p = &snapshot.providers[idx];
            let key = p
                .keys_text
                .lines()
                .map(str::trim)
                .find(|l| !l.is_empty())
                .unwrap_or_default()
                .to_owned();
            let result = if key.is_empty() {
                Err("enter a key first".to_string())
            } else {
                api::<ValidateResp>(
                    "POST",
                    "/setup/validate-key",
                    Some(json!({ "key": key, "provider": p.name })),
                )
                .await
                .map(|v| {
                    if v.ok {
                        Ok(format!("OK — {} models", v.models.len()))
                    } else {
                        Err(v.error)
                    }
                })
            };
            match result {
                Ok(Ok(msg)) => {
                    form.write().providers[idx].validate_ok = true;
                    form.write().providers[idx].validate_msg = msg;
                    status.set(WizardStatus::Idle);
                }
                Ok(Err(e)) => {
                    form.write().providers[idx].validate_ok = false;
                    form.write().providers[idx].validate_msg = e;
                    status.set(WizardStatus::Idle);
                }
                Err(e) => {
                    form.write().providers[idx].validate_ok = false;
                    form.write().providers[idx].validate_msg = e;
                    status.set(WizardStatus::Idle);
                }
            }
        });
    };

    let submit = move |_| {
        let mut status = status.clone();
        let mut form = form.clone();
        spawn(async move {
            status.set(WizardStatus::Busy);
            let snapshot = form.read().clone();
            let providers: Vec<Value> = snapshot
                .providers
                .iter()
                .filter(|p| !p.keys_text.trim().is_empty())
                .map(|p| {
                    json!({
                        "name": p.name,
                        "upstream": if p.upstream.trim().is_empty() { None } else { Some(p.upstream.trim()) },
                        "keys": p.keys_text.lines().map(str::trim).filter(|l| !l.is_empty()).map(|l| json!({ "key": l })).collect::<Vec<_>>(),
                    })
                })
                .collect();
            let body = json!({
                "username": snapshot.username,
                "password": snapshot.password,
                "providers": providers,
                "create_client_key": if snapshot.create_client {
                    Some(json!({ "name": if snapshot.client_name.trim().is_empty() { "default" } else { snapshot.client_name.trim() } }))
                } else { None },
            });
            match api::<SetupResp>("POST", "/setup", Some(body)).await {
                Ok(resp) => {
                    status.set(WizardStatus::Done(resp.client_key.map(|k| k.secret)));
                }
                Err(e) => status.set(WizardStatus::Err(e)),
            }
        });
    };

    rsx! {
        div { class: "panel",
            div { class: "title", "▮ BKG GATEWAY — INITIAL SETUP" }
            div { class: "hint", "First run: claim the superuser account, record the provider key pools, and (optionally) mint the first client key for /v1. The API stays closed until this completes." }

            label { "Superuser username" }
            input { value: form.read().username, oninput: move |evt| form.write().username = evt.value() }
            label { "Superuser password (min 10 chars)" }
            input { value: form.read().password, r#type: "password", oninput: move |evt| form.write().password = evt.value() }

            if form.read().providers.is_empty() {
                div { class: "hint", "Loading provider registry…" }
            } else {
                for (idx, p) in form.read().providers.iter().cloned().enumerate() {
                    div { key: "{p.name}",
                        div { class: "sub", "PROVIDER ▸ {p.name}" }
                        label { "Upstream base URL (optional override)" }
                        input { value: p.upstream, oninput: move |evt| form.write().providers[idx].upstream = evt.value() }
                        label { "API keys — one per line (one lane per key)" }
                        textarea { value: p.keys_text, oninput: move |evt| form.write().providers[idx].keys_text = evt.value() }
                        div { class: "row",
                            input { value: p.rpm, placeholder: "rpm tier (default 40)", oninput: move |evt| form.write().providers[idx].rpm = evt.value() }
                            button { class: "btn", disabled: status() == WizardStatus::Busy, onclick: move |_| validate_provider(idx), "VALIDATE KEY" }
                        }
                        if !p.validate_msg.is_empty() {
                            div { class: if p.validate_ok { "msg ok" } else { "msg err" }, "{p.validate_msg}" }
                        }
                    }
                }
            }

            div { class: "sub", "FIRST CLIENT KEY" }
            div { class: "hint", "Optional: mint one /v1 client key during setup so the gateway can serve requests immediately." }
            label { "Mint a client key" }
            input { r#type: "checkbox", checked: form.read().create_client, onchange: move |evt| form.write().create_client = evt.checked() }
            if form.read().create_client {
                label { "Client key name" }
                input { value: form.read().client_name, oninput: move |evt| form.write().client_name = evt.value() }
            }

            div { class: "row", style: "margin-top: 20px",
                button { class: "btn", disabled: status() == WizardStatus::Busy, onclick: submit, "CLAIM SUPERUSER & START" }
            }

            match status() {
                WizardStatus::Idle => rsx! {},
                WizardStatus::Busy => rsx! { div { class: "msg info", "Working…" } },
                WizardStatus::Err(e) => rsx! { div { class: "msg err", "{e}" } },
                WizardStatus::Done(secret) => rsx! {
                    div { class: "msg ok", "Setup complete. The superuser is registered and a session was minted." }
                    if let Some(s) = secret {
                        div { class: "secret", "CLIENT KEY (shown once): {s}" }
                    }
                    button { class: "btn", onclick: move |_| on_done.call(()), "ENTER DASHBOARD" }
                },
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

#[component]
fn LoginScreen(on_ok: EventHandler<String>) -> Element {
    let mut username = use_signal(String::new);
    let mut password = use_signal(String::new);
    let busy = use_signal(|| false);
    let err = use_signal(|| None::<String>);

    let do_login = move |_| {
        let mut busy = busy.clone();
        let mut err = err.clone();
        let username = username.clone();
        let password = password.clone();
        spawn(async move {
            busy.set(true);
            match api::<Value>("POST", "/api/login", Some(json!({ "username": username(), "password": password() }))).await {
                Ok(_) => {
                    let u = username();
                    on_ok.call(u);
                }
                Err(e) => err.set(Some(e)),
            }
            busy.set(false);
        });
    };

    rsx! {
        div { class: "panel", style: "max-width: 480px; margin: 10vh auto",
            div { class: "title", "▮ BKG GATEWAY — ADMIN LOGIN" }
            label { "Username" }
            input { value: username(), oninput: move |evt| username.set(evt.value()) }
            label { "Password" }
            input { value: password(), r#type: "password", oninput: move |evt| password.set(evt.value()) }
            button { class: "btn", style: "margin-top: 20px; width: 100%", disabled: busy(), onclick: do_login, "LOGIN" }
            if let Some(e) = err() {
                div { class: "msg err", "{e}" }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

#[component]
fn DashboardScreen() -> Element {
    let tick = use_signal(|| 0u64);
    use_effect(move || {
        let mut tick = tick.clone();
        let handle = Interval::new(2_000, move || {
            tick += 1;
        });
        handle.forget();
    });
    let dash = use_resource(move || async move {
        let _ = tick();
        api::<DashboardNow>("GET", "/api/dashboard/now", None).await
    });

    let data: Option<DashboardNow> = match dash.value()() {
        Some(Ok(d)) => Some(d),
        _ => None,
    };
    let meta: Option<String> = data.as_ref().map(|d| {
        format!("gateway v{} · providers: {}", d.version, d.providers.join(", "))
    });

    rsx! {
        div { class: "panel",
            div { class: "title", "▮ LIVE LANE TELEMETRY" }
            match data {
                None => rsx! { div { class: "hint", "Loading…" } },
                Some(d) => rsx! {
                    div { class: "kpis",
                        Kpi { label: "LANES", value: format!("{}", d.totals.lanes), cls: "" }
                        Kpi { label: "ALLOWED", value: format!("{}", d.totals.allowed), cls: "ok" }
                        Kpi { label: "LIMITED", value: format!("{}", d.totals.rate_limited), cls: if d.totals.rate_limited > 0 { "warn" } else { "" } }
                        Kpi { label: "BENCHED", value: format!("{}", d.totals.benched), cls: if d.totals.benched > 0 { "warn" } else { "" } }
                        Kpi { label: "ERRORS", value: format!("{}", d.totals.errors), cls: if d.totals.errors > 0 { "crit" } else { "" } }
                        Kpi { label: "UPTIME", value: fmt_uptime(d.uptime_secs), cls: "" }
                    }
                    if let Some(m) = &meta {
                        div { class: "hint", "{m}" }
                    }
                    table {
                        thead {
                            tr {
                                th { "LANE" } th { "PROVIDER" } th { "UPSTREAM" } th { "LOAD" } th { "RPM" }
                                th { "ALLOWED" } th { "LIMITED" } th { "ERRORS" } th { "LATENCY" } th { "STATUS" }
                            }
                        }
                        tbody {
                            for lane in d.lanes.iter().filter(|l| l.enabled) {
                                LaneRow { lane: lane.clone() }
                            }
                            for lane in d.lanes.iter().filter(|l| !l.enabled) {
                                LaneRow { lane: lane.clone() }
                            }
                        }
                    }
                },
            }
        }
    }
}

#[component]
fn Kpi(label: String, value: String, cls: String) -> Element {
    rsx! {
        div { class: "kpi",
            div { class: "k-label", "{label}" }
            div { class: "k-value {cls}", "{value}" }
        }
    }
}

#[component]
fn LaneRow(lane: LaneSnap) -> Element {
    let load_pct = (lane.used as f64 / 61.0 * 100.0).min(100.0) as u64;
    let (led_cls, led_txt) = if !lane.enabled {
        ("off", "OFF")
    } else if lane.cooldown_remaining_secs > 0 {
        ("bench", "BENCH")
    } else if lane.metrics.errors > 0 {
        ("fault", "FAULT")
    } else {
        ("ready", "READY")
    };
    rsx! {
        tr {
            td { class: "lane-name", "{lane.name}" }
            td { "{lane.provider}" }
            td { class: "lane-upstream", "{lane.upstream_base_url}" }
            td {
                div { class: "bar",
                    div { class: "bar-fill", style: "width: {load_pct}%" }
                }
                div { class: "muted", "{lane.used} in 61s" }
            }
            td { "{lane.rate_limit_per_window}" }
            td { "{lane.metrics.allowed}" }
            td { "{lane.metrics.rate_limited}" }
            td { "{lane.metrics.errors}" }
            td { "{lane.metrics.avg_latency_ms}ms" }
            td {
                span { class: "led {led_cls}", "{led_txt}" }
                if lane.cooldown_remaining_secs > 0 {
                    div { class: "muted", "retry in {lane.cooldown_remaining_secs}s" }
                }
            }
        }
    }
}

fn fmt_uptime(secs: u64) -> String {
    let d = secs / 86400;
    let h = (secs % 86400) / 3600;
    let m = (secs % 3600) / 60;
    if d > 0 {
        format!("{d}d{h}h")
    } else if h > 0 {
        format!("{h}h{m}m")
    } else {
        format!("{m}m{}s", secs % 60)
    }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

#[component]
fn SettingsScreen() -> Element {
    let rev = use_signal(|| 0u64);
    let cfg = use_resource(move || async move {
        let _ = rev();
        api::<ApiConfig>("GET", "/api/config", None).await
    });

    rsx! {
        div { class: "panel",
            div { class: "title", "▮ SETTINGS — PROVIDER KEY POOLS" }
            match cfg.value()() {
                None => rsx! { div { class: "hint", "Loading…" } },
                Some(Err(e)) => rsx! { div { class: "msg err", "{e}" } },
                Some(Ok(c)) => rsx! {
                    for p in c.providers.clone() {
                        ProviderPanel { provider: p, on_changed: move |_| { let mut rev = rev.clone(); rev += 1; } }
                    }
                },
            }
        }
        div { class: "panel",
            div { class: "title", "▮ SETTINGS — CLIENT KEYS" }
            match cfg.value()() {
                None => rsx! {},
                Some(Ok(c)) => rsx! { ClientsPanel { clients: c.clients.clone(), on_changed: move |_| { let mut rev = rev.clone(); rev += 1; } } },
                Some(Err(_)) => rsx! {},
            }
        }
        div { class: "panel",
            div { class: "title", "▮ SETTINGS — ACCOUNT" }
            AccountPanel {}
        }
    }
}

/// POST a provider key-pool mutation (`add` / `enable` / `disable` / `delete`).
async fn key_pool_action(
    provider: String,
    action: &'static str,
    key: Option<String>,
    rpm: Option<usize>,
    fingerprint: Option<String>,
) -> Result<Value, String> {
    let mut body = json!({ "provider": provider, "action": action });
    if let Some(k) = key {
        body["key"] = json!(k);
    }
    if let Some(r) = rpm {
        body["rpm"] = json!(r);
    }
    if let Some(f) = fingerprint {
        body["fingerprint"] = json!(f);
    }
    api::<Value>("POST", "/api/settings/keys", Some(body)).await
}

#[component]
fn ProviderPanel(provider: ProviderInfo, on_changed: EventHandler<()>) -> Element {
    let mut key_input = use_signal(String::new);
    let mut rpm_input = use_signal(|| String::new());
    let msg = use_signal(|| None::<(bool, String)>);
    let provider_name = use_signal(|| provider.name.clone());

    rsx! {
        div { class: "sub", "PROVIDER ▸ {provider.name}" }
        div { class: "hint", "upstream: {provider.upstream}" }
        if provider.keys.is_empty() {
            div { class: "muted", "no keys configured" }
        } else {
            table {
                thead { tr { th { "KEY" } th { "SRC" } th { "LAST4" } th { "RPM" } th { "STATE" } th { "" } } }
                tbody {
                    for k in provider.keys.clone() {
                        KeyRow { key_info: k, provider_name: provider_name, on_changed: on_changed }
                    }
                }
            }
        }
        div { class: "row", style: "margin-top: 12px",
            input { value: key_input(), placeholder: "new API key", oninput: move |evt| key_input.set(evt.value()) }
            input { value: rpm_input(), placeholder: "rpm (default 40)", oninput: move |evt| rpm_input.set(evt.value()) }
            button { class: "btn", onclick: move |_| {
                let key = key_input();
                let rpm = rpm_input().parse::<usize>().ok();
                let mut msg = msg.clone();
                let on_changed = on_changed.clone();
                let pn = provider_name();
                spawn(async move {
                    match key_pool_action(pn, "add", Some(key), rpm, None).await {
                        Ok(_) => {
                            msg.set(Some((true, "saved".to_string())));
                            on_changed.call(());
                        }
                        Err(e) => msg.set(Some((false, e))),
                    }
                });
                key_input.set(String::new());
                rpm_input.set(String::new());
            }, "ADD KEY" }
        }
        if let Some((ok, m)) = msg() {
            div { class: if ok { "msg ok" } else { "msg err" }, "{m}" }
        }
    }
}

/// One row in the provider key table; owns its own error/success message so
/// the enable/disable/delete buttons can each fire an independent mutation.
#[component]
fn KeyRow(key_info: KeyInfo, provider_name: Signal<String>, on_changed: EventHandler<()>) -> Element {
    let msg = use_signal(|| None::<(bool, String)>);
    let fp_sig = use_signal(|| key_info.fingerprint.clone());
    let key_name = if key_info.fingerprint.is_empty() {
        key_info.name.clone()
    } else {
        key_info.fingerprint.clone()
    };
    let last4 = key_info.last4.clone();
    let source = key_info.source.clone();
    let rpm = key_info.rpm;
    let enabled = key_info.enabled;

    rsx! {
        tr {
            td { class: "lane-name", "{key_name}" }
            td { span { class: "chip {source}", "{source}" } }
            td { "{last4}" }
            td { "{rpm}" }
            td {
                span { class: if enabled { "led ready" } else { "led off" }, if enabled { "ON" } else { "OFF" } }
            }
            td {
                if source == "runtime" {
                    button { class: "btn", style: "margin-right: 6px", onclick: move |_| {
                        let mut msg = msg.clone();
                        let on_changed = on_changed.clone();
                        let pn = provider_name();
                        let fp = fp_sig();
                        spawn(async move {
                            match key_pool_action(pn, "enable", None, None, Some(fp)).await {
                                Ok(_) => {
                                    msg.set(Some((true, "saved".to_string())));
                                    on_changed.call(());
                                }
                                Err(e) => msg.set(Some((false, e))),
                            }
                        });
                    }, "ENABLE" }
                    button { class: "btn", style: "margin-right: 6px", onclick: move |_| {
                        let mut msg = msg.clone();
                        let on_changed = on_changed.clone();
                        let pn = provider_name();
                        let fp = fp_sig();
                        spawn(async move {
                            match key_pool_action(pn, "disable", None, None, Some(fp)).await {
                                Ok(_) => {
                                    msg.set(Some((true, "saved".to_string())));
                                    on_changed.call(());
                                }
                                Err(e) => msg.set(Some((false, e))),
                            }
                        });
                    }, "DISABLE" }
                    button { class: "btn danger", onclick: move |_| {
                        let mut msg = msg.clone();
                        let on_changed = on_changed.clone();
                        let pn = provider_name();
                        let fp = fp_sig();
                        spawn(async move {
                            match key_pool_action(pn, "delete", None, None, Some(fp)).await {
                                Ok(_) => {
                                    msg.set(Some((true, "deleted".to_string())));
                                    on_changed.call(());
                                }
                                Err(e) => msg.set(Some((false, e))),
                            }
                        });
                    }, "DELETE" }
                } else {
                    span { class: "muted", "env-managed" }
                }
            }
        }
        if let Some((ok, m)) = msg() {
            tr {
                td { colspan: "6", class: if ok { "msg ok" } else { "msg err" }, "{m}" }
            }
        }
    }
}

#[component]
fn ClientsPanel(clients: Vec<ClientInfo>, on_changed: EventHandler<()>) -> Element {
    let mut name = use_signal(String::new);
    let msg = use_signal(|| None::<(bool, String)>);
    let secret = use_signal(|| None::<String>);

    rsx! {
        div { class: "hint", "Client keys authenticate /v1 requests (Bearer). The secret is shown exactly once at mint time." }
        if clients.is_empty() {
            div { class: "muted", "no client keys yet" }
        } else {
            table {
                thead { tr { th { "NAME" } th { "LAST4" } th { "OWNER" } } }
                tbody {
                    for c in clients.clone() {
                        tr { td { class: "lane-name", "{c.id}" } td { "{c.last4}" } td { "{c.owner}" } }
                    }
                }
            }
        }
        div { class: "row", style: "margin-top: 12px",
            input { value: name(), placeholder: "client name", oninput: move |evt| name.set(evt.value()) }
            button { class: "btn", onclick: move |_| {
                let mut msg = msg.clone();
                let mut secret = secret.clone();
                let name_val = name();
                spawn(async move {
                    match api::<MintResp>("POST", "/api/settings/clients", Some(json!({ "name": name_val }))).await {
                        Ok(resp) => {
                            if let Some(ck) = resp.client_key {
                                secret.set(Some(ck.secret));
                                msg.set(Some((true, "client key minted".to_string())));
                                on_changed.call(());
                            }
                        }
                        Err(e) => msg.set(Some((false, e))),
                    }
                });
                name.set(String::new());
            }, "MINT CLIENT KEY" }
        }
        if let Some(s) = secret() {
            div { class: "secret", "CLIENT KEY (shown once): {s}" }
        }
        if let Some((ok, m)) = msg() {
            div { class: if ok { "msg ok" } else { "msg err" }, "{m}" }
        }
    }
}

#[component]
fn AccountPanel() -> Element {
    let mut current = use_signal(String::new);
    let mut new_pw = use_signal(String::new);
    let msg = use_signal(|| None::<(bool, String)>);

    rsx! {
        div { class: "hint", "Changing the password invalidates every existing session (the session token is bound to the password generation)." }
        label { "Current password" }
        input { value: current(), r#type: "password", oninput: move |evt| current.set(evt.value()) }
        label { "New password (min 10 chars)" }
        input { value: new_pw(), r#type: "password", oninput: move |evt| new_pw.set(evt.value()) }
        button { class: "btn", style: "margin-top: 16px", onclick: move |_| {
            let mut msg = msg.clone();
            let current_val = current();
            let new_val = new_pw();
            spawn(async move {
                match api::<Value>("POST", "/api/settings/account", Some(json!({ "current_password": current_val, "new_password": new_val }))).await {
                    Ok(_) => { msg.set(Some((true, "password changed — other sessions are invalidated".to_string()))); }
                    Err(e) => msg.set(Some((false, e))),
                }
            });
            current.set(String::new());
            new_pw.set(String::new());
        }, "CHANGE PASSWORD" }
        if let Some((ok, m)) = msg() {
            div { class: if ok { "msg ok" } else { "msg err" }, "{m}" }
        }
    }
}
