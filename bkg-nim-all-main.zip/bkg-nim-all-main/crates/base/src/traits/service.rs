//! Service traits: inference and provider-independent capabilities.

use crate::error::CoreResult;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};

/// A request for model inference.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InferenceRequest {
    pub prompt: String,
    pub system: Option<String>,
    pub max_tokens: Option<u32>,
    pub temperature: Option<f64>,
}

/// The result of a model inference call.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InferenceResponse {
    pub text: String,
    pub finish_reason: String,
    pub usage: Option<Usage>,
}

/// Token usage counters.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Usage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub total_tokens: u32,
}

/// Provider-independent inference capability.
///
/// Implemented by provider plugins (e.g. NVIDIA NIM) — never by the kernel.
#[async_trait]
pub trait InferenceService: Send + Sync {
    async fn complete(&self, request: InferenceRequest) -> CoreResult<InferenceResponse>;
}

/// A structured query for knowledge retrieval.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct KnowledgeQuery {
    pub text: String,
    pub limit: Option<usize>,
}

/// A stored knowledge record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct KnowledgeRecord {
    pub key: String,
    pub content: String,
    pub metadata: serde_json::Value,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn request_roundtrips() {
        let r = InferenceRequest {
            prompt: "hi".into(),
            system: Some("be concise".into()),
            max_tokens: Some(64),
            temperature: Some(0.2),
        };
        let json = serde_json::to_string(&r).unwrap();
        let back: InferenceRequest = serde_json::from_str(&json).unwrap();
        assert_eq!(r, back);
    }
}
