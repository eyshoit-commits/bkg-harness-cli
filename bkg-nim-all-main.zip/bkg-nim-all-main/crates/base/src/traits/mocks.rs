//! Deterministic mock implementations of all foundation traits.
//!
//! Mocks return deterministic, testable results and have no external
//! dependencies. They exist so downstream crates and tests can exercise
//! behavior without real providers.

use crate::error::{CoreError, CoreResult};
use crate::events::{EventEnvelope, EventFilter, EventStream};
use crate::traits::{
    AppendLog, EventPublisher, InferenceRequest, InferenceResponse, KnowledgeQuery,
    KnowledgeRecord, MemoryProvider, SnapshotCodec, StateSerializable, StateSink, StateSource,
};
use async_trait::async_trait;
use std::sync::{Arc, Mutex};

/// In-memory [`InferenceService`](crate::traits::InferenceService) mock.
///
/// Returns `"mock:<prompt>"` with deterministic usage counters.
#[derive(Debug, Default, Clone)]
pub struct MockInferenceService {
    pub calls: Arc<Mutex<usize>>,
}

#[async_trait]
impl crate::traits::InferenceService for MockInferenceService {
    async fn complete(&self, request: InferenceRequest) -> CoreResult<InferenceResponse> {
        *self.calls.lock().unwrap() += 1;
        let tokens = request.prompt.chars().count() as u32;
        Ok(InferenceResponse {
            text: format!("mock:{}", request.prompt),
            finish_reason: "stop".into(),
            usage: Some(crate::traits::Usage {
                prompt_tokens: tokens,
                completion_tokens: 4,
                total_tokens: tokens + 4,
            }),
        })
    }
}

/// In-memory [`MemoryProvider`] mock with a bounded record map.
#[derive(Debug, Default, Clone)]
pub struct MockMemoryProvider {
    records: Arc<Mutex<Vec<KnowledgeRecord>>>,
}

impl MockMemoryProvider {
    pub fn with_records(records: Vec<KnowledgeRecord>) -> Self {
        Self {
            records: Arc::new(Mutex::new(records)),
        }
    }
}

#[async_trait]
impl MemoryProvider for MockMemoryProvider {
    async fn store(&self, record: KnowledgeRecord) -> CoreResult<()> {
        self.records.lock().unwrap().push(record);
        Ok(())
    }

    async fn search(&self, query: KnowledgeQuery) -> CoreResult<Vec<KnowledgeRecord>> {
        let needle = query.text.to_lowercase();
        let limit = query.limit.unwrap_or(10);
        let hits: Vec<KnowledgeRecord> = self
            .records
            .lock()
            .unwrap()
            .iter()
            .filter(|r| r.content.to_lowercase().contains(&needle))
            .take(limit)
            .cloned()
            .collect();
        Ok(hits)
    }
}

/// In-memory [`EventPublisher`] mock. Subscriptions receive a live stream
/// fed by a broadcast channel; publishes fan out to all subscribers.
#[derive(Debug, Clone)]
pub struct MockEventPublisher {
    tx: tokio::sync::broadcast::Sender<EventEnvelope>,
    published: Arc<Mutex<Vec<EventEnvelope>>>,
}

impl Default for MockEventPublisher {
    fn default() -> Self {
        let (tx, _rx) = tokio::sync::broadcast::channel(256);
        Self {
            tx,
            published: Arc::new(Mutex::new(Vec::new())),
        }
    }
}

#[async_trait]
impl EventPublisher for MockEventPublisher {
    async fn publish(&self, event: EventEnvelope) -> crate::error::EventResult<()> {
        self.published.lock().unwrap().push(event.clone());
        let _ = self.tx.send(event);
        Ok(())
    }

    async fn subscribe(&self, _filter: EventFilter) -> crate::error::EventResult<EventStream> {
        let mut rx = self.tx.subscribe();
        Ok(Box::pin(async_stream::stream! {
            loop {
                match rx.recv().await {
                    Ok(envelope) => yield envelope,
                    Err(tokio::sync::broadcast::error::RecvError::Closed) => break,
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                }
            }
        }))
    }
}

impl MockEventPublisher {
    pub fn published_count(&self) -> usize {
        self.published.lock().unwrap().len()
    }
}

/// In-memory [`StateSink`]/[`StateSource`] mock pair backed by the same value.
#[derive(Debug, Clone)]
pub struct MockStateStore {
    state: Arc<Mutex<Option<serde_json::Value>>>,
}

impl Default for MockStateStore {
    fn default() -> Self {
        Self {
            state: Arc::new(Mutex::new(None)),
        }
    }
}

#[async_trait]
impl StateSink for MockStateStore {
    async fn write(&self, state: &serde_json::Value) -> CoreResult<()> {
        *self.state.lock().unwrap() = Some(state.clone());
        Ok(())
    }
}

#[async_trait]
impl StateSource for MockStateStore {
    async fn read(&self) -> CoreResult<serde_json::Value> {
        self.state
            .lock()
            .unwrap()
            .clone()
            .ok_or_else(|| CoreError::Validation("no state written".into()))
    }
}

/// In-memory [`SnapshotCodec`] mock.
#[derive(Debug, Default, Clone)]
pub struct MockSnapshotCodec {
    snapshot: Arc<Mutex<Option<Vec<u8>>>>,
}

#[async_trait]
impl SnapshotCodec for MockSnapshotCodec {
    async fn write_snapshot(&self, data: &[u8]) -> CoreResult<()> {
        *self.snapshot.lock().unwrap() = Some(data.to_vec());
        Ok(())
    }

    async fn read_snapshot(&self) -> CoreResult<Vec<u8>> {
        self.snapshot
            .lock()
            .unwrap()
            .clone()
            .ok_or_else(|| CoreError::Validation("no snapshot".into()))
    }
}

/// In-memory [`AppendLog`] mock.
#[derive(Debug, Default, Clone)]
pub struct MockAppendLog {
    entries: Arc<Mutex<Vec<Vec<u8>>>>,
}

impl MockAppendLog {
    pub fn entries(&self) -> Vec<Vec<u8>> {
        self.entries.lock().unwrap().clone()
    }
}

#[async_trait]
impl AppendLog for MockAppendLog {
    async fn append(&self, entry: &[u8]) -> CoreResult<()> {
        self.entries.lock().unwrap().push(entry.to_vec());
        Ok(())
    }
}

/// In-memory [`StateSerializable`] mock.
#[derive(Debug, Default, Clone)]
pub struct MockStateSerializable {
    data: Arc<Mutex<Vec<u8>>>,
}

impl MockStateSerializable {
    pub fn new(data: Vec<u8>) -> Self {
        Self {
            data: Arc::new(Mutex::new(data)),
        }
    }
}

#[async_trait]
impl StateSerializable for MockStateSerializable {
    async fn serialize(&self) -> CoreResult<Vec<u8>> {
        Ok(self.data.lock().unwrap().clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::events::{EventEnvelope, EventType};
    use crate::traits::InferenceService;
    use async_trait::async_trait;
    use futures::StreamExt;

    #[tokio::test]
    async fn mock_inference_is_deterministic() {
        let mock = MockInferenceService::default();
        let request = InferenceRequest {
            prompt: "ping".into(),
            system: None,
            max_tokens: None,
            temperature: None,
        };
        let r1 = mock.complete(request.clone()).await.unwrap();
        let r2 = mock.complete(request).await.unwrap();
        assert_eq!(r1, r2);
        assert_eq!(r1.text, "mock:ping");
        assert_eq!(*mock.calls.lock().unwrap(), 2);
    }

    #[tokio::test]
    async fn mock_memory_filters_by_content() {
        let mock = MockMemoryProvider::with_records(vec![
            KnowledgeRecord {
                key: "k1".into(),
                content: "allergy: peanuts".into(),
                metadata: serde_json::json!({}),
            },
            KnowledgeRecord {
                key: "k2".into(),
                content: "preference: window seat".into(),
                metadata: serde_json::json!({}),
            },
        ]);
        let hits = mock
            .search(KnowledgeQuery {
                text: "allergy".into(),
                limit: None,
            })
            .await
            .unwrap();
        assert_eq!(hits.len(), 1);
        assert_eq!(hits[0].key, "k1");
    }

    #[tokio::test]
    async fn mock_publisher_counts_and_delivers() {
        let mock = MockEventPublisher::default();
        let mut sub = mock.subscribe(EventFilter::default()).await.unwrap();
        mock.publish(EventEnvelope::new(
            EventType::EvalCompleted,
            serde_json::json!({}),
        ))
        .await
        .unwrap();
        assert_eq!(mock.published_count(), 1);
        let received = tokio::time::timeout(std::time::Duration::from_secs(2), sub.next())
            .await
            .unwrap()
            .unwrap();
        assert_eq!(received.event_type, EventType::EvalCompleted);
    }

    #[tokio::test]
    async fn mock_state_store_roundtrip() {
        let store = MockStateStore::default();
        let state = serde_json::json!({"done": true});
        store.write(&state).await.unwrap();
        assert_eq!(store.read().await.unwrap(), state);
    }

    #[tokio::test]
    async fn mock_snapshot_codec_roundtrip() {
        let codec = MockSnapshotCodec::default();
        codec.write_snapshot(b"snap").await.unwrap();
        assert_eq!(codec.read_snapshot().await.unwrap(), b"snap");
    }

    #[tokio::test]
    async fn mock_append_log_collects_entries() {
        let log = MockAppendLog::default();
        log.append(b"a").await.unwrap();
        log.append(b"b").await.unwrap();
        assert_eq!(log.entries(), vec![b"a".to_vec(), b"b".to_vec()]);
    }

    #[tokio::test]
    async fn mock_state_serializable_returns_data() {
        let s = MockStateSerializable::new(b"bytes".to_vec());
        assert_eq!(s.serialize().await.unwrap(), b"bytes");
    }
}
