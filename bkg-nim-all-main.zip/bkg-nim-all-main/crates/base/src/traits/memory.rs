//! Memory provider traits.

use crate::error::CoreResult;
use async_trait::async_trait;

use super::service::{KnowledgeQuery, KnowledgeRecord};

/// Storage and retrieval of knowledge records.
#[async_trait]
pub trait MemoryProvider: Send + Sync {
    async fn store(&self, record: KnowledgeRecord) -> CoreResult<()>;
    async fn search(&self, query: KnowledgeQuery) -> CoreResult<Vec<KnowledgeRecord>>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn knowledge_query_defaults() {
        let q = KnowledgeQuery {
            text: "allergies".into(),
            limit: None,
        };
        assert_eq!(q.limit, None);
    }
}
