//! Persistence traits: state serialization, snapshots, append logs, sinks.

use crate::error::CoreResult;
use async_trait::async_trait;
use serde_json::Value;

/// Types that can serialize themselves to bytes.
#[async_trait]
pub trait StateSerializable: Send + Sync {
    async fn serialize(&self) -> CoreResult<Vec<u8>>;
}

/// A codec that persists snapshots and can read them back.
#[async_trait]
pub trait SnapshotCodec: Send + Sync {
    async fn write_snapshot(&self, data: &[u8]) -> CoreResult<()>;
    async fn read_snapshot(&self) -> CoreResult<Vec<u8>>;
}

/// An append-only byte log.
#[async_trait]
pub trait AppendLog: Send + Sync {
    async fn append(&self, entry: &[u8]) -> CoreResult<()>;
}

/// A destination for serialized state.
#[async_trait]
pub trait StateSink: Send + Sync {
    async fn write(&self, state: &Value) -> CoreResult<()>;
}

/// A source of serialized state.
#[async_trait]
pub trait StateSource: Send + Sync {
    async fn read(&self) -> CoreResult<Value>;
}
