//! Event publisher traits.

use crate::error::EventResult;
use crate::events::{EventEnvelope, EventFilter, EventStream};
use async_trait::async_trait;

/// Publishes events to subscribers and exposes subscriptions.
#[async_trait]
pub trait EventPublisher: Send + Sync {
    async fn publish(&self, event: EventEnvelope) -> EventResult<()>;
    async fn subscribe(&self, filter: EventFilter) -> EventResult<EventStream>;
}
