//! Foundation traits: capability-oriented service boundaries.
//!
//! Names are capability-oriented, not provider-oriented. Each trait has a
//! mock implementation for testing (see [`mocks`]).

pub mod events;
pub mod memory;
pub mod persistence;
pub mod service;

pub mod mocks;

pub use events::*;
pub use memory::*;
pub use persistence::*;
pub use service::*;
