//! Messaging concepts: messages, citations, attachments.

use super::identity::{AgentId, MessageId};
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// A message exchanged between actors in the platform.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Message {
    pub id: MessageId,
    pub author: AgentId,
    pub content: String,
    pub sent_at: DateTime<Utc>,
}

impl Message {
    pub fn new(author: AgentId, content: impl Into<String>) -> Self {
        Self {
            id: MessageId::new(),
            author,
            content: content.into(),
            sent_at: Utc::now(),
        }
    }
}

/// A citation referencing a source document or memory.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Citation {
    pub source_id: String,
    pub source_title: String,
    pub snippet: String,
}

impl Citation {
    pub fn new(
        source_id: impl Into<String>,
        source_title: impl Into<String>,
        snippet: impl Into<String>,
    ) -> Self {
        Self {
            source_id: source_id.into(),
            source_title: source_title.into(),
            snippet: snippet.into(),
        }
    }
}

/// An attachment carried alongside a message.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Attachment {
    pub name: String,
    pub mime_type: String,
    pub size_bytes: u64,
    /// Content addressed storage reference; never inline payload bytes.
    pub storage_ref: String,
}

impl Attachment {
    pub fn new(
        name: impl Into<String>,
        mime_type: impl Into<String>,
        size_bytes: u64,
        storage_ref: impl Into<String>,
    ) -> Self {
        Self {
            name: name.into(),
            mime_type: mime_type.into(),
            size_bytes,
            storage_ref: storage_ref.into(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn message_has_fresh_id_and_timestamp() {
        let a = Message::new(AgentId::new(), "hello");
        let b = Message::new(AgentId::new(), "world");
        assert_ne!(a.id, b.id);
        assert!(a.sent_at <= b.sent_at || b.sent_at <= a.sent_at);
    }

    #[test]
    fn citation_roundtrip() {
        let c = Citation::new("src-1", "Privacy Policy", "no PII in public output");
        let json = serde_json::to_string(&c).unwrap();
        let back: Citation = serde_json::from_str(&json).unwrap();
        assert_eq!(c, back);
    }

    #[test]
    fn attachment_roundtrip() {
        let a = Attachment::new("report.pdf", "application/pdf", 1024, "store://r/1");
        let json = serde_json::to_string(&a).unwrap();
        let back: Attachment = serde_json::from_str(&json).unwrap();
        assert_eq!(a, back);
    }
}
