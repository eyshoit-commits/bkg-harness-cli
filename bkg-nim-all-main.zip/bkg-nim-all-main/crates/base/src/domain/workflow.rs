//! Workflow domain concepts: incident types and lifecycle status.

use serde::{Deserialize, Serialize};
use std::fmt;
use std::str::FromStr;

/// The category of an operational incident.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum IncidentType {
    Operational,
    Security,
    Communication,
}

impl fmt::Display for IncidentType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

impl FromStr for IncidentType {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_ascii_lowercase().as_str() {
            "operational" => Ok(IncidentType::Operational),
            "security" => Ok(IncidentType::Security),
            "communication" => Ok(IncidentType::Communication),
            other => Err(format!("unknown incident type: {other}")),
        }
    }
}

/// Lifecycle status of an incident or work item.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Status {
    Pending,
    InProgress,
    Resolved,
    Closed,
}

impl Status {
    /// All statuses in lifecycle order.
    pub const ORDER: [Status; 4] = [
        Status::Pending,
        Status::InProgress,
        Status::Resolved,
        Status::Closed,
    ];

    /// Whether this status is terminal (no further transitions defined).
    pub fn is_terminal(&self) -> bool {
        matches!(self, Status::Resolved | Status::Closed)
    }

    /// The next status in the lifecycle, if any.
    pub fn next(&self) -> Option<Status> {
        match self {
            Status::Pending => Some(Status::InProgress),
            Status::InProgress => Some(Status::Resolved),
            Status::Resolved => Some(Status::Closed),
            Status::Closed => None,
        }
    }
}

impl fmt::Display for Status {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

impl FromStr for Status {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_ascii_lowercase().as_str() {
            "pending" => Ok(Status::Pending),
            "in_progress" | "inprogress" => Ok(Status::InProgress),
            "resolved" => Ok(Status::Resolved),
            "closed" => Ok(Status::Closed),
            other => Err(format!("unknown status: {other}")),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn status_lifecycle_advances() {
        assert_eq!(Status::Pending.next(), Some(Status::InProgress));
        assert_eq!(Status::InProgress.next(), Some(Status::Resolved));
        assert_eq!(Status::Resolved.next(), Some(Status::Closed));
        assert_eq!(Status::Closed.next(), None);
    }

    #[test]
    fn terminal_statuses() {
        assert!(Status::Resolved.is_terminal());
        assert!(Status::Closed.is_terminal());
        assert!(!Status::Pending.is_terminal());
    }

    #[test]
    fn incident_type_parses() {
        assert_eq!(
            IncidentType::from_str("security").unwrap(),
            IncidentType::Security
        );
        assert!(IncidentType::from_str("bogus").is_err());
    }
}
