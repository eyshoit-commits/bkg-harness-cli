//! Pure data concepts for the BKG platform.
//!
//! This module contains only data types. No database logic, no retrieval
//! logic, no business rules. All models implement [`Serialize`],
//! [`Deserialize`], [`Clone`], [`Debug`] and, where semantically valid,
//! [`PartialEq`]/[`Eq`]/[`Hash`].

pub mod identity;
pub mod messaging;
pub mod policy;
pub mod workflow;

pub use identity::*;
pub use messaging::*;
pub use policy::*;
pub use workflow::*;
