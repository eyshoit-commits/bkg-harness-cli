//! Policy domain concepts: kinds of protected data and severity levels.

use serde::{Deserialize, Serialize};
use std::fmt;
use std::str::FromStr;

/// Kinds of protected data the policy engine understands.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum PolicyKind {
    Password,
    CreditCard,
    TaiwanPhone,
    Email,
    PassportOrId,
    InternalNote,
}

impl PolicyKind {
    /// Canonical classifier name used by the policy engine.
    pub fn as_str(&self) -> &'static str {
        match self {
            PolicyKind::Password => "password",
            PolicyKind::CreditCard => "credit_card",
            PolicyKind::TaiwanPhone => "taiwan_phone",
            PolicyKind::Email => "email",
            PolicyKind::PassportOrId => "passport_or_id",
            PolicyKind::InternalNote => "internal_note",
        }
    }

    /// All known policy kinds, in deterministic order.
    pub const ALL: [PolicyKind; 6] = [
        PolicyKind::Password,
        PolicyKind::CreditCard,
        PolicyKind::TaiwanPhone,
        PolicyKind::Email,
        PolicyKind::PassportOrId,
        PolicyKind::InternalNote,
    ];
}

impl fmt::Display for PolicyKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.as_str())
    }
}

impl FromStr for PolicyKind {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "password" => Ok(PolicyKind::Password),
            "credit_card" => Ok(PolicyKind::CreditCard),
            "taiwan_phone" => Ok(PolicyKind::TaiwanPhone),
            "email" => Ok(PolicyKind::Email),
            "passport_or_id" => Ok(PolicyKind::PassportOrId),
            "internal_note" => Ok(PolicyKind::InternalNote),
            other => Err(format!("unknown policy kind: {other}")),
        }
    }
}

/// Severity of a policy finding or operational incident.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
pub enum Severity {
    Info,
    Low,
    Medium,
    High,
    Critical,
}

impl fmt::Display for Severity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

impl FromStr for Severity {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_ascii_lowercase().as_str() {
            "info" => Ok(Severity::Info),
            "low" => Ok(Severity::Low),
            "medium" => Ok(Severity::Medium),
            "high" => Ok(Severity::High),
            "critical" => Ok(Severity::Critical),
            other => Err(format!("unknown severity: {other}")),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn policy_kind_parses_all() {
        for kind in PolicyKind::ALL {
            assert_eq!(PolicyKind::from_str(&kind.as_str()).unwrap(), kind);
        }
    }

    #[test]
    fn policy_kind_unknown_errors() {
        assert!(PolicyKind::from_str("nope").is_err());
    }

    #[test]
    fn severity_ordering() {
        assert!(Severity::Critical > Severity::High);
        assert!(Severity::High > Severity::Medium);
        assert!(Severity::Medium > Severity::Low);
        assert!(Severity::Low > Severity::Info);
    }

    #[test]
    fn severity_parses_case_insensitive() {
        assert_eq!(Severity::from_str("CRITICAL").unwrap(), Severity::Critical);
        assert_eq!(Severity::from_str("high").unwrap(), Severity::High);
    }
}
