//! Stable identity types used across the platform.
//!
//! Identities are opaque newtype wrappers around [`uuid::Uuid`]. They are
//! intentionally not interchangeable with one another at the type level:
//! an `AgentId` cannot be passed where an `EventId` is expected.

use serde::{Deserialize, Serialize};
use std::fmt;
use uuid::Uuid;

macro_rules! id_type {
    ($name:ident, $doc:expr) => {
        #[doc = $doc]
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
        pub struct $name(pub Uuid);

        impl $name {
            /// Generate a fresh random identifier.
            pub fn new() -> Self {
                Self(Uuid::new_v4())
            }

            /// Wrap an existing UUID.
            pub fn from_uuid(id: Uuid) -> Self {
                Self(id)
            }

            /// Borrow the inner UUID.
            pub fn as_uuid(&self) -> &Uuid {
                &self.0
            }

            /// Parse an identifier from its string representation.
            pub fn parse_str(s: &str) -> Result<Self, uuid::Error> {
                Ok(Self(Uuid::parse_str(s)?))
            }
        }

        impl Default for $name {
            fn default() -> Self {
                Self::new()
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "{}", self.0)
            }
        }

        impl From<Uuid> for $name {
            fn from(id: Uuid) -> Self {
                Self(id)
            }
        }
    };
}

id_type!(AgentId, "Identifies an agent (a knowledge profile owner).");
id_type!(EventId, "Identifies an event envelope.");
id_type!(MemoryId, "Identifies a stored memory record.");
id_type!(MessageId, "Identifies a message exchanged between actors.");

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ids_are_distinct_types() {
        let agent = AgentId::new();
        let event = EventId::new();
        // Distinct types cannot be compared directly; both serialize as UUID strings.
        assert_ne!(agent.to_string(), event.to_string());
    }

    #[test]
    fn ids_roundtrip_through_serde() {
        let id = MemoryId::new();
        let json = serde_json::to_string(&id).unwrap();
        let back: MemoryId = serde_json::from_str(&json).unwrap();
        assert_eq!(id, back);
    }

    #[test]
    fn ids_parse_from_string() {
        let id = AgentId::new();
        let parsed = AgentId::parse_str(&id.to_string()).unwrap();
        assert_eq!(id, parsed);
    }

    #[test]
    fn default_generates_fresh_id() {
        let a = AgentId::default();
        let b = AgentId::default();
        assert_ne!(a, b);
    }
}
