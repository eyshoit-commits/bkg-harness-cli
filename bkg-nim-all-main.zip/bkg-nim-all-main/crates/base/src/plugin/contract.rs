//! Plugin contracts only.
//!
//! BKG-BASE supplies contracts. No runtime loading, no manifest signature
//! verification, no isolation, no health endpoint server, no registry
//! implementation, no HashMap. Those belong in `plugin-runtime`.

use crate::error::PluginResult;
use semver::Version;
use serde::{Deserialize, Serialize};

/// Capabilities a plugin can advertise.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum PluginCapability {
    InferenceService,
    MemoryProvider,
    EventPublisher,
    StateSerializable,
    SnapshotCodec,
    AppendLog,
    StateSink,
    StateSource,
}

impl PluginCapability {
    /// Canonical snake_case name.
    pub fn as_str(&self) -> &'static str {
        match self {
            PluginCapability::InferenceService => "inference_service",
            PluginCapability::MemoryProvider => "memory_provider",
            PluginCapability::EventPublisher => "event_publisher",
            PluginCapability::StateSerializable => "state_serializable",
            PluginCapability::SnapshotCodec => "snapshot_codec",
            PluginCapability::AppendLog => "append_log",
            PluginCapability::StateSink => "state_sink",
            PluginCapability::StateSource => "state_source",
        }
    }
}

impl std::fmt::Display for PluginCapability {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.as_str())
    }
}

/// Static metadata describing a plugin.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PluginDescriptor {
    pub name: String,
    pub version: Version,
    pub description: String,
    pub capabilities: Vec<PluginCapability>,
}

impl PluginDescriptor {
    pub fn new(
        name: impl Into<String>,
        version: Version,
        description: impl Into<String>,
        capabilities: Vec<PluginCapability>,
    ) -> Self {
        Self {
            name: name.into(),
            version,
            description: description.into(),
            capabilities,
        }
    }

    /// Whether this plugin provides the given capability.
    pub fn provides(&self, capability: PluginCapability) -> bool {
        self.capabilities.contains(&capability)
    }
}

/// Lifecycle state of a plugin instance.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum PluginState {
    Unloaded,
    Loaded,
    Initializing,
    Running,
    Stopping,
    Stopped,
    Failed(String),
}

impl PluginState {
    /// Whether the state is a terminal failure.
    pub fn is_failed(&self) -> bool {
        matches!(self, PluginState::Failed(_))
    }

    /// Whether the state means the plugin is actively serving.
    pub fn is_running(&self) -> bool {
        matches!(self, PluginState::Running)
    }
}

impl std::fmt::Display for PluginState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            PluginState::Unloaded => write!(f, "unloaded"),
            PluginState::Loaded => write!(f, "loaded"),
            PluginState::Initializing => write!(f, "initializing"),
            PluginState::Running => write!(f, "running"),
            PluginState::Stopping => write!(f, "stopping"),
            PluginState::Stopped => write!(f, "stopped"),
            PluginState::Failed(reason) => write!(f, "failed: {reason}"),
        }
    }
}

/// Health snapshot of a running plugin.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PluginHealth {
    pub status: PluginState,
    pub version: Version,
    pub dependencies: Vec<String>,
    pub latency_ms: u64,
}

/// Lifecycle contract every plugin implements.
pub trait PluginLifecycle: Send + Sync {
    fn init(&mut self) -> PluginResult<()>;
    fn start(&mut self) -> PluginResult<()>;
    fn stop(&mut self) -> PluginResult<()>;
    fn health(&self) -> PluginResult<PluginHealth>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn descriptor_tracks_capabilities() {
        let descriptor = PluginDescriptor::new(
            "memory",
            Version::new(0, 1, 0),
            "knowledge memory",
            vec![PluginCapability::MemoryProvider],
        );
        assert!(descriptor.provides(PluginCapability::MemoryProvider));
        assert!(!descriptor.provides(PluginCapability::InferenceService));
    }

    #[test]
    fn descriptor_roundtrips() {
        let descriptor = PluginDescriptor::new(
            "policy",
            Version::new(1, 2, 3),
            "policy gate",
            vec![PluginCapability::StateSink],
        );
        let json = serde_json::to_string(&descriptor).unwrap();
        let back: PluginDescriptor = serde_json::from_str(&json).unwrap();
        assert_eq!(descriptor, back);
        assert_eq!(back.version, Version::new(1, 2, 3));
    }

    #[test]
    fn state_transitions_reported() {
        assert!(PluginState::Running.is_running());
        assert!(!PluginState::Unloaded.is_running());
        assert!(PluginState::Failed("boom".into()).is_failed());
        assert!(!PluginState::Stopped.is_failed());
    }

    #[test]
    fn capability_names_parse_stable() {
        assert_eq!(PluginCapability::MemoryProvider.as_str(), "memory_provider");
    }
}
