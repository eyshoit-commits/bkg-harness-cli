//! # BKG-BASE
//!
//! Pure foundation layer for the BKG platform.
//!
//! BKG-BASE owns only types, traits, errors, events and plugin contracts.
//! All implementation logic lives in dedicated crates: `storage`, `memory`,
//! `rag`, `policy`, `simulation`, `runtime`, `plugin-runtime`, `nim`,
//! `proxy`.
//!
//! This crate is a library only. It contains no binaries, no CLI
//! entrypoints, no servers and no executable runtime loops. It depends on
//! nothing inside the workspace and has no reverse dependencies.
//!
//! BKG-BASE is designed independently from any behavioral reference
//! implementation. It is a Rust-native foundation layer.

pub mod domain;
pub mod error;
pub mod events;
pub mod plugin;
pub mod traits;

// Explicit re-exports (no glob) to avoid module-name collisions between
// `domain::policy` and `error::policy`.
pub use domain::{
    AgentId, Attachment, Citation, EventId, IncidentType, MemoryId, Message, MessageId, PolicyKind,
    Severity, Status,
};
pub use error::{
    CoreError, CoreResult, EventError, EventResult, PluginError, PluginResult, PolicyError,
    PolicyResult, RetrievalError, RetrievalResult, StorageError, StorageResult,
};
pub use events::{EventEnvelope, EventFilter, EventStream, EventType};
pub use plugin::{PluginCapability, PluginDescriptor, PluginHealth, PluginLifecycle, PluginState};
pub use traits::{
    AppendLog, EventPublisher, InferenceRequest, InferenceResponse, InferenceService,
    KnowledgeQuery, KnowledgeRecord, MemoryProvider, SnapshotCodec, StateSerializable, StateSink,
    StateSource, Usage,
};
