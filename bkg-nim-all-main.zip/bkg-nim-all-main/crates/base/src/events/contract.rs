//! Event system contracts.
//!
//! The base crate defines only the contract: [`EventEnvelope`],
//! [`EventType`], [`EventFilter`] and the [`EventStream`] alias.
//! JSONL parsing and `StreamDeserializer` belong in the storage crate.

use crate::domain::EventId;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Event stream alias: an async stream of event envelopes.
pub type EventStream = std::pin::Pin<Box<dyn futures::Stream<Item = EventEnvelope> + Send>>;

/// All known event types in the platform.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum EventType {
    MessageReceived,
    QuestionAnswered,
    IncidentPosted,
    IncidentFollowupPosted,
    MemoryAppended,
    GateViolation,
    ProvisionStatus,
    EvalCompleted,
    LiveSummaryRefreshed,
}

impl EventType {
    /// Canonical snake_case name.
    pub fn as_str(&self) -> &'static str {
        match self {
            EventType::MessageReceived => "message_received",
            EventType::QuestionAnswered => "question_answered",
            EventType::IncidentPosted => "incident_posted",
            EventType::IncidentFollowupPosted => "incident_followup_posted",
            EventType::MemoryAppended => "memory_appended",
            EventType::GateViolation => "gate_violation",
            EventType::ProvisionStatus => "provision_status",
            EventType::EvalCompleted => "eval_completed",
            EventType::LiveSummaryRefreshed => "live_summary_refreshed",
        }
    }
}

impl std::fmt::Display for EventType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.as_str())
    }
}

impl std::str::FromStr for EventType {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "message_received" => Ok(EventType::MessageReceived),
            "question_answered" => Ok(EventType::QuestionAnswered),
            "incident_posted" => Ok(EventType::IncidentPosted),
            "incident_followup_posted" => Ok(EventType::IncidentFollowupPosted),
            "memory_appended" => Ok(EventType::MemoryAppended),
            "gate_violation" => Ok(EventType::GateViolation),
            "provision_status" => Ok(EventType::ProvisionStatus),
            "eval_completed" => Ok(EventType::EvalCompleted),
            "live_summary_refreshed" => Ok(EventType::LiveSummaryRefreshed),
            other => Err(format!("unknown event type: {other}")),
        }
    }
}

/// A versioned event envelope.
///
/// Versioning ensures that new event types do not break old consumers.
/// Each event carries its schema version.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EventEnvelope {
    pub id: EventId,
    pub version: u32,
    pub timestamp: DateTime<Utc>,
    pub event_type: EventType,
    pub payload: serde_json::Value,
}

impl EventEnvelope {
    /// Build a new event envelope with schema version 1.
    pub fn new(event_type: EventType, payload: impl Into<serde_json::Value>) -> Self {
        Self {
            id: EventId::new(),
            version: 1,
            timestamp: Utc::now(),
            event_type,
            payload: payload.into(),
        }
    }

    /// Build an envelope with an explicit schema version.
    pub fn with_version(
        version: u32,
        event_type: EventType,
        payload: impl Into<serde_json::Value>,
    ) -> Self {
        Self {
            id: EventId::new(),
            version,
            timestamp: Utc::now(),
            event_type,
            payload: payload.into(),
        }
    }
}

/// Filter used to subscribe to a subset of events.
#[derive(Debug, Clone, PartialEq, Eq, Default, Serialize, Deserialize)]
pub struct EventFilter {
    pub event_types: Option<Vec<EventType>>,
    pub min_version: Option<u32>,
}

impl EventFilter {
    /// Match an envelope against this filter.
    pub fn matches(&self, envelope: &EventEnvelope) -> bool {
        if let Some(types) = &self.event_types {
            if !types.contains(&envelope.event_type) {
                return false;
            }
        }
        if let Some(min_version) = self.min_version {
            if envelope.version < min_version {
                return false;
            }
        }
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::str::FromStr;

    #[test]
    fn envelope_roundtrips_through_json() {
        let envelope =
            EventEnvelope::new(EventType::MemoryAppended, serde_json::json!({"count": 3}));
        let json = serde_json::to_string(&envelope).unwrap();
        let back: EventEnvelope = serde_json::from_str(&json).unwrap();
        assert_eq!(envelope, back);
        assert_eq!(back.version, 1);
    }

    #[test]
    fn event_type_parses_all() {
        let all = [
            EventType::MessageReceived,
            EventType::QuestionAnswered,
            EventType::IncidentPosted,
            EventType::IncidentFollowupPosted,
            EventType::MemoryAppended,
            EventType::GateViolation,
            EventType::ProvisionStatus,
            EventType::EvalCompleted,
            EventType::LiveSummaryRefreshed,
        ];
        for t in all {
            assert_eq!(EventType::from_str(t.as_str()).unwrap(), t);
        }
    }

    #[test]
    fn filter_matches_by_type_and_version() {
        let envelope =
            EventEnvelope::with_version(2, EventType::GateViolation, serde_json::json!({}));

        let any = EventFilter::default();
        assert!(any.matches(&envelope));

        let typed = EventFilter {
            event_types: Some(vec![EventType::GateViolation]),
            min_version: None,
        };
        assert!(typed.matches(&envelope));

        let wrong = EventFilter {
            event_types: Some(vec![EventType::EvalCompleted]),
            min_version: None,
        };
        assert!(!wrong.matches(&envelope));

        let versioned = EventFilter {
            event_types: None,
            min_version: Some(3),
        };
        assert!(!versioned.matches(&envelope));
    }
}
