//! Provider-independent error architecture.
//!
//! All library code uses [`thiserror`]-derived error types. `anyhow` is
//! permitted only in binary crates for top-level error reporting.
//!
//! Core errors never reference provider types. The kernel does not know
//! about NVIDIA, Discord, or any external service.

pub mod core;
pub mod event;
pub mod plugin;
pub mod policy;
pub mod retrieval;
pub mod storage;

pub use core::*;
pub use event::*;
pub use plugin::*;
pub use policy::*;
pub use retrieval::*;
pub use storage::*;
