//! Event system errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum EventError {
    #[error("event filter rejected: {0}")]
    FilterRejected(String),

    #[error("publish failed: {0}")]
    Publish(String),

    #[error("subscription failed: {0}")]
    Subscription(String),

    #[error("stream closed")]
    StreamClosed,

    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
}

pub type EventResult<T> = Result<T, EventError>;
