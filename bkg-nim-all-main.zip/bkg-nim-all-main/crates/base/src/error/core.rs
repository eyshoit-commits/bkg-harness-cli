//! Core foundation error type.

use thiserror::Error;

/// Root error for the foundation layer.
#[derive(Debug, Error)]
pub enum CoreError {
    #[error("invalid state transition: {0}")]
    InvalidStateTransition(String),

    #[error("invalid configuration: {0}")]
    InvalidConfiguration(String),

    #[error("operation not supported: {0}")]
    Unsupported(String),

    #[error("serialization failed: {0}")]
    Serialization(String),

    #[error("deserialization failed: {0}")]
    Deserialization(String),

    #[error("domain validation failed: {0}")]
    Validation(String),

    #[error("storage error: {0}")]
    Storage(String),
}

pub type CoreResult<T> = Result<T, CoreError>;
