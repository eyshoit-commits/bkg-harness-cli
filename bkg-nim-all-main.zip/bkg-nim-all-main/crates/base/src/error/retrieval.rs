//! Retrieval engine errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum RetrievalError {
    #[error("empty query")]
    EmptyQuery,

    #[error("no index available")]
    NoIndex,

    #[error("tokenization failed: {0}")]
    Tokenization(String),

    #[error("citation generation failed: {0}")]
    Citation(String),
}

pub type RetrievalResult<T> = Result<T, RetrievalError>;
