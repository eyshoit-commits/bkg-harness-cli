//! Policy engine errors.

use crate::domain::PolicyKind;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum PolicyError {
    #[error("invalid policy kind: {0}")]
    InvalidPolicyKind(PolicyKind),

    #[error("missing required field: {0}")]
    MissingField(String),

    #[error("invalid input: {0}")]
    InvalidInput(String),

    #[error("audit write failed: {0}")]
    Audit(String),
}

pub type PolicyResult<T> = Result<T, PolicyError>;
