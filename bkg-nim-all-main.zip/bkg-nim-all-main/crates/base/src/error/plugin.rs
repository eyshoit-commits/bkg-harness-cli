//! Plugin contract errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum PluginError {
    #[error("plugin not found: {0}")]
    NotFound(String),

    #[error("plugin load failed: {0}")]
    LoadFailed(String),

    #[error("plugin initialization failed: {0}")]
    InitFailed(String),

    #[error("plugin already in state: {0}")]
    InvalidState(String),

    #[error("capability not provided: {0}")]
    MissingCapability(String),

    #[error("version conflict: {0}")]
    VersionConflict(String),
}

pub type PluginResult<T> = Result<T, PluginError>;
