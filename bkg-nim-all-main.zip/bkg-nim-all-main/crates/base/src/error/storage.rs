//! Storage layer errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum StorageError {
    #[error("database error: {0}")]
    Database(String),

    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    #[error("record not found: {0}")]
    NotFound(String),

    #[error("integrity violation: {0}")]
    Integrity(String),

    #[error("atomic write failed: {0}")]
    AtomicWrite(String),
}

pub type StorageResult<T> = Result<T, StorageError>;
