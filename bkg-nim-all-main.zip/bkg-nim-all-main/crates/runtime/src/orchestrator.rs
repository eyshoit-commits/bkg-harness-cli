use crate::domain::*;
use crate::error::*;
use crate::events::*;
use crate::memory::*;
use crate::policy::*;
use crate::sim::*;
use async_trait::async_trait;

#[async_trait]
pub trait SimulationService {
    async fn run_simulation(&self) -> Result<(), Error>;
}

#[async_trait]
pub trait RetrievalService {
    async fn search(&self, query: &str) -> Result<Vec<EventEnvelope>, Error>;
}

#[async_trait]
pub trait PolicyService {
    async fn gate_text(&self, input: &str) -> Result<GateResult, Error>;
    async fn gate_payload(&self, payload: &Value) -> Result<GateResult, Error>;
}

#[async_trait]
pub trait ReplicantService {
    async fn store_memory(&self, memory: Memory) -> Result<(), Error>;
    async fn search_memory(&self, query: &str) -> Result<Vec<Memory>, Error>;
}

#[async_trait]
pub trait LiveOpsService {
    async fn refresh_summary(&self) -> Result<(), Error>;
}

#[async_trait]
pub trait EvaluationService {
    async fn evaluate(&self, context: &str) -> Result<(), Error>;
}
