use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Mutex;
use std::time::SystemTime;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct MemoryProfile {
    pub person_id: String,
    pub profile_data: HashMap<String, String>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct MemoryCase {
    pub case_id: String,
    pub content: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct MemoryDiscord {
    pub discord_id: String,
    pub content: String,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum MemoryType {
    Case,
    Discord,
    // Add more memory types as needed
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct MemoryEntry {
    pub memory_type: MemoryType,
    pub content: String,
    pub timestamp: SystemTime,
}

pub struct ReplicantMemory {
    pub profiles: HashMap<String, MemoryProfile>,
    pub cases: Vec<MemoryCase>,
    pub discord_memories: Vec<MemoryDiscord>,
}

impl ReplicantMemory {
    pub fn new() -> Self {
        ReplicantMemory {
            profiles: HashMap::new(),
            cases: Vec::new(),
            discord_memories: Vec::new(),
        }
    }

    pub fn add_profile(&mut self, person_id: String, data: HashMap<String, String>) {
        self.profiles.insert(
            person_id,
            MemoryProfile {
                person_id,
                profile_data: data,
            },
        );
    }

    pub fn add_case(&mut self, case_id: String, content: String) {
        self.cases.push(MemoryCase { case_id, content });
    }

    pub fn add_discord_memory(&mut self, discord_id: String, content: String) {
        self.discord_memories.push(MemoryDiscord {
            discord_id,
            content,
        });
    }

    // Add more methods for managing memories
}
