//! Auth: users, passwords (argon2), sessions — backed by PostgreSQL.
//!
//! Passwords are hashed with argon2id (OWASP-recommended); sessions are
//! opaque bearer tokens stored as SHA-256 hashes, with expiry and revoke.

use crate::persist::StorageError;
use serde_json::json;
use sha2::{Digest, Sha256};
use sqlx::PgPool;
use std::time::Duration;

const ARGON2_M_COST: u32 = 19456; // 19 MiB
const ARGON2_T_COST: u32 = 2;
const ARGON2_P_COST: u32 = 1;

/// A user row (password hash never leaves this module).
#[derive(Debug, Clone, serde::Serialize)]
pub struct User {
    pub id: uuid::Uuid,
    pub email: String,
    pub display_name: Option<String>,
    pub role: String,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, thiserror::Error)]
pub enum AuthError {
    #[error("database error: {0}")]
    Db(#[source] StorageError),
    #[error("invalid credentials")]
    InvalidCredentials,
    #[error("user already exists")]
    EmailTaken,
    #[error("session expired")]
    SessionExpired,
    #[error("session revoked")]
    SessionRevoked,
    #[error("session not found")]
    NoSession,
}

impl From<sqlx::Error> for AuthError {
    fn from(e: sqlx::Error) -> Self {
        AuthError::Db(StorageError::Query(e))
    }
}

pub struct Auth {
    pool: PgPool,
}

impl Auth {
    pub fn new(pool: PgPool) -> Self {
        Self { pool }
    }

    /// Create a user with an argon2id-hashed password.
    pub async fn register(
        &self,
        email: &str,
        password: &str,
        display_name: Option<&str>,
    ) -> Result<User, AuthError> {
        let email = email.trim().to_lowercase();
        validate_credentials(&email, password)?;
        let hash = hash_password(password)?;
        let row = sqlx::query_as::<_, UserRow>(
            "INSERT INTO auth_users (email, password_hash, display_name)
             VALUES ($1, $2, $3)
             RETURNING id, email, display_name, role, created_at",
        )
        .bind(&email)
        .bind(&hash)
        .bind(display_name)
        .fetch_one(&self.pool)
        .await;
        match row {
            Ok(r) => Ok(r.into()),
            Err(sqlx::Error::Database(db)) if db.is_unique_violation() => {
                Err(AuthError::EmailTaken)
            }
            Err(e) => Err(e.into()),
        }
    }

    /// Verify email+password, return the user.
    pub async fn login(&self, email: &str, password: &str) -> Result<User, AuthError> {
        let email = email.trim().to_lowercase();
        let row = sqlx::query_as::<_, UserRow>(
            "SELECT id, email, display_name, role, created_at, password_hash
             FROM auth_users WHERE email = $1",
        )
        .bind(&email)
        .fetch_optional(&self.pool)
        .await?;
        let Some(row) = row else {
            return Err(AuthError::InvalidCredentials);
        };
        if !verify_password(password, &row.password_hash)? {
            return Err(AuthError::InvalidCredentials);
        }
        Ok(User {
            id: row.id,
            email: row.email,
            display_name: row.display_name,
            role: row.role,
            created_at: row.created_at,
        })
    }

    /// Create a session for a user; returns the raw bearer token.
    pub async fn create_session(
        &self,
        user_id: uuid::Uuid,
        ttl: Duration,
    ) -> Result<(String, chrono::DateTime<chrono::Utc>), AuthError> {
        let token = uuid::Uuid::new_v4().to_string();
        let token_hash = hash_token(&token);
        let expires_at = chrono::Utc::now() + ttl;
        sqlx::query(
            "INSERT INTO auth_sessions (user_id, token_hash, expires_at)
             VALUES ($1, $2, $3)",
        )
        .bind(user_id)
        .bind(&token_hash)
        .bind(expires_at)
        .execute(&self.pool)
        .await?;
        Ok((token, expires_at))
    }

    /// Validate a bearer token, return the user (checking expiry/revoke).
    pub async fn validate_session(&self, token: &str) -> Result<User, AuthError> {
        let token_hash = hash_token(token);
        let row = sqlx::query_as::<_, SessionRow>(
            "SELECT u.id, u.email, u.display_name, u.role, u.created_at,
                    s.expires_at, s.revoked_at
             FROM auth_sessions s
             JOIN auth_users u ON u.id = s.user_id
             WHERE s.token_hash = $1",
        )
        .bind(&token_hash)
        .fetch_optional(&self.pool)
        .await?;
        let Some(row) = row else {
            return Err(AuthError::NoSession);
        };
        if row.revoked_at.is_some() {
            return Err(AuthError::SessionRevoked);
        }
        if row.expires_at < chrono::Utc::now() {
            return Err(AuthError::SessionExpired);
        }
        Ok(User {
            id: row.id,
            email: row.email,
            display_name: row.display_name,
            role: row.role,
            created_at: row.created_at,
        })
    }

    /// Revoke a session token (logout).
    pub async fn revoke_session(&self, token: &str) -> Result<(), AuthError> {
        let token_hash = hash_token(token);
        sqlx::query("UPDATE auth_sessions SET revoked_at = now() WHERE token_hash = $1")
            .bind(&token_hash)
            .execute(&self.pool)
            .await?;
        Ok(())
    }

    /// Delete all expired sessions (call periodically).
    pub async fn prune_expired(&self) -> Result<u64, AuthError> {
        let res = sqlx::query("DELETE FROM auth_sessions WHERE expires_at < now()")
            .execute(&self.pool)
            .await?;
        Ok(res.rows_affected())
    }
}

// --- password hashing (argon2id) ---------------------------------------------

/// Pure validation shared by register/login.
fn validate_credentials(email: &str, password: &str) -> Result<(), AuthError> {
    if !email.contains('@') || password.len() < 8 {
        return Err(AuthError::InvalidCredentials);
    }
    Ok(())
}

fn hash_password(password: &str) -> Result<String, AuthError> {
    use argon2::password_hash::SaltString;
    use argon2::{Argon2, PasswordHasher};
    use rand_core::OsRng;

    let salt = SaltString::generate(&mut OsRng);
    let params =
        argon2::Params::new(ARGON2_M_COST, ARGON2_T_COST, ARGON2_P_COST, None).map_err(|e| {
            AuthError::Db(StorageError::Connect(sqlx::Error::Configuration(
                e.to_string().into(),
            )))
        })?;
    let hash = Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params)
        .hash_password(password.as_bytes(), &salt)
        .map_err(|e| {
            AuthError::Db(StorageError::Connect(sqlx::Error::Configuration(
                e.to_string().into(),
            )))
        })?;
    Ok(hash.to_string())
}

fn verify_password(password: &str, hash: &str) -> Result<bool, AuthError> {
    use argon2::{Argon2, PasswordHash, PasswordVerifier};

    let parsed = PasswordHash::new(hash).map_err(|e| {
        AuthError::Db(StorageError::Connect(sqlx::Error::Configuration(
            e.to_string().into(),
        )))
    })?;
    Ok(Argon2::default()
        .verify_password(password.as_bytes(), &parsed)
        .is_ok())
}

fn hash_token(token: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(token.as_bytes());
    hex::encode(hasher.finalize())
}

// --- row mappers --------------------------------------------------------------

#[derive(sqlx::FromRow)]
struct UserRow {
    id: uuid::Uuid,
    email: String,
    display_name: Option<String>,
    role: String,
    created_at: chrono::DateTime<chrono::Utc>,
    password_hash: String,
}

#[derive(sqlx::FromRow)]
struct SessionRow {
    id: uuid::Uuid,
    email: String,
    display_name: Option<String>,
    role: String,
    created_at: chrono::DateTime<chrono::Utc>,
    expires_at: chrono::DateTime<chrono::Utc>,
    revoked_at: Option<chrono::DateTime<chrono::Utc>>,
}

impl From<UserRow> for User {
    fn from(r: UserRow) -> Self {
        User {
            id: r.id,
            email: r.email,
            display_name: r.display_name,
            role: r.role,
            created_at: r.created_at,
        }
    }
}

/// Helper: build a JSON login response.
pub fn login_response(token: &str, user: &User) -> serde_json::Value {
    json!({
        "access_token": token,
        "token_type": "Bearer",
        "user": user,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn token_hash_is_sha256_hex() {
        let h = hash_token("abc");
        assert_eq!(h.len(), 64);
        assert!(h.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn password_roundtrip() {
        let hash = hash_password("correct horse battery staple").unwrap();
        assert_ne!(hash, "correct horse battery staple");
        assert!(verify_password("correct horse battery staple", &hash).unwrap());
        assert!(!verify_password("wrong", &hash).unwrap());
    }

    #[test]
    fn registration_rejects_short_password() {
        let pool_placeholder = PgPool::new_lazy("postgres://localhost:5433/none");
        let auth = Auth::new(pool_placeholder);
        let err = auth.register("a@b.c", "short", None).await.unwrap_err();
        assert!(matches!(err, AuthError::InvalidCredentials));
    }
}
