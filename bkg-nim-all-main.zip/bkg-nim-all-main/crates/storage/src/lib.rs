//! BKG storage: PostgreSQL (sqlx), auth, event stream, RAG vector store.

pub mod auth;
pub mod persist;

pub use auth::{Auth, AuthError, User};
pub use persist::{EmbeddingHit, EventRow, Storage, StorageError, UsageRecord};
