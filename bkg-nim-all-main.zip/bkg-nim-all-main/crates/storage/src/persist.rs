//! BKG persistence layer: PostgreSQL (sqlx) + auth + event stream + RAG.
//!
//! Uses the Rust client (`sqlx`) directly against PostgreSQL — no JS
//! Supabase client. Schema is bootstrapped by
//! `deploy/postgres/init/001_bkg.sql` (auth_users, auth_sessions,
//! state_store, event_stream, rag_documents, rag_embeddings, usage_ledger).

use bkg_base::traits::{AppendLog, SnapshotCodec, StateSink, StateSource};
use bkg_base::{CoreError, CoreResult};
use serde_json::Value;
use sqlx::postgres::{PgConnectOptions, PgPool, PgPoolOptions};
use std::sync::Arc;

/// PostgreSQL-backed storage root.
#[derive(Debug, Clone)]
pub struct Storage {
    pool: Arc<PgPool>,
}

impl Storage {
    /// Connect using a full `postgres://` URL (password from Docker secret /
    /// env interpolation — nothing hardcoded).
    pub async fn connect(database_url: &str) -> Result<Self, StorageError> {
        let pool = PgPoolOptions::new()
            .max_connections(10)
            .acquire_timeout(std::time::Duration::from_secs(5))
            .connect(database_url)
            .await
            .map_err(StorageError::Connect)?;
        Ok(Self {
            pool: Arc::new(pool),
        })
    }

    /// Connect with explicit parts (used when the URL is split by the caller).
    pub async fn connect_with(
        host: &str,
        port: u16,
        user: &str,
        password: &str,
        database: &str,
    ) -> Result<Self, StorageError> {
        let options = PgConnectOptions::new()
            .host(host)
            .port(port)
            .username(user)
            .password(password)
            .database(database);
        let pool = PgPoolOptions::new()
            .max_connections(10)
            .connect_with(options)
            .await
            .map_err(StorageError::Connect)?;
        Ok(Self {
            pool: Arc::new(pool),
        })
    }

    pub fn pool(&self) -> &PgPool {
        &self.pool
    }

    // --- state store -------------------------------------------------------

    /// Read the JSON state for a namespace/key.
    pub async fn read_state(
        &self,
        namespace: &str,
        key: &str,
    ) -> Result<Option<Value>, StorageError> {
        let row: Option<(Value,)> =
            sqlx::query_as("SELECT value FROM state_store WHERE namespace = $1 AND key = $2")
                .bind(namespace)
                .bind(key)
                .fetch_optional(&*self.pool)
                .await
                .map_err(StorageError::Query)?;
        Ok(row.map(|(v,)| v))
    }

    /// Upsert the JSON state for a namespace/key.
    pub async fn write_state(
        &self,
        namespace: &str,
        key: &str,
        value: &Value,
    ) -> Result<(), StorageError> {
        sqlx::query(
            "INSERT INTO state_store (namespace, key, value, updated_at)
             VALUES ($1, $2, $3, now())
             ON CONFLICT (namespace, key) DO UPDATE
               SET value = EXCLUDED.value, updated_at = now()",
        )
        .bind(namespace)
        .bind(key)
        .bind(value)
        .execute(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(())
    }

    // --- event stream -------------------------------------------------------

    /// Append an event (JSON payload) to the append-only stream.
    pub async fn append_event(
        &self,
        namespace: &str,
        event_type: &str,
        payload: &Value,
    ) -> Result<i64, StorageError> {
        let row: (i64,) = sqlx::query_as(
            "INSERT INTO event_stream (namespace, event_type, payload)
             VALUES ($1, $2, $3) RETURNING seq",
        )
        .bind(namespace)
        .bind(event_type)
        .bind(payload)
        .fetch_one(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(row.0)
    }

    /// List events after `after_seq` (0 = all), newest last.
    pub async fn list_events(
        &self,
        namespace: &str,
        after_seq: i64,
        limit: i64,
    ) -> Result<Vec<EventRow>, StorageError> {
        let rows = sqlx::query_as::<_, EventRow>(
            "SELECT seq, namespace, event_type, payload, created_at
             FROM event_stream
             WHERE namespace = $1 AND seq > $2
             ORDER BY seq
             LIMIT $3",
        )
        .bind(namespace)
        .bind(after_seq)
        .bind(limit)
        .fetch_all(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(rows)
    }

    // --- RAG ----------------------------------------------------------------

    /// Insert a document and return its id.
    pub async fn insert_document(
        &self,
        namespace: &str,
        title: &str,
        content: &str,
        source: &str,
    ) -> Result<uuid::Uuid, StorageError> {
        let row: (uuid::Uuid,) = sqlx::query_as(
            "INSERT INTO rag_documents (namespace, title, content, source)
             VALUES ($1, $2, $3, $4) RETURNING id",
        )
        .bind(namespace)
        .bind(title)
        .bind(content)
        .bind(source)
        .fetch_one(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(row.0)
    }

    /// Store a chunk embedding (pgvector).
    #[allow(clippy::too_many_arguments)]
    pub async fn insert_embedding(
        &self,
        document_id: uuid::Uuid,
        chunk_index: i32,
        chunk_text: &str,
        embedding: &[f32],
    ) -> Result<(), StorageError> {
        sqlx::query(
            "INSERT INTO rag_embeddings (document_id, chunk_index, chunk_text, embedding)
             VALUES ($1, $2, $3, $4::vector)",
        )
        .bind(document_id)
        .bind(chunk_index)
        .bind(chunk_text)
        .bind(embedding.to_vec())
        .execute(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(())
    }

    /// Cosine similarity search over pgvector embeddings.
    pub async fn search_embeddings(
        &self,
        embedding: &[f32],
        limit: i64,
    ) -> Result<Vec<EmbeddingHit>, StorageError> {
        let rows = sqlx::query_as::<_, EmbeddingHit>(
            "SELECT e.id, e.document_id, e.chunk_index, e.chunk_text,
                    1 - (e.embedding <=> $1::vector) AS similarity
             FROM rag_embeddings e
             ORDER BY e.embedding <=> $1::vector
             LIMIT $2",
        )
        .bind(embedding.to_vec())
        .bind(limit)
        .fetch_all(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(rows)
    }

    // --- usage ledger --------------------------------------------------------

    pub async fn record_usage(&self, row: &UsageRecord) -> Result<(), StorageError> {
        sqlx::query(
            "INSERT INTO usage_ledger
               (lane, model, user_id, prompt_tokens, completion_tokens, total_tokens, latency_ms)
             VALUES ($1, $2, $3, $4, $5, $6, $7)",
        )
        .bind(&row.lane)
        .bind(&row.model)
        .bind(row.user_id)
        .bind(row.prompt_tokens)
        .bind(row.completion_tokens)
        .bind(row.total_tokens)
        .bind(row.latency_ms)
        .execute(&*self.pool)
        .await
        .map_err(StorageError::Query)?;
        Ok(())
    }
}

/// One row from the append-only event stream.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, sqlx::FromRow)]
pub struct EventRow {
    pub seq: i64,
    pub namespace: String,
    pub event_type: String,
    pub payload: Value,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

/// One pgvector similarity hit.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, sqlx::FromRow)]
pub struct EmbeddingHit {
    pub id: uuid::Uuid,
    pub document_id: uuid::Uuid,
    pub chunk_index: i32,
    pub chunk_text: String,
    pub similarity: f64,
}

/// A usage ledger record.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct UsageRecord {
    pub lane: String,
    pub model: Option<String>,
    pub user_id: Option<uuid::Uuid>,
    pub prompt_tokens: i32,
    pub completion_tokens: i32,
    pub total_tokens: i32,
    pub latency_ms: Option<i32>,
}

/// Storage errors.
#[derive(Debug, thiserror::Error)]
pub enum StorageError {
    #[error("database connect failed: {0}")]
    Connect(#[source] sqlx::Error),
    #[error("database query failed: {0}")]
    Query(#[source] sqlx::Error),
}

impl From<StorageError> for CoreError {
    fn from(e: StorageError) -> Self {
        CoreError::Storage(e.to_string())
    }
}

// --- base trait impls (JSON state store) ------------------------------------

/// State sink backed by the Postgres state_store table.
pub struct PgStateSink {
    storage: Storage,
    namespace: String,
    key: String,
}

impl PgStateSink {
    pub fn new(storage: Storage, namespace: impl Into<String>, key: impl Into<String>) -> Self {
        Self {
            storage,
            namespace: namespace.into(),
            key: key.into(),
        }
    }
}

#[async_trait::async_trait]
impl StateSink for PgStateSink {
    async fn write(&self, state: &Value) -> CoreResult<()> {
        self.storage
            .write_state(&self.namespace, &self.key, state)
            .await?;
        Ok(())
    }
}

/// State source backed by the Postgres state_store table.
pub struct PgStateSource {
    storage: Storage,
    namespace: String,
    key: String,
}

impl PgStateSource {
    pub fn new(storage: Storage, namespace: impl Into<String>, key: impl Into<String>) -> Self {
        Self {
            storage,
            namespace: namespace.into(),
            key: key.into(),
        }
    }
}

#[async_trait::async_trait]
impl StateSource for PgStateSource {
    async fn read(&self) -> CoreResult<Value> {
        Ok(self
            .storage
            .read_state(&self.namespace, &self.key)
            .await?
            .unwrap_or(Value::Null))
    }
}

/// Append-only event log backed by the Postgres event_stream table.
pub struct PgAppendLog {
    storage: Storage,
    namespace: String,
}

impl PgAppendLog {
    pub fn new(storage: Storage, namespace: impl Into<String>) -> Self {
        Self {
            storage,
            namespace: namespace.into(),
        }
    }
}

#[async_trait::async_trait]
impl AppendLog for PgAppendLog {
    async fn append(&self, entry: &[u8]) -> CoreResult<()> {
        let payload =
            serde_json::from_slice(entry).map_err(|e| CoreError::Serialization(e.to_string()))?;
        self.storage
            .append_event(&self.namespace, "event", &payload)
            .await?;
        Ok(())
    }
}

/// Snapshot codec backed by the Postgres state_store table.
pub struct PgSnapshotCodec {
    storage: Storage,
    namespace: String,
    key: String,
}

impl PgSnapshotCodec {
    pub fn new(storage: Storage, namespace: impl Into<String>, key: impl Into<String>) -> Self {
        Self {
            storage,
            namespace: namespace.into(),
            key: key.into(),
        }
    }
}

#[async_trait::async_trait]
impl SnapshotCodec for PgSnapshotCodec {
    async fn write_snapshot(&self, data: &[u8]) -> CoreResult<()> {
        let value =
            serde_json::from_slice(data).map_err(|e| CoreError::Serialization(e.to_string()))?;
        self.storage
            .write_state(&self.namespace, &self.key, &value)
            .await?;
        Ok(())
    }

    async fn read_snapshot(&self) -> CoreResult<Vec<u8>> {
        let value = self
            .storage
            .read_state(&self.namespace, &self.key)
            .await?
            .unwrap_or(Value::Null);
        serde_json::to_vec(&value).map_err(|e| CoreError::Serialization(e.to_string()))
    }
}
