//! Runtime router rebuild and upstream key probing.
//!
//! - `rebuild_router` layers the persisted state (runtime upstream
//!   overrides + runtime-managed provider keys) on top of the env-provided
//!   lane pool and rebuilds the live router. Called at boot and after every
//!   settings mutation so a key/upstream change takes effect immediately.
//! - `probe_key` validates a key against a provider's upstream `/models`
//!   endpoint — the same pre-auth validation the nim-proxy setup wizard
//!   performs (`/setup/validate-key`).

use crate::config::GatewayConfig;
use crate::lane::Lane;
use crate::server::LaneRouter;
use crate::store::GatewayState;
use std::time::Duration;

/// One request timeout for upstream probes (generous; upstreams can be
/// slow on first contact).
const PROBE_TIMEOUT: Duration = Duration::from_secs(15);

/// Rebuild `router` from the env lane pool plus the persisted runtime
/// state:
///
/// - every env lane stays (provider key files / numbered keys);
/// - a state upstream override replaces the upstream for EVERY lane of that
///   provider — env lanes and runtime lanes alike (nim-proxy `base_url`
///   editing semantics: the provider's upstream is a single value);
/// - every runtime key becomes one additional lane (`{provider}-rt-{n}`),
///   carrying its rpm tier and enabled flag (nim-proxy `nim_keys`).
///
/// Runtime lanes use a distinct `-rt-` suffix so they can never collide
/// with env lane names (`{provider}-1`, `{provider}-2`, …).
///
/// Returns a lane-name → client-key map so HTTP forwarding can look up the
/// live key for a routed lane (env lanes AND runtime lanes alike).
pub fn rebuild_router(
    router: &mut LaneRouter,
    config: &GatewayConfig,
    state: &GatewayState,
) -> std::collections::HashMap<String, String> {
    *router = LaneRouter::new();
    let mut lane_keys = std::collections::HashMap::new();

    for lane in &config.lanes {
        let mut lane = lane.clone();
        if let Some(up) = state
            .providers
            .get(&lane.provider)
            .and_then(|p| p.upstream.clone())
        {
            lane.upstream_base_url = up;
        }
        lane_keys.insert(lane.name.clone(), lane.client_key.clone());
        router.add_lane(lane);
    }

    let mut providers: Vec<&String> = state.providers.keys().collect();
    providers.sort();
    for provider in providers {
        let entry = state.providers.get(provider).expect("iterated key exists");
        let upstream = entry
            .upstream
            .clone()
            .or_else(|| config.lane_for(provider).map(|l| l.upstream_base_url.clone()))
            .unwrap_or_default();
        if upstream.is_empty() {
            continue;
        }
        for (i, k) in entry.keys.iter().enumerate() {
            if k.key.is_empty() {
                continue;
            }
            let mut lane = Lane::new(
                provider.clone(),
                format!("{provider}-rt-{}", i + 1),
                upstream.clone(),
                k.key.clone(),
            );
            lane.rate_limit_per_window = k.rpm;
            lane.enabled = k.enabled;
            lane_keys.insert(lane.name.clone(), lane.client_key.clone());
            router.add_lane(lane);
        }
    }
    lane_keys
}

/// Probe `key` against `base_url`'s `/models` endpoint.
///
/// Returns the model id list on success, or a human-readable error on any
/// upstream / HTTP / parse failure. Mirrors nim-proxy
/// `setup_validate_key` (bearer auth, GET /models).
pub async fn probe_key(
    http: &reqwest::Client,
    base_url: &str,
    key: &str,
) -> Result<Vec<String>, String> {
    let url = format!("{}/models", base_url.trim_end_matches('/'));
    let resp = http
        .get(&url)
        .bearer_auth(key)
        .timeout(PROBE_TIMEOUT)
        .send()
        .await
        .map_err(|e| format!("upstream error: {e}"))?;
    let status = resp.status();
    if !status.is_success() {
        let text = resp.text().await.unwrap_or_default();
        let snippet = text.chars().take(200).collect::<String>();
        return Err(format!("upstream returned {status}: {snippet}"));
    }
    let body: serde_json::Value = resp
        .json()
        .await
        .map_err(|e| format!("invalid upstream response: {e}"))?;
    let models: Vec<String> = body
        .get("data")
        .and_then(|d| d.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|m| m.get("id").and_then(|i| i.as_str()).map(String::from))
                .collect()
        })
        .unwrap_or_default();
    Ok(models)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lane::Lane;
    use crate::store::RuntimeKey;

    fn test_config() -> GatewayConfig {
        let mut c = GatewayConfig {
            gateway_bind: "0.0.0.0:666".parse().unwrap(),
            dashboard_bind: "0.0.0.0:7666".parse().unwrap(),
            providers: vec!["gemini".into()],
            lanes: vec![Lane::new(
                "gemini",
                "gemini-1",
                "https://generativelanguage.googleapis.com/v1beta",
                "env_key",
            )],
            client_keys: Vec::new(),
        };
        c.lanes[0].rate_limit_per_window = 40;
        c
    }

    #[test]
    fn rebuild_layers_env_lanes_and_runtime_keys() {
        let config = test_config();
        let mut state = GatewayState::default();
        {
            let entry = state.providers.entry("gemini".into()).or_default();
            entry.upstream = Some("https://override.example/v1".into());
            entry.keys.push(RuntimeKey::new("rt_key_1".into(), 60));
            entry.keys.push(RuntimeKey::new("rt_key_2".into(), 80));
        }
        // A disabled runtime key stays present but unroutable.
        state
            .providers
            .get_mut("gemini")
            .unwrap()
            .keys
            .push(RuntimeKey::new("rt_key_3".into(), 20));

        let mut router = LaneRouter::new();
        let lane_keys = rebuild_router(&mut router, &config, &state);
        let names = router.lane_names();
        assert_eq!(names, vec!["gemini-1", "gemini-rt-1", "gemini-rt-2", "gemini-rt-3"]);
        assert_eq!(lane_keys.get("gemini-1").unwrap(), "env_key");
        assert_eq!(lane_keys.get("gemini-rt-1").unwrap(), "rt_key_1");

        // The override upstream applies to EVERY gemini lane (env + runtime):
        // nim-proxy edits the provider's single base_url.
        for _ in 0..4 {
            match router.route("gemini") {
                crate::server::RouteDecision::Forward { upstream, .. } => {
                    assert_eq!(upstream, "https://override.example/v1");
                }
                other => panic!("unexpected: {other:?}"),
            }
        }
    }

    #[test]
    fn rebuild_skips_provider_without_upstream() {
        let config = test_config();
        let mut state = GatewayState::default();
        // Provider "nim" is NOT in config.lanes and has no upstream in
        // state -> no lanes may be created for it.
        state
            .providers
            .entry("nim".into())
            .or_default()
            .keys
            .push(RuntimeKey::new("nim_key".into(), 40));
        let mut router = LaneRouter::new();
        let lane_keys = rebuild_router(&mut router, &config, &state);
        assert_eq!(router.lane_names(), vec!["gemini-1"]);
        assert_eq!(lane_keys.len(), 1);
    }

    async fn spawn_upstream(status: u16, body: serde_json::Value) -> String {
        use axum::routing::get;
        let app = axum::Router::new().route(
            "/models",
            get(move || {
                let body = body.clone();
                async move { (axum::http::StatusCode::from_u16(status).unwrap(), axum::Json(body)) }
            }),
        );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        tokio::spawn(async move {
            axum::serve(listener, app).await.unwrap();
        });
        format!("http://{addr}")
    }

    #[tokio::test]
    async fn probe_key_accepts_valid_upstream() {
        let base = spawn_upstream(
            200,
            serde_json::json!({ "object": "list", "data": [ { "id": "gemini-2.5-pro" }, { "id": "gemini-2.5-flash" } ] }),
        )
        .await;
        let http = reqwest::Client::new();
        let models = probe_key(&http, &base, "gpk_valid").await.expect("probe succeeds");
        assert_eq!(models, vec!["gemini-2.5-pro", "gemini-2.5-flash"]);
    }

    #[tokio::test]
    async fn probe_key_reports_upstream_error() {
        let base = spawn_upstream(401, serde_json::json!({ "error": "unauthorized" })).await;
        let http = reqwest::Client::new();
        let err = probe_key(&http, &base, "gpk_bad").await.unwrap_err();
        assert!(err.contains("401"), "error should mention status: {err}");
    }

    #[tokio::test]
    async fn probe_key_reports_connection_error() {
        // Nothing listens on this port.
        let http = reqwest::Client::new();
        let err = probe_key(&http, "http://127.0.0.1:1", "key").await.unwrap_err();
        assert!(err.contains("upstream error"), "unexpected: {err}");
    }
}
