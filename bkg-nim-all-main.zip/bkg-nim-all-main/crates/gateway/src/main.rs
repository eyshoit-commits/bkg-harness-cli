//! BKG gateway binary.
//!
//! Serves an OpenAI-compatible API on `GATEWAY_BIND` and the admin
//! dashboard on `DASHBOARD_BIND` (both from env — nothing hardcoded).
//!
//! Endpoints (API):
//!   POST /v1/chat/completions  OpenAI-compatible, forwarded to a lane
//!   GET  /v1/models            enabled lanes as OpenAI model list
//!   GET  /health               liveness
//!
//! The API is closed (503) until the first-run setup wizard has claimed
//! the superuser (nim-proxy parity).
//!
//! Endpoints (dashboard bind — the WebAssembly admin app at `/` plus its
//! JSON API; the embedded single-file SPA is the fallback when no wasm
//! bundle is built):
//!   GET  /                      wasm admin app (setup/login/dashboard/settings)
//!   GET  /assets/{path}         static wasm assets from `BKG_UI_DIR`
//!   POST /setup                 claim superuser + initial keys + session
//!   POST /setup/validate-key    pre-auth key probe against upstream
//!   POST /api/login             admin session cookie
//!   POST /api/logout            expire the session cookie
//!   GET  /api/config            read-only admin view (session-gated)
//!   POST /api/settings/keys     add/disable/enable/delete provider keys
//!   POST /api/settings/clients  mint a client key (secret shown once)
//!   POST /api/settings/account  password change
//!   GET  /api/dashboard/now     live lane snapshot (public, internal bind)
//!   GET  /metrics               JSON lane metrics

use axum::{
    extract::{Path, State},
    http::{HeaderMap, StatusCode, header},
    response::{IntoResponse, Response},
    routing::{get, post},
    Json, Router,
};
use bkg_gateway::{GatewayConfig, RouteDecision, Runtime};
use serde_json::{json, Value};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tokio::net::TcpListener;

type SharedRuntime = Arc<Runtime>;

/// Parse a `Retry-After` header carrying whole seconds. Returns `None` for
/// HTTP-date values or garbage — callers fall back to their own default.
fn retry_after_from_headers(headers: &HeaderMap) -> Option<u64> {
    headers
        .get(header::RETRY_AFTER)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.trim().parse::<u64>().ok())
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config = GatewayConfig::from_env()?;
    let runtime: SharedRuntime = Arc::new(Runtime::new(config));

    // Dashboard + admin API on its own bind (separate traffic plane).
    let dash_state = runtime.clone();
    let dash_bind = runtime.config.dashboard_bind;
    tokio::spawn(async move {
        let app = Router::new()
            .route("/", get(dashboard_index))
            .route("/assets/{*path}", get(ui_asset))
            .route("/metrics", get(dashboard_metrics))
            .route("/api/dashboard/now", get(api_dashboard_now))
            .route("/setup", post(bkg_gateway::settings::setup_submit))
            .route(
                "/setup/validate-key",
                post(bkg_gateway::settings::setup_validate_key),
            )
            .route("/api/login", post(bkg_gateway::settings::login_submit))
            .route("/api/logout", post(bkg_gateway::settings::logout))
            .route("/api/config", get(bkg_gateway::settings::api_config))
            .route(
                "/api/settings/keys",
                post(bkg_gateway::settings::settings_keys),
            )
            .route(
                "/api/settings/clients",
                post(bkg_gateway::settings::settings_clients),
            )
            .route(
                "/api/settings/account",
                post(bkg_gateway::settings::settings_account),
            )
            .with_state(dash_state);
        let listener = TcpListener::bind(dash_bind).await?;
        axum::serve(listener, app).await?;
        Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
    });

    // API gateway on its own bind.
    let api_bind = runtime.config.gateway_bind;
    let api_app = Router::new()
        .route("/v1/chat/completions", post(chat_completions))
        .route("/v1/models", get(list_models))
        .route("/health", get(health))
        .with_state(runtime);

    println!("gateway listening on {api_bind}");
    let listener = TcpListener::bind(api_bind).await?;
    axum::serve(listener, api_app).await?;
    Ok(())
}

/// The API is closed until the first-run wizard claims the superuser
/// (nim-proxy: startup → `/v1` returns 503 until setup).
fn setup_not_done(runtime: &Runtime) -> Option<Response> {
    use std::sync::atomic::Ordering;
    if runtime.setup_required.load(Ordering::SeqCst) {
        return Some(
            (
                StatusCode::SERVICE_UNAVAILABLE,
                Json(json!({ "error": { "message": "gateway not configured: run /setup first", "type": "setup_required", "code": "setup_required" } })),
            )
                .into_response(),
        );
    }
    None
}

/// Authenticate the `Authorization: Bearer <key>` header against the env
/// key AND the runtime-minted client keys.
fn authorized(runtime: &Runtime, headers: &HeaderMap) -> bool {
    let Some(value) = headers.get(header::AUTHORIZATION) else {
        return false;
    };
    let Ok(value) = value.to_str() else {
        return false;
    };
    let Some(key) = value
        .strip_prefix("Bearer ")
        .or_else(|| value.strip_prefix("bearer "))
    else {
        return false;
    };
    runtime.authorize(key.trim())
}

fn unauthorized() -> Response {
    (
        StatusCode::UNAUTHORIZED,
        Json(json!({ "error": { "message": "invalid api key", "type": "authentication_error", "code": "invalid_api_key" } })),
    )
        .into_response()
}

async fn chat_completions(
    State(runtime): State<SharedRuntime>,
    headers: HeaderMap,
    Json(body): Json<Value>,
) -> Response {
    if let Some(resp) = setup_not_done(&runtime) {
        return resp;
    }
    if !authorized(&runtime, &headers) {
        return unauthorized();
    }

    // Provider selection: explicit header wins, else model prefix, else
    // the registry's default provider (first BKG_PROVIDERS entry).
    let provider = headers
        .get("x-bkg-provider")
        .and_then(|v| v.to_str().ok())
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| s.to_ascii_lowercase())
        .or_else(|| {
            body.get("model")
                .and_then(|m| m.as_str())
                .map(|model| model.to_ascii_lowercase())
                .and_then(|model| {
                    runtime.config.providers.iter().find(|p| {
                        model == **p
                            || model.contains(&format!("{p}/"))
                            || model.starts_with(p.as_str())
                    })
                })
                .cloned()
        })
        .unwrap_or_else(|| runtime.config.default_provider().unwrap_or("nim").to_string());

    let decision = {
        let mut router = runtime.router.lock().expect("router lock");
        router.route(&provider)
    };
    match decision {
        RouteDecision::Forward { lane, upstream } => {
            let lane_name = lane.clone();
            let Some(client_key) = runtime.lane_key(&lane_name) else {
                return (
                    StatusCode::BAD_GATEWAY,
                    Json(json!({ "error": { "message": format!("lane '{lane_name}' has no key record") } })),
                )
                    .into_response();
            };

            let url = format!("{}/chat/completions", upstream.trim_end_matches('/'));
            let mut req = runtime
                .http
                .post(&url)
                .bearer_auth(&client_key)
                .json(&body);

            if let Some(user) = headers.get("x-bkg-user").and_then(|v| v.to_str().ok()) {
                req = req.header("x-bkg-user", user);
            }

            match req.send().await {
                Ok(resp) => {
                    let status = resp.status();
                    // nim-proxy key failover: when the upstream returns
                    // 429/5xx (quota exhausted / key blocked), bench this
                    // lane so the NEXT request automatically fails over to
                    // another key in the pool. The current response is
                    // passed through untouched.
                    if status.is_server_error() || status == StatusCode::TOO_MANY_REQUESTS {
                        let backoff = retry_after_from_headers(resp.headers())
                            .map(Duration::from_secs)
                            .unwrap_or_else(|| {
                                if status == StatusCode::TOO_MANY_REQUESTS {
                                    Duration::from_secs(60)
                                } else {
                                    Duration::from_secs(10)
                                }
                            });
                        runtime
                            .router
                            .lock()
                            .expect("router lock")
                            .penalize(&lane_name, backoff);
                    }
                    let bytes = match resp.bytes().await {
                        Ok(b) => b,
                        Err(e) => {
                            return (
                                StatusCode::BAD_GATEWAY,
                                Json(json!({ "error": { "message": format!("upstream read error: {e}") } })),
                            )
                                .into_response();
                        }
                    };
                    let mut resp = Response::new(bytes.into());
                    *resp.status_mut() = status;
                    resp
                }
                Err(e) => (
                    StatusCode::BAD_GATEWAY,
                    Json(json!({ "error": { "message": format!("upstream error: {e}") } })),
                )
                    .into_response(),
            }
        }
        RouteDecision::RateLimited {
            retry_after_ms, ..
        } => {
            let retry_after = retry_after_ms.max(1);
            let mut resp = (
                StatusCode::TOO_MANY_REQUESTS,
                Json(json!({
                    "error": {
                        "message": format!("rate limit exceeded, retry in {retry_after_ms}ms"),
                        "type": "rate_limit_error",
                        "code": "rate_limit_exceeded",
                    }
                })),
            )
                .into_response();
            resp.headers_mut().insert(
                header::RETRY_AFTER,
                header::HeaderValue::from_str(&retry_after.to_string()).unwrap(),
            );
            resp
        }
        RouteDecision::NoLane { provider } => (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(json!({ "error": { "message": format!("no enabled lane for provider '{provider}'") } })),
        )
            .into_response(),
    }
}

async fn list_models(State(runtime): State<SharedRuntime>, headers: HeaderMap) -> Response {
    if let Some(resp) = setup_not_done(&runtime) {
        return resp;
    }
    if !authorized(&runtime, &headers) {
        return unauthorized();
    }
    let router = runtime.router.lock().expect("router lock");
    let data: Vec<Value> = router
        .lane_names()
        .into_iter()
        .map(|name| json!({ "id": name, "object": "model", "owned_by": "bkg-gateway" }))
        .collect();
    (
        StatusCode::OK,
        Json(json!({ "object": "list", "data": data })),
    )
        .into_response()
}

async fn health() -> Response {
    (StatusCode::OK, Json(json!({ "status": "ok" }))).into_response()
}

/// The WebAssembly admin app lives in `BKG_UI_DIR` (default unset). When a
/// bundle is present serve `index.html`; otherwise fall back to the
/// embedded single-file SPA so the gateway works without a wasm build.
async fn dashboard_index() -> Response {
    if let Some(dir) = ui_dir() {
        let index = dir.join("index.html");
        if index.is_file() {
            return serve_file(&index, "text/html; charset=utf-8");
        }
    }
    (
        StatusCode::OK,
        [
            (header::CONTENT_TYPE, "text/html; charset=utf-8"),
            (
                header::CONTENT_SECURITY_POLICY,
                "default-src 'none'; img-src 'self' data:; \
                 style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; \
                 connect-src 'self'; font-src 'self'",
            ),
        ],
        include_str!("dashboard.html"),
    )
        .into_response()
}

/// Serve one static wasm-app asset from `BKG_UI_DIR`.
async fn ui_asset(State(_runtime): State<SharedRuntime>, Path(path): Path<String>) -> Response {
    if path.contains("..") {
        return StatusCode::NOT_FOUND.into_response();
    }
    let Some(dir) = ui_dir() else {
        return StatusCode::NOT_FOUND.into_response();
    };
    let file = dir.join(&path);
    if !file.is_file() {
        return StatusCode::NOT_FOUND.into_response();
    }
    let content_type = match PathBuf::from(&path)
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or_default()
    {
        "wasm" => "application/wasm",
        "js" => "application/javascript",
        "css" => "text/css",
        "png" => "image/png",
        "svg" => "image/svg+xml",
        "ico" => "image/x-icon",
        "woff2" => "font/woff2",
        "json" => "application/json",
        _ => "application/octet-stream",
    };
    serve_file(&file, content_type)
}

fn ui_dir() -> Option<PathBuf> {
    std::env::var("BKG_UI_DIR").ok().filter(|s| !s.is_empty()).map(PathBuf::from)
}

fn serve_file(path: &std::path::Path, content_type: &str) -> Response {
    match std::fs::read(path) {
        Ok(bytes) => (
            StatusCode::OK,
            [(header::CONTENT_TYPE, content_type)],
            bytes,
        )
            .into_response(),
        Err(_) => StatusCode::NOT_FOUND.into_response(),
    }
}

/// Point-in-time dashboard payload (mirrors nim-proxy `/api/dashboard/now`):
/// registry, lane pool state and aggregate counters.
async fn api_dashboard_now(State(runtime): State<SharedRuntime>) -> Response {
    let router = runtime.router.lock().expect("router lock");
    let snap = router.snapshot(std::time::Instant::now());
    let total_allowed: u64 = snap.iter().map(|l| l.metrics.allowed).sum();
    let total_limited: u64 = snap.iter().map(|l| l.metrics.rate_limited).sum();
    let total_errors: u64 = snap.iter().map(|l| l.metrics.errors).sum();
    let benched = snap.iter().filter(|l| l.cooldown_remaining_secs > 0).count();
    (
        StatusCode::OK,
        Json(json!({
            "version": env!("CARGO_PKG_VERSION"),
            "sampled_at": std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs())
                .unwrap_or(0),
            "uptime_secs": runtime.uptime_secs(),
            "providers": runtime.config.providers,
            "lanes": snap,
            "totals": {
                "lanes": snap.len(),
                "benched": benched,
                "allowed": total_allowed,
                "rate_limited": total_limited,
                "errors": total_errors,
            },
        })),
    )
        .into_response()
}

async fn dashboard_metrics(State(runtime): State<SharedRuntime>) -> Response {
    let router = runtime.router.lock().expect("router lock");
    let metrics = router.metrics().snapshot();
    (StatusCode::OK, Json(metrics)).into_response()
}
