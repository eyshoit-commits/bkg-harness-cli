//! In-process request server abstraction.
//!
//! Rather than pulling in a full HTTP framework in the core proxy logic,
//! this module models the request/response flow the proxy performs and
//! provides a pure decision layer that an HTTP handler (or CLI test
//! harness) can drive. The real HTTP server lives in `server.rs`.

use crate::lane::ActiveLane;
use std::collections::HashMap;
use std::time::{Duration, Instant};

/// Outcome of routing a request to a lane.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RouteDecision {
    /// The request is allowed and should be forwarded to the given lane.
    Forward { lane: String, upstream: String },
    /// The lane exists but is rate limited; retry after the given ms.
    RateLimited { lane: String, retry_after_ms: u64 },
    /// No enabled lane provides this provider.
    NoLane { provider: String },
}

/// A point-in-time snapshot of one lane for the dashboard.
#[derive(Debug, Clone, serde::Serialize)]
pub struct LaneSnapshot {
    pub name: String,
    pub provider: String,
    pub upstream_base_url: String,
    pub enabled: bool,
    pub rate_limit_per_window: usize,
    pub window_secs: u64,
    /// In-window request load (last `window_secs`, counter only).
    pub used: usize,
    /// Seconds until the cooldown bench expires (0 = ready).
    pub cooldown_remaining_secs: u64,
    pub metrics: crate::metrics::LaneMetrics,
}

/// The lane router: applies sliding-window limits and picks a lane.
///
/// Selection follows the nim-proxy key pool (`pool.rs::reserve`):
/// the least-loaded READY lane wins, lanes in cooldown (benched after an
/// upstream 429/5xx) are skipped, and if every lane is busy the soonest
/// slot is reported. With N keys configured for a provider this spreads
/// TPS across all keys and fails over to the next key automatically.
pub struct LaneRouter {
    lanes: HashMap<String, ActiveLane>,
    metrics: crate::metrics::MetricsStore,
}

impl LaneRouter {
    pub fn new() -> Self {
        Self {
            lanes: HashMap::new(),
            metrics: crate::metrics::MetricsStore::new(),
        }
    }

    pub fn add_lane(&mut self, lane: crate::lane::Lane) {
        self.lanes.insert(lane.name.clone(), ActiveLane::new(lane));
    }

    pub fn lane_names(&self) -> Vec<String> {
        let mut names: Vec<String> = self.lanes.keys().cloned().collect();
        names.sort();
        names
    }

    /// Route a request for `provider` through an enabled lane.
    ///
    /// nim-proxy semantics WITHOUT an artificial cap: every lane is ready
    /// unless it is benched in cooldown (quota exhausted / upstream
    /// 429/5xx); the least-loaded ready lane wins (spreading TPS evenly
    /// across all keys), benched lanes are skipped so the pool fails over
    /// to the next key, and when EVERY lane is benched the soonest
    /// recovery is reported. Falls back to any enabled lane (other
    /// providers) when the provider has no lanes.
    pub fn route(&mut self, provider: &str) -> RouteDecision {
        let started = Instant::now();
        let now = Instant::now();

        let provider_lanes: Vec<String> = self
            .lanes
            .iter()
            .filter(|(_, active)| active.lane.enabled && active.lane.provider == provider)
            .map(|(name, _)| name.clone())
            .collect();

        let candidates = if provider_lanes.is_empty() {
            // Fallback: any enabled lane.
            self.lanes
                .iter()
                .filter(|(_, active)| active.lane.enabled)
                .map(|(name, _)| name.clone())
                .collect::<Vec<String>>()
        } else {
            provider_lanes
        };

        if candidates.is_empty() {
            self.metrics.record_error(provider);
            return RouteDecision::NoLane {
                provider: provider.to_string(),
            };
        }

        // nim-proxy `pool::reserve` spreading: ready lanes sorted by
        // in-window load (least-loaded wins), benched lanes skipped,
        // soonest recovery tracked.
        let mut ready: Vec<(usize, String)> = Vec::new();
        let mut best_wait: Option<u64> = None;
        for name in &candidates {
            let active = self.lanes.get_mut(name).expect("lane exists");
            if active.in_cooldown(now) {
                if let Some(wait) = active.cooldown_wait(now) {
                    let wait_ms = wait.as_millis() as u64;
                    best_wait = Some(best_wait.map_or(wait_ms, |b| b.min(wait_ms)));
                }
                continue;
            }
            let load = active.load_at(now);
            ready.push((load, name.clone()));
        }
        ready.sort_unstable();
        if let Some((_, name)) = ready.into_iter().next() {
            let active = self.lanes.get_mut(&name).expect("lane exists");
            active.record(now);
            let upstream = active.lane.upstream_base_url.clone();
            self.metrics
                .record(&name, true, started.elapsed().as_millis() as u64);
            return RouteDecision::Forward {
                lane: name,
                upstream,
            };
        }

        // Every lane is benched (all keys exhausted): report the soonest
        // recovery instead of failing hard.
        let retry_after_ms = best_wait.unwrap_or(60_000);
        let lane = candidates[0].clone();
        self.metrics.record(&lane, false, 0);
        RouteDecision::RateLimited {
            lane,
            retry_after_ms,
        }
    }

    /// Bench a lane after an upstream 429/5xx (quota exhausted / key
    /// blocked): it is skipped until the backoff elapses, so the pool
    /// fails over to the next key (nim-proxy `pool::penalize`).
    pub fn penalize(&mut self, lane: &str, backoff: Duration) {
        if let Some(active) = self.lanes.get_mut(lane) {
            active.penalize(backoff);
        }
    }

    pub fn metrics(&self) -> &crate::metrics::MetricsStore {
        &self.metrics
    }

    /// Point-in-time snapshot of every lane (dashboard polling endpoint).
    pub fn snapshot(&self, now: Instant) -> Vec<LaneSnapshot> {
        let metrics = self.metrics.snapshot();
        let mut out: Vec<LaneSnapshot> = self
            .lanes
            .iter()
            .map(|(name, active)| {
                let cooldown = active
                    .cooldown_wait(now)
                    .map(|d| d.as_secs())
                    .unwrap_or(0);
                LaneSnapshot {
                    name: name.clone(),
                    provider: active.lane.provider.clone(),
                    upstream_base_url: active.lane.upstream_base_url.clone(),
                    enabled: active.lane.enabled,
                    rate_limit_per_window: active.lane.rate_limit_per_window,
                    window_secs: active.lane.window_secs,
                    used: active.used(),
                    cooldown_remaining_secs: cooldown,
                    metrics: metrics.get(name).cloned().unwrap_or_default(),
                }
            })
            .collect();
        out.sort_by(|a, b| a.name.cmp(&b.name));
        out
    }
}

impl Default for LaneRouter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_lane(provider: &str, name: &str, limit: usize) -> crate::lane::Lane {
        let mut lane = crate::lane::Lane::new(provider, name, "http://upstream/v1", "key");
        lane.rate_limit_per_window = limit;
        lane.window_secs = 60;
        lane
    }

    #[test]
    fn routes_to_matching_provider() {
        let mut router = LaneRouter::new();
        router.add_lane(test_lane("gemini", "gemini-1", 10));
        router.add_lane(test_lane("nim", "nim-1", 10));

        match router.route("gemini") {
            RouteDecision::Forward { lane, .. } => assert_eq!(lane, "gemini-1"),
            other => panic!("unexpected: {other:?}"),
        }
    }

    #[test]
    fn no_artificial_rate_limit_single_lane_never_gates() {
        let mut router = LaneRouter::new();
        router.add_lane(test_lane("gemini", "gemini-1", 1));
        // The rpm field is metadata only — the gateway imposes no cap:
        // every request goes through even though "limit" is 1.
        for _ in 0..5 {
            assert!(matches!(
                router.route("gemini"),
                RouteDecision::Forward { lane, .. } if lane == "gemini-1"
            ));
        }
    }

    #[test]
    fn multi_lane_least_loaded_spreads_across_provider_lanes() {
        let mut router = LaneRouter::new();
        router.add_lane(test_lane("gemini", "gemini-1", 10));
        router.add_lane(test_lane("gemini", "gemini-2", 10));
        router.add_lane(test_lane("gemini", "gemini-3", 10));

        let mut seen = std::collections::HashSet::new();
        for _ in 0..3 {
            match router.route("gemini") {
                RouteDecision::Forward { lane, .. } => {
                    seen.insert(lane);
                }
                other => panic!("unexpected: {other:?}"),
            }
        }
        assert_eq!(seen.len(), 3, "expected all three lanes to be used");
    }

    #[test]
    fn penalized_lane_is_skipped_so_pool_fails_over_to_next_key() {
        let mut router = LaneRouter::new();
        router.add_lane(test_lane("gemini", "gemini-1", 10));
        router.add_lane(test_lane("gemini", "gemini-2", 10));

        // Quota exhausted on gemini-1 (upstream 429/5xx) -> benched.
        router.penalize("gemini-1", Duration::from_secs(30));
        assert!(matches!(
            router.route("gemini"),
            RouteDecision::Forward { lane, .. } if lane == "gemini-2"
        ));
        // Second request still on gemini-2 (gemini-1 keeps its cooldown).
        assert!(matches!(
            router.route("gemini"),
            RouteDecision::Forward { lane, .. } if lane == "gemini-2"
        ));
    }

    #[test]
    fn all_lanes_penalized_reports_soonest_recovery() {
        let mut router = LaneRouter::new();
        router.add_lane(test_lane("gemini", "gemini-1", 10));
        router.add_lane(test_lane("gemini", "gemini-2", 10));
        router.penalize("gemini-1", Duration::from_secs(30));
        router.penalize("gemini-2", Duration::from_secs(5));
        assert!(matches!(
            router.route("gemini"),
            RouteDecision::RateLimited { retry_after_ms, .. }
                if retry_after_ms > 0 && retry_after_ms <= 5_000
        ));
    }

    #[test]
    fn routes_any_registered_provider_by_name() {
        let mut router = LaneRouter::new();
        // Provider added purely via config, no enum needed.
        router.add_lane(test_lane("nevis", "nevis-1", 10));
        match router.route("nevis") {
            RouteDecision::Forward { lane, .. } => assert_eq!(lane, "nevis-1"),
            other => panic!("unexpected: {other:?}"),
        }
    }
}
