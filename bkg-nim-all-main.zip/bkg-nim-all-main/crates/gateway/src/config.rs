//! Gateway configuration: provider registry, lanes, binds, auth records.
//!
//! Nothing is hardcoded: every address, port, URL, provider name and key
//! comes from the environment (Docker secrets / compose env). The gateway
//! and dashboard each bind their own internal-network IPv4 address so
//! traffic is separated at the network layer.

use crate::auth::ClientKeyRecord;
use crate::lane::Lane;
use std::env;
use std::net::SocketAddrV4;
use std::str::FromStr;

/// Error produced while assembling the configuration from the environment.
#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    #[error("missing required environment variable {0}")]
    Missing(String),
    #[error("invalid value for {0}: {1}")]
    Invalid(String, String),
}

impl ConfigError {
    fn missing(name: impl Into<String>) -> Self {
        ConfigError::Missing(name.into())
    }
}

/// Runtime configuration for the gateway.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct GatewayConfig {
    /// Address the OpenAI-compatible gateway API listens on.
    pub gateway_bind: SocketAddrV4,
    /// Address the dashboard listens on.
    pub dashboard_bind: SocketAddrV4,
    /// Provider registry in configured order (from `BKG_PROVIDERS`).
    pub providers: Vec<String>,
    /// Provider lanes.
    pub lanes: Vec<Lane>,
    /// Client keys allowed to use the gateway.
    pub client_keys: Vec<ClientKeyRecord>,
}

impl GatewayConfig {
    /// Build a config from the environment / Docker secrets.
    ///
    /// Required: `GATEWAY_BIND`, `DASHBOARD_BIND`, `API_KEY`
    /// (or `API_KEY_FILE` pointing at a mounted Docker secret), and
    /// `BKG_PROVIDERS` — the provider registry.
    ///
    /// Every value — ports, IPs, URLs, provider names, keys — comes from
    /// the environment, never from constants in code. Keys resolve as:
    ///   `X_KEY_FILE` -> read file (Docker secret mount, e.g. /run/secrets/x)
    ///   `X_KEY`      -> inline environment value
    ///
    /// PROVIDER REGISTRY (add ANY provider by name, nim-proxy flow):
    ///   BKG_PROVIDERS=nim,gemini,opencode,claude,my-provider,…
    ///     comma-separated list; the order defines the default provider.
    ///   For each provider name P (uppercased for env lookup):
    ///     `P_UPSTREAM`            required single base URL (nim-proxy
    ///                              `base_url`); a listed provider without
    ///                              upstream is a hard boot error
    ///     `P_API_KEYS_FILE`       bulk key pool: one key per line, any
    ///                              number of keys (100, 1000, …) — the
    ///                              practical way to add many accounts
    ///     OR numbered keys:       `P_API_KEY` / `P_API_KEY_FILE` (lane 1),
    ///                              `P_API_KEY_2` / `_FILE` (lane 2), …
    ///                              scanning until the key var is absent
    ///     `P_API_KEY_{N}_RPM`     optional per-key tier metadata
    ///                              (default 40, informational only)
    ///
    /// One lane per key against the SAME upstream: N keys = N lanes.
    /// Lane names are "{provider}-1", "{provider}-2", … The gateway
    /// imposes NO artificial rate limit and NO key-count cap — add as many
    /// keys/accounts as you like; TPS scales with the pool. When a key's
    /// free quota is exhausted (upstream 429/5xx) the lane is benched and
    /// the next key takes over automatically.
    ///
    /// Example — a 3-key Gemini pool (like nim-proxy `nim_keys`):
    ///   BKG_PROVIDERS=nim,gemini
    ///   GEMINI_UPSTREAM=https://generativelanguage.googleapis.com/v1beta
    ///   GEMINI_API_KEYS_FILE=/run/secrets/gemini_keys   (3 lines inside)
    ///
    /// A listed provider with an upstream but no key is a hard boot error
    /// (fail fast, never silently drop a configured provider).
    pub fn from_env() -> Result<Self, ConfigError> {
        let gateway_bind = parse_bind("GATEWAY_BIND")?;
        let dashboard_bind = parse_bind("DASHBOARD_BIND")?;
        let api_key = secret("API_KEY")?;
        let providers = parse_providers("BKG_PROVIDERS")?;

        let mut config = GatewayConfig {
            gateway_bind,
            dashboard_bind,
            providers,
            lanes: Vec::new(),
            client_keys: Vec::new(),
        };
        config.add_client_key(ClientKeyRecord::from_key("default", "system", &api_key));

        for provider in &config.providers.clone() {
            Self::push_provider_pool(&mut config, provider)?;
        }

        Ok(config)
    }

    /// Build ONE provider's key pool: single upstream + N keys -> N lanes.
    ///
    /// Prefers the bulk `{P}_API_KEYS_FILE` (one key per line — scales to
    /// hundreds/thousands of keys); otherwise falls back to numbered
    /// `{P}_API_KEY[_FILE]`, `{P}_API_KEY_2[_FILE]`, … until a var is
    /// absent. A listed provider without upstream or without keys is a
    /// hard error.
    fn push_provider_pool(config: &mut GatewayConfig, provider: &str) -> Result<(), ConfigError> {
        let prefix = provider.to_uppercase().replace('-', "_");
        let upstream_var = format!("{prefix}_UPSTREAM");
        let upstream = env::var(&upstream_var)
            .ok()
            .filter(|s| !s.is_empty())
            .ok_or_else(|| ConfigError::missing(&upstream_var))?;

        let keys_file_var = format!("{prefix}_API_KEYS_FILE");
        if let Ok(path) = env::var(&keys_file_var) {
            let raw = std::fs::read_to_string(&path)
                .map_err(|e| ConfigError::Invalid(keys_file_var.clone(), format!("{path}: {e}")))?;
            let keys: Vec<String> = raw
                .lines()
                .map(str::trim)
                .filter(|l| !l.is_empty())
                .map(String::from)
                .collect();
            if keys.is_empty() {
                return Err(ConfigError::Invalid(
                    keys_file_var,
                    format!("{path} contains no keys"),
                ));
            }
            for (i, key) in keys.into_iter().enumerate() {
                config.lanes.push(Lane::new(
                    provider,
                    format!("{provider}-{}", i + 1),
                    upstream.clone(),
                    key,
                ));
            }
            return Ok(());
        }

        let key_var_base = format!("{prefix}_API_KEY");
        let mut n = 1usize;
        let mut pushed = false;
        loop {
            let key_var = if n == 1 {
                key_var_base.clone()
            } else {
                format!("{key_var_base}_{n}")
            };
            let rpm_var = format!("{key_var}_RPM");
            let key = match secret(&key_var) {
                Ok(k) if !k.trim().is_empty() => k,
                Ok(_) if n == 1 => return Err(ConfigError::missing(&key_var)),
                Err(_) if n == 1 => return Err(ConfigError::missing(&key_var)),
                _ => break, // end of the key pool
            };
            let rpm = env::var(&rpm_var)
                .ok()
                .and_then(|s| s.parse::<usize>().ok())
                .unwrap_or(crate::lane::DEFAULT_RPM);
            let mut lane = Lane::new(provider, format!("{provider}-{n}"), upstream.clone(), key);
            lane.rate_limit_per_window = rpm;
            config.lanes.push(lane);
            pushed = true;
            n += 1;
        }
        if !pushed {
            return Err(ConfigError::missing(&key_var_base));
        }
        Ok(())
    }

    pub fn add_lane(&mut self, lane: Lane) {
        self.lanes.push(lane);
    }

    pub fn add_client_key(&mut self, record: ClientKeyRecord) {
        self.client_keys.push(record);
    }

    /// Find a client key record that verifies against the presented key.
    pub fn authorize(&self, presented: &str) -> bool {
        self.client_keys
            .iter()
            .any(|record| record.verify(presented))
    }

    /// Find an enabled lane by provider name.
    pub fn lane_for(&self, provider: &str) -> Option<&Lane> {
        self.lanes
            .iter()
            .find(|lane| lane.provider == provider && lane.enabled)
    }

    /// All enabled lanes for a provider (the provider's key pool).
    pub fn lanes_for(&self, provider: &str) -> Vec<&Lane> {
        self.lanes
            .iter()
            .filter(|lane| lane.provider == provider && lane.enabled)
            .collect()
    }

    /// The default provider: the first entry of the registry, when present.
    pub fn default_provider(&self) -> Option<&str> {
        self.providers.first().map(String::as_str)
    }
}

/// Parse `BKG_PROVIDERS` into a deduplicated, ordered, validated list.
fn parse_providers(var: &'static str) -> Result<Vec<String>, ConfigError> {
    let raw = env::var(var).map_err(|_| ConfigError::missing(var))?;
    let mut seen = std::collections::HashSet::new();
    let mut out = Vec::new();
    for name in raw.split(',') {
        let name = name.trim().to_ascii_lowercase();
        if name.is_empty() {
            continue;
        }
        let ok = name.chars().all(|c| c.is_ascii_alphanumeric() || c == '-');
        if !ok || name.len() > 64 {
            return Err(ConfigError::Invalid(
                var.to_string(),
                format!("provider name {name:?} must be <=64 chars of letters, digits or '-'"),
            ));
        }
        if seen.insert(name.clone()) {
            out.push(name);
        }
    }
    if out.is_empty() {
        return Err(ConfigError::Invalid(
            var.to_string(),
            "must list at least one provider".into(),
        ));
    }
    Ok(out)
}

fn parse_bind(var: &'static str) -> Result<SocketAddrV4, ConfigError> {
    let raw = env::var(var).map_err(|_| ConfigError::missing(var))?;
    // Accept "0.0.0.0:666" or "172.28.0.20:666".
    let addr = SocketAddrV4::from_str(&raw)
        .map_err(|e| ConfigError::Invalid(var.to_string(), format!("{raw}: {e}")))?;
    Ok(addr)
}

/// Resolve a secret: `{NAME}_FILE` (Docker secret mount) wins, otherwise
/// the inline `{NAME}` environment value. Missing file -> empty value.
fn secret(name: &str) -> Result<String, ConfigError> {
    let file_var = format!("{name}_FILE");
    if let Ok(path) = env::var(&file_var) {
        let content = std::fs::read_to_string(&path)
            .map_err(|e| ConfigError::Invalid(file_var.clone(), format!("{path}: {e}")))?;
        let trimmed = content.trim().to_string();
        if trimmed.is_empty() {
            return Err(ConfigError::Invalid(file_var, format!("{path} is empty")));
        }
        return Ok(trimmed);
    }
    env::var(name).map_err(|_| ConfigError::missing(name))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// All config tests mutate process-global env vars, so they must run
    /// strictly one at a time. Poisoned-lock recovery: even if a panic
    /// happened, the env state is reset by the next `clear_all()`.
    static ENV_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    fn lock_env() -> std::sync::MutexGuard<'static, ()> {
        ENV_LOCK.lock().unwrap_or_else(|e| e.into_inner())
    }

    fn clear_all() {
        for var in [
            "GATEWAY_BIND",
            "DASHBOARD_BIND",
            "API_KEY",
            "API_KEY_FILE",
            "BKG_PROVIDERS",
            "NIM_UPSTREAM",
            "NIM_API_KEY",
            "NIM_API_KEY_FILE",
            "NIM_API_KEYS_FILE",
            "GEMINI_UPSTREAM",
            "GEMINI_API_KEY",
            "GEMINI_API_KEY_FILE",
            "GEMINI_API_KEYS_FILE",
            "GEMINI_API_KEY_2",
            "GEMINI_API_KEY_2_FILE",
            "GEMINI_API_KEY_2_RPM",
            "GEMINI_API_KEY_3",
            "GEMINI_API_KEY_3_FILE",
            "GEMINI_API_KEY_3_RPM",
            "OPENCODE_UPSTREAM",
            "OPENCODE_API_KEY",
            "OPENCODE_API_KEY_FILE",
            "OPENCODE_API_KEYS_FILE",
            "NEVIS_UPSTREAM",
            "NEVIS_API_KEY",
            "NEVIS_API_KEY_FILE",
            "NEVIS_API_KEYS_FILE",
            "MY_CUSTOM_UPSTREAM",
            "MY_CUSTOM_API_KEY",
            "MY_CUSTOM_API_KEYS_FILE",
        ] {
            env::remove_var(var);
        }
    }

    #[test]
    fn from_env_requires_binds_and_key() {
        let _guard = lock_env();
        clear_all();
        let err = GatewayConfig::from_env().unwrap_err();
        assert!(
            matches!(err, ConfigError::Missing(ref v) if v == "GATEWAY_BIND"),
            "unexpected error: {err:?}"
        );
    }

    #[test]
    fn from_env_requires_provider_registry() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        let err = GatewayConfig::from_env().unwrap_err();
        assert!(
            matches!(err, ConfigError::Missing(ref v) if v == "BKG_PROVIDERS"),
            "registry must be explicit, no hardcoded providers: {err:?}"
        );
    }

    #[test]
    fn from_env_builds_lanes_from_vars() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "nim,gemini,opencode");
        env::set_var("NIM_UPSTREAM", "http://172.28.0.30:8066/v1");
        env::set_var("NIM_API_KEY", "npk_nim");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );
        env::set_var("GEMINI_API_KEY", "gpk_test");
        env::set_var("OPENCODE_UPSTREAM", "https://api.opencode.ai/v1");
        env::set_var("OPENCODE_API_KEY", "opk_test");

        let config = GatewayConfig::from_env().unwrap();
        assert_eq!(config.gateway_bind.port(), 666);
        assert_eq!(config.dashboard_bind.port(), 7666);
        assert!(config.authorize("npk_test"));
        assert_eq!(config.providers, vec!["nim", "gemini", "opencode"]);
        assert_eq!(config.default_provider(), Some("nim"));
        assert_eq!(config.lanes.len(), 3);
        assert_eq!(
            config.lane_for("nim").unwrap().upstream_base_url,
            "http://172.28.0.30:8066/v1"
        );
        assert_eq!(config.lane_for("gemini").unwrap().provider, "gemini");
        assert_eq!(config.lane_for("opencode").unwrap().provider, "opencode");
    }

    #[test]
    fn registry_accepts_any_provider_name() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        // A provider the user adds by name — no code changes needed.
        env::set_var("BKG_PROVIDERS", "nevis,my-custom");
        env::set_var("NEVIS_UPSTREAM", "https://api.nevis.ai/v1");
        env::set_var("NEVIS_API_KEY", "nvk_1");
        env::set_var("MY_CUSTOM_UPSTREAM", "http://172.28.0.40:9000/v1");
        env::set_var("MY_CUSTOM_API_KEY", "mk_1");

        let config = GatewayConfig::from_env().unwrap();
        assert_eq!(config.providers, vec!["nevis", "my-custom"]);
        assert_eq!(config.lanes_for("nevis").len(), 1);
        assert_eq!(config.lane_for("my-custom").unwrap().client_key, "mk_1");
    }

    #[test]
    fn from_env_builds_gemini_key_pool_multi_lane() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "gemini");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );
        env::set_var("GEMINI_API_KEY", "gpk_lane1");
        env::set_var("GEMINI_API_KEY_2", "gpk_lane2");
        env::set_var("GEMINI_API_KEY_2_RPM", "60");
        env::set_var("GEMINI_API_KEY_3", "gpk_lane3");

        let config = GatewayConfig::from_env().unwrap();
        let gemini_lanes = config.lanes_for("gemini");
        assert_eq!(gemini_lanes.len(), 3, "expected 3 gemini lanes");
        assert_eq!(gemini_lanes[0].name, "gemini-1");
        assert_eq!(gemini_lanes[1].name, "gemini-2");
        assert_eq!(gemini_lanes[2].name, "gemini-3");
        assert_eq!(gemini_lanes[1].client_key, "gpk_lane2");
        // nim-proxy key-pool semantics: ONE upstream for every lane.
        for lane in &gemini_lanes {
            assert_eq!(
                lane.upstream_base_url,
                "https://generativelanguage.googleapis.com/v1beta"
            );
        }
        // Per-key rpm honored (default 40, nim-proxy parity).
        assert_eq!(gemini_lanes[0].rate_limit_per_window, 40);
        assert_eq!(gemini_lanes[1].rate_limit_per_window, 60);
        assert_eq!(gemini_lanes[2].rate_limit_per_window, 40);
    }

    #[test]
    fn bulk_keys_file_scales_to_many_keys() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "nevis");

        let dir = tempfile::tempdir().unwrap();
        let keys_file = dir.path().join("nevis_keys");
        // 1000 lines — the next-day key pool size.
        let mut content = String::new();
        for i in 1..=1000 {
            content.push_str(&format!("nvk_key_{i}\n"));
        }
        std::fs::write(&keys_file, &content).unwrap();
        env::set_var("NEVIS_UPSTREAM", "https://api.nevis.ai/v1");
        env::set_var("NEVIS_API_KEYS_FILE", &keys_file);

        let config = GatewayConfig::from_env().unwrap();
        let lanes = config.lanes_for("nevis");
        assert_eq!(lanes.len(), 1000, "one lane per key, no cap");
        assert_eq!(lanes[0].name, "nevis-1");
        assert_eq!(lanes[999].name, "nevis-1000");
        assert_eq!(lanes[999].client_key, "nvk_key_1000");
        assert_eq!(lanes[999].upstream_base_url, "https://api.nevis.ai/v1");
    }

    #[test]
    fn listed_provider_without_upstream_is_a_hard_error() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "gemini,nevis");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );
        env::set_var("GEMINI_API_KEY", "gpk_1");
        // NEVIS_UPSTREAM missing -> fail fast on the listed provider.
        let err = GatewayConfig::from_env().unwrap_err();
        assert!(
            matches!(err, ConfigError::Missing(ref v) if v == "NEVIS_UPSTREAM"),
            "listed provider without upstream must fail fast: {err:?}"
        );
    }

    #[test]
    fn upstream_without_key_is_a_hard_error() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "gemini");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );

        let err = GatewayConfig::from_env().unwrap_err();
        assert!(
            matches!(err, ConfigError::Missing(ref v) if v == "GEMINI_API_KEY"),
            "configured upstream without key must fail fast: {err:?}"
        );
    }

    #[test]
    fn key_pool_stops_at_first_missing_key() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("API_KEY", "npk_test");
        env::set_var("BKG_PROVIDERS", "gemini");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );
        env::set_var("GEMINI_API_KEY", "gpk_lane1");
        // No GEMINI_API_KEY_2 -> the pool ends at lane 1.
        let config = GatewayConfig::from_env().unwrap();
        assert_eq!(config.lanes_for("gemini").len(), 1);
    }

    #[test]
    fn from_env_reads_keys_from_docker_secret_files() {
        let _guard = lock_env();
        clear_all();
        env::set_var("GATEWAY_BIND", "0.0.0.0:666");
        env::set_var("DASHBOARD_BIND", "0.0.0.0:7666");
        env::set_var("BKG_PROVIDERS", "nim,gemini,opencode");
        env::set_var("NIM_UPSTREAM", "http://172.28.0.30:8066/v1");
        env::set_var(
            "GEMINI_UPSTREAM",
            "https://generativelanguage.googleapis.com/v1beta",
        );
        env::set_var("OPENCODE_UPSTREAM", "https://api.opencode.ai/v1");

        let dir = tempfile::tempdir().unwrap();
        let api_file = dir.path().join("api_key");
        let nim_file = dir.path().join("nim_key");
        let gemini_file = dir.path().join("gemini_key");
        let opencode_file = dir.path().join("opencode_key");
        std::fs::write(&api_file, "npk_secret_file\n").unwrap();
        std::fs::write(&nim_file, "npk_nim_secret\n").unwrap();
        std::fs::write(&gemini_file, "gpk_secret\n").unwrap();
        std::fs::write(&opencode_file, "opk_secret\n").unwrap();

        env::set_var("API_KEY_FILE", &api_file);
        env::set_var("NIM_API_KEY_FILE", &nim_file);
        env::set_var("GEMINI_API_KEY_FILE", &gemini_file);
        env::set_var("OPENCODE_API_KEY_FILE", &opencode_file);

        let config = GatewayConfig::from_env().unwrap();
        assert!(config.authorize("npk_secret_file"));
        assert_eq!(config.lane_for("nim").unwrap().client_key, "npk_nim_secret");
        assert_eq!(config.lane_for("gemini").unwrap().client_key, "gpk_secret");
        assert_eq!(
            config.lane_for("opencode").unwrap().client_key,
            "opk_secret"
        );
    }
}
