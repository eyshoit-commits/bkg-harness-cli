//! Proxy metrics: counters and snapshots for the dashboard.

use std::collections::HashMap;
use std::sync::Mutex;

/// Aggregate request counters per lane.
#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct LaneMetrics {
    pub requests: u64,
    pub allowed: u64,
    pub rate_limited: u64,
    pub errors: u64,
    pub avg_latency_ms: u64,
}

impl LaneMetrics {
    fn record(&mut self, allowed: bool) {
        self.requests += 1;
        if allowed {
            self.allowed += 1;
        } else {
            self.rate_limited += 1;
        }
    }
}

/// Thread-safe metrics store.
#[derive(Debug, Default)]
pub struct MetricsStore {
    lanes: Mutex<HashMap<String, LaneMetrics>>,
}

impl MetricsStore {
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a request outcome against a lane name.
    pub fn record(&self, lane: &str, allowed: bool, latency_ms: u64) {
        let mut lanes = self.lanes.lock().unwrap();
        let metrics = lanes.entry(lane.to_string()).or_default();
        metrics.record(allowed);
        metrics.avg_latency_ms = if metrics.requests == 1 {
            latency_ms
        } else {
            (metrics.avg_latency_ms + latency_ms) / 2
        };
    }

    pub fn record_error(&self, lane: &str) {
        let mut lanes = self.lanes.lock().unwrap();
        lanes.entry(lane.to_string()).or_default().errors += 1;
    }

    /// Snapshot for the dashboard.
    pub fn snapshot(&self) -> HashMap<String, LaneMetrics> {
        self.lanes.lock().unwrap().clone()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn metrics_accumulate() {
        let store = MetricsStore::new();
        store.record("nim", true, 10);
        store.record("nim", false, 0);
        store.record_error("nim");
        let snap = store.snapshot();
        let m = &snap["nim"];
        assert_eq!(m.requests, 2);
        assert_eq!(m.allowed, 1);
        assert_eq!(m.rate_limited, 1);
        assert_eq!(m.errors, 1);
    }
}
