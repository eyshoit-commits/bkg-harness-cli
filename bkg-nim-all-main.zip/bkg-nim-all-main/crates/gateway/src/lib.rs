//! OpenAI-compatible multi-provider gateway.
//!
//! The gateway routes OpenAI-style requests to provider lanes (nim, gemini,
//! opencode). Each lane owns a sliding-window rate limiter and its own
//! upstream endpoint and client key — one lane per provider key, matching
//! the rate-limit-conscious design from the reference implementation.
//!
//! The gateway listens on a dedicated internal IPv4 address, while the
//! dashboard listens on a separate internal IPv4 address, so traffic can be
//! split at the network layer. No ports or keys are hardcoded: everything
//! comes from the environment (`GatewayConfig::from_env`).
//!
//! Admin surface (nim-proxy parity):
//! - `admin` — argon2 password hashing, HMAC-signed session cookies,
//!   failed-login throttle;
//! - `store` — persisted gateway state (`BKG_STATE_FILE`): superuser,
//!   runtime client keys, runtime provider key pools + upstream overrides;
//! - `settings` — setup wizard + login/logout + settings JSON API;
//! - `routes` — router rebuild from env+state and upstream key probing.

pub mod admin;
pub mod auth;
pub mod config;
pub mod lane;
pub mod metrics;
pub mod routes;
pub mod server;
pub mod settings;
pub mod store;

pub use admin::*;
pub use auth::*;
pub use config::*;
pub use lane::*;
pub use metrics::*;
pub use routes::*;
pub use server::*;
pub use settings::*;
pub use store::*;
