//! Admin authentication: argon2 password hashing, HMAC-signed session
//! cookies and a failed-login throttle.
//!
//! Mirrors the nim-proxy auth posture:
//! - passwords are stored as salted argon2 hashes (never plaintext);
//! - sessions are `hex(expiry).hex(username).pw_fragment.hex(hmac)` signed
//!   with a persistent per-install secret (unlike nim-proxy's per-boot key,
//!   ours survives restarts so a logged-in operator stays logged in);
//! - password verification is CPU-bound by design -> run in
//!   `spawn_blocking` on request paths;
//! - a fixed-window throttle backs off brute force (per process, cheap
//!   backstop; the reverse proxy should do IP-level limiting).

use hmac::{Hmac, Mac};
use sha2::{Digest, Sha256};
use std::time::{SystemTime, UNIX_EPOCH};

/// PBKDF2-style iteration default handled by argon2 crate defaults; we
/// configure argon2id with OWASP-recognized parameters.
const ARGON2_MEM_COST_KIB: u32 = 19_456; // 19 MiB
const ARGON2_TIME_COST: u32 = 2;
const ARGON2_PARALLELISM: u32 = 1;

pub fn sha256_hex(s: &str) -> String {
    hex::encode(Sha256::digest(s.as_bytes()))
}

/// Hash a password for storage: `argon2id$v=19$m=19456,t=2,p=1$<salt>$<hash>`.
pub fn hash_password(password: &str) -> String {
    use argon2::password_hash::{PasswordHasher, SaltString};
    // 16 bytes of OS randomness for the salt (getrandom is available
    // without extra features on every supported target).
    let mut salt_bytes = [0u8; 16];
    getrandom::getrandom(&mut salt_bytes).expect("OS RNG for password salt");
    let salt = SaltString::encode_b64(&salt_bytes).expect("salt bytes are valid base64");
    let params = argon2::Params::new(
        ARGON2_MEM_COST_KIB,
        ARGON2_TIME_COST,
        ARGON2_PARALLELISM,
        None,
    )
    .expect("argon2 params are valid");
    argon2::Argon2::new(argon2::Algorithm::Argon2id, argon2::Version::V0x13, params)
        .hash_password(password.as_bytes(), &salt)
        .expect("argon2 hashing")
        .to_string()
}

/// Verify a password against a stored argon2id hash string; malformed
/// strings fail closed. Call inside `spawn_blocking` on request paths.
pub fn verify_password(password: &str, stored: &str) -> bool {
    use argon2::password_hash::{PasswordHash, PasswordVerifier};
    let Ok(parsed) = PasswordHash::new(stored) else {
        return false;
    };
    argon2::Argon2::default()
        .verify_password(password.as_bytes(), &parsed)
        .is_ok()
}

/// First 8 hex chars of SHA-256(password_hash): binds a session to a
/// password *generation* (invalidation on change) without leaking the hash.
fn pw_fragment(password_hash: &str) -> String {
    sha256_hex(password_hash)[..8].to_owned()
}

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

const SESSION_TTL_SECS: u64 = 30 * 24 * 3600; // 30 days
const THROTTLE_WINDOW_SECS: u64 = 60;
const THROTTLE_MAX_FAILURES: u32 = 10;

/// Session signing + login throttle. The signing key is provided by the
/// persisted gateway state (stable across restarts).
pub struct Admin {
    signing_key: [u8; 32],
    throttle: std::sync::Mutex<Throttle>,
}

#[derive(Default)]
struct Throttle {
    window_start: u64,
    failures: u32,
}

impl Admin {
    pub fn new(signing_key: [u8; 32]) -> Self {
        Self {
            signing_key,
            throttle: std::sync::Mutex::new(Throttle {
                window_start: now(),
                failures: 0,
            }),
        }
    }

    fn mac(&self, parts: &[&[u8]]) -> [u8; 32] {
        let mut mac = Hmac::<Sha256>::new_from_slice(&self.signing_key)
            .expect("HMAC accepts any key length");
        for p in parts {
            mac.update(&(p.len() as u64).to_be_bytes()); // length-prefix each part
            mac.update(p);
        }
        mac.finalize().into_bytes().into()
    }

    /// Mint a session token for `username`:
    /// `hex(expiry).hex(username).pw_fragment.hex(hmac)`.
    pub fn sign_session(&self, username: &str, password_hash: &str) -> String {
        let expiry = now() + SESSION_TTL_SECS;
        let frag = pw_fragment(password_hash);
        let tag = self.mac(&[&expiry.to_be_bytes(), username.as_bytes(), frag.as_bytes()]);
        format!(
            "{expiry:x}.{}.{frag}.{}",
            hex::encode(username.as_bytes()),
            hex::encode(tag)
        )
    }

    /// Verify a session token: signature intact, not expired, the user
    /// still exists with the same password generation. Returns the
    /// authenticated username.
    pub fn verify_session<F>(&self, token: &str, lookup: F) -> Option<String>
    where
        F: Fn(&str) -> Option<String>, // username -> current password_hash
    {
        let mut parts = token.split('.');
        let (Some(exp_hex), Some(user_hex), Some(frag), Some(tag_hex), None) = (
            parts.next(),
            parts.next(),
            parts.next(),
            parts.next(),
            parts.next(),
        ) else {
            return None;
        };
        let Ok(expiry) = u64::from_str_radix(exp_hex, 16) else {
            return None;
        };
        if expiry < now() {
            return None;
        }
        let Ok(username_bytes) = hex::decode(user_hex) else {
            return None;
        };
        let Ok(username) = String::from_utf8(username_bytes) else {
            return None;
        };
        let Ok(tag) = hex::decode(tag_hex) else {
            return None;
        };
        let expected = self.mac(&[&expiry.to_be_bytes(), username.as_bytes(), frag.as_bytes()]);
        if tag.len() != expected.len() || !constant_time_eq(&tag, &expected) {
            return None;
        }
        let current_hash = lookup(&username)?;
        if pw_fragment(&current_hash) != frag {
            return None; // password changed since minting
        }
        Some(username)
    }

    /// Record a failed attempt; returns true if the caller is now throttled.
    pub fn note_failure(&self) -> bool {
        let mut t = self.throttle.lock().unwrap();
        let n = now();
        if n >= t.window_start + THROTTLE_WINDOW_SECS {
            t.window_start = n;
            t.failures = 0;
        }
        t.failures += 1;
        t.failures >= THROTTLE_MAX_FAILURES
    }

    pub fn is_throttled(&self) -> bool {
        let t = self.throttle.lock().unwrap();
        let n = now();
        t.failures > 0 && n < t.window_start + THROTTLE_WINDOW_SECS && t.failures >= THROTTLE_MAX_FAILURES
    }
}

/// Name of the admin session cookie.
pub const SESSION_COOKIE: &str = "bkg_session";

impl Admin {
    /// A `Set-Cookie` value that installs a fresh session:
    /// `bkg_session=<token>; HttpOnly; SameSite=Lax; Path=/; Max-Age=<ttl>`.
    pub fn session_cookie(&self, username: &str, password_hash: &str) -> String {
        let token = self.sign_session(username, password_hash);
        format!(
            "{SESSION_COOKIE}={token}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_TTL_SECS}"
        )
    }
}

/// A `Set-Cookie` value that expires the session immediately.
pub fn expire_session_cookie() -> String {
    format!("{SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0")
}

/// Extract the value of one cookie from a `Cookie` request header.
pub fn parse_cookie(header: &str, name: &str) -> Option<String> {
    for part in header.split(';') {
        let part = part.trim();
        if let Some((n, v)) = part.split_once('=') {
            if n.trim() == name {
                return Some(v.trim().to_owned());
            }
        }
    }
    None
}

/// Constant-time byte equality.
fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn password_roundtrip() {
        let hash = hash_password("correct horse battery staple");
        assert!(verify_password("correct horse battery staple", &hash));
        assert!(!verify_password("wrong", &hash));
        assert!(!verify_password("correct horse battery staple", "not-a-hash"));
    }

    #[test]
    fn session_signs_and_verifies() {
        let admin = Admin::new([7u8; 32]);
        let hash = hash_password("pw");
        let token = admin.sign_session("chief", &hash);
        let lookup = |name: &str| (name == "chief").then(|| hash.clone());
        assert_eq!(admin.verify_session(&token, lookup).as_deref(), Some("chief"));
    }

    #[test]
    fn session_rejects_tampered_token() {
        let admin = Admin::new([7u8; 32]);
        let hash = hash_password("pw");
        let token = admin.sign_session("chief", &hash);
        let mut tampered = token.clone();
        let last = tampered.len() - 1;
        tampered.replace_range(last.., if &tampered[last..] == "a" { "b" } else { "a" });
        let lookup = |name: &str| (name == "chief").then(|| hash.clone());
        assert_eq!(admin.verify_session(&tampered, lookup), None);
    }

    #[test]
    fn session_rejects_after_password_change() {
        let admin = Admin::new([7u8; 32]);
        let old_hash = hash_password("old");
        let token = admin.sign_session("chief", &old_hash);
        let new_hash = hash_password("new");
        let lookup = |name: &str| (name == "chief").then(|| new_hash.clone());
        assert_eq!(admin.verify_session(&token, lookup), None);
    }

    #[test]
    fn throttle_blocks_after_max_failures() {
        let admin = Admin::new([7u8; 32]);
        assert!(!admin.is_throttled());
        for _ in 0..10 {
            admin.note_failure();
        }
        assert!(admin.is_throttled());
    }

    #[test]
    fn session_cookie_installs_and_parses() {
        let admin = Admin::new([9u8; 32]);
        let hash = hash_password("pw");
        let cookie = admin.session_cookie("chief", &hash);
        assert!(cookie.starts_with(&format!("{SESSION_COOKIE}=")));
        assert!(cookie.contains("HttpOnly"));
        assert!(cookie.contains("SameSite=Lax"));
        assert!(cookie.contains("Path=/"));
        let value = cookie.split(';').next().unwrap().split_once('=').unwrap().1;
        let lookup = |name: &str| (name == "chief").then(|| hash.clone());
        assert_eq!(admin.verify_session(value, lookup).as_deref(), Some("chief"));
    }

    #[test]
    fn expire_cookie_zeroes_max_age() {
        let cookie = expire_session_cookie();
        assert!(cookie.starts_with(&format!("{SESSION_COOKIE}=")));
        assert!(cookie.contains("Max-Age=0"));
    }

    #[test]
    fn parse_cookie_finds_named_value() {
        let header = "other=1; bkg_session=abc123; third=2";
        assert_eq!(parse_cookie(header, "bkg_session").as_deref(), Some("abc123"));
        assert_eq!(parse_cookie(header, "missing"), None);
        assert_eq!(parse_cookie("bkg_session=", "bkg_session").as_deref(), Some(""));
    }
}
