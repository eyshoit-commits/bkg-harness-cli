//! Client key authentication: constant-time comparison, SHA-256 digests.

use sha2::{Digest, Sha256};

/// A client key plus its stored SHA-256 digest and last-4 fingerprint.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ClientKeyRecord {
    pub id: String,
    pub digest: String,
    pub last4: String,
    pub owner: String,
}

impl ClientKeyRecord {
    /// Derive the storage record for a raw key.
    pub fn from_key(id: impl Into<String>, owner: impl Into<String>, key: &str) -> Self {
        let digest = hex::encode(Sha256::digest(key.as_bytes()));
        let last4 = key
            .chars()
            .rev()
            .take(4)
            .collect::<String>()
            .chars()
            .rev()
            .collect();
        Self {
            id: id.into(),
            digest,
            last4,
            owner: owner.into(),
        }
    }

    /// Constant-time comparison of a presented key against the digest.
    pub fn verify(&self, presented: &str) -> bool {
        let presented_digest = hex::encode(Sha256::digest(presented.as_bytes()));
        constant_time_eq(&presented_digest, &self.digest)
    }
}

/// Constant-time byte equality.
fn constant_time_eq(a: &str, b: &str) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.bytes().zip(b.bytes()) {
        diff |= x ^ y;
    }
    diff == 0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn record_derives_digest_and_last4() {
        let record = ClientKeyRecord::from_key("k1", "alice", "npk_abcdef1234");
        assert_eq!(record.last4, "1234");
        assert_eq!(record.digest.len(), 64); // sha256 hex
        assert!(record.verify("npk_abcdef1234"));
        assert!(!record.verify("npk_abcdef9999"));
    }

    #[test]
    fn constant_time_eq_works() {
        assert!(constant_time_eq("abc", "abc"));
        assert!(!constant_time_eq("abc", "abd"));
        assert!(!constant_time_eq("a", "ab"));
    }
}
