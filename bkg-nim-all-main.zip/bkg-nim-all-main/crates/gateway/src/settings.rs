//! Admin settings API (nim-proxy `settings.rs` features, BKG delivery:
//! the UI is a compiled WebAssembly app served at `/`, this module is the
//! JSON API it talks to).
//!
//! - `POST /setup` + `POST /setup/validate-key` — first-run wizard:
//!   atomic superuser claim + initial provider keys + optional first client
//!   key. `/v1` stays closed (503) until setup completes.
//! - `POST /api/login` + `POST /api/logout` — admin session (HMAC cookie).
//! - `GET /api/config` — read-only view (providers, upstreams, key
//!   fingerprints, client keys, users).
//! - `POST /api/settings/keys` — add / disable / enable / delete a runtime
//!   provider key (one lane per key).
//! - `POST /api/settings/clients` — mint a client key; the secret is shown
//!   exactly once.
//! - `POST /api/settings/account` — password change.
//!
//! Every mutation persists to `BKG_STATE_FILE` and rebuilds the live
//! router so it takes effect immediately. API handlers return the same
//! error shape as the proxy (`{"error":{...}}`).

use crate::admin::Admin;
use crate::config::GatewayConfig;
use crate::routes::rebuild_router;
use crate::server::LaneRouter;
use crate::store::{GatewayState, Role, RuntimeKey, UserRecord, save_state, state_path};
use axum::extract::State;
use axum::http::{HeaderMap, StatusCode, header};
use axum::response::{IntoResponse, Response};
use axum::Json;
use serde::Deserialize;
use serde_json::json;
use std::sync::atomic::Ordering;
use std::sync::{Arc, Mutex};

/// Shared runtime: config + persisted state + live router + admin.
pub struct Runtime {
    pub config: GatewayConfig,
    pub store: Mutex<GatewayState>,
    pub setup_required: std::sync::atomic::AtomicBool,
    pub admin: Admin,
    pub http: reqwest::Client,
    pub router: Arc<Mutex<LaneRouter>>,
    /// lane name -> live client key (env + runtime lanes), used by the
    /// proxy when forwarding a routed request.
    pub lane_keys: Mutex<std::collections::HashMap<String, String>>,
    started: std::time::SystemTime,
}

impl Runtime {
    pub fn new(config: GatewayConfig) -> Self {
        let path = state_path();
        let store = crate::store::load_state(&path);
        let setup_required = std::sync::atomic::AtomicBool::new(store.superuser().is_none());
        let admin = Admin::new(store.signing_key());
        let mut router = LaneRouter::new();
        let lane_keys = rebuild_router(&mut router, &config, &store);
        Self {
            config,
            store: Mutex::new(store),
            setup_required,
            admin,
            http: reqwest::Client::new(),
            router: Arc::new(Mutex::new(router)),
            lane_keys: Mutex::new(lane_keys),
            started: std::time::SystemTime::now(),
        }
    }

    /// Rebuild the live router from env lanes + persisted state. Call
    /// after every key/upstream mutation.
    pub fn reload_router(&self) {
        let store = self.store.lock().unwrap();
        let mut router = self.router.lock().unwrap();
        let keys = rebuild_router(&mut router, &self.config, &store);
        *self.lane_keys.lock().unwrap() = keys;
    }

    /// The live client key for a routed lane (env or runtime).
    pub fn lane_key(&self, lane_name: &str) -> Option<String> {
        self.lane_keys.lock().unwrap().get(lane_name).cloned()
    }

    /// Process uptime in whole seconds (dashboard display).
    pub fn uptime_secs(&self) -> u64 {
        self.started.elapsed().map(|d| d.as_secs()).unwrap_or(0)
    }

    /// A presented /v1 key is valid if it matches an env key OR a
    /// runtime-minted client key.
    pub fn authorize(&self, presented: &str) -> bool {
        self.config.authorize(presented)
            || self.store.lock().unwrap().client_authorize(presented)
    }
}

fn json_error(status: StatusCode, code: &str, message: impl Into<String>) -> Response {
    (
        status,
        Json(json!({
            "error": { "message": message.into(), "type": "proxy_error", "code": code }
        })),
    )
        .into_response()
}

fn ok_json(v: serde_json::Value) -> Response {
    (StatusCode::OK, Json(v)).into_response()
}

// ---------------------------------------------------------------------------
// Setup wizard (first run)
// ---------------------------------------------------------------------------

#[derive(Deserialize)]
pub struct SetupReq {
    username: String,
    password: String,
    /// Optional upstream override + initial keys per provider (the wizard's
    /// advanced field, nim-proxy parity).
    #[serde(default)]
    providers: Vec<SetupProvider>,
    /// Mint a first client key so a fresh gateway can serve /v1 at once.
    #[serde(default)]
    create_client_key: Option<CreateClientKey>,
}

#[derive(Deserialize)]
pub struct SetupProvider {
    name: String,
    #[serde(default)]
    upstream: Option<String>,
    #[serde(default)]
    keys: Vec<SetupKey>,
}

#[derive(Deserialize)]
pub struct CreateClientKey {
    name: String,
}

#[derive(Deserialize)]
pub struct SetupKey {
    key: String,
    #[serde(default)]
    rpm: Option<usize>,
}

/// `POST /setup` — one atomic claim: create the superuser, record the
/// initial provider keys, persist, rebuild the router and mint a session.
/// An abandoned wizard leaves nothing behind.
pub async fn setup_submit(
    State(runtime): State<Arc<Runtime>>,
    Json(req): Json<SetupReq>,
) -> Response {
    if !runtime.setup_required.load(Ordering::SeqCst) {
        return json_error(
            StatusCode::CONFLICT,
            "already_configured",
            "setup was already completed",
        );
    }
    if req.username.trim().is_empty() {
        return json_error(StatusCode::BAD_REQUEST, "missing_username", "username is required");
    }
    if req.password.len() < 10 {
        return json_error(
            StatusCode::BAD_REQUEST,
            "weak_password",
            "password must be at least 10 characters",
        );
    }
    let password = req.password.clone();
    let hash = tokio::task::spawn_blocking(move || crate::admin::hash_password(&password))
        .await
        .expect("hashing task");

    let mut minted: Option<(String, String)> = None; // (name, secret)
    {
        let mut guard = runtime.store.lock().unwrap();
        if guard.superuser().is_some() {
            // Two claimers raced; the store lock made the first win whole.
            return json_error(
                StatusCode::CONFLICT,
                "already_configured",
                "setup was just completed by someone else",
            );
        }
        guard.users.push(UserRecord {
            username: req.username.trim().to_owned(),
            password_hash: hash.clone(),
            role: Role::Superuser,
        });
        // Initial provider keys + upstream overrides.
        for p in &req.providers {
            let name = p.name.trim().to_ascii_lowercase();
            if name.is_empty() {
                continue;
            }
            let entry = guard.providers.entry(name).or_default();
            if let Some(u) = &p.upstream {
                if !u.trim().is_empty() {
                    entry.upstream = Some(u.trim().trim_end_matches('/').to_owned());
                }
            }
            for k in &p.keys {
                let key = k.key.trim().to_owned();
                if key.is_empty() {
                    continue;
                }
                entry.keys.push(RuntimeKey::new(
                    key,
                    k.rpm.unwrap_or(crate::lane::DEFAULT_RPM),
                ));
            }
        }
        if let Some(ck) = &req.create_client_key {
            let name = ck.name.trim().to_owned();
            if name.is_empty() {
                return json_error(StatusCode::BAD_REQUEST, "missing_name", "client key name is required");
            }
            let secret = mint_client_secret();
            guard.client_keys.push(crate::auth::ClientKeyRecord::from_key(
                name,
                req.username.trim().to_owned(),
                &secret,
            ));
            minted = Some((ck.name.trim().to_owned(), secret));
        }
        if let Err(e) = save_state(&state_path(), &guard) {
            return json_error(StatusCode::BAD_REQUEST, "invalid_config", e);
        }
    }
    runtime.setup_required.store(false, Ordering::SeqCst);
    runtime.reload_router();
    let cookie = runtime.admin.session_cookie(req.username.trim(), &hash);
    let mut body = json!({ "ok": true });
    if let Some((name, secret)) = minted {
        // The one and only time this secret leaves the server.
        body["client_key"] = json!({ "name": name, "secret": secret });
    }
    (
        StatusCode::OK,
        [(header::SET_COOKIE, cookie)],
        Json(body),
    )
        .into_response()
}

#[derive(Deserialize)]
pub struct ValidateKeyReq {
    key: String,
    #[serde(default)]
    provider: Option<String>,
}

/// `POST /setup/validate-key` — pre-auth key probe for the wizard, bounded
/// by the shared login throttle plus a fixed delay (probe abuse control).
pub async fn setup_validate_key(
    State(runtime): State<Arc<Runtime>>,
    Json(req): Json<ValidateKeyReq>,
) -> Response {
    if !runtime.setup_required.load(Ordering::SeqCst) {
        return not_found();
    }
    if runtime.admin.is_throttled() {
        return json_error(
            StatusCode::TOO_MANY_REQUESTS,
            "throttled",
            "too many validation attempts, try again shortly",
        );
    }
    runtime.admin.note_failure(); // every pre-auth probe burns throttle budget
    tokio::time::sleep(std::time::Duration::from_millis(500)).await;
    let provider = req
        .provider
        .clone()
        .unwrap_or_else(|| runtime.config.default_provider().unwrap_or("nim").to_owned());
    let base = {
        let guard = runtime.store.lock().unwrap();
        guard
            .providers
            .get(&provider)
            .and_then(|p| p.upstream.clone())
            .or_else(|| runtime.config.lane_for(&provider).map(|l| l.upstream_base_url.clone()))
            .unwrap_or_default()
    };
    Json(match crate::routes::probe_key(&runtime.http, &base, req.key.trim()).await {
        Ok(models) => json!({ "ok": true, "models": models, "provider": provider }),
        Err(e) => json!({ "ok": false, "error": e, "provider": provider }),
    })
    .into_response()
}

/// Mint a fresh client-key secret: `npk_` + 128 bits of OS randomness.
fn mint_client_secret() -> String {
    let mut raw = [0u8; 16];
    getrandom::getrandom(&mut raw).expect("OS RNG for client secret");
    format!("npk_{}", hex::encode(raw))
}

fn not_found() -> Response {
    StatusCode::NOT_FOUND.into_response()
}

// ---------------------------------------------------------------------------
// Admin session (login / logout / gate)
// ---------------------------------------------------------------------------

#[derive(Deserialize)]
pub struct LoginReq {
    username: String,
    password: String,
}

/// `POST /api/login` — verify credentials, mint a session cookie.
pub async fn login_submit(
    State(runtime): State<Arc<Runtime>>,
    Json(req): Json<LoginReq>,
) -> Response {
    if runtime.admin.is_throttled() {
        return json_error(
            StatusCode::TOO_MANY_REQUESTS,
            "throttled",
            "too many failed attempts, try again shortly",
        );
    }
    let stored_hash = runtime.store.lock().unwrap().password_hash_of(req.username.trim());
    let Some(stored_hash) = stored_hash else {
        runtime.admin.note_failure();
        return json_error(StatusCode::UNAUTHORIZED, "invalid_credentials", "invalid credentials");
    };
    let password = req.password.clone();
    let hash_for_verify = stored_hash.clone();
    let ok =
        tokio::task::spawn_blocking(move || crate::admin::verify_password(&password, &hash_for_verify))
            .await
            .expect("verify task");
    if !ok {
        runtime.admin.note_failure();
        return json_error(StatusCode::UNAUTHORIZED, "invalid_credentials", "invalid credentials");
    }
    let cookie = runtime.admin.session_cookie(req.username.trim(), &stored_hash);
    (
        StatusCode::OK,
        [(header::SET_COOKIE, cookie)],
        Json(json!({ "ok": true })),
    )
        .into_response()
}

/// `POST /api/logout` — expire the session cookie.
pub async fn logout(State(_runtime): State<Arc<Runtime>>) -> Response {
    let cookie = crate::admin::expire_session_cookie();
    (
        StatusCode::OK,
        [(header::SET_COOKIE, cookie)],
        Json(json!({ "ok": true })),
    )
        .into_response()
}

/// Session gate: the caller must hold a valid admin cookie. Returns the
/// authenticated username, or `None`.
pub fn require_admin(runtime: &Runtime, headers: &HeaderMap) -> Option<String> {
    if runtime.setup_required.load(Ordering::SeqCst) {
        return None;
    }
    let token = headers
        .get(header::COOKIE)
        .and_then(|v| v.to_str().ok())
        .and_then(|c| crate::admin::parse_cookie(c, crate::admin::SESSION_COOKIE))?;
    let guard = runtime.store.lock().unwrap();
    runtime
        .admin
        .verify_session(&token, |name| guard.password_hash_of(name))
}

fn unauthorized() -> Response {
    (
        StatusCode::UNAUTHORIZED,
        Json(json!({ "error": { "message": "admin session required", "type": "authentication_error", "code": "admin_session_required" } })),
    )
        .into_response()
}

// ---------------------------------------------------------------------------
// Settings API (session-gated)
// ---------------------------------------------------------------------------

/// `GET /api/config` — read-only view for the dashboard.
///
/// Before setup the endpoint is public but minimal: the setup wizard needs
/// the provider registry to offer the initial-key form, and a fresh install
/// has no users/clients/secrets to protect. Once setup is done every call
/// requires a valid admin session.
pub async fn api_config(State(runtime): State<Arc<Runtime>>, headers: HeaderMap) -> Response {
    let setup_pending = runtime.setup_required.load(Ordering::SeqCst);
    let Some(_user) = require_admin(&runtime, &headers) else {
        if setup_pending {
            return ok_json(json!({
                "version": env!("CARGO_PKG_VERSION"),
                "providers": runtime.config.providers.iter().map(|name| {
                    let upstream = runtime.config
                        .lane_for(name)
                        .map(|l| l.upstream_base_url.clone())
                        .unwrap_or_default();
                    json!({ "name": name, "upstream": upstream })
                }).collect::<Vec<_>>(),
                "clients": [],
                "users": [],
                "setup_required": true,
            }));
        }
        return unauthorized();
    };
    let guard = runtime.store.lock().unwrap();
    let mut providers = Vec::new();
    for name in &runtime.config.providers {
        let env_upstream = runtime.config.lane_for(name).map(|l| l.upstream_base_url.clone());
        let state = guard.providers.get(name);
        let upstream = state
            .and_then(|p| p.upstream.clone())
            .or(env_upstream)
            .unwrap_or_default();
        let mut keys = Vec::new();
        for lane in runtime.config.lanes_for(name) {
            keys.push(json!({
                "source": "env",
                "name": lane.name,
                "last4": last4(&lane.client_key),
                "enabled": lane.enabled,
                "rpm": lane.rate_limit_per_window,
            }));
        }
        for k in state.map(|p| &p.keys).unwrap_or(&Vec::new()) {
            keys.push(json!({
                "source": "runtime",
                "fingerprint": k.fingerprint,
                "last4": k.last4,
                "enabled": k.enabled,
                "rpm": k.rpm,
            }));
        }
        providers.push(json!({ "name": name, "upstream": upstream, "keys": keys }));
    }
    ok_json(json!({
        "version": env!("CARGO_PKG_VERSION"),
        "providers": providers,
        "clients": guard.client_keys.iter().map(|c| json!({ "id": c.id, "last4": c.last4, "owner": c.owner })).collect::<Vec<_>>(),
        "users": guard.users.iter().map(|u| json!({ "username": u.username, "role": format!("{:?}", u.role) })).collect::<Vec<_>>(),
        "setup_required": runtime.setup_required.load(Ordering::SeqCst),
    }))
}
#[derive(Deserialize)]
pub struct KeyActionReq {
    provider: String,
    /// add | disable | enable | delete
    action: String,
    #[serde(default)]
    key: Option<String>,
    #[serde(default)]
    rpm: Option<usize>,
    #[serde(default)]
    fingerprint: Option<String>,
}

/// `POST /api/settings/keys` — manage runtime provider keys (one lane per
/// key). Mutates the persisted state and rebuilds the router lanes.
pub async fn settings_keys(
    State(runtime): State<Arc<Runtime>>,
    headers: HeaderMap,
    Json(req): Json<KeyActionReq>,
) -> Response {
    let Some(_user) = require_admin(&runtime, &headers) else {
        return unauthorized();
    };
    let provider = req.provider.trim().to_ascii_lowercase();
    if provider.is_empty() || !runtime.config.providers.contains(&provider) {
        return json_error(
            StatusCode::BAD_REQUEST,
            "unknown_provider",
            "provider not in registry",
        );
    }
    {
        let mut guard = runtime.store.lock().unwrap();
        let entry = guard.providers.entry(provider.clone()).or_default();
        match req.action.as_str() {
            "add" => {
                let Some(key) = req.key.map(|k| k.trim().to_owned()).filter(|k| !k.is_empty())
                else {
                    return json_error(StatusCode::BAD_REQUEST, "missing_key", "key is required");
                };
                let rpm = req.rpm.unwrap_or(crate::lane::DEFAULT_RPM);
                if rpm == 0 || rpm > 100_000 {
                    return json_error(
                        StatusCode::BAD_REQUEST,
                        "invalid_rpm",
                        "rpm must be 1..100000",
                    );
                }
                entry.keys.push(RuntimeKey::new(key, rpm));
            }
            "disable" | "enable" => {
                let Some(fp) = &req.fingerprint else {
                    return json_error(
                        StatusCode::BAD_REQUEST,
                        "missing_fingerprint",
                        "fingerprint is required",
                    );
                };
                let Some(k) = entry.keys.iter_mut().find(|k| &k.fingerprint == fp) else {
                    return json_error(StatusCode::NOT_FOUND, "unknown_key", "key not found");
                };
                k.enabled = req.action == "enable";
            }
            "delete" => {
                let Some(fp) = &req.fingerprint else {
                    return json_error(
                        StatusCode::BAD_REQUEST,
                        "missing_fingerprint",
                        "fingerprint is required",
                    );
                };
                let before = entry.keys.len();
                entry.keys.retain(|k| &k.fingerprint != fp);
                if entry.keys.len() == before {
                    return json_error(StatusCode::NOT_FOUND, "unknown_key", "key not found");
                }
            }
            _ => {
                return json_error(
                    StatusCode::BAD_REQUEST,
                    "unknown_action",
                    "action must be add|disable|enable|delete",
                )
            }
        }
        if let Err(e) = save_state(&state_path(), &guard) {
            return json_error(StatusCode::BAD_REQUEST, "invalid_config", e);
        }
    }
    runtime.reload_router();
    ok_json(json!({ "ok": true }))
}

#[derive(Deserialize)]
pub struct ClientReq {
    name: String,
}

/// `POST /api/settings/clients` — mint a client key; the secret is
/// returned exactly once.
pub async fn settings_clients(
    State(runtime): State<Arc<Runtime>>,
    headers: HeaderMap,
    Json(req): Json<ClientReq>,
) -> Response {
    let Some(user) = require_admin(&runtime, &headers) else {
        return unauthorized();
    };
    let name = req.name.trim().to_owned();
    if name.is_empty() {
        return json_error(StatusCode::BAD_REQUEST, "missing_name", "name is required");
    }
    let secret = mint_client_secret();
    {
        let mut guard = runtime.store.lock().unwrap();
        guard
            .client_keys
            .push(crate::auth::ClientKeyRecord::from_key(name.clone(), user.clone(), &secret));
        if let Err(e) = save_state(&state_path(), &guard) {
            return json_error(StatusCode::BAD_REQUEST, "invalid_config", e);
        }
    }
    ok_json(json!({ "ok": true, "client_key": { "name": name, "secret": secret } }))
}

#[derive(Deserialize)]
pub struct AccountReq {
    current_password: String,
    new_password: String,
}

/// `POST /api/settings/account` — change the caller's password. Existing
/// sessions stay valid until the old password generation changes — they
/// are all invalidated immediately after this mutation.
pub async fn settings_account(
    State(runtime): State<Arc<Runtime>>,
    headers: HeaderMap,
    Json(req): Json<AccountReq>,
) -> Response {
    let Some(username) = require_admin(&runtime, &headers) else {
        return unauthorized();
    };
    if req.new_password.len() < 10 {
        return json_error(
            StatusCode::BAD_REQUEST,
            "weak_password",
            "password must be at least 10 characters",
        );
    }
    let stored_hash = runtime.store.lock().unwrap().password_hash_of(&username);
    let Some(stored_hash) = stored_hash else {
        return unauthorized();
    };
    let current = req.current_password.clone();
    let ok =
        tokio::task::spawn_blocking(move || crate::admin::verify_password(&current, &stored_hash))
            .await
            .expect("verify task");
    if !ok {
        return json_error(
            StatusCode::UNAUTHORIZED,
            "invalid_credentials",
            "current password is wrong",
        );
    }
    let new = req.new_password.clone();
    let new_hash =
        tokio::task::spawn_blocking(move || crate::admin::hash_password(&new)).await
            .expect("hashing task");
    {
        let mut guard = runtime.store.lock().unwrap();
        let Some(user) = guard.users.iter_mut().find(|u| u.username == username) else {
            return unauthorized();
        };
        user.password_hash = new_hash;
        if let Err(e) = save_state(&state_path(), &guard) {
            return json_error(StatusCode::BAD_REQUEST, "invalid_config", e);
        }
    }
    ok_json(json!({ "ok": true }))
}

fn last4(s: &str) -> String {
    s.chars()
        .skip(s.chars().count().saturating_sub(4))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lane::Lane;

    /// All tests in this module mutate the process-global `BKG_STATE_FILE`
    /// env var, so they must run strictly one at a time.
    static STATE_LOCK: std::sync::Mutex<()> = std::sync::Mutex::new(());

    fn test_config() -> GatewayConfig {
        let mut c = GatewayConfig {
            gateway_bind: "0.0.0.0:666".parse().unwrap(),
            dashboard_bind: "0.0.0.0:7666".parse().unwrap(),
            providers: vec!["gemini".into()],
            lanes: vec![Lane::new(
                "gemini",
                "gemini-1",
                "https://generativelanguage.googleapis.com/v1beta",
                "gpk_env",
            )],
            client_keys: vec![crate::auth::ClientKeyRecord::from_key(
                "default",
                "system",
                "npk_test",
            )],
        };
        c.lanes[0].rate_limit_per_window = 40;
        c
    }

    #[test]
    fn setup_claims_superuser_atomically() {
        let _guard = STATE_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        std::env::set_var("BKG_STATE_FILE", dir.path().join("state.json"));
        let runtime = Arc::new(Runtime::new(test_config()));
        assert!(runtime.setup_required.load(Ordering::SeqCst));

        // Simulate a successful wizard (store path only; HTTP-level flow is
        // covered by the binary smoke test).
        {
            let mut guard = runtime.store.lock().unwrap();
            guard.users.push(UserRecord {
                username: "chief".into(),
                password_hash: crate::admin::hash_password("supersecretpw"),
                role: Role::Superuser,
            });
            let _ = save_state(&state_path(), &guard);
        }
        runtime.setup_required.store(false, Ordering::SeqCst);
        runtime.reload_router();

        // Reload from disk keeps the superuser, minted keys and the router.
        let runtime2 = Runtime::new(test_config());
        assert_eq!(runtime2.store.lock().unwrap().superuser().unwrap().username, "chief");
        assert!(!runtime2.setup_required.load(Ordering::SeqCst));
        assert!(runtime2.authorize("npk_test")); // env client key still valid
        std::env::remove_var("BKG_STATE_FILE");
    }

    #[test]
    fn runtime_keys_and_upstream_survive_restart() {
        let _guard = STATE_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        std::env::set_var("BKG_STATE_FILE", dir.path().join("state.json"));
        {
            let runtime = Runtime::new(test_config());
            let mut guard = runtime.store.lock().unwrap();
            guard.users.push(UserRecord {
                username: "chief".into(),
                password_hash: crate::admin::hash_password("supersecretpw"),
                role: Role::Superuser,
            });
            let entry = guard.providers.entry("gemini".into()).or_default();
            entry.upstream = Some("https://override.example/v1".into());
            entry.keys.push(RuntimeKey::new("gpk_runtime".into(), 60));
            let _ = save_state(&state_path(), &guard);
        }
        let runtime = Runtime::new(test_config());
        assert!(!runtime.setup_required.load(Ordering::SeqCst));
        let keys = runtime.store.lock().unwrap().runtime_keys("gemini");
        assert_eq!(keys.len(), 1);
        assert_eq!(keys[0].rpm, 60);
        // The runtime key became a lane and the override upstream is used.
        let names = runtime.router.lock().unwrap().lane_names();
        assert_eq!(names, vec!["gemini-1", "gemini-rt-1"]);
        std::env::remove_var("BKG_STATE_FILE");
    }

    #[test]
    fn require_admin_rejects_without_session() {
        let _guard = STATE_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        std::env::set_var("BKG_STATE_FILE", dir.path().join("state.json"));
        let runtime = Runtime::new(test_config());
        let headers = HeaderMap::new();
        assert_eq!(require_admin(&runtime, &headers), None);
        std::env::remove_var("BKG_STATE_FILE");
    }

    #[test]
    fn require_admin_accepts_valid_session() {
        let _guard = STATE_LOCK.lock().unwrap_or_else(|e| e.into_inner());
        let dir = tempfile::tempdir().unwrap();
        std::env::set_var("BKG_STATE_FILE", dir.path().join("state.json"));
        let runtime = Runtime::new(test_config());
        let hash = crate::admin::hash_password("supersecretpw");
        {
            let mut guard = runtime.store.lock().unwrap();
            guard.users.push(UserRecord {
                username: "chief".into(),
                password_hash: hash.clone(),
                role: Role::Superuser,
            });
        }
        runtime.setup_required.store(false, Ordering::SeqCst);
        let cookie = runtime.admin.session_cookie("chief", &hash);
        let mut headers = HeaderMap::new();
        headers.insert(
            header::COOKIE,
            cookie.parse().unwrap(),
        );
        assert_eq!(require_admin(&runtime, &headers).as_deref(), Some("chief"));
        std::env::remove_var("BKG_STATE_FILE");
    }
}
