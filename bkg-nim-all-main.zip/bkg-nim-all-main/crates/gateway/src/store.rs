//! Persisted gateway state: the superuser, runtime-minted client keys and
//! runtime-managed provider key pools (the nim-proxy "store").
//!
//! Everything runtime-administrable lives in one JSON file
//! (`BKG_STATE_FILE`, default `./bkg-gateway-state.json`, written 0600).
//! The env still supplies the base registry (`BKG_PROVIDERS` + upstreams +
//! initial key files); state layers runtime additions/overrides on top:
//! - provider upstreams/keys managed in the dashboard overlay the env pool;
//! - client keys minted in the dashboard are accepted alongside the env
//!   `API_KEY`;
//! - the signing secret is generated on first boot and persisted so admin
//!   sessions survive restarts.

use crate::auth::ClientKeyRecord;
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
pub enum Role {
    Superuser,
    Admin,
    User,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct UserRecord {
    pub username: String,
    pub password_hash: String,
    pub role: Role,
}

#[derive(Debug, Clone, Default, serde::Serialize, serde::Deserialize)]
pub struct ProviderKeys {
    /// Optional runtime upstream override for the provider (overrides the
    /// env `{P}_UPSTREAM`).
    pub upstream: Option<String>,
    /// Runtime-managed keys for a provider (env key files still count too).
    pub keys: Vec<RuntimeKey>,
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct RuntimeKey {
    pub key: String,
    pub enabled: bool,
    pub rpm: usize,
    pub fingerprint: String,
    pub last4: String,
}

impl RuntimeKey {
    pub fn new(key: String, rpm: usize) -> Self {
        let digest = crate::admin::sha256_hex(&key);
        let fingerprint = digest[..8].to_owned();
        let last4 = key
            .chars()
            .rev()
            .take(4)
            .collect::<String>()
            .chars()
            .rev()
            .collect();
        Self {
            key,
            enabled: true,
            rpm,
            fingerprint,
            last4,
        }
    }
}

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct GatewayState {
    /// HMAC signing secret for admin sessions (minted on first boot).
    pub signing_secret: String,
    pub users: Vec<UserRecord>,
    /// Runtime-minted client keys (env API_KEY still accepted).
    pub client_keys: Vec<ClientKeyRecord>,
    /// Runtime-managed provider key pools keyed by provider name.
    pub providers: std::collections::HashMap<String, ProviderKeys>,
}

impl Default for GatewayState {
    fn default() -> Self {
        let mut secret = [0u8; 32];
        getrandom::getrandom(&mut secret).expect("OS RNG for signing secret");
        Self {
            signing_secret: hex::encode(secret),
            users: Vec::new(),
            client_keys: Vec::new(),
            providers: std::collections::HashMap::new(),
        }
    }
}

impl GatewayState {
    pub fn superuser(&self) -> Option<&UserRecord> {
        self.users
            .iter()
            .find(|u| u.role == Role::Superuser)
    }

    pub fn user(&self, username: &str) -> Option<&UserRecord> {
        self.users.iter().find(|u| u.username == username)
    }

    pub fn password_hash_of(&self, username: &str) -> Option<String> {
        self.user(username).map(|u| u.password_hash.clone())
    }

    pub fn signing_key(&self) -> [u8; 32] {
        let mut key = [0u8; 32];
        let bytes = hex::decode(&self.signing_secret).unwrap_or_default();
        for (i, b) in bytes.iter().take(32).enumerate() {
            key[i] = *b;
        }
        key
    }

    /// Runtime client keys verify as well as the env API_KEY.
    pub fn client_authorize(&self, presented: &str) -> bool {
        self.client_keys
            .iter()
            .any(|record| record.verify(presented))
    }

    /// Runtime-added keys for a provider (does NOT include env keys).
    pub fn runtime_keys(&self, provider: &str) -> Vec<RuntimeKey> {
        self.providers
            .get(provider)
            .map(|p| p.keys.clone())
            .unwrap_or_default()
    }
}

/// Load state from `BKG_STATE_FILE` (default `./bkg-gateway-state.json`);
/// a missing/corrupt file yields a fresh default (first boot) — corrupt
/// files are renamed aside rather than silently dropped.
pub fn load_state(path: &Path) -> GatewayState {
    match std::fs::read_to_string(path) {
        Ok(raw) => match serde_json::from_str::<GatewayState>(&raw) {
            Ok(state) => state,
            Err(e) => {
                eprintln!("state file corrupt ({e}); backing up and starting fresh");
                let _ = std::fs::rename(path, path.with_extension("json.corrupt"));
                GatewayState::default()
            }
        },
        Err(_) => GatewayState::default(),
    }
}

/// Persist state atomically (tmp + rename) with 0600 perms.
pub fn save_state(path: &Path, state: &GatewayState) -> Result<(), String> {
    let tmp = path.with_extension("json.tmp");
    let raw = serde_json::to_string_pretty(state).map_err(|e| e.to_string())?;
    let mut f = std::fs::File::create(&tmp).map_err(|e| format!("{tmp:?}: {e}"))?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = f.set_permissions(std::fs::Permissions::from_mode(0o600));
    }
    f.write_all(raw.as_bytes()).map_err(|e| e.to_string())?;
    f.flush().map_err(|e| e.to_string())?;
    std::fs::rename(&tmp, path).map_err(|e| format!("{path:?}: {e}"))?;
    Ok(())
}

/// Resolve the state file path from the environment.
pub fn state_path() -> PathBuf {
    std::env::var("BKG_STATE_FILE")
        .map(PathBuf::from)
        .unwrap_or_else(|_| PathBuf::from("./bkg-gateway-state.json"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn state_roundtrips_through_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("state.json");

        let mut state = GatewayState::default();
        state.users.push(UserRecord {
            username: "chief".into(),
            password_hash: "h".into(),
            role: Role::Superuser,
        });
        state.client_keys.push(ClientKeyRecord::from_key(
            "k1",
            "chief",
            "npk_minted_secret",
        ));
        state
            .providers
            .entry("gemini".into())
            .or_default()
            .keys
            .push(RuntimeKey::new("gpk_runtime".into(), 60));

        save_state(&path, &state).unwrap();
        let loaded = load_state(&path);
        assert_eq!(loaded.superuser().unwrap().username, "chief");
        assert!(loaded.client_authorize("npk_minted_secret"));
        let keys = loaded.runtime_keys("gemini");
        assert_eq!(keys.len(), 1);
        assert_eq!(keys[0].rpm, 60);
        assert_eq!(keys[0].fingerprint.len(), 8);
    }

    #[test]
    fn missing_state_is_fresh_default_with_secret() {
        let dir = tempfile::tempdir().unwrap();
        let state = load_state(&dir.path().join("nope.json"));
        assert!(state.superuser().is_none());
        assert_eq!(state.signing_secret.len(), 64);
    }

    #[test]
    fn runtime_key_derives_fingerprint_and_last4() {
        let key = RuntimeKey::new("npk_supersecret1234".into(), 40);
        assert_eq!(key.last4, "1234");
        assert_eq!(key.fingerprint.len(), 8);
    }
}
