//! Provider lane model: one lane per provider key (nim-proxy key-pool
//! semantics: ONE upstream base URL per provider, N keys = N lanes).
//!
//! The gateway imposes NO artificial rate limit: as many TPS as the pool
//! has keys is allowed. Each lane keeps a rolling 61s window COUNTER (only
//! for least-loaded spreading and dashboard display) and a cooldown bench
//! used for failover: after an upstream 429/5xx (quota exhausted) the lane
//! is skipped and the next key takes over.

use std::collections::VecDeque;
use std::time::{Duration, Instant};

/// Rolling window used for the per-lane load counter and dashboard display
/// (nim-proxy uses 61s with a 1s delivery-jitter margin). NOT a limiter —
/// it only measures load for least-loaded spreading.
pub const DEFAULT_WINDOW_SECS: u64 = 61;

/// Per-key tier metadata (nim-proxy `NimKey::rpm`). Informational only:
/// shown on the dashboard as the key's configured tier; the gateway does
/// NOT enforce it — the upstream enforces the real quota per account.
pub const DEFAULT_RPM: usize = 40;

/// A single window sample.
#[derive(Debug, Clone, Copy)]
struct Window {
    timestamp: Instant,
}

/// Rolling-window load counter.
///
/// Records every routed request within a rolling `window` duration and can
/// report the current in-window count. It never blocks — it is a counter
/// for spread/display, not a rate limiter.
#[derive(Debug, Clone)]
pub struct SlidingWindowLimiter {
    window: Duration,
    timestamps: VecDeque<Window>,
}

impl SlidingWindowLimiter {
    pub fn new(window: Duration) -> Self {
        Self {
            window,
            timestamps: VecDeque::new(),
        }
    }

    /// Prune expired samples, then count the request that just arrived.
    /// Always succeeds — no artificial cap.
    pub fn record(&mut self, now: Instant) {
        while let Some(front) = self.timestamps.front() {
            if now.duration_since(front.timestamp) >= self.window {
                self.timestamps.pop_front();
            } else {
                break;
            }
        }
        self.timestamps.push_back(Window { timestamp: now });
    }

    /// Prune expired samples and return the in-window count WITHOUT
    /// recording a new request. Used by the router to measure each lane's
    /// current load and pick the least-loaded ready lane (nim-proxy
    /// `pool::reserve`).
    pub fn load_at(&mut self, now: Instant) -> usize {
        while let Some(front) = self.timestamps.front() {
            if now.duration_since(front.timestamp) >= self.window {
                self.timestamps.pop_front();
            } else {
                break;
            }
        }
        self.timestamps.len()
    }

    pub fn used(&self) -> usize {
        self.timestamps.len()
    }
}

/// A provider lane: upstream endpoint, client key, provider name.
///
/// Providers are fully dynamic — add any provider by name in the config
/// (`BKG_PROVIDERS`) and give it an upstream + a key pool. There is no
/// hardcoded list of providers in code.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct Lane {
    /// Provider name (e.g. "gemini", "nim", "claude", "my-provider").
    pub provider: String,
    /// Lane identifier: "{provider}-1", "{provider}-2", … one per key.
    pub name: String,
    /// The provider's single upstream base URL (nim-proxy `base_url`).
    pub upstream_base_url: String,
    /// The API key for this lane (one lane = one key = one account).
    pub client_key: String,
    /// Per-key tier metadata (informational only — never enforced).
    pub rate_limit_per_window: usize,
    pub window_secs: u64,
    pub enabled: bool,
}

impl Lane {
    pub fn new(
        provider: impl Into<String>,
        name: impl Into<String>,
        upstream_base_url: impl Into<String>,
        client_key: impl Into<String>,
    ) -> Self {
        Self {
            provider: provider.into(),
            name: name.into(),
            upstream_base_url: upstream_base_url.into(),
            client_key: client_key.into(),
            rate_limit_per_window: DEFAULT_RPM,
            window_secs: DEFAULT_WINDOW_SECS,
            enabled: true,
        }
    }
}

/// A lane together with its live state (load counter + cooldown bench).
pub struct ActiveLane {
    pub lane: Lane,
    counter: SlidingWindowLimiter,
    /// The lane is benched until this instant (set after an upstream
    /// 429/5xx — nim-proxy `penalize`).
    cooldown_until: Instant,
}

impl ActiveLane {
    pub fn new(lane: Lane) -> Self {
        let counter = SlidingWindowLimiter::new(Duration::from_secs(lane.window_secs));
        Self {
            lane,
            counter,
            cooldown_until: Instant::now(),
        }
    }

    /// Record a routed request (no gate — the upstream enforces quotas).
    pub fn record(&mut self, now: Instant) {
        self.counter.record(now);
    }

    /// In-window request load (prunes expired samples, records nothing).
    pub fn load_at(&mut self, now: Instant) -> usize {
        self.counter.load_at(now)
    }

    pub fn used(&self) -> usize {
        self.counter.used()
    }

    /// Bench the lane until `now + backoff` (nim-proxy `penalize`).
    pub fn penalize(&mut self, backoff: Duration) {
        let until = Instant::now() + backoff;
        if self.cooldown_until < until {
            self.cooldown_until = until;
        }
    }

    pub fn in_cooldown(&self, now: Instant) -> bool {
        self.cooldown_until > now
    }

    /// Remaining cooldown, if any.
    pub fn cooldown_wait(&self, now: Instant) -> Option<Duration> {
        self.cooldown_until.checked_duration_since(now)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sliding_window_counts_without_limiting() {
        let mut counter = SlidingWindowLimiter::new(Duration::from_secs(10));
        let now = Instant::now();
        counter.record(now);
        counter.record(now);
        counter.record(now);
        assert_eq!(counter.used(), 3, "no gate: all requests are counted");
    }

    #[test]
    fn sliding_window_expires_samples() {
        let mut counter = SlidingWindowLimiter::new(Duration::from_millis(50));
        let now = Instant::now();
        counter.record(now);
        assert_eq!(counter.load_at(now), 1);
        let later = now + Duration::from_millis(60);
        assert_eq!(counter.load_at(later), 0, "expired sample pruned");
    }

    #[test]
    fn lane_defaults_for_any_provider() {
        let lane = Lane::new(
            "my-provider",
            "my-provider-1",
            "http://172.28.0.30:8066/v1",
            "npk_test",
        );
        assert_eq!(lane.provider, "my-provider");
        assert_eq!(lane.upstream_base_url, "http://172.28.0.30:8066/v1");
        assert_eq!(lane.rate_limit_per_window, DEFAULT_RPM);
        assert_eq!(lane.window_secs, DEFAULT_WINDOW_SECS);
        assert!(lane.enabled);
    }

    #[test]
    fn active_lane_cooldown_benches_until_backoff_elapses() {
        let lane = Lane::new(
            "gemini",
            "gemini-1",
            "https://generativelanguage.googleapis.com/v1beta",
            "key",
        );
        let mut active = ActiveLane::new(lane);
        let now = Instant::now();
        assert!(!active.in_cooldown(now));
        active.penalize(Duration::from_secs(30));
        assert!(active.in_cooldown(now));
        assert_eq!(
            active.cooldown_wait(now).unwrap().as_secs(),
            30,
            "cooldown is counted from penalize time"
        );
        let later = now + Duration::from_secs(31);
        assert!(!active.in_cooldown(later));
        assert!(active.cooldown_wait(later).is_none());
    }

    #[test]
    fn active_lane_records_and_measures_load() {
        let lane = Lane::new(
            "gemini",
            "gemini-1",
            "https://generativelanguage.googleapis.com/v1beta",
            "key",
        );
        let mut active = ActiveLane::new(lane);
        let now = Instant::now();
        active.record(now);
        assert_eq!(active.used(), 1);
        assert_eq!(active.load_at(now), 1);
    }
}
