//! NIM client errors.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum NimError {
    #[error("configuration error: {0}")]
    Config(String),

    #[error("HTTP transport error: {0}")]
    Transport(String),

    #[error("NIM API error (status {status}): {message}")]
    Api { status: u16, message: String },

    #[error("invalid response: {0}")]
    InvalidResponse(String),

    #[error("rate limited: retry after {retry_after_ms} ms")]
    RateLimited { retry_after_ms: u64 },
}
