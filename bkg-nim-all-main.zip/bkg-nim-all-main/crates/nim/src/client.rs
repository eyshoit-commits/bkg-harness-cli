//! OpenAI-compatible NIM client.

use async_trait::async_trait;
use bkg_base::error::CoreResult;
use bkg_base::traits::{InferenceRequest, InferenceResponse, InferenceService, Usage};
use serde::Deserialize;

use crate::error::NimError;

/// Configuration for the NIM endpoint.
#[derive(Debug, Clone)]
pub struct NimConfig {
    pub base_url: String,
    pub api_key: String,
    pub model: String,
    pub timeout_secs: u64,
}

impl NimConfig {
    pub fn new(
        base_url: impl Into<String>,
        api_key: impl Into<String>,
        model: impl Into<String>,
    ) -> Self {
        Self {
            base_url: base_url.into(),
            api_key: api_key.into(),
            model: model.into(),
            timeout_secs: 120,
        }
    }
}

/// Wire types for the OpenAI-compatible chat completions API.
#[derive(serde::Serialize)]
struct ChatRequest<'a> {
    model: &'a str,
    messages: Vec<ChatMessage<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    max_tokens: Option<u32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    temperature: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    stream: Option<bool>,
}

#[derive(serde::Serialize)]
struct ChatMessage<'a> {
    role: &'a str,
    content: &'a str,
}

#[derive(Deserialize)]
struct ChatResponse {
    choices: Vec<Choice>,
    usage: Option<UsageWire>,
}

#[derive(Deserialize)]
struct Choice {
    message: ResponseMessage,
    finish_reason: Option<String>,
}

#[derive(Deserialize)]
struct ResponseMessage {
    content: Option<String>,
}

#[derive(Deserialize)]
struct UsageWire {
    prompt_tokens: u32,
    completion_tokens: u32,
    total_tokens: u32,
}

/// NIM client implementing [`InferenceService`].
#[derive(Debug)]
pub struct NimClient {
    config: NimConfig,
    http: reqwest::Client,
}

impl NimClient {
    pub fn new(config: NimConfig) -> Result<Self, NimError> {
        if config.api_key.trim().is_empty() {
            return Err(NimError::Config("empty API key".into()));
        }
        if config.model.trim().is_empty() {
            return Err(NimError::Config("empty model".into()));
        }
        let http = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(config.timeout_secs))
            .build()
            .map_err(|e| NimError::Transport(e.to_string()))?;
        Ok(Self { config, http })
    }

    /// The configured model name.
    pub fn model(&self) -> &str {
        &self.config.model
    }

    async fn complete_inner(
        &self,
        request: InferenceRequest,
    ) -> Result<InferenceResponse, NimError> {
        let mut messages = Vec::new();
        if let Some(system) = &request.system {
            messages.push(ChatMessage {
                role: "system",
                content: system,
            });
        }
        messages.push(ChatMessage {
            role: "user",
            content: &request.prompt,
        });

        let body = ChatRequest {
            model: &self.config.model,
            messages,
            max_tokens: request.max_tokens,
            temperature: request.temperature,
            stream: Some(false),
        };

        let url = format!(
            "{}/chat/completions",
            self.config.base_url.trim_end_matches('/')
        );
        let response = self
            .http
            .post(&url)
            .bearer_auth(&self.config.api_key)
            .json(&body)
            .send()
            .await
            .map_err(|e| NimError::Transport(e.to_string()))?;

        let status = response.status();
        if status == reqwest::StatusCode::TOO_MANY_REQUESTS {
            let retry_after_ms = response
                .headers()
                .get(reqwest::header::RETRY_AFTER)
                .and_then(|v| v.to_str().ok())
                .and_then(|v| v.parse::<u64>().ok())
                .unwrap_or(1000)
                * 1000;
            return Err(NimError::RateLimited { retry_after_ms });
        }
        if !status.is_success() {
            let text = response.text().await.unwrap_or_default();
            return Err(NimError::Api {
                status: status.as_u16(),
                message: text.chars().take(500).collect(),
            });
        }

        let parsed: ChatResponse = response
            .json()
            .await
            .map_err(|e| NimError::InvalidResponse(e.to_string()))?;
        let choice = parsed
            .choices
            .into_iter()
            .next()
            .ok_or_else(|| NimError::InvalidResponse("no choices".into()))?;
        let text = choice.message.content.unwrap_or_default();
        let usage = parsed.usage.map(|u| Usage {
            prompt_tokens: u.prompt_tokens,
            completion_tokens: u.completion_tokens,
            total_tokens: u.total_tokens,
        });
        Ok(InferenceResponse {
            text,
            finish_reason: choice.finish_reason.unwrap_or_else(|| "stop".into()),
            usage,
        })
    }
}

#[async_trait]
impl InferenceService for NimClient {
    async fn complete(&self, request: InferenceRequest) -> CoreResult<InferenceResponse> {
        self.complete_inner(request)
            .await
            .map_err(|e| bkg_base::error::CoreError::Unsupported(format!("NIM: {e}")))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn config_rejects_empty_key() {
        let err = NimClient::new(NimConfig::new("http://x", "", "model")).unwrap_err();
        assert!(matches!(err, NimError::Config(_)));
    }

    #[test]
    fn config_rejects_empty_model() {
        let err = NimClient::new(NimConfig::new("http://x", "key", "")).unwrap_err();
        assert!(matches!(err, NimError::Config(_)));
    }

    #[test]
    fn request_body_shape_matches_openai() {
        let body = ChatRequest {
            model: "m",
            messages: vec![ChatMessage {
                role: "user",
                content: "hi",
            }],
            max_tokens: Some(8),
            temperature: None,
            stream: Some(false),
        };
        let json = serde_json::to_value(&body).unwrap();
        assert_eq!(json["model"], "m");
        assert_eq!(json["messages"][0]["role"], "user");
        assert_eq!(json["messages"][0]["content"], "hi");
        assert_eq!(json["max_tokens"], 8);
        assert!(json.get("temperature").is_none());
    }
}
