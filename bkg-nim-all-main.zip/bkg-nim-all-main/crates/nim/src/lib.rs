//! NVIDIA NIM provider client.
//!
//! Implements the provider-independent [`InferenceService`] contract from
//! the base crate against the NVIDIA NIM OpenAI-compatible API. All model
//! knowledge is data-driven: the endpoint, key and model are configuration.

pub mod client;
pub mod error;

pub use client::*;
pub use error::*;
