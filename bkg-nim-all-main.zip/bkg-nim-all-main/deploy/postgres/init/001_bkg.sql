-- BKG PostgreSQL bootstrap: auth + storage + RAG (pgvector).
-- Runs once on first container start via docker-entrypoint-initdb.d.

-- pgvector for RAG embeddings.
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pgcrypto; -- gen_random_uuid()

-- ---------------------------------------------------------------------------
-- Auth: users + sessions (login/passwords). Passwords stored as argon2 hashes
-- (computed by the Rust storage crate — never plaintext).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auth_users (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,               -- bcrypt
    display_name  TEXT,
    role          TEXT NOT NULL DEFAULT 'user', -- user | admin
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS auth_sessions (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES auth_users(id) ON DELETE CASCADE,
    token_hash   TEXT NOT NULL UNIQUE,          -- sha256 of the bearer token
    expires_at   TIMESTAMPTZ NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_auth_sessions_user ON auth_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_token ON auth_sessions(token_hash);

-- ---------------------------------------------------------------------------
-- Storage: per-namespace JSON state store.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS state_store (
    namespace  TEXT NOT NULL,
    key        TEXT NOT NULL,
    value      JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (namespace, key)
);

CREATE TABLE IF NOT EXISTS event_stream (
    seq        BIGSERIAL PRIMARY KEY,
    namespace  TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload    JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_event_stream_namespace ON event_stream(namespace, seq);

-- ---------------------------------------------------------------------------
-- RAG: documents + pgvector embeddings.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rag_documents (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    namespace    TEXT NOT NULL,
    title        TEXT,
    content      TEXT NOT NULL,
    source       TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rag_embeddings (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id   UUID NOT NULL REFERENCES rag_documents(id) ON DELETE CASCADE,
    chunk_index   INT NOT NULL,
    chunk_text    TEXT NOT NULL,
    embedding     VECTOR(1536),          -- OpenAI-compatible dim; adjust per provider
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_rag_embeddings_doc ON rag_embeddings(document_id);

-- ---------------------------------------------------------------------------
-- Dashboard / gateway usage ledger.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usage_ledger (
    id          BIGSERIAL PRIMARY KEY,
    lane        TEXT NOT NULL,
    model       TEXT,
    user_id     UUID REFERENCES auth_users(id),
    prompt_tokens INT NOT NULL DEFAULT 0,
    completion_tokens INT NOT NULL DEFAULT 0,
    total_tokens INT NOT NULL DEFAULT 0,
    latency_ms  INT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_usage_ledger_lane ON usage_ledger(lane, created_at);
