# Docker secret files — copy each example into `secrets/` with real values.
# These files are mounted read-only into the containers at /run/secrets/<name>.
#
#   mkdir -p secrets
#   cp secrets.example/*.example secrets/
#   ... edit with real keys/passwords ...
#
# Never commit the real secret files.

api_key.example:
  placeholder text to be replaced by real API key
nim_keys.example:
  placeholder NIM provider keys — ONE KEY PER LINE (each line = one lane)
gemini_keys.example:
  placeholder Gemini provider keys — ONE KEY PER LINE
opencode_keys.example:
  placeholder OpenCode provider keys — ONE KEY PER LINE
postgres_password.example:
  placeholder Postgres superuser password

# Adding a new provider (e.g. Nevis AI):
#   1. add the name to BKG_PROVIDERS in .env
#   2. add NEVIS_UPSTREAM to .env
#   3. create secrets/nevis_keys (one key per line) + mount it in
#      docker-compose.yml gateway service (NEVIS_API_KEYS_FILE + secret)
