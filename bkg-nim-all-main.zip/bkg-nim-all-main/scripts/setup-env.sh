#!/usr/bin/env bash
#
# Idempotent environment bootstrap for the bkg-nim-studio knowledge base.
#
# This repository is a documentation / reverse-engineering inventory. It has no
# language package manager and no compiled artifacts, so setup only verifies
# that the doc-authoring and validation toolchain is present and prepares the
# repo scripts. It performs no network downloads and is safe to re-run.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "== bkg-nim-studio environment setup =="
echo "repo root: $REPO_ROOT"

echo
echo "-- Required toolchain --"
missing=0
require() {
  local tool="$1"
  if command -v "$tool" >/dev/null 2>&1; then
    printf '  %-8s %s\n' "$tool" "$("$tool" --version 2>&1 | head -1)"
  else
    printf '  %-8s MISSING\n' "$tool"
    missing=1
  fi
}
require python3
require jq
require rg
require git

if [[ $missing -ne 0 ]]; then
  echo "ERROR: required tooling missing from base image." >&2
  exit 1
fi

echo
echo "-- Preparing repository scripts --"
chmod +x scripts/*.sh
echo "  scripts marked executable"

echo
echo "-- Repository inventory --"
printf '  tracked files:      %s\n' "$(git ls-files | wc -l | tr -d ' ')"
printf '  tracked markdown:   %s\n' "$(git ls-files '*.md' | wc -l | tr -d ' ')"
printf '  documented repos:   %s\n' "$(find docs -maxdepth 1 -mindepth 1 -type d -name '[0-9]*' | wc -l | tr -d ' ')"

echo
echo "Environment setup complete."
