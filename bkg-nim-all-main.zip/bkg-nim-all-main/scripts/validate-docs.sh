#!/usr/bin/env bash
#
# Inner-loop validator for the bkg-nim-studio reverse-engineering knowledge base.
#
# Two modes:
#   (default)  Environment / structural health checks that MUST pass for the
#              repository to be considered well-formed. Exit 0 on success.
#   --gate     Additionally enforce the AGENTS.md / TODO completion gates
#              (placeholder-free docs, Phase 11/12 deliverables). Exits non-zero
#              until the reverse-engineering analysis is finished.
#
# The completion gates intentionally fail while analysis is still in progress;
# that is a property of the content, not of the environment.

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

GATE_MODE=0
if [[ "${1:-}" == "--gate" ]]; then
  GATE_MODE=1
fi

# Standard per-repository document set expected under docs/NN-<repo>/.
STANDARD_DOCS=(index.md files.md functions.md architecture.md data-models.md nim.md tests.md rust-foundation.md)

# Completion-gate placeholder patterns defined in AGENTS.md.
PLACEHOLDER_PATTERN='Eingaben: Nicht ermittelt|Ausgaben: Nicht ermittelt|Verantwortlichkeit: Nicht ermittelt|Geschäftslogik: Nicht ermittelt|Algorithmen: Nicht ermittelt|APIs: Nicht ermittelt|Rust-Relevanz: Nicht erkennbar'

env_failures=0
gate_failures=0

hr() { printf '%s\n' "------------------------------------------------------------"; }
ok()   { printf '  [ OK ]   %s\n' "$1"; }
warn() { printf '  [WARN]   %s\n' "$1"; }
fail() { printf '  [FAIL]   %s\n' "$1"; }

hr
printf 'bkg-nim-studio docs validator\n'
printf 'repo root: %s\n' "$REPO_ROOT"
hr

# 1. Toolchain availability -------------------------------------------------
printf '\n[1] Toolchain\n'
for tool in python3 jq rg git; do
  if command -v "$tool" >/dev/null 2>&1; then
    ok "$tool -> $(command -v "$tool")"
  else
    fail "$tool missing"
    env_failures=$((env_failures + 1))
  fi
done

# 2. Brain state JSON validity ----------------------------------------------
printf '\n[2] .brain state (valid JSON)\n'
brain_json=$(git ls-files '.brain/*.json' 2>/dev/null)
if [[ -z "$brain_json" ]]; then
  warn "no .brain/*.json tracked"
else
  while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    if jq -e . "$f" >/dev/null 2>&1; then
      ok "$f"
    else
      fail "invalid JSON: $f"
      env_failures=$((env_failures + 1))
    fi
  done <<< "$brain_json"
fi

# 3. No empty tracked markdown ----------------------------------------------
printf '\n[3] No empty tracked markdown\n'
empty_md=0
while IFS= read -r f; do
  [[ -z "$f" ]] && continue
  if [[ ! -s "$f" ]]; then
    fail "empty: $f"
    env_failures=$((env_failures + 1))
    empty_md=$((empty_md + 1))
  fi
done <<< "$(git ls-files '*.md')"
[[ $empty_md -eq 0 ]] && ok "all tracked .md files are non-empty"

# 4. Per-repository documentation set ---------------------------------------
printf '\n[4] Per-repository documentation set\n'
while IFS= read -r docdir; do
  [[ -z "$docdir" ]] && continue
  base="${docdir%/}"
  missing=()
  for doc in "${STANDARD_DOCS[@]}"; do
    [[ -f "$base/$doc" ]] || missing+=("$doc")
  done
  if [[ ${#missing[@]} -eq 0 ]]; then
    ok "$base (complete)"
  else
    warn "$base missing: ${missing[*]}"
  fi
done <<< "$(find docs -maxdepth 1 -mindepth 1 -type d -name '[0-9]*' | sort)"

# 5. AGENTS.md completion gates ---------------------------------------------
printf '\n[5] Completion gates (AGENTS.md / TODO)\n'
placeholder_hits=$(rg -c "$PLACEHOLDER_PATTERN" docs/ 2>/dev/null | awk -F: '{s+=$2} END {print s+0}')
if [[ "$placeholder_hits" -eq 0 ]]; then
  ok "no 'Nicht ermittelt / Nicht erkennbar' placeholders in docs/"
else
  warn "$placeholder_hits placeholder line(s) remain in docs/ (analysis in progress)"
  rg -l "$PLACEHOLDER_PATTERN" docs/ 2>/dev/null | sed 's/^/           - /'
  gate_failures=$((gate_failures + 1))
fi

for deliverable in docs/12-product-opportunities.md docs/13-capability-traceability.md; do
  if [[ -f "$deliverable" ]]; then
    ok "$deliverable present"
  else
    warn "$deliverable not yet created (Phase 11/12 pending)"
    gate_failures=$((gate_failures + 1))
  fi
done

# Summary -------------------------------------------------------------------
hr
if [[ $env_failures -eq 0 ]]; then
  printf 'Environment/structural checks: PASS\n'
else
  printf 'Environment/structural checks: FAIL (%d issue(s))\n' "$env_failures"
fi

if [[ $gate_failures -eq 0 ]]; then
  printf 'Completion gates:              PASS\n'
else
  printf 'Completion gates:              INCOMPLETE (%d gate(s) open) — analysis ongoing\n' "$gate_failures"
fi
hr

# Exit policy: structural failures always fail. Completion gates only fail the
# run in --gate mode (used at analysis-completion time / CI final check).
if [[ $env_failures -ne 0 ]]; then
  exit 1
fi
if [[ $GATE_MODE -eq 1 && $gate_failures -ne 0 ]]; then
  exit 2
fi
exit 0
