use axum::{
    routing::get,
    Json, Router,
};
use serde_json::Value;
use tokio;

#[tokio::main]
async fn main() {
    // Initialize tracing
    tracing_subscriber::fmt::init();
    
    // Build our application with a route
    let app = Router::new()
        .route("/", get(root))
        .route("/health", get(health));

    // Run it with hyper on localhost:3000
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    println!("🚀 Basic LLM-Loader server running on http://0.0.0.0:3000");
    println!("🎮 Admin UI: http://0.0.0.0:3000/admin");
    println!("💚 Health check: http://0.0.0.0:3000/health");
    
    axum::serve(listener, app).await.unwrap();
}

// Basic handler that responds with a static string
async fn root() -> &'static str {
    "🚀 LLM-Loader v0.2α - Neural Interface Active"
}

// Health check endpoint
async fn health() -> Json<Value> {
    Json(serde_json::json!({
        "status": "healthy",
        "version": "0.2.0-alpha",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "message": "🤖 Cyberpunk neural interface online"
    }))
}