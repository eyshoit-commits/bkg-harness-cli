use rand::distributions::{Distribution, WeightedIndex};
use rand::thread_rng;

#[derive(Debug, Clone)]
pub struct SamplerConfig {
    pub temperature: f32,
    pub top_k: Option<usize>,
    pub repetition_penalty: Option<f32>,
}

impl Default for SamplerConfig {
    fn default() -> Self {
        Self {
            temperature: 1.0,
            top_k: Some(40),
            repetition_penalty: None,
        }
    }
}

pub fn sample_token(
    logits: &[f32],
    cfg: &SamplerConfig,
    recent_tokens: &[u32],
) -> u32 {
    let mut scores = logits.to_vec();
    if let Some(rp) = cfg.repetition_penalty {
        for &t in recent_tokens {
            let idx = t as usize;
            if idx < scores.len() {
                if scores[idx] > 0.0 {
                    scores[idx] /= rp;
                } else {
                    scores[idx] *= rp;
                }
            }
        }
    }

    if cfg.temperature != 1.0 {
        let inv_t = 1.0f32 / cfg.temperature.max(1e-6);
        for s in &mut scores {
            *s *= inv_t;
        }
    }

    let mut indices: Vec<usize> = (0..scores.len()).collect();
    if let Some(k) = cfg.top_k {
        let k = k.min(indices.len());
        indices.select_nth_unstable_by(k, |&a, &b| {
            scores[b]
                .partial_cmp(&scores[a])
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        indices.truncate(k);
    }

    let shifted = softmax_subset(&scores, &indices);
    let dist = WeightedIndex::new(shifted).unwrap();
    let mut rng = thread_rng();
    let pick = dist.sample(&mut rng);
    indices[pick] as u32
}

fn softmax_subset(scores: &[f32], idxs: &[usize]) -> Vec<f64> {
    let mut max_v = f32::NEG_INFINITY;
    for &i in idxs {
        max_v = max_v.max(scores[i]);
    }
    let mut sum = 0.0f64;
    let mut exps = Vec::with_capacity(idxs.len());
    for &i in idxs {
        let e = ((scores[i] - max_v) as f64).exp();
        sum += e;
        exps.push(e);
    }
    for e in &mut exps {
        *e /= sum.max(1e-12);
    }
    exps
}
