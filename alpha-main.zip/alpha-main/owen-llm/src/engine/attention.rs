//! Attention module placeholder. To be implemented with simd::gemm.

