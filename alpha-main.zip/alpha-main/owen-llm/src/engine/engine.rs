use crate::core::error::Result;

#[derive(Debug, Clone)]
pub struct EngineConfig {
    pub vocab_size: usize,
    pub hidden_size: usize,
}

#[derive(Debug)]
pub struct Engine {
    pub config: EngineConfig,
}

impl Engine {
    pub fn new(config: EngineConfig) -> Result<Self> {
        Ok(Self { config })
    }

    pub fn forward_logits(&mut self, _token_id: u32) -> Result<Vec<f32>> {
        Ok(vec![0.0; self.config.vocab_size])
    }
}
