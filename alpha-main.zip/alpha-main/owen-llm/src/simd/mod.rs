mod scalar;
pub mod common;

pub use scalar::gemm_scalar;

#[derive(Debug)]
pub struct GemmParams<'a> {
    pub m: usize,
    pub n: usize,
    pub k: usize,
    pub a: &'a [f32],
    pub b: &'a [f32],
    pub c: &'a mut [f32],
}

pub fn gemm(params: GemmParams<'_>) {
    // TODO: runtime dispatch to arch-specific kernels
    crate::simd::scalar::gemm_scalar(params)
}
