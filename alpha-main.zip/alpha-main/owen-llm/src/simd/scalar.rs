use super::{common::validate_gemm_inputs, GemmParams};

pub fn gemm_scalar(mut params: GemmParams<'_>) {
    assert!(validate_gemm_inputs(params.m, params.n, params.k, params.a, params.b, params.c));
    let (m, n, k) = (params.m, params.n, params.k);
    let (a, b, c) = (params.a, params.b, &mut params.c);
    for i in 0..m {
        for j in 0..n {
            let mut sum = 0.0f32;
            for p in 0..k {
                sum += a[i * k + p] * b[p * n + j];
            }
            c[i * n + j] = sum;
        }
    }
}
