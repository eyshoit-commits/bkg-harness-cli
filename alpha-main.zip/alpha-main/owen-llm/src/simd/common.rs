pub fn validate_gemm_inputs(m: usize, n: usize, k: usize, a: &[f32], b: &[f32], c: &[f32]) -> bool {
    a.len() == m * k && b.len() == k * n && c.len() == m * n
}
