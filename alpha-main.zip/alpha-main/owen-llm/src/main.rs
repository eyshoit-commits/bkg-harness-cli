use owen_llm::config::AppConfig;
use owen_llm::core::log::init_logging;
use std::path::PathBuf;

fn main() {
    init_logging();
    let config_path = std::env::args()
        .nth(1)
        .map(PathBuf::from);
    let cfg = AppConfig::load(config_path).expect("load config");
    tracing::info!(port = cfg.server.port, model_dir = ?cfg.server.model_dir, "owen-llm starting");
}
