use rand::Rng;
use std::time::Duration;

#[derive(Clone, Debug)]
pub struct RetryPolicy {
    pub max_retries: u32,
    pub initial_backoff: Duration,
    pub max_backoff: Duration,
    pub jitter_fraction: f64,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_retries: 5,
            initial_backoff: Duration::from_millis(200),
            max_backoff: Duration::from_secs(10),
            jitter_fraction: 0.2,
        }
    }
}

impl RetryPolicy {
    pub fn backoff_with_jitter(&self, attempt: u32) -> Duration {
        let pow = 2u64.saturating_pow(attempt.min(30));
        let base = self
            .initial_backoff
            .saturating_mul(pow.try_into().unwrap_or(u32::MAX));
        let clamped = base.min(self.max_backoff);
        let jitter = (clamped.as_millis() as f64) * self.jitter_fraction;
        let delta = rand::thread_rng().gen_range(0.0..jitter);
        let millis = (clamped.as_millis() as f64 + delta) as u64;
        Duration::from_millis(millis)
    }
}
