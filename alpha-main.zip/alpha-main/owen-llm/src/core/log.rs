use tracing_subscriber::{fmt, layer::SubscriberExt, EnvFilter, Registry};

pub fn init_logging() {
    let env_filter = EnvFilter::try_from_default_env()
        .or_else(|_| EnvFilter::try_new("info"))
        .unwrap();

    let fmt_layer = fmt::layer()
        .json()
        .with_current_span(false)
        .with_span_events(fmt::format::FmtSpan::NONE)
        .with_target(true)
        .with_file(false)
        .with_line_number(false)
        .with_level(true);

    let subscriber = Registry::default()
        .with(env_filter)
        .with(fmt_layer);

    let _ = tracing::subscriber::set_global_default(subscriber);
    tracing::debug!(message = "logging initialized");
}
