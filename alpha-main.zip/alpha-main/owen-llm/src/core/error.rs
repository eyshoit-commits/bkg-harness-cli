use std::io;
use thiserror::Error;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, Error)]
pub enum Error {
    #[error("I/O error: {0}")]
    Io(#[from] io::Error),
    #[error("serde json error: {0}")]
    SerdeJson(#[from] serde_json::Error),
    #[error("toml error: {0}")]
    TomlDe(#[from] toml::de::Error),
    #[error("toml ser error: {0}")]
    TomlSer(#[from] toml::ser::Error),
    #[error("invalid data: {0}")]
    InvalidData(&'static str),
    #[error("unsupported: {0}")]
    Unsupported(&'static str),
    #[error("other: {0}")]
    Other(String),
}
