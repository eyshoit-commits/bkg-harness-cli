use crate::core::error::Result;
use serde::{Deserialize, Serialize};
use std::{env, fs, path::PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub server: ServerConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerConfig {
    pub port: u16,
    pub model_dir: PathBuf,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub level: String,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            server: ServerConfig {
                port: 8080,
                model_dir: PathBuf::from("./models"),
            },
            logging: LoggingConfig {
                level: "info".to_string(),
            },
        }
    }
}

impl AppConfig {
    pub fn load(path: Option<PathBuf>) -> Result<Self> {
        let mut cfg = if let Some(path) = path {
            if path.exists() {
                let text = fs::read_to_string(path)?;
                toml::from_str(&text)?
            } else {
                Self::default()
            }
        } else {
            Self::default()
        };

        if let Ok(port) = env::var("OWEN_PORT") {
            if let Ok(num) = port.parse::<u16>() {
                cfg.server.port = num;
            }
        }
        if let Ok(level) = env::var("OWEN_LOG_LEVEL") {
            cfg.logging.level = level;
        }
        if let Ok(model_dir) = env::var("OWEN_MODEL_DIR") {
            cfg.server.model_dir = PathBuf::from(model_dir);
        }
        Ok(cfg)
    }
}
