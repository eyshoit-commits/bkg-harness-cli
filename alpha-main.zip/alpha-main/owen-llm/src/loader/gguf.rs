use crate::core::error::{Error, Result};
use crate::tensor::view::{mmap_file, DType, Shape, TensorView};
use memmap2::Mmap;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

#[derive(Debug, Clone)]
pub struct GGUFTensorMeta {
    pub name: String,
    pub offset: u64,
    pub dtype: DType,
    pub shape: Shape,
}

#[derive(Debug, Clone)]
pub struct GGUFIndex {
    pub path: PathBuf,
    pub version: u32,
    pub tensors: Vec<GGUFTensorMeta>,
    pub tensor_by_name: HashMap<String, usize>,
    map: Option<Arc<Mmap>>,
}

impl GGUFIndex {
    pub fn open_index(path: impl AsRef<Path>) -> Result<Self> {
        let path_buf = path.as_ref().to_path_buf();
        let bytes = std::fs::read(&path_buf)?;
        if bytes.len() < 8 {
            return Err(Error::InvalidData("file too small for GGUF header"));
        }
        if &bytes[0..4] != b"GGUF" {
            return Err(Error::InvalidData("missing GGUF magic"));
        }
        let version = u32::from_le_bytes(bytes[4..8].try_into().unwrap());

        // NOTE: Proper directory parsing is TODO. We return an empty index for now.
        Ok(Self {
            path: path_buf,
            version,
            tensors: Vec::new(),
            tensor_by_name: HashMap::new(),
            map: None,
        })
    }

    pub fn ensure_mmap(&mut self) -> Result<Arc<Mmap>> {
        if let Some(map) = &self.map {
            return Ok(Arc::clone(map));
        }
        let map = mmap_file(&self.path)?;
        self.map = Some(Arc::clone(&map));
        Ok(map)
    }

    pub fn tensor_view_by_name(&mut self, name: &str) -> Result<Option<TensorView>> {
        let idx = match self.tensor_by_name.get(name).copied() {
            Some(i) => i,
            None => return Ok(None),
        };
        let meta = self.tensors[idx].clone();
        let map = self.ensure_mmap()?;
        let element_size = meta.dtype.size_in_bytes();
        let len = meta.shape.num_elements() * element_size;
        let view = TensorView::from_mmap_arc(map, meta.offset as usize, len, meta.dtype, meta.shape.clone());
        Ok(Some(view))
    }
}
