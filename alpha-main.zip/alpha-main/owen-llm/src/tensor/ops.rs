//! Tensor operations scaffolding. Backed by simd::gemm for matmul.

