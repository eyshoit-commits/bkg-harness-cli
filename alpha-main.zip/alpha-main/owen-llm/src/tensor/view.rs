use crate::core::error::{Error, Result};
use memmap2::{Mmap, MmapOptions};
use serde::{Deserialize, Serialize};
use std::{fs::File, ops::Range, path::Path, sync::Arc};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DType {
    F32,
    F16,
    I8,
    U8,
    I16,
    I32,
    Q4_0,
}

impl DType {
    pub fn size_in_bytes(self) -> usize {
        match self {
            DType::F32 => 4,
            DType::F16 => 2,
            DType::I8 | DType::U8 => 1,
            DType::I16 => 2,
            DType::I32 => 4,
            DType::Q4_0 => 1, // compact; block-structured in real formats
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Shape(pub Vec<usize>);

impl Shape {
    pub fn num_elements(&self) -> usize {
        self.0.iter().copied().product::<usize>().max(1)
    }
}

#[derive(Debug, Clone)]
pub struct TensorView {
    pub dtype: DType,
    pub shape: Shape,
    file_map: Arc<Mmap>,
    byte_range: Range<usize>,
}

impl TensorView {
    pub fn len_bytes(&self) -> usize {
        self.byte_range.end - self.byte_range.start
    }

    pub fn as_f32_slice(&self) -> Result<&[f32]> {
        match self.dtype {
            DType::F32 => {
                let bytes = &self.file_map[self.byte_range.clone()];
                if bytes.as_ptr() as usize % std::mem::align_of::<f32>() != 0 {
                    return Err(Error::InvalidData("unaligned f32 slice"));
                }
                if bytes.len() % 4 != 0 {
                    return Err(Error::InvalidData("invalid f32 byte length"));
                }
                let slice = unsafe {
                    std::slice::from_raw_parts(bytes.as_ptr() as *const f32, bytes.len() / 4)
                };
                Ok(slice)
            }
            _ => Err(Error::Unsupported("dtype is not f32")),
        }
    }

    pub fn from_mmap_arc(
        map: Arc<Mmap>,
        offset: usize,
        len: usize,
        dtype: DType,
        shape: Shape,
    ) -> Self {
        Self {
            dtype,
            shape,
            file_map: map,
            byte_range: offset..(offset + len),
        }
    }
}

pub fn mmap_file(path: &Path) -> Result<Arc<Mmap>> {
    let file = File::open(path)?;
    let mmap = unsafe { MmapOptions::new().map(&file)? };
    Ok(Arc::new(mmap))
}
