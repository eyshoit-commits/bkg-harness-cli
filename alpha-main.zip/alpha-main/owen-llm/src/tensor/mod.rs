pub mod view;
pub mod ops;

pub use view::{DType, Shape, TensorView};
