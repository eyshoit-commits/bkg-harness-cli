use std::time::Duration;
use tokio::time::sleep;
use rand::Rng;

#[derive(Debug, Clone)]
pub struct RetryPolicy {
    pub max_retries: usize,
    pub base_delay: Duration,
    pub max_delay: Duration,
    pub jitter: bool,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_retries: 3,
            base_delay: Duration::from_millis(100),
            max_delay: Duration::from_secs(30),
            jitter: true,
        }
    }
}

impl RetryPolicy {
    pub fn new(max_retries: usize) -> Self {
        Self {
            max_retries,
            ..Default::default()
        }
    }
    
    pub fn with_base_delay(mut self, delay: Duration) -> Self {
        self.base_delay = delay;
        self
    }
    
    pub fn with_max_delay(mut self, delay: Duration) -> Self {
        self.max_delay = delay;
        self
    }
    
    pub fn with_jitter(mut self, jitter: bool) -> Self {
        self.jitter = jitter;
        self
    }
    
    pub async fn execute<F, T, E>(&self, mut operation: F) -> Result<T, E>
    where
        F: FnMut() -> Result<T, E>,
        E: std::fmt::Debug,
    {
        let mut attempt = 0;
        
        loop {
            match operation() {
                Ok(result) => return Ok(result),
                Err(error) => {
                    attempt += 1;
                    
                    if attempt > self.max_retries {
                        return Err(error);
                    }
                    
                    let delay = self.calculate_delay(attempt);
                    tracing::debug!(
                        "Operation failed (attempt {}/{}), retrying in {:?}: {:?}",
                        attempt, self.max_retries, delay, error
                    );
                    
                    sleep(delay).await;
                }
            }
        }
    }
    
    fn calculate_delay(&self, attempt: usize) -> Duration {
        let multiplier = 2_u64.pow((attempt as u32).saturating_sub(1));
        let exponential_delay = self.base_delay * multiplier as u32;
        let delay = exponential_delay.min(self.max_delay);
        
        if self.jitter {
            let jitter_range = delay.as_millis() / 10; // 10% jitter
            let jitter = rand::thread_rng().gen_range(0..=jitter_range);
            delay + Duration::from_millis(jitter as u64)
        } else {
            delay
        }
    }
}