use thiserror::Error;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Error, Debug)]
pub enum Error {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
    
    #[error("TOML error: {0}")]
    Toml(#[from] toml::de::Error),
    
    #[error("HTTP error: {0}")]
    Http(#[from] hyper::Error),
    
    #[error("Request error: {0}")]
    Request(#[from] reqwest::Error),
    
    #[error("Anyhow error: {0}")]
    Anyhow(#[from] anyhow::Error),
    
    #[error("Model error: {message}")]
    Model { message: String },
    
    #[error("GGUF error: {message}")]
    Gguf { message: String },
    
    #[error("Tensor error: {message}")]
    Tensor { message: String },
    
    #[error("Engine error: {message}")]
    Engine { message: String },
    
    #[error("Authentication error: {message}")]
    Auth { message: String },
    
    #[error("Configuration error: {message}")]
    Config { message: String },
    
    #[error("Download error: {message}")]
    Download { message: String },
    
    #[error("SIMD error: {message}")]
    Simd { message: String },
    
    #[error("Server error: {message}")]
    Server { message: String },
    
    #[error("Internal error: {message}")]
    Internal { message: String },
}

impl Error {
    pub fn model(message: impl Into<String>) -> Self {
        Self::Model { message: message.into() }
    }
    
    pub fn gguf(message: impl Into<String>) -> Self {
        Self::Gguf { message: message.into() }
    }
    
    pub fn tensor(message: impl Into<String>) -> Self {
        Self::Tensor { message: message.into() }
    }
    
    pub fn engine(message: impl Into<String>) -> Self {
        Self::Engine { message: message.into() }
    }
    
    pub fn auth(message: impl Into<String>) -> Self {
        Self::Auth { message: message.into() }
    }
    
    pub fn config(message: impl Into<String>) -> Self {
        Self::Config { message: message.into() }
    }
    
    pub fn download(message: impl Into<String>) -> Self {
        Self::Download { message: message.into() }
    }
    
    pub fn simd(message: impl Into<String>) -> Self {
        Self::Simd { message: message.into() }
    }
    
    pub fn server(message: impl Into<String>) -> Self {
        Self::Server { message: message.into() }
    }
    
    pub fn internal(message: impl Into<String>) -> Self {
        Self::Internal { message: message.into() }
    }
}