use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;
use tokio::fs::OpenOptions;
use tokio::io::AsyncWriteExt;
use uuid::Uuid;

use crate::core::{Error, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditEntry {
    pub id: Uuid,
    pub timestamp: DateTime<Utc>,
    pub user_id: Option<String>,
    pub action: String,
    pub resource: String,
    pub metadata: HashMap<String, serde_json::Value>,
    pub success: bool,
    pub error: Option<String>,
}

impl AuditEntry {
    pub fn new(
        action: impl Into<String>,
        resource: impl Into<String>,
    ) -> Self {
        Self {
            id: Uuid::new_v4(),
            timestamp: Utc::now(),
            user_id: None,
            action: action.into(),
            resource: resource.into(),
            metadata: HashMap::new(),
            success: true,
            error: None,
        }
    }
    
    pub fn with_user(mut self, user_id: impl Into<String>) -> Self {
        self.user_id = Some(user_id.into());
        self
    }
    
    pub fn with_metadata(mut self, key: impl Into<String>, value: serde_json::Value) -> Self {
        self.metadata.insert(key.into(), value);
        self
    }
    
    pub fn with_error(mut self, error: impl Into<String>) -> Self {
        self.success = false;
        self.error = Some(error.into());
        self
    }
}

pub struct AuditLogger {
    log_path: std::path::PathBuf,
}

impl AuditLogger {
    pub fn new(log_path: impl AsRef<Path>) -> Self {
        Self {
            log_path: log_path.as_ref().to_path_buf(),
        }
    }
    
    pub async fn log(&self, entry: AuditEntry) -> Result<()> {
        let entry_json = serde_json::to_string(&entry)
            .map_err(|e| Error::internal(format!("Failed to serialize audit entry: {}", e)))?;
        
        let mut file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.log_path)
            .await
            .map_err(|e| Error::internal(format!("Failed to open audit log: {}", e)))?;
        
        file.write_all(entry_json.as_bytes()).await
            .map_err(|e| Error::internal(format!("Failed to write audit entry: {}", e)))?;
        
        file.write_all(b"\n").await
            .map_err(|e| Error::internal(format!("Failed to write newline: {}", e)))?;
        
        file.sync_all().await
            .map_err(|e| Error::internal(format!("Failed to sync audit log: {}", e)))?;
        
        Ok(())
    }
    
    pub async fn log_action(
        &self,
        action: impl Into<String>,
        resource: impl Into<String>,
    ) -> Result<()> {
        let entry = AuditEntry::new(action, resource);
        self.log(entry).await
    }
    
    pub async fn log_error(
        &self,
        action: impl Into<String>,
        resource: impl Into<String>,
        error: impl Into<String>,
    ) -> Result<()> {
        let entry = AuditEntry::new(action, resource).with_error(error);
        self.log(entry).await
    }
}