use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use tokio::fs;

use crate::Args;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub profile: String,
    pub server: ServerConfig,
    pub model: ModelConfig,
    pub engine: EngineConfig,
    pub auth: AuthConfig,
    pub logging: LoggingConfig,
    pub admin: AdminConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub workers: usize,
    pub max_connections: usize,
    pub timeout_seconds: u64,
    pub cors_enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelConfig {
    pub directory: PathBuf,
    pub cache_size_mb: usize,
    pub max_models: usize,
    pub download_timeout_seconds: u64,
    pub verify_checksums: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineConfig {
    pub max_sequence_length: usize,
    pub batch_size: usize,
    pub num_threads: usize,
    pub use_simd: bool,
    pub kv_cache_size_mb: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthConfig {
    pub enabled: bool,
    pub jwt_secret: Option<String>,
    pub token_expiry_hours: u64,
    pub admin_token: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub level: String,
    pub json_format: bool,
    pub file_path: Option<PathBuf>,
    pub audit_log_path: Option<PathBuf>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdminConfig {
    pub enabled: bool,
    pub ui_enabled: bool,
    pub terminal_enabled: bool,
    pub allowed_commands: Vec<String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            profile: "dev".to_string(),
            server: ServerConfig {
                host: "0.0.0.0".to_string(),
                port: 8080,
                workers: num_cpus::get(),
                max_connections: 1000,
                timeout_seconds: 30,
                cors_enabled: true,
            },
            model: ModelConfig {
                directory: PathBuf::from("./models"),
                cache_size_mb: 2048,
                max_models: 10,
                download_timeout_seconds: 300,
                verify_checksums: true,
            },
            engine: EngineConfig {
                max_sequence_length: 2048,
                batch_size: 1,
                num_threads: num_cpus::get(),
                use_simd: true,
                kv_cache_size_mb: 512,
            },
            auth: AuthConfig {
                enabled: false,
                jwt_secret: None,
                token_expiry_hours: 24,
                admin_token: None,
            },
            logging: LoggingConfig {
                level: "info".to_string(),
                json_format: true,
                file_path: None,
                audit_log_path: Some(PathBuf::from("./logs/audit.jsonl")),
            },
            admin: AdminConfig {
                enabled: true,
                ui_enabled: true,
                terminal_enabled: false,
                allowed_commands: vec![
                    "ps".to_string(),
                    "top".to_string(),
                    "df".to_string(),
                    "free".to_string(),
                    "tail".to_string(),
                ],
            },
        }
    }
}

impl Config {
    pub async fn load(config_path: Option<&Path>, args: &Args) -> Result<Self> {
        let mut config = if let Some(path) = config_path {
            Self::load_from_file(path).await?
        } else {
            // Try to load from default locations
            let default_paths = [
                "./llm-loader.toml",
                "~/.config/llm-loader/config.toml",
                "/etc/llm-loader/config.toml",
            ];
            
            let mut config = Self::default();
            
            for path_str in &default_paths {
                let path = if path_str.starts_with('~') {
                    if let Some(home) = dirs::home_dir() {
                        home.join(&path_str[2..])
                    } else {
                        continue;
                    }
                } else {
                    PathBuf::from(path_str)
                };
                
                if path.exists() {
                    config = Self::load_from_file(&path).await?;
                    break;
                }
            }
            
            config
        };
        
        // Override with CLI arguments
        config.server.port = args.port;
        config.model.directory = args.model_dir.clone();
        config.logging.level = args.log_level.clone();
        config.admin.ui_enabled = args.admin_ui;
        
        // Override with environment variables
        if let Ok(port) = std::env::var("LLM_LOADER_PORT") {
            if let Ok(port) = port.parse() {
                config.server.port = port;
            }
        }
        
        if let Ok(model_dir) = std::env::var("LLM_LOADER_MODEL_DIR") {
            config.model.directory = PathBuf::from(model_dir);
        }
        
        if let Ok(log_level) = std::env::var("LLM_LOADER_LOG_LEVEL") {
            config.logging.level = log_level;
        }
        
        Ok(config)
    }
    
    async fn load_from_file(path: &Path) -> Result<Self> {
        let contents = fs::read_to_string(path).await?;
        let config: Self = toml::from_str(&contents)?;
        Ok(config)
    }
    
    pub async fn save(&self, path: &Path) -> Result<()> {
        let contents = toml::to_string_pretty(self)?;
        
        // Create parent directory if it doesn't exist
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).await?;
        }
        
        fs::write(path, contents).await?;
        Ok(())
    }
    
    pub fn is_production(&self) -> bool {
        self.profile == "prod" || self.profile == "production"
    }
    
    pub fn is_development(&self) -> bool {
        self.profile == "dev" || self.profile == "development"
    }
}