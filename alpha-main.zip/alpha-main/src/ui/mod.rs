/// Embedded UI assets for the cyberpunk admin interface
pub mod assets {
    /// Get the admin UI HTML content
    pub fn admin_html() -> &'static str {
        include_str!("../../ui/admin.html")
    }
    
    /// Get admin UI CSS (if we had a separate CSS file)
    pub fn admin_css() -> Option<&'static str> {
        // CSS is embedded in the HTML for now
        None
    }
    
    /// Get admin UI JavaScript (if we had a separate JS file)
    pub fn admin_js() -> Option<&'static str> {
        // JavaScript is embedded in the HTML for now
        None
    }
}