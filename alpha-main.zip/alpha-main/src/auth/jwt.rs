use chrono::{DateTime, Duration, Utc};
use jsonwebtoken::{decode, encode, Algorithm, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use crate::auth::{CapabilitySet, Permission};
use crate::core::{Error, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JwtClaims {
    /// Subject (user ID)
    pub sub: String,
    
    /// Issued at timestamp
    pub iat: i64,
    
    /// Expiration timestamp
    pub exp: i64,
    
    /// Issuer
    pub iss: String,
    
    /// Audience
    pub aud: String,
    
    /// User permissions
    pub permissions: Permission,
    
    /// Session ID for revocation
    pub session_id: String,
    
    /// Custom metadata
    pub metadata: HashMap<String, serde_json::Value>,
}

impl JwtClaims {
    pub fn new(
        user_id: String,
        permissions: Permission,
        session_id: String,
        expiry_hours: i64,
    ) -> Self {
        let now = Utc::now();
        let exp = now + Duration::hours(expiry_hours);
        
        Self {
            sub: user_id,
            iat: now.timestamp(),
            exp: exp.timestamp(),
            iss: "llm-loader".to_string(),
            aud: "llm-loader-api".to_string(),
            permissions,
            session_id,
            metadata: HashMap::new(),
        }
    }
    
    pub fn is_expired(&self) -> bool {
        Utc::now().timestamp() > self.exp
    }
    
    pub fn expires_at(&self) -> DateTime<Utc> {
        DateTime::from_timestamp(self.exp, 0).unwrap_or_else(Utc::now)
    }
    
    pub fn issued_at(&self) -> DateTime<Utc> {
        DateTime::from_timestamp(self.iat, 0).unwrap_or_else(Utc::now)
    }
    
    pub fn capabilities(&self) -> CapabilitySet {
        self.permissions.to_capability_set()
    }
    
    pub fn add_metadata(&mut self, key: String, value: serde_json::Value) {
        self.metadata.insert(key, value);
    }
    
    pub fn get_metadata(&self, key: &str) -> Option<&serde_json::Value> {
        self.metadata.get(key)
    }
}

pub struct JwtManager {
    encoding_key: EncodingKey,
    decoding_key: DecodingKey,
    algorithm: Algorithm,
    validation: Validation,
    revoked_sessions: std::sync::RwLock<std::collections::HashSet<String>>,
}

impl JwtManager {
    pub fn new(secret: &str) -> Self {
        let encoding_key = EncodingKey::from_secret(secret.as_bytes());
        let decoding_key = DecodingKey::from_secret(secret.as_bytes());
        let algorithm = Algorithm::HS256;
        
        let mut validation = Validation::new(algorithm);
        validation.set_issuer(&["llm-loader"]);
        validation.set_audience(&["llm-loader-api"]);
        validation.validate_exp = true;
        validation.validate_nbf = false;
        
        Self {
            encoding_key,
            decoding_key,
            algorithm,
            validation,
            revoked_sessions: std::sync::RwLock::new(std::collections::HashSet::new()),
        }
    }
    
    pub fn generate_token(&self, claims: JwtClaims) -> Result<String> {
        let header = Header::new(self.algorithm);
        encode(&header, &claims, &self.encoding_key)
            .map_err(|e| Error::auth(format!("Failed to encode JWT: {}", e)))
    }
    
    pub fn verify_token(&self, token: &str) -> Result<JwtClaims> {
        let token_data = decode::<JwtClaims>(token, &self.decoding_key, &self.validation)
            .map_err(|e| Error::auth(format!("Failed to decode JWT: {}", e)))?;
        
        let claims = token_data.claims;
        
        // Check if the session is revoked
        if self.is_session_revoked(&claims.session_id) {
            return Err(Error::auth("Session has been revoked".to_string()));
        }
        
        // Check if the token is expired
        if claims.is_expired() {
            return Err(Error::auth("Token has expired".to_string()));
        }
        
        Ok(claims)
    }
    
    pub fn refresh_token(&self, old_token: &str, new_expiry_hours: i64) -> Result<String> {
        let claims = self.verify_token(old_token)?;
        
        let new_claims = JwtClaims::new(
            claims.sub,
            claims.permissions,
            uuid::Uuid::new_v4().to_string(), // New session ID
            new_expiry_hours,
        );
        
        // Revoke the old session
        self.revoke_session(&claims.session_id);
        
        self.generate_token(new_claims)
    }
    
    pub fn revoke_session(&self, session_id: &str) {
        if let Ok(mut revoked) = self.revoked_sessions.write() {
            revoked.insert(session_id.to_string());
        }
    }
    
    pub fn is_session_revoked(&self, session_id: &str) -> bool {
        if let Ok(revoked) = self.revoked_sessions.read() {
            revoked.contains(session_id)
        } else {
            false
        }
    }
    
    pub fn cleanup_expired_revocations(&self) {
        // In a real implementation, you'd want to periodically clean up
        // expired session IDs from the revoked set to prevent memory leaks
        // This could be done with a background task
    }
    
    pub fn create_admin_token(&self, expiry_hours: i64) -> Result<String> {
        let claims = JwtClaims::new(
            "admin".to_string(),
            Permission::Admin,
            uuid::Uuid::new_v4().to_string(),
            expiry_hours,
        );
        
        self.generate_token(claims)
    }
    
    pub fn create_user_token(&self, user_id: String, permission: Permission, expiry_hours: i64) -> Result<String> {
        let claims = JwtClaims::new(
            user_id,
            permission,
            uuid::Uuid::new_v4().to_string(),
            expiry_hours,
        );
        
        self.generate_token(claims)
    }
    
    pub fn decode_token_unsafe(&self, token: &str) -> Result<JwtClaims> {
        // Decode without verification - useful for debugging or extracting claims
        // from expired tokens
        let mut validation = Validation::new(self.algorithm);
        validation.validate_exp = false;
        validation.validate_aud = false;
        
        let token_data = decode::<JwtClaims>(token, &self.decoding_key, &validation)
            .map_err(|e| Error::auth(format!("Failed to decode JWT: {}", e)))?;
        
        Ok(token_data.claims)
    }
}

/// JWT token extractor for HTTP requests
#[derive(Debug)]
pub enum TokenLocation {
    Header(String),      // Authorization: Bearer <token>
    Cookie(String),      // Cookie: auth_token=<token>
    Query(String),       // ?token=<token>
}

impl Default for TokenLocation {
    fn default() -> Self {
        TokenLocation::Header("Authorization".to_string())
    }
}

pub fn extract_token_from_header(header_value: &str) -> Option<&str> {
    if header_value.starts_with("Bearer ") {
        Some(&header_value[7..])
    } else {
        None
    }
}

/// Helper for creating development tokens
pub fn create_dev_token_manager() -> JwtManager {
    JwtManager::new("dev-secret-key-not-for-production")
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::auth::Capability;
    
    #[test]
    fn test_jwt_creation_and_verification() {
        let manager = create_dev_token_manager();
        
        let claims = JwtClaims::new(
            "test_user".to_string(),
            Permission::User,
            "session_123".to_string(),
            24,
        );
        
        let token = manager.generate_token(claims.clone()).unwrap();
        let verified_claims = manager.verify_token(&token).unwrap();
        
        assert_eq!(verified_claims.sub, "test_user");
        assert_eq!(verified_claims.session_id, "session_123");
        assert!(!verified_claims.is_expired());
    }
    
    #[test]
    fn test_token_expiration() {
        let manager = create_dev_token_manager();
        
        let mut claims = JwtClaims::new(
            "test_user".to_string(),
            Permission::User,
            "session_123".to_string(),
            24,
        );
        
        // Set expiration to past
        claims.exp = Utc::now().timestamp() - 3600;
        
        let token = manager.generate_token(claims).unwrap();
        let result = manager.verify_token(&token);
        
        assert!(result.is_err());
    }
    
    #[test]
    fn test_session_revocation() {
        let manager = create_dev_token_manager();
        
        let claims = JwtClaims::new(
            "test_user".to_string(),
            Permission::User,
            "session_123".to_string(),
            24,
        );
        
        let token = manager.generate_token(claims).unwrap();
        
        // Token should be valid initially
        assert!(manager.verify_token(&token).is_ok());
        
        // Revoke the session
        manager.revoke_session("session_123");
        
        // Token should now be invalid
        assert!(manager.verify_token(&token).is_err());
    }
    
    #[test]
    fn test_token_refresh() {
        let manager = create_dev_token_manager();
        
        let claims = JwtClaims::new(
            "test_user".to_string(),
            Permission::User,
            "session_123".to_string(),
            24,
        );
        
        let old_token = manager.generate_token(claims).unwrap();
        let new_token = manager.refresh_token(&old_token, 48).unwrap();
        
        // Old token should be revoked
        assert!(manager.verify_token(&old_token).is_err());
        
        // New token should be valid
        let new_claims = manager.verify_token(&new_token).unwrap();
        assert_eq!(new_claims.sub, "test_user");
        assert_ne!(new_claims.session_id, "session_123"); // New session ID
    }
    
    #[test]
    fn test_capability_extraction() {
        let claims = JwtClaims::new(
            "test_user".to_string(),
            Permission::User,
            "session_123".to_string(),
            24,
        );
        
        let capabilities = claims.capabilities();
        assert!(capabilities.has(&Capability::InferenceExecute));
        assert!(!capabilities.has(&Capability::SystemConfig));
    }
}