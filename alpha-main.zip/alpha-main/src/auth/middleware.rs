// Re-export the auth middleware from server
pub use crate::server::middleware::auth::*;