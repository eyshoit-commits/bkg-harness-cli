use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::fmt;

use crate::core::{Error, Result};

/// Fine-grained capability-based permissions
#[derive(Debug, Clone, Hash, PartialEq, Eq, Serialize, Deserialize)]
pub enum Capability {
    // Model management
    ModelLoad,
    ModelUnload,
    ModelInfo,
    ModelList,
    
    // Inference operations
    InferenceExecute,
    InferenceStream,
    InferenceConfig,
    
    // Tokenization
    Tokenize,
    Detokenize,
    
    // Embeddings
    EmbeddingsCompute,
    
    // System administration
    SystemInfo,
    SystemMetrics,
    SystemLogs,
    SystemConfig,
    
    // Admin UI access
    AdminUIAccess,
    AdminUITerminal,
    
    // Configuration management
    ConfigRead,
    ConfigWrite,
    ConfigReload,
    
    // Log management
    LogsRead,
    LogsClear,
    LogsDownload,
    
    // File operations
    FileRead,
    FileWrite,
    FileDelete,
    FileList,
    
    // Network operations
    NetworkAccess,
    NetworkProxy,
    
    // Process management
    ProcessStart,
    ProcessStop,
    ProcessRestart,
    ProcessList,
    
    // Custom capability for extensibility
    Custom(String),
}

impl fmt::Display for Capability {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Capability::ModelLoad => write!(f, "model:load"),
            Capability::ModelUnload => write!(f, "model:unload"),
            Capability::ModelInfo => write!(f, "model:info"),
            Capability::ModelList => write!(f, "model:list"),
            Capability::InferenceExecute => write!(f, "inference:execute"),
            Capability::InferenceStream => write!(f, "inference:stream"),
            Capability::InferenceConfig => write!(f, "inference:config"),
            Capability::Tokenize => write!(f, "tokenize"),
            Capability::Detokenize => write!(f, "detokenize"),
            Capability::EmbeddingsCompute => write!(f, "embeddings:compute"),
            Capability::SystemInfo => write!(f, "system:info"),
            Capability::SystemMetrics => write!(f, "system:metrics"),
            Capability::SystemLogs => write!(f, "system:logs"),
            Capability::SystemConfig => write!(f, "system:config"),
            Capability::AdminUIAccess => write!(f, "admin:ui"),
            Capability::AdminUITerminal => write!(f, "admin:terminal"),
            Capability::ConfigRead => write!(f, "config:read"),
            Capability::ConfigWrite => write!(f, "config:write"),
            Capability::ConfigReload => write!(f, "config:reload"),
            Capability::LogsRead => write!(f, "logs:read"),
            Capability::LogsClear => write!(f, "logs:clear"),
            Capability::LogsDownload => write!(f, "logs:download"),
            Capability::FileRead => write!(f, "file:read"),
            Capability::FileWrite => write!(f, "file:write"),
            Capability::FileDelete => write!(f, "file:delete"),
            Capability::FileList => write!(f, "file:list"),
            Capability::NetworkAccess => write!(f, "network:access"),
            Capability::NetworkProxy => write!(f, "network:proxy"),
            Capability::ProcessStart => write!(f, "process:start"),
            Capability::ProcessStop => write!(f, "process:stop"),
            Capability::ProcessRestart => write!(f, "process:restart"),
            Capability::ProcessList => write!(f, "process:list"),
            Capability::Custom(name) => write!(f, "custom:{}", name),
        }
    }
}

impl Capability {
    /// Parse capability from string representation
    pub fn from_str(s: &str) -> Result<Self> {
        match s {
            "model:load" => Ok(Capability::ModelLoad),
            "model:unload" => Ok(Capability::ModelUnload),
            "model:info" => Ok(Capability::ModelInfo),
            "model:list" => Ok(Capability::ModelList),
            "inference:execute" => Ok(Capability::InferenceExecute),
            "inference:stream" => Ok(Capability::InferenceStream),
            "inference:config" => Ok(Capability::InferenceConfig),
            "tokenize" => Ok(Capability::Tokenize),
            "detokenize" => Ok(Capability::Detokenize),
            "embeddings:compute" => Ok(Capability::EmbeddingsCompute),
            "system:info" => Ok(Capability::SystemInfo),
            "system:metrics" => Ok(Capability::SystemMetrics),
            "system:logs" => Ok(Capability::SystemLogs),
            "system:config" => Ok(Capability::SystemConfig),
            "admin:ui" => Ok(Capability::AdminUIAccess),
            "admin:terminal" => Ok(Capability::AdminUITerminal),
            "config:read" => Ok(Capability::ConfigRead),
            "config:write" => Ok(Capability::ConfigWrite),
            "config:reload" => Ok(Capability::ConfigReload),
            "logs:read" => Ok(Capability::LogsRead),
            "logs:clear" => Ok(Capability::LogsClear),
            "logs:download" => Ok(Capability::LogsDownload),
            "file:read" => Ok(Capability::FileRead),
            "file:write" => Ok(Capability::FileWrite),
            "file:delete" => Ok(Capability::FileDelete),
            "file:list" => Ok(Capability::FileList),
            "network:access" => Ok(Capability::NetworkAccess),
            "network:proxy" => Ok(Capability::NetworkProxy),
            "process:start" => Ok(Capability::ProcessStart),
            "process:stop" => Ok(Capability::ProcessStop),
            "process:restart" => Ok(Capability::ProcessRestart),
            "process:list" => Ok(Capability::ProcessList),
            s if s.starts_with("custom:") => {
                let name = s.strip_prefix("custom:").unwrap();
                Ok(Capability::Custom(name.to_string()))
            }
            _ => Err(Error::auth(format!("Unknown capability: {}", s))),
        }
    }
    
    /// Get the category of this capability
    pub fn category(&self) -> &'static str {
        match self {
            Capability::ModelLoad | Capability::ModelUnload | 
            Capability::ModelInfo | Capability::ModelList => "model",
            
            Capability::InferenceExecute | Capability::InferenceStream | 
            Capability::InferenceConfig => "inference",
            
            Capability::Tokenize | Capability::Detokenize => "tokenization",
            
            Capability::EmbeddingsCompute => "embeddings",
            
            Capability::SystemInfo | Capability::SystemMetrics | 
            Capability::SystemLogs | Capability::SystemConfig => "system",
            
            Capability::AdminUIAccess | Capability::AdminUITerminal => "admin",
            
            Capability::ConfigRead | Capability::ConfigWrite | 
            Capability::ConfigReload => "config",
            
            Capability::LogsRead | Capability::LogsClear | 
            Capability::LogsDownload => "logs",
            
            Capability::FileRead | Capability::FileWrite | 
            Capability::FileDelete | Capability::FileList => "file",
            
            Capability::NetworkAccess | Capability::NetworkProxy => "network",
            
            Capability::ProcessStart | Capability::ProcessStop | 
            Capability::ProcessRestart | Capability::ProcessList => "process",
            
            Capability::Custom(_) => "custom",
        }
    }
    
    /// Check if this capability is considered dangerous
    pub fn is_dangerous(&self) -> bool {
        matches!(self,
            Capability::ModelUnload |
            Capability::SystemConfig |
            Capability::ConfigWrite |
            Capability::ConfigReload |
            Capability::LogsClear |
            Capability::FileWrite |
            Capability::FileDelete |
            Capability::ProcessStart |
            Capability::ProcessStop |
            Capability::ProcessRestart |
            Capability::AdminUITerminal |
            Capability::NetworkProxy
        )
    }
}

/// A set of capabilities with efficient lookup
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapabilitySet {
    capabilities: HashSet<Capability>,
}

impl CapabilitySet {
    /// Create a new empty capability set
    pub fn new() -> Self {
        Self {
            capabilities: HashSet::new(),
        }
    }
    
    /// Create a capability set from a list of capabilities
    pub fn from_capabilities(capabilities: Vec<Capability>) -> Self {
        Self {
            capabilities: capabilities.into_iter().collect(),
        }
    }
    
    /// Create a capability set from string representations
    pub fn from_strings(capability_strings: Vec<String>) -> Result<Self> {
        let mut capabilities = HashSet::new();
        for cap_str in capability_strings {
            capabilities.insert(Capability::from_str(&cap_str)?);
        }
        Ok(Self { capabilities })
    }
    
    /// Add a capability to the set
    pub fn add(&mut self, capability: Capability) {
        self.capabilities.insert(capability);
    }
    
    /// Remove a capability from the set
    pub fn remove(&mut self, capability: &Capability) -> bool {
        self.capabilities.remove(capability)
    }
    
    /// Check if the set contains a specific capability
    pub fn has(&self, capability: &Capability) -> bool {
        self.capabilities.contains(capability)
    }
    
    /// Check if the set has all the required capabilities
    pub fn has_all(&self, required: &[Capability]) -> bool {
        required.iter().all(|cap| self.has(cap))
    }
    
    /// Check if the set has any of the required capabilities
    pub fn has_any(&self, required: &[Capability]) -> bool {
        required.iter().any(|cap| self.has(cap))
    }
    
    /// Get all capabilities in the set
    pub fn capabilities(&self) -> &HashSet<Capability> {
        &self.capabilities
    }
    
    /// Get capabilities by category
    pub fn by_category(&self, category: &str) -> Vec<&Capability> {
        self.capabilities
            .iter()
            .filter(|cap| cap.category() == category)
            .collect()
    }
    
    /// Get dangerous capabilities in the set
    pub fn dangerous_capabilities(&self) -> Vec<&Capability> {
        self.capabilities
            .iter()
            .filter(|cap| cap.is_dangerous())
            .collect()
    }
    
    /// Check if the set contains any dangerous capabilities
    pub fn has_dangerous(&self) -> bool {
        self.capabilities.iter().any(|cap| cap.is_dangerous())
    }
    
    /// Create a union of two capability sets
    pub fn union(&self, other: &CapabilitySet) -> CapabilitySet {
        let mut capabilities = self.capabilities.clone();
        capabilities.extend(other.capabilities.iter().cloned());
        CapabilitySet { capabilities }
    }
    
    /// Create an intersection of two capability sets
    pub fn intersection(&self, other: &CapabilitySet) -> CapabilitySet {
        let capabilities = self.capabilities
            .intersection(&other.capabilities)
            .cloned()
            .collect();
        CapabilitySet { capabilities }
    }
    
    /// Check if the set is empty
    pub fn is_empty(&self) -> bool {
        self.capabilities.is_empty()
    }
    
    /// Get the number of capabilities
    pub fn len(&self) -> usize {
        self.capabilities.len()
    }
    
    /// Convert to a vector of strings
    pub fn to_strings(&self) -> Vec<String> {
        self.capabilities.iter().map(|cap| cap.to_string()).collect()
    }
}

impl Default for CapabilitySet {
    fn default() -> Self {
        Self::new()
    }
}

/// Predefined permission levels
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Permission {
    /// No access - empty capability set
    None,
    
    /// Read-only access to basic information
    ReadOnly,
    
    /// Standard user - can perform inference and basic operations
    User,
    
    /// Power user - can manage models and configurations
    PowerUser,
    
    /// Administrator - full access to all capabilities
    Admin,
    
    /// Custom permission set
    Custom(CapabilitySet),
}

impl Permission {
    /// Convert permission to capability set
    pub fn to_capability_set(&self) -> CapabilitySet {
        match self {
            Permission::None => CapabilitySet::new(),
            
            Permission::ReadOnly => CapabilitySet::from_capabilities(vec![
                Capability::ModelInfo,
                Capability::ModelList,
                Capability::SystemInfo,
                Capability::SystemMetrics,
                Capability::LogsRead,
                Capability::ConfigRead,
            ]),
            
            Permission::User => CapabilitySet::from_capabilities(vec![
                // Read capabilities
                Capability::ModelInfo,
                Capability::ModelList,
                Capability::SystemInfo,
                Capability::SystemMetrics,
                Capability::LogsRead,
                Capability::ConfigRead,
                // Inference capabilities
                Capability::InferenceExecute,
                Capability::InferenceStream,
                Capability::InferenceConfig,
                Capability::Tokenize,
                Capability::Detokenize,
                Capability::EmbeddingsCompute,
                // Basic admin UI
                Capability::AdminUIAccess,
            ]),
            
            Permission::PowerUser => {
                let mut caps = Permission::User.to_capability_set();
                caps.add(Capability::ModelLoad);
                caps.add(Capability::ModelUnload);
                caps.add(Capability::ConfigWrite);
                caps.add(Capability::LogsClear);
                caps.add(Capability::FileRead);
                caps.add(Capability::FileList);
                caps
            },
            
            Permission::Admin => CapabilitySet::from_capabilities(vec![
                // All capabilities
                Capability::ModelLoad,
                Capability::ModelUnload,
                Capability::ModelInfo,
                Capability::ModelList,
                Capability::InferenceExecute,
                Capability::InferenceStream,
                Capability::InferenceConfig,
                Capability::Tokenize,
                Capability::Detokenize,
                Capability::EmbeddingsCompute,
                Capability::SystemInfo,
                Capability::SystemMetrics,
                Capability::SystemLogs,
                Capability::SystemConfig,
                Capability::AdminUIAccess,
                Capability::AdminUITerminal,
                Capability::ConfigRead,
                Capability::ConfigWrite,
                Capability::ConfigReload,
                Capability::LogsRead,
                Capability::LogsClear,
                Capability::LogsDownload,
                Capability::FileRead,
                Capability::FileWrite,
                Capability::FileDelete,
                Capability::FileList,
                Capability::NetworkAccess,
                Capability::NetworkProxy,
                Capability::ProcessStart,
                Capability::ProcessStop,
                Capability::ProcessRestart,
                Capability::ProcessList,
            ]),
            
            Permission::Custom(capability_set) => capability_set.clone(),
        }
    }
    
    /// Create a permission from a capability set
    pub fn from_capability_set(capability_set: CapabilitySet) -> Self {
        // Check if it matches a predefined permission level
        let admin_caps = Permission::Admin.to_capability_set();
        let power_user_caps = Permission::PowerUser.to_capability_set();
        let user_caps = Permission::User.to_capability_set();
        let readonly_caps = Permission::ReadOnly.to_capability_set();
        
        if capability_set.capabilities == admin_caps.capabilities {
            Permission::Admin
        } else if capability_set.capabilities == power_user_caps.capabilities {
            Permission::PowerUser
        } else if capability_set.capabilities == user_caps.capabilities {
            Permission::User
        } else if capability_set.capabilities == readonly_caps.capabilities {
            Permission::ReadOnly
        } else if capability_set.is_empty() {
            Permission::None
        } else {
            Permission::Custom(capability_set)
        }
    }
}

impl fmt::Display for Permission {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Permission::None => write!(f, "none"),
            Permission::ReadOnly => write!(f, "readonly"),
            Permission::User => write!(f, "user"),
            Permission::PowerUser => write!(f, "power_user"),
            Permission::Admin => write!(f, "admin"),
            Permission::Custom(_) => write!(f, "custom"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_capability_string_conversion() {
        let cap = Capability::ModelLoad;
        assert_eq!(cap.to_string(), "model:load");
        assert_eq!(Capability::from_str("model:load").unwrap(), cap);
    }
    
    #[test]
    fn test_capability_set_operations() {
        let mut caps = CapabilitySet::new();
        caps.add(Capability::ModelLoad);
        caps.add(Capability::InferenceExecute);
        
        assert!(caps.has(&Capability::ModelLoad));
        assert!(!caps.has(&Capability::ModelUnload));
        
        assert!(caps.has_all(&[Capability::ModelLoad, Capability::InferenceExecute]));
        assert!(!caps.has_all(&[Capability::ModelLoad, Capability::ModelUnload]));
        
        assert!(caps.has_any(&[Capability::ModelLoad, Capability::ModelUnload]));
        assert!(!caps.has_any(&[Capability::ModelUnload, Capability::SystemConfig]));
    }
    
    #[test]
    fn test_permission_levels() {
        let user_caps = Permission::User.to_capability_set();
        assert!(user_caps.has(&Capability::InferenceExecute));
        assert!(!user_caps.has(&Capability::SystemConfig));
        
        let admin_caps = Permission::Admin.to_capability_set();
        assert!(admin_caps.has(&Capability::SystemConfig));
        assert!(admin_caps.has(&Capability::InferenceExecute));
    }
    
    #[test]
    fn test_dangerous_capabilities() {
        let caps = CapabilitySet::from_capabilities(vec![
            Capability::ModelLoad,
            Capability::SystemConfig,
            Capability::InferenceExecute,
        ]);
        
        let dangerous = caps.dangerous_capabilities();
        assert_eq!(dangerous.len(), 1);
        assert_eq!(*dangerous[0], Capability::SystemConfig);
        assert!(caps.has_dangerous());
    }
}