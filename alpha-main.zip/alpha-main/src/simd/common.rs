use crate::core::Result;

/// GEMM parameters structure
#[derive(Debug, Clone)]
pub struct GemmParams {
    pub m: usize,      // Number of rows in A and C
    pub n: usize,      // Number of columns in B and C  
    pub k: usize,      // Number of columns in A / rows in B
    pub alpha: f32,    // Scaling factor for A*B
    pub beta: f32,     // Scaling factor for C
    pub lda: usize,    // Leading dimension of A
    pub ldb: usize,    // Leading dimension of B
    pub ldc: usize,    // Leading dimension of C
}

impl GemmParams {
    pub fn new(
        m: usize,
        n: usize, 
        k: usize,
        alpha: f32,
        beta: f32,
        lda: usize,
        ldb: usize,
        ldc: usize,
    ) -> Self {
        Self {
            m,
            n,
            k,
            alpha,
            beta,
            lda,
            ldb,
            ldc,
        }
    }
    
    pub fn validate(&self) -> Result<()> {
        if self.m == 0 || self.n == 0 || self.k == 0 {
            return Err(crate::core::Error::simd("Invalid matrix dimensions: zero size".to_string()));
        }
        
        if self.lda < self.k || self.ldb < self.n || self.ldc < self.n {
            return Err(crate::core::Error::simd("Invalid leading dimensions".to_string()));
        }
        
        Ok(())
    }
}

/// Packed matrix representation for optimized access patterns
pub struct PackedMatrix {
    pub data: Vec<f32>,
    pub rows: usize,
    pub cols: usize,
    pub block_size: usize,
}

impl PackedMatrix {
    pub fn pack_a(matrix: &[f32], m: usize, k: usize, lda: usize, block_size: usize) -> Self {
        let mut data = vec![0.0f32; m * k];
        
        // Pack matrix A in row-major blocks
        for block_row in (0..m).step_by(block_size) {
            for block_col in (0..k).step_by(block_size) {
                let end_row = (block_row + block_size).min(m);
                let end_col = (block_col + block_size).min(k);
                
                for i in block_row..end_row {
                    for j in block_col..end_col {
                        let src_idx = i * lda + j;
                        let dst_idx = block_row * k + block_col * block_size + 
                                     (i - block_row) * block_size + (j - block_col);
                        if src_idx < matrix.len() && dst_idx < data.len() {
                            data[dst_idx] = matrix[src_idx];
                        }
                    }
                }
            }
        }
        
        Self {
            data,
            rows: m,
            cols: k,
            block_size,
        }
    }
    
    pub fn pack_b(matrix: &[f32], k: usize, n: usize, ldb: usize, block_size: usize) -> Self {
        let mut data = vec![0.0f32; k * n];
        
        // Pack matrix B in column-major blocks
        for block_col in (0..n).step_by(block_size) {
            for block_row in (0..k).step_by(block_size) {
                let end_col = (block_col + block_size).min(n);
                let end_row = (block_row + block_size).min(k);
                
                for j in block_col..end_col {
                    for i in block_row..end_row {
                        let src_idx = i * ldb + j;
                        let dst_idx = block_col * k + block_row * block_size +
                                     (j - block_col) * block_size + (i - block_row);
                        if src_idx < matrix.len() && dst_idx < data.len() {
                            data[dst_idx] = matrix[src_idx];
                        }
                    }
                }
            }
        }
        
        Self {
            data,
            rows: k,
            cols: n,
            block_size,
        }
    }
}

/// Block sizes optimized for different architectures
pub const AVX2_BLOCK_SIZE: usize = 64;
pub const NEON_BLOCK_SIZE: usize = 32;
pub const SCALAR_BLOCK_SIZE: usize = 16;

/// Memory alignment for SIMD operations
pub const SIMD_ALIGNMENT: usize = 32;

/// Helper functions for common operations
pub mod helpers {
    /// Transpose a matrix in-place (square matrices only)
    pub fn transpose_square(matrix: &mut [f32], n: usize) {
        for i in 0..n {
            for j in (i + 1)..n {
                let idx1 = i * n + j;
                let idx2 = j * n + i;
                matrix.swap(idx1, idx2);
            }
        }
    }
    
    /// Copy matrix with different leading dimensions
    pub fn copy_matrix(
        src: &[f32],
        dst: &mut [f32],
        rows: usize,
        cols: usize,
        src_ld: usize,
        dst_ld: usize,
    ) {
        for i in 0..rows {
            for j in 0..cols {
                let src_idx = i * src_ld + j;
                let dst_idx = i * dst_ld + j;
                if src_idx < src.len() && dst_idx < dst.len() {
                    dst[dst_idx] = src[src_idx];
                }
            }
        }
    }
    
    /// Zero out a matrix
    pub fn zero_matrix(matrix: &mut [f32]) {
        matrix.fill(0.0);
    }
    
    /// Scale matrix by constant
    pub fn scale_matrix(matrix: &mut [f32], scale: f32) {
        for val in matrix.iter_mut() {
            *val *= scale;
        }
    }
}