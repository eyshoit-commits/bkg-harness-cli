use crate::core::Result;
use crate::simd::common::{GemmParams, SCALAR_BLOCK_SIZE};

/// Scalar GEMM implementation - baseline reference
pub fn gemm_scalar(
    params: &GemmParams,
    a: &[f32],
    b: &[f32],
    c: &mut [f32],
) -> Result<()> {
    params.validate()?;
    
    let GemmParams { m, n, k, alpha, beta, lda, ldb, ldc } = *params;
    
    // Apply beta scaling to C if needed
    if beta != 1.0 {
        for i in 0..m {
            for j in 0..n {
                let idx = i * ldc + j;
                if idx < c.len() {
                    c[idx] *= beta;
                }
            }
        }
    }
    
    // Blocked GEMM for better cache locality
    for ii in (0..m).step_by(SCALAR_BLOCK_SIZE) {
        for jj in (0..n).step_by(SCALAR_BLOCK_SIZE) {
            for kk in (0..k).step_by(SCALAR_BLOCK_SIZE) {
                let end_i = (ii + SCALAR_BLOCK_SIZE).min(m);
                let end_j = (jj + SCALAR_BLOCK_SIZE).min(n);
                let end_k = (kk + SCALAR_BLOCK_SIZE).min(k);
                
                gemm_micro_kernel(
                    ii, end_i, jj, end_j, kk, end_k,
                    alpha, a, lda, b, ldb, c, ldc,
                );
            }
        }
    }
    
    Ok(())
}

/// Micro-kernel for small block multiplication
fn gemm_micro_kernel(
    start_i: usize,
    end_i: usize,
    start_j: usize,
    end_j: usize,
    start_k: usize,
    end_k: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    b: &[f32],
    ldb: usize,
    c: &mut [f32],
    ldc: usize,
) {
    for i in start_i..end_i {
        for j in start_j..end_j {
            let mut sum = 0.0f32;
            
            // Inner loop - vectorizable
            for k in start_k..end_k {
                let a_idx = i * lda + k;
                let b_idx = k * ldb + j;
                
                if a_idx < a.len() && b_idx < b.len() {
                    sum += a[a_idx] * b[b_idx];
                }
            }
            
            let c_idx = i * ldc + j;
            if c_idx < c.len() {
                c[c_idx] += alpha * sum;
            }
        }
    }
}

/// Optimized matrix-vector multiplication (GEMV)
pub fn gemv_scalar(
    m: usize,
    n: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    x: &[f32],
    beta: f32,
    y: &mut [f32],
) -> Result<()> {
    if a.len() < m * lda || x.len() < n || y.len() < m {
        return Err(crate::core::Error::simd("Invalid dimensions for GEMV".to_string()));
    }
    
    // Apply beta scaling to y
    if beta != 1.0 {
        for val in y.iter_mut().take(m) {
            *val *= beta;
        }
    }
    
    // Compute y = alpha * A * x + y
    for i in 0..m {
        let mut sum = 0.0f32;
        
        // Unroll inner loop for better performance
        let mut j = 0;
        while j + 4 <= n {
            let a_base = i * lda + j;
            sum += a[a_base] * x[j]
                + a[a_base + 1] * x[j + 1]
                + a[a_base + 2] * x[j + 2]
                + a[a_base + 3] * x[j + 3];
            j += 4;
        }
        
        // Handle remaining elements
        while j < n {
            let a_idx = i * lda + j;
            sum += a[a_idx] * x[j];
            j += 1;
        }
        
        y[i] += alpha * sum;
    }
    
    Ok(())
}

/// Vector dot product
pub fn dot_scalar(x: &[f32], y: &[f32]) -> Result<f32> {
    if x.len() != y.len() {
        return Err(crate::core::Error::simd("Vector length mismatch".to_string()));
    }
    
    let mut sum = 0.0f32;
    let n = x.len();
    
    // Unroll for better performance
    let mut i = 0;
    while i + 4 <= n {
        sum += x[i] * y[i]
            + x[i + 1] * y[i + 1]
            + x[i + 2] * y[i + 2]
            + x[i + 3] * y[i + 3];
        i += 4;
    }
    
    // Handle remaining elements
    while i < n {
        sum += x[i] * y[i];
        i += 1;
    }
    
    Ok(sum)
}

/// Vector scaling: y = alpha * x
pub fn scale_scalar(alpha: f32, x: &[f32], y: &mut [f32]) -> Result<()> {
    if x.len() != y.len() {
        return Err(crate::core::Error::simd("Vector length mismatch".to_string()));
    }
    
    for (dst, &src) in y.iter_mut().zip(x.iter()) {
        *dst = alpha * src;
    }
    
    Ok(())
}

/// Vector addition: z = alpha * x + y
pub fn axpy_scalar(alpha: f32, x: &[f32], y: &mut [f32]) -> Result<()> {
    if x.len() != y.len() {
        return Err(crate::core::Error::simd("Vector length mismatch".to_string()));
    }
    
    for (dst, &src) in y.iter_mut().zip(x.iter()) {
        *dst += alpha * src;
    }
    
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::simd::common::GemmParams;
    
    #[test]
    fn test_scalar_gemm_basic() {
        let a = vec![1.0, 2.0, 3.0, 4.0]; // 2x2
        let b = vec![5.0, 6.0, 7.0, 8.0]; // 2x2
        let mut c = vec![0.0; 4]; // 2x2
        
        let params = GemmParams::new(2, 2, 2, 1.0, 0.0, 2, 2, 2);
        gemm_scalar(&params, &a, &b, &mut c).unwrap();
        
        // Expected: [19, 22, 43, 50]
        assert!((c[0] - 19.0).abs() < 1e-6);
        assert!((c[1] - 22.0).abs() < 1e-6);
        assert!((c[2] - 43.0).abs() < 1e-6);
        assert!((c[3] - 50.0).abs() < 1e-6);
    }
    
    #[test]
    fn test_scalar_dot() {
        let x = vec![1.0, 2.0, 3.0];
        let y = vec![4.0, 5.0, 6.0];
        
        let result = dot_scalar(&x, &y).unwrap();
        assert!((result - 32.0).abs() < 1e-6); // 1*4 + 2*5 + 3*6 = 32
    }
}