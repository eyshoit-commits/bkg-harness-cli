pub mod common;
pub mod scalar;

#[cfg(feature = "simd-avx2")]
pub mod avx2;

#[cfg(feature = "simd-neon")]
pub mod neon;

use crate::core::{Error, Result};
use crate::simd::common::{GemmParams, PackedMatrix};

/// Main GEMM dispatch function
pub fn gemm(
    m: usize,
    n: usize,
    k: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    b: &[f32],
    ldb: usize,
    beta: f32,
    c: &mut [f32],
    ldc: usize,
) -> Result<()> {
    let params = GemmParams::new(m, n, k, alpha, beta, lda, ldb, ldc);
    
    // Validate input dimensions
    if a.len() < m * lda || b.len() < k * ldb || c.len() < m * ldc {
        return Err(Error::simd("Invalid matrix dimensions".to_string()));
    }
    
    // Choose the best available implementation
    #[cfg(feature = "simd-avx2")]
    {
        if is_x86_feature_detected!("avx2") {
            return avx2::gemm_avx2(&params, a, b, c);
        }
    }
    
    #[cfg(feature = "simd-neon")]
    {
        if std::arch::is_aarch64_feature_detected!("neon") {
            return neon::gemm_neon(&params, a, b, c);
        }
    }
    
    // Fallback to scalar implementation
    scalar::gemm_scalar(&params, a, b, c)
}

/// Optimized matrix multiplication for common cases
pub fn matmul(a: &[f32], b: &[f32], c: &mut [f32], m: usize, n: usize, k: usize) -> Result<()> {
    gemm(m, n, k, 1.0, a, k, b, n, 0.0, c, n)
}

/// Matrix-vector multiplication
pub fn matvec(a: &[f32], x: &[f32], y: &mut [f32], m: usize, n: usize) -> Result<()> {
    gemm(m, 1, n, 1.0, a, n, x, 1, 0.0, y, 1)
}

/// Vector dot product
pub fn dot(a: &[f32], b: &[f32]) -> Result<f32> {
    if a.len() != b.len() {
        return Err(Error::simd("Vector length mismatch".to_string()));
    }
    
    let mut result = vec![0.0f32];
    gemm(1, 1, a.len(), 1.0, a, a.len(), b, 1, 0.0, &mut result, 1)?;
    Ok(result[0])
}

/// Check if SIMD is available on current platform
pub fn is_simd_available() -> bool {
    #[cfg(feature = "simd-avx2")]
    {
        if is_x86_feature_detected!("avx2") {
            return true;
        }
    }
    
    #[cfg(feature = "simd-neon")]
    {
        if std::arch::is_aarch64_feature_detected!("neon") {
            return true;
        }
    }
    
    false
}

/// Get the name of the active SIMD implementation
pub fn active_simd_impl() -> &'static str {
    #[cfg(feature = "simd-avx2")]
    {
        if is_x86_feature_detected!("avx2") {
            return "AVX2";
        }
    }
    
    #[cfg(feature = "simd-neon")]
    {
        if std::arch::is_aarch64_feature_detected!("neon") {
            return "NEON";
        }
    }
    
    "Scalar"
}