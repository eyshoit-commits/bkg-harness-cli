#[cfg(feature = "simd-avx2")]
use std::arch::x86_64::*;

use crate::core::Result;
use crate::simd::common::{GemmParams, AVX2_BLOCK_SIZE};

/// AVX2 optimized GEMM implementation
#[cfg(feature = "simd-avx2")]
pub fn gemm_avx2(
    params: &GemmParams,
    a: &[f32],
    b: &[f32],
    c: &mut [f32],
) -> Result<()> {
    params.validate()?;
    
    let GemmParams { m, n, k, alpha, beta, lda, ldb, ldc } = *params;
    
    // Apply beta scaling to C if needed
    if beta != 1.0 {
        unsafe {
            scale_matrix_avx2(c, m, n, ldc, beta);
        }
    }
    
    // Blocked GEMM with AVX2 micro-kernels
    for ii in (0..m).step_by(AVX2_BLOCK_SIZE) {
        for jj in (0..n).step_by(AVX2_BLOCK_SIZE) {
            for kk in (0..k).step_by(AVX2_BLOCK_SIZE) {
                let end_i = (ii + AVX2_BLOCK_SIZE).min(m);
                let end_j = (jj + AVX2_BLOCK_SIZE).min(n);
                let end_k = (kk + AVX2_BLOCK_SIZE).min(k);
                
                unsafe {
                    gemm_micro_kernel_avx2(
                        ii, end_i, jj, end_j, kk, end_k,
                        alpha, a, lda, b, ldb, c, ldc,
                    );
                }
            }
        }
    }
    
    Ok(())
}

#[cfg(feature = "simd-avx2")]
#[target_feature(enable = "avx2")]
unsafe fn scale_matrix_avx2(
    matrix: &mut [f32],
    rows: usize,
    cols: usize,
    ld: usize,
    scale: f32,
) {
    let scale_vec = _mm256_set1_ps(scale);
    
    for i in 0..rows {
        let row_start = i * ld;
        let mut j = 0;
        
        // Process 8 elements at a time with AVX2
        while j + 8 <= cols {
            let idx = row_start + j;
            if idx + 8 <= matrix.len() {
                let data = _mm256_loadu_ps(matrix.as_ptr().add(idx));
                let scaled = _mm256_mul_ps(data, scale_vec);
                _mm256_storeu_ps(matrix.as_mut_ptr().add(idx), scaled);
            }
            j += 8;
        }
        
        // Handle remaining elements
        while j < cols {
            let idx = row_start + j;
            if idx < matrix.len() {
                matrix[idx] *= scale;
            }
            j += 1;
        }
    }
}

#[cfg(feature = "simd-avx2")]
#[target_feature(enable = "avx2")]
unsafe fn gemm_micro_kernel_avx2(
    start_i: usize,
    end_i: usize,
    start_j: usize,
    end_j: usize,
    start_k: usize,
    end_k: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    b: &[f32],
    ldb: usize,
    c: &mut [f32],
    ldc: usize,
) {
    let alpha_vec = _mm256_set1_ps(alpha);
    
    for i in start_i..end_i {
        let mut j = start_j;
        
        // Process 8 columns at a time
        while j + 8 <= end_j {
            let mut sum_vec = _mm256_setzero_ps();
            
            for k in start_k..end_k {
                let a_val = if i * lda + k < a.len() { a[i * lda + k] } else { 0.0 };
                let a_vec = _mm256_set1_ps(a_val);
                
                let b_idx = k * ldb + j;
                if b_idx + 8 <= b.len() {
                    let b_vec = _mm256_loadu_ps(b.as_ptr().add(b_idx));
                    sum_vec = _mm256_fmadd_ps(a_vec, b_vec, sum_vec);
                }
            }
            
            // Scale by alpha and add to C
            let scaled_sum = _mm256_mul_ps(sum_vec, alpha_vec);
            let c_idx = i * ldc + j;
            
            if c_idx + 8 <= c.len() {
                let c_vec = _mm256_loadu_ps(c.as_ptr().add(c_idx));
                let result = _mm256_add_ps(c_vec, scaled_sum);
                _mm256_storeu_ps(c.as_mut_ptr().add(c_idx), result);
            }
            
            j += 8;
        }
        
        // Handle remaining columns with scalar code
        while j < end_j {
            let mut sum = 0.0f32;
            
            for k in start_k..end_k {
                let a_idx = i * lda + k;
                let b_idx = k * ldb + j;
                
                if a_idx < a.len() && b_idx < b.len() {
                    sum += a[a_idx] * b[b_idx];
                }
            }
            
            let c_idx = i * ldc + j;
            if c_idx < c.len() {
                c[c_idx] += alpha * sum;
            }
            
            j += 1;
        }
    }
}

/// AVX2 optimized matrix-vector multiplication
#[cfg(feature = "simd-avx2")]
pub fn gemv_avx2(
    m: usize,
    n: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    x: &[f32],
    beta: f32,
    y: &mut [f32],
) -> Result<()> {
    if a.len() < m * lda || x.len() < n || y.len() < m {
        return Err(crate::core::Error::simd("Invalid dimensions for AVX2 GEMV".to_string()));
    }
    
    unsafe {
        gemv_avx2_impl(m, n, alpha, a, lda, x, beta, y);
    }
    
    Ok(())
}

#[cfg(feature = "simd-avx2")]
#[target_feature(enable = "avx2")]
unsafe fn gemv_avx2_impl(
    m: usize,
    n: usize,
    alpha: f32,
    a: &[f32],
    lda: usize,
    x: &[f32],
    beta: f32,
    y: &mut [f32],
) {
    let alpha_vec = _mm256_set1_ps(alpha);
    let beta_vec = _mm256_set1_ps(beta);
    
    for i in 0..m {
        let mut sum_vec = _mm256_setzero_ps();
        let mut j = 0;
        
        // Process 8 elements at a time
        while j + 8 <= n {
            let a_idx = i * lda + j;
            if a_idx + 8 <= a.len() && j + 8 <= x.len() {
                let a_vec = _mm256_loadu_ps(a.as_ptr().add(a_idx));
                let x_vec = _mm256_loadu_ps(x.as_ptr().add(j));
                sum_vec = _mm256_fmadd_ps(a_vec, x_vec, sum_vec);
            }
            j += 8;
        }
        
        // Horizontal sum of sum_vec
        let sum_high = _mm256_extractf128_ps(sum_vec, 1);
        let sum_low = _mm256_castps256_ps128(sum_vec);
        let sum_quad = _mm_add_ps(sum_low, sum_high);
        let sum_dual = _mm_hadd_ps(sum_quad, sum_quad);
        let sum_single = _mm_hadd_ps(sum_dual, sum_dual);
        let mut sum = _mm_cvtss_f32(sum_single);
        
        // Handle remaining elements
        while j < n {
            let a_idx = i * lda + j;
            if a_idx < a.len() {
                sum += a[a_idx] * x[j];
            }
            j += 1;
        }
        
        // Update y[i]
        y[i] = beta * y[i] + alpha * sum;
    }
}

#[cfg(not(feature = "simd-avx2"))]
pub fn gemm_avx2(
    _params: &GemmParams,
    _a: &[f32],
    _b: &[f32],
    _c: &mut [f32],
) -> Result<()> {
    Err(crate::core::Error::simd("AVX2 support not enabled".to_string()))
}

#[cfg(not(feature = "simd-avx2"))]
pub fn gemv_avx2(
    _m: usize,
    _n: usize,
    _alpha: f32,
    _a: &[f32],
    _lda: usize,
    _x: &[f32],
    _beta: f32,
    _y: &mut [f32],
) -> Result<()> {
    Err(crate::core::Error::simd("AVX2 support not enabled".to_string()))
}