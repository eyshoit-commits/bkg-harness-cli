use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use tokio::sync::RwLock;
use chrono::{DateTime, Utc};

use crate::core::{Error, Result};

pub type PipelineTask = Box<dyn Fn() -> Pin<Box<dyn Future<Output = Result<serde_json::Value>> + Send>> + Send + Sync>;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PipelineStep {
    pub id: String,
    pub name: String,
    pub description: String,
    pub dependencies: Vec<String>,
    pub timeout_seconds: Option<u64>,
    pub retry_count: u32,
    pub required: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PipelineExecution {
    pub id: String,
    pub pipeline_id: String,
    pub started_at: DateTime<Utc>,
    pub completed_at: Option<DateTime<Utc>>,
    pub status: ExecutionStatus,
    pub step_results: HashMap<String, StepResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ExecutionStatus {
    Pending,
    Running,
    Completed,
    Failed(String),
    Cancelled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StepResult {
    pub step_id: String,
    pub status: StepStatus,
    pub started_at: DateTime<Utc>,
    pub completed_at: Option<DateTime<Utc>>,
    pub output: Option<serde_json::Value>,
    pub error: Option<String>,
    pub retry_count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum StepStatus {
    Pending,
    Running,
    Completed,
    Failed,
    Skipped,
}

pub struct Pipeline {
    pub id: String,
    pub name: String,
    pub description: String,
    pub steps: Vec<PipelineStep>,
    pub tasks: HashMap<String, PipelineTask>,
    pub executions: Arc<RwLock<HashMap<String, PipelineExecution>>>,
}

impl Pipeline {
    pub fn new(id: String, name: String, description: String) -> Self {
        Self {
            id,
            name,
            description,
            steps: Vec::new(),
            tasks: HashMap::new(),
            executions: Arc::new(RwLock::new(HashMap::new())),
        }
    }
    
    pub fn add_step(&mut self, step: PipelineStep) -> &mut Self {
        self.steps.push(step);
        self
    }
    
    pub fn add_task<F, Fut>(&mut self, step_id: String, task: F) -> &mut Self
    where
        F: Fn() -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<serde_json::Value>> + Send + 'static,
    {
        let boxed_task = Box::new(move || Box::pin(task()) as Pin<Box<dyn Future<Output = Result<serde_json::Value>> + Send>>);
        self.tasks.insert(step_id, boxed_task);
        self
    }
    
    pub async fn execute(&self) -> Result<PipelineExecution> {
        let execution_id = uuid::Uuid::new_v4().to_string();
        let mut execution = PipelineExecution {
            id: execution_id.clone(),
            pipeline_id: self.id.clone(),
            started_at: Utc::now(),
            completed_at: None,
            status: ExecutionStatus::Running,
            step_results: HashMap::new(),
        };
        
        // Store execution
        {
            let mut executions = self.executions.write().await;
            executions.insert(execution_id.clone(), execution.clone());
        }
        
        // Build dependency graph
        let dependency_graph = self.build_dependency_graph()?;
        
        // Execute steps in topological order
        let execution_order = self.topological_sort(&dependency_graph)?;
        
        for step_id in execution_order {
            let step = self.steps.iter()
                .find(|s| s.id == step_id)
                .ok_or_else(|| Error::internal(format!("Step {} not found", step_id)))?;
            
            let step_result = self.execute_step(step, &execution.step_results).await;
            execution.step_results.insert(step_id.clone(), step_result.clone());
            
            // Update execution in storage
            {
                let mut executions = self.executions.write().await;
                if let Some(stored_execution) = executions.get_mut(&execution_id) {
                    stored_execution.step_results = execution.step_results.clone();
                }
            }
            
            // Check if step failed and is required
            if matches!(step_result.status, StepStatus::Failed) && step.required {
                execution.status = ExecutionStatus::Failed(
                    step_result.error.unwrap_or_else(|| "Step failed".to_string())
                );
                break;
            }
        }
        
        // Finalize execution
        execution.completed_at = Some(Utc::now());
        if matches!(execution.status, ExecutionStatus::Running) {
            execution.status = ExecutionStatus::Completed;
        }
        
        // Update final execution state
        {
            let mut executions = self.executions.write().await;
            executions.insert(execution_id, execution.clone());
        }
        
        Ok(execution)
    }
    
    async fn execute_step(
        &self,
        step: &PipelineStep,
        previous_results: &HashMap<String, StepResult>,
    ) -> StepResult {
        let mut result = StepResult {
            step_id: step.id.clone(),
            status: StepStatus::Running,
            started_at: Utc::now(),
            completed_at: None,
            output: None,
            error: None,
            retry_count: 0,
        };
        
        // Check dependencies
        for dep_id in &step.dependencies {
            if let Some(dep_result) = previous_results.get(dep_id) {
                if matches!(dep_result.status, StepStatus::Failed) {
                    result.status = StepStatus::Skipped;
                    result.error = Some(format!("Dependency {} failed", dep_id));
                    result.completed_at = Some(Utc::now());
                    return result;
                }
            } else {
                result.status = StepStatus::Failed;
                result.error = Some(format!("Dependency {} not found", dep_id));
                result.completed_at = Some(Utc::now());
                return result;
            }
        }
        
        // Execute task with retries
        let task = match self.tasks.get(&step.id) {
            Some(task) => task,
            None => {
                result.status = StepStatus::Failed;
                result.error = Some("No task defined for step".to_string());
                result.completed_at = Some(Utc::now());
                return result;
            }
        };
        
        for attempt in 0..=step.retry_count {
            result.retry_count = attempt;
            
            let task_result = if let Some(timeout) = step.timeout_seconds {
                // Execute with timeout
                match tokio::time::timeout(
                    std::time::Duration::from_secs(timeout),
                    task()
                ).await {
                    Ok(task_result) => task_result,
                    Err(_) => Err(Error::internal("Task timed out".to_string())),
                }
            } else {
                // Execute without timeout
                task().await
            };
            
            match task_result {
                Ok(output) => {
                    result.status = StepStatus::Completed;
                    result.output = Some(output);
                    break;
                }
                Err(e) => {
                    if attempt == step.retry_count {
                        result.status = StepStatus::Failed;
                        result.error = Some(e.to_string());
                    } else {
                        // Wait before retry
                        tokio::time::sleep(std::time::Duration::from_millis(
                            1000 * (attempt + 1) as u64
                        )).await;
                    }
                }
            }
        }
        
        result.completed_at = Some(Utc::now());
        result
    }
    
    fn build_dependency_graph(&self) -> Result<HashMap<String, Vec<String>>> {
        let mut graph = HashMap::new();
        
        for step in &self.steps {
            graph.insert(step.id.clone(), step.dependencies.clone());
        }
        
        // Validate that all dependencies exist
        for step in &self.steps {
            for dep in &step.dependencies {
                if !graph.contains_key(dep) {
                    return Err(Error::internal(format!(
                        "Step {} depends on non-existent step {}",
                        step.id, dep
                    )));
                }
            }
        }
        
        Ok(graph)
    }
    
    fn topological_sort(&self, graph: &HashMap<String, Vec<String>>) -> Result<Vec<String>> {
        let mut visited = std::collections::HashSet::new();
        let mut temp_visited = std::collections::HashSet::new();
        let mut result = Vec::new();
        
        fn visit(
            node: &str,
            graph: &HashMap<String, Vec<String>>,
            visited: &mut std::collections::HashSet<String>,
            temp_visited: &mut std::collections::HashSet<String>,
            result: &mut Vec<String>,
        ) -> Result<()> {
            if temp_visited.contains(node) {
                return Err(Error::internal("Circular dependency detected".to_string()));
            }
            
            if visited.contains(node) {
                return Ok(());
            }
            
            temp_visited.insert(node.to_string());
            
            if let Some(dependencies) = graph.get(node) {
                for dep in dependencies {
                    visit(dep, graph, visited, temp_visited, result)?;
                }
            }
            
            temp_visited.remove(node);
            visited.insert(node.to_string());
            result.push(node.to_string());
            
            Ok(())
        }
        
        for node in graph.keys() {
            if !visited.contains(node) {
                visit(node, graph, &mut visited, &mut temp_visited, &mut result)?;
            }
        }
        
        Ok(result)
    }
    
    pub async fn get_execution(&self, execution_id: &str) -> Option<PipelineExecution> {
        let executions = self.executions.read().await;
        executions.get(execution_id).cloned()
    }
    
    pub async fn list_executions(&self) -> Vec<PipelineExecution> {
        let executions = self.executions.read().await;
        executions.values().cloned().collect()
    }
    
    pub async fn cancel_execution(&self, execution_id: &str) -> Result<()> {
        let mut executions = self.executions.write().await;
        if let Some(execution) = executions.get_mut(execution_id) {
            execution.status = ExecutionStatus::Cancelled;
            execution.completed_at = Some(Utc::now());
        }
        Ok(())
    }
}

/// Predefined pipeline templates
pub mod templates {
    use super::*;
    
    pub fn model_reload_pipeline() -> Pipeline {
        let mut pipeline = Pipeline::new(
            "model_reload".to_string(),
            "Model Reload".to_string(),
            "Safely reload model with validation".to_string(),
        );
        
        pipeline
            .add_step(PipelineStep {
                id: "backup_config".to_string(),
                name: "Backup Configuration".to_string(),
                description: "Create backup of current configuration".to_string(),
                dependencies: vec![],
                timeout_seconds: Some(30),
                retry_count: 2,
                required: true,
            })
            .add_step(PipelineStep {
                id: "unload_model".to_string(),
                name: "Unload Current Model".to_string(),
                description: "Safely unload the current model".to_string(),
                dependencies: vec!["backup_config".to_string()],
                timeout_seconds: Some(60),
                retry_count: 1,
                required: true,
            })
            .add_step(PipelineStep {
                id: "load_model".to_string(),
                name: "Load New Model".to_string(),
                description: "Load and initialize the new model".to_string(),
                dependencies: vec!["unload_model".to_string()],
                timeout_seconds: Some(300),
                retry_count: 2,
                required: true,
            })
            .add_step(PipelineStep {
                id: "smoke_test".to_string(),
                name: "Smoke Test".to_string(),
                description: "Run basic inference test".to_string(),
                dependencies: vec!["load_model".to_string()],
                timeout_seconds: Some(60),
                retry_count: 1,
                required: false,
            });
        
        pipeline
    }
    
    pub fn cache_clear_pipeline() -> Pipeline {
        let mut pipeline = Pipeline::new(
            "cache_clear".to_string(),
            "Cache Clear".to_string(),
            "Clear all caches and temporary data".to_string(),
        );
        
        pipeline
            .add_step(PipelineStep {
                id: "clear_kv_cache".to_string(),
                name: "Clear KV Cache".to_string(),
                description: "Clear key-value cache".to_string(),
                dependencies: vec![],
                timeout_seconds: Some(10),
                retry_count: 1,
                required: true,
            })
            .add_step(PipelineStep {
                id: "clear_temp_files".to_string(),
                name: "Clear Temporary Files".to_string(),
                description: "Remove temporary files".to_string(),
                dependencies: vec![],
                timeout_seconds: Some(30),
                retry_count: 2,
                required: false,
            })
            .add_step(PipelineStep {
                id: "gc_collect".to_string(),
                name: "Garbage Collection".to_string(),
                description: "Force garbage collection".to_string(),
                dependencies: vec!["clear_kv_cache".to_string(), "clear_temp_files".to_string()],
                timeout_seconds: Some(30),
                retry_count: 1,
                required: false,
            });
        
        pipeline
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[tokio::test]
    async fn test_pipeline_execution() {
        let mut pipeline = Pipeline::new(
            "test".to_string(),
            "Test Pipeline".to_string(),
            "Test pipeline".to_string(),
        );
        
        pipeline
            .add_step(PipelineStep {
                id: "step1".to_string(),
                name: "Step 1".to_string(),
                description: "First step".to_string(),
                dependencies: vec![],
                timeout_seconds: Some(5),
                retry_count: 1,
                required: true,
            })
            .add_task("step1".to_string(), || async {
                Ok(serde_json::json!({"result": "step1_complete"}))
            });
        
        let execution = pipeline.execute().await.unwrap();
        assert!(matches!(execution.status, ExecutionStatus::Completed));
        assert_eq!(execution.step_results.len(), 1);
    }
    
    #[test]
    fn test_dependency_graph() {
        let pipeline = Pipeline::new(
            "test".to_string(),
            "Test".to_string(),
            "Test".to_string(),
        );
        
        let mut graph = HashMap::new();
        graph.insert("a".to_string(), vec!["b".to_string()]);
        graph.insert("b".to_string(), vec!["c".to_string()]);
        graph.insert("c".to_string(), vec![]);
        
        let order = pipeline.topological_sort(&graph).unwrap();
        
        // c should come before b, b should come before a
        let c_pos = order.iter().position(|x| x == "c").unwrap();
        let b_pos = order.iter().position(|x| x == "b").unwrap();
        let a_pos = order.iter().position(|x| x == "a").unwrap();
        
        assert!(c_pos < b_pos);
        assert!(b_pos < a_pos);
    }
}