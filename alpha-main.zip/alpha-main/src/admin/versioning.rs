use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use chrono::{DateTime, Utc};

use crate::core::{Error, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Version {
    pub id: String,
    pub name: String,
    pub description: String,
    pub created_at: DateTime<Utc>,
    pub config_path: PathBuf,
    pub model_path: Option<PathBuf>,
    pub is_active: bool,
    pub checksum: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Channel {
    pub name: String,
    pub description: String,
    pub current_version: Option<String>,
    pub versions: Vec<String>,
}

pub struct VersionManager {
    base_path: PathBuf,
    channels: HashMap<String, Channel>,
    versions: HashMap<String, Version>,
}

impl VersionManager {
    pub fn new(base_path: impl AsRef<Path>) -> Result<Self> {
        let base_path = base_path.as_ref().to_path_buf();
        std::fs::create_dir_all(&base_path)?;
        
        Ok(Self {
            base_path,
            channels: HashMap::new(),
            versions: HashMap::new(),
        })
    }
    
    pub fn create_version(
        &mut self,
        name: String,
        description: String,
        config_path: PathBuf,
        model_path: Option<PathBuf>,
    ) -> Result<Version> {
        let id = uuid::Uuid::new_v4().to_string();
        let checksum = self.calculate_checksum(&config_path, &model_path)?;
        
        let version = Version {
            id: id.clone(),
            name,
            description,
            created_at: Utc::now(),
            config_path,
            model_path,
            is_active: false,
            checksum,
        };
        
        self.versions.insert(id.clone(), version.clone());
        self.save_version(&version)?;
        
        Ok(version)
    }
    
    pub fn create_channel(&mut self, name: String, description: String) -> Result<()> {
        let channel = Channel {
            name: name.clone(),
            description,
            current_version: None,
            versions: Vec::new(),
        };
        
        self.channels.insert(name, channel);
        Ok(())
    }
    
    pub fn switch_version(&mut self, channel: &str, version_id: &str) -> Result<()> {
        // Validate version exists
        if !self.versions.contains_key(version_id) {
            return Err(Error::internal(format!("Version {} not found", version_id)));
        }
        
        // Get or create channel
        let channel = self.channels.entry(channel.to_string())
            .or_insert_with(|| Channel {
                name: channel.to_string(),
                description: format!("Auto-created channel: {}", channel),
                current_version: None,
                versions: Vec::new(),
            });
        
        // Deactivate current version if any
        if let Some(current_id) = &channel.current_version {
            if let Some(current_version) = self.versions.get_mut(current_id) {
                current_version.is_active = false;
            }
        }
        
        // Activate new version
        channel.current_version = Some(version_id.to_string());
        if let Some(version) = self.versions.get_mut(version_id) {
            version.is_active = true;
        }
        
        // Add to channel versions if not already there
        if !channel.versions.contains(&version_id.to_string()) {
            channel.versions.push(version_id.to_string());
        }
        
        self.create_symlinks(channel, version_id)?;
        
        Ok(())
    }
    
    pub fn rollback(&mut self, channel: &str) -> Result<Option<String>> {
        let channel = self.channels.get(channel)
            .ok_or_else(|| Error::internal(format!("Channel {} not found", channel)))?;
        
        // Find previous version
        if let Some(current_id) = &channel.current_version {
            if let Some(current_idx) = channel.versions.iter().position(|v| v == current_id) {
                if current_idx > 0 {
                    let previous_id = &channel.versions[current_idx - 1];
                    let channel_name = channel.name.clone();
                    self.switch_version(&channel_name, previous_id)?;
                    return Ok(Some(previous_id.clone()));
                }
            }
        }
        
        Ok(None)
    }
    
    pub fn list_versions(&self) -> Vec<&Version> {
        self.versions.values().collect()
    }
    
    pub fn list_channels(&self) -> Vec<&Channel> {
        self.channels.values().collect()
    }
    
    pub fn get_active_version(&self, channel: &str) -> Option<&Version> {
        self.channels.get(channel)
            .and_then(|c| c.current_version.as_ref())
            .and_then(|id| self.versions.get(id))
    }
    
    fn calculate_checksum(&self, config_path: &Path, model_path: &Option<PathBuf>) -> Result<String> {
        use sha2::{Sha256, Digest};
        
        let mut hasher = Sha256::new();
        
        // Hash config file
        if config_path.exists() {
            let config_data = std::fs::read(config_path)?;
            hasher.update(&config_data);
        }
        
        // Hash model file if present
        if let Some(model_path) = model_path {
            if model_path.exists() {
                // For large model files, just hash metadata
                let metadata = std::fs::metadata(model_path)?;
                hasher.update(model_path.to_string_lossy().as_bytes());
                hasher.update(&metadata.len().to_le_bytes());
                hasher.update(&metadata.modified()?.duration_since(std::time::UNIX_EPOCH).unwrap().as_secs().to_le_bytes());
            }
        }
        
        Ok(format!("{:x}", hasher.finalize()))
    }
    
    fn save_version(&self, version: &Version) -> Result<()> {
        let version_dir = self.base_path.join("versions").join(&version.id);
        std::fs::create_dir_all(&version_dir)?;
        
        let version_file = version_dir.join("version.json");
        let content = serde_json::to_string_pretty(version)?;
        std::fs::write(version_file, content)?;
        
        Ok(())
    }
    
    fn create_symlinks(&self, channel: &Channel, version_id: &str) -> Result<()> {
        let version = self.versions.get(version_id)
            .ok_or_else(|| Error::internal(format!("Version {} not found", version_id)))?;
        
        let channel_dir = self.base_path.join("channels").join(&channel.name);
        std::fs::create_dir_all(&channel_dir)?;
        
        // Create symlink to config
        let config_link = channel_dir.join("config.toml");
        if config_link.exists() {
            std::fs::remove_file(&config_link)?;
        }
        
        #[cfg(unix)]
        {
            use std::os::unix::fs::symlink;
            symlink(&version.config_path, &config_link)?;
        }
        
        #[cfg(windows)]
        {
            use std::os::windows::fs::symlink_file;
            symlink_file(&version.config_path, &config_link)?;
        }
        
        // Create symlink to model if present
        if let Some(model_path) = &version.model_path {
            let model_link = channel_dir.join("model.gguf");
            if model_link.exists() {
                std::fs::remove_file(&model_link)?;
            }
            
            #[cfg(unix)]
            {
                use std::os::unix::fs::symlink;
                symlink(model_path, &model_link)?;
            }
            
            #[cfg(windows)]
            {
                use std::os::windows::fs::symlink_file;
                symlink_file(model_path, &model_link)?;
            }
        }
        
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;
    
    #[test]
    fn test_version_creation() {
        let temp_dir = TempDir::new().unwrap();
        let mut vm = VersionManager::new(temp_dir.path()).unwrap();
        
        let version = vm.create_version(
            "test-v1".to_string(),
            "Test version".to_string(),
            temp_dir.path().join("config.toml"),
            None,
        ).unwrap();
        
        assert_eq!(version.name, "test-v1");
        assert!(!version.is_active);
    }
    
    #[test]
    fn test_channel_switching() {
        let temp_dir = TempDir::new().unwrap();
        let mut vm = VersionManager::new(temp_dir.path()).unwrap();
        
        let version = vm.create_version(
            "test-v1".to_string(),
            "Test version".to_string(),
            temp_dir.path().join("config.toml"),
            None,
        ).unwrap();
        
        vm.create_channel("stable".to_string(), "Stable channel".to_string()).unwrap();
        vm.switch_version("stable", &version.id).unwrap();
        
        let active = vm.get_active_version("stable").unwrap();
        assert_eq!(active.id, version.id);
        assert!(active.is_active);
    }
}