use crate::core::{Error, Result};
use crate::tensor::{TensorView, DType, Shape};

pub trait TensorOps {
    fn add(&self, other: &TensorView) -> Result<Vec<f32>>;
    fn mul(&self, other: &TensorView) -> Result<Vec<f32>>;
    fn matmul(&self, other: &TensorView) -> Result<Vec<f32>>;
    fn softmax(&self, dim: usize) -> Result<Vec<f32>>;
    fn layer_norm(&self, weight: &TensorView, bias: Option<&TensorView>, eps: f32) -> Result<Vec<f32>>;
    fn gelu(&self) -> Result<Vec<f32>>;
    fn silu(&self) -> Result<Vec<f32>>;
    fn relu(&self) -> Result<Vec<f32>>;
}

impl TensorOps for TensorView {
    fn add(&self, other: &TensorView) -> Result<Vec<f32>> {
        let broadcast_shape = self.shape.broadcast_with(&other.shape)?;
        let mut result = vec![0.0f32; broadcast_shape.size()];
        
        let self_data = self.as_f32_slice()?;
        let other_data = other.as_f32_slice()?;
        
        // Simple element-wise addition for same shapes
        if self.shape == other.shape {
            for i in 0..result.len() {
                result[i] = self_data[i] + other_data[i];
            }
        } else {
            // TODO: Implement proper broadcasting
            return Err(Error::tensor("Broadcasting not yet implemented".to_string()));
        }
        
        Ok(result)
    }
    
    fn mul(&self, other: &TensorView) -> Result<Vec<f32>> {
        let broadcast_shape = self.shape.broadcast_with(&other.shape)?;
        let mut result = vec![0.0f32; broadcast_shape.size()];
        
        let self_data = self.as_f32_slice()?;
        let other_data = other.as_f32_slice()?;
        
        // Simple element-wise multiplication for same shapes
        if self.shape == other.shape {
            for i in 0..result.len() {
                result[i] = self_data[i] * other_data[i];
            }
        } else {
            // TODO: Implement proper broadcasting
            return Err(Error::tensor("Broadcasting not yet implemented".to_string()));
        }
        
        Ok(result)
    }
    
    fn matmul(&self, other: &TensorView) -> Result<Vec<f32>> {
        if !self.shape.is_matrix() || !other.shape.is_matrix() {
            return Err(Error::tensor("Matrix multiplication requires 2D tensors".to_string()));
        }
        
        let [m, k] = [self.shape.dims[0], self.shape.dims[1]];
        let [k2, n] = [other.shape.dims[0], other.shape.dims[1]];
        
        if k != k2 {
            return Err(Error::tensor(format!(
                "Matrix dimension mismatch: {}x{} * {}x{}",
                m, k, k2, n
            )));
        }
        
        let mut result = vec![0.0f32; m * n];
        let self_data = self.as_f32_slice()?;
        let other_data = other.as_f32_slice()?;
        
        // Basic matrix multiplication (will be replaced with SIMD GEMM)
        for i in 0..m {
            for j in 0..n {
                let mut sum = 0.0f32;
                for k_idx in 0..k {
                    sum += self_data[i * k + k_idx] * other_data[k_idx * n + j];
                }
                result[i * n + j] = sum;
            }
        }
        
        Ok(result)
    }
    
    fn softmax(&self, dim: usize) -> Result<Vec<f32>> {
        if dim >= self.shape.rank() {
            return Err(Error::tensor(format!(
                "Softmax dimension {} out of bounds for tensor with {} dimensions",
                dim, self.shape.rank()
            )));
        }
        
        let data = self.as_f32_slice()?;
        let mut result = vec![0.0f32; data.len()];
        
        // For now, implement 1D softmax
        if self.shape.rank() == 1 {
            let max_val = data.iter().fold(f32::NEG_INFINITY, |a, &b| a.max(b));
            let mut sum = 0.0f32;
            
            for (i, &val) in data.iter().enumerate() {
                let exp_val = (val - max_val).exp();
                result[i] = exp_val;
                sum += exp_val;
            }
            
            for val in result.iter_mut() {
                *val /= sum;
            }
        } else {
            // TODO: Implement multi-dimensional softmax
            return Err(Error::tensor("Multi-dimensional softmax not yet implemented".to_string()));
        }
        
        Ok(result)
    }
    
    fn layer_norm(&self, weight: &TensorView, bias: Option<&TensorView>, eps: f32) -> Result<Vec<f32>> {
        let data = self.as_f32_slice()?;
        let weight_data = weight.as_f32_slice()?;
        let bias_data = if let Some(b) = bias {
            Some(b.as_f32_slice()?)
        } else {
            None
        };
        
        let mut result = vec![0.0f32; data.len()];
        
        // Simple layer normalization
        let mean = data.iter().sum::<f32>() / data.len() as f32;
        let variance = data.iter()
            .map(|x| (x - mean).powi(2))
            .sum::<f32>() / data.len() as f32;
        
        let std_dev = (variance + eps).sqrt();
        
        for (i, &val) in data.iter().enumerate() {
            let normalized = (val - mean) / std_dev;
            let weight_idx = i % weight_data.len();
            result[i] = normalized * weight_data[weight_idx];
            
            if let Some(bias) = bias_data {
                let bias_idx = i % bias.len();
                result[i] += bias[bias_idx];
            }
        }
        
        Ok(result)
    }
    
    fn gelu(&self) -> Result<Vec<f32>> {
        let data = self.as_f32_slice()?;
        let result = data.iter()
            .map(|&x| {
                // GELU approximation: 0.5 * x * (1 + tanh(sqrt(2/π) * (x + 0.044715 * x^3)))
                let sqrt_2_over_pi = 0.7978845608f32;
                let inner = sqrt_2_over_pi * (x + 0.044715f32 * x.powi(3));
                0.5f32 * x * (1.0f32 + inner.tanh())
            })
            .collect();
        
        Ok(result)
    }
    
    fn silu(&self) -> Result<Vec<f32>> {
        let data = self.as_f32_slice()?;
        let result = data.iter()
            .map(|&x| x / (1.0f32 + (-x).exp()))
            .collect();
        
        Ok(result)
    }
    
    fn relu(&self) -> Result<Vec<f32>> {
        let data = self.as_f32_slice()?;
        let result = data.iter()
            .map(|&x| x.max(0.0f32))
            .collect();
        
        Ok(result)
    }
}