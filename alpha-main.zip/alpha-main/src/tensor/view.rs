use std::sync::Arc;
use memmap2::Mmap;

use crate::core::{Error, Result};
use crate::tensor::{DType, Shape};

/// Zero-copy tensor view backed by memory-mapped data
#[derive(Debug)]
pub struct TensorView {
    pub name: String,
    pub dtype: DType,
    pub shape: Shape,
    pub data: Arc<Mmap>,
    pub offset: usize,
    pub stride: Vec<usize>,
}

impl TensorView {
    pub fn new(
        name: String,
        dtype: DType,
        shape: Shape,
        data: Arc<Mmap>,
        offset: usize,
    ) -> Self {
        let stride = Self::compute_stride(&shape);
        Self {
            name,
            dtype,
            shape,
            data,
            offset,
            stride,
        }
    }
    
    fn compute_stride(shape: &Shape) -> Vec<usize> {
        let mut stride = vec![1; shape.dims.len()];
        for i in (0..shape.dims.len().saturating_sub(1)).rev() {
            stride[i] = stride[i + 1] * shape.dims[i + 1];
        }
        stride
    }
    
    pub fn size_in_bytes(&self) -> usize {
        self.shape.size() * self.dtype.size_in_bytes()
    }
    
    pub fn data_slice(&self) -> &[u8] {
        let start = self.offset;
        let end = start + self.size_in_bytes();
        &self.data[start..end.min(self.data.len())]
    }
    
    pub fn as_f32_slice(&self) -> Result<&[f32]> {
        if self.dtype != DType::F32 {
            return Err(Error::tensor(format!(
                "Cannot view {} tensor as f32", 
                self.dtype.name()
            )));
        }
        
        let data = self.data_slice();
        if data.len() % 4 != 0 {
            return Err(Error::tensor("Invalid f32 tensor alignment".to_string()));
        }
        
        let ptr = data.as_ptr() as *const f32;
        let len = data.len() / 4;
        Ok(unsafe { std::slice::from_raw_parts(ptr, len) })
    }
    
    pub fn as_f16_slice(&self) -> Result<&[half::f16]> {
        if self.dtype != DType::F16 {
            return Err(Error::tensor(format!(
                "Cannot view {} tensor as f16", 
                self.dtype.name()
            )));
        }
        
        let data = self.data_slice();
        if data.len() % 2 != 0 {
            return Err(Error::tensor("Invalid f16 tensor alignment".to_string()));
        }
        
        let ptr = data.as_ptr() as *const half::f16;
        let len = data.len() / 2;
        Ok(unsafe { std::slice::from_raw_parts(ptr, len) })
    }
    
    pub fn as_i32_slice(&self) -> Result<&[i32]> {
        if self.dtype != DType::I32 {
            return Err(Error::tensor(format!(
                "Cannot view {} tensor as i32", 
                self.dtype.name()
            )));
        }
        
        let data = self.data_slice();
        if data.len() % 4 != 0 {
            return Err(Error::tensor("Invalid i32 tensor alignment".to_string()));
        }
        
        let ptr = data.as_ptr() as *const i32;
        let len = data.len() / 4;
        Ok(unsafe { std::slice::from_raw_parts(ptr, len) })
    }
    
    pub fn get_linear_index(&self, indices: &[usize]) -> Result<usize> {
        if indices.len() != self.shape.dims.len() {
            return Err(Error::tensor(format!(
                "Index dimension mismatch: expected {}, got {}",
                self.shape.dims.len(),
                indices.len()
            )));
        }
        
        let mut linear_index = 0;
        for (i, &idx) in indices.iter().enumerate() {
            if idx >= self.shape.dims[i] {
                return Err(Error::tensor(format!(
                    "Index {} out of bounds for dimension {} (size {})",
                    idx, i, self.shape.dims[i]
                )));
            }
            linear_index += idx * self.stride[i];
        }
        
        Ok(linear_index)
    }
    
    pub fn slice(&self, ranges: &[(usize, usize)]) -> Result<TensorView> {
        if ranges.len() != self.shape.dims.len() {
            return Err(Error::tensor("Slice dimension mismatch".to_string()));
        }
        
        let mut new_shape_dims = Vec::new();
        let mut offset_adjustment = 0;
        
        for (i, &(start, end)) in ranges.iter().enumerate() {
            if start >= end || end > self.shape.dims[i] {
                return Err(Error::tensor(format!(
                    "Invalid slice range [{}, {}) for dimension {} (size {})",
                    start, end, i, self.shape.dims[i]
                )));
            }
            
            new_shape_dims.push(end - start);
            offset_adjustment += start * self.stride[i] * self.dtype.size_in_bytes();
        }
        
        Ok(TensorView {
            name: format!("{}[slice]", self.name),
            dtype: self.dtype,
            shape: Shape::new(new_shape_dims),
            data: Arc::clone(&self.data),
            offset: self.offset + offset_adjustment,
            stride: self.stride.clone(),
        })
    }
    
    pub fn reshape(&self, new_shape: Shape) -> Result<TensorView> {
        if new_shape.size() != self.shape.size() {
            return Err(Error::tensor(format!(
                "Cannot reshape tensor of size {} to size {}",
                self.shape.size(),
                new_shape.size()
            )));
        }
        
        Ok(TensorView {
            name: format!("{}[reshaped]", self.name),
            dtype: self.dtype,
            shape: new_shape,
            data: Arc::clone(&self.data),
            offset: self.offset,
            stride: Self::compute_stride(&self.shape),
        })
    }
    
    pub fn is_contiguous(&self) -> bool {
        let expected_stride = Self::compute_stride(&self.shape);
        self.stride == expected_stride
    }
}