pub mod view;
pub mod ops;
pub mod dtype;

pub use dtype::DType;
pub use view::TensorView;
pub use ops::TensorOps;

use crate::core::{Error, Result};

#[derive(Debug, Clone, PartialEq)]
pub struct Shape {
    pub dims: Vec<usize>,
}

impl Shape {
    pub fn new(dims: Vec<usize>) -> Self {
        Self { dims }
    }
    
    pub fn rank(&self) -> usize {
        self.dims.len()
    }
    
    pub fn size(&self) -> usize {
        self.dims.iter().product()
    }
    
    pub fn is_scalar(&self) -> bool {
        self.dims.is_empty() || (self.dims.len() == 1 && self.dims[0] == 1)
    }
    
    pub fn is_vector(&self) -> bool {
        self.dims.len() == 1
    }
    
    pub fn is_matrix(&self) -> bool {
        self.dims.len() == 2
    }
    
    pub fn broadcast_with(&self, other: &Shape) -> Result<Shape> {
        let max_rank = self.rank().max(other.rank());
        let mut result_dims = vec![1; max_rank];
        
        for i in 0..max_rank {
            let self_dim = if i < self.rank() {
                self.dims[self.rank() - 1 - i]
            } else {
                1
            };
            
            let other_dim = if i < other.rank() {
                other.dims[other.rank() - 1 - i]
            } else {
                1
            };
            
            if self_dim == other_dim {
                result_dims[max_rank - 1 - i] = self_dim;
            } else if self_dim == 1 {
                result_dims[max_rank - 1 - i] = other_dim;
            } else if other_dim == 1 {
                result_dims[max_rank - 1 - i] = self_dim;
            } else {
                return Err(Error::tensor(format!(
                    "Cannot broadcast shapes {:?} and {:?}",
                    self.dims, other.dims
                )));
            }
        }
        
        Ok(Shape::new(result_dims))
    }
}

impl From<Vec<usize>> for Shape {
    fn from(dims: Vec<usize>) -> Self {
        Self::new(dims)
    }
}

impl From<&[usize]> for Shape {
    fn from(dims: &[usize]) -> Self {
        Self::new(dims.to_vec())
    }
}