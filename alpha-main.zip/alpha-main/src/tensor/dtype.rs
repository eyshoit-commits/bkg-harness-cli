use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DType {
    F32,
    F16,
    BF16,
    I32,
    I16,
    I8,
    U32,
    U16,
    U8,
    Bool,
    // Quantized types
    Q4_0,
    Q4_1,
    Q5_0,
    Q5_1,
    Q8_0,
    Q8_1,
    Q2_K,
    Q3_K,
    Q4_K,
    Q5_K,
    Q6_K,
    Q8_K,
}

impl DType {
    pub fn size_in_bytes(self) -> usize {
        match self {
            DType::F32 | DType::I32 | DType::U32 => 4,
            DType::F16 | DType::BF16 | DType::I16 | DType::U16 => 2,
            DType::I8 | DType::U8 | DType::Bool => 1,
            // Quantized types - approximate sizes
            DType::Q4_0 | DType::Q4_1 => 1, // 4 bits per weight + overhead
            DType::Q5_0 | DType::Q5_1 => 1, // 5 bits per weight + overhead
            DType::Q8_0 | DType::Q8_1 => 1, // 8 bits per weight + overhead
            DType::Q2_K => 1, // 2 bits per weight + overhead
            DType::Q3_K => 1, // 3 bits per weight + overhead
            DType::Q4_K => 1, // 4 bits per weight + overhead
            DType::Q5_K => 1, // 5 bits per weight + overhead
            DType::Q6_K => 1, // 6 bits per weight + overhead
            DType::Q8_K => 1, // 8 bits per weight + overhead
        }
    }
    
    pub fn is_quantized(self) -> bool {
        matches!(self, 
            DType::Q4_0 | DType::Q4_1 | DType::Q5_0 | DType::Q5_1 |
            DType::Q8_0 | DType::Q8_1 | DType::Q2_K | DType::Q3_K |
            DType::Q4_K | DType::Q5_K | DType::Q6_K | DType::Q8_K
        )
    }
    
    pub fn is_float(self) -> bool {
        matches!(self, DType::F32 | DType::F16 | DType::BF16)
    }
    
    pub fn is_integer(self) -> bool {
        matches!(self, 
            DType::I32 | DType::I16 | DType::I8 |
            DType::U32 | DType::U16 | DType::U8
        )
    }
    
    pub fn name(self) -> &'static str {
        match self {
            DType::F32 => "f32",
            DType::F16 => "f16",
            DType::BF16 => "bf16",
            DType::I32 => "i32",
            DType::I16 => "i16",
            DType::I8 => "i8",
            DType::U32 => "u32",
            DType::U16 => "u16",
            DType::U8 => "u8",
            DType::Bool => "bool",
            DType::Q4_0 => "q4_0",
            DType::Q4_1 => "q4_1",
            DType::Q5_0 => "q5_0",
            DType::Q5_1 => "q5_1",
            DType::Q8_0 => "q8_0",
            DType::Q8_1 => "q8_1",
            DType::Q2_K => "q2_k",
            DType::Q3_K => "q3_k",
            DType::Q4_K => "q4_k",
            DType::Q5_K => "q5_k",
            DType::Q6_K => "q6_k",
            DType::Q8_K => "q8_k",
        }
    }
}

impl From<u32> for DType {
    fn from(value: u32) -> Self {
        match value {
            0 => DType::F32,
            1 => DType::F16,
            2 => DType::Q4_0,
            3 => DType::Q4_1,
            6 => DType::Q5_0,
            7 => DType::Q5_1,
            8 => DType::Q8_0,
            9 => DType::Q8_1,
            10 => DType::Q2_K,
            11 => DType::Q3_K,
            12 => DType::Q4_K,
            13 => DType::Q5_K,
            14 => DType::Q6_K,
            15 => DType::Q8_K,
            16 => DType::I8,
            17 => DType::I16,
            18 => DType::I32,
            19 => DType::BF16,
            _ => DType::F32, // Default fallback
        }
    }
}

impl From<DType> for u32 {
    fn from(dtype: DType) -> Self {
        match dtype {
            DType::F32 => 0,
            DType::F16 => 1,
            DType::Q4_0 => 2,
            DType::Q4_1 => 3,
            DType::Q5_0 => 6,
            DType::Q5_1 => 7,
            DType::Q8_0 => 8,
            DType::Q8_1 => 9,
            DType::Q2_K => 10,
            DType::Q3_K => 11,
            DType::Q4_K => 12,
            DType::Q5_K => 13,
            DType::Q6_K => 14,
            DType::Q8_K => 15,
            DType::I8 => 16,
            DType::I16 => 17,
            DType::I32 => 18,
            DType::BF16 => 19,
            _ => 0, // Default fallback
        }
    }
}