use serde::{Deserialize, Serialize};
use tracing::debug;

use crate::core::{Error, Result};
use crate::tensor::{TensorView, TensorOps};
use crate::simd;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MlpConfig {
    pub hidden_size: usize,
    pub intermediate_size: usize,
    pub activation: String, // "silu", "gelu", "relu"
}

pub struct MlpLayer {
    config: MlpConfig,
    gate_proj: TensorView,
    up_proj: TensorView,
    down_proj: TensorView,
}

impl MlpLayer {
    pub fn new(
        config: MlpConfig,
        gate_proj: TensorView,
        up_proj: TensorView,
        down_proj: TensorView,
    ) -> Result<Self> {
        // Validate tensor shapes
        if gate_proj.shape.dims != [config.intermediate_size, config.hidden_size] {
            return Err(Error::engine(format!(
                "Gate projection shape mismatch: expected [{}, {}], got {:?}",
                config.intermediate_size, config.hidden_size, gate_proj.shape.dims
            )));
        }
        
        if up_proj.shape.dims != [config.intermediate_size, config.hidden_size] {
            return Err(Error::engine(format!(
                "Up projection shape mismatch: expected [{}, {}], got {:?}",
                config.intermediate_size, config.hidden_size, up_proj.shape.dims
            )));
        }
        
        if down_proj.shape.dims != [config.hidden_size, config.intermediate_size] {
            return Err(Error::engine(format!(
                "Down projection shape mismatch: expected [{}, {}], got {:?}",
                config.hidden_size, config.intermediate_size, down_proj.shape.dims
            )));
        }
        
        Ok(Self {
            config,
            gate_proj,
            up_proj,
            down_proj,
        })
    }
    
    pub fn forward(&self, hidden_states: &[f32]) -> Result<Vec<f32>> {
        let seq_len = hidden_states.len() / self.config.hidden_size;
        
        debug!("MLP forward: seq_len={}, activation={}", seq_len, self.config.activation);
        
        // Gate projection: hidden_states @ gate_proj^T
        let gate_output = self.linear_projection(hidden_states, &self.gate_proj)?;
        
        // Up projection: hidden_states @ up_proj^T  
        let up_output = self.linear_projection(hidden_states, &self.up_proj)?;
        
        // Apply activation to gate output
        let activated_gate = self.apply_activation(&gate_output)?;
        
        // Element-wise multiplication: activated_gate * up_output
        let mut intermediate = vec![0.0f32; activated_gate.len()];
        for i in 0..intermediate.len() {
            intermediate[i] = activated_gate[i] * up_output[i];
        }
        
        // Down projection: intermediate @ down_proj^T
        let output = self.linear_projection(&intermediate, &self.down_proj)?;
        
        Ok(output)
    }
    
    fn linear_projection(&self, input: &[f32], weight: &TensorView) -> Result<Vec<f32>> {
        let weight_data = weight.as_f32_slice()?;
        let input_size = weight.shape.dims[1]; // Second dimension is input size
        let output_size = weight.shape.dims[0]; // First dimension is output size
        let seq_len = input.len() / input_size;
        
        let mut result = vec![0.0f32; seq_len * output_size];
        
        // Use SIMD GEMM for matrix multiplication
        // Note: weight is stored in row-major format, so we need to transpose
        simd::gemm(
            seq_len,     // m
            output_size, // n
            input_size,  // k
            1.0,         // alpha
            input,       // a
            input_size,  // lda
            weight_data, // b (transposed)
            output_size, // ldb
            0.0,         // beta
            &mut result, // c
            output_size, // ldc
        )?;
        
        Ok(result)
    }
    
    fn apply_activation(&self, input: &[f32]) -> Result<Vec<f32>> {
        match self.config.activation.as_str() {
            "silu" | "swish" => Ok(self.silu(input)),
            "gelu" => Ok(self.gelu(input)),
            "relu" => Ok(self.relu(input)),
            "tanh" => Ok(self.tanh(input)),
            _ => Err(Error::engine(format!(
                "Unsupported activation function: {}",
                self.config.activation
            ))),
        }
    }
    
    fn silu(&self, input: &[f32]) -> Vec<f32> {
        input.iter()
            .map(|&x| x / (1.0 + (-x).exp()))
            .collect()
    }
    
    fn gelu(&self, input: &[f32]) -> Vec<f32> {
        input.iter()
            .map(|&x| {
                // GELU approximation: 0.5 * x * (1 + tanh(sqrt(2/π) * (x + 0.044715 * x^3)))
                let sqrt_2_over_pi = 0.7978845608f32;
                let inner = sqrt_2_over_pi * (x + 0.044715f32 * x.powi(3));
                0.5f32 * x * (1.0f32 + inner.tanh())
            })
            .collect()
    }
    
    fn relu(&self, input: &[f32]) -> Vec<f32> {
        input.iter()
            .map(|&x| x.max(0.0))
            .collect()
    }
    
    fn tanh(&self, input: &[f32]) -> Vec<f32> {
        input.iter()
            .map(|&x| x.tanh())
            .collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::tensor::{Shape, DType};
    use std::sync::Arc;
    use memmap2::Mmap;
    
    fn create_dummy_tensor(shape: Vec<usize>, data: Vec<f32>) -> TensorView {
        let data_bytes: Vec<u8> = data.iter()
            .flat_map(|&f| f.to_le_bytes().to_vec())
            .collect();
        
        // Create a dummy mmap (this is just for testing)
        let mmap = Arc::new(unsafe { 
            Mmap::map(&std::fs::File::open("/dev/zero").unwrap()).unwrap() 
        });
        
        TensorView::new(
            "test".to_string(),
            DType::F32,
            Shape::new(shape),
            mmap,
            0,
        )
    }
    
    #[test]
    fn test_silu_activation() {
        let config = MlpConfig {
            hidden_size: 2,
            intermediate_size: 4,
            activation: "silu".to_string(),
        };
        
        // Create dummy tensors
        let gate_proj = create_dummy_tensor(vec![4, 2], vec![1.0, 0.5, -0.5, 1.0, 0.0, -1.0, 1.5, -0.5]);
        let up_proj = create_dummy_tensor(vec![4, 2], vec![0.5, 1.0, 1.0, -0.5, -1.0, 0.0, -0.5, 1.5]);
        let down_proj = create_dummy_tensor(vec![2, 4], vec![1.0, -1.0, 0.5, 0.0, 0.0, 0.5, -1.0, 1.0]);
        
        let mlp = MlpLayer::new(config, gate_proj, up_proj, down_proj).unwrap();
        
        // Test SiLU function directly
        let input = vec![0.0, 1.0, -1.0, 2.0];
        let output = mlp.silu(&input);
        
        // SiLU(0) = 0, SiLU(1) ≈ 0.731, SiLU(-1) ≈ -0.269, SiLU(2) ≈ 1.761
        assert!((output[0] - 0.0).abs() < 1e-3);
        assert!((output[1] - 0.731).abs() < 1e-2);
        assert!((output[2] - (-0.269)).abs() < 1e-2);
        assert!((output[3] - 1.761).abs() < 1e-2);
    }
    
    #[test]
    fn test_gelu_activation() {
        let config = MlpConfig {
            hidden_size: 2,
            intermediate_size: 4,
            activation: "gelu".to_string(),
        };
        
        let gate_proj = create_dummy_tensor(vec![4, 2], vec![1.0; 8]);
        let up_proj = create_dummy_tensor(vec![4, 2], vec![1.0; 8]);
        let down_proj = create_dummy_tensor(vec![2, 4], vec![1.0; 8]);
        
        let mlp = MlpLayer::new(config, gate_proj, up_proj, down_proj).unwrap();
        
        // Test GELU function directly
        let input = vec![0.0, 1.0, -1.0];
        let output = mlp.gelu(&input);
        
        // GELU(0) = 0, GELU(1) ≈ 0.841, GELU(-1) ≈ -0.159
        assert!((output[0] - 0.0).abs() < 1e-3);
        assert!((output[1] - 0.841).abs() < 1e-2);
        assert!((output[2] - (-0.159)).abs() < 1e-2);
    }
}