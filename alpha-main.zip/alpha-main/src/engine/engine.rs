use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use tracing::{debug, info, warn};

use crate::core::{Error, Result};
use crate::loader::GgufLoader;
use crate::tensor::{TensorView, TensorOps};
use crate::engine::{AttentionLayer, AttentionConfig, MlpLayer, MlpConfig, KvCache, Sampler, SamplingConfig};
use crate::simd;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelConfig {
    pub vocab_size: usize,
    pub hidden_size: usize,
    pub intermediate_size: usize,
    pub num_hidden_layers: usize,
    pub num_attention_heads: usize,
    pub num_key_value_heads: Option<usize>,
    pub max_position_embeddings: usize,
    pub rope_theta: f32,
    pub rms_norm_eps: f32,
    pub use_cache: bool,
}

impl Default for ModelConfig {
    fn default() -> Self {
        Self {
            vocab_size: 32000,
            hidden_size: 4096,
            intermediate_size: 11008,
            num_hidden_layers: 32,
            num_attention_heads: 32,
            num_key_value_heads: None,
            max_position_embeddings: 2048,
            rope_theta: 10000.0,
            rms_norm_eps: 1e-6,
            use_cache: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceConfig {
    pub max_new_tokens: usize,
    pub do_sample: bool,
    pub temperature: f32,
    pub top_k: Option<usize>,
    pub top_p: Option<f32>,
    pub repetition_penalty: f32,
    pub stop_sequences: Vec<String>,
    pub pad_token_id: Option<u32>,
    pub eos_token_id: Option<u32>,
}

impl Default for InferenceConfig {
    fn default() -> Self {
        Self {
            max_new_tokens: 512,
            do_sample: true,
            temperature: 0.7,
            top_k: Some(50),
            top_p: Some(0.95),
            repetition_penalty: 1.1,
            stop_sequences: vec![],
            pad_token_id: None,
            eos_token_id: Some(2),
        }
    }
}

pub struct TransformerEngine {
    model_config: ModelConfig,
    loader: GgufLoader,
    
    // Model layers
    embed_tokens: Option<TensorView>,
    layers: Vec<TransformerLayer>,
    norm: Option<TensorView>,
    lm_head: Option<TensorView>,
    
    // Caches and state
    kv_cache: KvCache,
    scratch_buffer: Vec<f32>,
    
    // Sampler
    sampler: Sampler,
}

struct TransformerLayer {
    attention: AttentionLayer,
    mlp: MlpLayer,
    input_layernorm: Option<TensorView>,
    post_attention_layernorm: Option<TensorView>,
}

impl TransformerEngine {
    pub fn new(loader: GgufLoader, inference_config: InferenceConfig) -> Result<Self> {
        info!("🔧 Initializing TransformerEngine");
        
        // Extract model configuration from GGUF metadata
        let model_config = Self::extract_model_config(&loader)?;
        info!("📊 Model config: {} layers, {} heads, vocab_size: {}", 
              model_config.num_hidden_layers, 
              model_config.num_attention_heads,
              model_config.vocab_size);
        
        // Load embedding layer
        let embed_tokens = loader.get_tensor("token_embd.weight").ok();
        if embed_tokens.is_none() {
            warn!("⚠️  Embedding layer not found, will use identity mapping");
        }
        
        // Load transformer layers
        let mut layers = Vec::new();
        for layer_idx in 0..model_config.num_hidden_layers {
            debug!("Loading layer {}/{}", layer_idx + 1, model_config.num_hidden_layers);
            
            let attention_config = AttentionConfig {
                hidden_size: model_config.hidden_size,
                num_heads: model_config.num_attention_heads,
                num_key_value_heads: model_config.num_key_value_heads.unwrap_or(model_config.num_attention_heads),
                head_dim: model_config.hidden_size / model_config.num_attention_heads,
                rope_theta: model_config.rope_theta,
                max_position_embeddings: model_config.max_position_embeddings,
            };
            
            let mlp_config = MlpConfig {
                hidden_size: model_config.hidden_size,
                intermediate_size: model_config.intermediate_size,
                activation: "silu".to_string(),
            };
            
            let layer = Self::load_transformer_layer(&loader, layer_idx, attention_config, mlp_config)?;
            layers.push(layer);
        }
        
        // Load normalization and output layers
        let norm = loader.get_tensor("output_norm.weight").ok();
        let lm_head = loader.get_tensor("output.weight").ok();
        
        if lm_head.is_none() {
            warn!("⚠️  Language model head not found");
        }
        
        // Initialize KV cache
        let kv_cache = KvCache::new(
            model_config.num_hidden_layers,
            model_config.num_key_value_heads.unwrap_or(model_config.num_attention_heads),
            model_config.hidden_size / model_config.num_attention_heads,
            model_config.max_position_embeddings,
        );
        
        // Initialize scratch buffer
        let scratch_size = model_config.hidden_size * 4; // Conservative estimate
        let scratch_buffer = vec![0.0f32; scratch_size];
        
        // Initialize sampler
        let sampling_config = SamplingConfig {
            temperature: inference_config.temperature,
            top_k: inference_config.top_k,
            top_p: inference_config.top_p,
            repetition_penalty: inference_config.repetition_penalty,
            pad_token_id: inference_config.pad_token_id,
            eos_token_id: inference_config.eos_token_id,
        };
        
        let sampler = Sampler::new(sampling_config);
        
        info!("✅ TransformerEngine initialized successfully");
        Ok(Self {
            model_config,
            loader,
            embed_tokens,
            layers,
            norm,
            lm_head,
            kv_cache,
            scratch_buffer,
            sampler,
        })
    }
    
    fn extract_model_config(loader: &GgufLoader) -> Result<ModelConfig> {
        let mut config = ModelConfig::default();
        
        // Extract common parameters from GGUF metadata
        if let Some(vocab_size) = loader.get_metadata_u32("llama.vocab_size") {
            config.vocab_size = vocab_size as usize;
        }
        
        if let Some(hidden_size) = loader.get_metadata_u32("llama.embedding_length") {
            config.hidden_size = hidden_size as usize;
        }
        
        if let Some(intermediate_size) = loader.get_metadata_u32("llama.feed_forward_length") {
            config.intermediate_size = intermediate_size as usize;
        }
        
        if let Some(num_layers) = loader.get_metadata_u32("llama.block_count") {
            config.num_hidden_layers = num_layers as usize;
        }
        
        if let Some(num_heads) = loader.get_metadata_u32("llama.attention.head_count") {
            config.num_attention_heads = num_heads as usize;
        }
        
        if let Some(num_kv_heads) = loader.get_metadata_u32("llama.attention.head_count_kv") {
            config.num_key_value_heads = Some(num_kv_heads as usize);
        }
        
        if let Some(max_pos) = loader.get_metadata_u32("llama.context_length") {
            config.max_position_embeddings = max_pos as usize;
        }
        
        if let Some(rope_theta) = loader.get_metadata_f32("llama.rope.freq_base") {
            config.rope_theta = rope_theta;
        }
        
        if let Some(norm_eps) = loader.get_metadata_f32("llama.attention.layer_norm_rms_epsilon") {
            config.rms_norm_eps = norm_eps;
        }
        
        Ok(config)
    }
    
    fn load_transformer_layer(
        loader: &GgufLoader,
        layer_idx: usize,
        attention_config: AttentionConfig,
        mlp_config: MlpConfig,
    ) -> Result<TransformerLayer> {
        // Load attention weights
        let q_proj = loader.get_tensor(&format!("blk.{}.attn_q.weight", layer_idx))?;
        let k_proj = loader.get_tensor(&format!("blk.{}.attn_k.weight", layer_idx))?;
        let v_proj = loader.get_tensor(&format!("blk.{}.attn_v.weight", layer_idx))?;
        let o_proj = loader.get_tensor(&format!("blk.{}.attn_output.weight", layer_idx))?;
        
        let attention = AttentionLayer::new(attention_config, q_proj, k_proj, v_proj, o_proj)?;
        
        // Load MLP weights
        let gate_proj = loader.get_tensor(&format!("blk.{}.ffn_gate.weight", layer_idx))?;
        let up_proj = loader.get_tensor(&format!("blk.{}.ffn_up.weight", layer_idx))?;
        let down_proj = loader.get_tensor(&format!("blk.{}.ffn_down.weight", layer_idx))?;
        
        let mlp = MlpLayer::new(mlp_config, gate_proj, up_proj, down_proj)?;
        
        // Load layer normalization weights
        let input_layernorm = loader.get_tensor(&format!("blk.{}.attn_norm.weight", layer_idx)).ok();
        let post_attention_layernorm = loader.get_tensor(&format!("blk.{}.ffn_norm.weight", layer_idx)).ok();
        
        Ok(TransformerLayer {
            attention,
            mlp,
            input_layernorm,
            post_attention_layernorm,
        })
    }
    
    pub fn forward(&mut self, input_ids: &[u32], position_ids: Option<&[usize]>) -> Result<Vec<f32>> {
        let seq_len = input_ids.len();
        let batch_size = 1; // Currently only support batch_size = 1
        
        debug!("🔄 Forward pass: seq_len={}, batch_size={}", seq_len, batch_size);
        
        // Embedding lookup
        let mut hidden_states = if let Some(embed_tokens) = &self.embed_tokens {
            self.embed_lookup(input_ids, embed_tokens)?
        } else {
            // Identity mapping for testing
            vec![1.0f32; seq_len * self.model_config.hidden_size]
        };
        
        // Process through transformer layers
        for (layer_idx, layer) in self.layers.iter().enumerate() {
            debug!("Processing layer {}/{}", layer_idx + 1, self.layers.len());
            
            // Input layer normalization
            if let Some(norm_weight) = &layer.input_layernorm {
                hidden_states = self.rms_norm(&hidden_states, norm_weight)?;
            }
            
            // Self-attention
            let attention_output = layer.attention.forward(
                &hidden_states,
                position_ids,
                &mut self.kv_cache,
                layer_idx,
            )?;
            
            // Residual connection
            for (h, a) in hidden_states.iter_mut().zip(attention_output.iter()) {
                *h += a;
            }
            
            // Post-attention layer normalization  
            let normalized_states = if let Some(norm_weight) = &layer.post_attention_layernorm {
                self.rms_norm(&hidden_states, norm_weight)?
            } else {
                hidden_states.clone()
            };
            
            // MLP
            let mlp_output = layer.mlp.forward(&normalized_states)?;
            
            // Residual connection
            for (h, m) in hidden_states.iter_mut().zip(mlp_output.iter()) {
                *h += m;
            }
        }
        
        // Final layer normalization
        if let Some(norm_weight) = &self.norm {
            hidden_states = self.rms_norm(&hidden_states, norm_weight)?;
        }
        
        // Language model head
        let logits = if let Some(lm_head) = &self.lm_head {
            self.linear(&hidden_states, lm_head)?
        } else {
            // Return hidden states as logits for testing
            hidden_states
        };
        
        Ok(logits)
    }
    
    pub fn generate(
        &mut self,
        input_ids: &[u32],
        max_new_tokens: usize,
    ) -> Result<Vec<u32>> {
        let mut generated_tokens = Vec::new();
        let mut current_input = input_ids.to_vec();
        
        info!("🎯 Starting generation: max_new_tokens={}", max_new_tokens);
        
        for step in 0..max_new_tokens {
            debug!("Generation step {}/{}", step + 1, max_new_tokens);
            
            // Forward pass
            let logits = self.forward(&current_input, None)?;
            
            // Extract logits for the last token
            let last_token_logits = &logits[logits.len() - self.model_config.vocab_size..];
            
            // Sample next token
            let next_token = self.sampler.sample(last_token_logits, &generated_tokens)?;
            
            // Check for EOS token
            if let Some(eos_token_id) = self.sampler.config.eos_token_id {
                if next_token == eos_token_id {
                    debug!("🛑 EOS token encountered, stopping generation");
                    break;
                }
            }
            
            generated_tokens.push(next_token);
            current_input = vec![next_token]; // Only process the new token for next iteration
            
            debug!("Generated token: {}", next_token);
        }
        
        info!("✅ Generation complete: {} tokens generated", generated_tokens.len());
        Ok(generated_tokens)
    }
    
    fn embed_lookup(&self, input_ids: &[u32], embed_tokens: &TensorView) -> Result<Vec<f32>> {
        let seq_len = input_ids.len();
        let hidden_size = self.model_config.hidden_size;
        let mut result = vec![0.0f32; seq_len * hidden_size];
        
        let embed_data = embed_tokens.as_f32_slice()?;
        
        for (i, &token_id) in input_ids.iter().enumerate() {
            let token_id = token_id as usize;
            if token_id >= self.model_config.vocab_size {
                return Err(Error::engine(format!(
                    "Token ID {} out of vocabulary range", token_id
                )));
            }
            
            let embed_start = token_id * hidden_size;
            let result_start = i * hidden_size;
            
            for j in 0..hidden_size {
                if embed_start + j < embed_data.len() {
                    result[result_start + j] = embed_data[embed_start + j];
                }
            }
        }
        
        Ok(result)
    }
    
    fn rms_norm(&self, input: &[f32], weight: &TensorView) -> Result<Vec<f32>> {
        let weight_data = weight.as_f32_slice()?;
        let hidden_size = self.model_config.hidden_size;
        let seq_len = input.len() / hidden_size;
        let mut result = vec![0.0f32; input.len()];
        
        for i in 0..seq_len {
            let start = i * hidden_size;
            let end = start + hidden_size;
            let slice = &input[start..end];
            
            // Compute RMS
            let mean_square = slice.iter().map(|x| x * x).sum::<f32>() / hidden_size as f32;
            let rms = (mean_square + self.model_config.rms_norm_eps).sqrt();
            
            // Normalize and apply weight
            for j in 0..hidden_size {
                let weight_idx = j % weight_data.len();
                result[start + j] = (slice[j] / rms) * weight_data[weight_idx];
            }
        }
        
        Ok(result)
    }
    
    fn linear(&self, input: &[f32], weight: &TensorView) -> Result<Vec<f32>> {
        let weight_data = weight.as_f32_slice()?;
        let hidden_size = self.model_config.hidden_size;
        let output_size = self.model_config.vocab_size;
        let seq_len = input.len() / hidden_size;
        
        let mut result = vec![0.0f32; seq_len * output_size];
        
        // Use SIMD GEMM for matrix multiplication
        simd::gemm(
            seq_len,    // m
            output_size, // n  
            hidden_size, // k
            1.0,        // alpha
            input,      // a
            hidden_size, // lda
            weight_data, // b
            output_size, // ldb
            0.0,        // beta
            &mut result, // c
            output_size, // ldc
        )?;
        
        Ok(result)
    }
    
    pub fn model_config(&self) -> &ModelConfig {
        &self.model_config
    }
    
    pub fn clear_cache(&mut self) {
        self.kv_cache.clear();
    }
    
    pub fn cache_size(&self) -> usize {
        self.kv_cache.size()
    }
}