use crate::core::{Error, Result};

/// Key-Value cache for transformer attention layers
pub struct KvCache {
    /// Key cache: [num_layers, max_seq_len, num_kv_heads, head_dim]
    key_cache: Vec<Vec<f32>>,
    /// Value cache: [num_layers, max_seq_len, num_kv_heads, head_dim]  
    value_cache: Vec<Vec<f32>>,
    /// Current sequence length for each layer
    seq_lengths: Vec<usize>,
    /// Configuration
    num_layers: usize,
    num_kv_heads: usize,
    head_dim: usize,
    max_seq_len: usize,
}

impl KvCache {
    pub fn new(
        num_layers: usize,
        num_kv_heads: usize,
        head_dim: usize,
        max_seq_len: usize,
    ) -> Self {
        let cache_size_per_layer = max_seq_len * num_kv_heads * head_dim;
        
        let key_cache = vec![vec![0.0f32; cache_size_per_layer]; num_layers];
        let value_cache = vec![vec![0.0f32; cache_size_per_layer]; num_layers];
        let seq_lengths = vec![0; num_layers];
        
        Self {
            key_cache,
            value_cache,
            seq_lengths,
            num_layers,
            num_kv_heads,
            head_dim,
            max_seq_len,
        }
    }
    
    /// Update cache with new key and value states
    pub fn update(
        &mut self,
        layer_idx: usize,
        new_key_states: Vec<f32>,
        new_value_states: Vec<f32>,
    ) -> Result<(Vec<f32>, Vec<f32>)> {
        if layer_idx >= self.num_layers {
            return Err(Error::engine(format!(
                "Layer index {} out of bounds (max: {})",
                layer_idx, self.num_layers - 1
            )));
        }
        
        let new_seq_len = new_key_states.len() / (self.num_kv_heads * self.head_dim);
        let current_seq_len = self.seq_lengths[layer_idx];
        let total_seq_len = current_seq_len + new_seq_len;
        
        if total_seq_len > self.max_seq_len {
            return Err(Error::engine(format!(
                "Sequence length {} exceeds maximum cache size {}",
                total_seq_len, self.max_seq_len
            )));
        }
        
        // Append new states to cache
        let key_cache = &mut self.key_cache[layer_idx];
        let value_cache = &mut self.value_cache[layer_idx];
        
        let insert_offset = current_seq_len * self.num_kv_heads * self.head_dim;
        let new_states_size = new_seq_len * self.num_kv_heads * self.head_dim;
        
        // Copy new key states
        if insert_offset + new_states_size <= key_cache.len() {
            key_cache[insert_offset..insert_offset + new_states_size]
                .copy_from_slice(&new_key_states[..new_states_size]);
        }
        
        // Copy new value states
        if insert_offset + new_states_size <= value_cache.len() {
            value_cache[insert_offset..insert_offset + new_states_size]
                .copy_from_slice(&new_value_states[..new_states_size]);
        }
        
        // Update sequence length
        self.seq_lengths[layer_idx] = total_seq_len;
        
        // Return all cached states for this layer
        let cached_key_size = total_seq_len * self.num_kv_heads * self.head_dim;
        let cached_value_size = total_seq_len * self.num_kv_heads * self.head_dim;
        
        let all_key_states = key_cache[..cached_key_size].to_vec();
        let all_value_states = value_cache[..cached_value_size].to_vec();
        
        Ok((all_key_states, all_value_states))
    }
    
    /// Get cached states for a layer
    pub fn get(&self, layer_idx: usize) -> Result<(Vec<f32>, Vec<f32>)> {
        if layer_idx >= self.num_layers {
            return Err(Error::engine(format!(
                "Layer index {} out of bounds (max: {})",
                layer_idx, self.num_layers - 1
            )));
        }
        
        let seq_len = self.seq_lengths[layer_idx];
        let cache_size = seq_len * self.num_kv_heads * self.head_dim;
        
        let key_states = self.key_cache[layer_idx][..cache_size].to_vec();
        let value_states = self.value_cache[layer_idx][..cache_size].to_vec();
        
        Ok((key_states, value_states))
    }
    
    /// Clear cache for all layers
    pub fn clear(&mut self) {
        for layer_cache in &mut self.key_cache {
            layer_cache.fill(0.0);
        }
        for layer_cache in &mut self.value_cache {
            layer_cache.fill(0.0);
        }
        self.seq_lengths.fill(0);
    }
    
    /// Clear cache for a specific layer
    pub fn clear_layer(&mut self, layer_idx: usize) -> Result<()> {
        if layer_idx >= self.num_layers {
            return Err(Error::engine(format!(
                "Layer index {} out of bounds (max: {})",
                layer_idx, self.num_layers - 1
            )));
        }
        
        self.key_cache[layer_idx].fill(0.0);
        self.value_cache[layer_idx].fill(0.0);
        self.seq_lengths[layer_idx] = 0;
        
        Ok(())
    }
    
    /// Get current sequence length for a layer
    pub fn sequence_length(&self, layer_idx: usize) -> Option<usize> {
        if layer_idx < self.num_layers {
            Some(self.seq_lengths[layer_idx])
        } else {
            None
        }
    }
    
    /// Get total memory usage in bytes
    pub fn size(&self) -> usize {
        let cache_size_per_layer = self.max_seq_len * self.num_kv_heads * self.head_dim;
        // Key cache + Value cache, each element is 4 bytes (f32)
        self.num_layers * cache_size_per_layer * 2 * 4
    }
    
    /// Get memory usage for a specific layer in bytes
    pub fn layer_size(&self, layer_idx: usize) -> Option<usize> {
        if layer_idx < self.num_layers {
            let seq_len = self.seq_lengths[layer_idx];
            let used_size = seq_len * self.num_kv_heads * self.head_dim;
            // Key cache + Value cache, each element is 4 bytes (f32)
            Some(used_size * 2 * 4)
        } else {
            None
        }
    }
    
    /// Check if cache is full for a layer
    pub fn is_full(&self, layer_idx: usize) -> bool {
        if layer_idx < self.num_layers {
            self.seq_lengths[layer_idx] >= self.max_seq_len
        } else {
            false
        }
    }
    
    /// Get remaining capacity for a layer
    pub fn remaining_capacity(&self, layer_idx: usize) -> Option<usize> {
        if layer_idx < self.num_layers {
            Some(self.max_seq_len - self.seq_lengths[layer_idx])
        } else {
            None
        }
    }
    
    /// Resize cache (useful for dynamic sequence lengths)
    pub fn resize(&mut self, new_max_seq_len: usize) -> Result<()> {
        if new_max_seq_len == self.max_seq_len {
            return Ok(());
        }
        
        let new_cache_size_per_layer = new_max_seq_len * self.num_kv_heads * self.head_dim;
        
        // Resize key and value caches
        for layer_idx in 0..self.num_layers {
            let old_seq_len = self.seq_lengths[layer_idx];
            
            if new_max_seq_len < old_seq_len {
                // Truncate if new size is smaller
                self.seq_lengths[layer_idx] = new_max_seq_len;
            }
            
            // Resize the cache vectors
            self.key_cache[layer_idx].resize(new_cache_size_per_layer, 0.0);
            self.value_cache[layer_idx].resize(new_cache_size_per_layer, 0.0);
        }
        
        self.max_seq_len = new_max_seq_len;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_kv_cache_basic() {
        let mut cache = KvCache::new(2, 4, 64, 128);
        
        // Test initial state
        assert_eq!(cache.sequence_length(0), Some(0));
        assert_eq!(cache.sequence_length(1), Some(0));
        assert_eq!(cache.remaining_capacity(0), Some(128));
        assert!(!cache.is_full(0));
        
        // Test update
        let key_states = vec![1.0f32; 4 * 64]; // 1 token, 4 heads, 64 dim
        let value_states = vec![2.0f32; 4 * 64];
        
        let (cached_keys, cached_values) = cache.update(0, key_states, value_states).unwrap();
        
        assert_eq!(cache.sequence_length(0), Some(1));
        assert_eq!(cached_keys.len(), 4 * 64);
        assert_eq!(cached_values.len(), 4 * 64);
        assert_eq!(cached_keys[0], 1.0);
        assert_eq!(cached_values[0], 2.0);
    }
    
    #[test]
    fn test_kv_cache_multiple_updates() {
        let mut cache = KvCache::new(1, 2, 32, 10);
        
        // Add first token
        let key1 = vec![1.0f32; 2 * 32];
        let value1 = vec![2.0f32; 2 * 32];
        cache.update(0, key1, value1).unwrap();
        
        // Add second token
        let key2 = vec![3.0f32; 2 * 32];
        let value2 = vec![4.0f32; 2 * 32];
        let (cached_keys, cached_values) = cache.update(0, key2, value2).unwrap();
        
        assert_eq!(cache.sequence_length(0), Some(2));
        assert_eq!(cached_keys.len(), 2 * 2 * 32); // 2 tokens, 2 heads, 32 dim
        assert_eq!(cached_values.len(), 2 * 2 * 32);
        
        // Check that both tokens are in cache
        assert_eq!(cached_keys[0], 1.0); // First token
        assert_eq!(cached_keys[2 * 32], 3.0); // Second token
    }
    
    #[test]
    fn test_kv_cache_clear() {
        let mut cache = KvCache::new(2, 2, 16, 64);
        
        // Add some data
        let key_states = vec![1.0f32; 2 * 16];
        let value_states = vec![2.0f32; 2 * 16];
        cache.update(0, key_states, value_states).unwrap();
        
        assert_eq!(cache.sequence_length(0), Some(1));
        
        // Clear all
        cache.clear();
        assert_eq!(cache.sequence_length(0), Some(0));
        assert_eq!(cache.sequence_length(1), Some(0));
        
        // Test layer-specific clear
        cache.update(0, vec![1.0f32; 2 * 16], vec![2.0f32; 2 * 16]).unwrap();
        cache.update(1, vec![3.0f32; 2 * 16], vec![4.0f32; 2 * 16]).unwrap();
        
        cache.clear_layer(0).unwrap();
        assert_eq!(cache.sequence_length(0), Some(0));
        assert_eq!(cache.sequence_length(1), Some(1));
    }
}