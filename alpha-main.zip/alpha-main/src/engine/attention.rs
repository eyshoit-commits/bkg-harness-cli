use serde::{Deserialize, Serialize};
use tracing::debug;

use crate::core::{Error, Result};
use crate::tensor::{TensorView, TensorOps};
use crate::engine::KvCache;
use crate::simd;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AttentionConfig {
    pub hidden_size: usize,
    pub num_heads: usize,
    pub num_key_value_heads: usize,
    pub head_dim: usize,
    pub rope_theta: f32,
    pub max_position_embeddings: usize,
}

pub struct AttentionLayer {
    config: AttentionConfig,
    q_proj: TensorView,
    k_proj: TensorView,
    v_proj: TensorView,
    o_proj: TensorView,
    rope_cache: RopeCache,
}

impl AttentionLayer {
    pub fn new(
        config: AttentionConfig,
        q_proj: TensorView,
        k_proj: TensorView,
        v_proj: TensorView,
        o_proj: TensorView,
    ) -> Result<Self> {
        let rope_cache = RopeCache::new(
            config.head_dim,
            config.max_position_embeddings,
            config.rope_theta,
        )?;
        
        Ok(Self {
            config,
            q_proj,
            k_proj,
            v_proj,
            o_proj,
            rope_cache,
        })
    }
    
    pub fn forward(
        &self,
        hidden_states: &[f32],
        position_ids: Option<&[usize]>,
        kv_cache: &mut KvCache,
        layer_idx: usize,
    ) -> Result<Vec<f32>> {
        let seq_len = hidden_states.len() / self.config.hidden_size;
        let batch_size = 1; // Currently only support batch_size = 1
        
        debug!("Attention forward: seq_len={}, layer={}", seq_len, layer_idx);
        
        // Project to Q, K, V
        let query_states = self.linear_projection(hidden_states, &self.q_proj)?;
        let key_states = self.linear_projection(hidden_states, &self.k_proj)?;
        let value_states = self.linear_projection(hidden_states, &self.v_proj)?;
        
        // Reshape to [batch_size, seq_len, num_heads, head_dim]
        let query_states = self.reshape_for_attention(&query_states, seq_len, self.config.num_heads)?;
        let key_states = self.reshape_for_attention(&key_states, seq_len, self.config.num_key_value_heads)?;
        let value_states = self.reshape_for_attention(&value_states, seq_len, self.config.num_key_value_heads)?;
        
        // Apply RoPE (Rotary Position Embedding)
        let (query_states, key_states) = self.apply_rope(&query_states, &key_states, position_ids)?;
        
        // Update KV cache
        let (key_states, value_states) = kv_cache.update(layer_idx, key_states, value_states)?;
        
        // Compute attention
        let attention_output = self.compute_attention(&query_states, &key_states, &value_states)?;
        
        // Reshape back to [batch_size * seq_len, hidden_size]
        let attention_output = self.reshape_from_attention(&attention_output, seq_len)?;
        
        // Output projection
        let output = self.linear_projection(&attention_output, &self.o_proj)?;
        
        Ok(output)
    }
    
    fn linear_projection(&self, input: &[f32], weight: &TensorView) -> Result<Vec<f32>> {
        let weight_data = weight.as_f32_slice()?;
        let input_size = self.config.hidden_size;
        let output_size = weight.shape.dims[0]; // First dimension is output size
        let seq_len = input.len() / input_size;
        
        let mut result = vec![0.0f32; seq_len * output_size];
        
        // Use SIMD GEMM for matrix multiplication
        simd::gemm(
            seq_len,     // m
            output_size, // n
            input_size,  // k
            1.0,         // alpha
            input,       // a
            input_size,  // lda
            weight_data, // b
            output_size, // ldb
            0.0,         // beta
            &mut result, // c
            output_size, // ldc
        )?;
        
        Ok(result)
    }
    
    fn reshape_for_attention(
        &self,
        states: &[f32],
        seq_len: usize,
        num_heads: usize,
    ) -> Result<Vec<f32>> {
        let head_dim = self.config.head_dim;
        let expected_size = seq_len * num_heads * head_dim;
        
        if states.len() != expected_size {
            return Err(Error::engine(format!(
                "Shape mismatch in attention reshape: expected {}, got {}",
                expected_size, states.len()
            )));
        }
        
        // Already in the correct shape, just return a copy
        Ok(states.to_vec())
    }
    
    fn reshape_from_attention(&self, states: &[f32], seq_len: usize) -> Result<Vec<f32>> {
        let expected_size = seq_len * self.config.hidden_size;
        
        if states.len() != expected_size {
            return Err(Error::engine(format!(
                "Shape mismatch in attention reshape back: expected {}, got {}",
                expected_size, states.len()
            )));
        }
        
        Ok(states.to_vec())
    }
    
    fn apply_rope(
        &self,
        query_states: &[f32],
        key_states: &[f32],
        position_ids: Option<&[usize]>,
    ) -> Result<(Vec<f32>, Vec<f32>)> {
        let seq_len = query_states.len() / (self.config.num_heads * self.config.head_dim);
        
        // Generate position IDs if not provided
        let positions: Vec<usize> = if let Some(pos_ids) = position_ids {
            pos_ids.to_vec()
        } else {
            (0..seq_len).collect()
        };
        
        let rotated_query = self.rope_cache.apply(query_states, &positions, self.config.num_heads)?;
        let rotated_key = self.rope_cache.apply(key_states, &positions, self.config.num_key_value_heads)?;
        
        Ok((rotated_query, rotated_key))
    }
    
    fn compute_attention(
        &self,
        query_states: &[f32],
        key_states: &[f32],
        value_states: &[f32],
    ) -> Result<Vec<f32>> {
        let seq_len = query_states.len() / (self.config.num_heads * self.config.head_dim);
        let kv_seq_len = key_states.len() / (self.config.num_key_value_heads * self.config.head_dim);
        let head_dim = self.config.head_dim;
        let num_heads = self.config.num_heads;
        let num_kv_heads = self.config.num_key_value_heads;
        
        // Group query attention for multi-query/grouped-query attention
        let group_size = num_heads / num_kv_heads;
        
        let mut attention_output = vec![0.0f32; seq_len * num_heads * head_dim];
        
        for head_idx in 0..num_heads {
            let kv_head_idx = head_idx / group_size;
            
            // Extract query for this head
            let q_start = head_idx * seq_len * head_dim;
            let q_end = q_start + seq_len * head_dim;
            let query = &query_states[q_start..q_end];
            
            // Extract key and value for corresponding KV head
            let k_start = kv_head_idx * kv_seq_len * head_dim;
            let k_end = k_start + kv_seq_len * head_dim;
            let key = &key_states[k_start..k_end];
            
            let v_start = kv_head_idx * kv_seq_len * head_dim;
            let v_end = v_start + kv_seq_len * head_dim;
            let value = &value_states[v_start..v_end];
            
            // Compute attention scores: Q @ K^T
            let mut scores = vec![0.0f32; seq_len * kv_seq_len];
            simd::gemm(
                seq_len,    // m
                kv_seq_len, // n
                head_dim,   // k
                1.0 / (head_dim as f32).sqrt(), // alpha (scaled attention)
                query,      // a
                head_dim,   // lda
                key,        // b (transposed)
                head_dim,   // ldb
                0.0,        // beta
                &mut scores, // c
                kv_seq_len, // ldc
            )?;
            
            // Apply causal mask and softmax
            self.apply_causal_mask_and_softmax(&mut scores, seq_len, kv_seq_len)?;
            
            // Compute attention output: scores @ V
            let output_start = head_idx * seq_len * head_dim;
            let output_end = output_start + seq_len * head_dim;
            let mut head_output = vec![0.0f32; seq_len * head_dim];
            
            simd::gemm(
                seq_len,    // m
                head_dim,   // n
                kv_seq_len, // k
                1.0,        // alpha
                &scores,    // a
                kv_seq_len, // lda
                value,      // b
                head_dim,   // ldb
                0.0,        // beta
                &mut head_output, // c
                head_dim,   // ldc
            )?;
            
            // Copy to attention output
            attention_output[output_start..output_end].copy_from_slice(&head_output);
        }
        
        Ok(attention_output)
    }
    
    fn apply_causal_mask_and_softmax(
        &self,
        scores: &mut [f32],
        seq_len: usize,
        kv_seq_len: usize,
    ) -> Result<()> {
        for i in 0..seq_len {
            let row_start = i * kv_seq_len;
            let row_end = row_start + kv_seq_len;
            let row = &mut scores[row_start..row_end];
            
            // Apply causal mask (set future positions to -inf)
            for j in (i + 1)..kv_seq_len.min(seq_len) {
                row[j] = f32::NEG_INFINITY;
            }
            
            // Apply softmax to the row
            let max_val = row.iter().fold(f32::NEG_INFINITY, |a, &b| a.max(b));
            let mut sum = 0.0f32;
            
            for val in row.iter_mut() {
                if val.is_finite() {
                    *val = (*val - max_val).exp();
                    sum += *val;
                } else {
                    *val = 0.0;
                }
            }
            
            if sum > 0.0 {
                for val in row.iter_mut() {
                    *val /= sum;
                }
            }
        }
        
        Ok(())
    }
}

/// RoPE (Rotary Position Embedding) cache
struct RopeCache {
    cos_cache: Vec<f32>,
    sin_cache: Vec<f32>,
    head_dim: usize,
}

impl RopeCache {
    fn new(head_dim: usize, max_seq_len: usize, theta: f32) -> Result<Self> {
        let mut cos_cache = vec![0.0f32; max_seq_len * head_dim];
        let mut sin_cache = vec![0.0f32; max_seq_len * head_dim];
        
        for pos in 0..max_seq_len {
            for i in 0..(head_dim / 2) {
                let freq = 1.0 / theta.powf(2.0 * i as f32 / head_dim as f32);
                let angle = pos as f32 * freq;
                
                let cos_val = angle.cos();
                let sin_val = angle.sin();
                
                // Store cos and sin for both dimensions of the pair
                cos_cache[pos * head_dim + 2 * i] = cos_val;
                cos_cache[pos * head_dim + 2 * i + 1] = cos_val;
                sin_cache[pos * head_dim + 2 * i] = sin_val;
                sin_cache[pos * head_dim + 2 * i + 1] = sin_val;
            }
        }
        
        Ok(Self {
            cos_cache,
            sin_cache,
            head_dim,
        })
    }
    
    fn apply(
        &self,
        states: &[f32],
        position_ids: &[usize],
        num_heads: usize,
    ) -> Result<Vec<f32>> {
        let seq_len = position_ids.len();
        let mut rotated = states.to_vec();
        
        for (seq_idx, &pos) in position_ids.iter().enumerate() {
            for head_idx in 0..num_heads {
                let head_start = head_idx * seq_len * self.head_dim + seq_idx * self.head_dim;
                
                for i in 0..(self.head_dim / 2) {
                    let x_idx = head_start + 2 * i;
                    let y_idx = head_start + 2 * i + 1;
                    
                    if x_idx < rotated.len() && y_idx < rotated.len() {
                        let cos_val = self.cos_cache[pos * self.head_dim + 2 * i];
                        let sin_val = self.sin_cache[pos * self.head_dim + 2 * i];
                        
                        let x = rotated[x_idx];
                        let y = rotated[y_idx];
                        
                        rotated[x_idx] = x * cos_val - y * sin_val;
                        rotated[y_idx] = x * sin_val + y * cos_val;
                    }
                }
            }
        }
        
        Ok(rotated)
    }
}