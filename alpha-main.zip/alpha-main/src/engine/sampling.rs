use rand::{Rng, SeedableRng};
use rand::rngs::StdRng;
use serde::{Deserialize, Serialize};
use std::collections::VecDeque;
use tracing::debug;

use crate::core::{Error, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SamplingConfig {
    pub temperature: f32,
    pub top_k: Option<usize>,
    pub top_p: Option<f32>,
    pub repetition_penalty: f32,
    pub pad_token_id: Option<u32>,
    pub eos_token_id: Option<u32>,
}

impl Default for SamplingConfig {
    fn default() -> Self {
        Self {
            temperature: 1.0,
            top_k: None,
            top_p: None,
            repetition_penalty: 1.0,
            pad_token_id: None,
            eos_token_id: None,
        }
    }
}

#[derive(Debug, Clone)]
pub enum StopCondition {
    MaxTokens(usize),
    EosToken(u32),
    StopSequence(Vec<u32>),
    Custom(fn(&[u32]) -> bool),
}

pub struct Sampler {
    pub config: SamplingConfig,
    rng: StdRng,
    repetition_history: VecDeque<u32>,
    repetition_window: usize,
}

impl Sampler {
    pub fn new(config: SamplingConfig) -> Self {
        let rng = StdRng::from_entropy();
        let repetition_history = VecDeque::new();
        let repetition_window = 64; // Keep last 64 tokens for repetition penalty
        
        Self {
            config,
            rng,
            repetition_history,
            repetition_window,
        }
    }
    
    pub fn with_seed(config: SamplingConfig, seed: u64) -> Self {
        let rng = StdRng::seed_from_u64(seed);
        let repetition_history = VecDeque::new();
        let repetition_window = 64;
        
        Self {
            config,
            rng,
            repetition_history,
            repetition_window,
        }
    }
    
    /// Sample next token from logits
    pub fn sample(&mut self, logits: &[f32], generated_tokens: &[u32]) -> Result<u32> {
        if logits.is_empty() {
            return Err(Error::engine("Empty logits for sampling".to_string()));
        }
        
        debug!("Sampling with temperature={}, top_k={:?}, top_p={:?}", 
               self.config.temperature, self.config.top_k, self.config.top_p);
        
        // Apply repetition penalty
        let mut adjusted_logits = self.apply_repetition_penalty(logits, generated_tokens)?;
        
        // Apply temperature scaling
        if self.config.temperature != 1.0 && self.config.temperature > 0.0 {
            for logit in adjusted_logits.iter_mut() {
                *logit /= self.config.temperature;
            }
        }
        
        // Convert logits to probabilities
        let mut probs = self.softmax(&adjusted_logits)?;
        
        // Apply top-k filtering
        if let Some(top_k) = self.config.top_k {
            self.apply_top_k(&mut probs, top_k)?;
        }
        
        // Apply top-p (nucleus) sampling
        if let Some(top_p) = self.config.top_p {
            self.apply_top_p(&mut probs, top_p)?;
        }
        
        // Sample from the distribution
        let token = if self.config.temperature == 0.0 {
            // Greedy sampling
            self.greedy_sample(&probs)?
        } else {
            // Stochastic sampling
            self.multinomial_sample(&probs)?
        };
        
        // Update repetition history
        self.update_repetition_history(token);
        
        debug!("Sampled token: {}", token);
        Ok(token)
    }
    
    fn apply_repetition_penalty(&self, logits: &[f32], generated_tokens: &[u32]) -> Result<Vec<f32>> {
        let mut adjusted_logits = logits.to_vec();
        
        if self.config.repetition_penalty != 1.0 && !generated_tokens.is_empty() {
            // Apply penalty to tokens that have appeared in the history
            let penalty = self.config.repetition_penalty;
            
            for &token_id in generated_tokens.iter().rev().take(self.repetition_window) {
                let token_id = token_id as usize;
                if token_id < adjusted_logits.len() {
                    if adjusted_logits[token_id] > 0.0 {
                        adjusted_logits[token_id] /= penalty;
                    } else {
                        adjusted_logits[token_id] *= penalty;
                    }
                }
            }
        }
        
        Ok(adjusted_logits)
    }
    
    fn softmax(&self, logits: &[f32]) -> Result<Vec<f32>> {
        let max_logit = logits.iter()
            .fold(f32::NEG_INFINITY, |a, &b| a.max(b));
        
        if !max_logit.is_finite() {
            return Err(Error::engine("Invalid logits for softmax".to_string()));
        }
        
        let mut exp_logits: Vec<f32> = logits.iter()
            .map(|&x| (x - max_logit).exp())
            .collect();
        
        let sum_exp: f32 = exp_logits.iter().sum();
        
        if sum_exp == 0.0 || !sum_exp.is_finite() {
            return Err(Error::engine("Softmax normalization failed".to_string()));
        }
        
        for prob in exp_logits.iter_mut() {
            *prob /= sum_exp;
        }
        
        Ok(exp_logits)
    }
    
    fn apply_top_k(&self, probs: &mut [f32], k: usize) -> Result<()> {
        if k == 0 || k >= probs.len() {
            return Ok(());
        }
        
        // Get indices sorted by probability (descending)
        let mut indices: Vec<usize> = (0..probs.len()).collect();
        indices.sort_unstable_by(|&a, &b| probs[b].partial_cmp(&probs[a]).unwrap());
        
        // Zero out probabilities for tokens not in top-k
        for &idx in indices.iter().skip(k) {
            probs[idx] = 0.0;
        }
        
        // Renormalize
        let sum: f32 = probs.iter().sum();
        if sum > 0.0 {
            for prob in probs.iter_mut() {
                *prob /= sum;
            }
        }
        
        Ok(())
    }
    
    fn apply_top_p(&self, probs: &mut [f32], p: f32) -> Result<()> {
        if p >= 1.0 || p <= 0.0 {
            return Ok(());
        }
        
        // Get indices sorted by probability (descending)
        let mut indices: Vec<usize> = (0..probs.len()).collect();
        indices.sort_unstable_by(|&a, &b| probs[b].partial_cmp(&probs[a]).unwrap());
        
        // Find cutoff point where cumulative probability exceeds p
        let mut cumulative_prob = 0.0;
        let mut cutoff_idx = indices.len();
        
        for (i, &idx) in indices.iter().enumerate() {
            cumulative_prob += probs[idx];
            if cumulative_prob >= p {
                cutoff_idx = i + 1;
                break;
            }
        }
        
        // Zero out probabilities for tokens not in nucleus
        for &idx in indices.iter().skip(cutoff_idx) {
            probs[idx] = 0.0;
        }
        
        // Renormalize
        let sum: f32 = probs.iter().sum();
        if sum > 0.0 {
            for prob in probs.iter_mut() {
                *prob /= sum;
            }
        }
        
        Ok(())
    }
    
    fn greedy_sample(&self, probs: &[f32]) -> Result<u32> {
        let max_idx = probs.iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(idx, _)| idx)
            .ok_or_else(|| Error::engine("No valid tokens for greedy sampling".to_string()))?;
        
        Ok(max_idx as u32)
    }
    
    fn multinomial_sample(&mut self, probs: &[f32]) -> Result<u32> {
        let random_value: f32 = self.rng.gen();
        let mut cumulative_prob = 0.0;
        
        for (idx, &prob) in probs.iter().enumerate() {
            cumulative_prob += prob;
            if random_value <= cumulative_prob {
                return Ok(idx as u32);
            }
        }
        
        // Fallback to last token if rounding errors occur
        Ok((probs.len() - 1) as u32)
    }
    
    fn update_repetition_history(&mut self, token: u32) {
        self.repetition_history.push_back(token);
        
        // Keep only recent history
        while self.repetition_history.len() > self.repetition_window {
            self.repetition_history.pop_front();
        }
    }
    
    /// Check if sequence should stop based on stop conditions
    pub fn should_stop(&self, tokens: &[u32], stop_conditions: &[StopCondition]) -> bool {
        for condition in stop_conditions {
            match condition {
                StopCondition::MaxTokens(max) => {
                    if tokens.len() >= *max {
                        return true;
                    }
                }
                StopCondition::EosToken(eos_id) => {
                    if let Some(&last_token) = tokens.last() {
                        if last_token == *eos_id {
                            return true;
                        }
                    }
                }
                StopCondition::StopSequence(sequence) => {
                    if tokens.len() >= sequence.len() {
                        let suffix = &tokens[tokens.len() - sequence.len()..];
                        if suffix == sequence.as_slice() {
                            return true;
                        }
                    }
                }
                StopCondition::Custom(func) => {
                    if func(tokens) {
                        return true;
                    }
                }
            }
        }
        
        false
    }
    
    /// Reset sampler state
    pub fn reset(&mut self) {
        self.repetition_history.clear();
    }
    
    /// Get current repetition history
    pub fn repetition_history(&self) -> &VecDeque<u32> {
        &self.repetition_history
    }
    
    /// Update configuration
    pub fn update_config(&mut self, config: SamplingConfig) {
        self.config = config;
    }
}

/// Utility functions for common sampling patterns
impl Sampler {
    /// Create a greedy sampler (temperature = 0)
    pub fn greedy() -> Self {
        let config = SamplingConfig {
            temperature: 0.0,
            top_k: None,
            top_p: None,
            repetition_penalty: 1.0,
            pad_token_id: None,
            eos_token_id: None,
        };
        Self::new(config)
    }
    
    /// Create a nucleus sampler (top-p)
    pub fn nucleus(top_p: f32, temperature: f32) -> Self {
        let config = SamplingConfig {
            temperature,
            top_k: None,
            top_p: Some(top_p),
            repetition_penalty: 1.1,
            pad_token_id: None,
            eos_token_id: None,
        };
        Self::new(config)
    }
    
    /// Create a top-k sampler
    pub fn top_k(k: usize, temperature: f32) -> Self {
        let config = SamplingConfig {
            temperature,
            top_k: Some(k),
            top_p: None,
            repetition_penalty: 1.1,
            pad_token_id: None,
            eos_token_id: None,
        };
        Self::new(config)
    }
    
    /// Create a balanced sampler (top-k + top-p + repetition penalty)
    pub fn balanced() -> Self {
        let config = SamplingConfig {
            temperature: 0.7,
            top_k: Some(50),
            top_p: Some(0.95),
            repetition_penalty: 1.1,
            pad_token_id: None,
            eos_token_id: Some(2), // Common EOS token ID
        };
        Self::new(config)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_greedy_sampling() {
        let mut sampler = Sampler::greedy();
        let logits = vec![1.0, 3.0, 2.0, 0.5];
        let generated = vec![];
        
        let token = sampler.sample(&logits, &generated).unwrap();
        assert_eq!(token, 1); // Index of maximum logit
    }
    
    #[test]
    fn test_temperature_scaling() {
        let config = SamplingConfig {
            temperature: 2.0,
            ..Default::default()
        };
        let mut sampler = Sampler::with_seed(config, 42);
        
        let logits = vec![2.0, 4.0, 1.0];
        let generated = vec![];
        
        // With higher temperature, distribution should be more uniform
        let token = sampler.sample(&logits, &generated).unwrap();
        assert!(token < 3);
    }
    
    #[test]
    fn test_top_k_filtering() {
        let config = SamplingConfig {
            temperature: 1.0,
            top_k: Some(2),
            ..Default::default()
        };
        let mut sampler = Sampler::with_seed(config, 42);
        
        let logits = vec![1.0, 4.0, 3.0, 0.5, 2.0];
        let generated = vec![];
        
        let token = sampler.sample(&logits, &generated).unwrap();
        // Should only sample from top-2: indices 1 and 2
        assert!(token == 1 || token == 2);
    }
    
    #[test]
    fn test_repetition_penalty() {
        let config = SamplingConfig {
            temperature: 1.0,
            repetition_penalty: 2.0,
            ..Default::default()
        };
        let mut sampler = Sampler::with_seed(config, 42);
        
        let logits = vec![2.0, 2.0, 2.0]; // Equal logits
        let generated = vec![0, 0, 1]; // Token 0 repeated
        
        let adjusted = sampler.apply_repetition_penalty(&logits, &generated).unwrap();
        // Token 0 should be penalized more than others
        assert!(adjusted[0] < adjusted[2]);
        assert!(adjusted[1] < adjusted[2]); // Token 1 also appeared
    }
    
    #[test]
    fn test_softmax() {
        let sampler = Sampler::greedy();
        let logits = vec![1.0, 2.0, 3.0];
        
        let probs = sampler.softmax(&logits).unwrap();
        
        // Check that probabilities sum to 1
        let sum: f32 = probs.iter().sum();
        assert!((sum - 1.0).abs() < 1e-6);
        
        // Check that higher logits have higher probabilities
        assert!(probs[2] > probs[1]);
        assert!(probs[1] > probs[0]);
    }
    
    #[test]
    fn test_stop_conditions() {
        let sampler = Sampler::greedy();
        
        let tokens = vec![1, 2, 3, 2]; // EOS token = 2
        let conditions = vec![
            StopCondition::MaxTokens(3),
            StopCondition::EosToken(2),
        ];
        
        assert!(sampler.should_stop(&tokens, &conditions));
        
        let tokens = vec![1, 3, 4];
        assert!(!sampler.should_stop(&tokens, &conditions));
    }
}