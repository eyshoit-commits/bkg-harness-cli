use axum::{
    extract::{Query, WebSocketUpgrade},
    http::StatusCode,
    response::{Html, IntoResponse, Response},
    Json,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tracing::{debug, info};

#[derive(Debug, Serialize)]
pub struct SystemInfo {
    pub version: String,
    pub uptime: u64,
    pub memory_usage: MemoryInfo,
    pub cpu_info: CpuInfo,
    pub model_info: Option<ModelInfo>,
}

#[derive(Debug, Serialize)]
pub struct MemoryInfo {
    pub total_mb: u64,
    pub used_mb: u64,
    pub free_mb: u64,
}

#[derive(Debug, Serialize)]
pub struct CpuInfo {
    pub cores: usize,
    pub usage_percent: f64,
    pub architecture: String,
}

#[derive(Debug, Serialize)]
pub struct ModelInfo {
    pub name: String,
    pub size_mb: usize,
    pub parameters: u64,
    pub cache_size_mb: usize,
}

#[derive(Debug, Serialize)]
pub struct SystemMetrics {
    pub timestamp: String,
    pub requests_per_second: f64,
    pub avg_response_time_ms: f64,
    pub active_connections: usize,
    pub memory_usage: MemoryInfo,
    pub gpu_usage: Option<GpuInfo>,
}

#[derive(Debug, Serialize)]
pub struct GpuInfo {
    pub name: String,
    pub memory_used_mb: u64,
    pub memory_total_mb: u64,
    pub utilization_percent: f64,
}

#[derive(Debug, Serialize)]
pub struct LogEntry {
    pub timestamp: String,
    pub level: String,
    pub message: String,
    pub module: String,
}

#[derive(Debug, Deserialize)]
pub struct LogQuery {
    pub level: Option<String>,
    pub limit: Option<usize>,
    pub since: Option<String>,
}

pub async fn admin_ui() -> Html<&'static str> {
    Html(include_str!("../../../ui/admin.html"))
}

pub async fn system_info() -> Result<Json<SystemInfo>, Response> {
    debug!("📊 Getting system information");
    
    let info = SystemInfo {
        version: env!("CARGO_PKG_VERSION").to_string(),
        uptime: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs(),
        memory_usage: get_memory_info(),
        cpu_info: get_cpu_info(),
        model_info: None, // TODO: Get from engine state
    };
    
    Ok(Json(info))
}

pub async fn system_metrics() -> Result<Json<SystemMetrics>, Response> {
    debug!("📈 Getting system metrics");
    
    let metrics = SystemMetrics {
        timestamp: chrono::Utc::now().to_rfc3339(),
        requests_per_second: 0.0, // TODO: Implement metrics collection
        avg_response_time_ms: 0.0,
        active_connections: 0,
        memory_usage: get_memory_info(),
        gpu_usage: None, // TODO: Implement GPU monitoring
    };
    
    Ok(Json(metrics))
}

pub async fn get_logs(Query(query): Query<LogQuery>) -> Result<Json<Vec<LogEntry>>, Response> {
    debug!("📜 Getting logs with query: {:?}", query);
    
    // Mock log entries for now
    let logs = vec![
        LogEntry {
            timestamp: chrono::Utc::now().to_rfc3339(),
            level: "INFO".to_string(),
            message: "Server started successfully".to_string(),
            module: "main".to_string(),
        },
        LogEntry {
            timestamp: chrono::Utc::now().to_rfc3339(),
            level: "DEBUG".to_string(),
            message: "Processing inference request".to_string(),
            module: "engine".to_string(),
        },
    ];
    
    Ok(Json(logs))
}

pub async fn get_config() -> Result<Json<serde_json::Value>, Response> {
    debug!("⚙️  Getting configuration");
    
    // Mock configuration for now
    let config = serde_json::json!({
        "server": {
            "host": "0.0.0.0",
            "port": 8080,
            "cors_enabled": true
        },
        "model": {
            "directory": "./models",
            "cache_size_mb": 2048
        },
        "engine": {
            "max_sequence_length": 2048,
            "batch_size": 1,
            "use_simd": true
        }
    });
    
    Ok(Json(config))
}

pub async fn update_config(
    Json(new_config): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>, Response> {
    info!("🔧 Updating configuration");
    
    // TODO: Implement configuration update
    // For now, just return success
    Ok(Json(serde_json::json!({
        "status": "updated",
        "message": "Configuration updated successfully"
    })))
}

pub async fn websocket_handler(ws: WebSocketUpgrade) -> Response {
    info!("🔌 WebSocket connection established");
    
    ws.on_upgrade(handle_websocket)
}

async fn handle_websocket(mut socket: axum::extract::ws::WebSocket) {
    use axum::extract::ws::Message;
    use tokio::time::{interval, Duration};
    
    let mut interval = interval(Duration::from_secs(1));
    
    loop {
        tokio::select! {
            _ = interval.tick() => {
                // Send periodic system metrics
                let metrics = SystemMetrics {
                    timestamp: chrono::Utc::now().to_rfc3339(),
                    requests_per_second: rand::random::<f64>() * 10.0,
                    avg_response_time_ms: rand::random::<f64>() * 100.0,
                    active_connections: rand::random::<usize>() % 10,
                    memory_usage: get_memory_info(),
                    gpu_usage: None,
                };
                
                let json = serde_json::to_string(&metrics).unwrap();
                if socket.send(Message::Text(json)).await.is_err() {
                    break;
                }
            }
            
            msg = socket.recv() => {
                match msg {
                    Some(Ok(Message::Text(text))) => {
                        debug!("📨 Received WebSocket message: {}", text);
                        // Echo back for now
                        if socket.send(Message::Text(format!("Echo: {}", text))).await.is_err() {
                            break;
                        }
                    }
                    Some(Ok(Message::Close(_))) => {
                        info!("🔌 WebSocket connection closed");
                        break;
                    }
                    Some(Err(e)) => {
                        info!("❌ WebSocket error: {}", e);
                        break;
                    }
                    None => break,
                    _ => {}
                }
            }
        }
    }
}

// Helper functions

fn get_memory_info() -> MemoryInfo {
    // Mock memory information
    MemoryInfo {
        total_mb: 16384,
        used_mb: 8192,
        free_mb: 8192,
    }
}

fn get_cpu_info() -> CpuInfo {
    CpuInfo {
        cores: num_cpus::get(),
        usage_percent: rand::random::<f64>() * 100.0,
        architecture: std::env::consts::ARCH.to_string(),
    }
}