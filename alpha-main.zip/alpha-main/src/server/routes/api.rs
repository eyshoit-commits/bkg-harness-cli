use axum::{
    extract::{Query, State},
    http::StatusCode,
    response::{IntoResponse, Response, Sse},
    Json,
};
use futures::stream::{self, Stream};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
// Removed tokio_stream dependency
use tracing::{debug, error, info, warn};

use crate::engine::{TransformerEngine, InferenceConfig};
use crate::loader::GgufLoader;

#[derive(Clone)]
pub struct ApiState {
    pub engine: Option<Arc<RwLock<TransformerEngine>>>,
}

// Request/Response types
#[derive(Debug, Deserialize)]
pub struct LoadModelRequest {
    pub model_path: String,
    pub config: Option<InferenceConfig>,
}

#[derive(Debug, Deserialize)]
pub struct InferenceRequest {
    pub prompt: String,
    pub max_new_tokens: Option<usize>,
    pub temperature: Option<f32>,
    pub top_k: Option<usize>,
    pub top_p: Option<f32>,
    pub repetition_penalty: Option<f32>,
    pub stop_sequences: Option<Vec<String>>,
    pub stream: Option<bool>,
}

#[derive(Debug, Serialize)]
pub struct InferenceResponse {
    pub text: String,
    pub tokens: Vec<u32>,
    pub finish_reason: String,
    pub usage: TokenUsage,
}

#[derive(Debug, Serialize)]
pub struct InferenceStreamChunk {
    pub token: Option<u32>,
    pub text: Option<String>,
    pub finish_reason: Option<String>,
    pub usage: Option<TokenUsage>,
}

#[derive(Debug, Serialize)]
pub struct TokenUsage {
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub total_tokens: usize,
}

#[derive(Debug, Deserialize)]
pub struct TokenizeRequest {
    pub text: String,
}

#[derive(Debug, Serialize)]
pub struct TokenizeResponse {
    pub tokens: Vec<u32>,
}

#[derive(Debug, Deserialize)]
pub struct DetokenizeRequest {
    pub tokens: Vec<u32>,
}

#[derive(Debug, Serialize)]
pub struct DetokenizeResponse {
    pub text: String,
}

#[derive(Debug, Serialize)]
pub struct ModelInfo {
    pub name: String,
    pub parameters: u64,
    pub size_mb: usize,
    pub architecture: String,
    pub loaded: bool,
    pub config: Option<serde_json::Value>,
}

#[derive(Debug, Serialize)]
pub struct ErrorResponse {
    pub error: String,
    pub code: String,
    pub details: Option<serde_json::Value>,
}

// API Handlers

pub async fn list_models() -> Json<Vec<ModelInfo>> {
    debug!("📋 Listing available models");
    
    // For now, return empty list - in a real implementation,
    // this would scan the model directory
    let models = vec![];
    
    Json(models)
}

pub async fn load_model(
    State(_state): State<ApiState>,
    Json(request): Json<LoadModelRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    info!("📦 Loading model: {}", request.model_path);
    
    // Check if model file exists
    if !std::path::Path::new(&request.model_path).exists() {
        return Err((
            StatusCode::NOT_FOUND,
            Json(ErrorResponse {
                error: format!("Model file not found: {}", request.model_path),
                code: "model_not_found".to_string(),
                details: None,
            })
        ));
    }
    
    // Mock successful loading
    info!("✅ Model loaded successfully: {}", request.model_path);
    
    Ok(Json(serde_json::json!({
        "status": "loaded",
        "model_path": request.model_path,
        "message": "Model loaded successfully"
    })))
}

pub async fn unload_model(
    State(_state): State<ApiState>,
) -> Json<serde_json::Value> {
    info!("🗑️  Unloading model");
    
    Json(serde_json::json!({
        "status": "unloaded",
        "message": "Model unloaded successfully"
    }))
}

pub async fn model_info(
    State(_state): State<ApiState>,
) -> Result<Json<ModelInfo>, (StatusCode, Json<ErrorResponse>)> {
    debug!("ℹ️  Getting model info");
    
    // Mock model info
    let info = ModelInfo {
        name: "mock_model".to_string(),
        parameters: 7_000_000_000, // 7B parameters
        size_mb: 4096,
        architecture: "transformer".to_string(),
        loaded: true,
        config: Some(serde_json::json!({
            "max_sequence_length": 2048,
            "vocab_size": 32000
        })),
    };
    
    Ok(Json(info))
}

pub async fn infer(
    State(_state): State<ApiState>,
    Json(request): Json<InferenceRequest>,
) -> Json<InferenceResponse> {
    info!("🧠 Starting inference: prompt_len={}", request.prompt.len());
    
    // Mock response
    let mock_tokens = vec![1, 2, 3, 4, 5];
    let mock_text = "This is a mock response from the LLM server.".to_string();
    
    let response = InferenceResponse {
        text: mock_text,
        tokens: mock_tokens.clone(),
        finish_reason: "length".to_string(),
        usage: TokenUsage {
            prompt_tokens: request.prompt.len() / 4, // Rough estimate
            completion_tokens: mock_tokens.len(),
            total_tokens: request.prompt.len() / 4 + mock_tokens.len(),
        },
    };
    
    info!("✅ Inference completed: {} tokens generated", response.tokens.len());
    Json(response)
}

pub async fn infer_stream(
    State(_state): State<ApiState>,
    Json(request): Json<InferenceRequest>,
) -> Sse<impl Stream<Item = Result<axum::response::sse::Event, axum::Error>>> {
    info!("🌊 Starting streaming inference: prompt_len={}", request.prompt.len());
    
    use futures::StreamExt;
    
    // Create a mock stream of tokens
    let stream = stream::iter(0..10)
        .then(move |i| async move {
            tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
            
            let chunk = if i == 9 {
                InferenceStreamChunk {
                    token: None,
                    text: None,
                    finish_reason: Some("length".to_string()),
                    usage: Some(TokenUsage {
                        prompt_tokens: 10,
                        completion_tokens: 10,
                        total_tokens: 20,
                    }),
                }
            } else {
                InferenceStreamChunk {
                    token: Some(i + 100),
                    text: Some(format!("token_{} ", i)),
                    finish_reason: None,
                    usage: None,
                }
            };
            
            let json = serde_json::to_string(&chunk).unwrap();
            Ok(axum::response::sse::Event::default()
                .event("token")
                .data(json))
        });
    
    Sse::new(stream)
}

pub async fn tokenize(
    State(_state): State<ApiState>,
    Json(request): Json<TokenizeRequest>,
) -> Json<TokenizeResponse> {
    debug!("🔤 Tokenizing text: len={}", request.text.len());
    
    // Mock tokenization - split by whitespace and hash
    let tokens: Vec<u32> = request.text
        .split_whitespace()
        .enumerate()
        .map(|(i, word)| {
            // Simple hash-based tokenization for demo
            let mut hash = 0u32;
            for byte in word.bytes() {
                hash = hash.wrapping_mul(31).wrapping_add(byte as u32);
            }
            hash % 32000 + i as u32 // Ensure reasonable token range
        })
        .collect();
    
    Json(TokenizeResponse { tokens })
}

pub async fn detokenize(
    State(_state): State<ApiState>,
    Json(request): Json<DetokenizeRequest>,
) -> Json<DetokenizeResponse> {
    debug!("🔢 Detokenizing {} tokens", request.tokens.len());
    
    // Mock detokenization
    let text = request.tokens
        .iter()
        .map(|&token| format!("token_{}", token))
        .collect::<Vec<_>>()
        .join(" ");
    
    Json(DetokenizeResponse { text })
}

pub async fn embeddings(
    State(_state): State<ApiState>,
    Json(request): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    debug!("🎯 Computing embeddings");
    
    // Mock embeddings response
    let embeddings = vec![vec![0.1, 0.2, 0.3, 0.4]; 1]; // Mock 4-dimensional embedding
    
    Json(serde_json::json!({
        "embeddings": embeddings,
        "model": "mock_model",
        "usage": {
            "prompt_tokens": 10,
            "total_tokens": 10
        }
    }))
}