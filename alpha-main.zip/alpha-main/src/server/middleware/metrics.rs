use axum::{
    extract::Request,
    response::Response,
};
use std::time::Instant;
use tower::{Layer, Service};
use tracing::{info, debug};

#[derive(Clone)]
pub struct MetricsLayer;

impl MetricsLayer {
    pub fn new() -> Self {
        Self
    }
}

impl<S> Layer<S> for MetricsLayer {
    type Service = MetricsService<S>;

    fn layer(&self, service: S) -> Self::Service {
        MetricsService { service }
    }
}

#[derive(Clone)]
pub struct MetricsService<S> {
    service: S,
}

impl<S> Service<Request> for MetricsService<S>
where
    S: Service<Request, Response = Response> + Clone + Send + 'static,
    S::Future: Send + 'static,
{
    type Response = Response;
    type Error = S::Error;
    type Future = std::pin::Pin<Box<dyn std::future::Future<Output = Result<Self::Response, Self::Error>> + Send>>;

    fn poll_ready(&mut self, cx: &mut std::task::Context<'_>) -> std::task::Poll<Result<(), Self::Error>> {
        self.service.poll_ready(cx)
    }

    fn call(&mut self, request: Request) -> Self::Future {
        let start_time = Instant::now();
        let method = request.method().clone();
        let uri = request.uri().clone();
        let mut service = self.service.clone();
        
        Box::pin(async move {
            let response = service.call(request).await?;
            let duration = start_time.elapsed();
            let status = response.status();
            
            // Log request metrics
            info!(
                method = %method,
                uri = %uri,
                status = %status.as_u16(),
                duration_ms = duration.as_millis(),
                "HTTP request completed"
            );
            
            // TODO: Send metrics to monitoring system
            debug!("Request metrics: {} {} {} {}ms", 
                   method, uri, status, duration.as_millis());
            
            Ok(response)
        })
    }
}