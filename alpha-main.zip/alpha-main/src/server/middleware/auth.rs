use axum::{
    extract::{Request, State},
    http::{header, StatusCode},
    middleware::Next,
    response::{IntoResponse, Response},
    Json,
};
use serde_json::json;
use std::sync::Arc;

use crate::auth::{JwtManager, JwtClaims, Capability, extract_token_from_header};
use crate::core::Error;

/// Authentication middleware that validates JWT tokens
pub struct AuthMiddleware {
    jwt_manager: Arc<JwtManager>,
    required_capability: Option<Capability>,
}

impl AuthMiddleware {
    pub fn new(jwt_manager: Arc<JwtManager>) -> Self {
        Self {
            jwt_manager,
            required_capability: None,
        }
    }
    
    pub fn require_capability(mut self, capability: Capability) -> Self {
        self.required_capability = Some(capability);
        self
    }
}

/// Extension type to store authenticated user claims in request
#[derive(Debug, Clone)]
pub struct AuthenticatedUser {
    pub claims: JwtClaims,
}

impl AuthenticatedUser {
    pub fn user_id(&self) -> &str {
        &self.claims.sub
    }
    
    pub fn session_id(&self) -> &str {
        &self.claims.session_id
    }
    
    pub fn has_capability(&self, capability: &Capability) -> bool {
        self.claims.capabilities().has(capability)
    }
    
    pub fn is_admin(&self) -> bool {
        matches!(self.claims.permissions, crate::auth::Permission::Admin)
    }
}

/// Middleware function for JWT authentication
pub async fn auth_middleware(
    mut request: Request,
    next: Next,
) -> Result<Response, Response> {
    // Extract JWT manager from app state (if available)
    // For now, we'll create a default one - in production this would come from state
    let jwt_manager = Arc::new(crate::auth::jwt::create_dev_token_manager());
    
    // Extract token from Authorization header
    let token = request
        .headers()
        .get(header::AUTHORIZATION)
        .and_then(|header| header.to_str().ok())
        .and_then(extract_token_from_header);
    
    let token = match token {
        Some(token) => token.to_string(),
        None => {
            return Err(auth_error("Missing or invalid authorization header"));
        }
    };
    
    // Verify the token
    let claims = match jwt_manager.verify_token(&token) {
        Ok(claims) => claims,
        Err(_) => {
            return Err(auth_error("Invalid or expired token"));
        }
    };
    
    // Add authenticated user to request extensions
    let auth_user = AuthenticatedUser { claims };
    request.extensions_mut().insert(auth_user);
    
    // Continue to the next middleware/handler
    Ok(next.run(request).await)
}

/// Middleware function for capability-based authorization
pub fn require_capability(capability: Capability) -> impl Fn(Request, Next) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<Response, Response>> + Send>> + Clone {
    move |request: Request, next: Next| {
        let required_cap = capability.clone();
        Box::pin(async move {
            // Get authenticated user from request extensions
            let auth_user = request
                .extensions()
                .get::<AuthenticatedUser>()
                .cloned();
            
            let auth_user = match auth_user {
                Some(user) => user,
                None => {
                    return Err(auth_error("Authentication required"));
                }
            };
            
            // Check if user has the required capability
            if !auth_user.has_capability(&required_cap) {
                return Err(authorization_error(&format!(
                    "Insufficient permissions. Required: {}",
                    required_cap
                )));
            }
            
            Ok(next.run(request).await)
        })
    }
}

/// Middleware function for admin-only access
pub async fn admin_only_middleware(
    request: Request,
    next: Next,
) -> Result<Response, Response> {
    let auth_user = request
        .extensions()
        .get::<AuthenticatedUser>()
        .cloned();
    
    let auth_user = match auth_user {
        Some(user) => user,
        None => {
            return Err(auth_error("Authentication required"));
        }
    };
    
    if !auth_user.is_admin() {
        return Err(authorization_error("Admin access required"));
    }
    
    Ok(next.run(request).await)
}

/// Optional authentication middleware - allows unauthenticated requests
pub async fn optional_auth_middleware(
    mut request: Request,
    next: Next,
) -> Response {
    let jwt_manager = Arc::new(crate::auth::jwt::create_dev_token_manager());
    
    // Try to extract and verify token, but don't fail if missing
    if let Some(token) = request
        .headers()
        .get(header::AUTHORIZATION)
        .and_then(|header| header.to_str().ok())
        .and_then(extract_token_from_header)
    {
        if let Ok(claims) = jwt_manager.verify_token(token) {
            let auth_user = AuthenticatedUser { claims };
            request.extensions_mut().insert(auth_user);
        }
    }
    
    next.run(request).await
}

/// Rate limiting middleware based on user/IP
pub async fn rate_limit_middleware(
    request: Request,
    next: Next,
) -> Result<Response, Response> {
    // Extract user ID or IP for rate limiting key
    let rate_limit_key = if let Some(auth_user) = request.extensions().get::<AuthenticatedUser>() {
        format!("user:{}", auth_user.user_id())
    } else {
        // Fall back to IP address
        "anonymous".to_string()
    };
    
    // TODO: Implement actual rate limiting logic
    // For now, just pass through
    tracing::debug!("Rate limiting check for: {}", rate_limit_key);
    
    Ok(next.run(request).await)
}

/// Helper functions for error responses
fn auth_error(message: &str) -> Response {
    let error_response = json!({
        "error": message,
        "code": "authentication_required",
        "status": 401
    });
    
    (StatusCode::UNAUTHORIZED, Json(error_response)).into_response()
}

fn authorization_error(message: &str) -> Response {
    let error_response = json!({
        "error": message,
        "code": "insufficient_permissions",
        "status": 403
    });
    
    (StatusCode::FORBIDDEN, Json(error_response)).into_response()
}

/// Helper to extract authenticated user from request
pub fn get_authenticated_user(request: &Request) -> Option<&AuthenticatedUser> {
    request.extensions().get::<AuthenticatedUser>()
}

/// Helper to require authenticated user from request
pub fn require_authenticated_user(request: &Request) -> Result<&AuthenticatedUser, Error> {
    get_authenticated_user(request)
        .ok_or_else(|| Error::auth("No authenticated user found in request".to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{body::Body, http::Request};
    use tower::ServiceExt;
    
    #[tokio::test]
    async fn test_auth_middleware_missing_token() {
        let request = Request::builder()
            .uri("/test")
            .body(Body::empty())
            .unwrap();
        
        let response = auth_middleware(request, |req| async move {
            axum::response::Response::new(Body::empty())
        }).await;
        
        assert!(response.is_err());
    }
    
    #[tokio::test]
    async fn test_auth_middleware_valid_token() {
        let jwt_manager = crate::auth::jwt::create_dev_token_manager();
        let token = jwt_manager.create_user_token(
            "test_user".to_string(),
            crate::auth::Permission::User,
            24,
        ).unwrap();
        
        let request = Request::builder()
            .uri("/test")
            .header(header::AUTHORIZATION, format!("Bearer {}", token))
            .body(Body::empty())
            .unwrap();
        
        let response = auth_middleware(request, |req| async move {
            // Check that user was added to extensions
            let auth_user = req.extensions().get::<AuthenticatedUser>();
            assert!(auth_user.is_some());
            assert_eq!(auth_user.unwrap().user_id(), "test_user");
            
            axum::response::Response::new(Body::empty())
        }).await;
        
        assert!(response.is_ok());
    }
}