pub mod http;
pub mod routes;
pub mod middleware;
pub mod websocket;

use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::info;

use crate::config::Config;
use crate::core::{Error, Result};
use crate::engine::TransformerEngine;
use crate::loader::GgufLoader;

pub use http::HttpServer;

pub struct Server {
    config: Config,
    engine: Option<Arc<RwLock<TransformerEngine>>>,
}

impl Server {
    pub async fn new(config: Config) -> Result<Self> {
        info!("🔧 Initializing server with config: {}", config.profile);
        
        Ok(Self {
            config,
            engine: None,
        })
    }
    
    pub async fn load_model(&mut self, model_path: &str) -> Result<()> {
        info!("📦 Loading model from: {}", model_path);
        
        let loader = GgufLoader::new(model_path)?;
        info!("✅ GGUF file loaded: {} parameters, {} MB", 
              loader.total_parameters(), 
              loader.file_size() / (1024 * 1024));
        
        let inference_config = crate::engine::InferenceConfig::default();
        let engine = TransformerEngine::new(loader, inference_config)?;
        
        self.engine = Some(Arc::new(RwLock::new(engine)));
        info!("🚀 Model loaded and ready for inference");
        
        Ok(())
    }
    
    pub async fn serve(self) -> Result<()> {
        let http_server = HttpServer::new(self.config, self.engine).await?;
        http_server.serve().await
    }
    
    pub fn engine(&self) -> Option<Arc<RwLock<TransformerEngine>>> {
        self.engine.clone()
    }
}