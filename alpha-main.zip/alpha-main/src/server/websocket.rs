use axum::extract::ws::{Message, WebSocket};
use futures::{sink::SinkExt, stream::StreamExt};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::{broadcast, RwLock};
use tracing::{debug, info, warn, error};
use uuid::Uuid;

use crate::core::{Error, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WebSocketMessage {
    pub id: String,
    pub message_type: MessageType,
    pub payload: serde_json::Value,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MessageType {
    // System events
    SystemMetrics,
    SystemStatus,
    LogEntry,
    
    // Model events
    ModelLoaded,
    ModelUnloaded,
    ModelError,
    
    // Inference events
    InferenceStart,
    InferenceToken,
    InferenceComplete,
    InferenceError,
    
    // Admin events
    ConfigUpdate,
    UserConnected,
    UserDisconnected,
    
    // Client messages
    Subscribe,
    Unsubscribe,
    Ping,
    Pong,
}

#[derive(Debug, Clone)]
pub struct WebSocketConnection {
    pub id: String,
    pub user_id: Option<String>,
    pub subscriptions: Vec<String>,
    pub connected_at: chrono::DateTime<chrono::Utc>,
}

pub struct WebSocketManager {
    connections: Arc<RwLock<HashMap<String, WebSocketConnection>>>,
    broadcast_tx: broadcast::Sender<WebSocketMessage>,
}

impl WebSocketManager {
    pub fn new() -> Self {
        let (broadcast_tx, _) = broadcast::channel(1000);
        
        Self {
            connections: Arc::new(RwLock::new(HashMap::new())),
            broadcast_tx,
        }
    }
    
    pub async fn handle_connection(
        &self,
        socket: WebSocket,
        user_id: Option<String>,
    ) {
        let connection_id = Uuid::new_v4().to_string();
        let connection = WebSocketConnection {
            id: connection_id.clone(),
            user_id: user_id.clone(),
            subscriptions: vec!["system".to_string()], // Default subscription
            connected_at: chrono::Utc::now(),
        };
        
        // Register connection
        {
            let mut connections = self.connections.write().await;
            connections.insert(connection_id.clone(), connection);
        }
        
        info!("🔌 WebSocket connection established: {} (user: {:?})", 
              connection_id, user_id);
        
        // Notify about new connection
        let _ = self.broadcast_message(WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::UserConnected,
            payload: serde_json::json!({
                "connection_id": connection_id,
                "user_id": user_id
            }),
            timestamp: chrono::Utc::now(),
        }).await;
        
        // Handle the connection
        let result = self.handle_socket(socket, connection_id.clone()).await;
        
        // Clean up connection
        {
            let mut connections = self.connections.write().await;
            connections.remove(&connection_id);
        }
        
        // Notify about disconnection
        let _ = self.broadcast_message(WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::UserDisconnected,
            payload: serde_json::json!({
                "connection_id": connection_id,
                "user_id": user_id
            }),
            timestamp: chrono::Utc::now(),
        }).await;
        
        if let Err(e) = result {
            warn!("WebSocket connection {} ended with error: {}", connection_id, e);
        } else {
            info!("🔌 WebSocket connection {} closed gracefully", connection_id);
        }
    }
    
    async fn handle_socket(&self, mut socket: WebSocket, connection_id: String) -> Result<()> {
        let mut broadcast_rx = self.broadcast_tx.subscribe();
        
        loop {
            tokio::select! {
                // Handle incoming messages from client
                msg = socket.recv() => {
                    match msg {
                        Some(Ok(Message::Text(text))) => {
                            if let Err(e) = self.handle_client_message(&connection_id, &text).await {
                                error!("Error handling client message: {}", e);
                                let error_msg = self.create_error_message(&e.to_string());
                                if socket.send(Message::Text(serde_json::to_string(&error_msg).unwrap())).await.is_err() {
                                    break;
                                }
                            }
                        }
                        Some(Ok(Message::Binary(_))) => {
                            warn!("Received binary message, ignoring");
                        }
                        Some(Ok(Message::Ping(data))) => {
                            if socket.send(Message::Pong(data)).await.is_err() {
                                break;
                            }
                        }
                        Some(Ok(Message::Pong(_))) => {
                            debug!("Received pong from {}", connection_id);
                        }
                        Some(Ok(Message::Close(_))) => {
                            debug!("Client {} requested close", connection_id);
                            break;
                        }
                        Some(Err(e)) => {
                            error!("WebSocket error for {}: {}", connection_id, e);
                            break;
                        }
                        None => {
                            debug!("WebSocket stream ended for {}", connection_id);
                            break;
                        }
                    }
                }
                
                // Handle broadcast messages
                msg = broadcast_rx.recv() => {
                    match msg {
                        Ok(broadcast_msg) => {
                            if self.should_send_to_connection(&connection_id, &broadcast_msg).await {
                                let json = serde_json::to_string(&broadcast_msg)
                                    .unwrap_or_else(|_| "{}".to_string());
                                
                                if socket.send(Message::Text(json)).await.is_err() {
                                    break;
                                }
                            }
                        }
                        Err(broadcast::error::RecvError::Lagged(_)) => {
                            warn!("WebSocket {} lagged behind broadcast", connection_id);
                        }
                        Err(broadcast::error::RecvError::Closed) => {
                            debug!("Broadcast channel closed");
                            break;
                        }
                    }
                }
            }
        }
        
        Ok(())
    }
    
    async fn handle_client_message(&self, connection_id: &str, text: &str) -> Result<()> {
        let msg: serde_json::Value = serde_json::from_str(text)
            .map_err(|e| Error::server(format!("Invalid JSON: {}", e)))?;
        
        let message_type = msg.get("type")
            .and_then(|t| t.as_str())
            .ok_or_else(|| Error::server("Missing message type".to_string()))?;
        
        match message_type {
            "subscribe" => {
                let topic = msg.get("topic")
                    .and_then(|t| t.as_str())
                    .ok_or_else(|| Error::server("Missing topic for subscription".to_string()))?;
                
                self.add_subscription(connection_id, topic).await;
                debug!("Connection {} subscribed to {}", connection_id, topic);
            }
            
            "unsubscribe" => {
                let topic = msg.get("topic")
                    .and_then(|t| t.as_str())
                    .ok_or_else(|| Error::server("Missing topic for unsubscription".to_string()))?;
                
                self.remove_subscription(connection_id, topic).await;
                debug!("Connection {} unsubscribed from {}", connection_id, topic);
            }
            
            "ping" => {
                // Send pong response
                let pong_msg = WebSocketMessage {
                    id: Uuid::new_v4().to_string(),
                    message_type: MessageType::Pong,
                    payload: serde_json::json!({}),
                    timestamp: chrono::Utc::now(),
                };
                
                // Send directly to this connection (not broadcast)
                // This would require a direct send mechanism
            }
            
            _ => {
                warn!("Unknown message type from {}: {}", connection_id, message_type);
            }
        }
        
        Ok(())
    }
    
    async fn should_send_to_connection(&self, connection_id: &str, msg: &WebSocketMessage) -> bool {
        let connections = self.connections.read().await;
        
        if let Some(connection) = connections.get(connection_id) {
            // Check if connection is subscribed to relevant topics
            match &msg.message_type {
                MessageType::SystemMetrics | MessageType::SystemStatus => {
                    connection.subscriptions.contains(&"system".to_string())
                }
                MessageType::ModelLoaded | MessageType::ModelUnloaded | MessageType::ModelError => {
                    connection.subscriptions.contains(&"model".to_string())
                }
                MessageType::InferenceStart | MessageType::InferenceToken | 
                MessageType::InferenceComplete | MessageType::InferenceError => {
                    connection.subscriptions.contains(&"inference".to_string())
                }
                MessageType::LogEntry => {
                    connection.subscriptions.contains(&"logs".to_string())
                }
                MessageType::ConfigUpdate => {
                    connection.subscriptions.contains(&"admin".to_string())
                }
                MessageType::UserConnected | MessageType::UserDisconnected => {
                    connection.subscriptions.contains(&"admin".to_string())
                }
                _ => true, // Send other message types to all connections
            }
        } else {
            false
        }
    }
    
    async fn add_subscription(&self, connection_id: &str, topic: &str) {
        let mut connections = self.connections.write().await;
        if let Some(connection) = connections.get_mut(connection_id) {
            if !connection.subscriptions.contains(&topic.to_string()) {
                connection.subscriptions.push(topic.to_string());
            }
        }
    }
    
    async fn remove_subscription(&self, connection_id: &str, topic: &str) {
        let mut connections = self.connections.write().await;
        if let Some(connection) = connections.get_mut(connection_id) {
            connection.subscriptions.retain(|t| t != topic);
        }
    }
    
    pub async fn broadcast_message(&self, message: WebSocketMessage) -> Result<()> {
        self.broadcast_tx.send(message)
            .map_err(|e| Error::server(format!("Failed to broadcast message: {}", e)))?;
        Ok(())
    }
    
    pub async fn broadcast_system_metrics(&self, metrics: serde_json::Value) -> Result<()> {
        let message = WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::SystemMetrics,
            payload: metrics,
            timestamp: chrono::Utc::now(),
        };
        
        self.broadcast_message(message).await
    }
    
    pub async fn broadcast_log_entry(&self, level: &str, message: &str, module: &str) -> Result<()> {
        let log_msg = WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::LogEntry,
            payload: serde_json::json!({
                "level": level,
                "message": message,
                "module": module,
                "timestamp": chrono::Utc::now()
            }),
            timestamp: chrono::Utc::now(),
        };
        
        self.broadcast_message(log_msg).await
    }
    
    pub async fn broadcast_inference_token(&self, token: u32, text: &str) -> Result<()> {
        let message = WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::InferenceToken,
            payload: serde_json::json!({
                "token": token,
                "text": text
            }),
            timestamp: chrono::Utc::now(),
        };
        
        self.broadcast_message(message).await
    }
    
    pub async fn get_connection_count(&self) -> usize {
        let connections = self.connections.read().await;
        connections.len()
    }
    
    pub async fn get_connections(&self) -> Vec<WebSocketConnection> {
        let connections = self.connections.read().await;
        connections.values().cloned().collect()
    }
    
    fn create_error_message(&self, error: &str) -> WebSocketMessage {
        WebSocketMessage {
            id: Uuid::new_v4().to_string(),
            message_type: MessageType::InferenceError,
            payload: serde_json::json!({
                "error": error
            }),
            timestamp: chrono::Utc::now(),
        }
    }
}

impl Default for WebSocketManager {
    fn default() -> Self {
        Self::new()
    }
}