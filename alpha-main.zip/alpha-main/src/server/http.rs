use axum::{
    extract::DefaultBodyLimit,
    http::{header, Method, StatusCode},
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use std::sync::Arc;
use tokio::sync::RwLock;
use tower::ServiceBuilder;
use tower_http::{
    cors::{Any, CorsLayer},
    trace::TraceLayer,
    services::ServeDir,
};
use tracing::{info, error};

use crate::config::Config;
use crate::core::{Error, Result};
use crate::engine::TransformerEngine;
use crate::server::{routes, middleware};

pub struct HttpServer {
    config: Config,
    engine: Option<Arc<RwLock<TransformerEngine>>>,
    app: Router,
}

impl HttpServer {
    pub async fn new(
        config: Config,
        engine: Option<Arc<RwLock<TransformerEngine>>>,
    ) -> Result<Self> {
        let app = Self::build_router(&config, engine.clone()).await?;
        
        Ok(Self {
            config,
            engine,
            app,
        })
    }
    
    async fn build_router(
        config: &Config,
        engine: Option<Arc<RwLock<TransformerEngine>>>,
    ) -> Result<Router> {
        let mut app = Router::new();
        
        // Health check endpoint
        app = app.route("/health", get(health_check));
        
        // API routes
        app = app.nest("/api", Self::api_routes(engine.clone()));
        
        // Admin UI routes (if enabled)
        if config.admin.ui_enabled {
            app = app.nest("/admin", Self::admin_routes());
        }
        
        // Static file serving for UI assets
        if config.admin.ui_enabled {
            app = app.nest_service("/static", ServeDir::new("ui/dist"));
        }
        
        // Apply middleware
        let middleware_stack = ServiceBuilder::new()
            .layer(TraceLayer::new_for_http())
            .layer(DefaultBodyLimit::max(10 * 1024 * 1024)) // 10MB limit
            .layer(middleware::request_id::RequestIdLayer::new())
            .layer(middleware::metrics::MetricsLayer::new());
        
        // CORS configuration
        let cors = if config.server.cors_enabled {
            CorsLayer::new()
                .allow_origin(Any)
                .allow_methods([Method::GET, Method::POST, Method::PUT, Method::DELETE])
                .allow_headers([header::CONTENT_TYPE, header::AUTHORIZATION])
        } else {
            CorsLayer::permissive()
        };
        
        app = app
            .layer(middleware_stack)
            .layer(cors);
        
        Ok(app)
    }
    
    fn api_routes(engine: Option<Arc<RwLock<TransformerEngine>>>) -> Router {
        Router::new()
            .route("/models", get(routes::api::list_models))
            .route("/models/load", post(routes::api::load_model))
            .route("/models/unload", post(routes::api::unload_model))
            .route("/models/info", get(routes::api::model_info))
            .route("/infer", post(routes::api::infer))
            .route("/infer/stream", post(routes::api::infer_stream))
            .route("/tokenize", post(routes::api::tokenize))
            .route("/detokenize", post(routes::api::detokenize))
            .route("/embeddings", post(routes::api::embeddings))
            .with_state(routes::api::ApiState { engine })
    }
    
    fn admin_routes() -> Router {
        Router::new()
            .route("/", get(routes::admin::admin_ui))
            .route("/api/system/info", get(routes::admin::system_info))
            .route("/api/system/metrics", get(routes::admin::system_metrics))
            .route("/api/logs", get(routes::admin::get_logs))
            .route("/api/config", get(routes::admin::get_config))
            .route("/api/config", post(routes::admin::update_config))
            .route("/ws", get(routes::admin::websocket_handler))
    }
    
    pub async fn serve(self) -> Result<()> {
        let addr = format!("{}:{}", self.config.server.host, self.config.server.port);
        let listener = tokio::net::TcpListener::bind(&addr).await
            .map_err(|e| Error::server(format!("Failed to bind to {}: {}", addr, e)))?;
        
        info!("🌐 HTTP server listening on {}", addr);
        info!("📱 Admin UI: http://{}/admin", addr);
        info!("🔗 API docs: http://{}/api", addr);
        
        axum::serve(listener, self.app)
            .await
            .map_err(|e| Error::server(format!("Server error: {}", e)))?;
        
        Ok(())
    }
}

async fn health_check() -> impl IntoResponse {
    Json(serde_json::json!({
        "status": "healthy",
        "timestamp": chrono::Utc::now().to_rfc3339(),
        "version": env!("CARGO_PKG_VERSION"),
        "uptime": std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs()
    }))
}