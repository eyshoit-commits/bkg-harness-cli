use clap::Parser;
use std::path::PathBuf;
use tracing::{info, warn};

mod config;
mod core;
mod engine;
mod loader;
mod server;
mod simd;
mod tensor;
mod ui;
mod auth;
mod admin;

use config::Config;
use core::logging;
use server::Server;
use core::Result;

#[derive(Parser)]
#[command(name = "llm-loader")]
#[command(about = "High-performance LLM inference server with cyberpunk Admin UI")]
#[command(version = "0.2.0-alpha")]
pub struct Args {
    /// Configuration file path
    #[arg(short, long, value_name = "FILE")]
    config: Option<PathBuf>,
    
    /// Server port
    #[arg(short, long, default_value = "8080")]
    port: u16,
    
    /// Log level
    #[arg(long, default_value = "info")]
    log_level: String,
    
    /// Enable admin UI
    #[arg(long)]
    admin_ui: bool,
    
    /// Model directory
    #[arg(long, default_value = "./models")]
    model_dir: PathBuf,
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();
    
    // Initialize logging
    logging::init(&args.log_level).map_err(|e| core::Error::internal(e.to_string()))?;
    
    info!("🚀 LLM-Loader v0.2.0-alpha starting...");
    info!("⚡ Cyberpunk-themed inference server initializing");
    
    // Load configuration
    let config = Config::load(args.config.as_deref(), &args).await?;
    info!("📋 Configuration loaded: {}", config.profile);
    
    // Create and start server
    let server = Server::new(config).await?;
    
    info!("🌐 Server listening on port {}", args.port);
    if args.admin_ui {
        info!("🎮 Admin UI available at http://localhost:{}/admin", args.port);
    }
    
    // Graceful shutdown handling
    let shutdown = async {
        tokio::signal::ctrl_c()
            .await
            .expect("Failed to install CTRL+C signal handler");
        warn!("🛑 Shutdown signal received");
    };
    
    tokio::select! {
        result = server.serve() => {
            if let Err(e) = result {
                tracing::error!("💥 Server error: {}", e);
                return Err(e);
            }
        }
        _ = shutdown => {
            info!("👋 Shutting down gracefully...");
        }
    }
    
    Ok(())
}