use std::collections::HashMap;
use std::fs::File;
use std::path::Path;
use std::sync::Arc;
use byteorder::{LittleEndian, ReadBytesExt};
use memmap2::Mmap;
use serde::{Deserialize, Serialize};

use crate::core::{Error, Result};
use crate::tensor::{DType, Shape, TensorView};

const GGUF_MAGIC: u32 = 0x46554747; // "GGUF"
const GGUF_VERSION: u32 = 3;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GgufMetadata {
    pub version: u32,
    pub tensor_count: u64,
    pub metadata_kv_count: u64,
    pub metadata: HashMap<String, GgufValue>,
    pub tensors: HashMap<String, TensorInfo>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TensorInfo {
    pub name: String,
    pub dimensions: Vec<u64>,
    pub dtype: DType,
    pub offset: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum GgufValue {
    UInt8(u8),
    Int8(i8),
    UInt16(u16),
    Int16(i16),
    UInt32(u32),
    Int32(i32),
    Float32(f32),
    Bool(bool),
    String(String),
    Array(Vec<GgufValue>),
    UInt64(u64),
    Int64(i64),
    Float64(f64),
}

pub struct GgufLoader {
    file_path: std::path::PathBuf,
    mmap: Arc<Mmap>,
    metadata: GgufMetadata,
    data_offset: usize,
}

impl GgufLoader {
    pub fn new(path: impl AsRef<Path>) -> Result<Self> {
        let file_path = path.as_ref().to_path_buf();
        let file = File::open(&file_path)?;
        let mmap = unsafe { Mmap::map(&file)? };
        let mmap = Arc::new(mmap);
        
        let mut cursor = std::io::Cursor::new(&**mmap);
        
        // Read and verify magic number
        let magic = cursor.read_u32::<LittleEndian>()?;
        if magic != GGUF_MAGIC {
            return Err(Error::gguf(format!(
                "Invalid GGUF magic number: 0x{:08x}", magic
            )));
        }
        
        // Read version
        let version = cursor.read_u32::<LittleEndian>()?;
        if version != GGUF_VERSION {
            return Err(Error::gguf(format!(
                "Unsupported GGUF version: {}", version
            )));
        }
        
        // Read tensor and metadata counts
        let tensor_count = cursor.read_u64::<LittleEndian>()?;
        let metadata_kv_count = cursor.read_u64::<LittleEndian>()?;
        
        // Read metadata key-value pairs
        let mut metadata = HashMap::new();
        for _ in 0..metadata_kv_count {
            let key = Self::read_string(&mut cursor)?;
            let value_type = cursor.read_u32::<LittleEndian>()?;
            let value = Self::read_value(&mut cursor, value_type)?;
            metadata.insert(key, value);
        }
        
        // Read tensor information
        let mut tensors = HashMap::new();
        for _ in 0..tensor_count {
            let name = Self::read_string(&mut cursor)?;
            let n_dimensions = cursor.read_u32::<LittleEndian>()?;
            
            let mut dimensions = Vec::new();
            for _ in 0..n_dimensions {
                dimensions.push(cursor.read_u64::<LittleEndian>()?);
            }
            
            let dtype_raw = cursor.read_u32::<LittleEndian>()?;
            let dtype = DType::from(dtype_raw);
            let offset = cursor.read_u64::<LittleEndian>()?;
            
            let tensor_info = TensorInfo {
                name: name.clone(),
                dimensions,
                dtype,
                offset,
            };
            
            tensors.insert(name, tensor_info);
        }
        
        // Calculate data offset (align to 32 bytes)
        let header_size = cursor.position() as usize;
        let data_offset = (header_size + 31) & !31;
        
        let gguf_metadata = GgufMetadata {
            version,
            tensor_count,
            metadata_kv_count,
            metadata,
            tensors,
        };
        
        Ok(Self {
            file_path,
            mmap,
            metadata: gguf_metadata,
            data_offset,
        })
    }
    
    pub fn metadata(&self) -> &GgufMetadata {
        &self.metadata
    }
    
    pub fn tensor_names(&self) -> Vec<&String> {
        self.metadata.tensors.keys().collect()
    }
    
    pub fn get_tensor(&self, name: &str) -> Result<TensorView> {
        let tensor_info = self.metadata.tensors.get(name)
            .ok_or_else(|| Error::gguf(format!("Tensor '{}' not found", name)))?;
        
        let shape = Shape::new(
            tensor_info.dimensions.iter().map(|&d| d as usize).collect()
        );
        
        let offset = self.data_offset + tensor_info.offset as usize;
        
        Ok(TensorView::new(
            name.to_string(),
            tensor_info.dtype,
            shape,
            Arc::clone(&self.mmap),
            offset,
        ))
    }
    
    pub fn get_tensor_info(&self, name: &str) -> Option<&TensorInfo> {
        self.metadata.tensors.get(name)
    }
    
    pub fn get_metadata_value(&self, key: &str) -> Option<&GgufValue> {
        self.metadata.metadata.get(key)
    }
    
    pub fn get_metadata_string(&self, key: &str) -> Option<&str> {
        if let Some(GgufValue::String(s)) = self.get_metadata_value(key) {
            Some(s)
        } else {
            None
        }
    }
    
    pub fn get_metadata_u32(&self, key: &str) -> Option<u32> {
        match self.get_metadata_value(key) {
            Some(GgufValue::UInt32(v)) => Some(*v),
            Some(GgufValue::Int32(v)) => Some(*v as u32),
            _ => None,
        }
    }
    
    pub fn get_metadata_f32(&self, key: &str) -> Option<f32> {
        if let Some(GgufValue::Float32(v)) = self.get_metadata_value(key) {
            Some(*v)
        } else {
            None
        }
    }
    
    fn read_string(cursor: &mut std::io::Cursor<&[u8]>) -> Result<String> {
        let len = cursor.read_u64::<LittleEndian>()? as usize;
        let mut buffer = vec![0u8; len];
        std::io::Read::read_exact(cursor, &mut buffer)?;
        String::from_utf8(buffer)
            .map_err(|e| Error::gguf(format!("Invalid UTF-8 string: {}", e)))
    }
    
    fn read_value(cursor: &mut std::io::Cursor<&[u8]>, value_type: u32) -> Result<GgufValue> {
        match value_type {
            0 => Ok(GgufValue::UInt8(cursor.read_u8()?)),
            1 => Ok(GgufValue::Int8(cursor.read_i8()?)),
            2 => Ok(GgufValue::UInt16(cursor.read_u16::<LittleEndian>()?)),
            3 => Ok(GgufValue::Int16(cursor.read_i16::<LittleEndian>()?)),
            4 => Ok(GgufValue::UInt32(cursor.read_u32::<LittleEndian>()?)),
            5 => Ok(GgufValue::Int32(cursor.read_i32::<LittleEndian>()?)),
            6 => Ok(GgufValue::Float32(cursor.read_f32::<LittleEndian>()?)),
            7 => Ok(GgufValue::Bool(cursor.read_u8()? != 0)),
            8 => Ok(GgufValue::String(Self::read_string(cursor)?)),
            9 => {
                let array_type = cursor.read_u32::<LittleEndian>()?;
                let array_len = cursor.read_u64::<LittleEndian>()? as usize;
                let mut array = Vec::with_capacity(array_len);
                for _ in 0..array_len {
                    array.push(Self::read_value(cursor, array_type)?);
                }
                Ok(GgufValue::Array(array))
            }
            10 => Ok(GgufValue::UInt64(cursor.read_u64::<LittleEndian>()?)),
            11 => Ok(GgufValue::Int64(cursor.read_i64::<LittleEndian>()?)),
            12 => Ok(GgufValue::Float64(cursor.read_f64::<LittleEndian>()?)),
            _ => Err(Error::gguf(format!("Unknown GGUF value type: {}", value_type))),
        }
    }
    
    pub fn file_path(&self) -> &Path {
        &self.file_path
    }
    
    pub fn file_size(&self) -> usize {
        self.mmap.len()
    }
    
    pub fn tensor_count(&self) -> usize {
        self.metadata.tensors.len()
    }
    
    pub fn total_parameters(&self) -> u64 {
        self.metadata.tensors.values()
            .map(|info| info.dimensions.iter().product::<u64>())
            .sum()
    }
}