use reqwest::{Client, Response, header::{HeaderValue, RANGE, CONTENT_RANGE}};
use sha2::{Sha256, Digest};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write, Seek, SeekFrom};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};
use tokio::time::sleep;
use tracing::{debug, info, warn, error};
use serde::{Deserialize, Serialize};

use crate::core::{Error, Result, retry::RetryPolicy};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadProgress {
    pub url: String,
    pub total_size: Option<u64>,
    pub downloaded: u64,
    pub speed_bytes_per_sec: f64,
    pub eta_seconds: Option<u64>,
    pub status: DownloadStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DownloadStatus {
    Pending,
    Downloading,
    Paused,
    Completed,
    Failed(String),
    Verifying,
    Verified,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DownloadMetadata {
    pub url: String,
    pub filename: String,
    pub total_size: Option<u64>,
    pub expected_hash: Option<String>,
    pub hash_algorithm: String,
    pub chunks: Vec<ChunkInfo>,
    pub created_at: chrono::DateTime<chrono::Utc>,
    pub updated_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChunkInfo {
    pub start: u64,
    pub end: u64,
    pub downloaded: bool,
    pub hash: Option<String>,
}

pub struct ModelDownloader {
    client: Client,
    download_dir: PathBuf,
    chunk_size: u64,
    max_concurrent_chunks: usize,
    retry_policy: RetryPolicy,
    verify_integrity: bool,
}

impl ModelDownloader {
    pub fn new(download_dir: impl AsRef<Path>) -> Result<Self> {
        let client = Client::builder()
            .timeout(Duration::from_secs(30))
            .connect_timeout(Duration::from_secs(10))
            .user_agent("LLM-Loader/0.2.0-alpha")
            .build()
            .map_err(|e| Error::download(format!("Failed to create HTTP client: {}", e)))?;
        
        let download_dir = download_dir.as_ref().to_path_buf();
        std::fs::create_dir_all(&download_dir)
            .map_err(|e| Error::download(format!("Failed to create download directory: {}", e)))?;
        
        Ok(Self {
            client,
            download_dir,
            chunk_size: 8 * 1024 * 1024, // 8MB chunks
            max_concurrent_chunks: 4,
            retry_policy: RetryPolicy::default(),
            verify_integrity: true,
        })
    }
    
    pub fn with_chunk_size(mut self, chunk_size: u64) -> Self {
        self.chunk_size = chunk_size;
        self
    }
    
    pub fn with_max_concurrent_chunks(mut self, max_concurrent: usize) -> Self {
        self.max_concurrent_chunks = max_concurrent;
        self
    }
    
    pub fn with_retry_policy(mut self, retry_policy: RetryPolicy) -> Self {
        self.retry_policy = retry_policy;
        self
    }
    
    pub fn with_integrity_verification(mut self, verify: bool) -> Self {
        self.verify_integrity = verify;
        self
    }
    
    /// Download a model file with resumable support
    pub async fn download(
        &self,
        url: &str,
        filename: Option<&str>,
        expected_hash: Option<&str>,
    ) -> Result<PathBuf> {
        info!("📥 Starting download: {}", url);
        
        // Determine filename
        let filename = filename
            .map(|s| s.to_string())
            .unwrap_or_else(|| self.extract_filename_from_url(url));
        
        let file_path = self.download_dir.join(&filename);
        let metadata_path = self.download_dir.join(format!("{}.download", filename));
        
        // Load or create download metadata
        let mut metadata = if metadata_path.exists() {
            self.load_metadata(&metadata_path)?
        } else {
            self.create_metadata(url, &filename, expected_hash).await?
        };
        
        // Resume or start download
        let result = self.download_with_resume(&mut metadata, &file_path).await;
        
        match result {
            Ok(_) => {
                info!("✅ Download completed: {}", file_path.display());
                
                // Verify integrity if enabled and hash provided
                if self.verify_integrity && metadata.expected_hash.is_some() {
                    info!("🔍 Verifying file integrity...");
                    self.verify_file_integrity(&file_path, &metadata).await?;
                    info!("✅ File integrity verified");
                }
                
                // Clean up metadata file
                let _ = std::fs::remove_file(&metadata_path);
                
                Ok(file_path)
            }
            Err(e) => {
                error!("❌ Download failed: {}", e);
                // Save metadata for resume
                self.save_metadata(&metadata, &metadata_path)?;
                Err(e)
            }
        }
    }
    
    /// Get download progress for a file
    pub async fn get_progress(&self, filename: &str) -> Result<Option<DownloadProgress>> {
        let metadata_path = self.download_dir.join(format!("{}.download", filename));
        
        if !metadata_path.exists() {
            return Ok(None);
        }
        
        let metadata = self.load_metadata(&metadata_path)?;
        let file_path = self.download_dir.join(&metadata.filename);
        
        let downloaded = if file_path.exists() {
            std::fs::metadata(&file_path)
                .map(|m| m.len())
                .unwrap_or(0)
        } else {
            0
        };
        
        let progress = DownloadProgress {
            url: metadata.url.clone(),
            total_size: metadata.total_size,
            downloaded,
            speed_bytes_per_sec: 0.0, // Would need to track this in real implementation
            eta_seconds: None,
            status: if downloaded == metadata.total_size.unwrap_or(0) {
                DownloadStatus::Completed
            } else {
                DownloadStatus::Paused
            },
        };
        
        Ok(Some(progress))
    }
    
    /// Cancel an ongoing download
    pub async fn cancel_download(&self, filename: &str) -> Result<()> {
        let metadata_path = self.download_dir.join(format!("{}.download", filename));
        let file_path = self.download_dir.join(filename);
        
        // Remove partial file and metadata
        let _ = std::fs::remove_file(&file_path);
        let _ = std::fs::remove_file(&metadata_path);
        
        info!("🛑 Download cancelled: {}", filename);
        Ok(())
    }
    
    async fn create_metadata(
        &self,
        url: &str,
        filename: &str,
        expected_hash: Option<&str>,
    ) -> Result<DownloadMetadata> {
        // Get file size from HEAD request
        let response = self.retry_policy.execute(|| async {
            self.client.head(url).send().await
        }).await
        .map_err(|e| Error::download(format!("Failed to get file info: {}", e)))?;
        
        let total_size = response
            .headers()
            .get("content-length")
            .and_then(|h| h.to_str().ok())
            .and_then(|s| s.parse().ok());
        
        let supports_ranges = response
            .headers()
            .get("accept-ranges")
            .map(|h| h.to_str().unwrap_or(""))
            .unwrap_or("")
            .contains("bytes");
        
        if !supports_ranges {
            warn!("⚠️  Server doesn't support range requests, resume won't be available");
        }
        
        // Create chunks for parallel download
        let chunks = if let Some(size) = total_size {
            if supports_ranges && size > self.chunk_size {
                self.create_chunks(size)
            } else {
                vec![ChunkInfo {
                    start: 0,
                    end: size - 1,
                    downloaded: false,
                    hash: None,
                }]
            }
        } else {
            vec![ChunkInfo {
                start: 0,
                end: 0, // Unknown size
                downloaded: false,
                hash: None,
            }]
        };
        
        let now = chrono::Utc::now();
        Ok(DownloadMetadata {
            url: url.to_string(),
            filename: filename.to_string(),
            total_size,
            expected_hash: expected_hash.map(|s| s.to_string()),
            hash_algorithm: "sha256".to_string(),
            chunks,
            created_at: now,
            updated_at: now,
        })
    }
    
    fn create_chunks(&self, total_size: u64) -> Vec<ChunkInfo> {
        let mut chunks = Vec::new();
        let mut start = 0;
        
        while start < total_size {
            let end = std::cmp::min(start + self.chunk_size - 1, total_size - 1);
            chunks.push(ChunkInfo {
                start,
                end,
                downloaded: false,
                hash: None,
            });
            start = end + 1;
        }
        
        chunks
    }
    
    async fn download_with_resume(
        &self,
        metadata: &mut DownloadMetadata,
        file_path: &Path,
    ) -> Result<()> {
        // Open or create the file
        let mut file = OpenOptions::new()
            .create(true)
            .write(true)
            .read(true)
            .open(file_path)
            .map_err(|e| Error::download(format!("Failed to open file: {}", e)))?;
        
        // Set file size if known
        if let Some(total_size) = metadata.total_size {
            file.set_len(total_size)
                .map_err(|e| Error::download(format!("Failed to set file size: {}", e)))?;
        }
        
        let start_time = Instant::now();
        let mut total_downloaded = 0u64;
        
        // Download chunks
        for (chunk_idx, chunk) in metadata.chunks.iter_mut().enumerate() {
            if chunk.downloaded {
                total_downloaded += chunk.end - chunk.start + 1;
                continue;
            }
            
            debug!("📦 Downloading chunk {}/{}: {}-{}", 
                   chunk_idx + 1, metadata.chunks.len(), chunk.start, chunk.end);
            
            let chunk_data = self.download_chunk(&metadata.url, chunk.start, chunk.end).await?;
            
            // Write chunk to file
            file.seek(SeekFrom::Start(chunk.start))
                .map_err(|e| Error::download(format!("Failed to seek in file: {}", e)))?;
            
            file.write_all(&chunk_data)
                .map_err(|e| Error::download(format!("Failed to write chunk: {}", e)))?;
            
            file.sync_data()
                .map_err(|e| Error::download(format!("Failed to sync file: {}", e)))?;
            
            chunk.downloaded = true;
            total_downloaded += chunk_data.len() as u64;
            
            // Calculate and log progress
            if let Some(total_size) = metadata.total_size {
                let progress = (total_downloaded as f64 / total_size as f64) * 100.0;
                let elapsed = start_time.elapsed();
                let speed = total_downloaded as f64 / elapsed.as_secs_f64();
                
                info!("📊 Progress: {:.1}% ({:.2} MB/s)", 
                      progress, speed / (1024.0 * 1024.0));
            }
        }
        
        Ok(())
    }
    
    async fn download_chunk(&self, url: &str, start: u64, end: u64) -> Result<Vec<u8>> {
        self.retry_policy.execute(|| async {
            let range_header = if end > start {
                format!("bytes={}-{}", start, end)
            } else {
                format!("bytes={}-", start)
            };
            
            let response = self.client
                .get(url)
                .header(RANGE, range_header)
                .send()
                .await?;
            
            if !response.status().is_success() {
                return Err(reqwest::Error::from(response.error_for_status().unwrap_err()));
            }
            
            let bytes = response.bytes().await?;
            Ok(bytes.to_vec())
        }).await
        .map_err(|e| Error::download(format!("Failed to download chunk: {}", e)))
    }
    
    async fn verify_file_integrity(
        &self,
        file_path: &Path,
        metadata: &DownloadMetadata,
    ) -> Result<()> {
        let expected_hash = metadata.expected_hash.as_ref()
            .ok_or_else(|| Error::download("No expected hash provided".to_string()))?;
        
        let actual_hash = match metadata.hash_algorithm.as_str() {
            "sha256" => self.calculate_sha256(file_path).await?,
            _ => return Err(Error::download(format!(
                "Unsupported hash algorithm: {}", metadata.hash_algorithm
            ))),
        };
        
        if actual_hash.to_lowercase() != expected_hash.to_lowercase() {
            return Err(Error::download(format!(
                "File integrity check failed. Expected: {}, Got: {}",
                expected_hash, actual_hash
            )));
        }
        
        Ok(())
    }
    
    async fn calculate_sha256(&self, file_path: &Path) -> Result<String> {
        let mut file = File::open(file_path)
            .map_err(|e| Error::download(format!("Failed to open file for hashing: {}", e)))?;
        
        let mut hasher = Sha256::new();
        let mut buffer = vec![0u8; 64 * 1024]; // 64KB buffer
        
        loop {
            let bytes_read = file.read(&mut buffer)
                .map_err(|e| Error::download(format!("Failed to read file for hashing: {}", e)))?;
            
            if bytes_read == 0 {
                break;
            }
            
            hasher.update(&buffer[..bytes_read]);
            
            // Yield to allow other tasks to run
            tokio::task::yield_now().await;
        }
        
        Ok(format!("{:x}", hasher.finalize()))
    }
    
    fn extract_filename_from_url(&self, url: &str) -> String {
        url.split('/')
            .last()
            .unwrap_or("model.gguf")
            .to_string()
    }
    
    fn load_metadata(&self, path: &Path) -> Result<DownloadMetadata> {
        let content = std::fs::read_to_string(path)
            .map_err(|e| Error::download(format!("Failed to read metadata: {}", e)))?;
        
        serde_json::from_str(&content)
            .map_err(|e| Error::download(format!("Failed to parse metadata: {}", e)))
    }
    
    fn save_metadata(&self, metadata: &DownloadMetadata, path: &Path) -> Result<()> {
        let content = serde_json::to_string_pretty(metadata)
            .map_err(|e| Error::download(format!("Failed to serialize metadata: {}", e)))?;
        
        std::fs::write(path, content)
            .map_err(|e| Error::download(format!("Failed to save metadata: {}", e)))?;
        
        Ok(())
    }
}

/// Utility functions for common model repositories
pub mod repositories {
    use super::*;
    
    /// Hugging Face model repository utilities
    pub struct HuggingFaceRepo;
    
    impl HuggingFaceRepo {
        pub fn model_url(repo: &str, filename: &str) -> String {
            format!("https://huggingface.co/{}/resolve/main/{}", repo, filename)
        }
        
        pub fn get_model_info(repo: &str) -> String {
            format!("https://huggingface.co/api/models/{}", repo)
        }
    }
    
    /// Common model URLs and hashes
    pub fn get_popular_models() -> HashMap<&'static str, (&'static str, Option<&'static str>)> {
        let mut models = HashMap::new();
        
        // Format: (url, optional_sha256_hash)
        models.insert(
            "llama-2-7b-chat.gguf",
            (
                "https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGUF/resolve/main/llama-2-7b-chat.q4_0.gguf",
                Some("abcd1234...")  // Placeholder hash
            )
        );
        
        models.insert(
            "mistral-7b-instruct.gguf",
            (
                "https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.1-GGUF/resolve/main/mistral-7b-instruct-v0.1.q4_0.gguf",
                Some("efgh5678...")  // Placeholder hash
            )
        );
        
        models
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;
    
    #[test]
    fn test_chunk_creation() {
        let downloader = ModelDownloader::new("./test").unwrap();
        let chunks = downloader.create_chunks(1000);
        
        assert!(!chunks.is_empty());
        assert_eq!(chunks[0].start, 0);
        assert_eq!(chunks.last().unwrap().end, 999);
    }
    
    #[test]
    fn test_filename_extraction() {
        let downloader = ModelDownloader::new("./test").unwrap();
        
        let filename = downloader.extract_filename_from_url(
            "https://example.com/models/llama-2-7b.gguf"
        );
        assert_eq!(filename, "llama-2-7b.gguf");
        
        let filename = downloader.extract_filename_from_url("https://example.com/");
        assert_eq!(filename, "model.gguf");
    }
    
    #[tokio::test]
    async fn test_metadata_serialization() {
        let temp_dir = TempDir::new().unwrap();
        let downloader = ModelDownloader::new(temp_dir.path()).unwrap();
        
        let metadata = DownloadMetadata {
            url: "https://example.com/test.gguf".to_string(),
            filename: "test.gguf".to_string(),
            total_size: Some(1000),
            expected_hash: Some("abcd1234".to_string()),
            hash_algorithm: "sha256".to_string(),
            chunks: vec![],
            created_at: chrono::Utc::now(),
            updated_at: chrono::Utc::now(),
        };
        
        let metadata_path = temp_dir.path().join("test.json");
        downloader.save_metadata(&metadata, &metadata_path).unwrap();
        
        let loaded = downloader.load_metadata(&metadata_path).unwrap();
        assert_eq!(loaded.url, metadata.url);
        assert_eq!(loaded.filename, metadata.filename);
    }
}