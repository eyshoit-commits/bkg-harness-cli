use llm_core::{config::load_config, log::init_tracing};

#[tokio::main]
async fn main() {
    let cfg = load_config().expect("load config");
    init_tracing(&cfg.logging.level, cfg.logging.json);
    tracing::info!(bind = %cfg.server.bind, "LLM Loader starting");
}
