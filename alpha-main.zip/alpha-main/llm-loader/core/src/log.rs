use tracing_subscriber::{fmt, EnvFilter};

pub fn init_tracing(default_level: &str, json: bool) {
    let env_filter = EnvFilter::try_from_default_env()
        .or_else(|_| EnvFilter::try_new(default_level))
        .unwrap_or_else(|_| EnvFilter::new("info"));

    if json {
        fmt()
            .with_env_filter(env_filter)
            .json()
            .with_current_span(false)
            .with_span_list(false)
            .with_ansi(false)
            .init();
    } else {
        fmt()
            .with_env_filter(env_filter)
            .with_target(false)
            .init();
    }
}
