use thiserror::Error;

#[derive(Error, Debug)]
pub enum LlmError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Config error: {0}")]
    Config(String),
    #[error("HTTP error: {0}")]
    Http(String),
    #[error("Other: {0}")]
    Other(String),
}

pub type LlmResult<T> = Result<T, LlmError>;
