use std::time::Duration;
use rand::{thread_rng, Rng};
use tokio::time::sleep;

#[derive(Clone, Copy, Debug)]
pub struct RetryPolicy {
    pub max_retries: usize,
    pub backoff: Duration,
    pub jitter_ratio: f64,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self { max_retries: 3, backoff: Duration::from_millis(250), jitter_ratio: 0.2 }
    }
}

pub async fn retry_async<F, Fut, T, E>(policy: RetryPolicy, mut op: F) -> Result<T, E>
where
    F: FnMut(usize) -> Fut,
    Fut: std::future::Future<Output = Result<T, E>>,
{
    let mut attempt: usize = 0;
    loop {
        match op(attempt).await {
            Ok(value) => return Ok(value),
            Err(err) if attempt < policy.max_retries => {
                let base = policy.backoff.mul_f64(2f64.powi(attempt as i32));
                let jitter = thread_rng().gen_range(0.0..(base.as_secs_f64() * policy.jitter_ratio));
                let delay = base + Duration::from_secs_f64(jitter);
                sleep(delay).await;
                attempt += 1;
            }
            Err(err) => return Err(err),
        }
    }
}
