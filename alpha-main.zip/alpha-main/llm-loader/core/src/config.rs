use serde::{Deserialize, Serialize};
use std::{env, fs};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub server: ServerConfig,
    pub logging: LoggingConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServerConfig {
    pub bind: String,
    pub cors_allow_origin: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LoggingConfig {
    pub level: String,
    pub json: bool,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            server: ServerConfig { bind: "127.0.0.1:8080".into(), cors_allow_origin: None },
            logging: LoggingConfig { level: "info".into(), json: false },
        }
    }
}

pub fn load_config() -> anyhow::Result<AppConfig> {
    let path = env::var("LLM_CONFIG").ok();
    if let Some(path) = path {
        let is_toml = path.ends_with(".toml");
        let content = fs::read_to_string(path)?;
        if is_toml {
            Ok(toml::from_str(&content)?)
        } else {
            Ok(serde_json::from_str(&content)?)
        }
    } else {
        Ok(AppConfig::default())
    }
}
