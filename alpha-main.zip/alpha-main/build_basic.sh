#!/bin/bash

# Basic build script for LLM-Loader
echo "🔧 Building LLM-Loader v0.2α..."

# Set Rust environment
source /usr/local/cargo/env

# Build the basic example
echo "📦 Building basic server example..."
cargo build --example basic_server --release

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo ""
    echo "🚀 To run the basic server:"
    echo "   ./target/release/examples/basic_server"
    echo ""
    echo "🌐 The server will be available at:"
    echo "   http://localhost:3000"
    echo ""
    echo "📖 Full documentation in README.md"
else
    echo "❌ Build failed. Check the errors above."
    exit 1
fi