#!/bin/bash

# Script to start a simple AI setup with Ollama

echo "Starting simple AI setup with Ollama..."

echo "Starting Ollama service..."
docker-compose -f docker-compose.simple-ai.yml up -d ollama

echo ""
echo "Waiting for Ollama to start..."
sleep 10

echo "Pulling a small AI model (TinyLlama)..."
docker-compose -f docker-compose.simple-ai.yml exec ollama ollama pull tinyllama:latest

echo ""
echo "Starting dashboard..."
docker-compose -f docker-compose.simple-ai.yml up -d dashboard

echo ""
echo "Services started:"
echo "- Ollama API: http://localhost:11434"
echo "- Dashboard: http://localhost:3001 (may take a minute to build)"
echo ""
echo "You can test the AI with:"
echo "curl http://localhost:11434/api/generate -d '{\"model\": \"tinyllama:latest\", \"prompt\": \"Hello, world!\", \"stream\": false}'"