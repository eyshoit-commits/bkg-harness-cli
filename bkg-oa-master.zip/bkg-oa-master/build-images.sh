#!/bin/bash

# Script to build Docker images for Open Agent

set -e

echo "Building Open Agent Docker images..."

# Create data directory if it doesn't exist
mkdir -p data/backend

# Build backend image
echo "Building backend image..."
docker build -f Dockerfile.simple -t openagent/backend:latest .

# Build dashboard image
echo "Building dashboard image..."
docker build -f dashboard/Dockerfile.simple -t openagent/dashboard:latest ./dashboard

echo "Images built successfully:"
echo "- openagent/backend:latest"
echo "- openagent/dashboard:latest"

echo ""
echo "To run the services:"
echo "  docker-compose -f docker-compose.prebuilt.yml up -d"