#!/bin/bash

# Script to test Ollama setup

echo "Testing Ollama setup..."

# Check if Ollama is running
if curl -s http://localhost:11434/api/tags | grep -q "tinydolphin"; then
    echo "✓ TinyDolphin model is available"
else
    echo "ℹ TinyDolphin model not found, pulling it now..."
    curl -s http://localhost:11434/api/pull -d '{"name": "tinydolphin:latest"}'
fi

# Test a simple prompt
echo "Testing TinyDolphin with a simple prompt..."
curl -s http://localhost:11434/api/generate -d '{
  "model": "tinydolphin:latest",
  "prompt": "Hello, world!",
  "stream": false
}' | jq -r '.response'

echo ""
echo "Test complete!"