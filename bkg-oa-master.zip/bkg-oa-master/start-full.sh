#!/bin/bash

# Script to start the full Open Agent setup with Ollama

set -e

echo "Starting Open Agent with Ollama..."

# Create data directories if they don't exist
mkdir -p data/backend
mkdir -p data/ollama

echo "Starting services..."
docker-compose -f docker-compose.light.yml up -d

echo ""
echo "Services started:"
echo "- Dashboard: http://localhost:3001"
echo "- Backend API: http://localhost:3000"
echo "- Ollama API: http://localhost:11434"
echo ""
echo "Note: AI models will be downloaded on demand when first used."
echo "You can check the progress with: docker-compose -f docker-compose.light.yml logs -f ollama"