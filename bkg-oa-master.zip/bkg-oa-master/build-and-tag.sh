#!/bin/bash

# Script to build and tag Docker images for Open Agent

set -e

echo "Building Open Agent Docker images..."

# Create data directory if it doesn't exist
mkdir -p data/backend

# Build dashboard image
echo "Building dashboard image..."
docker build -f dashboard/Dockerfile.simple -t openagent/dashboard:latest ./dashboard

echo "Dashboard image built successfully!"

# For the backend, let's use a pre-built approach
echo "Building backend image..."
docker build -f Dockerfile.prebuilt -t openagent/backend:latest .

echo "Backend image built successfully!"

echo ""
echo "Images built:"
echo "- openagent/backend:latest"
echo "- openagent/dashboard:latest"
echo ""
echo "To run the services:"
echo "  docker-compose -f docker-compose.prebuilt.yml up -d"