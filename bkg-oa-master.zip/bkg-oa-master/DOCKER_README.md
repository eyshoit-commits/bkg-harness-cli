# Docker Setup for Open Agent

This directory contains Docker configuration files for running Open Agent in containerized environments.

## Files

- `Dockerfile`: Production build for the Rust backend
- `Dockerfile.dev`: Development build for the Rust backend with hot reloading
- `Dockerfile.backend-full`: Full backend build with proper dependencies
- `docker-compose.yml`: Main composition file for production deployment
- `docker-compose.override.yml`: Development overrides for local development
- `docker-compose.simple.yml`: Simplified composition for faster deployment
- `docker-compose.prebuilt.yml`: Prebuilt images composition
- `docker-compose.full.yml`: Full composition with Ollama and Qwen3
- `docker-compose.minimal.yml`: Minimal composition for testing
- `Caddyfile`: Reverse proxy configuration with automatic HTTPS
- `dashboard/Dockerfile`: Production build for the Next.js dashboard
- `dashboard/Dockerfile.dev`: Development build for the Next.js dashboard
- `dashboard/Dockerfile.simple`: Simplified build for the Next.js dashboard

## Quick Start

### Development Mode

```bash
# Start development environment with hot reloading
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Full Setup with Ollama and Qwen3 (Recommended)

```bash
# Start the full setup with Ollama and Qwen3
./start-full.sh

# Or manually:
docker-compose -f docker-compose.full.yml up -d

# Check service health
./health-check.sh

# Test Ollama setup
./test-ollama.sh

# View logs
docker-compose -f docker-compose.full.yml logs -f

# Stop services
docker-compose -f docker-compose.full.yml down
```

### Production Mode

```bash
# Start production environment
docker-compose -f docker-compose.yml up -d

# View logs
docker-compose -f docker-compose.yml logs -f

# Stop services
docker-compose -f docker-compose.yml down
```

## Services

### Core Services

- **Backend**: Open Agent Rust backend on port 3000
- **Dashboard**: Next.js frontend on port 3001
- **Ollama**: AI model server on port 11434 with Qwen3:0.5b

### Environment Variables

The services can be configured through environment variables in the docker-compose files:

- `DEV_MODE`: Set to `true` for development, `false` for production
- `NEXT_PUBLIC_API_URL`: URL for the backend API (used by dashboard)
- `OLLAMA_HOST`: URL for the Ollama service (used by backend)
- `WORKING_DIR`: Working directory for the backend

### Ports

- `3000`: Backend API
- `3001`: Dashboard
- `11434`: Ollama API
- `80/443`: Caddy reverse proxy (HTTP/HTTPS)

## Data Persistence

Data is persisted in the `./data` directory:
- `./data/backend`: Backend data and library
- `./data/ollama`: Ollama models and data
- `./data/caddy`: Caddy certificates and configuration

## Customization

### Adding More AI Models

To add more models to Ollama:

```bash
# Pull a new model
curl http://localhost:11434/api/pull -d '{"name": "llama3:8b"}'

# List available models
curl http://localhost:11434/api/tags
```

### Domain Configuration

To use your own domain, uncomment and modify the HTTPS section in the `Caddyfile`:

```
agent.yourdomain.com {
    handle /api/* {
        reverse_proxy backend:3000
    }
    
    handle {
        reverse_proxy dashboard:3001
    }
    
    encode gzip zstd
    tls admin@yourdomain.com
}
```

Then update the `docker-compose.yml` to remove the port mappings for 80/443 if you're using an external proxy.

### Authentication

For production, make sure to set secure passwords and JWT secrets in the environment variables:

```yaml
environment:
  - DASHBOARD_PASSWORD=your_secure_password_here
  - JWT_SECRET=your_long_random_jwt_secret_here
  - DEV_MODE=false
```

## Scripts

Several helper scripts are provided:

- `start-full.sh`: Start the full setup with all services
- `health-check.sh`: Check the health of all services
- `test-ollama.sh`: Test the Ollama setup with Qwen3
- `build-and-tag.sh`: Build and tag Docker images