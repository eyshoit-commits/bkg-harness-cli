#!/bin/bash

# Health check script for Open Agent services

echo "Checking Open Agent services health..."

# Check backend
if curl -s -f http://localhost:3000/api/health > /dev/null; then
    echo "✓ Backend is healthy"
else
    echo "✗ Backend is not responding"
fi

# Check dashboard
if curl -s -f http://localhost:3001/ > /dev/null; then
    echo "✓ Dashboard is healthy"
else
    echo "✗ Dashboard is not responding"
fi

# Check Ollama
if curl -s -f http://localhost:11434/ > /dev/null; then
    echo "✓ Ollama is healthy"
else
    echo "✗ Ollama is not responding"
fi

echo ""
echo "Service status:"
docker-compose -f docker-compose.full.yml ps