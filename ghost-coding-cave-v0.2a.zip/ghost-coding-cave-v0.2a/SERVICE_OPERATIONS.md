# 🎛️ Service Operations Guide — Ghost Coding Cave v0.2a

**Practical Guide to Running, Monitoring, and Debugging All Services**

---

## 🚀 Quick Start (All Services)

### Option A: Full Development Stack (Recommended)

```bash
# Terminal 1: Start all TypeScript services with hot-reload
npm run dev

# Terminal 2: Start AI-Server
cd rust-core
HELPER_DB_PATH=/home/wind/code/ghost-coding-cave-v0.2a/data/helper.db cargo run --bin ai-server

# Terminal 3: Start Semantic-Store
cd services/semantic-store
cargo run --bin ss-api

# Terminal 4: Optional - Monitor all
watch -n 1 'lsof -i | grep LISTEN'
```

**Expected Output:**

```
Terminal 1:
> @ghost/api@0.1.0 dev
> turbo dev --filter=@ghost/api
...
[api] [Nest] 3000   11/31/2025, 10:30:15 AM   LOG [NestFactory] Application successfully started +123ms

> @ghost/dashboard@0.1.0 dev
[dashboard] ready - started server on 0.0.0.0:4004...

Terminal 2:
🚀 ai-server listening on http://0.0.0.0:5001

Terminal 3:
[2025-10-31 10:30:45] Semantic-Store API listening on 0.0.0.0:8443
```

### Option B: Individual Services Only

```bash
# Just AI-Server
cd rust-core
HELPER_DB_PATH=./data/helper.db cargo run --bin ai-server

# Just Semantic-Store
cd services/semantic-store
cargo run --bin ss-api

# Just TypeScript services
npm run dev
```

---

## ✅ Health Checks

### Quick Check (All Services)

```bash
#!/bin/bash
# save as check-services.sh && chmod +x check-services.sh

echo "🔍 Service Health Check\n"

# PostgreSQL
if psql $DATABASE_URL -c "SELECT 1" 2>/dev/null; then
  echo "✅ PostgreSQL: OK"
else
  echo "❌ PostgreSQL: DOWN"
fi

# Semantic-Store
if curl -s http://localhost:8443/health | jq . 2>/dev/null; then
  echo "✅ Semantic-Store: OK"
else
  echo "❌ Semantic-Store: DOWN"
fi

# AI-Server
if curl -s http://localhost:5001/health 2>/dev/null; then
  echo "✅ AI-Server: OK"
else
  echo "❌ AI-Server: DOWN"
fi

# NestJS API
if curl -s http://localhost:3000/health 2>/dev/null; then
  echo "✅ NestJS API: OK"
else
  echo "❌ NestJS API: DOWN"
fi

# Dashboard
if curl -s http://localhost:4004 2>/dev/null; then
  echo "✅ Dashboard: OK"
else
  echo "❌ Dashboard: DOWN"
fi
```

### Individual Health Checks

```bash
# PostgreSQL (requires psql installed)
psql $DATABASE_URL -c "SELECT version();"

# Semantic-Store HTTP
curl http://localhost:8443/health | jq .

# AI-Server
curl http://localhost:5001/health | jq .

# NestJS API
curl http://localhost:3000/health | jq .

# Dashboard (HTTP 200 = OK)
curl -I http://localhost:4004

# gRPC (requires grpcurl)
grpcurl -plaintext localhost:9443 list
```

---

## 🧪 Running Tests

### All Rust Tests (Complete Suite)

```bash
# Run all tests with output
cd rust-core
cargo test --workspace -- --nocapture

# Run specific crate
cargo test -p ai-server
cargo test -p semantic-adapter
cargo test -p ss-core

# Run specific test
cargo test test_list_capsules_with_filters

# Watch mode (requires cargo-watch)
cargo watch -x "test --workspace"
```

### Expected Output (20/20 Tests)

```
running 20 tests

test ai_server::tests::test_health_check ... ok
test ai_server::tests::test_init ... ok
test ai_server::tests::test_models_endpoint ... ok
test gateway::tests::test_api_key_auth ... ok
...
test result: ok. 20 passed; 0 failed; 0 ignored; 0 measured

   Compiling ai-server v0.1.0
    Finished test [unoptimized + debuginfo] target(s) in 12.34s
```

### TypeScript Tests

```bash
# All TypeScript tests
npm test

# Watch mode
npm run test:watch

# Specific workspace
npm test --filter=@ghost/api
npm test --filter=@ghost/dashboard
```

---

## 📊 Port Reference

| Service | Port | Protocol | Health | Status |
|---------|------|----------|--------|--------|
| NestJS API | 3000 | HTTP/WS | `/health` | ⏳ Compiled |
| AI-Server | 5001 | HTTP | `/health` | 🟢 Running |
| PostgreSQL | 5432 | psql | `SELECT 1` | 🐳 Docker |
| Gateway | 8080 | HTTP | `/health` | ✅ Ready |
| Semantic-Store HTTP | 8443 | HTTP | `/health` | ✅ Ready |
| Semantic-Store gRPC | 9443 | gRPC | list services | ✅ Ready |
| Dashboard | 4004 | HTTP | URL check | ⏳ Compiled |

### Check Port Availability

```bash
# Check if port is in use
lsof -i :5001      # AI-Server
lsof -i :3000      # API
lsof -i :4004      # Dashboard
lsof -i :8443      # Semantic-Store

# Kill process on port
fuser -k 5001/tcp

# View all listening ports
lsof -i -P -n | grep LISTEN
```

---

## 🔧 Configuration & Environment

### Essential Environment Variables

```bash
# Copy and customize
cat > .env.local << EOF
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/ghost_db
DATABASE_SHADOW_URL=postgresql://user:password@localhost:5432/ghost_db_shadow

# AI Services
HELPER_DB_PATH=/home/wind/code/ghost-coding-cave-v0.2a/data/helper.db
AI_SERVER_PORT=5001
AI_SERVER_THREADS=2

# Semantic Store
SEMANTIC_STORE_URL=http://localhost:8443
SEMANTIC_STORE_GRPC_URL=grpc://localhost:9443

# API
API_PORT=3000
API_HOST=0.0.0.0
JWT_SECRET=your-secret-key-here

# Dashboard
DASHBOARD_PORT=4004
NEXT_PUBLIC_API_URL=http://localhost:3000

# Logging
RUST_LOG=info
LOG_LEVEL=debug
EOF

# Load for current session
source .env.local
```

### Quick Verify Environment

```bash
echo "Checking environment setup..."
echo "HELPER_DB_PATH: $HELPER_DB_PATH"
echo "DATABASE_URL: ${DATABASE_URL:0:40}..."
echo "AI_SERVER_PORT: $AI_SERVER_PORT"
echo "Semantic-Store: $SEMANTIC_STORE_URL"
```

---

## 🐛 Troubleshooting

### AI-Server Won't Start

**Problem:** `Error: Cannot open database file`

```bash
# Solution 1: Create data directory
mkdir -p data
chmod 755 data

# Solution 2: Set absolute path
export HELPER_DB_PATH="/absolute/path/to/data/helper.db"
cd rust-core && cargo run --bin ai-server

# Verify
ls -la $HELPER_DB_PATH
```

### Semantic-Store Port Conflict

**Problem:** `Address already in use`

```bash
# Find process using port
lsof -i :8443

# Kill the process
kill -9 <PID>

# Or use different port
cd services/semantic-store
cargo run --bin ss-api -- --port 8444
```

### Database Connection Failed

**Problem:** `Connection refused to localhost:5432`

```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Start PostgreSQL
docker run -d --name postgres \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:15

# Verify connection
psql $DATABASE_URL -c "SELECT 1"
```

### NestJS API Compilation Error

**Problem:** `Cannot find module '@ghost/types'`

```bash
# Regenerate packages
npm run db:generate

# Rebuild
npm run build

# Clean and rebuild
rm -rf node_modules .turbo
npm install
npm run build
```

### Dashboard Not Loading

**Problem:** `http://localhost:4004 - Connection refused`

```bash
# Check if Next.js is running
lsof -i :4004

# Restart dashboard
npm run dev --filter=@ghost/dashboard

# Check for build errors
npm run build --filter=@ghost/dashboard
```

---

## 🔍 Debugging & Logs

### View Service Logs in Real-Time

```bash
# AI-Server with debug output
RUST_LOG=debug cargo run --bin ai-server

# With all spans
RUST_LOG=trace cargo run --bin ai-server

# Filter to specific module
RUST_LOG=ai_server=debug cargo run --bin ai-server

# Semantic-Store logs
cd services/semantic-store
RUST_LOG=debug cargo run --bin ss-api
```

### View NestJS Logs

```bash
# With verbose output
npm run dev -- --verbose

# Just API service
npm run dev --filter=@ghost/api -- --verbose

# Check recent logs
cat logs/*.log | tail -100
```

### Database Query Debugging

```bash
# Connect to database
psql $DATABASE_URL

# View tables
\dt

# View capsule data
SELECT * FROM capsules LIMIT 5;

# View users
SELECT id, email, role FROM "User" LIMIT 5;

# Enable query logging in Prisma
DATABASE_LOG=query npm run dev
```

---

## 📈 Performance Monitoring

### Monitor Resource Usage

```bash
# Watch system resources
watch -n 1 'ps aux | head -20'

# Memory usage per service
ps aux | grep -E "ai-server|ss-api|node|next" | awk '{print $3, $4, $11}'

# CPU usage (macOS)
top -b -n 1 | head -20

# CPU usage (Linux)
top -bn1 | head -20
```

### Benchmark Tests

```bash
# Run with timing
cargo test --workspace -- --nocapture --test-threads=1

# Measure build time
time cargo build --release --workspace

# Profile release build
cargo build --release
perf record ./target/release/ai-server
perf report
```

---

## 🔐 Security Checks

### Verify JWT Configuration

```bash
# Check if JWT_SECRET is set
echo $JWT_SECRET

# Generate strong secret (bash)
openssl rand -base64 32

# Generate strong secret (Node.js)
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

### Check API Key Management

```bash
# Connect to database
psql $DATABASE_URL

# List API keys
SELECT id, name, "allowedModels", "allowedActions" FROM "ApiKey" LIMIT 5;

# Check token limits
SELECT id, name, "tokenLimit", "tokensUsed" FROM "ApiKey" LIMIT 5;
```

### Security Headers Check

```bash
# Check NestJS API headers
curl -I http://localhost:3000/health | grep -i security

# Check CORS configuration
curl -H "Origin: http://localhost:4004" http://localhost:3000/health
```

---

## 🚀 Performance Tuning

### Optimize Rust Build

```bash
# Use release mode for benchmarks
cargo build --release
./target/release/ai-server

# Use lto (link-time optimization)
cargo build --release -Z build-std=std,panic_abort --target x86_64-unknown-linux-gnu

# Parallel compilation
CARGO_BUILD_JOBS=8 cargo build
```

### Optimize Node.js

```bash
# Use production mode
NODE_ENV=production npm run build

# Increase memory
NODE_OPTIONS="--max-old-space-size=4096" npm run dev

# Profile
node --prof start dev app
node --prof-process isolate-*.log > profile.txt
```

---

## 📋 Service Status Dashboard

### Create Simple Status Page

```bash
#!/bin/bash
# save as status.sh && chmod +x status.sh

clear
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     🎨 Ghost Coding Cave - Service Status Dashboard        ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

check_service() {
  local name=$1
  local url=$2
  local port=$3
  
  if curl -s "$url" > /dev/null 2>&1; then
    echo "✅ $name (Port $port): RUNNING"
  else
    echo "❌ $name (Port $port): DOWN"
  fi
}

echo "Services:"
check_service "PostgreSQL" "localhost:5432" "5432"
check_service "AI-Server" "http://localhost:5001/health" "5001"
check_service "Semantic-Store" "http://localhost:8443/health" "8443"
check_service "NestJS API" "http://localhost:3000/health" "3000"
check_service "Dashboard" "http://localhost:4004" "4004"

echo ""
echo "Running Processes:"
ps aux | grep -E "ai-server|ss-api|node|next" | grep -v grep | wc -l | xargs echo "Total processes:"
```

---

## 🎯 Common Tasks

### Restart All Services

```bash
# Kill all processes
pkill -f "npm run dev"
pkill -f "cargo run"

# Wait a moment
sleep 2

# Start again (see Quick Start section)
npm run dev  # Terminal 1
cd rust-core && HELPER_DB_PATH=./data/helper.db cargo run --bin ai-server  # Terminal 2
```

### Clear All Caches

```bash
# Rust caches
cd rust-core && cargo clean
cd ../services/semantic-store && cargo clean

# Node caches
npm run clean

# Build caches
rm -rf .turbo

# Prisma
npm run db:push -- --force-reset
```

### Update Dependencies

```bash
# Check for updates
npm outdated

# Update TypeScript deps
npm update

# Update Rust deps
cargo update

# Update specific package
npm update @nest/core
```

---

## 📚 Related Documentation

- **Services:** `docs/SERVICES_INTEGRATION.md`
- **Manifest:** `docs/SERVICES_MANIFEST.md`
- **Storage:** `docs/STORAGE_ENGINE.md`
- **Deployment:** `docs/DEPLOYMENT.md`
- **Setup:** `QUICK_START.md`

---

**Last Updated:** 31. Oktober 2025  
**Maintained By:** Copilot Agent  
**Version:** 1.0  
**Status:** ✅ Phase 1 Complete
