//! Orchestra management functionality for ghost.
//!
//! This module provides functionality for managing collections of cavees in a coordinated way,
//! similar to how container orchestration tools manage multiple containers. It handles the lifecycle
//! of multiple cavees defined in configuration, including starting them up, shutting them down,
//! and applying configuration changes.
//!
//! The main operations provided by this module are:
//! - `up`: Start up all cavees defined in configuration
//! - `down`: Gracefully shut down all running cavees
//! - `apply`: Reconcile running cavees with configuration

use crate::{
    config::{ghost, START_SCRIPT_NAME},
    GhostError, GhostResult,
};

#[cfg(feature = "cli")]
use console::style;
#[cfg(feature = "cli")]
use ghost_utils::term;
use ghost_utils::{GHOST_ENV_DIR, CAVE_DB_FILENAME};
use nix::{
    sys::signal::{self, Signal},
    unistd::Pid,
};
use once_cell::sync::Lazy;
#[cfg(feature = "cli")]
use std::io::{self, IsTerminal};
use std::{
    collections::HashMap,
    path::{Path, PathBuf},
    sync::RwLock,
    time::{Duration, Instant},
};

use super::{cave, config, db, menv};

//--------------------------------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------------------------------

/// TTL for cached directory sizes.
const DISK_SIZE_TTL: Duration = Duration::from_secs(30);

#[cfg(feature = "cli")]
const APPLY_CONFIG_MSG: &str = "Applying cave configuration";

#[cfg(feature = "cli")]
const START_CAVEES_MSG: &str = "Starting cavees";

#[cfg(feature = "cli")]
const STOP_CAVEES_MSG: &str = "Stopping cavees";

/// Global cache path -> (size, last_updated)
static DISK_SIZE_CACHE: Lazy<RwLock<HashMap<String, (u64, Instant)>>> =
    Lazy::new(|| RwLock::new(HashMap::new()));

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

/// Information about a cave's resource usage
#[derive(Debug, Clone)]
pub struct CaveStatus {
    /// The name of the cave
    pub name: String,

    /// Whether the cave is running
    pub running: bool,

    /// The PID of the supervisor process
    pub supervisor_pid: Option<u32>,

    /// The PID of the microVM process
    pub microvm_pid: Option<u32>,

    /// CPU usage percentage
    pub cpu_usage: Option<f32>,

    /// Memory usage in MiB
    pub memory_usage: Option<u64>,

    /// Disk usage of the RW layer in bytes
    pub disk_usage: Option<u64>,

    /// Rootfs paths
    pub rootfs_paths: Option<String>,
}

//--------------------------------------------------------------------------------------------------
// Functions
//--------------------------------------------------------------------------------------------------

/// Reconciles the running cavees with the configuration.
///
/// This function ensures that the set of running cavees matches what is defined in the
/// configuration by:
/// - Starting any cavees that are in the config but not running
/// - Stopping any cavees that are running but not in the config
///
/// The function uses a file-based lock to prevent concurrent apply operations.
/// If another apply operation is in progress, this function will fail immediately.
/// The lock is automatically released when the function completes or if it fails.
///
/// ## Arguments
///
/// * `project_dir` - Optional path to the project directory. If None, defaults to current directory
/// * `config_file` - Optional path to the ghost config file. If None, uses default filename
/// * `detach` - Whether to run cavees in detached mode (true) or with prefixed output (false)
///
/// ## Returns
///
/// Returns `GhostResult<()>` indicating success or failure. Possible failures include:
/// - Config file not found or invalid
/// - Database errors
/// - Cave start/stop failures
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     // Apply configuration changes from the default ghost.yaml
///     orchestra::apply(None, None, true).await?;
///
///     // Or specify a custom project directory and config file, in non-detached mode
///     orchestra::apply(
///         Some(&PathBuf::from("/path/to/project")),
///         Some("custom-config.yaml"),
///         false,
///     ).await?;
///     Ok(())
/// }
/// ```
pub async fn apply(
    project_dir: Option<&Path>,
    config_file: Option<&str>,
    detach: bool,
) -> GhostResult<()> {
    // Create spinner for CLI feedback
    #[cfg(feature = "cli")]
    let apply_config_sp = term::create_spinner(APPLY_CONFIG_MSG.to_string(), None, None);

    // Load the configuration first to validate it exists before acquiring lock
    let (config, canonical_project_dir, config_file) =
        match config::load_config(project_dir, config_file).await {
            Ok(result) => result,
            Err(e) => {
                #[cfg(feature = "cli")]
                term::finish_with_error(&apply_config_sp);
                return Err(e);
            }
        };

    // Ensure menv files exist
    let menv_path = canonical_project_dir.join(GHOST_ENV_DIR);
    if let Err(e) = menv::ensure_menv_files(&menv_path).await {
        #[cfg(feature = "cli")]
        term::finish_with_error(&apply_config_sp);
        return Err(e);
    }

    // Get database connection pool
    let db_path = menv_path.join(CAVE_DB_FILENAME);
    let pool = match db::get_or_create_pool(&db_path, &db::CAVE_DB_MIGRATOR).await {
        Ok(pool) => pool,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&apply_config_sp);
            return Err(e);
        }
    };

    // Get all cavees defined in config
    let config_cavees = config.get_cavees();

    // Get all running cavees from database
    let running_cavees = match db::get_running_config_cavees(&pool, &config_file).await {
        Ok(cavees) => cavees,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&apply_config_sp);
            return Err(e);
        }
    };
    let running_cave_names: Vec<String> = running_cavees.iter().map(|s| s.name.clone()).collect();

    // Collect cavees that need to be started
    let cavees_to_start: Vec<&String> = config_cavees
        .keys()
        .filter(|name| !running_cave_names.contains(*name))
        .collect();

    if cavees_to_start.is_empty() {
        tracing::info!("No new cavees to start");
    } else if detach {
        // Start cavees in detached mode
        for name in cavees_to_start {
            tracing::info!("starting cave: {}", name);
            if let Err(e) = cave::run(
                name,
                Some(START_SCRIPT_NAME),
                Some(&canonical_project_dir),
                Some(&config_file),
                vec![],
                true, // detached mode
                None,
                true,
            )
            .await
            {
                #[cfg(feature = "cli")]
                term::finish_with_error(&apply_config_sp);
                return Err(e);
            }
        }
    } else {
        // Start cavees in non-detached mode with multiplexed output
        let cave_commands = match prepare_cave_commands(
            &cavees_to_start,
            Some(START_SCRIPT_NAME),
            &canonical_project_dir,
            &config_file,
        )
        .await
        {
            Ok(commands) => commands,
            Err(e) => {
                #[cfg(feature = "cli")]
                term::finish_with_error(&apply_config_sp);
                return Err(e);
            }
        };

        if !cave_commands.is_empty() {
            // Finish the spinner before running commands with output
            #[cfg(feature = "cli")]
            apply_config_sp.finish();

            if let Err(e) = run_commands_with_prefixed_output(cave_commands).await {
                return Err(e);
            }

            // Return early as we've already finished the spinner
            return Ok(());
        }
    }

    // Stop cavees that are active but not in config
    for cave in running_cavees {
        if !config_cavees.contains_key(&cave.name) {
            tracing::info!("stopping cave: {}", cave.name);
            if let Err(e) = signal::kill(Pid::from_raw(cave.supervisor_pid as i32), Signal::SIGTERM)
            {
                #[cfg(feature = "cli")]
                term::finish_with_error(&apply_config_sp);
                return Err(e.into());
            }
        }
    }

    #[cfg(feature = "cli")]
    apply_config_sp.finish();

    Ok(())
}

/// Starts specified cavees from the configuration if they are not already running.
///
/// This function ensures that the specified cavees are running by:
/// - Starting any specified cavees that are in the config but not running
/// - Ignoring cavees that are not specified or already running
///
/// ## Arguments
///
/// * `cave_names` - List of cave names to start
/// * `project_dir` - Optional path to the project directory. If None, defaults to current directory
/// * `config_file` - Optional path to the ghost config file. If None, uses default filename
/// * `detach` - Whether to run cavees in detached mode (true) or with prefixed output (false)
///
/// ## Returns
///
/// Returns `GhostResult<()>` indicating success or failure. Possible failures include:
/// - Config file not found or invalid
/// - Database errors
/// - Cave start failures
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     // Start specific cavees from the default ghost.yaml in detached mode
///     orchestra::up(vec!["cave1".to_string(), "cave2".to_string()], None, None, true).await?;
///
///     // Or specify a custom project directory and config file, in non-detached mode
///     orchestra::up(
///         vec!["cave1".to_string()],
///         Some(&PathBuf::from("/path/to/project")),
///         Some("custom-config.yaml"),
///         false,
///     ).await?;
///     Ok(())
/// }
/// ```
pub async fn up(
    cave_names: Vec<String>,
    project_dir: Option<&Path>,
    config_file: Option<&str>,
    detach: bool,
) -> GhostResult<()> {
    // Create spinner for CLI feedback
    #[cfg(feature = "cli")]
    let start_cavees_sp = term::create_spinner(START_CAVEES_MSG.to_string(), None, None);

    // Load the configuration first to validate it exists
    let (config, canonical_project_dir, config_file) =
        match config::load_config(project_dir, config_file).await {
            Ok(result) => result,
            Err(e) => {
                #[cfg(feature = "cli")]
                term::finish_with_error(&start_cavees_sp);
                return Err(e);
            }
        };

    // Get all cavees defined in config
    let config_cavees = config.get_cavees();

    // Use all cave names from config if no names were specified
    let cave_names_to_start = if cave_names.is_empty() {
        // Use all cave names from config
        config_cavees.keys().cloned().collect()
    } else {
        // Validate all cave names exist in config before proceeding
        if let Err(e) =
            validate_cave_names(&cave_names, &config, &canonical_project_dir, &config_file)
        {
            #[cfg(feature = "cli")]
            term::finish_with_error(&start_cavees_sp);
            return Err(e);
        }

        cave_names
    };

    // Ensure menv files exist
    let menv_path = canonical_project_dir.join(GHOST_ENV_DIR);
    if let Err(e) = menv::ensure_menv_files(&menv_path).await {
        #[cfg(feature = "cli")]
        term::finish_with_error(&start_cavees_sp);
        return Err(e);
    }

    // Get database connection pool
    let db_path = menv_path.join(CAVE_DB_FILENAME);
    let pool = match db::get_or_create_pool(&db_path, &db::CAVE_DB_MIGRATOR).await {
        Ok(pool) => pool,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&start_cavees_sp);
            return Err(e);
        }
    };

    // Get all running cavees from database
    let running_cavees = match db::get_running_config_cavees(&pool, &config_file).await {
        Ok(cavees) => cavees,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&start_cavees_sp);
            return Err(e);
        }
    };
    let running_cave_names: Vec<String> = running_cavees.iter().map(|s| s.name.clone()).collect();

    // Collect cavees that need to be started
    let cavees_to_start: Vec<&String> = config_cavees
        .keys()
        .filter(|name| cave_names_to_start.contains(*name) && !running_cave_names.contains(*name))
        .collect();

    if cavees_to_start.is_empty() {
        tracing::info!("No new cavees to start");
        #[cfg(feature = "cli")]
        start_cavees_sp.finish();
        return Ok(());
    }

    if detach {
        // Start specified cavees in detached mode
        for name in cavees_to_start {
            tracing::info!("starting cave: {}", name);
            if let Err(e) = cave::run(
                name,
                None,
                Some(&canonical_project_dir),
                Some(&config_file),
                vec![],
                true, // detached mode
                None,
                true,
            )
            .await
            {
                #[cfg(feature = "cli")]
                term::finish_with_error(&start_cavees_sp);
                return Err(e);
            }
        }
    } else {
        // Start cavees in non-detached mode with multiplexed output
        let cave_commands = match prepare_cave_commands(
            &cavees_to_start,
            None, // Start script is None for normal up
            &canonical_project_dir,
            &config_file,
        )
        .await
        {
            Ok(commands) => commands,
            Err(e) => {
                #[cfg(feature = "cli")]
                term::finish_with_error(&start_cavees_sp);
                return Err(e);
            }
        };

        if !cave_commands.is_empty() {
            // Finish the spinner before running commands with output
            #[cfg(feature = "cli")]
            start_cavees_sp.finish();

            if let Err(e) = run_commands_with_prefixed_output(cave_commands).await {
                return Err(e);
            }

            // Return early as we've already finished the spinner
            return Ok(());
        }
    }

    #[cfg(feature = "cli")]
    start_cavees_sp.finish();

    Ok(())
}

/// Stops specified cavees that are both in the configuration and currently running.
///
/// This function ensures that the specified cavees are stopped by:
/// - Stopping any specified cavees that are both in the config and currently running
/// - Ignoring cavees that are not specified, not in config, or not running
///
/// ## Arguments
///
/// * `cave_names` - List of cave names to stop
/// * `project_dir` - Optional path to the project directory. If None, defaults to current directory
/// * `config_file` - Optional path to the ghost config file. If None, uses default filename
///
/// ## Returns
///
/// Returns `GhostResult<()>` indicating success or failure. Possible failures include:
/// - Config file not found or invalid
/// - Database errors
/// - Cave stop failures
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     // Stop specific cavees from the default ghost.yaml
///     orchestra::down(vec!["cave1".to_string(), "cave2".to_string()], None, None).await?;
///
///     // Or specify a custom project directory and config file
///     orchestra::down(
///         vec!["cave1".to_string()],
///         Some(&PathBuf::from("/path/to/project")),
///         Some("custom-config.yaml"),
///     ).await?;
///     Ok(())
/// }
/// ```
pub async fn down(
    cave_names: Vec<String>,
    project_dir: Option<&Path>,
    config_file: Option<&str>,
) -> GhostResult<()> {
    // Create spinner for CLI feedback
    #[cfg(feature = "cli")]
    let stop_cavees_sp = term::create_spinner(STOP_CAVEES_MSG.to_string(), None, None);

    // Load the configuration first to validate it exists
    let (config, canonical_project_dir, config_file) =
        match config::load_config(project_dir, config_file).await {
            Ok(result) => result,
            Err(e) => {
                #[cfg(feature = "cli")]
                term::finish_with_error(&stop_cavees_sp);
                return Err(e);
            }
        };

    // Get all cavees defined in config
    let config_cavees = config.get_cavees();

    // Use all cave names from config if no names were specified
    let cave_names_to_stop = if cave_names.is_empty() {
        // Use all cave names from config
        config_cavees.keys().cloned().collect()
    } else {
        // Validate all cave names exist in config before proceeding
        if let Err(e) =
            validate_cave_names(&cave_names, &config, &canonical_project_dir, &config_file)
        {
            #[cfg(feature = "cli")]
            term::finish_with_error(&stop_cavees_sp);
            return Err(e);
        }

        cave_names
    };

    // Ensure menv files exist
    let menv_path = canonical_project_dir.join(GHOST_ENV_DIR);
    if let Err(e) = menv::ensure_menv_files(&menv_path).await {
        #[cfg(feature = "cli")]
        term::finish_with_error(&stop_cavees_sp);
        return Err(e);
    }

    // Get database connection pool
    let db_path = menv_path.join(CAVE_DB_FILENAME);
    let pool = match db::get_or_create_pool(&db_path, &db::CAVE_DB_MIGRATOR).await {
        Ok(pool) => pool,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&stop_cavees_sp);
            return Err(e);
        }
    };

    // Get all running cavees from database
    let running_cavees = match db::get_running_config_cavees(&pool, &config_file).await {
        Ok(cavees) => cavees,
        Err(e) => {
            #[cfg(feature = "cli")]
            term::finish_with_error(&stop_cavees_sp);
            return Err(e);
        }
    };

    // Stop specified cavees that are both in config and running
    for cave in running_cavees {
        if cave_names_to_stop.contains(&cave.name) && config_cavees.contains_key(&cave.name) {
            tracing::info!("stopping cave: {}", cave.name);
            if let Err(e) = signal::kill(Pid::from_raw(cave.supervisor_pid as i32), Signal::SIGTERM)
            {
                #[cfg(feature = "cli")]
                term::finish_with_error(&stop_cavees_sp);
                return Err(e.into());
            }
        }
    }

    #[cfg(feature = "cli")]
    stop_cavees_sp.finish();

    Ok(())
}

/// Gets status information about specified cavees.
///
/// This function retrieves the current status and resource usage of the specified cavees:
/// - Only reports on cavees that exist in the configuration
/// - For each cave, reports whether it's running and resource usage if it is
/// - If no cave names are specified (empty list), returns status for all cavees in the configuration
///
/// ## Arguments
///
/// * `cave_names` - List of cave names to get status for. If empty, all cavees in config are included.
/// * `project_dir` - Optional path to the project directory. If None, defaults to current directory
/// * `config_file` - Optional path to the ghost config file. If None, uses default filename
///
/// ## Returns
///
/// Returns `GhostResult<Vec<CaveStatus>>` containing status information for each cave.
/// Possible failures include:
/// - Config file not found or invalid
/// - Database errors
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     // Get status of specific cavees from the default ghost.yaml
///     let statuses = orchestra::status(
///         vec!["cave1".to_string(), "cave2".to_string()],
///         None,
///         None
///     ).await?;
///
///     // Or get status of all cavees from the default ghost.yaml
///     let all_statuses = orchestra::status(
///         vec![], // empty list means get all cavees
///         None,
///         None
///     ).await?;
///
///     for status in statuses {
///         println!("Cave: {}, Running: {}", status.name, status.running);
///         if status.running {
///             println!("  CPU: {:?}%, Memory: {:?}MiB, Disk: {:?}B",
///                 status.cpu_usage, status.memory_usage, status.disk_usage);
///         }
///     }
///
///     Ok(())
/// }
/// ```
pub async fn status(
    cave_names: Vec<String>,
    project_dir: Option<&Path>,
    config_file: Option<&str>,
) -> GhostResult<Vec<CaveStatus>> {
    // Load the configuration first to validate it exists
    let (config, canonical_project_dir, config_file) =
        config::load_config(project_dir, config_file).await?;

    // Get all cavees defined in config
    let config_cavees = config.get_cavees();

    // Use all cave names from config if no names were specified
    let cave_names_to_check = if cave_names.is_empty() {
        // Use all cave names from config
        config_cavees.keys().cloned().collect()
    } else {
        // Validate all cave names exist in config before proceeding
        validate_cave_names(&cave_names, &config, &canonical_project_dir, &config_file)?;

        cave_names
    };

    // Ensure menv files exist
    let menv_path = canonical_project_dir.join(GHOST_ENV_DIR);
    menv::ensure_menv_files(&menv_path).await?;

    // Get database connection pool
    let db_path = menv_path.join(CAVE_DB_FILENAME);
    let pool = db::get_or_create_pool(&db_path, &db::CAVE_DB_MIGRATOR).await?;

    // Get all running cavees from database
    let running_cavees = db::get_running_config_cavees(&pool, &config_file).await?;

    // Create a HashMap for quick lookup of running cavees
    let running_cave_map: std::collections::HashMap<String, crate::models::Cave> = running_cavees
        .into_iter()
        .map(|s| (s.name.clone(), s))
        .collect();

    // Get status for each cave name to check
    let mut statuses = Vec::new();
    for cave_name in &cave_names_to_check {
        // Only process cavees that exist in config
        if config_cavees.contains_key(cave_name) {
            // Create a basic status with name and running status
            let mut cave_status = CaveStatus {
                name: cave_name.clone(),
                running: running_cave_map.contains_key(cave_name),
                supervisor_pid: None,
                microvm_pid: None,
                cpu_usage: None,
                memory_usage: None,
                disk_usage: None,
                rootfs_paths: None,
            };

            // If the cave is running, get additional stats
            if cave_status.running {
                if let Some(cave) = running_cave_map.get(cave_name) {
                    cave_status.supervisor_pid = Some(cave.supervisor_pid);
                    cave_status.microvm_pid = Some(cave.microvm_pid);
                    cave_status.rootfs_paths = Some(cave.rootfs_paths.clone());

                    // Get CPU and memory usage for the microVM process
                    if let Ok(mut process) = psutil::process::Process::new(cave.microvm_pid) {
                        // CPU usage
                        if let Ok(cpu_percent) = process.cpu_percent() {
                            cave_status.cpu_usage = Some(cpu_percent);
                        }

                        // Memory usage
                        if let Ok(memory_info) = process.memory_info() {
                            // Convert bytes to MiB
                            cave_status.memory_usage = Some(memory_info.rss() / (1024 * 1024));
                        }
                    }

                    // Get disk usage of the RW layer if it's an overlayfs
                    if cave.rootfs_paths.starts_with("overlayfs:") {
                        let paths: Vec<&str> = cave.rootfs_paths.split(':').collect();
                        if paths.len() > 1 {
                            // The last path should be the RW layer
                            let rw_path = paths.last().unwrap();
                            if let Ok(metadata) = tokio::fs::metadata(rw_path).await {
                                // For a directory, we need to calculate the total size
                                if metadata.is_dir() {
                                    if let Ok(size) = get_directory_size(rw_path).await {
                                        cave_status.disk_usage = Some(size);
                                    }
                                } else {
                                    cave_status.disk_usage = Some(metadata.len());
                                }
                            }
                        }
                    } else if cave.rootfs_paths.starts_with("native:") {
                        // For native rootfs, get the size of the rootfs
                        let path = cave.rootfs_paths.strip_prefix("native:").unwrap();
                        if let Ok(metadata) = tokio::fs::metadata(path).await {
                            if metadata.is_dir() {
                                if let Ok(size) = get_directory_size(path).await {
                                    cave_status.disk_usage = Some(size);
                                }
                            } else {
                                cave_status.disk_usage = Some(metadata.len());
                            }
                        }
                    }
                }
            }

            statuses.push(cave_status);
        }
    }

    Ok(statuses)
}

/// Show the status of the cavees
///
/// ## Arguments
///
/// * `names` - The names of the cavees to show the status of
/// * `path` - The path to the ghost config file
/// * `config` - The config file to use
///
/// ## Returns
///
/// Returns `GhostResult<()>` indicating success or failure. Possible failures include:
/// - Config file not found or invalid
/// - Database errors
/// - Cave status retrieval failures
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     orchestra::show_status(
///         &["cave1".to_string(), "cave2".to_string()],
///         None,
///         None
///     ).await?;
///     Ok(())
/// }
/// ```
#[cfg(feature = "cli")]
pub async fn show_status(
    names: &[String],
    path: Option<&Path>,
    config: Option<&str>,
) -> GhostResult<()> {
    // Check if we're in a TTY to determine if we should do live updates
    let is_tty = io::stdin().is_terminal();
    let live_view = is_tty;
    let update_interval = std::time::Duration::from_secs(2);

    if live_view {
        println!("{}", style("Press Ctrl+C to exit live view").dim());
        // Use a loop with tokio sleep for live updates
        loop {
            // Clear the screen by printing ANSI escape code
            print!("\x1B[2J\x1B[1;1H");

            display_status(&names, path.as_deref(), config.as_deref()).await?;

            // Show update message
            println!(
                "\n{}",
                style("Updating every 2 seconds. Press Ctrl+C to exit.").dim()
            );

            // Wait for the update interval
            tokio::time::sleep(update_interval).await;
        }
    } else {
        // Just display once for non-TTY
        display_status(&names, path.as_deref(), config.as_deref()).await?;
    }

    Ok(())
}

/// Show status of cavees across multiple namespaces
///
/// This function displays the status of cavees from multiple namespaces in a consolidated view.
/// It's useful for server mode when you want to see all cavees across all namespaces.
///
/// ## Arguments
///
/// * `names` - List of cave names to show status for. If empty, shows all cavees.
/// * `namespaces_parent_dir` - The parent directory containing namespace directories
///
/// ## Returns
///
/// Returns `GhostResult<()>` indicating success or failure. Possible failures include:
/// - Config file not found or invalid
/// - Database errors
/// - Cave status retrieval failures
///
/// ## Example
///
/// ```no_run
/// use std::path::PathBuf;
/// use ghost_core::management::orchestra;
///
/// #[tokio::main]
/// async fn main() -> anyhow::Result<()> {
///     // Get all namespace directories
///     let namespaces = vec![
///         PathBuf::from("/path/to/namespaces/ns1"),
///         PathBuf::from("/path/to/namespaces/ns2"),
///     ];
///
///     // Show status for all cavees in all namespaces
///     orchestra::show_status_namespaces(&[], namespaces.iter().map(|p| p.as_path()).collect()).await?;
///
///     // Or show status for specific cavees
///     orchestra::show_status_namespaces(
///         &["cave1".to_string(), "cave2".to_string()],
///         namespaces.iter().map(|p| p.as_path()).collect()
///     ).await?;
///
///     Ok(())
/// }
/// ```
#[cfg(feature = "cli")]
pub async fn show_status_namespaces(
    names: &[String],
    namespaces_parent_dir: &Path,
) -> GhostResult<()> {
    // Check if we're in a TTY to determine if we should do live updates
    let is_tty = io::stdin().is_terminal();
    let live_view = is_tty;
    let update_interval = std::time::Duration::from_secs(2);

    if live_view {
        println!("{}", style("Press Ctrl+C to exit live view").dim());
        // Use a loop with tokio sleep for live updates
        loop {
            // Clear the screen by printing ANSI escape code
            print!("\x1B[2J\x1B[1;1H");

            display_status_namespaces(names, namespaces_parent_dir).await?;

            // Show update message
            println!(
                "\n{}",
                style("Updating every 2 seconds. Press Ctrl+C to exit.").dim()
            );

            // Wait for the update interval
            tokio::time::sleep(update_interval).await;
        }
    } else {
        // Just display once for non-TTY
        display_status_namespaces(names, namespaces_parent_dir).await?;
    }

    Ok(())
}

//--------------------------------------------------------------------------------------------------
// Functions: Helpers
//--------------------------------------------------------------------------------------------------

// Helper function to prepare commands for multiple cavees
async fn prepare_cave_commands(
    cave_names: &[&String],
    script_name: Option<&str>,
    project_dir: &Path,
    config_file: &str,
) -> GhostResult<Vec<(String, tokio::process::Command)>> {
    let mut commands = Vec::new();

    for &name in cave_names {
        // Don't print any individual cave preparation logs

        let (command, _) = cave::prepare_run(
            name,
            script_name,
            Some(project_dir),
            Some(config_file),
            vec![],
            false, // non-detached
            None,
            true,
        )
        .await?;

        commands.push((name.clone(), command));
    }

    Ok(commands)
}

// Helper function to run multiple commands with prefixed output
async fn run_commands_with_prefixed_output(
    commands: Vec<(String, tokio::process::Command)>,
) -> GhostResult<()> {
    use console::style;
    use futures::future::join_all;
    use std::process::Stdio;
    use tokio::io::{AsyncBufReadExt, BufReader};

    // Exit early if no commands to run
    if commands.is_empty() {
        return Ok(());
    }

    // This will hold our child process handles and associated tasks
    let mut children = Vec::new();
    let mut output_tasks = Vec::new();

    // Spawn all child processes
    for (i, (cave_name, mut command)) in commands.into_iter().enumerate() {
        // Configure command to pipe stdout and stderr
        command.stdout(Stdio::piped());
        command.stderr(Stdio::piped());

        // Spawn the child process
        let mut child = command.spawn()?;
        let cave_name_clone = cave_name.clone();

        // Style the cave name based on index
        let styled_name = match i % 7 {
            0 => style(&cave_name).green().bold(),
            1 => style(&cave_name).blue().bold(),
            2 => style(&cave_name).red().bold(),
            3 => style(&cave_name).yellow().bold(),
            4 => style(&cave_name).magenta().bold(),
            5 => style(&cave_name).cyan().bold(),
            _ => style(&cave_name).white().bold(),
        };

        // Apply the same color to the separator bar
        let styled_separator = match i % 7 {
            0 => style("|").green(),
            1 => style("|").blue(),
            2 => style("|").red(),
            3 => style("|").yellow(),
            4 => style("|").magenta(),
            5 => style("|").cyan(),
            _ => style("|").white(),
        };

        tracing::info!(
            "{} {} started supervisor process with PID: {}",
            styled_name,
            styled_separator,
            child.id().unwrap_or(0)
        );

        // Create task to handle stdout
        let stdout = child.stdout.take().expect("Failed to capture stdout");
        let name_stdout = cave_name.clone();
        let color_index = i;
        let stdout_task = tokio::spawn(async move {
            let mut reader = BufReader::new(stdout).lines();
            while let Ok(Some(line)) = reader.next_line().await {
                // Style the cave name and separator with color, but leave the message as plain text
                let styled_name = match color_index % 7 {
                    0 => style(&name_stdout).green().bold(),
                    1 => style(&name_stdout).blue().bold(),
                    2 => style(&name_stdout).red().bold(),
                    3 => style(&name_stdout).yellow().bold(),
                    4 => style(&name_stdout).magenta().bold(),
                    5 => style(&name_stdout).cyan().bold(),
                    _ => style(&name_stdout).white().bold(),
                };

                // Apply the same color to the separator bar
                let styled_separator = match color_index % 7 {
                    0 => style("|").green(),
                    1 => style("|").blue(),
                    2 => style("|").red(),
                    3 => style("|").yellow(),
                    4 => style("|").magenta(),
                    5 => style("|").cyan(),
                    _ => style("|").white(),
                };

                println!("{} {} {}", styled_name, styled_separator, line);
            }
        });

        // Create task to handle stderr
        let stderr = child.stderr.take().expect("Failed to capture stderr");
        let color_index = i;
        let stderr_task = tokio::spawn(async move {
            let mut reader = BufReader::new(stderr).lines();
            while let Ok(Some(line)) = reader.next_line().await {
                // Style the cave name and separator with color, but leave the message as plain text
                let styled_name = match color_index % 7 {
                    0 => style(&cave_name_clone).green().bold(),
                    1 => style(&cave_name_clone).blue().bold(),
                    2 => style(&cave_name_clone).red().bold(),
                    3 => style(&cave_name_clone).yellow().bold(),
                    4 => style(&cave_name_clone).magenta().bold(),
                    5 => style(&cave_name_clone).cyan().bold(),
                    _ => style(&cave_name_clone).white().bold(),
                };

                // Apply the same color to the separator bar
                let styled_separator = match color_index % 7 {
                    0 => style("|").green(),
                    1 => style("|").blue(),
                    2 => style("|").red(),
                    3 => style("|").yellow(),
                    4 => style("|").magenta(),
                    5 => style("|").cyan(),
                    _ => style("|").white(),
                };

                eprintln!("{} {} {}", styled_name, styled_separator, line);
            }
        });

        // Add to our collections
        children.push((cave_name, child));
        output_tasks.push(stdout_task);
        output_tasks.push(stderr_task);
    }

    // Create task to monitor child processes
    let monitor_task = tokio::spawn(async move {
        let mut statuses = Vec::new();

        for (name, mut child) in children {
            match child.wait().await {
                Ok(status) => {
                    let exit_code = status.code().unwrap_or(-1);
                    let success = status.success();
                    statuses.push((name, exit_code, success));
                }
                Err(_e) => {
                    #[cfg(feature = "cli")]
                    eprintln!("Error waiting for cave {}: {}", name, _e);
                    statuses.push((name, -1, false));
                }
            }
        }

        statuses
    });

    // Wait for all processes to complete and output tasks to finish
    let statuses = monitor_task.await?;
    join_all(output_tasks).await;

    // Check results and return error if any cave failed
    let failed_cavees: Vec<(String, i32)> = statuses
        .into_iter()
        .filter(|(_, _, success)| !success)
        .map(|(name, code, _)| (name, code))
        .collect();

    if !failed_cavees.is_empty() {
        // Format failure message with colored cave names
        let error_msg = failed_cavees
            .iter()
            .enumerate()
            .map(|(i, (name, code))| {
                // Apply colors directly based on index
                let styled_name = match i % 7 {
                    0 => style(name).green().bold(),
                    1 => style(name).blue().bold(),
                    2 => style(name).red().bold(),
                    3 => style(name).yellow().bold(),
                    4 => style(name).magenta().bold(),
                    5 => style(name).cyan().bold(),
                    _ => style(name).white().bold(),
                };

                // Apply the same color to the separator bar
                let styled_separator = match i % 7 {
                    0 => style("|").green(),
                    1 => style("|").blue(),
                    2 => style("|").red(),
                    3 => style("|").yellow(),
                    4 => style("|").magenta(),
                    5 => style("|").cyan(),
                    _ => style("|").white(),
                };

                format!("{} {} exit code: {}", styled_name, styled_separator, code)
            })
            .collect::<Vec<_>>()
            .join(", ");

        return Err(GhostError::SupervisorError(format!(
            "The following cavees failed: {}",
            error_msg
        )));
    }

    Ok(())
}

// Extracted the status display logic to a separate function
#[cfg(feature = "cli")]
async fn display_status(
    names: &[String],
    path: Option<&Path>,
    config: Option<&str>,
) -> GhostResult<()> {
    let mut statuses = status(names.to_vec(), path, config).await?;

    // Sort the statuses in a stable order to prevent entries from moving around between updates
    // Order by: running status (running first), CPU usage (highest first),
    // memory usage (highest first), disk usage (highest first), and finally name (alphabetical)
    statuses.sort_by(|a, b| {
        // First compare by running status (running cavees first)
        let running_order = b.running.cmp(&a.running);
        if running_order != std::cmp::Ordering::Equal {
            return running_order;
        }

        // Then compare by CPU usage (highest first)
        let cpu_order = b
            .cpu_usage
            .partial_cmp(&a.cpu_usage)
            .unwrap_or(std::cmp::Ordering::Equal);
        if cpu_order != std::cmp::Ordering::Equal {
            return cpu_order;
        }

        // Then compare by memory usage (highest first)
        let memory_order = b
            .memory_usage
            .partial_cmp(&a.memory_usage)
            .unwrap_or(std::cmp::Ordering::Equal);
        if memory_order != std::cmp::Ordering::Equal {
            return memory_order;
        }

        // Then compare by disk usage (highest first)
        let disk_order = b
            .disk_usage
            .partial_cmp(&a.disk_usage)
            .unwrap_or(std::cmp::Ordering::Equal);
        if disk_order != std::cmp::Ordering::Equal {
            return disk_order;
        }

        // Finally sort by name (alphabetical)
        a.name.cmp(&b.name)
    });

    // Get current timestamp
    let now = chrono::Local::now();
    let timestamp = now.format("%Y-%m-%d %H:%M:%S");

    // Display timestamp
    println!("{}", style(format!("Last updated: {}", timestamp)).dim());

    // Print a table-like output with status information
    println!(
        "\n{:<15} {:<10} {:<15} {:<12} {:<12} {:<12}",
        style("CAVE").bold(),
        style("STATUS").bold(),
        style("PIDS").bold(),
        style("CPU").bold(),
        style("MEMORY").bold(),
        style("DISK").bold()
    );

    println!("{}", style("─".repeat(80)).dim());

    for status in statuses {
        let (status_text, pids, cpu, memory, disk) = format_status_columns(&status);

        println!(
            "{:<15} {:<10} {:<15} {:<12} {:<12} {:<12}",
            style(&status.name).bold(),
            status_text,
            pids,
            cpu,
            memory,
            disk
        );
    }

    Ok(())
}

// Update display_status_namespaces to discover namespaces dynamically
#[cfg(feature = "cli")]
async fn display_status_namespaces(
    names: &[String],
    namespaces_parent_dir: &Path,
) -> GhostResult<()> {
    // Create a struct to hold status with namespace info
    #[derive(Clone)]
    struct NamespacedStatus {
        namespace: String,
        status: CaveStatus,
    }

    // Collect statuses from all namespaces
    let mut all_statuses = Vec::new();
    let mut namespace_count = 0;

    // Check if the parent directory exists
    if !namespaces_parent_dir.exists() {
        return Err(GhostError::PathNotFound(format!(
            "Namespaces directory not found at {}",
            namespaces_parent_dir.display()
        )));
    }

    // Scan the parent directory for namespaces
    let mut entries = tokio::fs::read_dir(namespaces_parent_dir).await?;
    let mut namespace_dirs = Vec::new();

    while let Some(entry) = entries.next_entry().await? {
        let path = entry.path();
        if path.is_dir() {
            namespace_dirs.push(path);
        }
    }

    // Sort namespace dirs alphabetically (initial sort to ensure deterministic behavior)
    namespace_dirs.sort_by(|a, b| {
        let a_name = a.file_name().and_then(|n| n.to_str()).unwrap_or("");
        let b_name = b.file_name().and_then(|n| n.to_str()).unwrap_or("");
        a_name.cmp(b_name)
    });

    // Process each namespace directory
    for namespace_dir in &namespace_dirs {
        // Extract namespace name from path
        let namespace = namespace_dir
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown")
            .to_string();

        namespace_count += 1;

        // Get statuses for this namespace
        match status(names.to_vec(), Some(namespace_dir), None).await {
            Ok(statuses) => {
                // Add namespace info to each status
                for status in statuses {
                    all_statuses.push(NamespacedStatus {
                        namespace: namespace.clone(),
                        status,
                    });
                }
            }
            Err(e) => {
                // Log error but continue with other namespaces
                tracing::warn!("Error getting status for namespace {}: {}", namespace, e);
            }
        }
    }

    // Group the statuses by namespace
    let mut statuses_by_namespace: std::collections::HashMap<String, Vec<CaveStatus>> =
        std::collections::HashMap::new();

    for namespaced_status in all_statuses {
        statuses_by_namespace
            .entry(namespaced_status.namespace)
            .or_default()
            .push(namespaced_status.status);
    }

    // Get current timestamp
    let now = chrono::Local::now();
    let timestamp = now.format("%Y-%m-%d %H:%M:%S");

    // Display timestamp
    println!("{}", style(format!("Last updated: {}", timestamp)).dim());

    // Prepare namespaces with their activity metrics for sorting
    #[derive(Clone)]
    struct NamespaceActivity {
        name: String,
        running_count: usize,
        total_cpu: f32,
        total_memory: u64,
        statuses: Vec<CaveStatus>,
    }

    let mut namespace_activities = Vec::new();

    // Calculate activity metrics for each namespace
    for (namespace, statuses) in statuses_by_namespace {
        if statuses.is_empty() {
            continue;
        }

        let running_count = statuses.iter().filter(|s| s.running).count();
        let total_cpu: f32 = statuses.iter().filter_map(|s| s.cpu_usage).sum();
        let total_memory: u64 = statuses.iter().filter_map(|s| s.memory_usage).sum();

        namespace_activities.push(NamespaceActivity {
            name: namespace,
            running_count,
            total_cpu,
            total_memory,
            statuses,
        });
    }

    // Sort namespaces by activity level (running count first, then resource usage)
    namespace_activities.sort_by(|a, b| {
        // First by number of running cavees (descending)
        let running_order = b.running_count.cmp(&a.running_count);
        if running_order != std::cmp::Ordering::Equal {
            return running_order;
        }

        // Then by total CPU usage (descending)
        let cpu_order = b
            .total_cpu
            .partial_cmp(&a.total_cpu)
            .unwrap_or(std::cmp::Ordering::Equal);
        if cpu_order != std::cmp::Ordering::Equal {
            return cpu_order;
        }

        // Then by total memory usage (descending)
        let memory_order = b.total_memory.cmp(&a.total_memory);
        if memory_order != std::cmp::Ordering::Equal {
            return memory_order;
        }

        // Finally by name (alphabetical) as a stable tiebreaker
        a.name.cmp(&b.name)
    });

    // Capture cavees count
    let mut total_cavees = 0;
    let mut is_first = true;

    // Display namespaces and their statuses with headers
    for activity in namespace_activities {
        // Add spacing between namespaces
        if !is_first {
            println!();
        }
        is_first = false;

        // Print namespace header
        print_namespace_header(&activity.name);

        // Sort the statuses in a stable order
        let mut statuses = activity.statuses;
        statuses.sort_by(|a, b| {
            // First compare by running status (running cavees first)
            let running_order = b.running.cmp(&a.running);
            if running_order != std::cmp::Ordering::Equal {
                return running_order;
            }

            // Then compare by CPU usage (highest first)
            let cpu_order = b
                .cpu_usage
                .partial_cmp(&a.cpu_usage)
                .unwrap_or(std::cmp::Ordering::Equal);
            if cpu_order != std::cmp::Ordering::Equal {
                return cpu_order;
            }

            // Then compare by memory usage (highest first)
            let memory_order = b
                .memory_usage
                .partial_cmp(&a.memory_usage)
                .unwrap_or(std::cmp::Ordering::Equal);
            if memory_order != std::cmp::Ordering::Equal {
                return memory_order;
            }

            // Then compare by disk usage (highest first)
            let disk_order = b
                .disk_usage
                .partial_cmp(&a.disk_usage)
                .unwrap_or(std::cmp::Ordering::Equal);
            if disk_order != std::cmp::Ordering::Equal {
                return disk_order;
            }

            // Finally sort by name (alphabetical)
            a.name.cmp(&b.name)
        });

        total_cavees += statuses.len();

        // Print a table header for this namespace's cavees
        println!(
            "{:<15} {:<10} {:<15} {:<12} {:<12} {:<12}",
            style("CAVE").bold(),
            style("STATUS").bold(),
            style("PIDS").bold(),
            style("CPU").bold(),
            style("MEMORY").bold(),
            style("DISK").bold()
        );

        println!("{}", style("─".repeat(80)).dim());

        // Display the statuses for this namespace
        for status in statuses {
            let (status_text, pids, cpu, memory, disk) = format_status_columns(&status);

            println!(
                "{:<15} {:<10} {:<15} {:<12} {:<12} {:<12}",
                style(&status.name).bold(),
                status_text,
                pids,
                cpu,
                memory,
                disk
            );
        }
    }

    // Show summary with the captured counts
    println!(
        "\n{}: {}, {}: {}",
        style("Total Namespaces").dim(),
        namespace_count,
        style("Total Cavees").dim(),
        total_cavees
    );

    Ok(())
}

/// Prints a stylized header for namespace display
#[cfg(feature = "cli")]
fn print_namespace_header(namespace: &str) {
    // Create the simple title text without padding
    let title = format!("NAMESPACE: {}", namespace);

    // Print the title with white color and underline styling
    println!("\n{}", style(title).white().bold());

    // Print a separator line
    println!("{}", style("─".repeat(80)).dim());
}

/// Formats the status columns for display
#[cfg(feature = "cli")]
fn format_status_columns(
    status: &CaveStatus,
) -> (
    console::StyledObject<String>,
    String,
    String,
    String,
    String,
) {
    let status_text = if status.running {
        style("RUNNING".to_string()).green()
    } else {
        style("STOPPED".to_string()).red()
    };

    let pids = if status.running {
        format!(
            "{}/{}",
            status.supervisor_pid.unwrap_or(0),
            status.microvm_pid.unwrap_or(0)
        )
    } else {
        "-".to_string()
    };

    let cpu = if let Some(cpu_usage) = status.cpu_usage {
        format!("{:.1}%", cpu_usage)
    } else {
        "-".to_string()
    };

    let memory = if let Some(memory_usage) = status.memory_usage {
        format!("{} MiB", memory_usage)
    } else {
        "-".to_string()
    };

    let disk = if let Some(disk_usage) = status.disk_usage {
        if disk_usage > 1024 * 1024 * 1024 {
            format!("{:.2} GB", disk_usage as f64 / (1024.0 * 1024.0 * 1024.0))
        } else if disk_usage > 1024 * 1024 {
            format!("{:.2} MB", disk_usage as f64 / (1024.0 * 1024.0))
        } else if disk_usage > 1024 {
            format!("{:.2} KB", disk_usage as f64 / 1024.0)
        } else {
            format!("{} B", disk_usage)
        }
    } else {
        "-".to_string()
    };

    (status_text, pids, cpu, memory, disk)
}

/// Validate that all requested cave names exist in the configuration
fn validate_cave_names(
    cave_names: &[String],
    config: &ghost,
    project_dir: &Path,
    config_file: &str,
) -> GhostResult<()> {
    let config_cavees = config.get_cavees();

    let missing_cavees: Vec<String> = cave_names
        .iter()
        .filter(|name| !config_cavees.contains_key(*name))
        .cloned()
        .collect();

    if !missing_cavees.is_empty() {
        return Err(GhostError::CaveNotFoundInConfig(
            missing_cavees.join(", "),
            project_dir.join(config_file),
        ));
    }

    Ok(())
}

/// Recursively calculate the size of a directory, but cache the result for a short period so that
/// callers (status refresh every ~2 s) don't hammer the filesystem.
async fn get_directory_size(path: &str) -> GhostResult<u64> {
    // First attempt to serve from cache
    {
        let cache = DISK_SIZE_CACHE.read().unwrap();
        if let Some((size, ts)) = cache.get(path) {
            if ts.elapsed() < DISK_SIZE_TTL {
                return Ok(*size);
            }
        }
    }

    // Need to (re)compute – perform blocking walk in a separate thread so we don't block Tokio
    let path_buf = PathBuf::from(path);
    let size = tokio::task::spawn_blocking(move || -> GhostResult<u64> {
        use walkdir::WalkDir;

        let mut total: u64 = 0;
        for entry in WalkDir::new(&path_buf).follow_links(false) {
            let entry = entry?; // propagates walkdir::Error (already covered in GhostError)
            if entry.file_type().is_file() {
                total += entry.metadata()?.len();
            }
        }
        Ok(total)
    })
    .await??; // first ? = JoinError, second ? = inner GhostError

    // Update cache
    {
        let mut cache = DISK_SIZE_CACHE.write().unwrap();
        cache.insert(path.to_string(), (size, Instant::now()));
    }

    Ok(size)
}

/// Checks if specified cavees from the configuration are running.
async fn _check_running(
    cave_names: Vec<String>,
    config: &ghost,
    project_dir: &Path,
    config_file: &str,
) -> GhostResult<Vec<(String, bool)>> {
    // Ensure menv files exist
    let canonical_project_dir = project_dir.canonicalize().map_err(|e| {
        GhostError::InvalidArgument(format!("Failed to canonicalize project directory: {}", e))
    })?;
    let menv_path = canonical_project_dir.join(GHOST_ENV_DIR);
    menv::ensure_menv_files(&menv_path).await?;

    // Get database connection pool
    let db_path = menv_path.join(CAVE_DB_FILENAME);
    let pool = db::get_or_create_pool(&db_path, &db::CAVE_DB_MIGRATOR).await?;

    // Get all cavees defined in config
    let config_cavees = config.get_cavees();

    // Get all running cavees from database
    let running_cavees = db::get_running_config_cavees(&pool, config_file).await?;
    let running_cave_names: Vec<String> = running_cavees.iter().map(|s| s.name.clone()).collect();

    // Check status of specified cavees
    let mut statuses = Vec::new();
    for cave_name in cave_names {
        // Only check if cave exists in config
        if config_cavees.contains_key(&cave_name) {
            let is_running = running_cave_names.contains(&cave_name);
            statuses.push((cave_name, is_running));
        }
    }

    Ok(statuses)
}
