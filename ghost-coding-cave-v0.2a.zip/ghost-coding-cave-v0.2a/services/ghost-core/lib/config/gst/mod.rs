//! ghost configuration helpers for cave definitions.

/// Configuration primitives for the microcave runtime.
pub mod microcave;

pub use microcave::*;
