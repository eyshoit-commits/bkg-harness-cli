use std::collections::HashMap;

use ghost_utils::DEFAULT_SHELL;
use semver::Version;
use typed_path::Utf8UnixPathBuf;

use crate::{
    config::{EnvPair, PathPair, PortPair, ReferenceOrPath},
    GhostResult,
};

use super::{ghost, Build, Cave, Meta, Module, NetworkScope};

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

/// Builder for ghost configuration
///
/// ### Optional fields:
/// - `meta`: The metadata for the configuration
/// - `modules`: The modules to import
/// - `builds`: The builds to run
/// - `cavees`: The cavees to run
#[derive(Default)]
pub struct GhostBuilder {
    meta: Option<Meta>,
    modules: HashMap<String, Module>,
    builds: HashMap<String, Build>,
    cavees: HashMap<String, Cave>,
}

/// Builder for Cave configuration
///
/// ### Required fields:
/// - `name`: The name of the cave
/// - `image`: The image to use
///
/// ### Optional fields:
/// - `version`: The version of the cave
/// - `meta`: The metadata for the cave
/// - `memory`: The maximum amount of memory allowed for the cave
/// - `cpus`: The maximum number of CPUs allowed for the cave
/// - `volumes`: The volumes to mount
/// - `ports`: The ports to expose
/// - `envs`: The environment variables to use
/// - `env_file`: The environment file to use
/// - `depends_on`: The cavees to depend on
/// - `workdir`: The working directory to use
/// - `shell`: The shell to use
/// - `scripts`: The scripts available in the cave
/// - `imports`: The files to import
/// - `exports`: The files to export
/// - `scope`: The network scope for the cave
/// - `proxy`: The proxy to use
pub struct CaveBuilder<I> {
    version: Option<Version>,
    meta: Option<Meta>,
    image: I,
    memory: Option<u32>,
    cpus: Option<u8>,
    volumes: Vec<PathPair>,
    ports: Vec<PortPair>,
    envs: Vec<EnvPair>,
    env_file: Option<Utf8UnixPathBuf>,
    depends_on: Vec<String>,
    workdir: Option<Utf8UnixPathBuf>,
    shell: Option<String>,
    scripts: HashMap<String, String>,
    command: Vec<String>,
    imports: HashMap<String, Utf8UnixPathBuf>,
    exports: HashMap<String, Utf8UnixPathBuf>,
    scope: NetworkScope,
}

//--------------------------------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------------------------------

impl GhostBuilder {
    /// Sets the metadata for the configuration
    pub fn meta(mut self, meta: Meta) -> Self {
        self.meta = Some(meta);
        self
    }

    /// Sets the modules to import
    pub fn modules(mut self, modules: impl IntoIterator<Item = (String, Module)>) -> Self {
        self.modules = modules.into_iter().collect();
        self
    }

    /// Sets the builds to run
    pub fn builds(mut self, builds: impl IntoIterator<Item = (String, Build)>) -> Self {
        self.builds = builds.into_iter().collect();
        self
    }

    /// Sets the cavees to run
    pub fn cavees(mut self, cavees: impl IntoIterator<Item = (String, Cave)>) -> Self {
        self.cavees = cavees.into_iter().collect();
        self
    }

    /// Builds the ghost configuration with validation
    pub fn build(self) -> GhostResult<ghost> {
        let ghost = self.build_unchecked();
        ghost.validate()?;
        Ok(ghost)
    }

    /// Builds the ghost configuration without validation
    pub fn build_unchecked(self) -> ghost {
        ghost {
            meta: self.meta,
            modules: self.modules,
            builds: self.builds,
            cavees: self.cavees,
        }
    }
}

impl<I> CaveBuilder<I> {
    /// Sets the version of the cave
    pub fn version(mut self, version: impl Into<Version>) -> CaveBuilder<I> {
        self.version = Some(version.into());
        self
    }

    /// Sets the metadata for the cave
    pub fn meta(mut self, meta: Meta) -> CaveBuilder<I> {
        self.meta = Some(meta);
        self
    }

    /// Sets the image for the cave
    pub fn image(self, image: impl Into<ReferenceOrPath>) -> CaveBuilder<ReferenceOrPath> {
        CaveBuilder {
            version: self.version,
            meta: self.meta,
            image: image.into(),
            memory: self.memory,
            cpus: self.cpus,
            volumes: self.volumes,
            ports: self.ports,
            envs: self.envs,
            env_file: self.env_file,
            depends_on: self.depends_on,
            workdir: self.workdir,
            shell: self.shell,
            scripts: self.scripts,
            command: self.command,
            imports: self.imports,
            exports: self.exports,
            scope: self.scope,
        }
    }

    /// Sets the maximum amount of memory allowed for the cave
    pub fn memory(mut self, memory: u32) -> CaveBuilder<I> {
        self.memory = Some(memory);
        self
    }

    /// Sets the maximum number of CPUs allowed for the cave
    pub fn cpus(mut self, cpus: u8) -> CaveBuilder<I> {
        self.cpus = Some(cpus);
        self
    }

    /// Sets the volumes to mount for the cave
    pub fn volumes(mut self, volumes: impl IntoIterator<Item = PathPair>) -> CaveBuilder<I> {
        self.volumes = volumes.into_iter().collect();
        self
    }

    /// Sets the ports to expose for the cave
    pub fn ports(mut self, ports: impl IntoIterator<Item = PortPair>) -> CaveBuilder<I> {
        self.ports = ports.into_iter().collect();
        self
    }

    /// Sets the environment variables for the cave
    pub fn envs(mut self, envs: impl IntoIterator<Item = EnvPair>) -> CaveBuilder<I> {
        self.envs = envs.into_iter().collect();
        self
    }

    /// Sets the environment file for the cave
    pub fn env_file(mut self, env_file: impl Into<Utf8UnixPathBuf>) -> CaveBuilder<I> {
        self.env_file = Some(env_file.into());
        self
    }

    /// Sets the cavees that the cave depends on
    pub fn depends_on(mut self, depends_on: impl IntoIterator<Item = String>) -> CaveBuilder<I> {
        self.depends_on = depends_on.into_iter().collect();
        self
    }

    /// Sets the working directory for the cave
    pub fn workdir(mut self, workdir: impl Into<Utf8UnixPathBuf>) -> CaveBuilder<I> {
        self.workdir = Some(workdir.into());
        self
    }

    /// Sets the shell for the cave
    pub fn shell(mut self, shell: impl AsRef<str>) -> CaveBuilder<I> {
        self.shell = Some(shell.as_ref().to_string());
        self
    }

    /// Sets the scripts for the cave
    pub fn scripts(
        mut self,
        scripts: impl IntoIterator<Item = (String, String)>,
    ) -> CaveBuilder<I> {
        self.scripts = scripts.into_iter().collect();
        self
    }

    /// Sets the command for the cave
    pub fn command(mut self, command: impl IntoIterator<Item = String>) -> CaveBuilder<I> {
        self.command = command.into_iter().collect();
        self
    }

    /// Sets the files to import for the cave
    pub fn imports(
        mut self,
        imports: impl IntoIterator<Item = (String, Utf8UnixPathBuf)>,
    ) -> CaveBuilder<I> {
        self.imports = imports.into_iter().collect();
        self
    }

    /// Sets the files to export for the cave
    pub fn exports(
        mut self,
        exports: impl IntoIterator<Item = (String, Utf8UnixPathBuf)>,
    ) -> CaveBuilder<I> {
        self.exports = exports.into_iter().collect();
        self
    }

    /// Sets the network scope for the cave
    pub fn scope(mut self, scope: NetworkScope) -> CaveBuilder<I> {
        self.scope = scope;
        self
    }
}

impl CaveBuilder<ReferenceOrPath> {
    /// Builds the cave
    pub fn build(self) -> Cave {
        Cave {
            version: self.version,
            meta: self.meta,
            image: self.image,
            memory: self.memory,
            cpus: self.cpus,
            volumes: self.volumes,
            ports: self.ports,
            envs: self.envs,
            depends_on: self.depends_on,
            workdir: self.workdir,
            shell: self.shell,
            scripts: self.scripts,
            command: self.command,
            imports: self.imports,
            exports: self.exports,
            scope: self.scope,
        }
    }
}

//--------------------------------------------------------------------------------------------------
// Trait Implementations
//--------------------------------------------------------------------------------------------------

impl Default for CaveBuilder<()> {
    fn default() -> Self {
        Self {
            version: None,
            meta: None,
            image: (),
            memory: None,
            cpus: None,
            volumes: Vec::new(),
            ports: Vec::new(),
            envs: Vec::new(),
            env_file: None,
            depends_on: Vec::new(),
            workdir: None,
            shell: Some(DEFAULT_SHELL.to_string()),
            scripts: HashMap::new(),
            command: Vec::new(),
            imports: HashMap::new(),
            exports: HashMap::new(),
            scope: NetworkScope::default(),
        }
    }
}
