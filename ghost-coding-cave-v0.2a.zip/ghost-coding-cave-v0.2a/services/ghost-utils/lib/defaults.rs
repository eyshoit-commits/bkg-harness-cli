//! Default values and constants used throughout the ghost project.
//!
//! This module provides default configuration values, paths, and other constants
//! that are used by various components of the ghost system.
//!
//! # Examples
//!
//! ```
//! use ghost_utils::defaults::{DEFAULT_NUM_VCPUS, DEFAULT_MEMORY_MIB};
//!
//! // Use default values for VM configuration
//! let vcpus = DEFAULT_NUM_VCPUS;
//! let memory = DEFAULT_MEMORY_MIB;
//! ```

use std::{fs, path::PathBuf, sync::LazyLock};

use crate::GHOST_HOME_DIR;

//--------------------------------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------------------------------

/// The default maximum log file size (10MB)
pub const DEFAULT_LOG_MAX_SIZE: u64 = 10 * 1024 * 1024;

/// The default number of vCPUs to use for the MicroVm.
pub const DEFAULT_NUM_VCPUS: u8 = 1;

/// The default amount of memory in MiB to use for the MicroVm.
pub const DEFAULT_MEMORY_MIB: u32 = 1024;

/// The path where all ghost global data is stored.
pub static DEFAULT_GHOST_HOME: LazyLock<PathBuf> =
    LazyLock::new(|| dirs::home_dir().unwrap().join(GHOST_HOME_DIR));

/// The default OCI registry domain.
pub const DEFAULT_OCI_REGISTRY: &str = "docker.io";

/// The default OCI reference tag.
pub const DEFAULT_OCI_REFERENCE_TAG: &str = "latest";

/// The default OCI reference repository namespace.
pub const DEFAULT_OCI_REFERENCE_REPO_NAMESPACE: &str = "library";

/// The default configuration file content
pub const DEFAULT_CONFIG: &str = "# Cave configurations\ncavees:\n";

/// The default shell to use for the cave.
pub const DEFAULT_SHELL: &str = "/bin/sh";

/// The default path to the gstrun binary.
pub static DEFAULT_GSTRUN_EXE_PATH: LazyLock<PathBuf> = LazyLock::new(|| {
    let current_exe = std::env::current_exe().unwrap();
    let actual_exe = fs::canonicalize(current_exe).unwrap();
    actual_exe.parent().unwrap().join("gstrun")
});

/// The default path to the gstserver binary.
pub static DEFAULT_GSTSERVER_EXE_PATH: LazyLock<PathBuf> = LazyLock::new(|| {
    let current_exe = std::env::current_exe().unwrap();
    let actual_exe = fs::canonicalize(current_exe).unwrap();
    actual_exe.parent().unwrap().join("gstserver")
});

/// The default working directory for the cave.
pub const DEFAULT_WORKDIR: &str = "/";

/// The default namespace for the cave server.
pub const DEFAULT_SERVER_NAMESPACE: &str = "default";

/// The default localhost address.
pub const DEFAULT_SERVER_HOST: &str = "127.0.0.1";

/// The default ghost-server port.
pub const DEFAULT_SERVER_PORT: u16 = 5555;

/// The default ghost-portal port.
pub const DEFAULT_PORTAL_GUEST_PORT: u16 = 4444;
