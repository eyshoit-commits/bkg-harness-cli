//! Utility functions for working with environment variables.

use std::path::PathBuf;

use crate::{DEFAULT_GHOST_HOME, DEFAULT_OCI_REGISTRY};

//--------------------------------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------------------------------

/// Environment variable for the ghost home directory
pub const GHOST_HOME_ENV_VAR: &str = "ghost_HOME";

/// Environment variable for the OCI registry domain
pub const OCI_REGISTRY_ENV_VAR: &str = "OCI_REGISTRY_DOMAIN";

/// Environment variable for the gstrun binary path
pub const GSTRUN_EXE_ENV_VAR: &str = "GSTRUN_EXE";

/// Environment variable for the gstserver binary path
pub const GSTSERVER_EXE_ENV_VAR: &str = "GSTSERVER_EXE";

//--------------------------------------------------------------------------------------------------
// Functions
//--------------------------------------------------------------------------------------------------

/// Returns the path to the ghost home directory.
/// If the ghost_HOME environment variable is set, returns that path.
/// Otherwise, returns the default ghost home path.
pub fn get_ghost_home_path() -> PathBuf {
    if let Ok(ghost_home) = std::env::var(GHOST_HOME_ENV_VAR) {
        PathBuf::from(ghost_home)
    } else {
        DEFAULT_GHOST_HOME.to_owned()
    }
}

/// Returns the domain for the OCI registry.
/// If the OCI_REGISTRY_DOMAIN environment variable is set, returns that value.
/// Otherwise, returns the default OCI registry domain.
pub fn get_oci_registry() -> String {
    if let Ok(oci_registry_domain) = std::env::var(OCI_REGISTRY_ENV_VAR) {
        oci_registry_domain
    } else {
        DEFAULT_OCI_REGISTRY.to_string()
    }
}
