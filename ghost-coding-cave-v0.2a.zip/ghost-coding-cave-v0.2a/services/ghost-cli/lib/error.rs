//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

use thiserror::Error;

/// The result of a ghost-cli related operation.
pub type GhostCliResult<T> = Result<T, GhostCliError>;

/// An error that occurred during a file system operation.
#[derive(pretty_error_debug::Debug, Error)]
pub enum GhostCliError {
    /// An I/O error.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    /// Error returned from the ghost-server crate
    #[error(transparent)]
    Server(#[from] ghost_server::GhostServerError),

    /// Error returned from the ghost-core crate
    #[error(transparent)]
    Core(#[from] ghost_core::GhostError),

    /// Invalid argument
    #[error("invalid argument: {0}")]
    InvalidArgument(String),

    /// Not found
    #[error("not found: {0}")]
    NotFound(String),

    /// Process wait error
    #[error("process wait error: {0}")]
    ProcessWaitError(String),

    /// Configuration error
    #[error("configuration error: {0}")]
    ConfigError(String),

    /// Namespace operation error
    #[error("namespace error: {0}")]
    NamespaceError(String),
}
