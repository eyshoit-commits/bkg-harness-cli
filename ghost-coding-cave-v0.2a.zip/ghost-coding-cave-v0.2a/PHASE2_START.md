# Phase 2 Quick-Start: Registry-Anbindung

**Dieses Dokument:** Phase 2 Setup & Execution Guide  
**Datum:** 31. Oktober 2025  
**Voraussetzung:** Phase 1 ✅ ABGESCHLOSSEN

---

## 📋 Pre-Flight Checks

```bash
# 1. Alle Services laufen?
✅ Semantic-Store kompiliert: cargo build -p ss-api
✅ AI-Server läuft: cargo run --bin ai-server
✅ PostgreSQL läuft: docker ps | grep postgres
✅ Tests bestehen: cargo test -p ss-api

# 2. Ports verfügbar?
lsof -i :8443    # Semantic-Store HTTP
lsof -i :9443    # Semantic-Store gRPC
lsof -i :5001    # AI-Server
lsof -i :5432    # PostgreSQL

# 3. Documentation vorhanden?
ls docs/STORAGE_ENGINE.md docs/PROGRESS.md
ls docs/PHASE2_ROADMAP.md  # Sollte exist
```

---

## 🚀 Task 2.1: gRPC Client für Semantic-Store

### Schritt 1: Proto Definitions erstellen

**Datei:** `rust-core/crates/ai-server/src/proto/semantic_store.proto`

```protobuf
syntax = "proto3";

package semantic_store;

service SemanticStore {
    rpc ListCapsules(ScanPrefixRequest) returns (CapsuleList);
    rpc GetCapsule(GetCapsuleRequest) returns (CapsuleData);
    rpc GetHealth(HealthRequest) returns (HealthResponse);
}

message ScanPrefixRequest {
    string prefix = 1;
    string model_name = 2;
    string architecture = 3;
    int32 min_size = 4;
    int32 max_size = 5;
    int32 limit = 6;
}

message CapsuleList {
    repeated CapsuleMetadata capsules = 1;
}

message CapsuleMetadata {
    string id = 1;
    string model_name = 2;
    string architecture = 3;
    int32 size = 4;
    string created_at = 5;
}

message GetCapsuleRequest {
    string id = 1;
}

message CapsuleData {
    string id = 1;
    bytes manifest = 2;
    bytes blob = 3;
}

message HealthRequest {}

message HealthResponse {
    string status = 1;
}
```

### Schritt 2: Build Configuration

**Datei:** `rust-core/crates/ai-server/build.rs`

```rust
fn main() -> Result<(), Box<dyn std::error::Error>> {
    tonic_build::compile_protos("src/proto/semantic_store.proto")?;
    Ok(())
}
```

### Schritt 3: gRPC Client implementieren

**Datei:** `rust-core/crates/ai-server/src/registry/semantic_store.rs`

```rust
use tonic::transport::Channel;
use tracing::{info, error};
use std::sync::Arc;

// Generated from proto
pub mod semantic_store {
    tonic::include_proto!("semantic_store");
}

use semantic_store::semantic_store_client::SemanticStoreClient;
use semantic_store::{ScanPrefixRequest, GetCapsuleRequest};

pub struct SemanticStoreRegistry {
    client: Arc<SemanticStoreClient<Channel>>,
    endpoint: String,
}

impl SemanticStoreRegistry {
    pub async fn new(endpoint: &str) -> Result<Self, tonic::transport::Error> {
        let channel = Channel::from_static(endpoint)
            .connect()
            .await?;
        
        let client = SemanticStoreClient::new(channel);
        
        info!("Connected to Semantic-Store at: {}", endpoint);
        
        Ok(Self {
            client: Arc::new(client),
            endpoint: endpoint.to_string(),
        })
    }

    pub async fn list_models(&self, limit: Option<i32>) -> Result<Vec<ModelInfo>, String> {
        let request = ScanPrefixRequest {
            prefix: "capsule::".to_string(),
            model_name: String::new(),
            architecture: String::new(),
            min_size: 0,
            max_size: 0,
            limit: limit.unwrap_or(100),
        };

        let response = self.client
            .clone()
            .list_capsules(request)
            .await
            .map_err(|e| format!("Failed to list capsules: {}", e))?;

        let models = response
            .into_inner()
            .capsules
            .iter()
            .map(|c| ModelInfo {
                id: c.id.clone(),
                name: c.model_name.clone(),
                architecture: c.architecture.clone(),
                size: c.size as usize,
                created_at: c.created_at.clone(),
            })
            .collect();

        Ok(models)
    }

    pub async fn load_model(&self, id: &str) -> Result<ModelData, String> {
        let request = GetCapsuleRequest {
            id: id.to_string(),
        };

        let response = self.client
            .clone()
            .get_capsule(request)
            .await
            .map_err(|e| format!("Failed to load capsule {}: {}", id, e))?;

        let capsule = response.into_inner();

        Ok(ModelData {
            id: capsule.id,
            manifest: capsule.manifest,
            blob: capsule.blob,
        })
    }

    pub async fn health_check(&self) -> Result<bool, String> {
        info!("Checking Semantic-Store health at: {}", self.endpoint);
        
        // Via HTTP health endpoint (fallback)
        let url = format!("http://{}/health", self.endpoint.replace("grpc://", ""));
        
        match reqwest::get(&url).await {
            Ok(resp) => Ok(resp.status().is_success()),
            Err(e) => {
                error!("Health check failed: {}", e);
                Err(format!("Health check failed: {}", e))
            }
        }
    }
}

#[derive(Debug, Clone)]
pub struct ModelInfo {
    pub id: String,
    pub name: String,
    pub architecture: String,
    pub size: usize,
    pub created_at: String,
}

#[derive(Debug, Clone)]
pub struct ModelData {
    pub id: String,
    pub manifest: Vec<u8>,
    pub blob: Vec<u8>,
}
```

### Schritt 4: Dependencies aktualisieren

**Datei:** `rust-core/crates/ai-server/Cargo.toml`

```toml
[dependencies]
tonic = "0.11"
prost = "0.12"
tokio = { version = "1", features = ["full"] }
tracing = "0.1"
reqwest = { version = "0.11", features = ["json"] }

[build-dependencies]
tonic-build = "0.11"
```

---

## 🧪 Tests für Task 2.1

**Datei:** `rust-core/crates/ai-server/src/registry/semantic_store_tests.rs`

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_connect_to_semantic_store() {
        // Requires running Semantic-Store on grpc://localhost:9443
        let result = SemanticStoreRegistry::new("http://localhost:8443").await;
        assert!(result.is_ok(), "Should connect to Semantic-Store");
    }

    #[tokio::test]
    async fn test_list_models() {
        let registry = SemanticStoreRegistry::new("http://localhost:8443")
            .await
            .expect("Failed to connect");

        let models = registry.list_models(Some(10)).await;
        assert!(models.is_ok(), "Should list models");
        
        let model_list = models.unwrap();
        println!("Found {} models", model_list.len());
    }

    #[tokio::test]
    async fn test_health_check() {
        let registry = SemanticStoreRegistry::new("http://localhost:8443")
            .await
            .expect("Failed to connect");

        let health = registry.health_check().await;
        assert!(health.is_ok(), "Health check should succeed");
        assert!(health.unwrap(), "Semantic-Store should be healthy");
    }
}
```

---

## 🔧 Execution Workflow

### Phase 2.1 Starten

```bash
cd /home/wind/code/ghost-coding-cave-v0.2a

# 1. Semantic-Store starten (falls nicht läuft)
cd services/semantic-store
cargo run --bin ss-api &

# 2. AI-Server mit neuem Client kompilieren
cd ../../rust-core/crates/ai-server
cargo build

# 3. Tests ausführen
cargo test --test semantic_store_tests

# 4. Code Review
cargo clippy -- -D warnings
```

### Checklist für Task 2.1

- [ ] Proto-Datei erstellt und kompiliert
- [ ] gRPC-Client implementiert
- [ ] Health-Check Test bestanden
- [ ] List-Models Test bestanden
- [ ] Clippy: Keine Warnings
- [ ] Documentation aktualisiert

---

## 📊 Success Criteria für Phase 2.1

| Kriterium | Beschreibung | Akzeptanzkriterien |
|-----------|-------------|-------------------|
| **Konnektivität** | AI-Server verbindet sich mit Semantic-Store | ✅ Successful handshake |
| **Model Discovery** | AI-Server kann Models auflisten | ✅ >0 Models returned |
| **Model Loading** | AI-Server kann einzelne Models laden | ✅ Manifest + Blob vollständig |
| **Error Handling** | Robustes Error-Handling für Netzwerk-Fehler | ✅ Graceful fallbacks |
| **Tests** | Unit Tests mit Mocking | ✅ 100% Pass Rate |
| **Documentation** | Code + API dokumentiert | ✅ Doc Comments vorhanden |

---

## 🎯 Nächste Schritte

Nach Task 2.1 Abschluss:
1. **→ Task 2.2:** Helper-Core Integration
2. **→ Task 2.3:** Model Loading Pipeline
3. **→ Task 2.4:** Docker Compose
4. **→ Task 2.5:** Testing & Documentation

**Geschätzter Timeline:**
- Task 2.1: 1 Tag
- Task 2.2: 1 Tag
- Task 2.3: 1-2 Tage
- Task 2.4: 1 Tag
- Task 2.5: 0.5 Tage

---

## 📞 References

- `docs/PHASE2_ROADMAP.md` — Vollständige Phase 2 Planung
- `docs/PROGRESS.md` — Phase 1 Summary
- `rust-core/crates/ai-server/` — AI-Server Source
- `services/semantic-store/` — Semantic-Store Implementation

---

**Status:** 🟢 Ready for Execution  
**Last Updated:** 31. Oktober 2025
