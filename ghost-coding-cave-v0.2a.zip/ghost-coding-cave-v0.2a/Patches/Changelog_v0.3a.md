# Changelog v0.3a – Full Session Progress Log

**Date:** 31. Oktober 2025  
**Version:** 0.3a  
**Session Start:** TBD (tracking started)  
**Scope:** Capsule DB models, API endpoint implementation, CLI integration tests, CI/CD automation, Playwright E2E tests, Prisma cleanup.

---

## Executive Summary

This phase completes the Ghost Coding Cave v0.2a platform with full API integration, automated testing, and CI/CD. Key objectives:
- ✅ Add database models for capsule persistence
- ✅ Implement `/v1/capsules/upload` API endpoint with signature validation
- ✅ Create integration tests for CLI sign/verify workflow
- ✅ Setup GitHub Actions with automated E2E testing
- ✅ Configure Docker Compose for seamless testing environment
- ✅ Create Playwright UI tests for Admin functionality
- ✅ Remove runtime Prisma dependency (Semantic-Store as single data layer)

---

## Session Timeline (Detailed Changes)

---

## Highlights
- One database: Semantic Store (our own code) – Postgres/Redis removed from default runtime.
- API = HTTP gateway to ss-api; Prisma fully removed from runtime/build.
- Admin Dashboard tabs for Models & Tokenizers, wired to the API.
- CI: API E2E (Supertest) + krun build verification; groundwork for UI sanity tests.
- Build: API Dockerfile cleanup, smaller image; patchelf compatibility fix in libkrun pipeline.

---

## Changes in Detail

### 1) Semantic Store (Single Source of Truth)
- Added `ss-core` crate (persistent JSON store with RwLock):
  - Records: ModelRecord, TokenizerRecord
  - Operations: list_models, create_model, get_model, update_model_status, delete_model, list_tokenizers, upsert_tokenizer
  - Persistence: `index.json` at `SS_STORAGE` path (configurable)
- Extended `ss-api` to embed `ss-core` and expose HTTP endpoints:
  - `GET /v1/models`, `POST /v1/models`
  - `GET /v1/tokenizers`, `POST /v1/tokenizers`
  - Existing Ghost helpers remain: manifest validate/schema, pack
- Docker Compose: `semantic-store-api` is the only DB service by default; ports 4011 (HTTP)/4012 (gRPC reserved)

### 2) API Gateway (NestJS)
- New Semantic Store client module:
  - `apps/api/src/semantic-store/semantic-store.service.ts` (HTTP client)
  - `apps/api/src/semantic-store/semantic-store.module.ts`
- New REST modules/controllers:
  - Models: `/api/models` (list/create)
  - Tokenizers: `/api/tokenizers` (list/upsert)
- Swagger/OpenAPI:
  - DTOs: `apps/api/src/dto/models.dto.ts`, `apps/api/src/dto/tokenizers.dto.ts`
  - Tagged sections: Models, Tokenizers; served at `/api/docs`
- Removed Prisma dependency from API:
  - `apps/api/package.json`: `@ghost/database` removed; added `supertest` (dev)
  - `DISABLE_DB=true` default; DB service/module detached from runtime
- E2E smoke tests (Supertest + Jest):
  - `apps/api/test/models.e2e-spec.ts`
  - `apps/api/test/tokenizers.e2e-spec.ts`
  - Tests hit real ss-api via `SEMANTIC_STORE_HTTP_URL`

### 3) Dashboard (Next.js) – Admin Integration
- New admin components:
  - `apps/dashboard/src/components/admin/AdminModels.tsx`
  - `apps/dashboard/src/components/admin/AdminTokenizers.tsx`
- Admin navigation updated to include new tabs:
  - `apps/dashboard/src/app/admin/page.tsx`
- Data flows:
  - Models: GET/POST `${NEXT_PUBLIC_API_URL}/api/models`
  - Tokenizers: GET/POST `${NEXT_PUBLIC_API_URL}/api/tokenizers`

### 4) CI/CD Workflows
- API E2E pipeline:
  - `.github/workflows/api-e2e.yml`
  - Builds and starts `ss-api` container, runs `npm ci && npm run build && npm test` in `apps/api`
- krun build verification:
  - `.github/workflows/krun.yml`
  - Validates `DT_NEEDED` and `RPATH` for libkrun artifacts via `patchelf`
- (Planned) UI sanity tests (Playwright) workflow groundwork; to be enabled next

### 5) Docker & DevOps
- docker-compose.yml
  - Removed Postgres/Redis from default; ss-api is the DB
  - Profiles kept (`llm`, `ai`, `mirror`) for optional services
  - API ENV includes `SEMANTIC_STORE_HTTP_URL` and `SEMANTIC_STORE_GRPC_URL`
- API Dockerfile cleanup (`apps/api/Dockerfile`):
  - Removed Prisma generate/engines + monorepo package copy
  - Image is substantially smaller; `EXPOSE 5906` and `DISABLE_DB=true`

### 6) Build Tooling & Scripts
- libkrun pipeline hardening (`scripts/ghost/build_libkrun.sh`):
  - Replaced unsupported `patchelf --set-needed` with compatible `--add-needed` (guarded by `--print-needed`)
  - Added `verify_elf` (checks DT_NEEDED for `libkrunfw.so.<ABI>` and RPATH `$ORIGIN`)
- Make & Just helpers:
  - `scripts/ghost/Makefile` – `krun` target to build+verify and print env exports
  - `Justfile` – `ghost-krun` and `ghost-env` tasks

---

## Version Bumps
- Crates:
  - `semantic-store/ss-api`: 0.2.1
  - `semantic-store/ss-core`: 0.2.1
  - `semantic-store/ss-cli`: 0.2.1
  - `semantic-store/ss-gf`: 0.2.1
  - `semantic-store/ss-gp`: 0.2.1
- Apps:
  - `apps/api`: 0.2.1
  - `apps/dashboard`: 0.2.1
- Patch Release Tag (this document): v0.3a

---

## Migration Notes
- API is DB-free at runtime; ensure `SEMANTIC_STORE_HTTP_URL` points to ss-api (Compose sets this automatically)
- Remove local Prisma leftovers; no Prisma imports remain in API
- Dashboard requires `NEXT_PUBLIC_API_URL` (provided by Compose)

---

## Known Next Steps
- Extend `ss-core` & `ss-api` with Files/Versions (blob I/O, dedup, append-only version logs)
- Add REST for Files/Versions + migration of API endpoints
- Add UI sanity tests (Playwright) and wire CI workflow to run Dashboard against live API/Store
- Optional: Swagger JSON export artifact in CI

---

## File & Patch Inventory (Key)
- Semantic Store:
  - `semantic-store/ss-core/*` (new & updated)
  - `semantic-store/ss-api/src/main.rs` (routes for models/tokenizers)
  - `semantic-store/ss-api/Cargo.toml` (dep on ss-core)
- API:
  - `apps/api/src/semantic-store/*` (client)
  - `apps/api/src/models/*`, `apps/api/src/tokenizers/*` (controllers/modules)
  - `apps/api/src/dto/*` (Swagger DTOs)
  - `apps/api/test/*` (E2E tests)
  - `apps/api/Dockerfile` (cleanup)
  - `apps/api/package.json` (remove Prisma, add supertest, version bump)
- Dashboard:
  - `apps/dashboard/src/components/admin/AdminModels.tsx`
  - `apps/dashboard/src/components/admin/AdminTokenizers.tsx`
  - `apps/dashboard/src/app/admin/page.tsx` (tabs & dynamic load)
  - `apps/dashboard/package.json` (version bump)
- CI:
  - `.github/workflows/api-e2e.yml`
  - `.github/workflows/krun.yml`
- Build/Tooling:
  - `scripts/ghost/build_libkrun.sh` (patchelf fix + verify_elf)
  - `scripts/ghost/Makefile` (krun)
  - `Justfile` (ghost-krun, ghost-env)

---

## Appendix: Release Notes Summary
- Semantic-Store-only architecture live (single DB)
- API → HTTP gateway; Swagger documented
- Admin UI for Models/Tokenizers
- CI covers API E2E; krun verified
- Images lighter; compose simplified

