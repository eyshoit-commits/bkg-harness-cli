# Ghost Coding Cave – LLM Stack Status

## Aktueller Stand im Repository

- Rust-Workspace‑Mitglieder: `helper-core`, `semantic-adapter`, `storage-adapter`, `gateway`, `ai-server`.
- Unter `/services/helper-db` liegt der komplette Helper-DB-Workspace (Core, Index, Query, API, CLI, PGML, Metrics, Plugins). In `STATUS.md` und `AGENTS.md` wird diese Technologie bereits als „semantic“/„semantic-store“ referenziert, im v0.2a-Stack ist sie jedoch noch nicht aktiv eingebunden.
- `ai-server` nutzt weiterhin einen Stub-Registry-Layer und speichert Attrappen unter `HELPER_DB_PATH`. `helper-core`, `semantic-adapter` und `storage-adapter` arbeiten derzeit ohne persistente Backing-Engine.
- Dokumentation und Statuslisten gehen noch von einer fertigen Helper-Integration aus, tatsächlich fehlt der Anschluss an den nun „semantic-store“ genannten Service.

## Semantic-Store Aufgabenliste (basierend auf helper-db Architektur)

1. **Workspace-Einbindung & Benennung**
   - Den Helper-DB-Workspace als `services/semantic-store` in den v0.2a-Build- und Compose-Prozess übernehmen.
   - Einheitliche Namensführung: „semantic-store“ für Service, API und CLI; Verweise in `STATUS.md`, `AGENTS.md`, Docs und Code anpassen.

2. **Storage Engine & WAL (helper-db-core)**
   - Konfiguration für WAL-Pfade, Snapshot-Verzeichnisse und Page-Management in der v0.2a-Umgebung anlegen.
   - Seeder/Snapshot-Routinen definieren (über CLI oder Admin-Endpoint), damit Modelle, Tokenizer und Trainingsjobs initial geladen werden können.

3. **Vektorindizes (helper-db-index)**
   - HNSW/IVF-Index-Lifecycle aktivieren: Training, Persistierung, Wiederherstellung über semantic-store APIs.
   - Admin-UI/API zum Erstellen/Löschen der Indizes einbauen.

4. **Query/DSL-Schicht (helper-db-query)**
   - REST/gRPC-Endpunkte für SQL-ähnliche Abfragen und Streaming (`/query`, `/query/stream`) verfügbar machen.
   - Integrationstests schreiben, die Speicher- und Indexpfade kombinieren.

5. **API Layer & Telemetrie (helper-db-api / metrics)**
   - HTTP (Axum) + gRPC (tonic) Server in Compose aufnehmen (Ports 8443/9443, Health, Metrics, Jaeger/Prometheus Integration).
   - `helper-db-metrics` an zentralen Monitoring-Stack anbinden und Dashboard-Widgets vorbereiten.

6. **PGML / Embedding Runtime (helper-db-pgml)**
   - Modelle im semantic-store speichern (`pgml::model::<name>`), Inferenzendpunkte für AI-Server/helper-core anbinden.
   - Caching & Training-Flows (`TrainSample`, LoRA etc.) über REST/CLI expose’n und ins Admin-Dashboard spiegeln.

7. **CLI & Plugin-Ökosystem (helper-db-cli, helper-db-plugins)**
   - CLI-Befehle (`start-api`, `snapshot`, `train-model`, `query`, `create-index`, `register-plugin` ...) in den DevOps-Workflow integrieren.
   - Plugin-Management (OpenAI, Ollama) in UI/API aufnehmen, Credentials sicher speichern.

8. **Adapter-Neuanbindung**
   - `helper-core`, `semantic-adapter`, `storage-adapter`, `ai-server` auf den semantic-store umstellen (statt lokaler Stubs oder In-Memory). Einheitliche Auth/Config (z. B. gRPC-Channel oder Embedded Crate).

9. **Admin-Dashboard & Service-Steuerung**
   - UI zum Modell-Download (GGUF, ONNX, Transformers) und Verwaltung im semantic-store.
   - Start/Stop/Restart für semantic-store, AI-Server, Gateway; Echtzeit-Statusanzeigen (Modelle, Trainingsjobs, Metriken).

10. **Dokumentations- und Statusabgleich**
   - `STATUS.md`, `AGENTS.md`, `API_REFERENCE.md`, `PRODUCTION_READINESS.md`, `OPS_CHECKLIST.md` auf die semantic-store-Realität aktualisieren.
   - Neuer Abschnitt zu Admin-/CLI-Workflows, Format-Support und Monitoring.

## Zusammenfassung

Der Helper-DB-Workspace bildet das Fundament für unseren „semantic-store“. Damit der Stack produktiv wird, muss dieser Service in v0.2a eingebunden, konfiguriert und an sämtliche Adapter/Services angebunden werden. Sobald WAL/Snapshots, Indizes, Query-DSL, PGML sowie Admin-/Dashboard-Funktionen bereitstehen und die Dokumentation angepasst ist, arbeiten AI-Server, helper-core und UI auf einer gemeinsamen persistenten Datenbasis.
