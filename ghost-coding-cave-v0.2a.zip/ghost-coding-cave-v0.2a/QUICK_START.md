# 🚀 Quick Setup Guide

**Ghost Coding Cave v0.2a — Local Development Setup**

---

## ⚡ 5-Minute Quick Start

### 1. Prerequisites

```bash
# Check installations
node --version    # v18+ required
npm --version     # v8+ required
rust --version    # Latest stable
postgres --version # Running on port 5432 (Docker OK)
```

### 2. Clone & Install

```bash
cd /home/wind/code/ghost-coding-cave-v0.2a

# Install dependencies
npm install

# Generate Prisma client
npm run db:generate
```

### 3. Setup Data Directories

```bash
mkdir -p data/{ai-server,semantic-store}
chmod 755 data
```

### 4. Configure Environment

```bash
# Copy template
cp .env.example .env.local

# Update HELPER_DB_PATH to your local path
# Edit .env.local and set:
HELPER_DB_PATH="/home/wind/code/ghost-coding-cave-v0.2a/data/helper.db"
```

### 5. Start Services (Terminal 1)

```bash
npm run dev
# Dashboard: http://localhost:4004
# API: http://localhost:3000
```

### 6. Start AI-Server (Terminal 2)

```bash
cd rust-core
HELPER_DB_PATH=/home/wind/code/ghost-coding-cave-v0.2a/data/helper.db \
  cargo run --bin ai-server
# AI-Server: http://localhost:5001
```

### 7. Start Semantic-Store (Terminal 3)

```bash
cd services/semantic-store
cargo run --bin ss-api
# Semantic-Store: http://localhost:8443
# gRPC: grpc://localhost:9443
```

---

## 🛠️ Troubleshooting

### Issue: AI-Server fails with "Permission denied"

**Solution:**
```bash
# Check HELPER_DB_PATH
echo $HELPER_DB_PATH

# Create data directory
mkdir -p data/ai-server

# Run with absolute path
cd rust-core
HELPER_DB_PATH="$(pwd)/../data/helper.db" cargo run --bin ai-server
```

### Issue: `npm run dev` fails

**Solution:**
```bash
# Generate Prisma
npm run db:generate

# Clear cache
rm -rf node_modules/.cache
npm install

# Try again
npm run dev
```

### Issue: PostgreSQL connection fails

**Solution:**
```bash
# Check if running
docker ps | grep postgres

# Start PostgreSQL (if using Docker)
docker run -d --name postgres -e POSTGRES_PASSWORD=password -p 5432:5432 postgres

# Update DATABASE_URL in .env.local if needed
```

### Issue: Cargo compilation errors

**Solution:**
```bash
# Clean and rebuild
cargo clean
cargo build

# Update toolchain
rustup update
```

---

## 📊 Service Status

Check all services running:

```bash
# Terminal checks
lsof -i :3000      # NestJS API
lsof -i :4004      # Next.js Dashboard
lsof -i :5001      # AI-Server
lsof -i :8443      # Semantic-Store HTTP
lsof -i :9443      # Semantic-Store gRPC
lsof -i :5432      # PostgreSQL
```

---

## 🔄 Common Workflows

### Run All Tests

```bash
npm test
cd rust-core && cargo test --workspace
cd services/semantic-store && cargo test --workspace
```

### Build Production

```bash
npm run build
cargo build --release
```

### Start Fresh

```bash
# Kill all services
pkill -f "npm run dev" || true
pkill -f "cargo run" || true

# Clear data (optional)
rm -rf data/*.db

# Restart
npm run dev
```

---

## 📚 Documentation

- **[docs/README.md](./docs/README.md)** — Full documentation index
- **[docs/START.md](./docs/START.md)** — Detailed setup guide
- **[PHASE2_START.md](./PHASE2_START.md)** — Phase 2 implementation guide
- **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — System architecture

---

## 🎯 What's Running?

| Service | Port | Status | Command |
|---------|------|--------|---------|
| Dashboard | 4004 | 🔄 Dev Mode | `npm run dev` |
| API | 3000 | 🔄 Dev Mode | `npm run dev` |
| AI-Server | 5001 | 🟢 Running | `cargo run --bin ai-server` |
| Semantic-Store | 8443 | 🔄 Dev Mode | `cargo run --bin ss-api` |
| PostgreSQL | 5432 | 🐘 Docker | `docker run postgres` |

---

## ✅ Next Steps

1. ✅ Services running
2. 📋 Run tests: `npm test`
3. 🔧 Read `PHASE2_START.md` for next phase
4. 📚 Check `docs/README.md` for documentation index

---

**Last Updated:** 31. Oktober 2025  
**Status:** All services ready ✅
