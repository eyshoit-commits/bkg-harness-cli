# StorageEngine Internals & scan_prefix

## Überblick

Der **StorageEngine** ist das Kernstück des Semantic-Store (`ss-core`) und bietet transaktionale Key-Value Storage mit Write-Ahead Logging (WAL), Page Management und Snapshotting.

Die Implementierung ist für Einbettung in Rust-Services oder als eigenständiger Server optimiert.

## Architektur

### Komponenten

```
┌─────────────────────────────────────┐
│      StorageEngine (Arc<Self>)      │
├─────────────────────────────────────┤
│ - Config: StorageConfig             │
│ - WAL: Arc<WriteAheadLog>           │
│ - PageManager: Arc<PageManager>     │
│ - SnapshotManager                   │
│ - CommitLock: Mutex<()>             │
└─────────────────────────────────────┘
         ↓         ↓              ↓
    ┌────────┬──────────┬──────────────┐
    ↓        ↓          ↓              ↓
  Pages   WAL    Snapshots      Transactions
```

### PageManager

- **Mehrere Pages**: Daten werden in mehrere Pages verteilt (Hash-basierte Partitionierung)
- **BTreeMap pro Page**: Jede Page speichert Daten in einem BTreeMap für sortierte Iteration
- **Page Eviction**: LRU-ähnlicher Cache-Eviction bei Speicherlimit
- **RwLock pro Page**: Parallele Lesezugriffe, exklusive Schreibzugriffe

### WriteAheadLog (WAL)

- **Append-Only Struktur**: Alle Operationen werden sequenziell geschrieben
- **Flush-Strategie**: Konfigurierbare Sync-Intervalle
- **Recovery**: WAL wird beim Starten replayed
- **Snapshot Integration**: Nach dem Snapshot wird WAL zurückgesetzt

## scan_prefix Funktionalität

### Konzept

`scan_prefix(prefix: &[u8])` ist eine neue Methode, die alle Key-Value-Paare zurückgibt, deren Keys mit dem gegebenen Präfix beginnen.

```rust
pub async fn scan_prefix(&self, prefix: &[u8]) -> Result<Vec<KeyValue>> {
    self.page_manager.scan_prefix(prefix).await
}
```

### Implementierung

```rust
// PageManager::scan_prefix
pub async fn scan_prefix(&self, prefix: &[u8]) -> Result<Vec<KeyValue>> {
    let guard = self.pages.read().await;
    let mut results = Vec::new();
    
    // Scan all loaded pages in memory
    for page in guard.values() {
        let page_data = page.data.read().await;
        for (key, value) in page_data.iter() {
            if key.starts_with(prefix) {
                results.push(KeyValue {
                    key: key.clone(),
                    value: value.clone(),
                });
            }
        }
    }
    
    // Also check disk pages that aren't currently loaded
    for page_id in 0..self.config.max_pages as u64 {
        if !guard.contains_key(&page_id) {
            if let Ok(page) = self.load_page_from_disk(page_id).await {
                let page_data = page.data.read().await;
                for (key, value) in page_data.iter() {
                    if key.starts_with(prefix) {
                        results.push(KeyValue {
                            key: key.clone(),
                            value: value.clone(),
                        });
                    }
                }
            }
        }
    }
    
    Ok(results)
}
```

### Performance-Charakteristika

| Szenario | Komplexität | Anmerkungen |
|----------|-------------|-----------|
| **Kleine Prefix** | O(N) | Alle Pages müssen gescannt werden |
| **Viele Matches** | O(N*M) | N = Anzahl Pages, M = Matches pro Page |
| **Disk-Zugriff** | O(K) | K = Anzahl nicht geladener Pages |
| **Memory-Optimiert** | O(L) | L = Anzahl geladener Pages (schneller) |

**Best Practice**: Für häufige Scans sollte das System genug RAM haben um die meisten Pages im Cache zu halten.

## Capsule-Endpunkte mit Prefix-Scan

### Key-Format

```rust
fn encode_manifest_key(id: &Uuid, suffix: &str) -> Vec<u8> {
    format!("capsule::{id}::{suffix}").into_bytes()
}
```

**Beispiele:**
- Manifest: `capsule::550e8400-e29b-41d4-a716-446655440000::manifest`
- Blob: `capsule::550e8400-e29b-41d4-a716-446655440000::blob`

### list_capsules Endpoint

**Route**: `GET /v1/capsules`

**Query-Parameter**:
```rust
struct CapsuleListQuery {
    model_name: Option<String>,      // Prefix-Match
    architecture: Option<String>,    // Exact-Match
    min_size: Option<u64>,          // Size-Filter
    max_size: Option<u64>,          // Size-Filter
    limit: Option<usize>,           // Limit Results
}
```

**Workflow:**
1. Scan mit Präfix `b"capsule::"` um alle Capsule-Keys zu finden
2. Für jeden Key:
   - Parse UUID aus Key-Format `capsule::<uuid>::manifest`
   - Deserialize Manifest aus Value
   - Apply Filters (model_name, architecture, size)
3. Limit anwenden und zurückgeben

### Beispiel-Request

```bash
# Alle Capsules auflisten
curl http://localhost:8443/v1/capsules

# Nach Modellname filtern (Präfix-Match)
curl "http://localhost:8443/v1/capsules?model_name=transformer"

# Nach Architektur filtern
curl "http://localhost:8443/v1/capsules?architecture=transformer"

# Nach Größe filtern
curl "http://localhost:8443/v1/capsules?min_size=1000&max_size=5000"

# Limit und kombinierte Filter
curl "http://localhost:8443/v1/capsules?architecture=gpt&limit=10"
```

## Integration in Semantic-Store

### ss-api HTTP Handler

```rust
#[instrument(skip(state))]
async fn list_capsules(
    Extension(state): Extension<Arc<HttpContext>>,
    Query(query): Query<CapsuleListQuery>,
) -> Result<Json<Vec<CapsuleMetadataResponse>>, ApiError> {
    let storage = state.storage();
    let prefix = b"capsule::";
    let kvs = storage.scan_prefix(prefix).await?;
    
    // Parse und Filter nach Query-Parametern
    // ...
}
```

## Testing

### Unit Tests

Siehe `ss-api/src/http.rs`:
- `put_get_roundtrip`: Basis Key-Value Test
- `upload_and_fetch_capsule_roundtrip`: Capsule Upload/Download
- `list_capsules_with_filters`: Prefix-Scan mit verschiedenen Filtern

### Test-Abdeckung

```rust
#[tokio::test]
async fn list_capsules_with_filters() {
    // Erstelle multiple Capsules mit verschiedenen Properties
    // Test 1: Alle Capsules auflisten
    // Test 2: Nach Modellname filtern (Präfix)
    // Test 3: Nach Architektur filtern
    // Test 4: Nach Größe filtern
    // Test 5: Limit anwenden
    // Test 6: Kombinierte Filter
}
```

## Performance-Optimierungen

### 1. Page Cache Tuning

```toml
# semantic-store/config/default.toml
max_pages = 64  # Abhängig vom RAM
```

Höhere Werte = mehr RAM, aber schneller Scan bei vielen Pages.

### 2. Index-Struktur

Die BTreeMap pro Page ermöglicht:
- **Range Queries**: `range_prefix()` für Future-Optimierungen
- **Sorted Iteration**: Natürliche Sortierung nach Key

### 3. Snapshot-Strategie

```rust
// Nach N Transaktionen Snapshot erstellen
if transaction.should_snapshot() {
    self.flush_snapshot().await?;
}
```

Dies reduziert WAL-Größe und beschleunigt Recovery.

## Bekannte Limitierungen

1. **No Distributed Scan**: Scan arbeitet nur auf einem Node (kein Clustering)
2. **Memory-bound**: Große Prefix-Scans können viel RAM verbrauchen
3. **Blocking Disk I/O**: Nicht geladene Pages blockieren während des Ladens
4. **No Partial Iteration**: scan_prefix muss alle Matches laden

## Zukünftige Verbesserungen

- [ ] **Async Iterator**: Streaming-Ergebnisse statt vollständiger Vektor
- [ ] **Bloom Filter**: Schnelle Negative-Checks vor Disk-Zugriff
- [ ] **B-Tree Index**: Dedizierter Index für Präfix-Queries
- [ ] **Distributed Scan**: Multi-Node Scanning für Cluster
- [ ] **Range Queries**: `scan_range(start, end)` für arbitrary Range-Scans

## Zusammenfassung

Der StorageEngine mit `scan_prefix` bietet:
- ✅ **Transaktional**: WAL-basierte ACID-Garantien
- ✅ **Effizient**: Page-basiertes Caching
- ✅ **Flexibel**: Beliebige Präfix-Patterns
- ✅ **Einfach**: Async/await API

Ideal für Modellregistries, Capsule-Management und andere Key-Value-Workloads mit Präfix-Access-Patterns.
