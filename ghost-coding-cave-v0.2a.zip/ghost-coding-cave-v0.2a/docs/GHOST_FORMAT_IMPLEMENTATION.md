# .ghost Format Implementation Guide

**Referenz:** `ghost-prompt.md` (Original-Spezifikation)  
**Status:** Phase 2 — Core Implementation COMPLETE ✅  
**Updated:** 31. Oktober 2025

## 🚀 Quick Start (Phase 2 Complete)

```bash
# Build and test ghost format utilities
cd services/semantic-store/ss-gf
cargo test -q

# Pack a capsule
cargo run --bin ghost-pack -- pack \
  --payload ./payload-dir \
  --manifest ./manifest.json \
  --output ./model.ghost

# Extract a capsule
cargo run --bin ghost-pack -- extract \
  --input ./model.ghost \
  --output ./out-dir
```

---

## 📋 Overview

Das `.ghost`-Format ist ein **universeller Modell-Container** für sichere Speicherung, Versionierung und Verteilung von AI-Modellen. Es vereinheitlicht GGUF, ONNX, Transformers und Custom-Modelle in ein verifizierbare Format.

### Warum `.ghost`?
- ✅ **Format-Unabhängig**: GGUF, ONNX, Transformers → `.ghost`
- ✅ **Sicherheit**: Ed25519 Signaturen, SHA3-512 Hashes
- ✅ **Nachverfolgbarkeit**: Audit-Chain für alle Operationen
- ✅ **Versionierung**: Immutable Kapsel-Registry
- ✅ **Performance**: Kompression (Zstd/Brotli), Streaming-Support

---

## 🏗️ Architecture

### `.ghost` Kapsel Struktur

```
[HEADER - 48 Byte]
├─ magic: "GHOST" (5 Byte)
├─ version: u16 (2 Byte)
├─ compression: u8 (1 Byte)
│  └─ 0 = none, 1 = zstd, 2 = brotli
├─ flags: u32 (4 Byte)
│  └─ signed, encrypted, has_audit_chain
├─ manifest_offset: u64 (8 Byte)
└─ fingerprint: [u8; 64] (64 Byte SHA3-512)

[PAYLOAD - Variable]
├─ model_weights (Tar-Archiv, optional komprimiert)
├─ tokenizer_files
├─ adapter_configs
├─ embeddings
└─ custom_artifacts

[MANIFEST - JSON]
├─ metadata
│  ├─ id: UUID
│  ├─ name: string
│  ├─ version: semver
│  ├─ created_at: RFC3339
│  ├─ source_format: enum(gguf|onnx|transformers|custom)
│  └─ description: string
│
├─ model_info
│  ├─ architecture: string
│  ├─ parameters: u64
│  ├─ quantization: enum(fp32|fp16|int8|int4)
│  ├─ context_length: u32
│  ├─ layer_count: u32
│  └─ hidden_size: u32
│
├─ security
│  ├─ signature: ed25519
│  ├─ signer_id: string
│  ├─ created_hash: sha3-512
│  ├─ payload_hash: sha3-512
│  └─ layer_hashes: Vec<sha3-512>
│
├─ runtime_profile
│  ├─ engine: enum(ggml|onnx|pytorch|triton)
│  ├─ device_preference: enum(cpu|gpu|auto)
│  ├─ memory_estimate_mb: u32
│  └─ constraints: Vec<RuntimeConstraint>
│
├─ policies
│  ├─ license: string
│  ├─ usage_restrictions: Vec<string>
│  ├─ model_card_url: string
│  └─ requires_attribution: bool
│
└─ audit_chain
   └─ events: Vec<AuditEvent>
      ├─ timestamp: RFC3339
      ├─ event_type: enum(created|converted|trained|validated)
      ├─ actor: string
      └─ details: JSON
```

---

## 📦 Phase 2: Core Format Implementation

### 2.1 Format Specification

**Datei:** `services/semantic-store/ss-gf/src/lib.rs`

```rust
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

// Header Definition
const MAGIC: &[u8] = b"GHOST";
const VERSION: u16 = 1;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GhostHeader {
    pub magic: [u8; 5],      // "GHOST"
    pub version: u16,
    pub compression: CompressionType,
    pub flags: u32,
    pub manifest_offset: u64,
    pub fingerprint: [u8; 64], // SHA3-512
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum CompressionType {
    None = 0,
    Zstd = 1,
    Brotli = 2,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GhostManifest {
    pub metadata: ManifestMetadata,
    pub model_info: ModelInfo,
    pub security: SecurityInfo,
    pub runtime_profile: RuntimeProfile,
    pub policies: Policies,
    pub audit_chain: AuditChain,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ManifestMetadata {
    pub id: String,           // UUID
    pub name: String,
    pub version: String,      // semver
    pub created_at: String,   // RFC3339
    pub source_format: SourceFormat,
    pub description: String,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum SourceFormat {
    GGUF,
    ONNX,
    Transformers,
    Custom,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    pub architecture: String,
    pub parameters: u64,
    pub quantization: QuantizationType,
    pub context_length: u32,
    pub layer_count: u32,
    pub hidden_size: u32,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum QuantizationType {
    FP32,
    FP16,
    INT8,
    INT4,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityInfo {
    pub signature: Vec<u8>,   // Ed25519 64 Bytes
    pub signer_id: String,
    pub created_hash: String, // SHA3-512 hex
    pub payload_hash: String,
    pub layer_hashes: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuntimeProfile {
    pub engine: Engine,
    pub device_preference: DevicePreference,
    pub memory_estimate_mb: u32,
    pub constraints: Vec<RuntimeConstraint>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum Engine {
    GGML,
    ONNX,
    PyTorch,
    Triton,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum DevicePreference {
    CPU,
    GPU,
    Auto,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuntimeConstraint {
    pub constraint_type: String,
    pub value: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Policies {
    pub license: String,
    pub usage_restrictions: Vec<String>,
    pub model_card_url: String,
    pub requires_attribution: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditChain {
    pub events: Vec<AuditEvent>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditEvent {
    pub timestamp: String,  // RFC3339
    pub event_type: AuditEventType,
    pub actor: String,
    pub details: serde_json::Value,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum AuditEventType {
    Created,
    Converted,
    Trained,
    Validated,
}

// Helper Functions
impl GhostManifest {
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }

    pub fn from_json(json: &str) -> Result<Self, serde_json::Error> {
        serde_json::from_str(json)
    }

    pub fn compute_hash(&self) -> String {
        use sha3::{Sha3_512, Digest};
        let json = self.to_json().unwrap();
        let mut hasher = Sha3_512::new();
        hasher.update(json.as_bytes());
        format!("{:x}", hasher.finalize())
    }
}
```

### 2.2 Capsule Container Builder

**Datei:** `services/semantic-store/ss-gf/src/container.rs`

```rust
use std::io::{Write, Read};
use std::path::Path;

pub struct CapsuleBuilder {
    manifest: GhostManifest,
    payload_data: Vec<u8>,
    compression: CompressionType,
}

impl CapsuleBuilder {
    pub fn new(manifest: GhostManifest, compression: CompressionType) -> Self {
        Self {
            manifest,
            payload_data: Vec::new(),
            compression,
        }
    }

    pub fn add_payload(&mut self, data: Vec<u8>) -> Result<&mut Self, std::io::Error> {
        self.payload_data = data;
        Ok(self)
    }

    pub fn build(&self) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let mut output = Vec::new();

        // 1. Compute hashes
        let payload_hash = self.compute_sha3_512(&self.payload_data);
        let manifest_json = self.manifest.to_json()?;
        
        // 2. Create header
        let header = self.create_header(&payload_hash)?;
        output.extend_from_slice(&header);

        // 3. Add payload (optionally compressed)
        let payload = match self.compression {
            CompressionType::None => self.payload_data.clone(),
            CompressionType::Zstd => zstd::encode_all(&self.payload_data[..], 3)?,
            CompressionType::Brotli => {
                let mut compressed = Vec::new();
                brotli::BrotliEncoderOperation::Finish.into();
                // ... brotli compression
                compressed
            }
        };
        output.extend_from_slice(&payload);

        // 4. Add manifest
        let manifest_offset = output.len() as u64;
        output.extend_from_slice(manifest_json.as_bytes());

        Ok(output)
    }

    fn create_header(&self, payload_hash: &str) -> Result<Vec<u8>, std::io::Error> {
        let mut header = Vec::new();

        // Magic
        header.extend_from_slice(b"GHOST");

        // Version
        header.extend_from_slice(&(1u16).to_le_bytes());

        // Compression type
        header.push(self.compression as u8);

        // Flags (placeholder)
        header.extend_from_slice(&(0u32).to_le_bytes());

        // Manifest offset (placeholder)
        header.extend_from_slice(&(0u64).to_le_bytes());

        // Fingerprint (SHA3-512 of entire capsule)
        let fingerprint = [0u8; 64]; // Will be updated after building
        header.extend_from_slice(&fingerprint);

        Ok(header)
    }

    fn compute_sha3_512(&self, data: &[u8]) -> String {
        use sha3::{Sha3_512, Digest};
        let mut hasher = Sha3_512::new();
        hasher.update(data);
        format!("{:x}", hasher.finalize())
    }
}
```

---

## 🔄 Phase 3: Format Conversion Pipeline

### 3.1 GGUF → .ghost Converter

**Datei:** `services/semantic-store/ss-cli/src/converters/gguf.rs`

```rust
use async_trait::async_trait;

pub struct GgufConverter;

#[async_trait]
pub trait ModelConverter {
    async fn convert(&self, input_path: &Path) -> Result<GhostManifest>;
}

#[async_trait]
impl ModelConverter for GgufConverter {
    async fn convert(&self, input_path: &Path) -> Result<GhostManifest> {
        // 1. Load GGUF metadata
        let gguf_meta = load_gguf_metadata(input_path).await?;

        // 2. Extract model info
        let model_info = ModelInfo {
            architecture: gguf_meta.architecture,
            parameters: gguf_meta.param_count,
            quantization: parse_quantization(&gguf_meta),
            context_length: gguf_meta.context_length,
            layer_count: gguf_meta.layer_count,
            hidden_size: gguf_meta.hidden_size,
        };

        // 3. Create manifest
        let manifest = GhostManifest {
            metadata: ManifestMetadata {
                id: uuid::Uuid::new_v4().to_string(),
                name: gguf_meta.model_name,
                version: "1.0.0".to_string(),
                created_at: chrono::Utc::now().to_rfc3339(),
                source_format: SourceFormat::GGUF,
                description: gguf_meta.description,
            },
            model_info,
            security: SecurityInfo {
                signature: vec![],
                signer_id: "system".to_string(),
                created_hash: String::new(),
                payload_hash: String::new(),
                layer_hashes: vec![],
            },
            runtime_profile: RuntimeProfile {
                engine: Engine::GGML,
                device_preference: DevicePreference::Auto,
                memory_estimate_mb: estimate_memory(&model_info),
                constraints: vec![],
            },
            policies: Policies {
                license: gguf_meta.license.unwrap_or_default(),
                usage_restrictions: vec![],
                model_card_url: String::new(),
                requires_attribution: true,
            },
            audit_chain: AuditChain {
                events: vec![AuditEvent {
                    timestamp: chrono::Utc::now().to_rfc3339(),
                    event_type: AuditEventType::Converted,
                    actor: "converter".to_string(),
                    details: serde_json::json!({"source": "gguf"}),
                }],
            },
        };

        Ok(manifest)
    }
}
```

### 3.2 ONNX → .ghost Converter

**Datei:** `services/semantic-store/ss-cli/src/converters/onnx.rs`

```rust
pub struct OnnxConverter;

#[async_trait]
impl ModelConverter for OnnxConverter {
    async fn convert(&self, input_path: &Path) -> Result<GhostManifest> {
        // Similar to GGUF but:
        // 1. Load ONNX model via ort crate
        // 2. Extract graph structure
        // 3. Create compatible manifest
        // 4. Set engine: Engine::ONNX
        // ...
    }
}
```

### 3.3 Transformers → .ghost Converter

**Datei:** `services/semantic-store/ss-cli/src/converters/transformers.rs`

```rust
pub struct TransformersConverter;

#[async_trait]
impl ModelConverter for TransformersConverter {
    async fn convert(&self, input_path: &Path) -> Result<GhostManifest> {
        // 1. Load from Hugging Face config.json
        // 2. Extract architecture from model.safetensors or pytorch_model.bin
        // 3. Create compatible manifest
        // 4. Set engine: Engine::PyTorch
        // ...
    }
}
```

---

## 🛠️ Phase 4: CLI Tools

### CLI Command Structure

```bash
# Pack a model
ghost pack --input llama2.gguf --output llama2.ghost --format gguf

# Validate integrity
ghost validate llama2.ghost

# Inspect manifest
ghost inspect llama2.ghost

# Extract components
ghost extract llama2.ghost --output-dir ./llama2-components

# Upload to semantic-store
ghost upload llama2.ghost --registry http://localhost:8443

# Sign capsule
ghost sign llama2.ghost --key ./private.key
```

---

## 📊 Database Schema

**Semantic-Store Schema Update:**

```sql
CREATE TABLE capsules (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    manifest JSONB NOT NULL,
    blob_path TEXT NOT NULL,
    size_bytes BIGINT NOT NULL,
    source_format TEXT NOT NULL,
    engine TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    created_by TEXT,
    
    -- Vector for semantic search
    embedding VECTOR(1536) GENERATED STORED AS (
        model('text-embedding-3-small', name || ' ' || description)
    ) STORED
);

CREATE TABLE capsule_audit (
    id UUID PRIMARY KEY,
    capsule_id UUID REFERENCES capsules(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    actor TEXT,
    details JSONB
);

CREATE INDEX idx_capsules_name ON capsules(name);
CREATE INDEX idx_capsules_engine ON capsules(engine);
CREATE INDEX idx_capsules_created ON capsules(created_at);
```

---

## ✅ Success Criteria

| Kriterium | Phase | Status |
|-----------|-------|--------|
| Format Spec fertig | 2 | ✅ |
| Header/Manifest implementiert | 2 | ✅ |
| Capsule Builder | 2 | ✅ |
| CLI Tools (ghost-pack) | 2 | ✅ |
| ss-gf Unit Tests | 2 | ✅ (2/2 passing) |
| GGUF Converter | 3 | ⏳ |
| ONNX Converter | 3 | ⏳ |
| Transformers Converter | 3 | ⏳ |
| Database Integration | 4 | ⏳ |
| Integrationstest | 5 | ⏳ |

---

## 📞 References

**Original Spezifikation:**
- `ghost-prompt.md` — Vollständige Anforderungen

**Implementation Guides:**
- `docs/PHASE2_ROADMAP.md` — Phase 2-4 Planning
- `docs/STORAGE_ENGINE.md` — Persistent Storage
- `docs/PROGRESS.md` — Current Status

**Codebase:**
- `services/semantic-store/ss-gf/` — Format Core
- `services/semantic-store/ss-cli/` — CLI Tools
- `services/semantic-store/ss-api/` — API Integration

---

**Status:** ✅ Phase 2 Core Format Complete  
**Completed in this session:**
- ✅ `ss-gf` crate fully implemented (manifest, header, capsule create/read)
- ✅ 2/2 unit tests passing
- ✅ CLI tool `ghost-pack` for pack/extract operations
- ✅ README with usage examples

**Next Step:** Phase 3 Converters (GGUF, ONNX, Transformers → .ghost)

**Quick Test:**
```bash
# Build & test
cd services/semantic-store/ss-gf
cargo test -q
cargo build --bins

# Use CLI
./target/debug/ghost-pack pack --help
./target/debug/ghost-pack extract --help
```
