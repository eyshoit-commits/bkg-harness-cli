# TASKS — ghost-coding-cave-v0.2a

> Stand: CHECK_2026-09-17_171722.md

---

## M1 — Runtime-Verifikation: Rust Gateway E2E [READY]

- [ ] `cd rust-core && cargo build -p ghost-gateway`
- [ ] `GHOST_GATEWAY_PORT=8080 cargo run -p ghost-gateway`
- [ ] `curl http://localhost:8080/health` → `{"service":"ghost-gateway","status":"ok",...}`
- [ ] `curl -X POST http://localhost:8080/api/storage/embeddings/index ...` → HTTP 200

---

## M2 — Docker Dashboard aktivieren [READY]

- [ ] `docker-compose.yml`: Zeilen 109–126 (dashboard service) entkommentieren
- [ ] `docker compose up dashboard`
- [ ] Browser http://localhost:4007 → Dashboard rendert und zeigt Login/Caves

---

## M3 — Rust Gateway im Docker aktivieren [BLOCKED by M1]

- [ ] `docker-compose.yml`: Zeilen 128–164 (ghost-gateway, storage-adapter-init) entkommentieren
- [ ] `docker compose up ghost-gateway`
- [ ] `curl http://localhost:4010/health` → OK

---

## M4 — Tests: Disk-Space-Blocker auflösen [BLOCKED — Infra]

- [ ] Disk-Space freimachen (`/tmp` + `/` waren 100% voll)
- [ ] `cd rust-core && cargo test --workspace` → alle 20 Tests grün
- [ ] Test-Report: "test result: ok. 20 passed; 0 failed"

---

## Erkannte Lücken (kein Scope)

- NestJS API und Rust Gateway haben überlappende Domänen — langfristiger Merge-Bedarf ohne bestätigten Scope
- Ghost Format CLI-Befehle (ss-gp: pack/validate/inspect) noch nicht in Gateway/API integriert
- Chunked Streaming für lange AI-Responses (TODO in STATUS.md)
- Dashboard-Capsule-Wiring (listing, delete in /v1/capsules)
- Semantic Store API-Docs nicht aktuell (STATUS.md Phase F "Pending")
