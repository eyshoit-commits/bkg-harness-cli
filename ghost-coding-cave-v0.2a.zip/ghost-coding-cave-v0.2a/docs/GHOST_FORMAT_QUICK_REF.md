# .ghost Format Quick Reference

**Kurze Übersicht der `.ghost` Kapsel-Struktur**  
**Referenz für Entwicklung & Debugging**

---

## 📦 Binary Format (Wire Format)

```
┌─────────────────────────────────┐
│     HEADER (48 bytes fixed)     │
├─────────────────────────────────┤
│   Byte 0-4:  "GHOST" (magic)    │
│   Byte 5-6:  version (u16 LE)   │
│   Byte 7:    compression (u8)   │
│   Byte 8-11: flags (u32 LE)     │
│   Byte 12-19: manifest_offset   │
│   Byte 20-83: fingerprint SHA3  │
├─────────────────────────────────┤
│  PAYLOAD (variable, optional    │
│  compression: zstd/brotli/none) │
├─────────────────────────────────┤
│  MANIFEST (JSON, variable)      │
└─────────────────────────────────┘
```

---

## 🔢 Hex Dump Example

```
Offset  Hex                                    ASCII
0x0000  47 48 4F 53 54 01 00 00 00 00 00 00   GHOST...........
0x000C  40 00 00 00 00 00 00 00                @.......
0x0014  (64 bytes fingerprint)
        ...
0x0054  (Payload starts here)
        ...
(Later)
        7B 22 6D 65 74 61 64 61 74 61 22 ...   {"metadata":...
```

---

## 🎯 Manifest JSON Schema

```json
{
  "metadata": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "llama-2-7b",
    "version": "1.0.0",
    "created_at": "2025-10-31T10:30:00Z",
    "source_format": "gguf",
    "description": "Llama 2 7B model from Meta"
  },
  
  "model_info": {
    "architecture": "llama",
    "parameters": 7000000000,
    "quantization": "fp16",
    "context_length": 4096,
    "layer_count": 32,
    "hidden_size": 4096
  },
  
  "security": {
    "signature": "base64-encoded-ed25519-signature",
    "signer_id": "meta-official",
    "created_hash": "sha3-512-hex",
    "payload_hash": "sha3-512-hex",
    "layer_hashes": [
      "sha3-512-layer-0",
      "sha3-512-layer-1"
    ]
  },
  
  "runtime_profile": {
    "engine": "ggml",
    "device_preference": "auto",
    "memory_estimate_mb": 14000,
    "constraints": [
      {"constraint_type": "min_ram_gb", "value": "14"},
      {"constraint_type": "gpu_vram_gb", "value": "6"}
    ]
  },
  
  "policies": {
    "license": "meta-llama2",
    "usage_restrictions": [
      "non-commercial",
      "research-only"
    ],
    "model_card_url": "https://huggingface.co/meta-llama/Llama-2-7b",
    "requires_attribution": true
  },
  
  "audit_chain": {
    "events": [
      {
        "timestamp": "2025-10-31T10:30:00Z",
        "event_type": "created",
        "actor": "meta-llama",
        "details": {"source_url": "huggingface.co"}
      },
      {
        "timestamp": "2025-10-31T11:00:00Z",
        "event_type": "converted",
        "actor": "converter-service",
        "details": {"from_format": "original", "to_format": "ghost"}
      }
    ]
  }
}
```

---

## 🔐 Security Workflow

### 1️⃣ Creating a Capsule

```
Input File (GGUF/ONNX/etc)
    ↓
Extract Metadata
    ↓
Compute Payload Hash (SHA3-512)
    ↓
Create Manifest
    ↓
Sign Manifest (Ed25519)
    ↓
Create Header with Fingerprint
    ↓
Assemble: Header + Payload + Manifest
    ↓
Output: .ghost file
```

### 2️⃣ Verifying a Capsule

```
Load .ghost file
    ↓
Parse Header
    ↓
Extract Manifest (JSON from end)
    ↓
Verify Header Magic & Version
    ↓
Verify Payload Hash
    ↓
Verify Signature against Manifest
    ↓
Check Layer Hashes
    ↓
Log Audit Chain
    ↓
✅ Valid or ❌ Invalid
```

---

## 🏃 Quick Commands

### Creating a .ghost Capsule

```rust
// 1. Load model metadata
let manifest = GhostManifest {
    metadata: ManifestMetadata {
        id: Uuid::new_v4().to_string(),
        name: "llama2-7b".to_string(),
        version: "1.0.0".to_string(),
        created_at: Utc::now().to_rfc3339(),
        source_format: SourceFormat::GGUF,
        description: "Meta Llama 2 7B".to_string(),
    },
    // ... other fields
};

// 2. Build capsule
let mut builder = CapsuleBuilder::new(manifest, CompressionType::Zstd);
builder.add_payload(model_bytes)?;
let capsule = builder.build()?;

// 3. Write to disk
std::fs::write("llama2-7b.ghost", capsule)?;
```

### Loading a .ghost Capsule

```rust
// 1. Read file
let capsule_data = std::fs::read("llama2-7b.ghost")?;

// 2. Parse header
let header = parse_header(&capsule_data[0..48])?;

// 3. Verify signature
verify_signature(&capsule_data, &header)?;

// 4. Extract manifest
let manifest_json = extract_manifest(&capsule_data)?;
let manifest = GhostManifest::from_json(&manifest_json)?;

// 5. Decompress payload if needed
let payload = if header.compression == CompressionType::Zstd {
    zstd::decode_all(&capsule_data[48..])?
} else {
    capsule_data[48..].to_vec()
};

// 6. Ready to use
Ok((manifest, payload))
```

---

## 📊 Format Variants

### Compression Types

| Type | Value | Use Case | Ratio |
|------|-------|----------|-------|
| None | 0 | Testing, Already compressed | 100% |
| Zstd | 1 | Fast, Good compression | 30-40% |
| Brotli | 2 | Smaller, Slower | 20-30% |

### Engine Types

| Engine | Format | Use Case |
|--------|--------|----------|
| GGML | GGUF | CPU-optimized, Quantized |
| ONNX | ONNX | Cross-platform inference |
| PyTorch | Transformers | Training, Fine-tuning |
| Triton | Multi-format | Enterprise inference |

### Quantization Levels

| Level | Size | Speed | Quality |
|-------|------|-------|---------|
| FP32 | 100% | Baseline | Maximum |
| FP16 | 50% | +20% | 99% |
| INT8 | 25% | +40% | 95% |
| INT4 | 12.5% | +80% | 85% |

---

## 🐛 Debugging Checklist

**Capsule wird nicht geladen?**
```
□ Magic "GHOST" korrekt?
□ Version number supported?
□ Manifest offset gültig?
□ Fingerprint verifiziert?
□ Signature gültig?
□ Payload dekomprimiert?
```

**Hash-Mismatches?**
```
□ Payload unverändert?
□ Manifest nicht modifiziert?
□ SHA3-512 Implementierung korrekt?
□ Layer-Hashes aktuell?
```

**Signature-Fehler?**
```
□ Signer-Key verfügbar?
□ Ed25519 Implementierung aktuell?
□ Manifest JSON kanonisch?
```

---

## 🔗 Abhängigkeiten

**Rust Crates:**
```toml
sha3 = "0.10"           # SHA3-512 hashing
ed25519 = "2.0"         # Ed25519 signing
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"      # JSON serialization
zstd = "0.13"           # Compression
uuid = { version = "1.0", features = ["v4", "serde"] }
chrono = { version = "0.4", features = ["serde"] }
```

---

## 📝 Examples

### Example 1: Minimal .ghost File

```json
{
  "metadata": {
    "id": "test-001",
    "name": "minimal-test",
    "version": "0.1.0",
    "created_at": "2025-10-31T00:00:00Z",
    "source_format": "custom",
    "description": "Test capsule"
  },
  "model_info": {
    "architecture": "test",
    "parameters": 1000,
    "quantization": "fp32",
    "context_length": 512,
    "layer_count": 1,
    "hidden_size": 64
  },
  "security": {
    "signature": "",
    "signer_id": "test",
    "created_hash": "",
    "payload_hash": "",
    "layer_hashes": []
  },
  "runtime_profile": {
    "engine": "ggml",
    "device_preference": "cpu",
    "memory_estimate_mb": 10,
    "constraints": []
  },
  "policies": {
    "license": "test",
    "usage_restrictions": [],
    "model_card_url": "",
    "requires_attribution": false
  },
  "audit_chain": {
    "events": []
  }
}
```

### Example 2: Production .ghost File

Siehe `GHOST_FORMAT_IMPLEMENTATION.md` für vollständiges Beispiel mit:
- Ed25519 Signatur
- Layer-Hashes
- Audit-Chain
- Runtime-Constraints

---

## 🎯 Checkliste für Format-Integration

- [ ] Header Parsing implementiert
- [ ] Manifest JSON Schema validiert
- [ ] SHA3-512 Hashing korrekt
- [ ] Ed25519 Signing funktioniert
- [ ] Kompression (Zstd/Brotli)
- [ ] Capsule Builder vollständig
- [ ] CLI Tools (pack, validate, inspect)
- [ ] Database Integration
- [ ] API Endpoints (upload, download, validate)
- [ ] E2E Tests
- [ ] Performance Tests
- [ ] Security Audit

---

**Referenzen:**
- `docs/GHOST_FORMAT_IMPLEMENTATION.md` — Detaillierte Implementation
- `ghost-prompt.md` — Original-Spezifikation
- `docs/PHASE2_ROADMAP.md` — Phase 2-4 Planning

**Status:** 📋 Format Specification Complete  
**Next:** Phase 2.1 gRPC Client Implementation
