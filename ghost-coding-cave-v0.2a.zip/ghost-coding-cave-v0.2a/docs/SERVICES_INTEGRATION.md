# 🏗️ Services Integration Map — Ghost Coding Cave v0.2a

**Complete Service Architecture & Integration Points**

---

## 📊 Service Inventory

### TypeScript Services (Monorepo)
```
apps/
├── api/                    NestJS Backend (Port 3000)
│   └── Auth, WebSocket, Database Layer
└── dashboard/              Next.js Frontend (Port 4004)
    └── Monaco Editor, Real-time Chat, Management UI

packages/
├── database/              Prisma ORM + Schema
└── types/                Shared TypeScript Types
```

### Rust Services (Microservices)

#### Main Rust-Core Crates
```
rust-core/crates/
├── ai-server/             AI Inference Server (Port 5001)
│   └── Model Registry, Chat, TTS, Analysis
├── gateway/               HTTP Gateway (Port 8080)
│   └── API Key Auth, Request Proxy, Response Transform
├── helper-core/           Analysis & Planning Engine
│   └── Code Analysis, Symbol Detection, Request Planning
├── semantic-adapter/      Semantic Search Integration
│   └── Reference Finding, Code Understanding
└── storage-adapter/       Vector Storage & Embeddings
    └── File Persistence, Embeddings, Similarity
```

#### Services Workspace
```
services/
├── semantic-store/        Vector DB & Model Registry (Ports 8443/9443)
│   ├── ss-api/            HTTP API
│   ├── ss-cli/            Command-line Tools
│   ├── ss-core/           Storage Engine
│   ├── ss-gf/             .ghost Format
│   ├── ss-gp/             .ghost Packer
│   ├── ss-index/          Indexing Engine
│   ├── ss-metrics/        Metrics Collection
│   ├── ss-pgml/           ML Pipeline
│   ├── ss-plugins/        Plugin System
│   └── ss-query/          Query Engine
│
├── ghost-server/          Main Server (Legacy)
│   └── cave execution, management
│
├── ghost-portal/          Admin Web UI 🆕
│   └── Admin Console, Session Mgmt, Project Tracking
│
└── mcp-ollama/           MCP Ollama Bridge
    └── Language Model Integration
```

---

## 🔄 Integration Points (Phase 2+)

### Phase 2: Registry-Anbindung

**gRPC Bridge (Task 2.1)**
```
AI-Server
    ↓
SemanticStoreRegistry (gRPC Client)
    ↓
Semantic-Store (ss-api gRPC Server)
    ↓
Model Loading & Management
```

**Helper-Core Binding (Task 2.2)**
```
Helper-Core Analysis
    ↓
SemanticStoreRegistry (Model Selection)
    ↓
AI-Server (Inference)
    ↓
Response Generation
```

**E2E Pipeline (Task 2.3)**
```
Dashboard/API
    ↓
Chat Request
    ↓
Helper-Core Analysis
    ↓
Model Selection from Registry
    ↓
AI-Server Inference
    ↓
Response Streaming
    ↓
Dashboard/Client
```

### Phase 3: .ghost Format

**Format Integration**
```
Semantic-Store ss-api
    ↓
GGUF/ONNX/Transformers Input
    ↓
Format Converters (ss-gf)
    ↓
.ghost Capsules
    ↓
Persistent Storage (ss-core)
    ↓
AI-Server Loading
```

### Phase 4: Admin Dashboard & Portal

**ghost-portal Integration (NEW)**
```
Next.js Dashboard (4004)
    ↓
NestJS API (3000)
    ↓
ghost-portal Admin UI
    ↓
Session Management (SQLite)
    ↓
Project Tracking
    ↓
API Key Management
    ↓
MCP Tool Registration
```

---

## 📋 Port Allocation

| Service | Port | Protocol | Status |
|---------|------|----------|--------|
| **Dashboard** | 4004 | HTTP | ⏳ Pending |
| **NestJS API** | 3000 | HTTP | ⏳ Pending |
| **AI-Server** | 5001 | HTTP | ✅ Running |
| **Gateway** | 8080 | HTTP | ⏳ Pending |
| **Semantic-Store** | 8443 | HTTP | ✅ Ready |
| **Semantic-Store** | 9443 | gRPC | ✅ Ready |
| **PostgreSQL** | 5432 | TCP | ✅ Ready |
| **Redis** | 6379 | TCP | ⏳ Optional |

---

## 🔐 Authentication Flow

### Current (Phase 1)
```
AI-Server
    ↓
Registry (Local Stub)
    ↓
Models (In-Memory)
```

### Phase 2: gRPC Auth
```
AI-Server
    ↓
SemanticStoreRegistry (Token Auth)
    ↓
Semantic-Store (Validates Token)
    ↓
Model Access
```

### Phase 2+: Full Auth Stack
```
Dashboard Login
    ↓
NestJS Auth (JWT)
    ↓
API Key Management
    ↓
Gateway (API Key Validation)
    ↓
Rust Services (Authorized Access)
```

### Phase 4: Admin Console
```
ghost-portal Login
    ↓
Session Management (SQLite)
    ↓
Admin Operations
    ↓
Project/Key/Tool Management
```

---

## 🚀 Service Dependencies

### Startup Order (Phase 2+)

```
1. PostgreSQL (Database)
   ↓
2. Semantic-Store (Model Registry)
   ↓
3. AI-Server (Inference Engine)
   ↓
4. NestJS API (Backend)
   ↓
5. Dashboard (Frontend)
   ↓
6. ghost-portal (Admin UI) [Optional]
```

### Health Check Dependencies
```
Dashboard
    ├→ API Health (Port 3000)
    │
API
    ├→ PostgreSQL Health
    ├→ SemanticStore Health (Port 8443)
    └→ AI-Server Health (Port 5001)
```

---

## 🔌 API Gateway Pattern

**Phase 2 Architecture:**
```
┌─────────────┐
│  Dashboard  │ (4004)
└──────┬──────┘
       │ HTTP
       ↓
┌─────────────┐
│  NestJS API │ (3000)
└──────┬──────┘
       │
       ├─→ Gateway (8080)
       │       ↓
       │    AI-Server (5001)
       │
       ├─→ Semantic-Store (8443)
       │    (gRPC: 9443)
       │
       └─→ PostgreSQL (5432)
```

**Future (Phase 3+):**
```
Add ghost-portal (Admin)
    ↓
Parallel Admin API Endpoints
    ↓
Separate Auth/RBAC
```

---

## 📦 Data Flow Examples

### Example 1: Chat Request (Phase 2)

```
1. User types in Dashboard
   └─ POST /api/chat {message}

2. NestJS API receives
   └─ Validates JWT token
   └─ Forwards to AI-Server

3. AI-Server processes
   └─ Consults SemanticStore for models
   └─ Loads best model via gRPC
   └─ Runs inference

4. Response flows back
   └─ AI-Server → API → Dashboard
   └─ Real-time WebSocket updates

5. Result displayed
   └─ Chat message appears
```

### Example 2: Model Management (Phase 3)

```
1. Admin uploads GGUF file
   └─ Dashboard → API → Semantic-Store

2. Format conversion
   └─ GGUF → .ghost (via ss-gf)

3. Storage & registration
   └─ Stored in ss-core
   └─ Indexed in ss-index

4. Registration in AI-Server
   └─ AI-Server queries SemanticStore
   └─ Model now available

5. Usage in chat
   └─ Follows Example 1
```

### Example 3: Admin Operations (Phase 4)

```
1. Operator visits ghost-portal
   └─ http://localhost:3000/admin

2. Authenticates
   └─ Username/Password → SQLite
   └─ Session cookie issued

3. Manages resources
   └─ Create projects
   └─ Generate API keys
   └─ Register MCP tools

4. Session tracked
   └─ SQLite records all operations
   └─ 12-hour expiry by default
```

---

## 🛠️ Development Workflow

### Local Development (npm run dev)

**Terminal 1: TypeScript Services**
```bash
npm run dev
# Starts Dashboard (4004) + API (3000)
```

**Terminal 2: AI-Server**
```bash
cd rust-core
HELPER_DB_PATH=./data/helper.db cargo run --bin ai-server
# Starts AI-Server (5001)
```

**Terminal 3: Semantic-Store**
```bash
cd services/semantic-store
cargo run --bin ss-api
# Starts Semantic-Store (8443, 9443)
```

**Terminal 4: Admin Portal (Phase 4)**
```bash
# When ready, start ghost-portal
cd services/ghost-portal
cargo run --bin portal
# Starts Admin UI
```

---

## 🔄 Service Communication Patterns

### Pattern 1: REST → gRPC
```
NestJS API (REST)
    ↓
Helper-Core (Internal)
    ↓
SemanticStoreRegistry (gRPC Client)
    ↓
Semantic-Store (gRPC Server)
    ↓
Response back through stack
```

### Pattern 2: WebSocket → HTTP
```
Dashboard (WebSocket)
    ↓
NestJS API (Socket.IO)
    ↓
Real-time Chat Updates
    ↓
Broadcast to connected clients
```

### Pattern 3: HTTP → Internal Queue
```
NestJS API (Request)
    ↓
Task Queue (Redis/In-Memory)
    ↓
Background Worker (async)
    ↓
Webhook/Database Update
```

---

## 📊 Scalability Plan

### Phase 2: Single Node
- All services on same machine
- PostgreSQL local or Docker
- Semantic-Store embedded

### Phase 3: Load Balancing
- Multiple API instances (behind nginx)
- Shared PostgreSQL
- Distributed Semantic-Store (cluster)

### Phase 4: Distributed
- API pods (Kubernetes)
- AI-Server instances (load balanced)
- Semantic-Store cluster
- Admin Portal (separate namespace)

---

## 🐛 Debugging Service Issues

### AI-Server won't connect to Semantic-Store?
```bash
# Check gRPC endpoint
echo $SEMANTIC_STORE_GRPC_URL

# Test connectivity
grpcurl -plaintext localhost:9443 list
```

### NestJS API not reaching PostgreSQL?
```bash
# Verify DATABASE_URL
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL -c "SELECT 1"
```

### Dashboard shows "API unreachable"?
```bash
# Check API health
curl http://localhost:3000/health

# Check CORS headers
curl -v http://localhost:3000/health
```

### Semantic-Store returning 503?
```bash
# Check health endpoint
curl http://localhost:8443/health

# Check available models
curl http://localhost:8443/api/v1/capsules
```

---

## 📚 Documentation by Service

| Service | Phase | Docs |
|---------|-------|------|
| **AI-Server** | 1-2 | `docs/API_REFERENCE.md` |
| **Semantic-Store** | 1-3 | `docs/STORAGE_ENGINE.md`, `docs/GHOST_FORMAT_*` |
| **NestJS API** | 2-3 | `docs/API_REFERENCE.md` |
| **Dashboard** | 2-4 | `docs/UX.md` |
| **ghost-portal** | 4 | `services/ghost-portal/README.md` |

---

## ✅ Integration Checklist

### Phase 1 (Current)
- [x] AI-Server standalone
- [x] Semantic-Store standalone
- [x] PostgreSQL ready
- [ ] NestJS API integration
- [ ] Dashboard integration

### Phase 2 (Next)
- [ ] gRPC client (AI-Server → Semantic-Store)
- [ ] Helper-Core binding
- [ ] E2E chat pipeline
- [ ] Docker Compose

### Phase 3
- [ ] .ghost format
- [ ] Model converters
- [ ] Admin upload flows
- [ ] API integration

### Phase 4
- [ ] ghost-portal setup
- [ ] Admin UI flows
- [ ] Session management
- [ ] Project tracking

---

**Last Updated:** 31. Oktober 2025  
**Status:** Phase 1 Complete, Phase 2 Ready  
**Next:** Start Phase 2.1 gRPC Integration
