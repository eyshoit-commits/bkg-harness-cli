# Phase 2: Registry-Anbindung & AI-Server Integration

**Stand:** 31. Oktober 2025  
**Status:** 🔄 In Bearbeitung  
**Dauer (Schätzung):** 3-5 Tage

---

## 🎯 Phase 2 Ziele

1. ✅ **AI-Server mit Semantic-Store verbinden**
2. ✅ **Model Registry implementieren**
3. ✅ **Helper-Core Integration**
4. ✅ **E2E Model Loading Pipeline**

---

## 📋 Detaillierte Aufgaben

### Task 2.1: gRPC Client für Semantic-Store

**Datei:** `rust-core/crates/ai-server/src/registry/semantic_store.rs`

**Was:**
- gRPC-Client zu Semantic-Store API
- Model-Listing und -Loading
- Error-Handling mit Fallbacks

**Pseudocode:**
```rust
pub struct SemanticStoreRegistry {
    client: SemanticStoreClient,
}

impl SemanticStoreRegistry {
    pub async fn list_models(&self) -> Result<Vec<ModelInfo>> {
        self.client.list_capsules(ScanPrefixRequest {
            prefix: "capsule::".to_string(),
        }).await
    }
    
    pub async fn load_model(&self, name: &str) -> Result<Model> {
        let capsule = self.client.get_capsule(name).await?;
        Model::from_capsule(capsule)
    }
}
```

**Abhängigkeiten:**
- `tonic` (gRPC)
- `prost` (Protocol Buffers)
- Semantic-Store Proto Definitions

**Testfälle:**
- [ ] Connect to Semantic-Store
- [ ] List Models erfolgreiche
- [ ] Load Model erfolgreich
- [ ] Error Handling (Timeout, Not Found)

---

### Task 2.2: Helper-Core Integration

**Dateien:**
- `rust-core/crates/helper-core/src/analysis/mod.rs`
- `rust-core/crates/helper-core/src/registry_adapter.rs`

**Was:**
- Analysis Module mit Model-Metadaten
- Planner mit verfügbaren Modellen
- Agents mit Model-Selection Logic

**Struktur:**
```rust
pub struct AnalysisContext {
    registry: Arc<SemanticStoreRegistry>,
    models: Vec<ModelInfo>,
}

impl AnalysisContext {
    pub async fn analyze_request(&self, request: &str) -> Result<Analysis> {
        // 1. Semantische Analyse des Request
        // 2. Matching mit verfügbaren Modellen
        // 3. Selection Logic
        // 4. Return Best Model
    }
}
```

**Integrationspunkte:**
- [ ] Registry-Loading beim Startup
- [ ] Cache-Strategie für Models
- [ ] Update-Mechanismus bei neuen Models
- [ ] Fallback bei Model-Unavailability

---

### Task 2.3: Model Loading Pipeline

**End-to-End Flow:**

```
1. AI-Server Start
   └─ Initialize SemanticStoreRegistry
      └─ Fetch Models from semantic-store

2. Chat Request kommt rein
   └─ Helper-Core Analysis
      └─ Select Best Model
         └─ Load Model (Cache oder Disk)
            └─ Run Inference

3. Response zurück an Client
   └─ Cache Model für nächsten Request
```

**Implementierung:**

```rust
pub struct AiServer {
    registry: Arc<SemanticStoreRegistry>,
    model_cache: Arc<ModelCache>,
    helper: Arc<HelperCore>,
}

impl AiServer {
    pub async fn chat(&self, request: ChatRequest) -> Result<ChatResponse> {
        // 1. Analyze request
        let analysis = self.helper.analyze(&request.message).await?;
        
        // 2. Get best model
        let model_info = self.registry
            .find_best_model(&analysis.requirements)
            .await?;
        
        // 3. Load model (from cache or disk)
        let model = self.model_cache
            .get_or_load(&model_info.id)
            .await?;
        
        // 4. Run inference
        let response = model.infer(&request.message).await?;
        
        Ok(ChatResponse { text: response })
    }
}
```

**Tests:**
- [ ] Model Selection Logic
- [ ] Cache Hit/Miss Behavior
- [ ] Inference Pipeline
- [ ] Error Recovery

---

### Task 2.4: Docker & DevOps

**Datei:** `docker-compose.yml`

**Neue Services:**
```yaml
services:
  semantic-store:
    image: ss-api:latest
    ports:
      - "8443:8443"  # HTTP API
      - "9443:9443"  # gRPC
    volumes:
      - ./data/semantic-store:/data
    environment:
      - STORAGE_PATH=/data
      - LOG_LEVEL=info
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8443/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  ai-server:
    depends_on:
      - semantic-store
    environment:
      - SEMANTIC_STORE_URL=grpc://semantic-store:9443
      - HELPER_DB_PATH=/data/helper.db
    volumes:
      - ./data/ai-server:/data
```

**Tasks:**
- [ ] Docker Image für ss-api bauen
- [ ] Docker Image für ai-server bauen
- [ ] Docker Compose Orchester konfigurieren
- [ ] Health Checks implementieren
- [ ] Startup-Order sicherstellen

---

### Task 2.5: Testing & Documentation

**Unit Tests:**
- [ ] SemanticStoreRegistry Tests
- [ ] Model Loading Tests
- [ ] Cache Behavior Tests
- [ ] Error Handling Tests

**Integration Tests:**
- [ ] Full Chat Pipeline
- [ ] Model Selection Logic
- [ ] Cache Eviction
- [ ] Multi-Model Handling

**Documentation:**
- [ ] API Reference Update
- [ ] Integration Guide
- [ ] Troubleshooting Guide
- [ ] Performance Tuning Guide

---

## 🏃 Execution Plan

### Sprint 1 (Tag 1-2)
- [ ] Task 2.1: gRPC Client implementieren
- [ ] Unit Tests für Registry
- [ ] Integration mit AI-Server

### Sprint 2 (Tag 2-3)
- [ ] Task 2.2: Helper-Core Integration
- [ ] Analysis Module erweitern
- [ ] Model Selection Logic testen

### Sprint 3 (Tag 3-4)
- [ ] Task 2.3: Model Loading Pipeline
- [ ] E2E Tests schreiben
- [ ] Performance Testing

### Sprint 4 (Tag 4-5)
- [ ] Task 2.4: Docker & DevOps
- [ ] Docker Compose Setup
- [ ] Production Readiness

---

## 📊 Success Criteria

| Kriterium | Beschreibung | Status |
|-----------|-------------|--------|
| **Model Registry** | Semantic-Store als Model-Quelle | ⏳ |
| **AI-Server Integration** | gRPC Client funktioniert | ⏳ |
| **Helper-Core Binding** | Analysis mit Models | ⏳ |
| **E2E Pipeline** | Chat → Model Selection → Inference | ⏳ |
| **Docker Ready** | Full Stack in Docker Compose | ⏳ |
| **Tests** | >80% Code Coverage | ⏳ |
| **Documentation** | Vollständig & aktuell | ⏳ |

---

## 🚀 Blockers & Dependencies

### Abhängigkeiten auf Phase 1
- ✅ StorageEngine funktioniert
- ✅ Capsule-Endpoints verfügbar
- ✅ AI-Server läuft

### Externe Abhängigkeiten
- PostgreSQL (für NestJS API)
- Redis (optional, für Cache)
- Docker (für Containerisierung)

### Mögliche Blockers
- ⚠️ gRPC Proto-Definition fehlt (müssen erstellt werden)
- ⚠️ Model Format (GGUF vs Ghost Format Entscheidung)
- ⚠️ Tokenizer-Handling (noch nicht definiert)

---

## 📞 References

**Phase 1 Dokumentation:**
- `docs/PROGRESS.md` — Phase 1 Summary
- `docs/STORAGE_ENGINE.md` — StorageEngine Details
- `docs/ARCHITECTURE.md` — System Architecture

**Code:**
- `services/semantic-store/` — Semantic-Store Implementation
- `rust-core/crates/ai-server/` — AI-Server Source
- `services/semantic-store/ss-api/src/http.rs` — API Endpoints

---

**Erstellt:** 31. Oktober 2025  
**Status:** Aktuell & Ready for Implementation  
**Next Review:** Nach Task 2.1 Abschluss
