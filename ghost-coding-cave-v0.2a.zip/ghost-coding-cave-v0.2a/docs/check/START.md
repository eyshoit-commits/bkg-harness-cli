# START — ghost-coding-cave-v0.2a

> Letzter Check: CHECK_2026-09-17_171722.md
> Stand: 2026-09-17

## Projekt
**Name:** Ghost Coding Cave v0.2a — Cloud IDE Platform  
**Zweck:** Vollständige Cloud-IDE mit Code-Execution (Sandbox), AI-Assistenz (Chat/TTS/Image), Semantic Analysis, Storage und Next.js Dashboard.  
**Domain:** Rust (Axum Gateway, AI-Server, Semantic Store), TypeScript/NestJS (API), Next.js 14 (Dashboard), Docker Compose

## Scope
- `rust-core/` — Rust Workspace (11 Crates): gateway, ai-server, semantic-store, storage-adapter, semantic-adapter, helper-core
- `apps/api/` — NestJS Backend (Auth, Caves, Models, Tokens, WebSocket)
- `apps/dashboard/` — Next.js 14 Dashboard (IDE-Interface)
- `docker-compose.yml` — Service-Orchestrierung

## Aktueller Milestone
**M1 — Runtime-Verifikation: Rust Gateway E2E** (parallel mit M2)

## Milestone-Status
READY

## Aktueller Blocker
Kein Code-Blocker. Rust Build kompiliert sauber.  
Dashboard und Rust Gateway in `docker-compose.yml` **auskommentiert** — muss aktiviert werden.  
Tests BLOCKED wegen Disk Full (`/tmp` war 100% voll — Infrastruktur).

## Aktuelle Tasks
→ siehe NEXT_TASKS.md

## Out-of-Scope
- NestJS API ↔ Rust Gateway langfristiger Merge (kein Scope bestätigt)
- Ghost Format (ss-gf/ss-gp) CLI-Integration (kein Scope bestätigt)
- ollama/llm/mirror Docker-Profile (optional, on-demand)

## Definition of Done (M1)
- `cargo build -p ghost-gateway` ohne Fehler
- `cargo run -p ghost-gateway` startet ohne Panic
- `curl http://localhost:8080/health` → HTTP 200, Body `{"service":"ghost-gateway","status":"ok",...}` (Response-Inhalt verifiziert)
- `POST /api/storage/embeddings/index` → HTTP 200 (Storage functional)

## Verweise
- Milestones:    docs/check/MILESTONES.md
- Next Tasks:    docs/check/NEXT_TASKS.md
- Tasks:         docs/TASKS.md
- Letzter Check: docs/check/CHECK_2026-09-17_171722.md
