# MILESTONES — Stand: 2026-09-17_171722

Letzter Check: CHECK_2026-09-17_171722.md

| Milestone | Name | Status | Abhängigkeit | Nachweis |
|---|---|---|---|---|
| M1 | Runtime-Verifikation: Rust Gateway E2E | READY | — | — |
| M2 | Docker Dashboard aktivieren | READY | — | — |
| M3 | Rust Gateway im Docker aktivieren | BLOCKED | M1 | — |
| M4 | Tests: Disk-Space-Blocker auflösen | BLOCKED | Infra | — |

## Nächster ausführbarer Milestone
**M1 und M2 parallel ausführbar** (unabhängig voneinander)

- M1: `cargo run -p ghost-gateway` → `curl localhost:8080/health`
- M2: docker-compose.yml Zeilen 109–126 entkommentieren → Dashboard auf :4007

## Blocker
- M3: M1 (Runtime-Nachweis) muss zuerst
- M4: `/tmp` / `/` war 100% voll — Infrastrukturproblem
