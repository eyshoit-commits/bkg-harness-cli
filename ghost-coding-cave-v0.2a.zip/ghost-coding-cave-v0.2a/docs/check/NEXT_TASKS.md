# NEXT_TASKS — Stand: 2026-09-17_171722

Aktueller Milestone: **M1 — Runtime-Verifikation: Rust Gateway E2E**
Status: READY

## Tasks

- [ ] Task 1: Gateway bauen
  ```bash
  cd rust-core && cargo build -p ghost-gateway
  ```

- [ ] Task 2: Gateway starten
  ```bash
  GHOST_GATEWAY_PORT=8080 cargo run -p ghost-gateway
  ```

- [ ] Task 3: Health-Endpoint verifizieren
  ```bash
  curl http://localhost:8080/health
  # Erwartetes Ergebnis: {"service":"ghost-gateway","version":"0.1.0","status":"ok"}
  ```

- [ ] Task 4 (parallel): Dashboard in docker-compose aktivieren
  - `docker-compose.yml` Zeilen 109–126: Kommentarzeichen entfernen
  - `docker compose up dashboard`
  - Browser: http://localhost:4007 → Dashboard rendert

## Nicht in diesem Milestone
- M3 — Rust Gateway im Docker (BLOCKED by M1)
- M4 — Tests: Disk-Space (BLOCKED — Infra)

## Definition of Done für M1
- [ ] `cargo build -p ghost-gateway` erfolgreich (0 errors)
- [ ] `cargo run -p ghost-gateway` startet ohne Panic
- [ ] `curl http://localhost:8080/health` → HTTP 200 mit Body `{"service":"ghost-gateway","status":"ok",...}` (Response-Inhalt verifiziert, nicht nur Status 200)
- [ ] `curl -X POST http://localhost:8080/api/storage/embeddings/index -H "Content-Type: application/json" -d '{"vector":[0.1,0.2,0.3]}' ` → HTTP 200 (Storage-Route functional)
