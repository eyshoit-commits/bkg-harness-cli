import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';

const DISABLED = true; // Database disabled - Semantic Store is the only data layer

@Injectable()
export class DatabaseService implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    console.log('⚠️  Database disabled – Semantic Store is the only data layer');
  }

  async onModuleDestroy() {
    // No cleanup needed
  }

  get client() {
    throw new Error('Database is permanently disabled. Use SemanticStoreService instead.');
  }
}

