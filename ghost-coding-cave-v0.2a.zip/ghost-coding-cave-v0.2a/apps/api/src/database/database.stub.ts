/**
 * Stub Database Service
 * 
 * All database operations have been removed.
 * The API is now a stateless HTTP gateway to the Semantic Store.
 * 
 * For Cave, Version, Token, Auth operations:
 * - Implement via Semantic Store HTTP client (see semantic-store.service.ts)
 * - Or migrate to in-memory mock for backward compatibility testing
 */

export class DatabaseService {
  constructor() {
    console.log('⚠️  DatabaseService disabled – API is stateless HTTP gateway to Semantic Store');
  }

  async onModuleInit() {
    console.log('✓ API running without local database (Semantic Store only)');
  }

  async onModuleDestroy() {
    // No cleanup needed
  }

  get client() {
    throw new Error('Database client unavailable. Use SemanticStoreService or implement mock.');
  }
}

/**
 * Mock implementations for testing (optional)
 */
export const mockCaveService = {
  create: async () => ({ id: 'mock-cave-1', name: 'Mock Cave' }),
  list: async () => [],
  delete: async () => true,
};

export const mockVersionService = {
  create: async () => ({ id: 'mock-version-1' }),
  list: async () => [],
};

export const mockTokenService = {
  create: async () => ({ id: 'mock-token-1' }),
  list: async () => [],
};
