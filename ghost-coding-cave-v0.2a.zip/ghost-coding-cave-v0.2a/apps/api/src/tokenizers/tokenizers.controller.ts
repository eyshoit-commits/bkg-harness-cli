import { Controller, Get, Post, Body } from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { SemanticStoreService } from '../semantic-store/semantic-store.service';
import { StoreTokenizerDto, UpsertTokenizerDto } from '../dto/tokenizers.dto';

@ApiTags('Tokenizers')
@Controller('tokenizers')
export class TokenizersController {
  constructor(private readonly store: SemanticStoreService) {}

  @Get()
  @ApiOkResponse({ type: StoreTokenizerDto, isArray: true })
  list() {
    return this.store.listTokenizers();
  }

  @Post()
  @ApiOkResponse({ type: StoreTokenizerDto })
  upsert(@Body() body: UpsertTokenizerDto) {
    return this.store.upsertTokenizer(body);
  }
}
