import { Module } from '@nestjs/common';
import { TokenizersController } from './tokenizers.controller';
import { SemanticStoreModule } from '../semantic-store/semantic-store.module';

@Module({
  imports: [SemanticStoreModule],
  controllers: [TokenizersController],
})
export class TokenizersModule {}
