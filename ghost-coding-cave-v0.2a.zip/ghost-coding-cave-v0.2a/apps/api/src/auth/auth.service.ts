import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DatabaseService } from '../database/database.service';
import { nanoid } from 'nanoid';

/**
 * AuthService – v0.3a Stub (Stateless Gateway)
 * 
 * All auth operations moved to Semantic Store (ss-api @ :4011).
 * This stub returns mock responses for API compatibility.
 */
@Injectable()
export class AuthService {
  constructor(
    private readonly db: DatabaseService,
    private readonly jwtService: JwtService,
  ) {}

  async registerEmailOnly(email: string) {
    // v0.3a: Auth operations moved to Semantic Store
    const apiKeyRaw = `ghost_${nanoid(32)}`;
    return {
      email,
      apiKey: apiKeyRaw,
      userId: nanoid(16),
    };
  }

  async setupPassword(apiKey: string, password: string) {
    // v0.3a: Auth operations moved to Semantic Store
    return {
      message: 'Password set successfully. You can now login.',
      email: 'user@example.com',
    };
  }

  async login(email: string, password: string) {
    // v0.3a: Auth operations moved to Semantic Store
    const payload = {
      sub: nanoid(16),
      email,
      role: 'USER',
      apiKeyId: nanoid(16),
    };

    return {
      access_token: this.jwtService.sign(payload),
      user: {
        id: payload.sub,
        email,
        role: 'USER',
        tokenBalance: 1000,
      },
    };
  }

  async validateApiKey(apiKey: string) {
    // v0.3a: Auth operations moved to Semantic Store
    return {
      user: { id: nanoid(16), email: 'user@example.com', role: 'USER' },
      apiKey: { id: nanoid(16), isActive: true },
    };
  }
}
