import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';

/**
 * JwtStrategy – v0.3a Stub (Prisma removed, API is stateless)
 * 
 * Real implementation would validate against user registry in Semantic Store
 * for now: accepting JWT and returning mock user object to unblock docker build
 */
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly config: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        (request: Request) => request?.cookies?.ghost_token || null,
        ExtractJwt.fromAuthHeaderAsBearerToken(),
      ]),
      secretOrKey: config.get('JWT_SECRET'),
    });
  }

  async validate(payload: any) {
    // TODO: validate payload against Semantic Store /v1/users/{userId}
    // For now: accept any valid JWT
    if (!payload || !payload.sub) {
      throw new UnauthorizedException();
    }

    return {
      userId: payload.sub,
      email: payload.email || `user-${payload.sub}@ghost.local`,
      role: payload.role || 'USER',
      apiKeyId: payload.apiKeyId,
    };
  }
}
