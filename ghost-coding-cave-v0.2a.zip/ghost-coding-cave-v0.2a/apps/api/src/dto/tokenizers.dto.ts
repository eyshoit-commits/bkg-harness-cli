import { ApiProperty } from '@nestjs/swagger';

export class UpsertTokenizerDto {
  @ApiProperty({ example: 'llama3.1-tokenizer' })
  name!: string;

  @ApiProperty({ example: { vocab_size: 128000, type: 'bpe' } })
  spec!: any;
}

export class StoreTokenizerDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  name!: string;

  @ApiProperty({ description: 'Tokenizer specification JSON' })
  spec!: any;
}
