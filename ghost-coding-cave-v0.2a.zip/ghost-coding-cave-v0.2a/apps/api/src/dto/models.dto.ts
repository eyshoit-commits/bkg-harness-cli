import { ApiProperty } from '@nestjs/swagger';

export class CreateModelDto {
  @ApiProperty({ example: 'qwen2.5:1.5b-instruct' })
  name!: string;

  @ApiProperty({ required: false, example: 'OLLAMA' })
  provider?: string;

  @ApiProperty({ required: false, example: 'GGUF' })
  format?: string;
}

export class StoreModelDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  name!: string;

  @ApiProperty({ required: false, nullable: true })
  provider?: string | null;

  @ApiProperty({ required: false, nullable: true })
  format?: string | null;

  @ApiProperty({ example: 'AVAILABLE' })
  status!: string;

  @ApiProperty({ required: false, nullable: true })
  meta?: any;
}
