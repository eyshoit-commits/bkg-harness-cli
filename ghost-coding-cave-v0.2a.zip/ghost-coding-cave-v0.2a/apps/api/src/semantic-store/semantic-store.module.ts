import { Module } from '@nestjs/common';
import { SemanticStoreService } from './semantic-store.service';

@Module({
  providers: [SemanticStoreService],
  exports: [SemanticStoreService],
})
export class SemanticStoreModule {}
