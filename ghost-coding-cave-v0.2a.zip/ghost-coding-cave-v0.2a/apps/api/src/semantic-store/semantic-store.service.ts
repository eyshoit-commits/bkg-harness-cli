import { Injectable } from '@nestjs/common';

export interface StoreModel {
  id: string;
  name: string;
  provider?: string | null;
  format?: string | null;
  status: string;
  meta?: any;
}

export interface StoreTokenizer {
  id: string;
  name: string;
  spec: any;
}

@Injectable()
export class SemanticStoreService {
  private baseUrl: string;

  constructor() {
    this.baseUrl = process.env.SEMANTIC_STORE_HTTP_URL || 'http://semantic-store-api:8443';
  }

  private async http<T>(path: string, init?: RequestInit): Promise<T> {
    const res = await fetch(`${this.baseUrl}${path}`, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`SemanticStore error ${res.status}: ${text}`);
    }
    return (await res.json()) as T;
  }

  // Models
  listModels(): Promise<StoreModel[]> {
    return this.http('/v1/models');
  }

  createModel(input: { name: string; provider?: string; format?: string }): Promise<StoreModel> {
    return this.http('/v1/models', { method: 'POST', body: JSON.stringify(input) });
  }

  // Tokenizers (to be implemented on ss-api soon)
  listTokenizers(): Promise<StoreTokenizer[]> {
    return this.http('/v1/tokenizers');
  }

  upsertTokenizer(input: { name: string; spec: any }): Promise<StoreTokenizer> {
    return this.http('/v1/tokenizers', { method: 'POST', body: JSON.stringify(input) });
  }
}
