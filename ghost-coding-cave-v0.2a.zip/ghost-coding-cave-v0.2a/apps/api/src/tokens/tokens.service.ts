import { Injectable } from '@nestjs/common';

/**
 * TokensService – v0.3a Stub (Prisma removed, API is stateless)
 * 
 * Real implementation would delegate to Semantic Store HTTP API
 * for now: returning mock data to unblock docker build
 */
@Injectable()
export class TokensService {
  async getBalance(userId: string) {
    // TODO: fetch from Semantic Store /v1/api-keys/{userId}
    return {
      balance: 10000,
      limit: 100000,
    };
  }

  async recharge(userId: string, amount: number) {
    // TODO: POST to Semantic Store /v1/api-keys/{userId}/recharge
    return { newBalance: 10000 + amount };
  }
}
