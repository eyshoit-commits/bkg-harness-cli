import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { CavesModule } from './caves/caves.module';
import { TokensModule } from './tokens/tokens.module';
import { VersionsModule } from './versions/versions.module';
import { AdminModule } from './admin/admin.module';
import { WebsocketModule } from './websocket/websocket.module';
import { SemanticStoreModule } from './semantic-store/semantic-store.module';
import { ModelsModule } from './models/models.module';
import { TokenizersModule } from './tokenizers/tokenizers.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.local', '.env'],
    }),
    SemanticStoreModule,
    ModelsModule,
    TokenizersModule,
    AuthModule,
    CavesModule,
    TokensModule,
    VersionsModule,
    AdminModule,
    WebsocketModule,
  ],
})
export class AppModule {}
