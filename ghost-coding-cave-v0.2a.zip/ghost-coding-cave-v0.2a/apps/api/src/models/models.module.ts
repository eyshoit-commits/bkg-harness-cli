import { Module } from '@nestjs/common';
import { ModelsController } from './models.controller';
import { SemanticStoreModule } from '../semantic-store/semantic-store.module';

@Module({
  imports: [SemanticStoreModule],
  controllers: [ModelsController],
})
export class ModelsModule {}
