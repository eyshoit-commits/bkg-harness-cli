import { Controller, Get, Post, Body } from '@nestjs/common';
import { ApiOkResponse, ApiTags } from '@nestjs/swagger';
import { SemanticStoreService } from '../semantic-store/semantic-store.service';
import { CreateModelDto, StoreModelDto } from '../dto/models.dto';

@ApiTags('Models')
@Controller('models')
export class ModelsController {
  constructor(private readonly store: SemanticStoreService) {}

  @Get()
  @ApiOkResponse({ type: StoreModelDto, isArray: true })
  list() {
    return this.store.listModels();
  }

  @Post()
  @ApiOkResponse({ type: StoreModelDto })
  create(@Body() body: CreateModelDto) {
    return this.store.createModel(body);
  }
}
