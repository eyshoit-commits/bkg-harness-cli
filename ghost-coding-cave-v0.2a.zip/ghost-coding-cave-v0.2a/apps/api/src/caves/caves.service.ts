import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { createHash } from 'crypto';
import { posix as pathPosix } from 'path';

/**
 * CavesService – v0.3a Stub (Prisma removed, API is stateless)
 * 
 * Real implementation would delegate to Semantic Store HTTP API
 * for now: returning mock data to unblock docker build
 */
@Injectable()
export class CavesService {
  private mockCaves = new Map<string, any>();
  private mockFiles = new Map<string, any>();

  private normalizePath(input: string): string {
    if (typeof input !== 'string') {
      throw new BadRequestException('File path must be a string');
    }

    const trimmed = input.trim();
    if (!trimmed) {
      throw new BadRequestException('File path is required');
    }

    const withForwardSlashes = trimmed.replace(/\\/g, '/');
    const normalized = pathPosix.normalize(withForwardSlashes);
    if (normalized.startsWith('..') || normalized.startsWith('/')) {
      throw new BadRequestException('Invalid file path');
    }

    return normalized;
  }

  async createCave(userId: string, name: string, language: string) {
    // TODO: POST to Semantic Store /v1/caves
    const caveId = `cave-${Date.now()}`;
    const cave = {
      id: caveId,
      projectId: `project-${userId}`,
      name,
      language: language.toUpperCase(),
      ramMb: parseInt(process.env.CAVE_DEFAULT_RAM_MB || '512'),
      cpuMillicores: parseInt(process.env.CAVE_DEFAULT_CPU_MILLICORES || '500'),
      tokensPerRun: parseInt(process.env.TOKEN_COST_RUN || '50'),
      status: 'ACTIVE',
      createdAt: new Date(),
    };
    this.mockCaves.set(caveId, cave);
    return cave;
  }

  async listCaves(userId: string) {
    // TODO: GET from Semantic Store /v1/caves?userId={userId}
    return Array.from(this.mockCaves.values());
  }

  async getCave(caveId: string, userId: string) {
    // TODO: GET from Semantic Store /v1/caves/{caveId}
    const cave = this.mockCaves.get(caveId);
    if (!cave) {
      throw new NotFoundException('Cave not found');
    }
    return { ...cave, files: [], versions: [] };
  }

  async listFiles(caveId: string, userId: string) {
    // TODO: GET from Semantic Store /v1/caves/{caveId}/files
    const files = Array.from(this.mockFiles.values()).filter(f => f.caveId === caveId);
    return {
      files: files.map((file) => ({
        path: file.path,
        name: file.path.split('/').pop(),
        size: file.size,
        updatedAt: file.updatedAt,
      })),
    };
  }

  async getFileContent(caveId: string, userId: string, rawPath: string | undefined) {
    if (!rawPath) {
      throw new BadRequestException('File path is required');
    }

    // TODO: GET from Semantic Store /v1/caves/{caveId}/files/{path}
    const normalizedPath = this.normalizePath(rawPath);
    const fileKey = `${caveId}:${normalizedPath}`;
    const file = this.mockFiles.get(fileKey);

    if (!file) {
      throw new NotFoundException('File not found');
    }

    return {
      path: file.path,
      name: file.path.split('/').pop(),
      content: file.content,
      size: file.size,
      updatedAt: file.updatedAt,
    };
  }

  async writeFile(
    caveId: string,
    userId: string,
    dto: { path: string; content: string },
  ) {
    // TODO: POST to Semantic Store /v1/caves/{caveId}/files
    const normalizedPath = this.normalizePath(dto.path);
    const content = dto.content ?? '';
    const buffer = Buffer.from(content, 'utf-8');
    const size = buffer.byteLength;
    const sha = createHash('sha256').update(buffer).digest('hex');

    const fileKey = `${caveId}:${normalizedPath}`;
    const file = {
      caveId,
      path: normalizedPath,
      contentSha: sha,
      size,
      content: content,
      updatedAt: new Date(),
    };
    this.mockFiles.set(fileKey, file);

    return {
      path: file.path,
      name: file.path.split('/').pop(),
      size: file.size,
      updatedAt: file.updatedAt,
    };
  }

  async renameFile(
    caveId: string,
    userId: string,
    dto: { path: string; newPath: string },
  ) {
    // TODO: PATCH to Semantic Store /v1/caves/{caveId}/files/{path}/rename
    const fromPath = this.normalizePath(dto.path);
    const toPath = this.normalizePath(dto.newPath);

    if (fromPath === toPath) {
      throw new BadRequestException('New path must be different from current path');
    }

    const fromKey = `${caveId}:${fromPath}`;
    const toKey = `${caveId}:${toPath}`;
    const file = this.mockFiles.get(fromKey);

    if (!file) {
      throw new NotFoundException('File not found');
    }

    if (this.mockFiles.has(toKey)) {
      throw new BadRequestException('Target path already exists');
    }

    const updated = { ...file, path: toPath };
    this.mockFiles.delete(fromKey);
    this.mockFiles.set(toKey, updated);

    return {
      path: updated.path,
      name: updated.path.split('/').pop(),
      size: updated.size,
      updatedAt: updated.updatedAt,
    };
  }

  async deleteFile(caveId: string, userId: string, rawPath: string | undefined) {
    if (!rawPath) {
      throw new BadRequestException('File path is required');
    }

    // TODO: DELETE to Semantic Store /v1/caves/{caveId}/files/{path}
    const normalizedPath = this.normalizePath(rawPath);
    const fileKey = `${caveId}:${normalizedPath}`;

    if (!this.mockFiles.has(fileKey)) {
      throw new NotFoundException('File not found');
    }

    this.mockFiles.delete(fileKey);
    return { path: normalizedPath };
  }

  async executeCave(caveId: string, code: string, userId: string, apiKey: any) {
    // TODO: POST to Ghost Server with authentication
    const ghostServerUrl = process.env.GHOST_SERVER_URL;
    const ghostServerApiKey = process.env.GHOST_SERVER_API_KEY || process.env.GHOST_API_KEY;

    if (!ghostServerUrl || !ghostServerApiKey) {
      throw new Error('Ghost server configuration missing');
    }

    const sanitizeUrl = (value: string) => value.replace(/\/$/, '');

    const jobId = `job-${Date.now()}`;
    const baseWsUrl = `${sanitizeUrl(ghostServerUrl.replace(/^http/, 'ws'))}/ws/logs`;

    return {
      jobId,
      logStreamUrl: `${baseWsUrl}/${jobId}`,
      tokensUsed: 50,
      tokenBalance: 9950,
    };
  }
}
