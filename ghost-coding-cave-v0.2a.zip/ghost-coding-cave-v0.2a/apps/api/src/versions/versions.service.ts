import { Injectable } from '@nestjs/common';

/**
 * VersionsService – v0.3a Stub (Prisma removed, API is stateless)
 * 
 * Real implementation would delegate to Semantic Store HTTP API
 * for now: returning mock data to unblock docker build
 */
@Injectable()
export class VersionsService {
  async createVersion(caveId: string, userId: string, summary?: string) {
    // TODO: POST to Semantic Store /v1/caves/{caveId}/versions
    return {
      id: `version-${Date.now()}`,
      caveId,
      authorUserId: userId,
      summary: summary || 'Auto-saved version',
      changeset: {},
      usedTokens: parseInt(process.env.TOKEN_COST_VERSION || '5'),
      timestamp: new Date(),
    };
  }

  async listVersions(caveId: string) {
    // TODO: GET from Semantic Store /v1/caves/{caveId}/versions
    return [];
  }
}
