import { Injectable } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';

/**
 * AdminService – v0.3a Stub (Stateless Gateway)
 * 
 * All admin operations moved to Semantic Store (ss-api @ :4011).
 * This stub returns empty/mock data for API compatibility.
 */
@Injectable()
export class AdminService {
  constructor(private readonly db: DatabaseService) {}

  async getAllUsers() {
    // v0.3a: Admin operations moved to Semantic Store
    return [];
  }

  async getAllCaves() {
    // v0.3a: Admin operations moved to Semantic Store
    return [];
  }

  async getAuditLogs(limit = 100) {
    // v0.3a: Admin operations moved to Semantic Store
    return [];
  }

  async getStats() {
    // v0.3a: Admin operations moved to Semantic Store
    return {
      totalUsers: 0,
      totalCaves: 0,
      totalTokensUsed: 0,
    };
  }
}
