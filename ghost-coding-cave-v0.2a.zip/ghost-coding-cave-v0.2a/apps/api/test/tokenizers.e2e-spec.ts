import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';

describe('Tokenizers E2E', () => {
  let app: INestApplication;

  beforeAll(async () => {
    process.env.SEMANTIC_STORE_HTTP_URL = process.env.SEMANTIC_STORE_HTTP_URL || 'http://localhost:4011';

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('GET /tokenizers should return array', async () => {
    const res = await request(app.getHttpServer()).get('/tokenizers').expect(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('POST /tokenizers upserts tokenizer', async () => {
    const payload = { name: `tok-${Date.now()}`, spec: { vocab_size: 1000 } };
    const res = await request(app.getHttpServer())
      .post('/tokenizers')
      .send(payload);
    expect([200,201]).toContain(res.status);
    expect(res.body).toMatchObject({ name: payload.name });
  });
});
