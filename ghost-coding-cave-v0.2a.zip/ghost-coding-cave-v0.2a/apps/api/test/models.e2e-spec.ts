import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';

// Requires ss-api running; use docker-compose default ports

describe('Models E2E', () => {
  let app: INestApplication;

  beforeAll(async () => {
    process.env.SEMANTIC_STORE_HTTP_URL = process.env.SEMANTIC_STORE_HTTP_URL || 'http://localhost:4011';

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('GET /models should return array', async () => {
    const res = await request(app.getHttpServer()).get('/models').expect(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  it('POST /models creates model', async () => {
    const payload = { name: `test-model-${Date.now()}`, provider: 'LOCAL', format: 'Ghost' };
    const res = await request(app.getHttpServer())
      .post('/models')
      .send(payload);
    expect([200,201]).toContain(res.status);
    expect(res.body).toMatchObject({ name: payload.name });
  });
});
