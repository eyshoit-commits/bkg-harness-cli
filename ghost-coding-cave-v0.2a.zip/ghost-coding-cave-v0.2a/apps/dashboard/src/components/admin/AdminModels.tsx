'use client'

import { useEffect, useState } from 'react'

type StoreModel = {
  id: string
  name: string
  provider?: string | null
  format?: string | null
  status: string
}

export default function AdminModels() {
  const [models, setModels] = useState<StoreModel[]>([])
  const [name, setName] = useState('')
  const [provider, setProvider] = useState('')
  const [format, setFormat] = useState('')
  const [loading, setLoading] = useState(false)
  const apiBase = process.env.NEXT_PUBLIC_API_URL || ''

  async function load() {
    const res = await fetch(`${apiBase}/api/models`)
    const data = await res.json()
    setModels(data)
  }

  async function create() {
    setLoading(true)
    try {
      await fetch(`${apiBase}/api/models`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, provider: provider || undefined, format: format || undefined }),
      })
      setName('')
      setProvider('')
      setFormat('')
      await load()
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="space-y-4">
      <div className="flex items-end gap-2">
        <div className="flex flex-col">
          <label className="text-xs text-text-gray">Name</label>
          <input className="border border-white/10 bg-black/30 rounded px-2 py-1" value={name} onChange={e=>setName(e.target.value)} placeholder="qwen2.5:1.5b-instruct" />
        </div>
        <div className="flex flex-col">
          <label className="text-xs text-text-gray">Provider</label>
          <input className="border border-white/10 bg-black/30 rounded px-2 py-1" value={provider} onChange={e=>setProvider(e.target.value)} placeholder="OLLAMA|LOCAL|HUGGINGFACE" />
        </div>
        <div className="flex flex-col">
          <label className="text-xs text-text-gray">Format</label>
          <input className="border border-white/10 bg-black/30 rounded px-2 py-1" value={format} onChange={e=>setFormat(e.target.value)} placeholder="GGUF|ONNX|Transformers|Ghost" />
        </div>
        <button onClick={create} disabled={loading || !name} className="px-3 py-2 rounded bg-accent-turquoise/20 text-accent-turquoise hover:bg-accent-turquoise/30">
          {loading ? 'Saving…' : 'Add Model'}
        </button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-white/10">
        <table className="min-w-full text-sm">
          <thead className="bg-white/5">
            <tr>
              <th className="text-left p-2">Name</th>
              <th className="text-left p-2">Provider</th>
              <th className="text-left p-2">Format</th>
              <th className="text-left p-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {models.map((m) => (
              <tr key={m.id} className="border-t border-white/10">
                <td className="p-2">{m.name}</td>
                <td className="p-2">{m.provider || '-'}</td>
                <td className="p-2">{m.format || '-'}</td>
                <td className="p-2">{m.status}</td>
              </tr>
            ))}
            {models.length === 0 && (
              <tr>
                <td className="p-3 text-text-gray" colSpan={4}>No models yet</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
