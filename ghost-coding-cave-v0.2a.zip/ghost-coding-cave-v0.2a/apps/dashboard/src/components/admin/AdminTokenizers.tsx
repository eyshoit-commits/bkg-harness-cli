'use client'

import { useEffect, useState } from 'react'

type StoreTokenizer = {
  id: string
  name: string
  spec: any
}

export default function AdminTokenizers() {
  const [tokenizers, setTokenizers] = useState<StoreTokenizer[]>([])
  const [name, setName] = useState('')
  const [spec, setSpec] = useState('{"vocab_size": 1000}')
  const [loading, setLoading] = useState(false)
  const apiBase = process.env.NEXT_PUBLIC_API_URL || ''

  async function load() {
    const res = await fetch(`${apiBase}/api/tokenizers`)
    const data = await res.json()
    setTokenizers(data)
  }

  async function upsert() {
    setLoading(true)
    try {
      const body = { name, spec: JSON.parse(spec || '{}') }
      await fetch(`${apiBase}/api/tokenizers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })
      setName('')
      await load()
    } catch (e) {
      alert('Invalid JSON in spec')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="space-y-4">
      <div className="flex items-end gap-2">
        <div className="flex flex-col">
          <label className="text-xs text-text-gray">Name</label>
          <input className="border border-white/10 bg-black/30 rounded px-2 py-1" value={name} onChange={e=>setName(e.target.value)} placeholder="llama-tokenizer" />
        </div>
        <div className="flex-1 flex flex-col">
          <label className="text-xs text-text-gray">Spec (JSON)</label>
          <input className="border border-white/10 bg-black/30 rounded px-2 py-1" value={spec} onChange={e=>setSpec(e.target.value)} />
        </div>
        <button onClick={upsert} disabled={loading || !name} className="px-3 py-2 rounded bg-accent-turquoise/20 text-accent-turquoise hover:bg-accent-turquoise/30">
          {loading ? 'Saving…' : 'Upsert Tokenizer'}
        </button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-white/10">
        <table className="min-w-full text-sm">
          <thead className="bg-white/5">
            <tr>
              <th className="text-left p-2">Name</th>
              <th className="text-left p-2">Spec</th>
            </tr>
          </thead>
          <tbody>
            {tokenizers.map((t) => (
              <tr key={t.id} className="border-t border-white/10">
                <td className="p-2">{t.name}</td>
                <td className="p-2 whitespace-pre-wrap text-xs text-text-gray">{JSON.stringify(t.spec)}</td>
              </tr>
            ))}
            {tokenizers.length === 0 && (
              <tr>
                <td className="p-3 text-text-gray" colSpan={2}>No tokenizers yet</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
