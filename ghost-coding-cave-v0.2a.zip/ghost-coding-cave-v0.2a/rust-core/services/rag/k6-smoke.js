import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 20,
  duration: '30s',
  thresholds: {
    http_req_duration: ['p(95)<500'],
    http_req_failed: ['rate<0.01'],
  },
};

const BASE = __ENV.BASE_URL || 'http://localhost:8083';

export default function () {
  // Health check
  let r = http.get(`${BASE}/healthz`);
  check(r, {
    'health is 200': (res) => res.status === 200,
    'health is ok': (res) => res.body === 'ok',
  });

  // Readiness check
  r = http.get(`${BASE}/readyz`);
  check(r, {
    'ready is 200': (res) => res.status === 200,
  });

  // Version check
  r = http.get(`${BASE}/version`);
  check(r, {
    'version is 200': (res) => res.status === 200,
  });

  // Ingest document
  const ingestPayload = JSON.stringify({
    text: 'k6 load test document with random data ' + Math.random(),
    metadata: { test: true, timestamp: Date.now() },
  });

  r = http.post(`${BASE}/ingest`, ingestPayload, {
    headers: { 'Content-Type': 'application/json' },
  });
  check(r, {
    'ingest is 200': (res) => res.status === 200,
    'ingest returns id': (res) => JSON.parse(res.body).id !== undefined,
  });

  // Query documents
  const queryPayload = JSON.stringify({
    query: 'load test query',
    top_k: 3,
    generate: true,
  });

  r = http.post(`${BASE}/query`, queryPayload, {
    headers: { 'Content-Type': 'application/json' },
  });
  check(r, {
    'query is 200': (res) => res.status === 200,
    'query returns contexts': (res) => JSON.parse(res.body).contexts !== undefined,
    'query returns answer': (res) => JSON.parse(res.body).answer !== undefined,
  });

  sleep(0.2);
}
