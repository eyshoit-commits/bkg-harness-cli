use rag::{AppState, http::routes};
use axum::{Router, routing::post};
use std::net::SocketAddr;

#[tokio::test]
async fn e2e_ingest_and_query() {
    let state = AppState::new();
    let app = Router::new()
        .route("/ingest", post(routes::ingest))
        .route("/query", post(routes::query))
        .with_state(state);

    let listener = tokio::net::TcpListener::bind(("127.0.0.1", 0)).await.unwrap();
    let addr: SocketAddr = listener.local_addr().unwrap();

    let server = tokio::spawn(async move {
        axum::serve(listener, app).await.unwrap();
    });

    let client = reqwest::Client::new();

    // ingest
    let res = client.post(format!("http://{}/ingest", addr))
        .json(&serde_json::json!({
            "text": "Rust ist nice für RAG. Axum rockt.",
            "metadata": { "lang": "de" }
        }))
        .send().await.unwrap();
    assert!(res.status().is_success());
    let v: serde_json::Value = res.json().await.unwrap();
    assert!(v.get("id").and_then(|x| x.as_str()).is_some());

    // query
    let res = client.post(format!("http://{}/query", addr))
        .json(&serde_json::json!({
            "query": "Was rockt?",
            "top_k": 2,
            "generate": true
        }))
        .send().await.unwrap();
    assert!(res.status().is_success());
    let vr: serde_json::Value = res.json().await.unwrap();
    assert!(vr["contexts"].as_array().unwrap().len() > 0);
    assert!(vr["answer"].as_str().unwrap().contains("Kontexte"));

    server.abort();
}
