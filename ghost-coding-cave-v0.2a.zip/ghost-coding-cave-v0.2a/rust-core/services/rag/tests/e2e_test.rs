#[cfg(test)]
mod tests {
    use rag::{AppState, http::routes};
    use axum::{Router, routing::post};
    use std::net::SocketAddr;
    
    #[tokio::test]
    async fn e2e_ingest_and_query() {
        // App in Test hochziehen, Port 0 => OS wählt
        let state = AppState::new();
        let app = Router::new()
            .route("/ingest", post(routes::ingest))
            .route("/query", post(routes::query))
            .with_state(state.clone());
    
        let listener = tokio::net::TcpListener::bind(("127.0.0.1", 0)).await.unwrap();
        let addr: SocketAddr = listener.local_addr().unwrap();
    
        let server = tokio::spawn(async move {
            axum::serve(listener, app).await.unwrap();
        });
    
        // 1) Ingest
        let client = reqwest::Client::new();
        let doc = r#"{"text":"Rust ist nice für RAG. Axum rockt.","metadata":{"lang":"de"}}"#;
        let res = client.post(format!("http://{}/ingest", addr))
            .header("content-type", "application/json")
            .body(doc)
            .send().await.unwrap();
        assert!(res.status().is_success());
        let v: serde_json::Value = res.json().await.unwrap();
        let id = v.get("id").unwrap().as_str().unwrap();
        assert!(!id.is_empty());
    
        // 2) Query
        let q = r#"{"query":"Was rockt?","top_k":2,"generate":true}"#;
        let res = client.post(format!("http://{}/query", addr))
            .header("content-type", "application/json")
            .body(q)
            .send().await.unwrap();
        assert!(res.status().is_success());
        let vr: serde_json::Value = res.json().await.unwrap();
        assert!(vr.get("contexts").unwrap().as_array().unwrap().len() > 0);
        assert!(vr.get("answer").unwrap().as_str().unwrap().contains("Kontexte"));
    
        // server beenden
        server.abort();
    }
}
