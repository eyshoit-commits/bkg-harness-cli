# RAG Service for Semantic Store

A modular Retrieval Augmented Generation (RAG) service that integrates with the Semantic Store.

## Features

- 🔄 Multiple storage backends:
  - **Embedded**: Simple file-based storage
  - **SQL**: SQLite backend (optional feature)
  - **NeoDB**: Cryptographically verifiable storage with WAL and Merkle trees

- 🔍 Vector indexing:
  - Integration with `nano-vectordb-rs` for fast similarity search
  - Optional feature - can run without vector capabilities

- 🤖 LLM integration:
  - REST API adapter for LLM services
  - Configurable prompt templates and generation parameters

- 📄 Document processing:
  - Chunking with configurable size and overlap
  - Metadata support
  - Namespace organization

- 🌐 APIs:
  - HTTP REST API (port 8647)
  - WebSocket for live advice (port 8650)
  - gRPC API (planned)

## Configuration

The service is configured through environment variables:

```
# Storage backend
SS_STORAGE_MODE=embedded|sql|neodb
SS_STORAGE_PATH=/path/to/storage

# Vector index
RAG_VECTOR_MODE=enabled|disabled
RAG_VECTOR_PATH=/path/to/vector/index
RAG_EMBEDDING_DIMS=768

# Server
RAG_HTTP_ADDR=127.0.0.1:8647
RAG_WS_ADDR=127.0.0.1:8650

# LLM
RAG_LLM_URL=http://localhost:8000
RAG_LLM_API_KEY=your_api_key
```

## Build & Run

```bash
# Build
cd rust-core/services/rag
cargo build --release

# Run
cargo run --release

# With Docker Compose
docker-compose -f docker-compose.rag.yml up
```

## API Usage

### Ingest a Document

```bash
curl -X POST http://localhost:8647/ingest -H "Content-Type: application/json" -d '{
  "id": "doc1",
  "namespace": "test",
  "text": "This is a test document for the RAG service.",
  "metadata": {"source": "example", "author": "test"}
}'
```

### Query

```bash
curl -X POST http://localhost:8647/query -H "Content-Type: application/json" -d '{
  "query": "What is this document about?",
  "top_k": 5
}'
```

### Reindex Documents

```bash
curl -X POST http://localhost:8647/admin/reindex -H "Content-Type: application/json" -d '{
  "namespaces": ["test"]
}'
```

## Integration with Helper Agents

The RAG service can integrate with the Helper Agents system via:

1. REST API for planning and advice
2. WebSocket connection for live assistance
