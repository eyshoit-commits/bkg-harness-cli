# RAG Service - Quick Start 🚀

## 30-Second Start

```bash
# Clone & Build
git clone <repo>
cd rust-core/services/rag

# Run locally
RUST_LOG=info cargo run -p rag

# Test
curl http://localhost:8083/healthz
```

## Docker (Fastest)

```bash
docker-compose up
```

Access: http://localhost:8083

## Production Deployment

### Option 1: Kubernetes
```bash
kubectl apply -f k8s-deployment.yaml
kubectl get pods -l app=rag
```

### Option 2: Docker
```bash
docker build -t rag:latest .
docker run -p 8083:8083 -e RUST_LOG=info rag:latest
```

### Option 3: Binary
```bash
cargo build --release -p rag
RAG_PORT=8083 RUST_LOG=info ./target/release/rag
```

## Configuration

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
# Edit .env with your settings
```

## API Examples

### Ingest Document
```bash
curl -X POST http://localhost:8083/ingest \
  -H 'Content-Type: application/json' \
  -d '{
    "text": "Rust is a systems programming language",
    "metadata": {"source": "docs"}
  }'
```

### Query
```bash
curl -X POST http://localhost:8083/query \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "What is Rust?",
    "top_k": 3,
    "generate": true
  }'
```

### Health Check
```bash
curl http://localhost:8083/healthz    # "ok"
curl http://localhost:8083/readyz     # "ready"
curl http://localhost:8083/version    # "0.1.0"
curl http://localhost:8083/metrics    # Prometheus metrics
```

## Development

### Run Tests
```bash
cargo test -p rag
```

### Lint
```bash
cargo fmt --all --check
cargo clippy -- -D warnings
```

### Load Test
```bash
k6 run --vus 20 --duration 30s k6-smoke.js
```

## Troubleshooting

**Port already in use?**
```bash
RAG_PORT=8084 cargo run -p rag
```

**Build fails?**
```bash
cargo clean
cargo build -p rag
```

**Need verbose logs?**
```bash
RUST_LOG=debug cargo run -p rag
```

## Production Checklist

Before deploying:
1. Set `RAG_ALLOWED_ORIGINS` for CORS
2. Enable `RAG_LOG_JSON=true`
3. Configure Prometheus scraping
4. Set up monitoring/alerting
5. Run `./scripts/preflight-rag.sh`

## Next Steps

- Read [HARDENING_COMPLETE.md](HARDENING_COMPLETE.md) for full features
- Check [PRODUCTION_READY.md](PRODUCTION_READY.md) for deployment guide
- Review [k6-smoke.js](k6-smoke.js) for load testing

## Support

- Issues: GitHub Issues
- Docs: `/docs` (OpenAPI - coming soon)
- Metrics: `/metrics` (Prometheus format)
