pub mod adapters;
pub mod pipeline;
pub mod http;
pub mod helper;

use std::sync::Arc;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Document {
    pub id: Uuid,
    pub text: String,
    #[serde(default)]
    pub metadata: serde_json::Value,
}

#[derive(Clone)]
pub struct AppState {
    pub storage: Arc<RwLock<adapters::storage::MemoryStorage>>,
    pub vectors: Arc<RwLock<adapters::vectors::MemoryVectorIndex>>,
    pub llm: Arc<adapters::llm::DummyLlm>,
}

impl Default for AppState {
    fn default() -> Self {
        Self::new()
    }
}

impl AppState {
    pub fn new() -> Self {
        Self {
            storage: Arc::new(RwLock::new(adapters::storage::MemoryStorage::default())),
            vectors: Arc::new(RwLock::new(adapters::vectors::MemoryVectorIndex::default())),
            llm: Arc::new(adapters::llm::DummyLlm::new(384)),
        }
    }
}
