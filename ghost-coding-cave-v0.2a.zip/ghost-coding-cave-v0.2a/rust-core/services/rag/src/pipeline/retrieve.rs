use crate::AppState;

pub async fn retrieve_topk(state: &AppState, query: &str, k: usize) -> Vec<String> {
    let q = state.llm.embed(query);
    let ids = state.vectors.read().search(&q, k);
    let storage = state.storage.read();
    ids.into_iter()
        .filter_map(|(id, _score)| storage.get(&id).map(|d| d.text))
        .collect()
}
