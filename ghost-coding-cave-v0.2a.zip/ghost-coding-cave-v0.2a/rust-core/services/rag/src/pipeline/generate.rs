use crate::AppState;

pub async fn answer(state: &AppState, query: &str, contexts: &[String]) -> String {
    state.llm.generate(query, contexts)
}
