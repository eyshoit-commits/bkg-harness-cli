use uuid::Uuid;
use serde_json::Value;
use crate::{AppState, Document};

pub async fn ingest(state: &AppState, text: String, metadata: Value) -> uuid::Uuid {
    let id = Uuid::new_v4();
    // Store doc
    {
        let mut storage = state.storage.write();
        storage.put(id, text.clone(), metadata);
    }
    // Build vector
    let emb = state.llm.embed(&text);
    {
        let mut index = state.vectors.write();
        index.upsert(id, emb);
    }
    id
}

pub async fn ingest_with_id(state: &AppState, id: Uuid, text: String, metadata: Value) {
    {
        let mut storage = state.storage.write();
        storage.put(id, text.clone(), metadata);
    }
    let emb = state.llm.embed(&text);
    {
        let mut index = state.vectors.write();
        index.upsert(id, emb);
    }
}

pub async fn list_all(state: &AppState) -> Vec<Document> {
    state.storage.read().all()
}
