use anyhow::Result;
use futures_util::{SinkExt, StreamExt};
use tokio::net::TcpListener;
use tokio_tungstenite::tungstenite::Message;

pub async fn serve_ws(addr: &str) -> Result<()> {
    let listener = TcpListener::bind(addr).await?;
    loop {
        let (stream, _peer) = listener.accept().await?;
        tokio::spawn(async move {
            let ws = tokio_tungstenite::accept_async(stream).await;
            if let Ok(mut ws) = ws {
                while let Some(Ok(msg)) = ws.next().await {
                    match msg {
                        Message::Text(t) => {
                            // TODO: ASR/TTS/RAG hooken
                            let _ = ws.send(Message::Text(format!("ack: {t}"))).await;
                        }
                        Message::Binary(_) => { /* audio frames */ }
                        _ => {}
                    }
                }
            }
        });
    }
}
