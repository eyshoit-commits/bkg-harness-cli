use anyhow::Result;

pub struct YouTubeIngest;

impl YouTubeIngest {
    pub async fn fetch_transcript(video_id: &str) -> Result<String> {
        // TODO: yt-dlp oder API-Wrapper; jetzt nur stub
        Ok(format!("transcript for {video_id}"))
    }
}
