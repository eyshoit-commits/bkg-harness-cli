use anyhow::{anyhow, Result};
use futures_util::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::broadcast;
use tokio_tungstenite::{
    connect_async,
    tungstenite::protocol::Message,
};

/// Message from the live advice system
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AdviceMessage {
    /// Source of the advice
    pub source: String,
    /// Type of advice
    pub kind: String,
    /// Content of the advice
    pub content: String,
    /// Timestamp
    pub timestamp: String,
}

/// Client for the live advice system
pub struct LiveAdviceClient {
    /// Broadcast channel for advice messages
    tx: broadcast::Sender<AdviceMessage>,
}

impl LiveAdviceClient {
    /// Create a new live advice client
    pub fn new() -> Self {
        let (tx, _) = broadcast::channel(100);
        Self { tx }
    }
    
    /// Connect to the live advice WebSocket server
    pub async fn connect(&self, ws_url: &str) -> Result<()> {
        let url = url::Url::parse(ws_url)
            .map_err(|e| anyhow!("Invalid WebSocket URL: {}", e))?;
            
        let (ws_stream, _) = connect_async(url).await
            .map_err(|e| anyhow!("Failed to connect to WebSocket: {}", e))?;
            
        let (mut write, read) = ws_stream.split();
        
        // Subscribe to the advice channel
        write.send(Message::Text("subscribe:advice".into())).await
            .map_err(|e| anyhow!("Failed to send subscription: {}", e))?;
            
        let tx = self.tx.clone();
        
        // Spawn a task to handle incoming messages
        tokio::spawn(async move {
            let mut read = read;
            
            while let Some(msg) = read.next().await {
                if let Ok(msg) = msg {
                    if let Message::Text(txt) = msg {
                        if let Ok(advice) = serde_json::from_str::<AdviceMessage>(&txt) {
                            let _ = tx.send(advice);
                        }
                    }
                }
            }
        });
        
        Ok(())
    }
    
    /// Subscribe to advice messages
    pub fn subscribe(&self) -> broadcast::Receiver<AdviceMessage> {
        self.tx.subscribe()
    }
}

impl Default for LiveAdviceClient {
    fn default() -> Self {
        Self::new()
    }
}
