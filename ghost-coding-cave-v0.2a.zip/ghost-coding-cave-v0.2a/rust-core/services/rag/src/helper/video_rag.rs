
pub struct VideoRagPlanner;

impl VideoRagPlanner {
    // zerschneidet lange Videos in Szenenfenster, priorisiert Treffer
    pub fn plan_windows(duration_ms: u64, window_ms: u64, stride_ms: u64) -> Vec<(u64,u64)> {
        let mut out = Vec::new();
        let mut s = 0;
        while s < duration_ms {
            let e = s.saturating_add(window_ms).min(duration_ms);
            out.push((s, e));
            if e == duration_ms { break; }
            s = s.saturating_add(stride_ms);
        }
        out
    }
}
