use anyhow::Result;
use serde::{Deserialize, Serialize};

/// Request for generating a plan
#[derive(Serialize)]
pub struct PlanRequest {
    /// The prompt to plan for
    pub prompt: String,
    /// Optional context for the plan
    pub context: Option<String>,
}

/// Response from plan generation
#[derive(Deserialize)]
pub struct PlanResponse {
    /// Summary of the plan
    pub summary: String,
    /// Suggested steps or actions
    pub suggestions: Vec<String>,
}

/// Generate a plan using the Helper Agent API
pub async fn plan(base_url: &str, req: &PlanRequest) -> Result<PlanResponse> {
    let url = format!("{base_url}/api/chat/plan");
    
    let client = reqwest::Client::new();
    let response = client
        .post(&url)
        .json(req)
        .send()
        .await?
        .error_for_status()?;
        
    let plan: PlanResponse = response.json().await?;
    Ok(plan)
}
