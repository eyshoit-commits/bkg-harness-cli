use axum::{routing::post, Json, Router};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::{AppState, adapters::{storage::StoreAdapter, vectors::CoreVector}, pipeline::{RagDoc, ingest::Ingestor, retrieve::Retriever, generate}};

#[derive(Deserialize)]
pub struct IngestReq { pub id:String, pub namespace:String, pub text:String, pub metadata: Option<serde_json::Value>, pub embedding: Option<Vec<f32>> }

#[derive(Deserialize)]
pub struct QueryReq { pub query_embedding: Vec<f32>, pub top_k: Option<usize>, pub user_query: Option<String>, pub llm_base: Option<String> }

#[derive(Serialize)]
pub struct QueryResp { pub answer:String, pub contexts:Vec<serde_json::Value> }

pub fn router(state: AppState) -> Router {
    let st = Arc::new(state);
    Router::new()
        .route("/ingest", post({
            let st = st.clone();
            move |Json(r): Json<IngestReq>| {
                let st = st.clone();
                async move {
                    let store = StoreAdapter::new(st.store.clone());
                    let vector = st.vector.clone().map(CoreVector);
                    let ing = Ingestor::new(store, vector);
                    let doc = RagDoc {
                        id: r.id, namespace: r.namespace, text: r.text,
                        metadata: r.metadata.unwrap_or(serde_json::json!({})),
                    };
                    ing.ingest(doc, r.embedding.as_deref()).await
                        .map(|_| Json(serde_json::json!({"status":"ok"})))
                        .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))
                }
            }
        }))
        .route("/query", post({
            move |Json(r): Json<QueryReq>| {
                let st = st.clone();
                async move {
                    let top_k = r.top_k.unwrap_or(5);
                    if let Some(v) = &st.vector {
                        let retr = Retriever::new(StoreAdapter::new(st.store.clone()), CoreVector(v.clone()));
                        let hits = retr.search(&r.query_embedding, top_k).await
                            .map_err(|e| (axum::http::StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
                        let mut ctx_json = Vec::new();
                        let mut ctx_texts = Vec::new();
                        for (_k, bytes) in hits {
                            if let Ok(v) = serde_json::from_slice::<serde_json::Value>(&bytes) {
                                ctx_texts.push(v.get("text").and_then(|t| t.as_str()).unwrap_or("").to_string());
                                ctx_json.push(v);
                            }
                        }
                        let llm_base = r.llm_base.unwrap_or_else(|| "http://localhost:8710".into());
                        let user_q = r.user_query.unwrap_or_else(|| "Summarize context".into());
                        let answer = generate::answer(&llm_base, &user_q, &ctx_texts).await
                            .map_err(|e| (axum::http::StatusCode::BAD_GATEWAY, e.to_string()))?;
                        Ok::<_, (axum::http::StatusCode, String)>(Json(QueryResp { answer, contexts: ctx_json }))
                    } else {
                        Err((axum::http::StatusCode::PRECONDITION_FAILED, "vector index disabled".into()))
                    }
                }
            }
        }))
}
