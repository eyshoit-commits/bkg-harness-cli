use blake3::Hasher;

#[derive(Clone)]
pub struct DummyLlm {
    dim: usize,
}

impl DummyLlm {
    pub fn new(dim: usize) -> Self { Self { dim } }

    pub fn embed(&self, text: &str) -> Vec<f32> {
        // deterministic pseudo-embedding via BLAKE3
        let bytes_needed = self.dim * 4;
        let mut hasher = Hasher::new();
        hasher.update(text.as_bytes());
        let mut out = hasher.finalize_xof();
        let mut buf = vec![0u8; bytes_needed];
        // fill expand
        out.fill(&mut buf);
        // map to [0,1) then mean-center + l2-normalize
        let mut v: Vec<f32> = buf.chunks_exact(4)
            .map(|c| {
                let x = u32::from_le_bytes([c[0], c[1], c[2], c[3]]);
                x as f32 / u32::MAX as f32
            })
            .collect();
        let mean = v.iter().sum::<f32>() / v.len() as f32;
        for x in &mut v { *x -= mean; }
        let norm = (v.iter().map(|x| x * x).sum::<f32>()).sqrt().max(1e-8);
        for x in &mut v { *x /= norm; }
        v
    }

    pub fn generate(&self, query: &str, contexts: &[String]) -> String {
        // Super-dummes "LLM": gibt die Top-Kontexte plus Query als Antwort zurück.
        let mut out = String::new();
        out.push_str("Antwort (demo):\n");
        out.push_str("Query: ");
        out.push_str(query);
        out.push_str("\nKontexte:\n");
        for (i, c) in contexts.iter().enumerate() {
            out.push_str(&format!("{}. {}\n", i + 1, c));
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::DummyLlm;

    #[test]
    fn embeddings_are_deterministic() {
        let llm = DummyLlm::new(64);
        assert_eq!(llm.embed("hi"), llm.embed("hi"));
    }

    #[test]
    fn embeddings_differ_for_different_text() {
        let llm = DummyLlm::new(64);
        assert_ne!(llm.embed("hello"), llm.embed("world"));
    }

    #[test]
    fn embeddings_are_normalized() {
        let llm = DummyLlm::new(64);
        let v = llm.embed("test");
        let norm: f32 = v.iter().map(|x| x * x).sum::<f32>().sqrt();
        assert!((norm - 1.0).abs() < 1e-5);
    }

    #[test]
    fn generate_is_deterministic() {
        let llm = DummyLlm::new(64);
        let ctx = vec!["ctx1".to_string(), "ctx2".to_string()];
        let out1 = llm.generate("hello", &ctx);
        let out2 = llm.generate("hello", &ctx);
        assert_eq!(out1, out2);
    }

    #[test]
    fn generate_includes_query_and_contexts() {
        let llm = DummyLlm::new(64);
        let ctx = vec!["context one".to_string()];
        let out = llm.generate("my query", &ctx);
        assert!(out.contains("my query"));
        assert!(out.contains("context one"));
    }
}
