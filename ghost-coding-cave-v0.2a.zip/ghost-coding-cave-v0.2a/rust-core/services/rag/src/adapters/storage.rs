use std::collections::HashMap;
use uuid::Uuid;
use serde_json::Value;
use crate::Document;

#[derive(Default, Clone)]
pub struct MemoryStorage {
    // id -> (text, metadata)
    inner: HashMap<Uuid, (String, Value)>,
}

impl MemoryStorage {
    pub fn put(&mut self, id: Uuid, text: String, metadata: Value) {
        self.inner.insert(id, (text, metadata));
    }

    pub fn get(&self, id: &Uuid) -> Option<Document> {
        self.inner.get(id).map(|(t, m)| Document {
            id: *id,
            text: t.clone(),
            metadata: m.clone(),
        })
    }

    pub fn all(&self) -> Vec<Document> {
        self.inner.iter().map(|(id, (t, m))| Document {
            id: *id,
            text: t.clone(),
            metadata: m.clone(),
        }).collect()
    }
}
