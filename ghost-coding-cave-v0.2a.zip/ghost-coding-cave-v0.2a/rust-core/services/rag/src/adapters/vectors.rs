use uuid::Uuid;

#[derive(Default, Clone)]
pub struct MemoryVectorIndex {
    // simple in-memory (id, embedding)
    pub items: Vec<(Uuid, Vec<f32>)>,
}

impl MemoryVectorIndex {
    pub fn upsert(&mut self, id: Uuid, emb: Vec<f32>) {
        if let Some(slot) = self.items.iter_mut().find(|(i, _)| *i == id) {
            slot.1 = emb;
        } else {
            self.items.push((id, emb));
        }
    }

    pub fn search(&self, q: &[f32], top_k: usize) -> Vec<(Uuid, f32)> {
        let mut scored: Vec<(Uuid, f32)> = self.items
            .iter()
            .map(|(id, v)| (*id, cosine_sim(q, v)))
            .collect();
        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        scored.truncate(top_k);
        scored
    }
}

fn cosine_sim(a: &[f32], b: &[f32]) -> f32 {
    let mut dot = 0.0;
    let mut na = 0.0;
    let mut nb = 0.0;
    let n = a.len().min(b.len());
    for i in 0..n {
        dot += a[i] * b[i];
        na += a[i] * a[i];
        nb += b[i] * b[i];
    }
    if na == 0.0 || nb == 0.0 { return 0.0; }
    dot / (na.sqrt() * nb.sqrt())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cosine_is_1_for_identical() {
        let v = vec![0.1, 0.2, 0.3];
        let s = cosine_sim(&v, &v);
        assert!((s - 1.0).abs() < 1e-6);
    }

    #[test]
    fn cosine_is_0_for_orthogonal() {
        let v1 = vec![1.0, 0.0];
        let v2 = vec![0.0, 1.0];
        let s = cosine_sim(&v1, &v2);
        assert!(s.abs() < 1e-6);
    }

    #[test]
    fn cosine_handles_zero_vectors() {
        let v1 = vec![0.0, 0.0];
        let v2 = vec![1.0, 2.0];
        let s = cosine_sim(&v1, &v2);
        assert_eq!(s, 0.0);
    }

    #[test]
    fn cosine_handles_different_lengths() {
        let v1 = vec![1.0, 2.0, 3.0];
        let v2 = vec![1.0, 2.0];
        let s = cosine_sim(&v1, &v2);
        // Should compute using min length (2)
        assert!(s > 0.99);
    }

    #[test]
    fn vector_index_upsert_updates_existing() {
        let mut idx = MemoryVectorIndex::default();
        let id = uuid::Uuid::new_v4();
        idx.upsert(id, vec![1.0, 2.0]);
        idx.upsert(id, vec![3.0, 4.0]);
        assert_eq!(idx.items.len(), 1);
        assert_eq!(idx.items[0].1, vec![3.0, 4.0]);
    }

    #[test]
    fn vector_index_search_returns_top_k() {
        let mut idx = MemoryVectorIndex::default();
        let id1 = uuid::Uuid::new_v4();
        let id2 = uuid::Uuid::new_v4();
        let id3 = uuid::Uuid::new_v4();
        
        idx.upsert(id1, vec![1.0, 0.0]);
        idx.upsert(id2, vec![0.9, 0.1]);
        idx.upsert(id3, vec![0.0, 1.0]);
        
        let query = vec![1.0, 0.0];
        let results = idx.search(&query, 2);
        
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].0, id1); // Most similar
    }
}
