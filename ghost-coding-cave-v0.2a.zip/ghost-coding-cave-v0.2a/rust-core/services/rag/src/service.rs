use crate::{
    adapters::{
        llm::{LlmEngine, LlmInput, LlmOutput},
        storage::KvStore,
        vectors::VectorIndex,
    },
    pipeline::{
        generate::{GenerateOptions, Generator},
        ingest::Ingestor,
        retrieve::Retriever,
        RagDoc, RetrievalResult,
    },
};
use anyhow::{anyhow, Context, Result};
use std::sync::Arc;

/// Status of the RAG service components
pub struct HealthStatus {
    /// Whether the vector index is available
    pub vector_index_available: bool,
    /// Whether the LLM is available
    pub llm_available: bool,
}

/// Result of a query operation
pub struct QueryResult {
    /// Generated answer
    pub answer: String,
    /// Retrieved contexts
    pub contexts: RetrievalResult,
    /// Total tokens used
    pub total_tokens: Option<usize>,
}

/// Service that ties together all RAG components
pub struct RagService<S, V, L> {
    /// Storage backend
    store: Arc<S>,
    /// Optional vector index
    vectors: Option<Arc<V>>,
    /// LLM engine
    llm: Arc<L>,
    /// Ingestor for documents
    ingestor: Ingestor<S, V>,
    /// Retriever for context
    retriever: Option<Retriever<S, V>>,
    /// Generator for answers
    generator: Generator<L>,
    /// Default options for generation
    generate_options: GenerateOptions,
    /// Default number of results to retrieve
    default_top_k: usize,
    /// Function to compute embeddings
    embedding_fn: Box<dyn Fn(&str) -> Result<Vec<f32>> + Send + Sync>,
}

impl<S, V, L> RagService<S, V, L>
where
    S: KvStore + 'static,
    V: VectorIndex + 'static,
    L: LlmEngine + 'static,
{
    /// Create a new RAG service
    pub fn new(
        store: Arc<S>,
        vectors: Option<Arc<V>>,
        llm: Arc<L>,
        default_top_k: usize,
        generate_options: Option<GenerateOptions>,
        embedding_fn: impl Fn(&str) -> Result<Vec<f32>> + Send + Sync + 'static,
    ) -> Self {
        let ingestor = Ingestor::new(Arc::clone(&store), vectors.clone(), None);
        let retriever = vectors
            .clone()
            .map(|v| Retriever::new(Arc::clone(&store), Arc::clone(&v), default_top_k));
        let generator = Generator::new(Arc::clone(&llm), generate_options.clone());

        Self {
            store,
            vectors,
            llm,
            ingestor,
            retriever,
            generator,
            generate_options: generate_options.unwrap_or_default(),
            default_top_k,
            embedding_fn: Box::new(embedding_fn),
        }
    }
    
    /// Check the health of service components
    pub async fn health_check(&self) -> Result<HealthStatus> {
        let vector_index_available = if let Some(vectors) = &self.vectors {
            vectors.count().await.is_ok()
        } else {
            false
        };
        
        let llm_available = self.llm.healthcheck().await.unwrap_or(false);
        
        Ok(HealthStatus {
            vector_index_available,
            llm_available,
        })
    }
    
    /// Ingest a document
    pub async fn ingest(&self, doc: RagDoc, embedding: Option<Vec<f32>>) -> Result<Vec<String>> {
        let embedding_fn = if let Some(emb) = embedding {
            // Use provided embedding
            let fixed_emb = emb.clone();
            Box::new(move |_: &str| -> Result<Vec<f32>> { Ok(fixed_emb.clone()) })
                as Box<dyn Fn(&str) -> Result<Vec<f32>> + Send + Sync>
        } else {
            // Use the default embedding function
            Box::new(|text| (self.embedding_fn)(text))
                as Box<dyn Fn(&str) -> Result<Vec<f32>> + Send + Sync>
        };
        
        self.ingestor.ingest(doc, embedding_fn).await
    }
    
    /// Query the RAG system
    pub async fn query(
        &self,
        query: &str,
        query_embedding: Option<Vec<f32>>,
        top_k: Option<usize>,
        namespaces: &[String],
        rerank: bool,
        filter_keywords: &[&str],
        system_prompt: Option<&str>,
    ) -> Result<QueryResult> {
        // Check if vector retrieval is enabled
        let retriever = self.retriever.as_ref().ok_or_else(|| {
            anyhow!("Vector retrieval is disabled. Enable with 'vectors' feature")
        })?;
        
        // Compute query embedding if not provided
        let emb = if let Some(emb) = query_embedding {
            emb
        } else {
            (self.embedding_fn)(query)?
        };
        
        // Retrieve context
        let mut contexts = retriever.search(&emb, top_k).await?;
        
        // Filter by keywords if provided
        if !filter_keywords.is_empty() {
            retriever.filter_by_keywords(&mut contexts, filter_keywords)?;
        }
        
        // Filter by namespace if provided
        if !namespaces.is_empty() {
            contexts.chunks.retain(|chunk| namespaces.contains(&chunk.namespace));
            // Recompute scores array to match chunks
            contexts.scores.truncate(contexts.chunks.len());
        }
        
        // Create generation options with custom system prompt if provided
        let mut options = self.generate_options.clone();
        if let Some(system) = system_prompt {
            options.system_template = system.to_string();
        }
        
        // Generate answer
        let llm_output = self.generator.generate(query, &contexts, Some(options)).await?;
        
        Ok(QueryResult {
            answer: llm_output.response,
            contexts,
            total_tokens: llm_output.total_tokens,
        })
    }
    
    /// Delete a document
    pub async fn delete_document(&self, namespace: &str, doc_id: &str) -> Result<usize> {
        self.ingestor.delete_document(namespace, doc_id).await
    }
    
    /// Reindex all documents or specific namespaces
    pub async fn reindex_all(&self, namespaces: &[String]) -> Result<usize> {
        if self.vectors.is_none() {
            return Ok(0);
        }
        
        self.ingestor
            .reindex_all(|text| (self.embedding_fn)(text))
            .await
    }
}
