use axum::{Router, routing::{get, post}, extract::State, http::StatusCode, response::IntoResponse};
use tower_http::{
    cors::CorsLayer,
    trace::TraceLayer,
    compression::CompressionLayer,
    timeout::TimeoutLayer,
    set_header::SetResponseHeaderLayer,
};
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};
use rag::{http::routes, AppState};
use std::{net::SocketAddr, env, time::Duration};
use axum_prometheus::PrometheusMetricLayer;
use tower_governor::{governor::GovernorConfigBuilder, GovernorLayer};
use http::{Method, HeaderValue, header::{CONTENT_TYPE, STRICT_TRANSPORT_SECURITY}};

const VERSION: &str = env!("CARGO_PKG_VERSION");

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Logging - JSON in production
    let use_json = env::var("RAG_LOG_JSON").unwrap_or_else(|_| "false".to_string()) == "true";
    
    if use_json {
        tracing_subscriber::registry()
            .with(tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,axum=info,tower_http=info".into()))
            .with(tracing_subscriber::fmt::layer().json())
            .init();
    } else {
        tracing_subscriber::registry()
            .with(tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info,axum=info,tower_http=info".into()))
            .with(tracing_subscriber::fmt::layer())
            .init();
    }

    let state = AppState::new();

    // CORS - Restrictive for production
    let allowed_origins = env::var("RAG_ALLOWED_ORIGINS")
        .unwrap_or_else(|_| "http://localhost:3000".to_string())
        .split(',')
        .filter_map(|s| s.trim().parse().ok())
        .collect::<Vec<_>>();
    
    let cors = if allowed_origins.is_empty() {
        CorsLayer::permissive() // Fallback for dev
    } else {
        CorsLayer::new()
            .allow_origin(allowed_origins)
            .allow_methods([Method::GET, Method::POST])
            .allow_headers([CONTENT_TYPE])
    };

    // Prometheus Metrics
    let (prom_layer, metric_handle) = PrometheusMetricLayer::pair();

    // Rate Limiting - 200 req/s per IP
    let governor_conf = GovernorConfigBuilder::default()
        .per_millisecond(200)
        .burst_size(400)
        .finish()
        .unwrap();
    let governor = GovernorLayer {
        config: std::sync::Arc::new(governor_conf),
    };

    // Security Headers - HSTS
    let hsts_layer = SetResponseHeaderLayer::if_not_present(
        STRICT_TRANSPORT_SECURITY,
        HeaderValue::from_static("max-age=31536000; includeSubDomains")
    );

    let app = Router::new()
        // API endpoints
        .route("/ingest", post(routes::ingest))
        .route("/query",  post(routes::query))
        // Health endpoints
        .route("/healthz", get(healthz))
        .route("/readyz",  get(readyz))
        .route("/version", get(|| async { VERSION }))
        // Metrics endpoint
        .route("/metrics", get(|| async move { metric_handle.render() }))
        // Apply middleware in correct order
        .layer(TraceLayer::new_for_http())
        .layer(cors)
        .layer(CompressionLayer::new())
        .layer(TimeoutLayer::new(Duration::from_secs(30)))
        .layer(hsts_layer)
        .layer(prom_layer)
        .layer(governor)
        .with_state(state);

    let port: u16 = env::var("RAG_PORT").ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(8083);

    let addr: SocketAddr = ([0, 0, 0, 0], port).into();
    let listener = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!("RAG listening on http://{addr}");

    // Graceful shutdown signal
    let shutdown_signal = async {
        #[cfg(unix)]
        {
            use tokio::signal::unix::{signal, SignalKind};
            let mut sigterm = signal(SignalKind::terminate()).expect("sigterm");
            let mut sigint  = signal(SignalKind::interrupt()).expect("sigint");
            tokio::select! {
                _ = sigterm.recv() => {},
                _ = sigint.recv()  => {},
            }
        }
        #[cfg(not(unix))]
        {
            let _ = tokio::signal::ctrl_c().await;
        }
        tracing::info!("shutdown signal received, draining connections...");
    };

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal)
        .await?;

    tracing::info!("server stopped");
    Ok(())
}

async fn healthz() -> &'static str {
    "ok"
}

async fn readyz(State(_state): State<AppState>) -> impl IntoResponse {
    // For in-memory storage, we're always ready
    // In production with real DB/Vector store, check actual connections here
    (StatusCode::OK, "ready")
}
