use axum::{Json, extract::State};

use crate::{AppState, pipeline};

use super::models::*;

pub async fn ingest(
    State(state): State<AppState>,
    Json(req): Json<IngestRequest>,
) -> Json<IngestResponse> {
    let id = if let Some(id) = req.id {
        pipeline::ingest::ingest_with_id(&state, id, req.text, req.metadata).await;
        id
    } else {
        pipeline::ingest::ingest(&state, req.text, req.metadata).await
    };
    Json(IngestResponse { id })
}

pub async fn query(
    State(state): State<AppState>,
    Json(req): Json<QueryRequest>,
) -> Json<QueryResponse> {
    let contexts = pipeline::retrieve::retrieve_topk(&state, &req.query, req.top_k).await;
    let answer = if req.generate {
        Some(pipeline::generate::answer(&state, &req.query, &contexts).await)
    } else {
        None
    };
    Json(QueryResponse { contexts, answer })
}
