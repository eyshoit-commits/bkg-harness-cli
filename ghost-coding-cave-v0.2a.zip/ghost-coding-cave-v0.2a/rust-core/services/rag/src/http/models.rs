use serde::{Serialize, Deserialize};
use serde_json::Value;
use uuid::Uuid;

#[derive(Deserialize)]
pub struct IngestRequest {
    pub text: String,
    #[serde(default)]
    pub metadata: Value,
    #[serde(default)]
    pub id: Option<Uuid>,
}

#[derive(Serialize)]
pub struct IngestResponse {
    pub id: Uuid,
}

#[derive(Deserialize)]
pub struct QueryRequest {
    pub query: String,
    #[serde(default = "default_top_k")]
    pub top_k: usize,
    #[serde(default)]
    pub generate: bool,
}

fn default_top_k() -> usize { 3 }

#[derive(Serialize)]
pub struct QueryResponse {
    pub contexts: Vec<String>,
    pub answer: Option<String>,
}
