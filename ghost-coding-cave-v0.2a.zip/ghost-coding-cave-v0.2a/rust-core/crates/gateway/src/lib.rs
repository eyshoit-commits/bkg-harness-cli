mod agents;

use std::{
    net::SocketAddr,
    path::{Path, PathBuf},
    time::Duration,
};

use anyhow::{Context, Result};
use axum::{
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        Path as AxumPath, Query, State,
    },
    http::{header, HeaderMap, HeaderValue, StatusCode},
    response::{IntoResponse, Response},
    routing::{delete, get, post},
    Json, Router,
};
use base64::{engine::general_purpose, Engine as _};
use bytes::Bytes;
use chrono::Utc;
use dotenvy::dotenv;
use futures::{SinkExt, StreamExt};
use reqwest::Client;
use semantic_adapter::{Reference, SemanticAdapter, SemanticRequest, SemanticSummary, Symbol};
use serde::{de::DeserializeOwned, Deserialize, Serialize};
use serde_json::{json, Value};
use storage_adapter::{
    EmbeddingRecord, EmbeddingSearchResult, FileRecord, FileSummary, StorageAdapter,
};
use tokio::signal;
use tower::limit::ConcurrencyLimitLayer;
use tower_http::trace::TraceLayer;
use tracing::{error, info, warn};

#[derive(Clone)]
pub struct AiClient {
    client: Client,
    base_url: String,
}

#[derive(Clone)]
pub struct AppState {
    pub service_name: &'static str,
    pub version: &'static str,
    pub storage: StorageAdapter,
    pub semantic: SemanticAdapter,
    pub ai: AiClient,
    pub api_key: Option<String>,
}

#[derive(Clone)]
pub struct AppConfig {
    pub host: String,
    pub port: u16,
    pub storage_dir: PathBuf,
    pub ai_base_url: String,
    pub ai_timeout: Duration,
    pub api_key: Option<String>,
    pub ai_max_concurrency: usize,
}

impl AppConfig {
    pub fn from_env() -> Result<Self> {
        let host = std::env::var("GHOST_GATEWAY_HOST").unwrap_or_else(|_| "0.0.0.0".into());
        let port = match std::env::var("GHOST_GATEWAY_PORT") {
            Ok(value) => value
                .parse::<u16>()
                .context("invalid GHOST_GATEWAY_PORT value")?,
            Err(_) => 8080,
        };
        let storage_dir =
            std::env::var("GHOST_STORAGE_DIR").unwrap_or_else(|_| ".ghost-storage".into());
        let ai_base_url =
            std::env::var("AI_SERVER_URL").unwrap_or_else(|_| "http://127.0.0.1:5001".into());
        let ai_timeout_secs = std::env::var("AI_SERVER_TIMEOUT_SECS")
            .ok()
            .and_then(|value| value.parse::<u64>().ok())
            .unwrap_or(30);
        let api_key = std::env::var("GHOST_GATEWAY_API_KEY")
            .ok()
            .map(|value| value.trim().to_string())
            .filter(|value| !value.is_empty());
        let ai_max_concurrency = std::env::var("GHOST_GATEWAY_MAX_CONCURRENCY")
            .or_else(|_| std::env::var("GHOST_GATEWAY_RATE_LIMIT"))
            .ok()
            .and_then(|value| value.parse::<usize>().ok())
            .map(|value| value.max(1))
            .unwrap_or(32);
        Ok(Self {
            host,
            port,
            storage_dir: PathBuf::from(storage_dir),
            ai_base_url,
            ai_timeout: Duration::from_secs(ai_timeout_secs),
            api_key,
            ai_max_concurrency,
        })
    }

    pub fn storage_dir(&self) -> &Path {
        &self.storage_dir
    }

    pub fn socket_addr(&self) -> SocketAddr {
        SocketAddr::new(
            self.host
                .parse()
                .unwrap_or_else(|_| "0.0.0.0".parse().expect("valid default host")),
            self.port,
        )
    }
}

impl AppState {
    fn require_api_key(&self, headers: &HeaderMap) -> AppResult<()> {
        ensure_api_key(self.api_key.as_deref(), headers)
    }
}

#[derive(Serialize)]
pub struct HealthResponse {
    service: &'static str,
    version: &'static str,
    status: &'static str,
}

pub async fn health(State(state): State<AppState>) -> Json<HealthResponse> {
    Json(HealthResponse {
        service: state.service_name,
        version: state.version,
        status: "ok",
    })
}

#[derive(Deserialize)]
pub struct ListFilesQuery {
    prefix: Option<String>,
}

#[derive(Serialize)]
pub struct ListFilesResponse {
    files: Vec<FileSummary>,
}

#[derive(Deserialize)]
pub struct FilePathQuery {
    path: String,
}

#[derive(Deserialize)]
pub struct FileWriteRequest {
    path: String,
    content: String,
}

#[derive(Serialize)]
pub struct FileWriteResponse {
    file: FileRecord,
}

#[derive(Deserialize)]
pub struct EmbeddingUpsertRequest {
    vector: Vec<f32>,
    #[serde(default)]
    metadata: Value,
}

#[derive(Deserialize)]
pub struct EmbeddingSearchRequest {
    vector: Vec<f32>,
    #[serde(default = "default_top_k")]
    top_k: usize,
}

#[derive(Serialize)]
pub struct EmbeddingUpsertResponse {
    embedding: EmbeddingRecord,
}

#[derive(Serialize)]
pub struct EmbeddingSearchResponse {
    results: Vec<EmbeddingSearchResult>,
}

pub async fn list_files(
    State(state): State<AppState>,
    Query(query): Query<ListFilesQuery>,
) -> AppResult<Json<ListFilesResponse>> {
    let files = state
        .storage
        .list_files(query.prefix.as_deref())
        .await
        .map_err(AppError::internal)?;
    Ok(Json(ListFilesResponse { files }))
}

pub async fn get_file(
    State(state): State<AppState>,
    Query(query): Query<FilePathQuery>,
) -> AppResult<Json<FileRecord>> {
    let path = normalize_path(&query.path)?;
    match state
        .storage
        .get_file(&path)
        .await
        .map_err(AppError::internal)?
    {
        Some(file) => Ok(Json(file)),
        None => Err(AppError::not_found(format!("file not found: {}", path))),
    }
}

pub async fn put_file(
    State(state): State<AppState>,
    Json(payload): Json<FileWriteRequest>,
) -> AppResult<Json<FileWriteResponse>> {
    let path = normalize_path(&payload.path)?;
    let file = state
        .storage
        .upsert_file(&path, &payload.content)
        .await
        .map_err(AppError::internal)?;
    Ok(Json(FileWriteResponse { file }))
}

pub async fn delete_file(
    State(state): State<AppState>,
    Query(query): Query<FilePathQuery>,
) -> AppResult<Response> {
    let path = normalize_path(&query.path)?;
    if state
        .storage
        .delete_file(&path)
        .await
        .map_err(AppError::internal)?
    {
        Ok(StatusCode::NO_CONTENT.into_response())
    } else {
        Err(AppError::not_found(format!("file not found: {}", path)))
    }
}

#[derive(Deserialize)]
pub struct FileRenameRequest {
    from: String,
    to: String,
}

pub async fn rename_file(
    State(state): State<AppState>,
    Json(payload): Json<FileRenameRequest>,
) -> AppResult<Json<FileWriteResponse>> {
    let from = normalize_path(&payload.from)?;
    let to = normalize_path(&payload.to)?;
    let record = state
        .storage
        .rename_file(&from, &to)
        .await
        .map_err(AppError::internal)?
        .ok_or_else(|| AppError::not_found(format!("file not found: {}", from)))?;
    Ok(Json(FileWriteResponse { file: record }))
}

pub async fn upsert_embedding(
    State(state): State<AppState>,
    Json(payload): Json<EmbeddingUpsertRequest>,
) -> AppResult<Json<EmbeddingUpsertResponse>> {
    if payload.vector.is_empty() {
        return Err(AppError::bad_request("vector must not be empty"));
    }
    let embedding = state
        .storage
        .upsert_embedding(payload.vector, payload.metadata)
        .await
        .map_err(AppError::internal)?;
    Ok(Json(EmbeddingUpsertResponse { embedding }))
}

pub async fn search_embeddings(
    State(state): State<AppState>,
    Json(payload): Json<EmbeddingSearchRequest>,
) -> AppResult<Json<EmbeddingSearchResponse>> {
    if payload.vector.is_empty() {
        return Err(AppError::bad_request("vector must not be empty"));
    }
    let top_k = payload.top_k.clamp(1, 32);
    let results = state
        .storage
        .search_embeddings(&payload.vector, top_k)
        .await
        .map_err(AppError::internal)?;
    Ok(Json(EmbeddingSearchResponse { results }))
}

pub async fn analyze_code(
    State(state): State<AppState>,
    Json(payload): Json<SemanticRequest>,
) -> AppResult<Json<SemanticSummary>> {
    if payload.content.trim().is_empty() {
        return Err(AppError::bad_request("content must not be empty"));
    }
    let summary = state
        .semantic
        .analyze_full(payload)
        .await
        .map_err(AppError::internal)?;
    Ok(Json(summary))
}

#[derive(Deserialize)]
pub struct SymbolsQuery {
    pub language: String,
    pub path: Option<String>,
    pub content: Option<String>,
}

#[derive(Serialize)]
pub struct SymbolsResponse {
    pub symbols: Vec<Symbol>,
}

pub async fn get_symbols(
    State(state): State<AppState>,
    Query(query): Query<SymbolsQuery>,
) -> AppResult<Json<SymbolsResponse>> {
    let content = if let Some(path) = &query.path {
        let normalized = normalize_path(path)?;
        state
            .storage
            .get_file(&normalized)
            .await
            .map_err(AppError::internal)?
            .map(|f| f.content)
            .unwrap_or_default()
    } else {
        query.content.unwrap_or_default()
    };

    if content.trim().is_empty() {
        return Err(AppError::bad_request("content or path required"));
    }

    let symbols = state
        .semantic
        .symbols(&query.language, &content)
        .map_err(AppError::internal)?;

    Ok(Json(SymbolsResponse { symbols }))
}

#[derive(Deserialize)]
pub struct ReferencesQuery {
    pub symbol_name: String,
    pub path: Option<String>,
    pub content: Option<String>,
}

#[derive(Serialize)]
pub struct ReferencesResponse {
    pub references: Vec<Reference>,
}

pub async fn get_references(
    State(state): State<AppState>,
    Query(query): Query<ReferencesQuery>,
) -> AppResult<Json<ReferencesResponse>> {
    let content = if let Some(path) = &query.path {
        let normalized = normalize_path(path)?;
        state
            .storage
            .get_file(&normalized)
            .await
            .map_err(AppError::internal)?
            .map(|f| f.content)
            .unwrap_or_default()
    } else {
        query.content.unwrap_or_default()
    };

    if content.trim().is_empty() {
        return Err(AppError::bad_request("content or path required"));
    }

    let references = state
        .semantic
        .references(&query.symbol_name, &content)
        .map_err(AppError::internal)?;

    Ok(Json(ReferencesResponse { references }))
}

pub async fn analyze_full(
    State(state): State<AppState>,
    Json(payload): Json<SemanticRequest>,
) -> AppResult<Json<SemanticSummary>> {
    if payload.content.trim().is_empty() {
        return Err(AppError::bad_request("content must not be empty"));
    }
    let summary = state
        .semantic
        .analyze_full(payload)
        .await
        .map_err(AppError::internal)?;
    Ok(Json(summary))
}

pub async fn semantic_stream_ws(State(state): State<AppState>, ws: WebSocketUpgrade) -> Response {
    ws.on_upgrade(move |socket| handle_semantic_stream_ws(state, socket))
}

async fn handle_semantic_stream_ws(state: AppState, socket: WebSocket) {
    let (mut sender, mut receiver) = socket.split();

    // Send initial ready event
    if sender
        .send(Message::Text(
            json!({
                "event": "connected",
                "service": state.service_name,
                "version": state.version,
            })
            .to_string(),
        ))
        .await
        .is_err()
    {
        return;
    }

    // Simulate periodic health updates
    let mut interval = tokio::time::interval(std::time::Duration::from_secs(5));
    let mut event_id = 0;

    loop {
        tokio::select! {
            _ = interval.tick() => {
                event_id += 1;
                let health_data = json!({
                    "timestamp": Utc::now().to_rfc3339(),
                    "status": "operational"
                });

                if sender
                    .send(Message::Text(
                        json!({
                            "event": "health_update",
                            "id": event_id,
                            "data": health_data,
                        })
                        .to_string(),
                    ))
                    .await
                    .is_err()
                {
                    break;
                }
            }
            Some(msg) = receiver.next() => {
                match msg {
                    Ok(Message::Text(raw)) => {
                        // Handle incoming requests for on-demand events, e.g., trigger analysis
                        if let Ok(request) = serde_json::from_str::<SemanticRequest>(&raw) {
                            if let Ok(summary) = state.semantic.analyze_full(request).await {
                                let _ = sender
                                    .send(Message::Text(
                                        json!({
                                            "event": "analysis_stream",
                                            "summary": summary,
                                        })
                                        .to_string(),
                                    ))
                                    .await;
                            }
                        }
                    }
                    Ok(Message::Ping(payload)) => {
                        let _ = sender.send(Message::Pong(payload)).await;
                    }
                    Ok(Message::Binary(_)) => {}
                    Ok(Message::Pong(_)) => {}
                    Ok(Message::Close(_)) => break,
                    Err(_) => break,
                }
            }
            else => break,
        }
    }
}

fn normalize_path(raw: &str) -> AppResult<String> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err(AppError::bad_request("path must not be empty"));
    }
    if trimmed.contains("..") {
        return Err(AppError::bad_request("path traversal is not allowed"));
    }
    Ok(trimmed.replace('\\', "/"))
}

fn default_top_k() -> usize {
    5
}

#[derive(Deserialize, Serialize)]
pub struct AiChatRequest {
    prompt: String,
    #[serde(default)]
    model: Option<String>,
}

#[derive(Deserialize, Serialize)]
pub struct AiChatResponse {
    response: String,
    model: String,
}

#[derive(Deserialize, Serialize)]
pub struct AiTtsRequest {
    text: String,
    #[serde(default)]
    model: Option<String>,
}

#[derive(Deserialize, Serialize)]
pub struct AiTtsResponse {
    audio_base64: String,
    sample_rate_hz: u32,
    model: String,
    #[serde(default)]
    mime_type: Option<String>,
}

#[derive(Deserialize, Serialize)]
pub struct AiImageRequest {
    prompt: String,
    #[serde(default)]
    model: Option<String>,
}

#[derive(Deserialize, Serialize)]
pub struct AiImageResponse {
    image_base64: String,
    #[serde(default)]
    mime_type: Option<String>,
    model: String,
}

#[derive(Deserialize, Serialize)]
pub struct AiVideoRequest {
    prompt: String,
    #[serde(default)]
    model: Option<String>,
}

#[derive(Deserialize, Serialize)]
pub struct AiVideoResponse {
    video_base64: String,
    #[serde(default)]
    mime_type: Option<String>,
    model: String,
}

impl AiTtsResponse {
    fn into_binary(self) -> AppResult<BinaryBody> {
        let bytes = decode_base64_payload(&self.audio_base64)?;
        let content_type = content_type_or_default(self.mime_type.as_deref(), "audio/wav");
        let mut body = BinaryBody::new(bytes, content_type);
        if let Ok(value) = HeaderValue::from_str(&self.sample_rate_hz.to_string()) {
            body = body.with_header(
                header::HeaderName::from_static("x-audio-sample-rate"),
                value,
            );
        }
        if let Ok(value) = HeaderValue::from_str(self.model.as_str()) {
            body = body.with_header(header::HeaderName::from_static("x-model-name"), value);
        }
        Ok(body)
    }
}

impl AiImageResponse {
    fn into_binary(self) -> AppResult<BinaryBody> {
        let bytes = decode_base64_payload(&self.image_base64)?;
        let content_type = content_type_or_default(self.mime_type.as_deref(), "image/png");
        let mut body = BinaryBody::new(bytes, content_type);
        if let Ok(value) = HeaderValue::from_str(self.model.as_str()) {
            body = body.with_header(header::HeaderName::from_static("x-model-name"), value);
        }
        Ok(body)
    }
}

impl AiVideoResponse {
    fn into_binary(self) -> AppResult<BinaryBody> {
        let bytes = decode_base64_payload(&self.video_base64)?;
        let content_type = content_type_or_default(self.mime_type.as_deref(), "video/mp4");
        let mut body = BinaryBody::new(bytes, content_type);
        if let Ok(value) = HeaderValue::from_str(self.model.as_str()) {
            body = body.with_header(header::HeaderName::from_static("x-model-name"), value);
        }
        Ok(body)
    }
}

#[derive(Deserialize, Serialize)]
pub struct AiTrainRequest {
    model: String,
    dataset_uri: String,
    #[serde(default)]
    epochs: Option<u32>,
}

#[derive(Deserialize, Serialize)]
pub struct AiTrainResponse {
    job_id: String,
    message: String,
}

#[derive(Serialize, Deserialize)]
pub struct CreateModelRequest {
    name: String,
    modality: String,
    #[serde(default)]
    description: Option<String>,
}

#[derive(Serialize, Deserialize)]
pub struct CreateModelResponse {
    id: String,
    name: String,
    modality: String,
    description: String,
}

#[derive(Serialize, Deserialize)]
pub struct DeleteModelResponse {
    removed: String,
}

#[derive(Serialize, Deserialize)]
pub struct ModelMetadata {
    id: String,
    name: String,
    modality: ModelModality,
    description: String,
}

#[derive(Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModelModality {
    Llm,
    Tts,
    Image,
    Video,
}

pub async fn ai_chat_completion(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<AiChatRequest>,
) -> AppResult<Json<AiChatResponse>> {
    state.require_api_key(&headers)?;
    let response = state
        .ai
        .post_json("/api/chat/completions", &payload)
        .await?;
    Ok(Json(response))
}

pub async fn ai_tts_synthesize(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<AiTtsRequest>,
) -> AppResult<Response> {
    state.require_api_key(&headers)?;
    let body = state
        .ai
        .post_media("/api/tts/synthesize", &payload, AiTtsResponse::into_binary)
        .await?;
    Ok(body.into_response())
}

pub async fn ai_generate_image(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<AiImageRequest>,
) -> AppResult<Response> {
    state.require_api_key(&headers)?;
    let body = state
        .ai
        .post_media(
            "/api/images/generate",
            &payload,
            AiImageResponse::into_binary,
        )
        .await?;
    Ok(body.into_response())
}

pub async fn ai_generate_video(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<AiVideoRequest>,
) -> AppResult<Response> {
    state.require_api_key(&headers)?;
    let body = state
        .ai
        .post_media(
            "/api/videos/generate",
            &payload,
            AiVideoResponse::into_binary,
        )
        .await?;
    Ok(body.into_response())
}

pub async fn ai_train_lora(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<AiTrainRequest>,
) -> AppResult<Json<AiTrainResponse>> {
    state.require_api_key(&headers)?;
    let response = state.ai.post_json("/api/train/lora", &payload).await?;
    Ok(Json(response))
}

pub async fn ai_list_models(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> AppResult<Json<Vec<ModelMetadata>>> {
    state.require_api_key(&headers)?;
    let response = state.ai.get_json("/api/models").await?;
    Ok(Json(response))
}

pub async fn ai_create_model(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(payload): Json<CreateModelRequest>,
) -> AppResult<Json<CreateModelResponse>> {
    state.require_api_key(&headers)?;
    if payload.name.trim().is_empty() {
        return Err(AppError::bad_request("name must not be empty"));
    }
    if payload.modality.trim().is_empty() {
        return Err(AppError::bad_request("modality must not be empty"));
    }

    let model = state
        .ai
        .post_json::<CreateModelResponse, _>("/api/models", &payload)
        .await?;
    Ok(Json(model))
}

pub async fn ai_delete_model(
    State(state): State<AppState>,
    headers: HeaderMap,
    AxumPath(name): AxumPath<String>,
) -> AppResult<Json<DeleteModelResponse>> {
    state.require_api_key(&headers)?;
    let response = state
        .ai
        .delete_json(&format!("/api/models/{}", name))
        .await?;
    Ok(Json(response))
}

pub type AppResult<T> = Result<T, AppError>;

pub struct BinaryBody {
    bytes: Bytes,
    content_type: Option<HeaderValue>,
    extra_headers: Vec<(header::HeaderName, HeaderValue)>,
}

impl BinaryBody {
    fn new(bytes: Bytes, content_type: Option<HeaderValue>) -> Self {
        Self {
            bytes,
            content_type,
            extra_headers: Vec::new(),
        }
    }

    fn with_header(mut self, name: header::HeaderName, value: HeaderValue) -> Self {
        self.extra_headers.push((name, value));
        self
    }
}

impl IntoResponse for BinaryBody {
    fn into_response(self) -> Response {
        let mut response = Response::new(self.bytes.into());
        if let Some(content_type) = self.content_type {
            response
                .headers_mut()
                .insert(header::CONTENT_TYPE, content_type);
        }
        for (name, value) in self.extra_headers {
            response.headers_mut().insert(name, value);
        }
        response
    }
}

fn parse_error_message(bytes: &[u8]) -> Option<String> {
    if bytes.is_empty() {
        return None;
    }
    if let Ok(value) = serde_json::from_slice::<serde_json::Value>(bytes) {
        if let Some(message) = value.get("error").and_then(|v| v.as_str()) {
            return Some(message.to_string());
        }
        if let Some(message) = value.get("message").and_then(|v| v.as_str()) {
            return Some(message.to_string());
        }
        if let Some(as_str) = value.as_str() {
            return Some(as_str.to_string());
        }
    }
    let fallback = String::from_utf8_lossy(bytes).trim().to_owned();
    if fallback.is_empty() {
        None
    } else {
        Some(fallback)
    }
}

fn map_upstream_status(status: StatusCode) -> StatusCode {
    if status.is_client_error() {
        status
    } else if status.is_server_error() {
        StatusCode::BAD_GATEWAY
    } else {
        StatusCode::INTERNAL_SERVER_ERROR
    }
}

fn header_value_from_str(value: &str) -> Option<HeaderValue> {
    HeaderValue::from_str(value).ok()
}

fn content_type_or_default(provided: Option<&str>, default: &str) -> Option<HeaderValue> {
    provided
        .and_then(header_value_from_str)
        .or_else(|| header_value_from_str(default))
}

fn decode_base64_payload(data: &str) -> AppResult<Bytes> {
    let decoded = general_purpose::STANDARD
        .decode(data)
        .map_err(|err| AppError::bad_request(format!("invalid base64 payload: {}", err)))?;
    Ok(Bytes::from(decoded))
}

fn ensure_api_key(expected: Option<&str>, headers: &HeaderMap) -> AppResult<()> {
    if let Some(expected) = expected {
        let header_match = headers
            .get("x-api-key")
            .and_then(|value| value.to_str().ok())
            .map(|value| value == expected)
            .unwrap_or(false);
        let bearer_match = headers
            .get(header::AUTHORIZATION)
            .and_then(|value| value.to_str().ok())
            .and_then(|value| value.strip_prefix("Bearer "))
            .map(|token| token == expected)
            .unwrap_or(false);
        if header_match || bearer_match {
            return Ok(());
        }
        return Err(AppError::unauthorized("missing or invalid api key"));
    }
    Ok(())
}

#[derive(Debug)]
pub struct AppError {
    status: StatusCode,
    message: String,
    source: Option<anyhow::Error>,
}

impl AppError {
    pub fn new(status: StatusCode, message: impl Into<String>) -> Self {
        Self {
            status,
            message: message.into(),
            source: None,
        }
    }

    pub fn with_source(status: StatusCode, err: anyhow::Error) -> Self {
        Self {
            status,
            message: err.to_string(),
            source: Some(err),
        }
    }

    pub fn status(&self) -> StatusCode {
        self.status
    }

    pub fn message(&self) -> &str {
        &self.message
    }

    pub fn bad_request(msg: impl Into<String>) -> Self {
        Self::new(StatusCode::BAD_REQUEST, msg)
    }

    pub fn unauthorized(msg: impl Into<String>) -> Self {
        Self::new(StatusCode::UNAUTHORIZED, msg)
    }

    pub fn not_found(msg: impl Into<String>) -> Self {
        Self::new(StatusCode::NOT_FOUND, msg)
    }

    pub fn too_many_requests(msg: impl Into<String>) -> Self {
        Self::new(StatusCode::TOO_MANY_REQUESTS, msg)
    }

    pub fn bad_gateway(msg: impl Into<String>) -> Self {
        Self::new(StatusCode::BAD_GATEWAY, msg)
    }

    pub fn internal(err: anyhow::Error) -> Self {
        Self::with_source(StatusCode::INTERNAL_SERVER_ERROR, err)
    }
}

impl AiClient {
    pub fn new(base_url: &str, timeout: Duration) -> Result<Self> {
        let client = Client::builder()
            .timeout(timeout)
            .build()
            .context("failed to build ai-server client")?;
        Ok(Self {
            client,
            base_url: base_url.trim_end_matches('/').to_string(),
        })
    }

    pub async fn get_json<T>(&self, path: &str) -> AppResult<T>
    where
        T: DeserializeOwned,
    {
        let response = self
            .client
            .get(self.build_url(path))
            .send()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        self.handle_json_response(response).await
    }

    pub async fn post_json<T, S>(&self, path: &str, payload: &S) -> AppResult<T>
    where
        T: DeserializeOwned,
        S: Serialize + ?Sized,
    {
        let response = self
            .client
            .post(self.build_url(path))
            .json(payload)
            .send()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        self.handle_json_response(response).await
    }

    pub async fn delete_json<T>(&self, path: &str) -> AppResult<T>
    where
        T: DeserializeOwned,
    {
        let response = self
            .client
            .delete(self.build_url(path))
            .send()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        self.handle_json_response(response).await
    }

    pub async fn post_media<S, T, F>(
        &self,
        path: &str,
        payload: &S,
        transform: F,
    ) -> AppResult<BinaryBody>
    where
        S: Serialize + ?Sized,
        T: DeserializeOwned,
        F: FnOnce(T) -> AppResult<BinaryBody>,
    {
        let response = self
            .client
            .post(self.build_url(path))
            .json(payload)
            .send()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        self.handle_media_response::<T, F>(response, transform)
            .await
    }

    fn build_url(&self, path: &str) -> String {
        let trimmed = path.trim_start_matches('/');
        format!("{}/{}", self.base_url, trimmed)
    }

    async fn handle_json_response<T>(&self, response: reqwest::Response) -> AppResult<T>
    where
        T: DeserializeOwned,
    {
        let status = response.status();
        let status_code =
            StatusCode::from_u16(status.as_u16()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
        let body = response
            .bytes()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        if !status.is_success() {
            let message = parse_error_message(&body).unwrap_or_else(|| {
                status_code
                    .canonical_reason()
                    .unwrap_or("request to ai-server failed")
                    .to_string()
            });
            return Err(AppError::new(map_upstream_status(status_code), message));
        }
        serde_json::from_slice(&body).map_err(|err| AppError::internal(anyhow::Error::new(err)))
    }

    async fn handle_media_response<T, F>(
        &self,
        response: reqwest::Response,
        transform: F,
    ) -> AppResult<BinaryBody>
    where
        T: DeserializeOwned,
        F: FnOnce(T) -> AppResult<BinaryBody>,
    {
        let status = response.status();
        let status_code =
            StatusCode::from_u16(status.as_u16()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
        let content_type_header = response
            .headers()
            .get(reqwest::header::CONTENT_TYPE)
            .and_then(|value| value.to_str().ok())
            .map(|value| value.to_string());
        let body = response
            .bytes()
            .await
            .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
        if !status.is_success() {
            let message = parse_error_message(&body).unwrap_or_else(|| {
                status_code
                    .canonical_reason()
                    .unwrap_or("request to ai-server failed")
                    .to_string()
            });
            return Err(AppError::new(map_upstream_status(status_code), message));
        }
        let is_json = content_type_header
            .as_deref()
            .map(|value| value.starts_with("application/json"))
            .unwrap_or(false);
        if is_json {
            let payload: T = serde_json::from_slice(&body)
                .map_err(|err| AppError::internal(anyhow::Error::new(err)))?;
            return transform(payload);
        }
        let content_type = content_type_header
            .as_deref()
            .and_then(header_value_from_str);
        Ok(BinaryBody::new(body, content_type))
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        if let Some(source) = &self.source {
            error!(error = ?source, status = ?self.status, "request failed");
        }
        let body = Json(ErrorResponse {
            error: self.message.clone(),
        });
        (self.status, body).into_response()
    }
}

#[derive(Serialize)]
pub struct ErrorResponse {
    error: String,
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::body::to_bytes;
    use axum::http::{HeaderMap, HeaderValue};

    #[test]
    fn ensure_api_key_accepts_header_match() {
        let mut headers = HeaderMap::new();
        headers.insert("x-api-key", HeaderValue::from_static("secret"));
        assert!(ensure_api_key(Some("secret"), &headers).is_ok());
    }

    #[test]
    fn ensure_api_key_rejects_missing_token() {
        let headers = HeaderMap::new();
        let err = ensure_api_key(Some("secret"), &headers).unwrap_err();
        assert_eq!(err.status(), StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn tts_response_into_binary_sets_headers() {
        let audio = vec![0_u8, 1, 2, 3];
        let encoded = general_purpose::STANDARD.encode(&audio);
        let response = AiTtsResponse {
            audio_base64: encoded,
            sample_rate_hz: 16_000,
            model: "ghost-tts".into(),
            mime_type: Some("audio/wav".into()),
        };
        let binary = response.into_binary().expect("convert to binary");
        let resp = binary.into_response();
        let headers = resp.headers().clone();
        let body = to_bytes(resp.into_body(), 64 * 1024)
            .await
            .expect("read body");
        assert_eq!(headers.get(header::CONTENT_TYPE).unwrap(), "audio/wav");
        assert_eq!(
            headers
                .get(header::HeaderName::from_static("x-model-name"))
                .unwrap(),
            "ghost-tts"
        );
        assert_eq!(
            headers
                .get(header::HeaderName::from_static("x-audio-sample-rate"))
                .unwrap(),
            "16000"
        );
        assert_eq!(body.as_ref(), audio.as_slice());
    }
}

pub async fn run() -> Result<()> {
    dotenv().ok();
    init_tracing()?;

    let config = AppConfig::from_env()?;
    let addr = config.socket_addr();

    let storage = StorageAdapter::new(config.storage_dir()).await?;
    let semantic = SemanticAdapter::new();
    let ai = AiClient::new(&config.ai_base_url, config.ai_timeout)?;
    let state = AppState {
        service_name: "ghost-gateway",
        version: env!("CARGO_PKG_VERSION"),
        storage,
        semantic,
        ai,
        api_key: config.api_key.clone(),
    };

    let app = Router::new()
        .route("/health", get(health))
        .route("/api/storage/files", get(list_files))
        .route(
            "/api/storage/file",
            get(get_file).put(put_file).delete(delete_file),
        )
        .route("/api/storage/file/rename", post(rename_file))
        .route("/api/storage/embeddings/index", post(upsert_embedding))
        .route("/api/storage/embeddings/search", post(search_embeddings))
        .route("/api/semantic/analyze", post(analyze_code))
        .route("/api/semantic/analyze/full", post(analyze_full))
        .route("/api/semantic/symbols", get(get_symbols))
        .route("/api/semantic/references", get(get_references))
        .route("/api/semantic/stream", get(semantic_stream_ws))
        .route("/api/ai/chat/completions", post(ai_chat_completion))
        .route("/api/ai/tts/synthesize", post(ai_tts_synthesize))
        .route("/api/ai/images/generate", post(ai_generate_image))
        .route("/api/ai/videos/generate", post(ai_generate_video))
        .route("/api/ai/train/lora", post(ai_train_lora))
        .route("/api/ai/models", get(ai_list_models).post(ai_create_model))
        .route("/api/ai/models/:name", delete(ai_delete_model))
        .route("/api/chat/plan", post(agents::chat_plan))
        .route("/ws/agent", get(agents::agent_ws))
        .with_state(state)
        .layer(TraceLayer::new_for_http())
        .layer(ConcurrencyLimitLayer::new(config.ai_max_concurrency));

    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .with_context(|| format!("failed to bind to {}", addr))?;

    info!("🚀 ghost-gateway listening on http://{}", addr);

    axum::serve(listener, app)
        .with_graceful_shutdown(shutdown_signal())
        .await
        .context("server error")?;

    info!("👋 ghost-gateway shutdown complete");
    Ok(())
}

fn init_tracing() -> Result<()> {
    let env_filter =
        std::env::var("RUST_LOG").unwrap_or_else(|_| "ghost_gateway=info,tower_http=info".into());
    tracing_subscriber::fmt()
        .with_env_filter(env_filter)
        .with_target(false)
        .compact()
        .try_init()
        .map_err(|err| anyhow::anyhow!("failed to initialize tracing subscriber: {err}"))?;
    Ok(())
}

async fn shutdown_signal() {
    let ctrl_c = async {
        signal::ctrl_c()
            .await
            .expect("failed to listen for ctrl_c signal");
    };

    #[cfg(unix)]
    let terminate = async {
        signal::unix::signal(signal::unix::SignalKind::terminate())
            .expect("failed to install signal handler")
            .recv()
            .await;
    };

    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => warn!("received Ctrl+C"),
        _ = terminate => warn!("received termination signal"),
    }

    tokio::time::sleep(Duration::from_millis(100)).await;
}
