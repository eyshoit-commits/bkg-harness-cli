use std::str::FromStr;

use axum::{
    extract::{Path, State},
    http::StatusCode,
    routing::{delete, get},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::{
    core::registry::{ModelMetadata, ModelModality, RegistryError},
    state::AppState,
};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/api/models", get(list_models).post(create_model))
        .route("/api/models/:name", delete(delete_model))
}

#[derive(Deserialize)]
struct CreateModelRequest {
    name: String,
    modality: String,
    #[serde(default)]
    description: Option<String>,
}

#[derive(Serialize, Deserialize)]
struct CreateModelResponse {
    id: Uuid,
    name: String,
    modality: String,
    description: String,
}

#[derive(Serialize, Deserialize)]
struct DeleteModelResponse {
    removed: String,
}

async fn list_models(State(state): State<AppState>) -> Json<Vec<ModelMetadata>> {
    let models = state.registry.list_models().await;
    Json(models)
}

async fn create_model(
    State(state): State<AppState>,
    Json(payload): Json<CreateModelRequest>,
) -> Result<Json<CreateModelResponse>, (StatusCode, Json<serde_json::Value>)> {
    if payload.name.trim().is_empty() {
        return Err(error_payload(
            StatusCode::BAD_REQUEST,
            "name must not be empty",
        ));
    }

    let modality = ModelModality::from_str(&payload.modality)
        .map_err(|m| error_payload(StatusCode::BAD_REQUEST, format!("invalid modality `{}`", m)))?;

    let description = payload
        .description
        .unwrap_or_else(|| "Custom registered model.".into());

    match state
        .registry
        .add_model(payload.name.clone(), modality.clone(), description.clone())
        .await
    {
        Ok(meta) => Ok(Json(CreateModelResponse {
            id: meta.id,
            name: meta.name,
            modality: modality.to_string(),
            description,
        })),
        Err(RegistryError::AlreadyExists(name)) => Err(error_payload(
            StatusCode::CONFLICT,
            format!("model `{}` already exists", name),
        )),
        Err(err) => Err(error_payload(
            StatusCode::INTERNAL_SERVER_ERROR,
            err.to_string(),
        )),
    }
}

async fn delete_model(
    State(state): State<AppState>,
    Path(name): Path<String>,
) -> Result<Json<DeleteModelResponse>, (StatusCode, Json<serde_json::Value>)> {
    match state.registry.remove_model(&name).await {
        Ok(_) => Ok(Json(DeleteModelResponse { removed: name })),
        Err(RegistryError::NotFound(_)) => Err(error_payload(
            StatusCode::NOT_FOUND,
            format!("model `{}` not found", name),
        )),
        Err(err) => Err(error_payload(
            StatusCode::INTERNAL_SERVER_ERROR,
            err.to_string(),
        )),
    }
}

fn error_payload(
    code: StatusCode,
    message: impl Into<String>,
) -> (StatusCode, Json<serde_json::Value>) {
    (code, Json(serde_json::json!({ "error": message.into() })))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::ServerConfig, state::AppState};
    use axum::{
        body::{to_bytes, Body},
        http::{Request, StatusCode},
    };
    use serde_json::Value;
    use tempfile::tempdir;
    use tower::ServiceExt;

    async fn test_state() -> (AppState, tempfile::TempDir) {
        let tmp = tempdir().expect("temp dir");
        let db_path = tmp.path().join("models.json");
        let config = ServerConfig {
            host: "127.0.0.1".into(),
            port: 0,
            helper_db_path: db_path.to_string_lossy().into_owned(),
            helper_mode: "test".into(),
            analysis_threads: 1,
            log_level: "warn".into(),
            semantic_store_http_url: None,
            sync_interval_secs: 60,
        };
        let state = AppState::try_new(&config).await.expect("state");
        (state, tmp)
    }

    #[tokio::test]
    async fn lists_models() {
        let (state, _tmp) = test_state().await;
        let app = router().with_state(state);

        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .uri("/api/models")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), 4096).await.unwrap();
        let json: Value = serde_json::from_slice(&body).unwrap();
        assert!(
            json.as_array().map(|arr| !arr.is_empty()).unwrap_or(false),
            "expected at least one model"
        );
    }

    #[tokio::test]
    async fn creates_and_deletes_model() {
        let (state, _tmp) = test_state().await;
        let app = router().with_state(state.clone());

        let create_payload =
            r#"{ "name": "custom-model", "modality": "llm", "description": "custom" }"#;
        let create_response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/models")
                    .header("content-type", "application/json")
                    .body(Body::from(create_payload))
                    .unwrap(),
            )
            .await
            .unwrap();
        let create_status = create_response.status();
        let create_body = to_bytes(create_response.into_body(), 4096).await.unwrap();
        if create_status != StatusCode::OK {
            panic!(
                "create failed: {} {}",
                create_status,
                String::from_utf8_lossy(&create_body)
            );
        }
        let created: Value = serde_json::from_slice(&create_body).expect("create payload");
        assert_eq!(created["name"], "custom-model");
        assert_eq!(created["modality"], "llm");

        let delete_response = app
            .oneshot(
                Request::builder()
                    .method("DELETE")
                    .uri("/api/models/custom-model")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = delete_response.status();
        let body = to_bytes(delete_response.into_body(), 1024).await.unwrap();
        if status != StatusCode::OK {
            panic!(
                "delete failed: {} {}",
                status,
                String::from_utf8_lossy(&body)
            );
        }
        let payload: DeleteModelResponse = serde_json::from_slice(&body).unwrap();
        assert_eq!(payload.removed, "custom-model");
    }
}
