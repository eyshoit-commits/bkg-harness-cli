use axum::{extract::State, routing::post, Json, Router};
use serde::{Deserialize, Serialize};

use crate::{core::llm, state::AppState};

#[derive(Deserialize)]
pub struct ChatRequest {
    pub prompt: String,
    #[serde(default)]
    pub model: Option<String>,
}

#[derive(Serialize)]
pub struct ChatResponse {
    pub response: String,
    pub model: String,
}

pub fn router() -> Router<AppState> {
    Router::new().route("/api/chat/completions", post(handle_chat))
}

async fn handle_chat(
    State(state): State<AppState>,
    Json(payload): Json<ChatRequest>,
) -> Result<Json<ChatResponse>, Json<serde_json::Value>> {
    if payload.prompt.trim().is_empty() {
        return Err(Json(serde_json::json!({
            "error": "prompt must not be empty"
        })));
    }

    let requested = payload.model.as_deref();
    match llm::generate_completion(&state.registry, requested, &payload.prompt).await {
        Ok(text) => Ok(Json(ChatResponse {
            response: text,
            model: requested.unwrap_or("ghost-llm-mini").to_string(),
        })),
        Err(err) => Err(Json(serde_json::json!({
            "error": err.to_string()
        }))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::ServerConfig, state::AppState};
    use axum::{
        body::{to_bytes, Body},
        http::{Request, StatusCode},
    };
    use serde_json::Value;
    use tempfile::tempdir;
    use tower::ServiceExt;

    async fn test_state() -> AppState {
        let tmp = tempdir().expect("temp dir");
        let db_path = tmp.path().join("models.json");
        let config = ServerConfig {
            host: "127.0.0.1".into(),
            port: 0,
            helper_db_path: db_path.to_string_lossy().into_owned(),
            helper_mode: "test".into(),
            analysis_threads: 1,
            log_level: "warn".into(),
            semantic_store_http_url: None,
            sync_interval_secs: 60,
        };
        let state = AppState::try_new(&config).await.expect("state");
        state
    }

    #[tokio::test]
    async fn rejects_empty_prompt() {
        let state = test_state().await;
        let app = router().with_state(state);

        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/chat/completions")
                    .header("content-type", "application/json")
                    .body(Body::from(r#"{ "prompt": "" }"#))
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), 1024).await.unwrap();
        let json: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["error"], "prompt must not be empty");
    }

    #[tokio::test]
    async fn returns_stub_response() {
        let state = test_state().await;
        let app = router().with_state(state);
        let payload = r#"{ "prompt": "hello world" }"#;

        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/chat/completions")
                    .header("content-type", "application/json")
                    .body(Body::from(payload))
                    .unwrap(),
            )
            .await
            .unwrap();

        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), 4096).await.unwrap();
        let json: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(json["model"], "ghost-llm-mini");
        assert!(json["response"]
            .as_str()
            .unwrap()
            .contains("ghost-llm-mini"));
    }
}
