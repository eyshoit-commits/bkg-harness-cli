use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use thiserror::Error;
use tokio::fs;
use tokio::sync::RwLock;
use uuid::Uuid;

#[derive(Debug, Error)]
pub enum RegistryError {
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("model `{0}` not found")]
    NotFound(String),
    #[error("model `{0}` already exists")]
    AlreadyExists(String),
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ModelMetadata {
    pub id: Uuid,
    pub name: String,
    pub modality: ModelModality,
    pub description: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ModelModality {
    Llm,
    Tts,
    Image,
    Video,
}

impl std::fmt::Display for ModelModality {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let value = match self {
            ModelModality::Llm => "llm",
            ModelModality::Tts => "tts",
            ModelModality::Image => "image",
            ModelModality::Video => "video",
        };
        f.write_str(value)
    }
}

impl std::str::FromStr for ModelModality {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "llm" => Ok(ModelModality::Llm),
            "tts" => Ok(ModelModality::Tts),
            "image" => Ok(ModelModality::Image),
            "video" => Ok(ModelModality::Video),
            other => Err(other.to_string()),
        }
    }
}

#[derive(Clone)]
pub struct ModelRegistry {
    store_path: Arc<PathBuf>,
    models: ArcRegistry,
}

type ArcRegistry = Arc<RwLock<HashMap<String, ModelMetadata>>>;

impl ModelRegistry {
    pub async fn load_from_path(path: &str) -> Result<Self, RegistryError> {
        let path_buf = PathBuf::from(path);
        ensure_parent_directory(&path_buf).await?;

        let registry = Self {
            store_path: Arc::new(path_buf),
            models: new_registry_store(),
        };
        registry.load_models_from_disk().await?;
        registry.seed_defaults().await?;
        Ok(registry)
    }

    pub async fn get_model(&self, name: &str) -> Result<ModelMetadata, RegistryError> {
        let models = self.models.read().await;
        models
            .get(name)
            .cloned()
            .ok_or_else(|| RegistryError::NotFound(name.to_string()))
    }

    pub async fn list_models(&self) -> Vec<ModelMetadata> {
        let models = self.models.read().await;
        models.values().cloned().collect()
    }

    pub async fn add_model(
        &self,
        name: String,
        modality: ModelModality,
        description: String,
    ) -> Result<ModelMetadata, RegistryError> {
        let mut models = self.models.write().await;
        if models.contains_key(&name) {
            return Err(RegistryError::AlreadyExists(name));
        }

        let metadata = ModelMetadata {
            id: Uuid::new_v4(),
            name: name.clone(),
            modality,
            description,
        };
        models.insert(name, metadata.clone());
        drop(models);
        self.persist().await?;
        Ok(metadata)
    }

    pub async fn remove_model(&self, name: &str) -> Result<ModelMetadata, RegistryError> {
        let mut models = self.models.write().await;
        let removed = models
            .remove(name)
            .ok_or_else(|| RegistryError::NotFound(name.to_string()))?;
        drop(models);
        self.persist().await?;
        Ok(removed)
    }

    async fn load_models_from_disk(&self) -> Result<(), RegistryError> {
        if !self.store_path.exists() {
            fs::write(&*self.store_path, b"[]").await?;
            return Ok(());
        }

        let bytes = fs::read(&*self.store_path).await?;
        if bytes.iter().all(|b| b.is_ascii_whitespace()) {
            return Ok(());
        }

        let parsed: Vec<ModelMetadata> = serde_json::from_slice(&bytes)?;
        let mut models = self.models.write().await;
        for meta in parsed {
            models.insert(meta.name.clone(), meta);
        }
        Ok(())
    }

    async fn seed_defaults(&self) -> Result<(), RegistryError> {
        let mut models = self.models.write().await;
        if !models.is_empty() {
            return Ok(());
        }

        let defaults = vec![
            ModelMetadata {
                id: Uuid::new_v4(),
                name: "ghost-llm-mini".into(),
                modality: ModelModality::Llm,
                description: "Placeholder conversational model.".into(),
            },
            ModelMetadata {
                id: Uuid::new_v4(),
                name: "ghost-tts-lite".into(),
                modality: ModelModality::Tts,
                description: "Placeholder text-to-speech voice.".into(),
            },
            ModelMetadata {
                id: Uuid::new_v4(),
                name: "ghost-diffusion".into(),
                modality: ModelModality::Image,
                description: "Placeholder text-to-image diffusion model.".into(),
            },
            ModelMetadata {
                id: Uuid::new_v4(),
                name: "ghost-video-diffusion".into(),
                modality: ModelModality::Video,
                description: "Placeholder text-to-video diffusion model.".into(),
            },
        ];

        for model in defaults {
            models.insert(model.name.clone(), model);
        }

        drop(models);
        self.persist().await?;
        Ok(())
    }

    async fn persist(&self) -> Result<(), RegistryError> {
        let models = self.models.read().await;
        let as_vec: Vec<_> = models.values().cloned().collect();
        let json = serde_json::to_vec_pretty(&as_vec)?;
        fs::write(&*self.store_path, json).await?;
        Ok(())
    }
}

fn new_registry_store() -> ArcRegistry {
    Arc::new(RwLock::new(HashMap::new()))
}

async fn ensure_parent_directory(path: &Path) -> Result<(), RegistryError> {
    if let Some(parent) = path.parent() {
        if !parent.exists() {
            fs::create_dir_all(parent).await?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[tokio::test]
    async fn registry_creates_defaults_when_missing() {
        let dir = tempdir().unwrap();
        let db_path = dir.path().join("models.json");
        let registry = ModelRegistry::load_from_path(db_path.to_str().unwrap())
            .await
            .expect("registry");
        let models = registry.list_models().await;
        assert!(
            models.len() >= 4,
            "expected seeded models, got {:?}",
            models
        );
    }

    #[tokio::test]
    async fn registry_persists_and_loads_models() {
        let dir = tempdir().unwrap();
        let db_path = dir.path().join("models.json");
        {
            let registry = ModelRegistry::load_from_path(db_path.to_str().unwrap())
                .await
                .expect("registry");
            // Persist happens during seed; add is not supported yet, so rely on defaults.
            let models = registry.list_models().await;
            assert!(!models.is_empty());
        }

        // Re-open and ensure models are still available (requires file load).
        let registry = ModelRegistry::load_from_path(db_path.to_str().unwrap())
            .await
            .expect("registry");
        let models = registry.list_models().await;
        assert!(
            models.iter().any(|m| m.name == "ghost-llm-mini"),
            "missing expected model"
        );
    }
}
