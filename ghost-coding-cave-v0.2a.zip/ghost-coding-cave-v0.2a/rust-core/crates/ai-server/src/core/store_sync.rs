use serde::Deserialize;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum StoreSyncError {
    #[error("http error: {0}")]
    Http(#[from] reqwest::Error),
    #[error("serde error: {0}")]
    Serde(#[from] serde_json::Error),
    #[error("missing store url")]
    MissingUrl,
}

#[derive(Debug, Clone, Deserialize)]
pub struct StoreModelDto {
    pub id: String,
    pub name: String,
    pub provider: Option<String>,
    pub format: Option<String>,
    pub status: String,
}

pub async fn fetch_models(store_url: &str) -> Result<Vec<StoreModelDto>, StoreSyncError> {
    let url = format!("{}/v1/models", store_url.trim_end_matches('/'));
    let res = reqwest::get(&url).await?.error_for_status()?;
    let models: Vec<StoreModelDto> = res.json().await?;
    Ok(models)
}
