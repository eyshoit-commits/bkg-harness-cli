use crate::config::ServerConfig;
use crate::core::registry::{ModelRegistry, RegistryError, ModelModality};
use crate::core::store_sync::{fetch_models, StoreSyncError};
use std::sync::Arc;
use tracing::{info, warn};
use tokio::time::{sleep, Duration};

#[derive(Clone)]
pub struct AppState {
    pub config: Arc<ServerConfig>,
    pub registry: Arc<ModelRegistry>,
}

impl AppState {
    pub async fn try_new(config: &ServerConfig) -> Result<Self, RegistryError> {
        info!(
            mode = %config.helper_mode,
            threads = config.analysis_threads,
            db_path = %config.helper_db_path,
            "initializing model registry"
        );
        let registry = ModelRegistry::load_from_path(&config.helper_db_path).await?;
        let state = Self { config: Arc::new(config.clone()), registry: Arc::new(registry) };
        if let Some(url) = &state.config.semantic_store_http_url {
            // initial sync
            if let Err(e) = state.sync_from_store_once().await {
                warn!(error = ?e, "initial store sync failed");
            }
            // background refresh
            let s = state.clone();
            tokio::spawn(async move {
                let interval = s.config.sync_interval_secs;
                loop {
                    sleep(Duration::from_secs(interval)).await;
                    if let Err(e) = s.sync_from_store_once().await {
                        warn!(error=?e, "store periodic sync failed");
                    }
                }
            });
        }
        Ok(state)
    }

    async fn sync_from_store_once(&self) -> Result<(), StoreSyncError> {
        let url = self.config.semantic_store_http_url.as_ref().ok_or(StoreSyncError::MissingUrl)?;
        let models = fetch_models(url).await?;
        // naive mapping: only names + modality llm
        for m in models {
            // map provider/format to description
            let desc = format!("provider={:?}, format={:?}, status={}", m.provider, m.format, m.status);
            // try to add model; ignore AlreadyExists
            match self.registry.add_model(m.name.clone(), ModelModality::Llm, desc).await {
                Ok(_) => {},
                Err(RegistryError::AlreadyExists(_)) => {},
                Err(e) => warn!(error=?e, model=?m.name, "failed to add model to registry"),
            }
        }
        Ok(())
    }
}
