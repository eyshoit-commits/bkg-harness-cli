use std::env;

#[derive(Clone, Debug)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub helper_db_path: String,
    pub helper_mode: String,
    pub analysis_threads: usize,
    pub log_level: String,
    pub semantic_store_http_url: Option<String>,
    pub sync_interval_secs: u64,
}

impl ServerConfig {
    pub fn from_env() -> Self {
        Self {
            host: env::var("AI_SERVER_HOST").unwrap_or_else(|_| "0.0.0.0".into()),
            port: env::var("AI_SERVER_PORT")
                .ok()
                .and_then(|value| value.parse().ok())
                .unwrap_or(5001),
            helper_db_path: env::var("HELPER_DB_PATH").unwrap_or_else(|_| "/data/helper.db".into()),
            helper_mode: env::var("HELPER_MODE").unwrap_or_else(|_| "development".into()),
            analysis_threads: env::var("HELPER_ANALYSIS_THREADS")
                .ok()
                .and_then(|value| value.parse().ok())
                .unwrap_or(2),
            log_level: env::var("AI_SERVER_LOG_LEVEL").unwrap_or_else(|_| "info".into()),
            semantic_store_http_url: env::var("SEMANTIC_STORE_HTTP_URL").ok(),
            sync_interval_secs: env::var("MODEL_SYNC_INTERVAL_SECS").ok().and_then(|s| s.parse().ok()).unwrap_or(60),
        }
    }
}
