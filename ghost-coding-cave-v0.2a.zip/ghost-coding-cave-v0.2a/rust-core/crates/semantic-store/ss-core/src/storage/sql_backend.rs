// Placeholder for SQL backend implementation
use anyhow::Result;
use async_trait::async_trait;
use std::path::Path;

use super::StorageBackend;

pub struct SqlBackend {
    // Placeholder implementation
}

impl SqlBackend {
    pub async fn connect_default() -> Result<Self> {
        unimplemented!("SQL backend not implemented yet")
    }

    pub async fn new<P: AsRef<Path>>(_base_path: P, _connection_string: &str) -> Result<Self> {
        unimplemented!("SQL backend not implemented yet")
    }
}

#[async_trait]
impl StorageBackend for SqlBackend {
    async fn put(&self, _key: &str, _value: &[u8]) -> Result<()> {
        unimplemented!("SQL backend not implemented yet")
    }

    async fn get(&self, _key: &str) -> Result<Option<Vec<u8>>> {
        unimplemented!("SQL backend not implemented yet")
    }

    async fn delete(&self, _key: &str) -> Result<()> {
        unimplemented!("SQL backend not implemented yet")
    }

    async fn query(&self, _expr: &str) -> Result<Vec<(String, Vec<u8>)>> {
        unimplemented!("SQL backend not implemented yet")
    }
}
