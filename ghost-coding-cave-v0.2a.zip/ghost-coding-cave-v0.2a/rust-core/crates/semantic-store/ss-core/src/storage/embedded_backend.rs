use anyhow::{bail, Context, Result};
use async_trait::async_trait;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tokio::fs::{self, File, OpenOptions};
use tokio::io::{AsyncReadExt, AsyncSeekExt, AsyncWriteExt};
use tokio::sync::{Mutex, RwLock};

use super::StorageBackend;

/// WAL-Layout (Little Endian):
/// [1 byte tombstone (0/1)]
/// [4 bytes klen]
/// [4 bytes vlen]
/// [klen bytes key]
/// [vlen bytes value]
///
/// value_offset = offset + 1 + 4 + 4 + klen
#[derive(Debug, Clone, Copy)]
struct IndexEntry {
    value_offset: u64,
    value_len: u32,
}

pub struct EmbeddedBackend {
    dir: PathBuf,
    wal_path: PathBuf,
    // separater Handle fürs Lesen (seek/read) und fürs Append
    read_file: Arc<Mutex<File>>,
    append_file: Arc<Mutex<File>>,
    index: Arc<RwLock<HashMap<String, IndexEntry>>>,
}

impl EmbeddedBackend {
    pub async fn open_default() -> Result<Self> {
        let base = std::env::var("SS_STORAGE_PATH")
            .map(PathBuf::from)
            .unwrap_or_else(|_| PathBuf::from("./data/ss_storage"));

        Self::open_with_path(&base).await
    }

    pub async fn open_with_path(base: &Path) -> Result<Self> {
        fs::create_dir_all(base)
            .await
            .with_context(|| format!("creating storage dir {}", base.display()))?;
        let wal_path = base.join("store.wal");

        // ensure WAL exists
        if fs::metadata(&wal_path).await.is_err() {
            let mut f = File::create(&wal_path).await?;
            f.flush().await?;
        }

        let read = OpenOptions::new().read(true).open(&wal_path).await?;
        let append = OpenOptions::new()
            .create(true)
            .append(true)
            .read(true)
            .open(&wal_path)
            .await?;

        let backend = EmbeddedBackend {
            dir: base.to_path_buf(),
            wal_path: wal_path.clone(),
            read_file: Arc::new(Mutex::new(read)),
            append_file: Arc::new(Mutex::new(append)),
            index: Arc::new(RwLock::new(HashMap::new())),
        };

        backend.rebuild_index().await?;
        Ok(backend)
    }

    async fn rebuild_index(&self) -> Result<()> {
        let mut rf = self.read_file.lock().await;
        rf.seek(std::io::SeekFrom::Start(0)).await?;
        let mut offset: u64 = 0;

        loop {
            // header 1+4+4 = 9 bytes
            let mut hdr = [0u8; 9];
            match rf.read_exact(&mut hdr).await {
                Ok(_) => {}
                Err(e) if e.kind() == std::io::ErrorKind::UnexpectedEof => break,
                Err(e) => return Err(e).context("reading WAL header"),
            }
            let tomb = hdr[0];
            let klen = u32::from_le_bytes([hdr[1], hdr[2], hdr[3], hdr[4]]) as usize;
            let vlen_u32 = u32::from_le_bytes([hdr[5], hdr[6], hdr[7], hdr[8]]);
            let vlen = vlen_u32 as usize;

            let mut kbuf = vec![0u8; klen];
            rf.read_exact(&mut kbuf).await?;
            let key = String::from_utf8(kbuf).context("key not utf8")?;

            // value may be empty for tombstone
            let value_offset = offset + 8 + klen as u64;
            if vlen > 0 {
                // skip value bytes, but also remember offset for index
                rf.seek(std::io::SeekFrom::Current(vlen as i64)).await?;
            }

            // update offset to next record
            let rec_len = 9u64 + klen as u64 + vlen as u64;
            offset = offset.saturating_add(rec_len);

            // apply to index
            let mut idx = self.index.write().await;
            if tomb == 1 {
                idx.remove(&key);
            } else {
                idx.insert(
                    key,
                    IndexEntry {
                        value_offset,
                        value_len: vlen_u32,
                    },
                );
            }
        }

        Ok(())
    }

    async fn wal_append(&self, tomb: u8, key: &str, value: &[u8]) -> Result<IndexEntry> {
        let mut af = self.append_file.lock().await;
        // current end offset
        let end = af.seek(std::io::SeekFrom::End(0)).await?;

        let k_bytes = key.as_bytes();
        let klen = k_bytes.len() as u32;
        let vlen = value.len() as u32;

        // header
        af.write_all(&[tomb]).await?;
        af.write_all(&klen.to_le_bytes()).await?;
        af.write_all(&vlen.to_le_bytes()).await?;
        // payload
        af.write_all(k_bytes).await?;
        if vlen > 0 {
            af.write_all(value).await?;
        }
        af.flush().await?;

        // compute value offset for index
        let value_offset = end + 1 + 4 + 4 + k_bytes.len() as u64;
        Ok(IndexEntry {
            value_offset,
            value_len: vlen,
        })
    }

    async fn read_value_at(&self, value_offset: u64, vlen: u32) -> Result<Vec<u8>> {
        let mut rf = self.read_file.lock().await;
        rf.seek(std::io::SeekFrom::Start(value_offset)).await?;
        let mut buf = vec![0u8; vlen as usize];
        rf.read_exact(&mut buf).await?;
        Ok(buf)
    }

    // simple "query" support:
    // - "" (empty) => returns all key/value pairs (careful for large stores; fine for tests & CLI)
    // - "key=<exact>" => exact match
    // - "prefix=<pfx>" => all keys starting with pfx
    async fn eval_query(&self, expr: &str) -> Result<Vec<(String, Vec<u8>)>> {
        let idx = self.index.read().await;

        if expr.is_empty() {
            let mut out = Vec::with_capacity(idx.len());
            for (k, entry) in idx.iter() {
                let v = self
                    .read_value_at(entry.value_offset, entry.value_len)
                    .await?;
                out.push((k.clone(), v));
            }
            return Ok(out);
        }

        if let Some(eq) = expr.strip_prefix("key=") {
            if let Some(entry) = idx.get(eq) {
                let v = self
                    .read_value_at(entry.value_offset, entry.value_len)
                    .await?;
                return Ok(vec![(eq.to_string(), v)]);
            } else {
                return Ok(vec![]);
            }
        }

        if let Some(pfx) = expr.strip_prefix("prefix=") {
            let mut out = Vec::new();
            for (k, entry) in idx.iter() {
                if k.starts_with(pfx) {
                    let v = self
                        .read_value_at(entry.value_offset, entry.value_len)
                        .await?;
                    out.push((k.clone(), v));
                }
            }
            return Ok(out);
        }

        bail!("unsupported query expr: {expr}");
    }
}

#[async_trait]
impl StorageBackend for EmbeddedBackend {
    async fn put(&self, key: &str, value: &[u8]) -> Result<()> {
        let entry = self.wal_append(0, key, value).await?;
        let mut idx = self.index.write().await;
        idx.insert(key.to_string(), entry);
        Ok(())
    }

    async fn get(&self, key: &str) -> Result<Option<Vec<u8>>> {
        let idx = self.index.read().await;
        if let Some(entry) = idx.get(key) {
            let v = self
                .read_value_at(entry.value_offset, entry.value_len)
                .await?;
            Ok(Some(v))
        } else {
            Ok(None)
        }
    }

    async fn delete(&self, key: &str) -> Result<()> {
        // write tombstone only if key exists (idempotent-ish)
        let exists = { self.index.read().await.contains_key(key) };
        if exists {
            self.wal_append(1, key, &[]).await?;
            let mut idx = self.index.write().await;
            idx.remove(key);
        }
        Ok(())
    }

    async fn query(&self, expr: &str) -> Result<Vec<(String, Vec<u8>)>> {
        self.eval_query(expr).await
    }

    // verify() bleibt default=false (no-op) im embedded Modus
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[tokio::test]
    async fn put_get_roundtrip() -> Result<()> {
        let dir = tempdir()?;
        std::env::set_var("SS_STORAGE_PATH", dir.path().to_string_lossy().to_string());
        let be = EmbeddedBackend::open_default().await?;

        be.put("hello", b"world").await?;
        let got = be.get("hello").await?;
        assert_eq!(got.as_deref(), Some(&b"world"[..]));

        Ok(())
    }

    #[tokio::test]
    async fn delete_removes_key() -> Result<()> {
        let dir = tempdir()?;
        std::env::set_var("SS_STORAGE_PATH", dir.path().to_string_lossy().to_string());
        let be = EmbeddedBackend::open_default().await?;
        be.put("a", b"1").await?;
        be.delete("a").await?;
        let got = be.get("a").await?;
        assert!(got.is_none());
        Ok(())
    }

    #[tokio::test]
    async fn query_prefix_and_all() -> Result<()> {
        let dir = tempdir()?;
        std::env::set_var("SS_STORAGE_PATH", dir.path().to_string_lossy().to_string());
        let be = EmbeddedBackend::open_default().await?;
        be.put("ns/a", b"x").await?;
        be.put("ns/b", b"y").await?;
        be.put("other/c", b"z").await?;

        let all = be.query("").await?;
        assert_eq!(all.len(), 3);

        let pref = be.query("prefix=ns/").await?;
        assert_eq!(pref.len(), 2);

        let eq = be.query("key=ns/a").await?;
        assert_eq!(eq.len(), 1);
        assert_eq!(eq[0].1, b"x");

        Ok(())
    }

    #[tokio::test]
    async fn survives_reopen_rebuild_index() -> Result<()> {
        let dir = tempdir()?;
        std::env::set_var("SS_STORAGE_PATH", dir.path().to_string_lossy().to_string());
        let be = EmbeddedBackend::open_default().await?;
        be.put("k1", b"v1").await?;
        be.put("k2", b"v2").await?;
        be.delete("k1").await?;

        // Reopen -> rebuild index from WAL
        let be2 = EmbeddedBackend::open_default().await?;
        let v1 = be2.get("k1").await?;
        let v2 = be2.get("k2").await?;
        assert!(v1.is_none());
        assert_eq!(v2.unwrap(), b"v2");
        Ok(())
    }
}
