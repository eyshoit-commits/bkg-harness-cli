use async_trait::async_trait;
use std::sync::Arc;
use anyhow::Result;
use thiserror::Error;

pub mod embedded_backend;
pub mod sql_backend;
pub mod neodb_backend;
pub mod vector_backend;
pub mod media_backend;
pub mod wal;
pub mod merkle;

#[derive(Debug, Error)]
pub enum StorageError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    
    #[error("Key not found: {0}")]
    NotFound(String),
    
    #[error("Invalid query expression: {0}")]
    InvalidQuery(String),
    
    #[error("Invalid proof: {0}")]
    InvalidProof(String),
    
    #[error("WAL error: {0}")]
    WalError(String),
    
    #[error("Other storage error: {0}")]
    Other(String),
}

#[derive(Debug, Clone)]
pub enum StorageMode {
    Embedded,
    Sql,
    NeoDb,
    Media,   // Media-spezifischer KV/Chunk-Store (Video/Audio)
}

impl StorageMode {
    pub fn from_env() -> Self {
        match std::env::var("SS_STORAGE_MODE")
            .unwrap_or_else(|_| "embedded".into())
            .to_lowercase()
            .as_str()
        {
            "sql"   => StorageMode::Sql,
            "neodb" => StorageMode::NeoDb,
            "media" => StorageMode::Media,
            _       => StorageMode::Embedded,
        }
    }
}

/// Unified trait for all storage engines.
#[async_trait]
pub trait StorageBackend: Send + Sync {
    async fn put(&self, key: &str, value: &[u8]) -> Result<()>;
    async fn get(&self, key: &str) -> Result<Option<Vec<u8>>>;
    async fn delete(&self, key: &str) -> Result<()>;
    async fn query(&self, expr: &str) -> Result<Vec<(String, Vec<u8>)>>;
    async fn verify(&self, _key: &str, _proof: &[u8]) -> Result<bool> {
        // default no-op verification for non-verifiable stores
        Ok(false)
    }
}

/// The main entry point for the active storage backend.
pub struct StorageDispatcher {
    backend: Arc<dyn StorageBackend>,
    // optional capability: VectorIndex (nano-vectordb-rs)
    vector: Option<Arc<dyn vector_backend::VectorIndex>>,
}

impl StorageDispatcher {
    pub async fn new() -> Result<Self> {
        let mode = StorageMode::from_env();

        let backend: Arc<dyn StorageBackend> = match mode {
            StorageMode::Embedded => Arc::new(embedded_backend::EmbeddedBackend::open_default().await?),
            StorageMode::Sql      => Arc::new(sql_backend::SqlBackend::connect_default().await?),
            StorageMode::NeoDb    => Arc::new(neodb_backend::NeoDbBackend::open_default().await?),
            StorageMode::Media    => Arc::new(media_backend::MediaBackend::open_default().await?),
        };

        // Vector capability nur wenn aktiviert
        let vector = match std::env::var("SS_VECTOR_MODE").as_deref() {
            Ok("enabled") | Ok("on") | Ok("1") => {
                Some(Arc::new(vector_backend::NanoIndex::open_default().await?) as Arc<dyn vector_backend::VectorIndex>)
            }
            _ => None,
        };

        Ok(Self { backend, vector })
    }

    pub fn backend(&self) -> Arc<dyn StorageBackend> { Arc::clone(&self.backend) }
    pub fn vector(&self)  -> Option<Arc<dyn vector_backend::VectorIndex>> { self.vector.clone() }
}
