// Placeholder for NeoDB backend implementation
use anyhow::Result;
use async_trait::async_trait;
use std::path::Path;

use super::StorageBackend;

pub struct NeoDbBackend {
    // Placeholder implementation
}

impl NeoDbBackend {
    pub async fn open_default() -> Result<Self> {
        unimplemented!("NeoDB backend not implemented yet")
    }

    pub async fn new<P: AsRef<Path>>(_base_path: P, _node_key_path: P) -> Result<Self> {
        unimplemented!("NeoDB backend not implemented yet")
    }
}

#[async_trait]
impl StorageBackend for NeoDbBackend {
    async fn put(&self, _key: &str, _value: &[u8]) -> Result<()> {
        unimplemented!("NeoDB backend not implemented yet")
    }

    async fn get(&self, _key: &str) -> Result<Option<Vec<u8>>> {
        unimplemented!("NeoDB backend not implemented yet")
    }

    async fn delete(&self, _key: &str) -> Result<()> {
        unimplemented!("NeoDB backend not implemented yet")
    }

    async fn query(&self, _expr: &str) -> Result<Vec<(String, Vec<u8>)>> {
        unimplemented!("NeoDB backend not implemented yet")
    }

    async fn verify(&self, _key: &str, _proof: &[u8]) -> Result<bool> {
        unimplemented!("NeoDB backend not implemented yet")
    }
}
