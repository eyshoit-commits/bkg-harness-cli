//! Write-Ahead Log implementation for NeoDB
//!
//! Provides an append-only log for durably storing operations before they are
//! applied to the Merkle tree state. This ensures data integrity and allows for
//! recovery in case of crashes.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufReader, BufWriter, Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use anyhow::Result;

/// Entry in the Write-Ahead Log
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WalEntry {
    /// Unique sequential ID for this entry
    pub id: u64,
    /// Timestamp when entry was created
    pub timestamp: DateTime<Utc>,
    /// Operation type (put, delete)
    pub op_type: WalOpType,
    /// Key for the operation
    pub key: String,
    /// Value for the operation (empty for delete)
    pub value: Vec<u8>,
    /// Hash of the current entry content (key, value, op_type)
    pub hash: [u8; 32],
    /// Hash of the previous entry (zeros for first entry)
    pub prev_hash: [u8; 32],
}

/// Type of operation in WAL
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum WalOpType {
    /// Put operation (create or update)
    Put,
    /// Delete operation
    Delete,
}

/// Manager for WAL operations
pub struct WalManager {
    /// Base directory for WAL files
    wal_dir: PathBuf,
    /// Current active WAL file
    current_file: Arc<Mutex<File>>,
    /// Last assigned entry ID
    last_id: Arc<Mutex<u64>>,
    /// Hash of the last entry
    last_hash: Arc<Mutex<[u8; 32]>>,
}

impl WalManager {
    /// Create a new WAL manager with the given base directory
    pub fn new<P: AsRef<Path>>(wal_dir: P) -> Result<Self> {
        let wal_dir = wal_dir.as_ref().to_path_buf();
        
        // Ensure WAL directory exists
        fs::create_dir_all(&wal_dir)?;
        
        // Find or create the current WAL file
        let (current_file, last_id, last_hash) = Self::initialize_wal(&wal_dir)?;
        
        Ok(Self {
            wal_dir,
            current_file: Arc::new(Mutex::new(current_file)),
            last_id: Arc::new(Mutex::new(last_id)),
            last_hash: Arc::new(Mutex::new(last_hash)),
        })
    }
    
    /// Initialize the WAL system, recovering the last state if available
    fn initialize_wal(wal_dir: &Path) -> Result<(File, u64, [u8; 32])> {
        let current_path = wal_dir.join("current.wal");
        
        // Create new WAL file if it doesn't exist
        if !current_path.exists() {
            let file = OpenOptions::new()
                .create(true)
                .read(true)
                .write(true)
                .open(&current_path)?;
            
            return Ok((file, 0, [0; 32]));
        }
        
        // Open existing WAL file and read the last entry
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(&current_path)?;
        
        let mut reader = BufReader::new(&file);
        let mut last_id = 0;
        let mut last_hash = [0; 32];
        
        // Scan for the last valid entry
        let mut position = 0;
        
        loop {
            // Read entry length
            let mut len_bytes = [0; 8];
            match reader.read_exact(&mut len_bytes) {
                Ok(_) => {},
                Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => break,
                Err(e) => return Err(e.into()),
            };
            
            let entry_len = u64::from_le_bytes(len_bytes);
            
            // Read entry data
            let mut entry_data = vec![0; entry_len as usize];
            match reader.read_exact(&mut entry_data) {
                Ok(_) => {},
                Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => break,
                Err(e) => return Err(e.into()),
            };
            
            // Deserialize entry
            match serde_json::from_slice::<WalEntry>(&entry_data) {
                Ok(entry) => {
                    last_id = entry.id;
                    last_hash = entry.hash;
                    position += 8 + entry_len;
                },
                Err(_) => break, // Corrupted entry, stop here
            }
        }
        
        // Truncate file if there was corruption (only keeping valid entries)
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .open(&current_path)?;
            
        file.set_len(position)?;
        
        Ok((file, last_id, last_hash))
    }
    
    /// Append a new entry to the WAL
    pub fn append(&self, key: &str, value: &[u8], op_type: WalOpType) -> Result<WalEntry> {
        let mut id_guard = self.last_id.lock().unwrap();
        let mut hash_guard = self.last_hash.lock().unwrap();
        
        // Create new entry
        let id = *id_guard + 1;
        let prev_hash = *hash_guard;
        
        // Calculate hash for this entry
        let mut hasher = blake3::Hasher::new();
        hasher.update(key.as_bytes());
        hasher.update(value);
        hasher.update(&[if op_type == WalOpType::Put { 1u8 } else { 0u8 }]);
        hasher.update(&id.to_le_bytes());
        let hash = *hasher.finalize().as_bytes();
        
        let entry = WalEntry {
            id,
            timestamp: Utc::now(),
            op_type,
            key: key.to_string(),
            value: value.to_vec(),
            hash,
            prev_hash,
        };
        
        // Serialize the entry
        let entry_data = serde_json::to_vec(&entry)?;
        
        // Write to WAL file
        let mut file_guard = self.current_file.lock().unwrap();
        let mut writer = BufWriter::new(&mut *file_guard);
        
        // Seek to end to ensure append
        writer.seek(SeekFrom::End(0))?;
        
        // Write entry length followed by entry data
        writer.write_all(&(entry_data.len() as u64).to_le_bytes())?;
        writer.write_all(&entry_data)?;
        writer.flush()?;
        
        // Update state
        *id_guard = id;
        *hash_guard = hash;
        
        Ok(entry)
    }
    
    /// Read all WAL entries
    pub fn read_all(&self) -> Result<Vec<WalEntry>> {
        let file_path = self.wal_dir.join("current.wal");
        
        if !file_path.exists() {
            return Ok(Vec::new());
        }
        
        let file = File::open(file_path)?;
        let mut reader = BufReader::new(file);
        let mut entries = Vec::new();
        
        loop {
            // Read entry length
            let mut len_bytes = [0; 8];
            match reader.read_exact(&mut len_bytes) {
                Ok(_) => {},
                Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => break,
                Err(e) => return Err(e.into()),
            };
            
            let entry_len = u64::from_le_bytes(len_bytes);
            
            // Read entry data
            let mut entry_data = vec![0; entry_len as usize];
            match reader.read_exact(&mut entry_data) {
                Ok(_) => {},
                Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => break,
                Err(e) => return Err(e.into()),
            };
            
            // Deserialize entry
            let entry = serde_json::from_slice(&entry_data)?;
            
            entries.push(entry);
        }
        
        Ok(entries)
    }
    
    /// Rotate the WAL file (archive current and start new)
    pub fn rotate(&self) -> Result<PathBuf> {
        let current = self.wal_dir.join("current.wal");
        if !current.exists() {
            return Ok(current); // Nothing to rotate
        }
        
        // Generate archive name with timestamp
        let timestamp = Utc::now().format("%Y%m%d_%H%M%S");
        let archive_name = format!("wal_{}.archive", timestamp);
        let archive_path = self.wal_dir.join(&archive_name);
        
        // Lock current file and close it
        {
            let file_guard = self.current_file.lock().unwrap();
            // Explicitly drop to ensure it's closed
            drop(file_guard);
        }
        
        // Rename current to archive
        fs::rename(&current, &archive_path)?;
        
        // Create new WAL file
        let new_file = OpenOptions::new()
            .create(true)
            .read(true)
            .write(true)
            .open(&current)?;
            
        // Replace the current file
        {
            let mut file_guard = self.current_file.lock().unwrap();
            *file_guard = new_file;
        }
        
        Ok(archive_path)
    }
    
    /// Get the last entry's hash
    pub fn last_hash(&self) -> [u8; 32] {
        *self.last_hash.lock().unwrap()
    }
    
    /// Get the number of entries in the WAL
    pub fn entry_count(&self) -> Result<usize> {
        let entries = self.read_all()?;
        Ok(entries.len())
    }
    
    /// Verify the integrity of the WAL
    pub fn verify_integrity(&self) -> Result<bool> {
        let entries = self.read_all()?;
        
        if entries.is_empty() {
            return Ok(true);
        }
        
        // Check if entries form a valid hash chain
        let mut prev_hash = [0; 32]; // Initial hash for first entry
        
        for entry in &entries {
            // Verify the prev_hash link
            if entry.prev_hash != prev_hash {
                return Ok(false);
            }
            
            // Verify the entry's own hash
            let mut hasher = blake3::Hasher::new();
            hasher.update(entry.key.as_bytes());
            hasher.update(&entry.value);
            let op_byte = if entry.op_type == WalOpType::Put { 1u8 } else { 0u8 };
            hasher.update(&[op_byte]);
            hasher.update(&entry.id.to_le_bytes());
            let calculated_hash = *hasher.finalize().as_bytes();
            
            if entry.hash != calculated_hash {
                return Ok(false);
            }
            
            // Use this entry's hash as prev_hash for the next one
            prev_hash = entry.hash;
        }
        
        Ok(true)
    }
}
