use anyhow::Result;
use async_trait::async_trait;
use std::path::PathBuf;

// Trait, unabhängig vom KV-Store
#[async_trait]
pub trait VectorIndex: Send + Sync {
    async fn upsert(&self, id: &str, embedding: &[f32]) -> Result<()>;
    async fn search(&self, embedding: &[f32], top_k: usize) -> Result<Vec<(String, f32)>>;
}

pub struct NanoIndex {
    path: PathBuf,
    dims: usize,
    // TODO: echte nano-vectordb-rs Handle hier rein
}

impl NanoIndex {
    pub async fn open_default() -> Result<Self> {
        let base = std::env::var("RAG_VECTOR_PATH").unwrap_or_else(|_| "./data/vector_index".into());
        let dims = std::env::var("RAG_VECTOR_DIMS")
            .ok().and_then(|s| s.parse().ok()).unwrap_or(768);
        // TODO: Index/Collection initialisieren
        Ok(Self { path: base.into(), dims })
    }
}

#[async_trait]
impl VectorIndex for NanoIndex {
    async fn upsert(&self, _id: &str, embedding: &[f32]) -> Result<()> {
        if embedding.len() != self.dims {
            anyhow::bail!("embedding dims {} != {}", embedding.len(), self.dims);
        }
        // TODO: echte Insert/Upsert-API aufrufen
        Ok(())
    }

    async fn search(&self, _embedding: &[f32], _top_k: usize) -> Result<Vec<(String, f32)>> {
        // TODO: echte ANN-Suche; Rückgabe: (doc_id, score)
        Ok(vec![])
    }
}
