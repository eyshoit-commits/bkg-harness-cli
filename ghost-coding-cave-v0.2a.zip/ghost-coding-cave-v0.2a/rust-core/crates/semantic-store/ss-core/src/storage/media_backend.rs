use anyhow::{Result, Context};
use async_trait::async_trait;
use std::{path::PathBuf, sync::Arc};
use tokio::{fs, io::AsyncWriteExt, sync::RwLock};
use super::StorageBackend;

#[derive(Clone)]
pub struct MediaBackend {
    base: PathBuf,
    // einfacher In-Memory Index -> später durch VectorIndex ersetzen
    index: Arc<RwLock<Vec<MediaIndexEntry>>>,
}

#[derive(Clone, Debug)]
struct MediaIndexEntry {
    key: String,          // z.B. "video/{video_id}/frame/{ts_ms}"
    media_path: PathBuf,  // binäre Chunks (jpg/png/wav)
    embed_key: Option<String>, // optional: Verweis auf Vektorindex-ID
}

impl MediaBackend {
    pub async fn open_default() -> Result<Self> {
        let base = std::env::var("SS_STORAGE_PATH")
            .unwrap_or_else(|_| "./data/ss_storage".into());
        let base = PathBuf::from(base).join("media");
        fs::create_dir_all(&base).await?;
        Ok(Self { base, index: Arc::new(RwLock::new(Vec::new())) })
    }

    async fn write_blob(&self, rel: &str, bytes: &[u8]) -> Result<PathBuf> {
        let path = self.base.join(rel);
        if let Some(parent) = path.parent() { fs::create_dir_all(parent).await?; }
        let mut f = tokio::fs::File::create(&path).await?;
        f.write_all(bytes).await?;
        f.flush().await?;
        Ok(path)
    }
}

#[async_trait]
impl StorageBackend for MediaBackend {
    async fn put(&self, key: &str, value: &[u8]) -> Result<()> {
        // Schlüsselraum:
        // - "media:<ns>/<id>/frame/<ts>.jpg"  -> binär
        // - "meta:<ns>/<id>.json"             -> text/json
        let is_media = key.starts_with("media:");
        let rel = key.replacen("media:", "", 1);
        if is_media {
            let p = self.write_blob(&rel, value).await?;
            let entry = MediaIndexEntry { key: key.to_string(), media_path: p, embed_key: None };
            self.index.write().await.push(entry);
            return Ok(());
        }
        // Metadaten als JSON auf Platte
        let _p = self.write_blob(&format!("meta/{}", rel), value).await?;
        Ok(())
    }

    async fn get(&self, key: &str) -> Result<Option<Vec<u8>>> {
        if key.starts_with("media:") {
            let rel = key.replacen("media:", "", 1);
            let path = self.base.join(rel);
            match tokio::fs::read(&path).await {
                Ok(bytes) => Ok(Some(bytes)),
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
                Err(e) => Err(e).context("read media"),
            }
        } else {
            let path = self.base.join(format!("meta/{}", key));
            match tokio::fs::read(&path).await {
                Ok(bytes) => Ok(Some(bytes)),
                Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
                Err(e) => Err(e).context("read meta"),
            }
        }
    }

    async fn delete(&self, key: &str) -> Result<()> {
        // Soft-delete: Datei entfernen, Index filtern
        let rel = if key.starts_with("media:") {
            key.replacen("media:", "", 1)
        } else {
            format!("meta/{}", key)
        };
        let path = self.base.join(rel);
        let _ = tokio::fs::remove_file(&path).await;
        self.index.write().await.retain(|e| e.key != key);
        Ok(())
    }

    async fn query(&self, expr: &str) -> Result<Vec<(String, Vec<u8>)>> {
        // minimal:
        // - "prefix=media:" -> alle Medienobjekte
        // - "prefix=meta:"  -> alle Metadaten
        let mut out = Vec::new();
        if let Some(pfx) = expr.strip_prefix("prefix=") {
            for e in self.index.read().await.iter() {
                if e.key.starts_with(pfx) {
                    if let Ok(bytes) = tokio::fs::read(&e.media_path).await {
                        out.push((e.key.clone(), bytes));
                    }
                }
            }
            return Ok(out);
        }
        anyhow::bail!("unsupported media query: {expr}")
    }
    
    async fn verify(&self, _key: &str, _proof: &[u8]) -> Result<bool> {
        // Media backend doesn't support verification
        Ok(false)
    }
}
