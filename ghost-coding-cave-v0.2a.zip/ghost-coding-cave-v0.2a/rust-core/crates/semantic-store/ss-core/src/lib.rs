use chrono::{DateTime, Utc};
use log::info;
use parking_lot::RwLock;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::{fs, io::Write};
use tempfile::NamedTempFile;
use thiserror::Error;
use uuid::Uuid;

// Storage module with backend implementations
pub mod storage;

#[derive(Debug, Error)]
pub enum StoreError {
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    #[error("serde error: {0}")]
    Serde(#[from] serde_json::Error),
    #[error("not found: {0}")]
    NotFound(String),
    #[error("already exists: {0}")]
    AlreadyExists(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelRecord {
    pub id: Uuid,
    pub name: String,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub provider: Option<String>,
    pub format: Option<String>,
    pub revision: Option<String>,
    pub status: String,
    pub meta: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenizerRecord {
    pub id: Uuid,
    pub name: String,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub spec: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SnapshotIndex {
    pub schema_version: u32,
    pub models: HashMap<Uuid, ModelRecord>,
    pub tokenizers: HashMap<Uuid, TokenizerRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StoreHealth {
    pub schema_version: u32,
    pub model_count: usize,
    pub tokenizer_count: usize,
    pub snapshot_count: usize,
}

#[derive(Clone)]
pub struct SemanticStoreCore {
    root: PathBuf,
    index: Arc<RwLock<SnapshotIndex>>,
}

impl SemanticStoreCore {
    pub fn open<P: AsRef<Path>>(root: P) -> Result<Self, StoreError> {
        let root = root.as_ref().to_path_buf();
        fs::create_dir_all(&root)?;
        fs::create_dir_all(root.join("snapshots"))?;
        let idx_path = root.join("index.json");
        let mut index: SnapshotIndex = if idx_path.exists() {
            let data = fs::read(&idx_path)?;
            serde_json::from_slice(&data)?
        } else {
            SnapshotIndex {
                schema_version: 1,
                ..Default::default()
            }
        };
        // Simple migration hook example
        if index.schema_version < 1 {
            index.schema_version = 1;
        }
        Ok(Self {
            root,
            index: Arc::new(RwLock::new(index)),
        })
    }

    fn persist_index(&self) -> Result<(), StoreError> {
        let data = serde_json::to_vec_pretty(&*self.index.read())?;
        // atomic write via tempfile + rename
        let tmp = NamedTempFile::new_in(&self.root)?;
        let path = tmp.path().to_path_buf();
        {
            let mut f = tmp.reopen()?;
            f.write_all(&data)?;
            f.flush()?;
        }
        fs::rename(path, self.root.join("index.json"))?;
        Ok(())
    }

    pub fn save(&self) -> Result<(), StoreError> {
        self.persist_index()
    }

    fn snapshots_dir(&self) -> PathBuf {
        self.root.join("snapshots")
    }

    pub fn snapshot_now(&self) -> Result<PathBuf, StoreError> {
        let ts = Utc::now().format("%Y-%m-%d_%H-%M-%S");
        let path = self.snapshots_dir().join(format!("index-{}.json", ts));
        let data = serde_json::to_vec_pretty(&*self.index.read())?;
        // atomic snapshot write
        let tmp = NamedTempFile::new_in(self.snapshots_dir())?;
        let tmp_path = tmp.path().to_path_buf();
        {
            let mut f = tmp.reopen()?;
            f.write_all(&data)?;
            f.flush()?;
        }
        fs::rename(tmp_path, &path)?;
        Ok(path)
    }

    pub fn recover_latest_snapshot(&self) -> Result<PathBuf, StoreError> {
        let mut entries: Vec<_> = fs::read_dir(self.snapshots_dir())?
            .filter_map(|e| e.ok())
            .filter(|e| e.path().is_file())
            .collect();
        entries.sort_by_key(|e| e.file_name());
        let latest = entries
            .last()
            .ok_or_else(|| StoreError::NotFound("no snapshots".into()))?;
        let latest_path = latest.path();
        let bytes = fs::read(&latest_path)?;
        let recovered: SnapshotIndex = serde_json::from_slice(&bytes)?;
        // write recovered index atomically
        let tmp = NamedTempFile::new_in(&self.root)?;
        let tp = tmp.path().to_path_buf();
        {
            let mut f = tmp.reopen()?;
            f.write_all(&bytes)?;
            f.flush()?;
        }
        fs::rename(tp, self.root.join("index.json"))?;
        // swap in-memory index
        let mut guard = self.index.write();
        *guard = recovered;
        info!(target: "ss-core", "recovered from snapshot: {}", latest_path.display());
        Ok(latest_path)
    }

    pub fn list_models(&self) -> Vec<ModelRecord> {
        self.index.read().models.values().cloned().collect()
    }

    pub fn create_model(
        &self,
        name: &str,
        provider: Option<&str>,
        format: Option<&str>,
    ) -> Result<ModelRecord, StoreError> {
        let mut guard = self.index.write();
        if guard.models.values().any(|m| m.name == name) {
            return Err(StoreError::AlreadyExists(name.to_string()));
        }
        let now = Utc::now();
        let rec = ModelRecord {
            id: Uuid::new_v4(),
            name: name.to_string(),
            created_at: now,
            updated_at: now,
            provider: provider.map(|s| s.to_string()),
            format: format.map(|s| s.to_string()),
            revision: None,
            status: "AVAILABLE".into(),
            meta: serde_json::json!({}),
        };
        guard.models.insert(rec.id, rec.clone());
        drop(guard);
        self.persist_index()?;
        Ok(rec)
    }

    pub fn get_model(&self, id: Uuid) -> Result<ModelRecord, StoreError> {
        self.index
            .read()
            .models
            .get(&id)
            .cloned()
            .ok_or(StoreError::NotFound(id.to_string()))
    }

    pub fn update_model_status(&self, id: Uuid, status: &str) -> Result<ModelRecord, StoreError> {
        let mut guard = self.index.write();
        let rec = guard
            .models
            .get_mut(&id)
            .ok_or(StoreError::NotFound(id.to_string()))?;
        rec.status = status.to_string();
        rec.updated_at = Utc::now();
        let out = rec.clone();
        drop(guard);
        self.persist_index()?;
        Ok(out)
    }

    pub fn delete_model(&self, id: Uuid) -> Result<(), StoreError> {
        let mut guard = self.index.write();
        guard
            .models
            .remove(&id)
            .ok_or(StoreError::NotFound(id.to_string()))?;
        drop(guard);
        self.persist_index()?;
        Ok(())
    }

    pub fn list_tokenizers(&self) -> Vec<TokenizerRecord> {
        self.index.read().tokenizers.values().cloned().collect()
    }

    pub fn upsert_tokenizer(
        &self,
        name: &str,
        spec: serde_json::Value,
    ) -> Result<TokenizerRecord, StoreError> {
        let mut guard = self.index.write();
        let now = Utc::now();
        if let Some((_id, tok)) = guard.tokenizers.iter_mut().find(|(_id, t)| t.name == name) {
            tok.spec = spec;
            tok.updated_at = now;
            let out = tok.clone();
            drop(guard);
            self.persist_index()?;
            return Ok(out);
        }
        let tok = TokenizerRecord {
            id: Uuid::new_v4(),
            name: name.to_string(),
            created_at: now,
            updated_at: now,
            spec,
        };
        guard.tokenizers.insert(tok.id, tok.clone());
        drop(guard);
        self.persist_index()?;
        Ok(tok)
    }
}
