use assert_json_diff::assert_json_eq;
use serde_json::Value;
use std::fs;
use tempfile::tempdir;

use ss_core::SemanticStoreCore;

#[test]
fn snapshot_recovery_roundtrip() {
    let dir = tempdir().unwrap();
    let root = dir.path();

    // init store and create a model
    let store = SemanticStoreCore::open(root).expect("open");
    store
        .create_model("reco-test", Some("LOCAL"), Some("Ghost"))
        .expect("create");

    // take snapshot
    let snap = store.snapshot_now().expect("snapshot");
    let snap_bytes = fs::read(&snap).expect("read snap");
    let snap_json: Value = serde_json::from_slice(&snap_bytes).expect("snap json");

    // corrupt index.json intentionally
    fs::write(root.join("index.json"), b"{}\n").expect("corrupt index");

    // recover
    let recovered = store.recover_latest_snapshot().expect("recover");
    assert_eq!(recovered, snap, "should recover the latest snapshot path");

    // verify model exists again
    let names: Vec<_> = store.list_models().into_iter().map(|m| m.name).collect();
    assert!(
        names.iter().any(|n| n == "reco-test"),
        "model reco-test should exist after recovery"
    );

    // persist current index and compare with snapshot structurally
    store.save().expect("save");
    let idx_bytes = fs::read(root.join("index.json")).expect("read index");
    let idx_json: Value = serde_json::from_slice(&idx_bytes).expect("idx json");
    assert_json_eq!(snap_json, idx_json);
}
