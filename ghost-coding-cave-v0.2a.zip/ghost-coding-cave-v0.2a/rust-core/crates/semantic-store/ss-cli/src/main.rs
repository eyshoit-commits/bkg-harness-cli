use anyhow::Result;
use clap::{Parser, Subcommand};
use ss_gf::{compute_sha3_256_hex, GhostManifest};
use std::fs::File;
use std::io::{stdin, Read};

#[derive(Parser)]
#[command(name = "ss-cli", version, about = "Semantic-Store CLI")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Validiert ein Ghost-Manifest (JSON-Datei; - für STDIN)
    ManifestValidate { path: String },
    /// Gibt das JSON-Schema des Manifests aus
    ManifestSchema,
    /// Berechnet sha3-256 Hash einer Datei (- für STDIN)
    Hash { path: String },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Commands::ManifestValidate { path } => {
            let mut buf = String::new();
            if path == "-" {
                stdin().read_to_string(&mut buf)?;
            } else {
                buf = std::fs::read_to_string(path)?;
            }
            let mf: GhostManifest = serde_json::from_str(&buf)?;
            mf.validate()?;
            println!("OK");
        }
        Commands::ManifestSchema => {
            let schema = schemars::schema_for!(GhostManifest);
            let json = serde_json::to_string_pretty(&schema)?;
            println!("{}", json);
        }
        Commands::Hash { path } => {
            if path == "-" {
                let hash = compute_sha3_256_hex(stdin())?;
                println!("{}", hash);
            } else {
                let f = File::open(path)?;
                let hash = compute_sha3_256_hex(f)?;
                println!("{}", hash);
            }
        }
    }
    Ok(())
}
