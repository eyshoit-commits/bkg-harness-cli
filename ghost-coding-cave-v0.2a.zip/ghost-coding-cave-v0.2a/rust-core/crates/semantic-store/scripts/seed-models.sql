-- Seed-Daten für Standard-Modelle
INSERT INTO models (name, version, format, metadata) VALUES
('Llama-2', '13B', 'gguf', '{"desc":"Meta Llama 2.0, 13B"}'),
('phi-2', '1.0', 'onnx', '{"desc":"Phi-2 Transformer"}'),
('GPT-4', '4.0', 'ghost', '{"desc":"OpenAI GPT-4"}');
