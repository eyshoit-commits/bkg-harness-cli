-- Datenbankschema für WAL und Snapshots
CREATE TABLE IF NOT EXISTS wal_events (
    id SERIAL PRIMARY KEY,
    event_data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS snapshots (
    id SERIAL PRIMARY KEY,
    snapshot_data BYTEA,
    created_at TIMESTAMP DEFAULT NOW()
);
