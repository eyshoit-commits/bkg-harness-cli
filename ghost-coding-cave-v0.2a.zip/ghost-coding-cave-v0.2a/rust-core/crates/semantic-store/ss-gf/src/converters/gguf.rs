use std::fs;
use std::fs::File;
use std::path::Path;

use chrono::Utc;
use serde::Serialize;
use serde_json::{Map as JsonMap, Value as JsonValue};

use crate::{compute_sha3_256_hex, GhostManifest, LayerDescriptor, TokenizerRef};

use super::ConverterError;

/// Options that influence how a GGUF artefact is converted into a `.ghost`
/// manifest.
#[derive(Debug, Clone)]
pub struct GgufConversionConfig {
    /// Manifest schema/version to emit.
    pub format_version: u32,
    /// Optional tokenizer reference to attach to the manifest.
    pub tokenizer: Option<TokenizerRef>,
    /// Optional creation timestamp; defaults to `Utc::now().to_rfc3339()`.
    pub created_at: Option<String>,
    /// Extra metadata to merge into the manifest blob.
    pub additional_metadata: Option<JsonValue>,
}

impl Default for GgufConversionConfig {
    fn default() -> Self {
        Self {
            format_version: 1,
            tokenizer: None,
            created_at: None,
            additional_metadata: None,
        }
    }
}

/// Minimal GGUF metadata extracted during conversion.
#[derive(Debug, Clone, Serialize)]
pub struct GgufMetadata {
    pub model_name: String,
    pub description: String,
    pub tensor_count: usize,
    pub quantization: Option<String>,
}

impl Default for GgufMetadata {
    fn default() -> Self {
        Self {
            model_name: "unknown".to_string(),
            description: "GGUF model".to_string(),
            tensor_count: 0,
            quantization: None,
        }
    }
}

/// Converter implementation for GGUF models.
pub struct GgufConverter;

impl GgufConverter {
    /// Convert a GGUF file into a validated [`GhostManifest`] using default
    /// conversion settings.
    pub fn convert<P, S1, S2>(
        path: P,
        model_name: S1,
        version: S2,
    ) -> Result<GhostManifest, ConverterError>
    where
        P: AsRef<Path>,
        S1: Into<String>,
        S2: Into<String>,
    {
        Self::convert_with_config(path, model_name, version, GgufConversionConfig::default())
    }

    /// Convert a GGUF file into a validated [`GhostManifest`] using the provided
    /// [`GgufConversionConfig`].
    pub fn convert_with_config<P, S1, S2>(
        path: P,
        model_name: S1,
        version: S2,
        config: GgufConversionConfig,
    ) -> Result<GhostManifest, ConverterError>
    where
        P: AsRef<Path>,
        S1: Into<String>,
        S2: Into<String>,
    {
        let path = path.as_ref();
        let display_path = path.to_string_lossy().into_owned();

        if !path.exists() {
            return Err(ConverterError::MissingFile(display_path));
        }

        let metadata = fs::metadata(path)?;
        if !metadata.is_file() {
            return Err(ConverterError::NotAFile(display_path));
        }

        ensure_extension(path, "gguf")?;

        if metadata.len() < 512 {
            return Err(ConverterError::FileTooSmall(metadata.len()));
        }

        let gguf_metadata = extract_metadata(path);

        let mut file = File::open(path)?;
        let hash = compute_sha3_256_hex(&mut file)?;

        let layer_entry = LayerDescriptor {
            name: layer_name(path),
            kind: "gguf-model".to_string(),
            sha3_256: hash,
            size_bytes: metadata.len(),
            metadata: Some(build_layer_metadata(path, &gguf_metadata)),
        };

        let created_at = config.created_at.unwrap_or_else(|| Utc::now().to_rfc3339());

        let manifest_metadata =
            build_manifest_metadata(&gguf_metadata, metadata.len(), config.additional_metadata);

        let manifest = GhostManifest {
            name: model_name.into(),
            version: version.into(),
            format_version: config.format_version,
            created_at,
            tokenizer: config.tokenizer,
            layers: vec![layer_entry],
            metadata: Some(manifest_metadata),
        };

        if let Err(err) = manifest.validate() {
            return Err(ConverterError::InvalidManifest(err));
        }

        Ok(manifest)
    }
}

fn ensure_extension(path: &Path, expected: &'static str) -> Result<(), ConverterError> {
    match path.extension().and_then(|ext| ext.to_str()) {
        Some(ext) if ext.eq_ignore_ascii_case(expected) => Ok(()),
        Some(found) => Err(ConverterError::InvalidExtension {
            expected,
            found: found.to_ascii_lowercase(),
        }),
        None => Err(ConverterError::InvalidExtension {
            expected,
            found: String::new(),
        }),
    }
}

fn layer_name(path: &Path) -> String {
    path.file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| {
            format!(
                "model.{}",
                path.extension().and_then(|s| s.to_str()).unwrap_or("gguf")
            )
        })
}

fn build_layer_metadata(path: &Path, meta: &GgufMetadata) -> JsonValue {
    let mut obj = JsonMap::new();
    obj.insert(
        "source_path".to_string(),
        JsonValue::String(path.to_string_lossy().into_owned()),
    );
    obj.insert(
        "tensor_count".to_string(),
        JsonValue::Number((meta.tensor_count as u64).into()),
    );
    if let Some(q) = &meta.quantization {
        obj.insert("quantization".to_string(), JsonValue::String(q.clone()));
    }
    JsonValue::Object(obj)
}

fn build_manifest_metadata(
    meta: &GgufMetadata,
    file_size: u64,
    additional: Option<JsonValue>,
) -> JsonValue {
    let mut obj = JsonMap::new();
    obj.insert("format".into(), JsonValue::String("gguf".into()));
    obj.insert(
        "file_size_bytes".into(),
        JsonValue::Number(file_size.into()),
    );
    obj.insert(
        "model_name".into(),
        JsonValue::String(meta.model_name.clone()),
    );
    obj.insert(
        "metadata".into(),
        serde_json::to_value(meta).unwrap_or(JsonValue::Null),
    );

    if let Some(additional) = additional {
        match additional {
            JsonValue::Object(extra) => {
                for (key, value) in extra {
                    obj.insert(key, value);
                }
            }
            other => {
                obj.insert("extra".into(), other);
            }
        }
    }

    JsonValue::Object(obj)
}

fn extract_metadata(path: &Path) -> GgufMetadata {
    let mut meta = GgufMetadata::default();
    if let Some(name) = path.file_stem().and_then(|s| s.to_str()) {
        meta.model_name = name.to_string();
        meta.description = format!("GGUF model converted from {}", name);
    }
    // TODO: Parse GGUF header for richer metadata such as tensor count.
    meta
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;

    #[test]
    fn rejects_missing_files() {
        let result = GgufConverter::convert("not-there.gguf", "demo", "1.0.0");
        assert!(matches!(result, Err(ConverterError::MissingFile(_))));
    }

    #[test]
    fn rejects_wrong_extension() {
        let file = NamedTempFile::new().unwrap();
        let result = GgufConverter::convert(file.path(), "demo", "1.0.0");
        assert!(matches!(
            result,
            Err(ConverterError::InvalidExtension { .. })
        ));
    }

    #[test]
    fn converts_and_validates_manifest() {
        let mut file = NamedTempFile::new().unwrap();
        let payload = vec![7u8; 1024];
        std::io::Write::write_all(&mut file, &payload).unwrap();

        let gguf_path = file.path().with_extension("gguf");
        fs::copy(file.path(), &gguf_path).unwrap();

        let manifest = GgufConverter::convert(&gguf_path, "sample-model", "0.1.0")
            .expect("conversion succeeds");

        assert_eq!(manifest.name, "sample-model");
        assert_eq!(manifest.version, "0.1.0");
        assert_eq!(manifest.layers.len(), 1);
        let layer = &manifest.layers[0];
        assert_eq!(layer.kind, "gguf-model");
        assert_eq!(layer.name, layer_name(&gguf_path));
        assert_eq!(layer.size_bytes, 1024);
        assert!(layer.metadata.is_some());

        manifest.validate().expect("manifest should validate");

        fs::remove_file(gguf_path).ok();
    }
}
