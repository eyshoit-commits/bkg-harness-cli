//! Model format converters for `.ghost` capsules.
//!
//! This module provides synchronous helpers that transform external model
//! artefacts into the lightweight [`GhostManifest`] representation shipped
//! with `ss-gf`.  Each converter validates the input file, extracts basic
//! metadata and constructs the manifest layers that will later be embedded
//! into a `.ghost` capsule.
//!
//! Only ONNX and GGUF converters are available right now, but the error type
//! is shared so additional backends (Transformers, SafeTensors, …) can plug
//! in without having to duplicate failure handling.

mod gguf;
mod onnx;

pub use gguf::{GgufConversionConfig, GgufConverter, GgufMetadata};
pub use onnx::{OnnxConversionConfig, OnnxConverter, OnnxMetadata};

use thiserror::Error;

/// Common error wrapper returned by format converters.
#[derive(Debug, Error)]
pub enum ConverterError {
    #[error("input file does not exist: {0}")]
    MissingFile(String),
    #[error("expected file with extension `{expected}`, got `{found}`")]
    InvalidExtension {
        expected: &'static str,
        found: String,
    },
    #[error("input is not a regular file: {0}")]
    NotAFile(String),
    #[error("file too small to contain a valid model ({0} bytes)")]
    FileTooSmall(u64),
    #[error("failed to read model: {0}")]
    Io(#[from] std::io::Error),
    #[error("hash computation failed: {0}")]
    Hash(#[from] crate::ValidationError),
    #[error("generated manifest failed validation: {0}")]
    InvalidManifest(crate::ValidationError),
}
