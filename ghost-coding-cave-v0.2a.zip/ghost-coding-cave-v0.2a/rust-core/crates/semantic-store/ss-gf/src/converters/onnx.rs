use std::fs;
use std::fs::File;
use std::path::Path;

use chrono::Utc;
use serde::Serialize;
use serde_json::{Map as JsonMap, Value as JsonValue};

use crate::{compute_sha3_256_hex, GhostManifest, LayerDescriptor, TokenizerRef};

use super::ConverterError;

/// Options that influence how an ONNX artefact is converted into a `.ghost`
/// manifest.
#[derive(Debug, Clone)]
pub struct OnnxConversionConfig {
    /// Manifest schema/version to emit.
    pub format_version: u32,
    /// Optional tokenizer reference to attach to the manifest.
    pub tokenizer: Option<TokenizerRef>,
    /// Optional creation timestamp; defaults to `Utc::now().to_rfc3339()`.
    pub created_at: Option<String>,
    /// Extra metadata to merge into the manifest blob.
    pub additional_metadata: Option<JsonValue>,
}

impl Default for OnnxConversionConfig {
    fn default() -> Self {
        Self {
            format_version: 1,
            tokenizer: None,
            created_at: None,
            additional_metadata: None,
        }
    }
}

/// Minimal ONNX metadata extracted during conversion.
#[derive(Debug, Clone, Serialize)]
pub struct OnnxMetadata {
    pub opset_version: i64,
    pub producer_name: String,
    pub producer_version: String,
    pub domain: String,
    pub model_version: i64,
    pub doc_string: String,
    pub graph_name: String,
    pub input_shapes: Vec<Vec<i64>>,
    pub output_shapes: Vec<Vec<i64>>,
}

impl Default for OnnxMetadata {
    fn default() -> Self {
        Self {
            opset_version: 13,
            producer_name: "unknown".to_string(),
            producer_version: "1.0.0".to_string(),
            domain: "ai.onnx".to_string(),
            model_version: 1,
            doc_string: String::new(),
            graph_name: "main_graph".to_string(),
            input_shapes: vec![],
            output_shapes: vec![],
        }
    }
}

/// Converter implementation for ONNX models.
pub struct OnnxConverter;

impl OnnxConverter {
    /// Convert an ONNX file into a validated [`GhostManifest`] using default
    /// conversion settings.
    pub fn convert<P, S1, S2>(
        path: P,
        model_name: S1,
        version: S2,
    ) -> Result<GhostManifest, ConverterError>
    where
        P: AsRef<Path>,
        S1: Into<String>,
        S2: Into<String>,
    {
        Self::convert_with_config(path, model_name, version, OnnxConversionConfig::default())
    }

    /// Convert an ONNX file into a validated [`GhostManifest`] using the provided
    /// [`OnnxConversionConfig`].
    pub fn convert_with_config<P, S1, S2>(
        path: P,
        model_name: S1,
        version: S2,
        config: OnnxConversionConfig,
    ) -> Result<GhostManifest, ConverterError>
    where
        P: AsRef<Path>,
        S1: Into<String>,
        S2: Into<String>,
    {
        let path = path.as_ref();
        let display_path = path.to_string_lossy().into_owned();

        if !path.exists() {
            return Err(ConverterError::MissingFile(display_path));
        }

        let metadata = fs::metadata(path)?;
        if !metadata.is_file() {
            return Err(ConverterError::NotAFile(display_path));
        }

        ensure_extension(path, "onnx")?;

        if metadata.len() < 128 {
            return Err(ConverterError::FileTooSmall(metadata.len()));
        }

        let onnx_metadata = extract_metadata(path);

        let mut file = File::open(path)?;
        let hash = compute_sha3_256_hex(&mut file)?;

        let layer_entry = LayerDescriptor {
            name: layer_name(path),
            kind: "onnx-model".to_string(),
            sha3_256: hash,
            size_bytes: metadata.len(),
            metadata: Some(build_layer_metadata(path, &onnx_metadata)),
        };

        let created_at = config.created_at.unwrap_or_else(|| Utc::now().to_rfc3339());

        let manifest_metadata =
            build_manifest_metadata(&onnx_metadata, metadata.len(), config.additional_metadata);

        let manifest = GhostManifest {
            name: model_name.into(),
            version: version.into(),
            format_version: config.format_version,
            created_at,
            tokenizer: config.tokenizer,
            layers: vec![layer_entry],
            metadata: Some(manifest_metadata),
        };

        if let Err(err) = manifest.validate() {
            return Err(ConverterError::InvalidManifest(err));
        }

        Ok(manifest)
    }
}

fn ensure_extension(path: &Path, expected: &'static str) -> Result<(), ConverterError> {
    match path.extension().and_then(|ext| ext.to_str()) {
        Some(ext) if ext.eq_ignore_ascii_case(expected) => Ok(()),
        Some(found) => Err(ConverterError::InvalidExtension {
            expected,
            found: found.to_ascii_lowercase(),
        }),
        None => Err(ConverterError::InvalidExtension {
            expected,
            found: String::new(),
        }),
    }
}

fn layer_name(path: &Path) -> String {
    path.file_name()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| {
            format!(
                "model.{}",
                path.extension().and_then(|s| s.to_str()).unwrap_or("onnx")
            )
        })
}

fn build_layer_metadata(path: &Path, meta: &OnnxMetadata) -> JsonValue {
    let mut obj = JsonMap::new();
    obj.insert(
        "source_path".to_string(),
        JsonValue::String(path.to_string_lossy().into_owned()),
    );
    obj.insert(
        "graph_name".to_string(),
        JsonValue::String(meta.graph_name.clone()),
    );
    obj.insert(
        "opset_version".to_string(),
        JsonValue::Number(meta.opset_version.into()),
    );
    JsonValue::Object(obj)
}

fn build_manifest_metadata(
    meta: &OnnxMetadata,
    file_size: u64,
    additional: Option<JsonValue>,
) -> JsonValue {
    let mut obj = JsonMap::new();
    obj.insert("format".into(), JsonValue::String("onnx".into()));
    obj.insert(
        "file_size_bytes".into(),
        JsonValue::Number(file_size.into()),
    );
    obj.insert(
        "producer".into(),
        JsonValue::String(format!("{} {}", meta.producer_name, meta.producer_version)),
    );
    obj.insert("domain".into(), JsonValue::String(meta.domain.clone()));
    obj.insert(
        "metadata".into(),
        serde_json::to_value(meta).unwrap_or(JsonValue::Null),
    );

    if let Some(additional) = additional {
        match additional {
            JsonValue::Object(extra) => {
                for (key, value) in extra {
                    obj.insert(key, value);
                }
            }
            other => {
                obj.insert("extra".into(), other);
            }
        }
    }

    JsonValue::Object(obj)
}

fn extract_metadata(path: &Path) -> OnnxMetadata {
    let mut meta = OnnxMetadata::default();

    if let Some(name) = path.file_stem().and_then(|s| s.to_str()) {
        meta.graph_name = name.to_string();
        meta.doc_string = format!("ONNX model converted from {}", name);
    }

    // TODO: Parse real ONNX protobuf for richer metadata.
    meta
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::NamedTempFile;

    #[test]
    fn rejects_missing_files() {
        let result = OnnxConverter::convert("not-there.onnx", "demo", "1.0.0");
        assert!(matches!(result, Err(ConverterError::MissingFile(_))));
    }

    #[test]
    fn rejects_wrong_extension() {
        let file = NamedTempFile::new().unwrap();
        let result = OnnxConverter::convert(file.path(), "demo", "1.0.0");
        assert!(matches!(
            result,
            Err(ConverterError::InvalidExtension { .. })
        ));
    }

    #[test]
    fn converts_and_validates_manifest() {
        let mut file = NamedTempFile::new().unwrap();
        let payload = vec![7u8; 256];
        std::io::Write::write_all(&mut file, &payload).unwrap();

        let onnx_path = file.path().with_extension("onnx");
        fs::copy(file.path(), &onnx_path).unwrap();

        let manifest = OnnxConverter::convert(&onnx_path, "sample-model", "0.1.0")
            .expect("conversion succeeds");

        assert_eq!(manifest.name, "sample-model");
        assert_eq!(manifest.version, "0.1.0");
        assert_eq!(manifest.layers.len(), 1);
        let layer = &manifest.layers[0];
        assert_eq!(layer.kind, "onnx-model");
        assert_eq!(layer.name, layer_name(&onnx_path));
        assert_eq!(layer.size_bytes, 256);
        assert!(layer.metadata.is_some());

        manifest.validate().expect("manifest should validate");

        fs::remove_file(onnx_path).ok();
    }

    #[test]
    fn merge_additional_metadata() {
        let mut file = NamedTempFile::new().unwrap();
        let payload = vec![1u8; 256];
        std::io::Write::write_all(&mut file, &payload).unwrap();

        let onnx_path = file.path().with_extension("onnx");
        fs::copy(file.path(), &onnx_path).unwrap();

        let mut extra = JsonMap::new();
        extra.insert(
            "training_dataset".into(),
            JsonValue::String("imagenet".into()),
        );

        let manifest = OnnxConverter::convert_with_config(
            &onnx_path,
            "extra-model",
            "0.2.0",
            OnnxConversionConfig {
                additional_metadata: Some(JsonValue::Object(extra)),
                ..Default::default()
            },
        )
        .expect("conversion");

        let meta = manifest.metadata.expect("metadata exists");
        let obj = meta.as_object().expect("metadata object");
        assert_eq!(
            obj.get("training_dataset").and_then(|v| v.as_str()),
            Some("imagenet")
        );

        fs::remove_file(onnx_path).ok();
    }
}
