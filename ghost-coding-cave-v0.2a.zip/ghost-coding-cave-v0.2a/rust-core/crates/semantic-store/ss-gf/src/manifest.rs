use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::util::{is_valid_hex_64, ValidationError};

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema, PartialEq, Eq)]
pub struct GhostManifest {
    pub name: String,
    pub version: String,
    pub format_version: u32,
    pub created_at: String,
    pub tokenizer: Option<TokenizerRef>,
    pub layers: Vec<LayerDescriptor>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,
}

impl GhostManifest {
    pub fn validate(&self) -> Result<(), ValidationError> {
        if self.name.trim().is_empty() {
            return Err(ValidationError::InvalidField("name".into()));
        }
        if self.version.trim().is_empty() {
            return Err(ValidationError::InvalidField("version".into()));
        }
        if self.format_version == 0 {
            return Err(ValidationError::InvalidField("format_version".into()));
        }
        if self.layers.is_empty() {
            return Err(ValidationError::InvalidField("layers".into()));
        }
        for layer in &self.layers {
            layer.validate()?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema, PartialEq, Eq)]
pub struct TokenizerRef {
    pub kind: String,      // z. B. "hf", "sentencepiece"
    pub reference: String, // z. B. Modellname oder Pfad
}

#[derive(Debug, Clone, Serialize, Deserialize, JsonSchema, PartialEq, Eq)]
pub struct LayerDescriptor {
    pub name: String,
    pub kind: String, // z. B. "tensor", "vocab", "config"
    pub sha3_256: String,
    pub size_bytes: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<serde_json::Value>,
}

impl LayerDescriptor {
    pub fn validate(&self) -> Result<(), ValidationError> {
        if self.name.trim().is_empty() {
            return Err(ValidationError::InvalidField("layers[].name".into()));
        }
        if self.kind.trim().is_empty() {
            return Err(ValidationError::InvalidField("layers[].kind".into()));
        }
        if !is_valid_hex_64(&self.sha3_256) {
            return Err(ValidationError::InvalidHashFormat);
        }
        Ok(())
    }
}
