use sha3::{Digest, Sha3_256};
use std::io::Read;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum ValidationError {
    #[error("invalid field: {0}")]
    InvalidField(String),
    #[error("invalid sha3-256 hex format")]
    InvalidHashFormat,
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
}

pub fn compute_sha3_256_hex(mut reader: impl Read) -> Result<String, ValidationError> {
    let mut hasher = Sha3_256::new();
    let mut buffer = [0u8; 8192];
    loop {
        let n = reader.read(&mut buffer)?;
        if n == 0 {
            break;
        }
        hasher.update(&buffer[..n]);
    }
    Ok(hex::encode(hasher.finalize()))
}

pub fn is_valid_hex_64(s: &str) -> bool {
    if s.len() != 64 {
        return false;
    }
    s.chars().all(|c| c.is_ascii_hexdigit())
}

pub fn is_valid_hash(s: &str) -> bool {
    if let Some(rest) = s.strip_prefix("sha3-256:") {
        return is_valid_hex_64(rest);
    }
    is_valid_hex_64(s)
}
