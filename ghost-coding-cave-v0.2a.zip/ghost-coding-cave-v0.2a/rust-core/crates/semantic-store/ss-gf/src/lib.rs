pub mod converters;
pub mod manifest;
pub mod util;

pub use converters::{
    ConverterError, GgufConversionConfig, GgufConverter, GgufMetadata, OnnxConversionConfig,
    OnnxConverter, OnnxMetadata,
};
pub use manifest::{GhostManifest, LayerDescriptor, TokenizerRef};
pub use util::{compute_sha3_256_hex, ValidationError};

#[cfg(test)]
mod tests {
    use super::*;
    use schemars::schema_for;

    #[test]
    fn schema_generation_works() {
        let _schema = schema_for!(GhostManifest);
        // Smoke test: ensure schema can be produced without panic
    }

    #[test]
    fn hash_computation_matches_expected() {
        let data = b"hello ghost";
        let hash = compute_sha3_256_hex(&data[..]).expect("hash");
        assert_eq!(hash.len(), 64);
        assert!(hash.chars().all(|c| c.is_ascii_hexdigit()));
    }

    #[test]
    fn manifest_roundtrip_and_validate() {
        let manifest = GhostManifest {
            name: "demo".into(),
            version: "0.1.0".into(),
            format_version: 1,
            created_at: "2025-10-30T00:00:00Z".into(),
            tokenizer: Some(TokenizerRef {
                kind: "hf".into(),
                reference: "bert-base-uncased".into(),
            }),
            layers: vec![LayerDescriptor {
                name: "weights".into(),
                kind: "tensor".into(),
                sha3_256: "a7b1a5a6a6d7e52bb0c9b3f1e3cd0b2ed96915e28d9891fb2be69a8eac9b1f1a".into(),
                size_bytes: 12,
                metadata: None,
            }],
            metadata: None,
        };

        manifest.validate().expect("valid");
        let json = serde_json::to_string_pretty(&manifest).expect("serialize");
        let decoded: GhostManifest = serde_json::from_str(&json).expect("deserialize");
        decoded.validate().expect("valid-after-decode");
    }
}
