use serde::{Deserialize, Serialize};
use ss_gf::GhostManifest;
use std::fs::File;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use tar::{Builder as TarBuilder, Header as TarHeader};
use thiserror::Error;

#[derive(Debug, Error)]
pub enum PackError {
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    #[error("serde json error: {0}")]
    Serde(#[from] serde_json::Error),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleHeader {
    pub magic: [u8; 6],        // b"GHOST\0"
    pub version: u16,          // 1
    pub flags: u32,            // Bitflags (z. B. 1 = zstd)
    pub manifest_path: String, // Pfad im Tar (z. B. manifest.json)
}

impl Default for CapsuleHeader {
    fn default() -> Self {
        Self {
            magic: *b"GHOST\0",
            version: 1,
            flags: 0,
            manifest_path: "manifest.json".into(),
        }
    }
}

pub struct PackOptions {
    pub use_zstd: bool,
}

impl Default for PackOptions {
    fn default() -> Self {
        Self { use_zstd: false }
    }
}

pub fn pack_capsule(
    output: &Path,
    header: &CapsuleHeader,
    manifest: &GhostManifest,
    files: &[(PathBuf, PathBuf)],
    opts: PackOptions,
) -> Result<(), PackError> {
    let out = File::create(output)?;
    // Optional: ZSTD wrap
    let mut writer: Box<dyn Write> = if opts.use_zstd {
        Box::new(zstd::stream::write::Encoder::new(out, 3)?.auto_finish())
    } else {
        Box::new(out)
    };

    // 1) Schreibe festen Header (einfach als JSON vor dem Tar)
    let header_json = serde_json::to_vec(header)?;
    writer.write_all(&(header_json.len() as u32).to_le_bytes())?;
    writer.write_all(&header_json)?;

    // 2) Erzeuge Tar-Archiv
    let mut tar_builder = TarBuilder::new(writer);

    // 2a) manifest.json hinzufügen
    let manifest_bytes = serde_json::to_vec_pretty(manifest)?;
    let mut hdr = TarHeader::new_gnu();
    hdr.set_path(&header.manifest_path)?;
    hdr.set_size(manifest_bytes.len() as u64);
    hdr.set_cksum();
    tar_builder.append(&hdr, &manifest_bytes[..])?;

    // 2b) Nutzdateien hinzufügen: (logical_path, source_path)
    for (logical_path, src_path) in files.iter() {
        let mut file = File::open(src_path)?;
        let mut buf = Vec::new();
        file.read_to_end(&mut buf)?;
        let mut hdr = TarHeader::new_gnu();
        hdr.set_path(logical_path)?;
        hdr.set_size(buf.len() as u64);
        hdr.set_cksum();
        tar_builder.append(&hdr, &buf[..])?;
    }

    tar_builder.finish()?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use ss_gf::{LayerDescriptor, TokenizerRef};
    use std::io::Read;
    use tempfile::tempdir;

    #[test]
    fn pack_roundtrip_smoke() {
        let dir = tempdir().unwrap();
        let out = dir.path().join("model.ghost");

        let manifest = GhostManifest {
            name: "demo".into(),
            version: "0.1.0".into(),
            format_version: 1,
            created_at: "2025-10-30T00:00:00Z".into(),
            tokenizer: Some(TokenizerRef {
                kind: "hf".into(),
                reference: "bert-base-uncased".into(),
            }),
            layers: vec![LayerDescriptor {
                name: "weights".into(),
                kind: "tensor".into(),
                sha3_256: "0".repeat(64),
                size_bytes: 0,
                metadata: None,
            }],
            metadata: None,
        };
        manifest.validate().unwrap();

        let header = CapsuleHeader::default();
        pack_capsule(
            &out,
            &header,
            &manifest,
            &[],
            PackOptions { use_zstd: false },
        )
        .unwrap();

        // Lese ersten 4 Bytes (Länge), dann Header-JSON prüfen
        let mut f = File::open(&out).unwrap();
        let mut len_buf = [0u8; 4];
        f.read_exact(&mut len_buf).unwrap();
        let header_len = u32::from_le_bytes(len_buf) as usize;
        let mut header_buf = vec![0u8; header_len];
        f.read_exact(&mut header_buf).unwrap();
        let decoded: CapsuleHeader = serde_json::from_slice(&header_buf).unwrap();
        assert_eq!(&decoded.magic, b"GHOST\0");
        assert_eq!(decoded.manifest_path, "manifest.json");
    }
}
