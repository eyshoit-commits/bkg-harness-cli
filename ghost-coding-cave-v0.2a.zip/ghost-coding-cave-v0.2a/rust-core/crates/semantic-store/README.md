# semantic-store

Monorepo für das AI Modellverwaltungssystem (Semantic-Store) – mit Multi-Format-Support, `.ghost`-Modellen, CLI und API.

## Struktur

- **ss-api**  – HTTP/gRPC API Service
- **ss-cli**  – Befehlszeilen-Tool für Verwaltung und Konvertierung
- **ss-core** – Zentrale Geschäftslogik
- **ss-gf**   – Ghost-Format: Manifest, Serialisierung, Konvertierung
- **ss-gp**   – Ghost-Pack: Kapsel/Containerisierung

## Entwicklung

1. Rust [cargo](https://doc.rust-lang.org/cargo/):
   - `cd semantic-store`
   - `cargo build`
2. Weitere Infos: siehe AGENTS.md im Wurzelverzeichnis.

---

Siehe `AGENTS.md` für Roadmap, Architektur und Todos.
