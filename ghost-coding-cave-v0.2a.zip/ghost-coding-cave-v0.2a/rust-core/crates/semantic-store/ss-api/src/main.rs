use axum::extract::Multipart;
use axum::{
    extract::State,
    routing::{get, post},
    Json, Router,
};
use schemars::schema_for;
use serde::{Deserialize, Serialize};
use ss_core::SemanticStoreCore;
use ss_gf::GhostManifest;
use ss_gp::{pack_capsule, CapsuleHeader, PackOptions};
use std::{net::SocketAddr, path::PathBuf, sync::Arc};
use tokio::{fs, io::AsyncWriteExt};
use tracing::{info, Level};
use tracing_subscriber::EnvFilter;

#[derive(Clone)]
struct AppState {
    storage_dir: PathBuf,
    core: Arc<SemanticStoreCore>,
}

#[derive(Serialize, Deserialize)]
struct CreateModelPayload {
    name: String,
    provider: Option<String>,
    format: Option<String>,
}

#[derive(Serialize, Deserialize)]
struct UpsertTokenizerPayload {
    name: String,
    spec: serde_json::Value,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive(Level::INFO.into()))
        .init();

    let storage = std::env::var("SS_STORAGE").unwrap_or_else(|_| "./data".into());
    fs::create_dir_all(&storage).await.ok();
    let _ = fs::create_dir_all(format!("{}/uploads", storage)).await;
    let _ = fs::create_dir_all(format!("{}/capsules", storage)).await;

    let core = Arc::new(SemanticStoreCore::open(&storage).expect("open store"));
    let state = AppState {
        storage_dir: storage.into(),
        core,
    };

    let app = Router::new()
        .route("/healthz", get(health))
        .route("/health", get(health))
        .route("/v1/ghost/manifest/validate", post(manifest_validate))
        .route("/v1/ghost/manifest/schema", get(manifest_schema))
        .route("/v1/ghost/pack", post(pack))
        // simple model/tokenizer CRUD over our own store
        .route("/v1/models", get(list_models).post(create_model))
        .route(
            "/v1/tokenizers",
            get(list_tokenizers).post(upsert_tokenizer),
        )
        .with_state(state);

    let addr: SocketAddr = "0.0.0.0:8443".parse().unwrap();
    info!(%addr, "ss-api listening");
    axum::serve(tokio::net::TcpListener::bind(addr).await.unwrap(), app)
        .await
        .unwrap();
}

async fn health() -> &'static str {
    "ok"
}

#[derive(Serialize)]
struct ValidateResponse {
    ok: bool,
}

async fn manifest_validate(Json(mf): Json<GhostManifest>) -> Json<ValidateResponse> {
    mf.validate().expect("manifest invalid");
    Json(ValidateResponse { ok: true })
}

async fn manifest_schema() -> Json<serde_json::Value> {
    let schema = schema_for!(GhostManifest);
    Json(serde_json::to_value(&schema).unwrap())
}

// Multipart Felder:
// - manifest: JSON-Datei
// - file: beliebig viele Nutzdateien (Name als logischer Pfad)
async fn pack(State(state): State<AppState>, mut mp: Multipart) -> Result<Vec<u8>, String> {
    let mut manifest: Option<GhostManifest> = None;
    let mut files: Vec<(PathBuf, PathBuf)> = Vec::new();

    while let Some(field) = mp.next_field().await.map_err(err_str)? {
        let name = field.name().map(|s| s.to_string());
        let file_name = field.file_name().map(|s| s.to_string());
        let bytes = field.bytes().await.map_err(err_str)?;

        match name.as_deref() {
            Some("manifest") => {
                let mf: GhostManifest = serde_json::from_slice(&bytes).map_err(err_str)?;
                mf.validate().map_err(err_str)?;
                manifest = Some(mf);
            }
            Some("file") => {
                let logical = file_name
                    .clone()
                    .ok_or_else(|| "file field requires filename".to_string())?;
                let tmp_path = state
                    .storage_dir
                    .join("uploads")
                    .join(format!("upload_{}", nanoid::nanoid!()));
                let mut f = fs::File::create(&tmp_path).await.map_err(err_str)?;
                f.write_all(&bytes).await.map_err(err_str)?;
                files.push((PathBuf::from(logical), tmp_path));
            }
            _ => {}
        }
    }

    let manifest = manifest.ok_or_else(|| "manifest part missing".to_string())?;

    let out_path = state
        .storage_dir
        .join("capsules")
        .join(format!("{}.ghost", nanoid::nanoid!()));
    // synchrones Packen in Blocking-Task, da tar/zstd blockierend arbeiten
    let header = CapsuleHeader::default();
    let out_path_cl = out_path.clone();
    let files_owned = files.clone();
    let manifest_owned = manifest.clone();
    tokio::task::spawn_blocking(move || {
        pack_capsule(
            &out_path_cl,
            &header,
            &manifest_owned,
            &files_owned,
            PackOptions { use_zstd: true },
        )
    })
    .await
    .map_err(err_str)
    .and_then(|r| r.map_err(err_str))?;

    // Datei zurückliefern
    let bytes = fs::read(&out_path).await.map_err(err_str)?;
    // Aufräumen temporärer Dateien
    for (_, p) in files {
        let _ = fs::remove_file(p).await;
    }
    let _ = fs::remove_file(out_path).await;
    Ok(bytes)
}

fn err_str<E: std::fmt::Display>(e: E) -> String {
    e.to_string()
}

async fn list_models(State(state): State<AppState>) -> Json<Vec<ss_core::ModelRecord>> {
    Json(state.core.list_models())
}

async fn create_model(
    State(state): State<AppState>,
    Json(body): Json<CreateModelPayload>,
) -> Result<Json<ss_core::ModelRecord>, String> {
    let rec = state
        .core
        .create_model(&body.name, body.provider.as_deref(), body.format.as_deref())
        .map_err(err_str)?;
    Ok(Json(rec))
}

async fn list_tokenizers(State(state): State<AppState>) -> Json<Vec<ss_core::TokenizerRecord>> {
    Json(state.core.list_tokenizers())
}

async fn upsert_tokenizer(
    State(state): State<AppState>,
    Json(body): Json<UpsertTokenizerPayload>,
) -> Result<Json<ss_core::TokenizerRecord>, String> {
    let rec = state
        .core
        .upsert_tokenizer(&body.name, body.spec)
        .map_err(err_str)?;
    Ok(Json(rec))
}
