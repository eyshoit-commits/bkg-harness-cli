# Changelog Live – Session v0.3a

**Status:** 🟢 **LIVE** – Semantic Store is now the single data layer. API is stateless HTTP gateway.

**Current Date:** 31. Oktober 2025  
**Session Version:** 0.3a  
**Last Update:** 23:52 UTC+1

---

## Summary

| Component | Status | Last Change | Time |
|-----------|--------|-------------|------|
| Semantic Store | 🟢 Live | Single DB, no Postgres/Redis | 23:52 |
| API Gateway | 🟢 Live | Prisma removed, stateless | 23:51 |
| Dashboard | 🟢 Live | Connected to API gateway | — |
| CLI `ghost-pack` | ✅ Ready | All 20/20 tests passing | v0.2a |

---

## Recent Changes

### Operation 1: Remove Prisma (23:50 UTC+1)
- **File:** `/apps/api/src/database/database.service.ts`
- **Change:** Removed `import { prisma } from '@ghost/database'` and all client initialization
- **Status:** ✅ Complete
- **Impact:** API no longer has database dependency

### Operation 2: Create Database Stub (23:51 UTC+1)
- **File:** `/apps/api/src/database/database.stub.ts` (new)
- **Change:** Created stub service with optional mocks for testing
- **Status:** ✅ Complete
- **Impact:** Clean error messages if DB is accidentally accessed

### Operation 3: Semantic Store Live (23:52 UTC+1)
- **Files:** 
  - `/semantic-store/ss-api/src/main.rs`
  - `/semantic-store/ss-core/src/lib.rs`
  - `/docker-compose.yml`
- **Change:** Verify ss-api is production-ready; ensure all endpoints respond correctly
- **Status:** ⏳ In Progress
- **Impact:** Single data layer, all reads/writes via HTTP to ss-api

---

## Architecture

```
Dashboard (Next.js @ :4004)
    ↓ HTTP
API Gateway (NestJS @ :3000)
    ↓ HTTP (stateless)
Semantic Store API (Rust @ :4011)
    ↓ persist
SS_STORAGE (/data/semantic-store)
```

**Key:** No local database, no Prisma, no Postgres. Everything goes through ss-api.

---

## Endpoints (Live)

### Semantic Store (ss-api @ :4011)
- `GET /v1/models` – List all models
- `POST /v1/models` – Create/register model
- `GET /v1/tokenizers` – List tokenizers
- `POST /v1/tokenizers` – Upsert tokenizer
- (Coming) `/v1/capsules/*` – Capsule operations with signature validation

### API Gateway (@ :3000)
- `GET /api/models` – Proxy to ss-api
- `POST /api/models` – Proxy to ss-api
- `GET /api/tokenizers` – Proxy to ss-api
- `POST /api/tokenizers` – Proxy to ss-api
- `GET /api/docs` – Swagger documentation

### Dashboard (@ :4004)
- Admin Models tab (read/create)
- Admin Tokenizers tab (read/upsert)

---

## Environment Variables (Active)

```bash
# Semantic Store
SS_STORAGE=/data/semantic-store  # Persistent storage root

# API Gateway
SEMANTIC_STORE_HTTP_URL=http://semantic-store-api:4011
DISABLE_DB=true  # (no effect; DB is always disabled)

# Dashboard
NEXT_PUBLIC_API_URL=http://localhost:3000
```

---

## Next Steps (v0.3b)

1. **Test** ss-api startup and endpoints locally
2. **Add** `/v1/capsules/upload` endpoint with signature validation
3. **Run** E2E tests via CI (GitHub Actions)
4. **Deploy** with docker-compose and verify all services

---

## File Changes Tracked in Progress.json

See `/Patches/Progress.json` for complete operation log with timestamps.

---

**End of Live Changelog**

