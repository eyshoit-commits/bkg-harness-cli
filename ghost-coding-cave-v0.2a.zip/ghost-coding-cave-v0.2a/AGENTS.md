Hier ist der erweiterte **Semantic-Store Integration Plan** mit der Hinzufügung des neuen **.ghost**-Modellformats sowie der Entwicklung eines neuen Modellformat-Systems für die Speicherung und Verwaltung von Modellen:

---

### **Semantic-Store Integration Plan (Progress Log)**

---

## **1. Semantic-Store Service aktivieren**

* [x] **1.1 Helper-DB Workspace nach `services/semantic-store` in v0.2a übernehmen.**

  * Der `semantic-store` wurde in das Projekt integriert, und der Workspace wurde entsprechend übernommen.
* [ ] **1.2 Cargo/Workspace-Konfigurationen im Rust-Core aktualisieren.**

  * Cargo- und Workspace-Konfigurationen müssen an die neue **semantic-store**-Struktur angepasst werden.
* [ ] **1.3 Docker/Compose-Einträge (Ports 8443/9443) und Volumes definieren.**

  * Docker-Compose muss aktualisiert werden, um den **semantic-store**-Service korrekt zu integrieren, inklusive Volumes und Ports.
* [ ] **1.4 WAL/Snapshot-Verzeichnisse konfigurieren, Seed/Init-Skripte vorbereiten.**

  * Konfiguration von Write-Ahead-Logging (WAL) und Snapshot-Verzeichnissen, um Datenbankintegrität und Backup zu gewährleisten.
  * Seed-Skripte zum Initialisieren von Daten in der **semantic-store**-Datenbank vorbereiten.

---

## **2. Registry-Anbindung (AI-Server & Adapter)**

* [ ] **2.1 Stub-Registry im `ai-server` durch semantic-store Abfragen ersetzen.**

  * Der Stub-Registry im AI-Server muss durch Abfragen von **semantic-store** ersetzt werden, um reale Modelle und Tokenizer zu laden.
* [ ] **2.2 `helper-core` an semantic-store koppeln (Analysis/Planner/Agents).**

  * Das **helper-core** muss an den **semantic-store** angebunden werden, um die Module `Analysis`, `Planner`, und `Agents` mit echten Daten zu versorgen.
* [ ] **2.3 `semantic-adapter` & `storage-adapter` auf Store-APIs umstellen.**

  * Die Adapter müssen so angepasst werden, dass sie über die neuen **semantic-store**-APIs auf die Daten zugreifen.
* [ ] **2.4 Gemeinsame Auth/Config (Env, gRPC/HTTP Client) etablieren.**

  * Authentifizierung und Konfiguration (z. B. Umgebungsvariablen, gRPC/HTTP-Clients) müssen für den Zugriff auf **semantic-store** standardisiert werden.

---

## **3. Admin-Dashboard & Service-Steuerung**

* [ ] **3.1 UI-Flows für Modell-Download/Registrierung (GGUF/ONNX/Transformers).**

  * Die Benutzeroberfläche für das Admin-Dashboard muss Flows implementieren, die es ermöglichen, Modelle in verschiedenen Formaten (GGUF, ONNX, Transformers) herunterzuladen und zu registrieren.
* [ ] **3.2 Modellverwaltung (anzeigen, aktualisieren, löschen, Tokenizer konfigurieren).**

  * Admins sollen Modelle anzeigen, aktualisieren und löschen können. Außerdem muss eine Möglichkeit bestehen, Tokenizer zu konfigurieren und zu verwalten.
* [ ] **3.3 Service Controls (Start/Stop/Restart) für semantic-store, AI-Server, Gateway.**

  * Im Dashboard müssen Steuerungsfunktionen (Start, Stop, Restart) für den **semantic-store**, **AI-Server** und **Gateway** verfügbar sein.
* [ ] **3.4 Echtzeitstatus für Modelle, Trainingsjobs, Metriken integrieren.**

  * Echtzeit-Statusaktualisierungen für Modelle, Trainingsjobs und relevante Metriken müssen im Dashboard angezeigt werden.

---

## **4. Multi-Format-Support & Tokenizer**

* [ ] **4.1 Loader/Adapter für GGUF, ONNX, Transformers implementieren.**

  * Implementierung von Loaders/Adaptern für verschiedene Modellformate wie **GGUF**, **ONNX** und **Transformers**.
* [ ] **4.2 Format-Autodetektion und Inferenzpfade im AI-Server/Helper-Core.**

  * Der **AI-Server** und **Helper-Core** müssen automatisch erkennen, welches Modellformat vorliegt, und den richtigen Inferenzpfad anwenden.
* [ ] **4.3 Tokenizer-Upload & Zuordnung im semantic-store API/UI.**

  * Die Möglichkeit, Tokenizer hochzuladen und mit entsprechenden Modellen zu verbinden, muss im **semantic-store** API und UI verfügbar sein.

---

## **5. Einführung des neuen `.ghost` Modellformats**

### **Phase 1: Core Format Foundations**
* [ ] **5.1 `ghost-format` crate entwickeln.**

  * Definiere `GhostManifest` (Modellmetadaten, Layer, Policies) + Serde-Serialisierung.
  * Biete Hashing-Helfer (sha3-256) für Payload-Verifikation.
  * JSON Schema & Validierungs-API für Manifeste.
* [ ] **5.2 Capsule Container Helpers implementieren.**

  * Implementiere Header (Magic/Version/Flags/Manifest Offset).
  * Tar-basierter Payload-Bundler + optionale zstd-Kompression.
  * Unit-Tests für Round-Trip (Erstellen → Lesen → Validieren).
  * Alle Komponenten werden unter dem neuen Namen `semantic-store-*` integriert, z. B. `semantic-store-core`, `semantic-store-cli`, etc.

### **Phase 2: Format Conversion & Tools**
* [ ] **5.3 .ghost Modellformat-System entwickeln.**

  * Ein neues Modellformatsystem für **.ghost** wird entwickelt, das sicherstellt, dass alle Modelle in dieses Format konvertiert werden, um eine standardisierte Speicherung und Verwendung im **semantic-store** zu ermöglichen.
  * Definiere ein Modellformat, das Metadaten, Modellgewichtungen und Tokenizer enthält, und als `.ghost`-Datei gespeichert wird.
* [ ] **5.4 Modelle in `.ghost` Format umwandeln.**

  * Entwickle einen Mechanismus, um bestehende Modelle (z. B. GGUF, ONNX, Transformers) in das **.ghost**-Format zu konvertieren. Dies umfasst das Speichern von Modellgewichtungen, Tokenizern und relevanten Metadaten im neuen Format.
  * Füge eine Funktionalität hinzu, die automatisch **GGUF**, **ONNX** und **Transformers**-Modelle beim Speichern in den **semantic-store** in das **.ghost**-Format umwandelt.
* [ ] **5.5 CLI-Tool für Konvertierung und Validierung.**

  * Erstelle ein Kommandozeilen-Tool, das Modelle von verschiedenen Formaten in `.ghost` konvertiert und die Integrität validiert.
  * Unterstütze Batch-Konvertierung und Fehlerberichterstattung.

### **Phase 3: Integration & Runtime Support**
* [ ] **5.6 Integration des .ghost Formats in das Modelldatenbanksystem.**

  * Integriere die Unterstützung für das **.ghost**-Format in das **semantic-store**, sodass Modelle im neuen Format ordnungsgemäß gespeichert, abgerufen und genutzt werden können.
* [ ] **5.7 Runtime-Loader für .ghost Modelle.**

  * Implementiere einen Loader im AI-Server, der `.ghost`-Dateien zur Laufzeit lädt und für Inferenz vorbereitet.
  * Füge Caching-Mechanismen hinzu, um Ladezeiten zu optimieren.
* [ ] **5.8 Plugin-System für erweiterte Features.**

  * Entwickle ein Plugin-System, das es ermöglicht, benutzerdefinierte Verarbeitungsschritte (z. B. Quantisierung, Optimierung) in das `.ghost`-Format zu integrieren.
  * Ermögliche dynamisches Laden von Plugins zur Laufzeit.

### **Phase 4: Advanced Features & Ecosystem**
* [ ] **5.9 Versionierung und Update-Mechanismen.**

  * Implementiere Versionierung für `.ghost`-Modelle, um Updates und Rollbacks zu unterstützen.
  * Erstelle Mechanismen für inkrementelle Updates ohne vollständiges Neuladen.
* [ ] **5.10 Cross-Platform Compatibility & Distribution.**

  * Stelle sicher, dass `.ghost`-Formate auf verschiedenen Plattformen (Linux, Windows, macOS) kompatibel sind.
  * Entwickle ein Distributionssystem für das Teilen und Herunterladen von `.ghost`-Modellen über ein Registry.
* [ ] **5.11 Monitoring und Analytics für .ghost Modelle.**

  * Integriere Metriken zur Verfolgung von Modellnutzung, Performance und Fehlern im `.ghost`-Format.
  * Füge Analytics hinzu, um Einblicke in Modellverhalten zu gewinnen.

### **Phase 5: Security, Extensibility & Community**
* [ ] **5.12 Security Enhancements für .ghost Modelle.**

  * Implementiere Verschlüsselung für Payloads (z. B. AES-256) und digitale Signaturen zur Integritätsprüfung.
  * Füge Access-Control-Listen (ACLs) hinzu, um den Zugriff auf Modelle basierend auf Benutzerrollen zu steuern.
* [ ] **5.13 Streaming und Performance-Optimierungen.**

  * Entwickle Streaming-Support für große `.ghost`-Modelle, um Ladezeiten zu reduzieren und Speicher zu schonen.
  * Integriere Lazy-Loading für Layer, um nur benötigte Teile des Modells zu laden.
* [ ] **5.14 Erweiterte Metadaten und Custom Schemas.**

  * Erlaube benutzerdefinierte Metadaten-Schemas im `GhostManifest`, um branchenspezifische Erweiterungen zu unterstützen (z. B. für Medizin- oder Finanz-Modelle).
  * Biete Tools zur Validierung und Migration von Schemas.
* [ ] **5.15 Integrationstests und CI/CD Pipeline.**

  * Erstelle umfassende Integrationstests für den gesamten `.ghost`-Pipeline (Konvertierung, Speicherung, Laden, Inferenz).
  * Integriere Tests in die CI/CD-Pipeline mit automatischer Validierung neuer Modelle.
* [ ] **5.16 Community und Ökosystem-Aufbau.**

  * Erstelle eine Open-Source-Registry für `.ghost`-Modelle, inklusive Upload-Tools und Community-Beiträge.
  * Entwickle Tutorials und Beispiele für die Erstellung und Nutzung von `.ghost`-Modellen in verschiedenen Anwendungsfällen.

---

## **6. Docker- & DevOps-Erweiterungen**

* [ ] **6.1 Compose/CI anpassen: semantic-store Service, Volumes, Healthchecks.**

  * Docker-Compose und CI-Konfigurationen müssen so angepasst werden, dass der **semantic-store**-Service korrekt integriert wird und Healthchecks unterstützt.
* [ ] **6.2 Monitoring: semantic-store-metrics + Jaeger/Prometheus in Stack integrieren.**

  * Monitoring-Tools wie **Jaeger** für Distributed Tracing und **Prometheus** für Metriken müssen in den Stack integriert werden, um den **semantic-store** und andere Services zu überwachen.
* [ ] **6.3 Deploy/OPS-Guides aktualisieren (Startreihenfolge, Backups, Logs).**

  * Die Bereitstellungs- und Operations-Guides müssen aktualisiert werden, um die Startreihenfolge der Services, Backup-Strategien und das Log-Management für den **semantic-store** zu berücksichtigen.

---

## **7. APIs, Tests & Dokumentation**

* [ ] **7.1 REST/gRPC-Endpunkte für Store/Modelle/Plugins/Jobs aktivieren.**

  * REST- und gRPC-Endpunkte müssen für den Zugriff auf den **semantic-store**, Modelle, Plugins und Jobs bereitgestellt werden.
* [ ] **7.2 Integrationstests für Datenbankzugriffe, Indexe, Inferenzpfade erstellen.**

  * Integrationstests müssen entwickelt werden, um sicherzustellen, dass die Datenbankabfragen, Indizes und Inferenzpfade korrekt funktionieren.
* [ ] **7.3 Dokumentation: `STATUS.md`, `AGENTS.md`, `API_REFERENCE.md`, `PRODUCTION_READINESS.md`, `OPS_CHECKLIST.md` synchronisieren.**

  * Alle relevanten Dokumentationen müssen aktualisiert und synchronisiert werden, um die Funktionsweise des **semantic-store** und der API zu beschreiben.
* [ ] **7.4 Admin-/CLI-Workflow beschreiben (Seed, Snapshot, Training, Plugin Mgmt).**

  * Die Workflow-Dokumentation für Administratoren und CLI-Nutzer muss erstellt werden, einschließlich Anleitungen zum Seed, Snapshot, Training und Plugin-Management.

---

### **Zusammenfassung und Fortschritt:**

* **Aktuell abgeschlossen:** Schritt 1.1 (Übernahme des Workspaces für den `semantic-store` in v0.2a).
* **Nächste Schritte:** Fortschritte in den Bereichen **Registry-Anbindung**, **Admin-Dashboard & Service-Steuerung** und **Einführung des neuen `.ghost` Formats**.

---

### **Neue Namenskonvention für Semantic-Store Struktur**

```
semantic-store/
├─ ss-api/
│  └─ Cargo.toml
├─ ss-cli/
│  └─ Cargo.toml
├─ ss-core/
│  └─ Cargo.toml
├─ ss-gf/        # früher ghost-format
│  └─ Cargo.toml
├─ ss-gp/        # früher ghost-pack
│  └─ Cargo.toml
├─ Cargo.toml
```

Ich finde deine Herangehensweise sehr gut! Es macht Sinn, die Namenskonventionen zu vereinheitlichen, vor allem für eine saubere und wartungsfreundliche Struktur. Die Idee, den Hauptordner als **`semantic-store`** zu behalten und dann die Unterordner (wie **`semantic-store-api`**, **`semantic-store-cli`**) auf kürzere Namen wie **`ss-api`**, **`ss-cli`** usw. zu verkürzen, hat mehrere Vorteile:

#### **Vorteile dieser Umstellung**:

1. **Kürzere und prägnantere Namen**:

   * **`ss-api`** und **`ss-cli`** sind kürzer und leichter zu schreiben, was die Handhabung und den Umgang mit diesen Komponenten in der Entwicklung und in der Dokumentation vereinfacht.

2. **Vermeidung von übermäßigen Unterstrichen**:

   * Durch die Reduzierung von Unterstrichen werden die Namen klarer und besser lesbar. Das entspricht auch der typischen Rust-Konvention, die bei Crate-Namen eher auf Bindestriche setzt (z.B. `ss-api` statt `semantic-store-api`).

3. **Einheitlichkeit**:

   * Eine konsistente und kompakte Namensgebung sorgt für mehr Klarheit und hilft auch dabei, die Module miteinander zu verbinden, ohne sich an verschiedene, potenziell lange Namenskonventionen erinnern zu müssen.

4. **Zukunftssicherheit**:

   * Du behältst den Hauptordner als **`semantic-store`**, was es klar macht, dass dies das übergeordnete System ist, während die Unterordner die verschiedenen Teile des Systems representieren (API, CLI, Core). Diese Struktur bleibt flexibel und lässt sich leicht erweitern, wenn neue Komponenten hinzugefügt werden müssen.

#### **Kleine Überlegungen**:

* **Kompatibilität mit bestehenden Abhängigkeiten**: Wenn du externe Abhängigkeiten hast, die auf den alten Namen (`semantic-store-api`, etc.) verweisen, musst du sicherstellen, dass auch diese korrekt umgestellt werden. Das betrifft sowohl die `Cargo.toml`-Dateien als auch mögliche Imports im Code.
* **Dokumentation**: Es wäre gut, nach der Umstellung die Dokumentation entsprechend anzupassen, damit andere Entwickler den neuen Namenskonventionen leicht folgen können.

#### **Fazit**:

