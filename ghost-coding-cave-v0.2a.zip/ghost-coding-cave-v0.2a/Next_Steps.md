---

# ⚙️ Ghost-Coding-Cave — Update-Protokoll

## 1. Zentrale Regel

**Nichts wird ausgeführt, gebaut oder committet, bevor `/Next_Steps.md` geprüft und aktualisiert wurde.**
Diese Datei ist die einzige „Quelle der Wahrheit“ für den aktuellen Arbeitsstand und die nächsten Aktionen.

---

## 2. Ablauf für jede Änderung

1. **Vor jeder Aktion:**

   * Lies `Next_Steps.md`.
   * Führe nur Schritte aus, die dort als `⚙️ laufend` oder `🧩 geplant` markiert sind.
   * Wenn du etwas Neues tun willst → **erst eintragen**, dann umsetzen.

2. **Während der Arbeit:**

   * Technische Zwischenergebnisse (Befehle, Tests, Pfade) **nur** in `Next_Steps.md` unter “🔨 Umsetzung” loggen.
   * Kein Duplikat in `Changelog_Live.md`.

3. **Nach Abschluss eines Tasks:**

   * In `Next_Steps.md`: Checkbox von `⚙️` → `✅`.
   * In `Changelog_Live.md`: Ein sauberer, kurzer Abschnitt mit Zeitstempel und Ergebnis.
   * In `Progress.json`: `status`, `phase` und `last_update` aktualisieren.

---

## 3. Synchronisationsregeln

| Datei               | Auslöser                               | Quelle                  |
| ------------------- | -------------------------------------- | ----------------------- |
| `Next_Steps.md`     | **Vor** jeder Codeänderung             | Handbuch & Planung      |
| `Changelog_Live.md` | **Nach** erfolgreicher Umsetzung       | `Next_Steps.md`         |
| `Progress.json`     | **Automatisch** nach Commit oder Build | aus `Next_Steps.md`     |
| `docs/releases/*`   | **Nur bei Versionsabschluss**          | aus `Changelog_Live.md` |

---

## 4. Schutz gegen Doppelcode

* Keine Code-Snippets oder Shell-Kommandos doppelt loggen.
* `Next_Steps.md` = *Planung und Ausführung*
* `Changelog_Live.md` = *Ergebnis und Zusammenfassung*
* Niemals dieselbe Zeile Code oder denselben Output in beiden Dateien.

**Beispiel:**

In `Next_Steps.md`

```markdown
## 🔨 Umsetzung
- Angelegt: ss-core/src/snapshot.rs
- Implementiert: atomic_write_snapshot(), recover_latest_snapshot()
```

In `Changelog_Live.md`

```markdown
## [2025-10-31 23:15] – Snapshot System Ready
- ✨ Feature: Atomic snapshot/recovery in ss-core
- 📁 Files: ss-core/src/snapshot.rs, ss-api/src/routes/admin.rs
```

---

## 5. Prüfung vor Merge oder Commit

* Prüfe zuerst, ob der letzte Eintrag in `Next_Steps.md` **geschlossen** ist (✅).
* Wenn nein → commit **nicht erlaubt**.
* `Changelog_Live.md` und `Progress.json` müssen auf denselben Zeitstempel zeigen (`last_update` identisch).

---

## 6. Automatische Kontrolle (geplant)

* Ein optionales `pre-commit`-Hook prüft:

  * `Next_Steps.md` hat keinen offenen Task ohne Ergebnis.
  * `Changelog_Live.md` enthält keinen doppelten Zeitstempel.
  * `Progress.json` ist valides JSON.
* Wenn ein Check fehlschlägt → Commit abgebrochen.

---

Wenn du willst, kann ich jetzt:

1. diese Regeln direkt **am Kopf von `Next_Steps.md`** einfügen (als Markdown-Kommentarblock),
2. und ein kleines `scripts/validate_docs.sh` schreiben, das diese Checks lokal oder im CI ausführt.

**Updated:** 2025-10-31 23:52 UTC+1  
**Status:** 🟢 Semantic Store Live, Prisma Removed  
**Owner:** GitHub Copilot + goose plan

## Goal: Complete Semantic Store integration + CI/CD pipelines + E2E testing

### 0) Guardrails & Logging
- [ ] Add structured logging + RUST_LOG defaults across ss-api and ai-server
- [ ] Health/metrics endpoints extended (counts, schema_version, snapshot info)

### 1) Semantic Store (DB) hardening
- [x] Atomic writes with tempfile + rename for index.json
- [ ] Snapshot/Recovery pipeline
  - [ ] ss-core: snapshot_dir, periodic_snapshot(), recover_latest_snapshot()
  - [ ] ss-api: POST /v1/admin/snapshot, POST /v1/admin/recover/latest
  - [ ] Compose volumes for /data/snapshots and retention policy docs
- [ ] File/Version support (design + stub)
  - [ ] Files: blob store with SHA256/Blake3 content addressing, dedup
  - [ ] Versions: append-only log per cave/project
  - [ ] Index schema_version bump + migration hook
- [ ] Validation/limits
  - [ ] Model/Tokenizer input validation (lengths, allowed chars)
  - [ ] Optional quotas (max models/tokenizers)

### 2) API sync with Store (NEXT AFTER SERVICES VERIFIED)
- [x] Models/Tokenizers switched to ss-api (HTTP client)
- [ ] Add GET/POST for Files/Versions (after store support)
- [ ] Add Admin endpoints to trigger snapshots/recovery

### 3) AI Server sync with Store
- [ ] Replace local registry file with live fetch from ss-api:
  - [ ] ai-server/config: SEMANTIC_STORE_HTTP_URL env support
  - [ ] ai-server: boot sequence fetches /v1/models; caches in memory
  - [ ] Periodic refresh (e.g. every 60s) or SSE/webhook later
  - [ ] Health: include store sync status, last sync timestamp
- [ ] Graceful reload of models on updates without restart

### 4) CI/CD (v0.3b focus)
- [x] API E2E workflow
- [ ] Add ss-api snapshot test in CI
- [ ] Add ai-server sync test (start ss-api -> seed model -> ai-server sees it)
- [ ] Playwright UI sanity workflow for admin tabs

### 5) Ops & Docs
- [x] CHANGELOG.md + docs/releases/v0.2a_ghost-format.md
- [ ] PRODUCTION_READINESS.md with checklist (backups, retention, health, alerts)
- [ ] OPS_CHECKLIST.md (compose, volumes, restore steps)
- [ ] Update docker-compose to include snapshots/WAL volumes and healthchecks

---

## Tracking

**All changes logged in:**
- `/Patches/Progress.json` – Structured operation log with timestamps
- `/Changelog_Live.md` – Current status dashboard
- `/docs/releases/v0.2a_ghost-format.md` – Release notes & post-mortem
- `/CHANGELOG.md` – Root changelog with v0.2a reference

**Done (v0.2a & v0.3a)**
- [x] Restored workspace and fixed compilation
- [x] Implemented .ghost format + CLI
- [x] Ed25519 signing & verification
- [x] Removed Prisma from API
- [x] Semantic Store configured as single DB
- [x] docker-compose updated with ss-api
- [x] Progress tracking in JSON + Markdown

---

## Immediate Actions (v0.3a – This Session)

### ✅ Phase 1: Remove Prisma (DONE)
- [x] Remove prisma client from API
- [x] Create database.stub.ts
- [x] Verify docker-compose Semantic Store config
- [x] Track all changes in Progress.json

### ⚙️ Phase 2: Verify Services Startup (NEXT – DO NOW)
- [ ] Start docker-compose: `docker-compose up -d`
- [ ] Verify all services healthy (semantic-store-api, api, dashboard)
- [ ] Test ss-api endpoints: GET /v1/models, GET /v1/tokenizers
- [ ] Test API gateway proxy: GET /api/models, GET /api/tokenizers
- [ ] Test Dashboard UI loads and connects
- [ ] **Track results in Progress.json**

## 🔨 Umsetzung (Phase 2)

**Startzeitpunkt:** 2025-10-31 23:55 UTC+1

```bash
# Step 1: Start services
cd /home/wind/code/ghost-coding-cave-v0.2a
docker-compose up -d
```

**Expected:** All services healthy
- semantic-store-api ✅
- api ✅
- dashboard ✅

```bash
# Step 2: Wait for health checks
sleep 5
docker-compose ps
```

**Expected:** All statuses "Up"

### ⏳ Phase 3: CLI Integration Tests
- [ ] Create end-to-end test: sign → detached signature → verify
- [ ] Test file: `/services/semantic-store/ss-gf/tests/capsule_lifecycle.rs`
- [ ] Command: `cd services/semantic-store/ss-gf && cargo test capsule_lifecycle`
- [ ] **Track results in Progress.json**

### ⏳ Phase 4: Capsule Upload API
- [ ] Create `/apps/api/src/capsules/capsules.controller.ts`
- [ ] Implement `POST /v1/capsules/upload` with signature validation
- [ ] Store capsule metadata in semantic-store
- [ ] Add E2E test for upload flow
- [ ] **Track results in Progress.json**

### ⏳ Phase 5: GitHub Actions CI/CD
- [ ] Create `.github/workflows/test.yml`
- [ ] Build Rust + run tests
- [ ] Build API + run tests
- [ ] Start services + run E2E tests
- [ ] Collect artifacts (logs, screenshots)
- [ ] **Track results in Progress.json**

---

## ✅ Completed: Copilot-Instructions v0.3a Documentation

**Date:** 2025-10-31 23:58 UTC+1  
**Task:** Generate/update `.github/copilot-instructions.md` for v0.3a  
**Status:** COMPLETE ✅

### 🔨 Umsetzung
- Analyzed existing copilot-instructions.md (v0.2a → outdated)
- Updated Projektüberblick: Prisma-free, Single-DB, Stateless API emphasis
- Revised Architektur: Simplified diagram, HTTP-only flow, no gRPC/PostgreSQL
- Updated Docker & Laufzeitumgebung: New ports (:4011, :3000, :4004), DISABLE_DB=true
- Added NEW Governance & Progress Tracking section (workflow rules + phases)
- Enhanced Testing & Debugging: tsconfig.json exclude fix documented
- Added 4 Production-Ready Appendices:
  1. **Workflow-Diagramm:** Visual representation of Antes→Während→Nachher pattern
  2. **Semantic-Store APIs:** Endpoint table (v1/models, v1/tokenizers, v1/capsules stub, v1/health)
  3. **Docker Compose Profiles:** llm, ai, mirror profiles documented with examples
  4. **CLI Reference (.ghost format):** ghost-pack pack/sign/verify/extract commands + workflow
- Total size: 500 lines (comprehensive yet concise)

### ✅ Ergebnis
- File: `/home/wind/code/ghost-coding-cave-v0.2a/.github/copilot-instructions.md`
- Commit: `b3300831` – "docs: update copilot instructions for v0.3a"
- Tag: `v0.3a-docs` – Annotated tag marking milestone
- Changes: 306 insertions(+), 95 deletions(-)
- Lint: Mock errors (Markdown, not real issues)
- Status: ✅ Production-ready, verbindlich für alle Agents/Devs

### 📝 Key Insights Captured
1. **Stateless Design:** API ist jetzt pure HTTP gateway, Semantic Store ist single source of truth
2. **Governance First:** Workflow rules integrated (Next_Steps.md, Progress.json, Changelog_Live.md)
3. **No Prisma:** Database operations removed from API layer completely
4. **CLI Stable:** Ghost-pack tool documented as production reference
5. **Profiles Optional:** LLM, AI, Mirror services can be activated but not by default

### 🚀 Next Phase Entry Point
Documentation now provides everything needed for **Phase 2: Services Verification**
- All ports documented
- Health check commands provided
- Environment variables listed
- Error handling patterns explained
- Governance workflow clear

---

## Medium-term Todos (v0.3b – Future sessions)
