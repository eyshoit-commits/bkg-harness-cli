---
applyTo: '**'
---
# 🧭 USE.md — Ghost Coding Cave Documentation & Workflow Rules

**Version:** 1.0
**Gültig ab:** 31. Oktober 2025
**Ort:** `/home/wind/code/ghost-coding-cave-v0.2a/USE.md`

---

## 💡 Zweck

Dieses Dokument definiert **verbindliche Standards** für:

* Schreibweise und Struktur von Projekt-Logs
* Pflege der Fortschritts- und Release-Dokumente
* Automatisierte Updates durch KI oder CI
* Einheitliche Kommunikation zwischen Mensch und Maschine

Jede Änderung, jedes Log-Update und jede Release-Datei **muss** diesen Regeln folgen.
Ziel: 100 % nachvollziehbare Historie, reproduzierbare Builds und konsistente Kommunikation.

---

## 🗂️ Dateirollen & Verantwortlichkeiten

| Datei                       | Zweck                                | Besitzer                         |                      |            |
| --------------------------- | ------------------------------------ | -------------------------------- | -------------------- | ---------- |
| `Next_Steps.md`             | Laufendes technisches Arbeitsjournal | Entwickler / KI-Assistent        |                      |            |
| `Patches/Changelog_Live.md` | Live-Protokoll aller Änderungen      | Entwickler / KI-Assistent        |                      |            |
| `Patches/Progress.json`     | Maschinenlesbarer Status-Tracker     | CI / KI-Assistent                |                      |            |
| `docs/releases/vX.Y[a       | b                                    | rc].md`                          | Finale Release Notes | Maintainer |
| `USE.md`                    | Dieses Regelwerk                     | Maintainer (nicht überschreiben) |                      |            |

---

## 🧩 Strukturregeln

### 1️⃣ Next_Steps.md

Chronologisches Arbeitsjournal.

```markdown
# 🧭 [YYYY-MM-DD – Thema]

## 🔨 Umsetzung
(Kurze, präzise Beschreibung der Änderungen und betroffenen Dateien.)

## ✅ Ergebnis
(Kompilierung, Teststatus, Logs.)

## 🚀 Nächste Schritte
- [ ] Aufgabe 1
- [ ] Aufgabe 2
```

**Symbole:**

* ✅ abgeschlossen
* ⚙️ in Arbeit
* 🧩 geplant
* 🚧 blockiert

**Regeln:**

* Nie überschreiben, nur anhängen
* Datum immer im ISO-Format
* Keine Prosa, reine Engineering-Notizen

---

### 2️⃣ Patches/Changelog_Live.md

Live-Protokoll der gesamten Projektentwicklung.

```markdown
## [YYYY-MM-DD HH:MM] – Titel
- ✨ Feature: ...
- 🧰 Fix: ...
- 🧩 Improvement: ...
- 📁 Files: ...
```

**Regeln:**

* Jeder Commit/Build = eigener Abschnitt
* Zeitstempel (UTC oder lokale Zeitzone +1) Pflicht
* Immer mit Bulletpoints
* Am Ende jeder Session automatisch in `docs/releases/` gespiegelt

---

### 3️⃣ Patches/Progress.json

Maschinenlesbarer Status für Tools, CI und KI.

```json
{
  "version": "0.3a",
  "phase": "3.2",
  "last_update": "2025-10-31T07:40:00Z",
  "status": {
    "tests": "20/20",
    "build": "success",
    "ci": "running"
  },
  "next_steps": [
    "Implement snapshot/recovery",
    "Expose /v1/admin endpoints"
  ],
  "notes": "Atomic write implemented; awaiting CI run."
}
```

**Regeln:**

* Immer valides JSON, keine Kommentare
* Zeit im RFC3339-Format
* Pflichtfelder: version, phase, last_update, status, next_steps, notes
* Wird automatisch von Tools/KI aktualisiert

---

### 4️⃣ docs/releases/vX.Y[a|b|rc].md

Finale Release Notes (keine Live-Dateien).

```markdown
# Ghost Coding Cave v0.3a — Snapshot Recovery Release
**Date:** 2025-11-05  
**Status:** Stable  

## 🔍 Summary
(Was wurde erreicht.)

## 📦 Changes
- Feature …
- Fix …

## 🧪 Tests
(Ergebnisse, Coverage.)

## 🧰 Build
(Anleitung zum Reproduzieren.)
```

**Regeln:**

* Nur bei stabilem Release anlegen
* Keine Bearbeitung nach Veröffentlichung
* Wird aus `Changelog_Live.md` generiert

---

## 🧱 Namens- & Strukturkonventionen

| Typ                 | Konvention                       |
| ------------------- | -------------------------------- |
| Release-Datei       | `v0.3a_feature.md`               |
| Patch-Datei         | `Changelog_v0.3a.md`             |
| JSON-Tracker        | `Progress.json`                  |
| Release-Verzeichnis | `docs/releases/`                 |
| Markdown-Format     | UTF-8, Unix-LF                   |
| Zeitangaben         | RFC3339 oder lokale Zeit (UTC+1) |

---

## 🔐 Schreibrechte

| Datei               | Schreibrecht                                     |
| ------------------- | ------------------------------------------------ |
| `Next_Steps.md`     | KI & Entwickler                                  |
| `Changelog_Live.md` | KI & Entwickler                                  |
| `Progress.json`     | KI & CI                                          |
| `docs/releases/*`   | Nur Maintainer                                   |
| `USE.md`            | Nur Maintainer (nicht automatisch überschreiben) |

---

## 🚦 Automatisierungsregeln

1. Jeder bestätigte Task erzeugt automatisch:

   * neuen Block in `Next_Steps.md`
   * Update von `Progress.json`
   * Eintrag in `Changelog_Live.md`

2. Beim Release-Tag:

   * Der letzte Abschnitt aus `Changelog_Live.md` wird nach `docs/releases/vX.Ya.md` kopiert.

3. Kein Tool oder KI darf diese Regeln überschreiben oder ignorieren.
   **Nur Maintainer kann das Regelwerk ändern.**

---

## 🧠 Style Guidelines

* Sprache: **technisch, klar, deutsch mit englischen Fachbegriffen**
* Kein Marketingtext, keine Phrasen
* Nur Markdown, keine eingebetteten HTML-Tags
* Commit Messages: `<type>(scope): message`

  * Beispiel: `feat(ss-core): implement snapshot recovery`
* Zeitangaben: **24h-Format**

---

## 📜 Gültigkeit

Dieses Regelwerk gilt für:

* Alle Commits, Logs, Patches, Automatisierungen und CI-Schritte
* Alle KI- oder menschlichen Beiträge im Projektverzeichnis
* Jede Version ab **v0.3a**

---
**Ende des USE.md Regelwerks**
