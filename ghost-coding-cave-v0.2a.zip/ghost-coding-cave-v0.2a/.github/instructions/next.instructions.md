---
applyTo: '**'
---
# ⚙️ Ghost-Coding-Cave — Update-Protokoll

## 1. Zentrale Regel

**Nichts wird ausgeführt, gebaut oder committet, bevor `/Next_Steps.md` geprüft und aktualisiert wurde.**
Diese Datei ist die einzige „Quelle der Wahrheit“ für den aktuellen Arbeitsstand und die nächsten Aktionen.

---

## 2. Ablauf für jede Änderung

1. **Vor jeder Aktion:**

   * Lies `Next_Steps.md`.
   * Führe nur Schritte aus, die dort als `⚙️ laufend` oder `🧩 geplant` markiert sind.
   * Wenn du etwas Neues tun willst → **erst eintragen**, dann umsetzen.

2. **Während der Arbeit:**

   * Technische Zwischenergebnisse (Befehle, Tests, Pfade) **nur** in `Next_Steps.md` unter “🔨 Umsetzung” loggen.
   * Kein Duplikat in `Changelog_Live.md`.

3. **Nach Abschluss eines Tasks:**

   * In `Next_Steps.md`: Checkbox von `⚙️` → `✅`.
   * In `Changelog_Live.md`: Ein sauberer, kurzer Abschnitt mit Zeitstempel und Ergebnis.
   * In `Progress.json`: `status`, `phase` und `last_update` aktualisieren.

---

## 3. Synchronisationsregeln

| Datei               | Auslöser                               | Quelle                  |
| ------------------- | -------------------------------------- | ----------------------- |
| `Next_Steps.md`     | **Vor** jeder Codeänderung             | Handbuch & Planung      |
| `Changelog_Live.md` | **Nach** erfolgreicher Umsetzung       | `Next_Steps.md`         |
| `Progress.json`     | **Automatisch** nach Commit oder Build | aus `Next_Steps.md`     |
| `docs/releases/*`   | **Nur bei Versionsabschluss**          | aus `Changelog_Live.md` |

---

## 4. Schutz gegen Doppelcode

* Keine Code-Snippets oder Shell-Kommandos doppelt loggen.
* `Next_Steps.md` = *Planung und Ausführung*
* `Changelog_Live.md` = *Ergebnis und Zusammenfassung*
* Niemals dieselbe Zeile Code oder denselben Output in beiden Dateien.

**Beispiel:**

In `Next_Steps.md`

```markdown
## 🔨 Umsetzung
- Angelegt: ss-core/src/snapshot.rs
- Implementiert: atomic_write_snapshot(), recover_latest_snapshot()
```

In `Changelog_Live.md`

```markdown
## [2025-10-31 23:15] – Snapshot System Ready
- ✨ Feature: Atomic snapshot/recovery in ss-core
- 📁 Files: ss-core/src/snapshot.rs, ss-api/src/routes/admin.rs
```

---

## 5. Prüfung vor Merge oder Commit

* Prüfe zuerst, ob der letzte Eintrag in `Next_Steps.md` **geschlossen** ist (✅).
* Wenn nein → commit **nicht erlaubt**.
* `Changelog_Live.md` und `Progress.json` müssen auf denselben Zeitstempel zeigen (`last_update` identisch).

---

## 6. Automatische Kontrolle (geplant)

* Ein optionales `pre-commit`-Hook prüft:

  * `Next_Steps.md` hat keinen offenen Task ohne Ergebnis.
  * `Changelog_Live.md` enthält keinen doppelten Zeitstempel.
  * `Progress.json` ist valides JSON.
* Wenn ein Check fehlschlägt → Commit abgebrochen.

---

Wenn du willst, kann ich jetzt:

1. diese Regeln direkt **am Kopf von `Next_Steps.md`** einfügen (als Markdown-Kommentarblock),
2. und ein kleines `scripts/validate_docs.sh` schreiben, das diese Checks lokal oder im CI ausführt.