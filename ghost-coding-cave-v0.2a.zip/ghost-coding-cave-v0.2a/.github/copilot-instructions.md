# Copilot Instructions – Ghost Coding Cave v0.3a

## Projektüberblick

Ghost Coding Cave ist ein hybrides AI-Entwicklungssystem, das TypeScript (Frontend/API) mit Rust (AI-Engine/Storage) kombiniert. **v0.3a Phase: Prisma-freie Architektur mit Semantic Store als Single-DB**.

**Hauptziele:**
- Multi-modale AI-Workflows (Chat, Code, Embeddings)
- Echtzeit-Kollaboration über WebSockets
- Skalierbare Modellverwaltung mit custom `.ghost`-Format
- Sichere Sandboxing von Code-Ausführung in "Caves"
- **NEW (v0.3a):** API ist stateless HTTP gateway (keine lokale DB)

**Kern-Services (v0.3a):**
- **Dashboard** (Next.js @ :4004): Benutzeroberfläche mit Monaco Editor
- **API** (NestJS @ :3000): HTTP gateway zu Semantic Store, stateless
- **Semantic-Store** (Rust @ :4011): Single data source (HTTP REST API)
- **Ghost-Server** (@ :4005): Sandbox für Code-Ausführung
- **Rust Gateway** (Axum @ :4010): Optional – Legacy Rust services

## Architektur (v0.3a)

### Service-Übersicht: Simplified Data Flow

```
┌──────────────────┐     HTTP      ┌──────────────────┐
│   Dashboard      │◄─────────────►│   API (NestJS)   │
│  (Next.js)       │   WebSocket   │   @ :3000        │
│  @ :4004         │               │  (Stateless)     │
└──────────────────┘               └─────────┬────────┘
                                             │
                                        HTTP │
                                             │
                              ┌──────────────▼─────────────┐
                              │ Semantic-Store (Rust)      │
                              │ ss-api @ :4011             │
                              │ [Single Data Source]       │
                              │ /data volume persistence   │
                              └────────────────────────────┘
```

**Warum diese Architektur (v0.3a)?**
- **Prisma entfernt:** API ist jetzt DB-agnostic, reine HTTP forwarding
- **Single DB (Semantic-Store):** Zentrale Quelle für alle Models, Tokenizers, Capsules
- **Stateless API:** Einfacher zu skalieren, keine lokalen Abhängigkeiten
- **HTTP only:** Rust-Services sprechen untereinander nur via HTTP REST
- **Volumes:** `/data/semantic-store` für Persistence (WAL, Snapshots)

### Rust-TypeScript Bridge (v0.3a: HTTP only)

**Communication Pattern:**
```typescript
// TypeScript API → Rust Semantic Store (HTTP REST)
const response = await fetch('http://semantic-store-api:4011/v1/models', {
  method: 'GET',
  headers: { 'Content-Type': 'application/json' }
});

// Dashboard → API (HTTP + WebSocket)
const chat = await fetch('http://api:3000/ai/chat', {
  method: 'POST',
  body: JSON.stringify({ message: 'Hello' })
});

// Real-time: WebSocket für Logs, Live Updates
socket.on('terminal-output', (data) => { /* ... */ });
```

**Key Change from v0.2a:**
- ❌ NO Prisma client, NO local PostgreSQL needed in API
- ✅ ALL data flows through `semantic-store-api` (@ :4011)
- ✅ API is **stateless gateway** – can be scaled horizontally
- ✅ Shared types in `packages/types/` still used for validation

**Semantic-Store APIs (HTTP @ :4011):**
- `GET/POST /v1/models` – Model registry
- `GET/POST /v1/tokenizers` – Tokenizer management
- `GET/POST /v1/capsules` – (future) .ghost capsule uploads
- `GET /v1/health` – Service status

## Docker & Laufzeitumgebung (v0.3a)

### Compose-Struktur (Single DB Pattern)
```yaml
services:
  semantic-store-api:
    # Single data source for entire system
    ports: ["4011:8443"]
    volumes: 
      - semantic_store_data:/data

  api:
    # Stateless NestJS gateway
    ports: ["3000:5906"]
    depends_on:
      - semantic-store-api
    env: SEMANTIC_STORE_HTTP_URL=http://semantic-store-api:4011
    # NO Prisma, NO PostgreSQL dependency

  dashboard:
    # Next.js frontend
    ports: ["4004:5900"]
    depends_on:
      - api
```

**Start-Befehle (v0.3a):**
```bash
# Alle Services (Semantic Store wird Primary)
docker-compose up -d

# Nur API + Dashboard (für schnelle Entwicklung)
docker-compose up -d api dashboard

# Logs vom Semantic Store
docker-compose logs -f semantic-store-api

# Health Check
curl http://localhost:4011/health
curl http://localhost:3000/api/health
```

**Wichtige Umgebungsvariablen (API @ :3000):**
- `SEMANTIC_STORE_HTTP_URL=http://semantic-store-api:4011` – Primary DB
- `DISABLE_DB=true` – Prisma disabled
- `JWT_SECRET` – Auth token secret
- `CORS_ORIGIN=http://localhost:4004` – Dashboard URL

**Service-Abhängigkeiten (v0.3a):**
- API **benötigt** Semantic-Store (HTTP @ :4011)
- Dashboard **benötigt** API (HTTP @ :3000)
- Ghost-Server optional für code execution
- Ollama/MCP optional (profile "llm")

## Authentifizierung & Security

### JWT-Strategie
```typescript
// Multi-Source Token Extraction
jwtFromRequest: ExtractJwt.fromExtractors([
  (request: Request) => request?.cookies?.ghost_token,  // Cookie-based
  ExtractJwt.fromAuthHeaderAsBearerToken(),           // Bearer-Header
])
```

### WebSocket-Handshake
```typescript
// Token wird bei WebSocket-Connect validiert
io.use((socket, next) => {
  const token = socket.handshake.auth.token || socket.handshake.headers.authorization;
  // JWT-Validierung vor WebSocket-Verbindung
});
```

### API-Key Management
- Gespeichert in `ApiKey`-Model mit JSON-Feldern für `allowedModels`, `allowedActions`
- Token-Limits pro Key für Rate-Limiting
- Verwendung: Rust-Services authentifizieren sich via API-Keys bei Node.js-API

### Zugriffsschutz
```typescript
// Proxy-Routen in API mit Guards
@UseGuards(JwtAuthGuard, ApiKeyGuard)
@Post('ai/chat')
async proxyChat(@Body() request: ChatRequest, @Req() req) {
  return this.gateway.forwardToAiServer(request, req.user);
}
```

## Semantic-Store & KI-Integration

### Rolle des Semantic-Store
- **Vector Database**: Embeddings für semantische Suche
- **Model Registry**: Verwaltung von GGUF, ONNX, Transformers → `.ghost`-Format
- **PGML Engine**: Optionale Integration für ML-Pipeline direkt in PostgreSQL
- **Persistence**: WAL + Snapshots für Ausfallsicherheit

### Datenfluss
```
AI-Server → Semantic-Store:
  - Model Loading/Caching
  - Embedding Generation
  - Vector Search Queries
  
API → Semantic-Store:
  - Model Management (Upload/Delete)
  - Health Checks
  - Configuration
```

### OTLP Telemetrie
- Rust-Services: `tracing` crate mit OTLP-Export
- TypeScript: Strukturierte Logs über NestJS
- Monitoring via Jaeger/Grafana (optional)

## Testing & Debugging (v0.3a)

### Build-Fehler: Tests ausschließen
**Problem:** TypeScript Tests kompilieren während Build, aber Jest `expect` ist nicht definiert.
**Lösung:** In `apps/api/tsconfig.json`:
```json
{
  "exclude": ["node_modules", "dist", "test"]
}
```
Tests werden damit nicht in Production-Build einbezogen.

### Test-Struktur
```bash
# Rust-Tests (alle Crates, inklusive ss-gf/ss-core)
cd rust-core && cargo test --workspace
cd semantic-store && cargo test --workspace

# TypeScript-Tests (Jest via Turbo)
npm test  # Alle Workspaces

# Spezifische Service Tests
npm run test --filter=@ghost/api
npm run test --filter=@ghost/dashboard
```

### Debugging-Patterns
```bash
# API lokales Development (DISABLE_DB=true by default)
npm run dev --filter=@ghost/api
# Logs zeigen Requests zu Semantic-Store @ :4011

# Rust Core Tests
cd semantic-store/ss-gf && cargo test --lib
# Tests für .ghost format packing/signing/compression

# Docker Compose Debugging
docker-compose logs -f api  # API logs
docker-compose logs -f semantic-store-api  # DB logs
```

## Governance & Progress Tracking (v0.3a – NEW)

### Workflow-Regeln (`.github/instructions/`)
**ALLE Änderungen müssen diesen Regeln folgen:**

1. **Vor jeder Aktion:** Lese `/Next_Steps.md`
   - Only execute steps marked `⚙️ laufend` or `🧩 geplant`
   - New tasks → add to `Next_Steps.md` first, then execute

2. **Während der Arbeit:**
   - Technical results → log in `Next_Steps.md` only (under "🔨 Umsetzung")
   - NO duplicates in `Changelog_Live.md` or `Progress.json`

3. **Nach Abschluss:**
   - `Next_Steps.md`: checkbox `⚙️` → `✅`
   - `Changelog_Live.md`: Add clean summary with timestamp
   - `Progress.json`: Update `status`, `phase`, `last_update`

### Key Files & Phasen
- **`Next_Steps.md`** (228 lines): Governance rules + action journal + phase checklist
- **`Patches/Progress.json`**: Machine-readable status (operations array with timestamps)
- **`Patches/Changelog_Live.md`**: Live dashboard (architecture diagram, endpoints, env vars)
- **`.github/instructions/`**: use.instructions.md (data structures), next.instructions.md (workflow)

**Phasen (v0.3a):**
- ✅ Phase 1: Prisma removed, Semantic Store live
- ⏳ Phase 2: Services verification (docker-compose, endpoints)
- 🧩 Phase 3: CLI tests (sign/verify flow)
- 🧩 Phase 4: Capsule API
- 🧩 Phase 5: GitHub Actions CI/CD

### Workflow-Diagramm

```
┌─────────────────┐
│  Vor Änderung   │
├─────────────────┤
│ 1. Lies         │
│    Next_Steps   │
│ 2. Check: nur   │
│    ⚙️/🧩 Spezifizieren
│ 3. Falls neu:   │
│    add + commit │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Während Work   │
├─────────────────┤
│ • Technische    │
│   Ergebnisse    │
│   ONLY in       │
│   Next_Steps    │
│ • Kein Duplikat │
│   in anderen    │
│   Files         │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Nach Abschluss  │
├─────────────────┤
│ 1. ⚙️ → ✅ in   │
│    Next_Steps   │
│ 2. Eintrag in   │
│    Changelog    │
│ 3. Progress.json│
│    aktualisiert │
└─────────────────┘
```

### Semantic-Store APIs (v0.3a)

| Endpoint | Method | Purpose | Status |
|----------|--------|---------|--------|
| `/v1/health` | GET | Service liveness probe | ✅ Stable |
| `/v1/models` | GET | List registered models | ✅ Stable |
| `/v1/models` | POST | Register new model | ✅ Stable |
| `/v1/tokenizers` | GET | List tokenizers | ✅ Stable |
| `/v1/tokenizers` | POST | Upload tokenizer | ✅ Stable |
| `/v1/capsules` | GET | List .ghost capsules | 🧩 Planned |
| `/v1/capsules/upload` | POST | Upload & verify capsule | 🧩 Planned |
| `/v1/capsules/{id}/sign` | POST | Sign capsule manifest | 🧩 Planned |

**Example: Create Model**
```bash
curl -X POST http://localhost:4011/v1/models \
  -H "Content-Type: application/json" \
  -d '{
    "name": "qwen2.5-1.5b",
    "format": "gguf",
    "path": "/data/models/qwen2.5-1.5b.gguf",
    "metadata": { "version": "1.0", "size": "1.2GB" }
  }'
```

### Docker Compose Profiles

Optionale Service-Gruppen (default: nur core services):

```bash
# Start nur Core (Semantic-Store, API, Dashboard)
docker-compose up -d

# + LLM Stack (Ollama + MCP)
docker-compose --profile llm up -d

# + AI Services (AI-Server, Helper-Core)
docker-compose --profile ai up -d

# + Mirror Services (NPM, PyPI mirrors)
docker-compose --profile mirror up -d

# Alle Profiles aktivieren
docker-compose --profile llm --profile ai --profile mirror up -d
```

**Profile Details:**
- `llm`: Ollama @ :4002, MCP-Ollama @ :4003
- `ai`: AI-Server (Inferenz), Helper-Core (Analysis/Planning)
- `mirror`: NPM/PyPI package mirrors (offline development)

### CLI Reference: `.ghost` Format

**Ghost-Pack Tool** (Capsule creation & signing):

```bash
# 1. Create .ghost capsule from model directory
ghost-pack pack \
  --source ./models/qwen2.5-1.5b \
  --output ./capsules/qwen2.5-1.5b.ghost \
  --compress zstd

# 2. Sign capsule with ed25519 key
ghost-pack sign \
  --capsule ./capsules/qwen2.5-1.5b.ghost \
  --key ./keys/private.pem \
  --output ./capsules/qwen2.5-1.5b.sig.json

# 3. Verify capsule signature (CI/pre-upload)
ghost-pack verify \
  --capsule ./capsules/qwen2.5-1.5b.ghost \
  --signature ./capsules/qwen2.5-1.5b.sig.json \
  --key ./keys/public.pem

# 4. Extract capsule (testing/deployment)
ghost-pack extract \
  --capsule ./capsules/qwen2.5-1.5b.ghost \
  --output ./extracted/qwen2.5-1.5b
```

**Workflow: Local→SS-API Upload**
```bash
# Create + sign locally
ghost-pack pack --source ./model --output ./model.ghost --compress zstd
ghost-pack sign --capsule ./model.ghost --key ~/.ssh/private.pem --output ./model.sig.json

# Verify locally (sanity check)
ghost-pack verify --capsule ./model.ghost --signature ./model.sig.json --key ~/.ssh/public.pem

# Upload to Semantic Store (Phase 4)
curl -X POST http://localhost:4011/v1/capsules/upload \
  -F "capsule=@./model.ghost" \
  -F "signature=@./model.sig.json"
```

**Format Internals** (ss-gf crate):
- Header: Magic (4B) + Version (1B) + Flags (1B) + Reserved (2B) + Manifest Offset (8B)
- Payload: TAR archive + optional zstd compression
- Manifest: JSON (GhostManifest struct) with model metadata, layers, policies
- Signature: Ed25519 detached (optional, for security)

## Dev Cheatsheet

### Start Local Development
```bash
# Alle Services (API + Dashboard)
npm run dev

# Einzelne Services
npm run dev --filter=@ghost/api
npm run dev --filter=@ghost/dashboard

# Semantic Store nur (keine Prisma DB!)
npm run dev --filter=@ghost/semantic-store
```

### Rust Development
```bash
# Build & Test
cd rust-core
cargo build --workspace
cargo test --workspace
cargo clippy -- -D warnings

# Einzelne Crates
cargo build -p ai-server
cargo test -p semantic-adapter
```

### Docker Operations
```bash
# Full Stack
docker-compose up -d

# Logs & Health
docker-compose logs -f semantic-store-api
docker-compose logs -f api
docker-compose logs -f dashboard

# Health Checks
curl http://localhost:4011/health  # Semantic-Store
curl http://localhost:3000/health  # API
curl http://localhost:4004         # Dashboard
```

## Wichtige Patterns

### Async-Architektur
```rust
// Axum + Tokio Pattern
async fn handler(State(app): State<AppState>) -> Result<Json<Response>, ApiError> {
    let result = app.ai_client.chat(request).await?;
    Ok(Json(Response::success(result)))
}
```

### Error-Handling
```rust
// Konsistente Result<T, ApiError> Pattern
#[derive(Debug, Serialize)]
pub struct ApiError {
    pub message: String,
    pub code: u16,
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (StatusCode::from_u16(self.code).unwrap(), Json(self)).into_response()
    }
}
```

### Frontend Contexts
```typescript
// AuthContext: JWT + User State
const { user, login, logout } = useAuth();

// WebSocketContext: Real-time Verbindungen
const { socket, emit, on } = useWebSocket();

// Proxy-Pattern für AI-Calls
const chatResponse = await api.post('/ai/chat', { message });
```

## Glossar

- **Ghost Capsule**: Binäres Arbeits-Artifact (Code + Manifest + Metadaten) im `.ghost`-Format
- **Cave**: Isolierte Laufzeitumgebung für Code-Ausführung (Container/Namespace-basiert)
- **Semantic Store**: Vector-Datenbank für Embeddings und Modellverwaltung
- **AI Server**: Zentrale Inferenz-Schicht (Chat, TTS, Embeddings, Model Loading)
- **Gateway**: HTTP/AI-Proxy zwischen Node.js-Stack und Rust-Services
- **Helper Core**: Rust-Bibliothek für Analysis/Planner/Agents (wird in semantic-store integriert)
- **ss-* Crates**: Semantic-Store Module (ss-api, ss-core, ss-gf, ss-cli, etc.)
- **Turbo**: Monorepo-Build-System für orchestrierte Entwicklung aller Workspaces