# 🗺️ Master Navigation Guide — Ghost Coding Cave v0.2a

**Your Complete Map to All Services, Code, and Documentation**

---

## 🎯 I Want To...

### 🚀 **Get Started (5 minutes)**
```
→ Read: QUICK_START.md
→ Then: npm run dev
→ Check: http://localhost:4004
✅ Done!
```

### 🔧 **Understand the Architecture**
```
→ Read: docs/ARCHITECTURE.md (system overview)
→ Then: docs/DESIGN.md (patterns & conventions)
→ Then: docs/SERVICES_INTEGRATION.md (how services talk)
→ Final: docs/SERVICES_MANIFEST.md (all services listed)
✅ Master!
```

### ▶️ **Run Everything Locally**
```
→ Read: SERVICE_OPERATIONS.md (quick start section)
→ Terminal 1: npm run dev
→ Terminal 2: cd rust-core && cargo run --bin ai-server
→ Terminal 3: cd services/semantic-store && cargo run --bin ss-api
→ Terminal 4: watch -n 1 'lsof -i | grep LISTEN'
✅ All running!
```

### 🧪 **Run Tests**
```
→ All Rust: cd rust-core && cargo test --workspace
→ Watch: cargo watch -x "test --workspace"
→ Specific: cargo test -p ai-server
→ TypeScript: npm test
✅ 20/20 passing!
```

### 🐛 **Debug a Service**
```
→ Read: SERVICE_OPERATIONS.md (troubleshooting section)
→ AI-Server issue? Check: HELPER_DB_PATH env var
→ Database issue? Check: DATABASE_URL
→ Port conflict? Check: lsof -i :<port>
✅ Fixed!
```

### 🚀 **Start Phase 2 (gRPC Integration)**
```
→ Read: PHASE2_CHECKLIST.md (prerequisites)
→ Then: PHASE2_START.md (implementation guide)
→ Start: Task 2.1 gRPC Client
→ Code: rust-core/crates/ai-server/src/registry/
✅ Ready!
```

### 📦 **Deploy to Production**
```
→ Read: docs/DEPLOYMENT.md (deployment guide)
→ Check: docs/PRODUCTION_READINESS.md (checklist)
→ Review: docs/SECURITY_GUIDE.md (security)
→ Setup: docker-compose up -d
✅ Live!
```

---

## 📁 Directory Structure at a Glance

```
ghost-coding-cave-v0.2a/
│
├── 📋 Root Documentation (START HERE)
│   ├── QUICK_START.md              ← 5 min setup
│   ├── README.md                   ← Project intro
│   ├── SERVICE_OPERATIONS.md       ← Run/Monitor/Debug
│   ├── PHASE2_CHECKLIST.md         ← Phase 2 ready check
│   ├── DOCUMENTATION.md            ← Doc index
│   ├── me.md                       ← Progress log
│   └── package.json                ← Root dependencies
│
├── 📚 docs/ (Detailed Documentation)
│   ├── ARCHITECTURE.md             ← System design
│   ├── DESIGN.md                   ← Code patterns
│   ├── STORAGE_ENGINE.md           ← Database internals
│   ├── SERVICES_MANIFEST.md        ← Service inventory
│   ├── SERVICES_INTEGRATION.md     ← How services connect
│   ├── API_REFERENCE.md            ← API endpoints
│   ├── GHOST_FORMAT_IMPLEMENTATION.md ← Format spec
│   ├── GHOST_FORMAT_QUICK_REF.md   ← Quick format ref
│   ├── PHASE2_ROADMAP.md           ← Phase 2 plan
│   ├── SECURITY_GUIDE.md           ← Security
│   ├── DEPLOYMENT.md               ← Deploy guide
│   ├── PRODUCTION_READINESS.md     ← Prod checklist
│   ├── OPS_CHECKLIST.md            ← Ops tasks
│   └── README.md                   ← Docs index
│
├── 📱 apps/ (TypeScript/Node.js Services)
│   ├── api/                        ← NestJS Backend (Port 3000)
│   │   ├── src/
│   │   ├── Dockerfile
│   │   └── package.json
│   │
│   └── dashboard/                  ← Next.js Frontend (Port 4004)
│       ├── src/
│       ├── next.config.js
│       └── package.json
│
├── 📦 packages/ (Shared Libraries)
│   ├── database/                   ← Prisma ORM
│   │   ├── schema.prisma
│   │   └── index.ts
│   │
│   └── types/                      ← Shared TypeScript Types
│       └── index.ts
│
├── 🦀 rust-core/ (Main Rust Services)
│   ├── crates/
│   │   ├── ai-server/              ← 🟢 RUNNING on Port 5001
│   │   │   ├── src/
│   │   │   │   ├── main.rs         ← Entry point
│   │   │   │   ├── registry/       ← Model registry (Phase 2: gRPC)
│   │   │   │   ├── chat/           ← Chat routes
│   │   │   │   ├── models/         ← Model routes
│   │   │   │   └── lib.rs
│   │   │   ├── tests/
│   │   │   └── Cargo.toml
│   │   │
│   │   ├── gateway/                ← HTTP Gateway & Auth
│   │   │   ├── src/
│   │   │   └── tests/
│   │   │
│   │   ├── helper-core/            ← Analysis & Planning Engine
│   │   │   ├── src/
│   │   │   │   ├── analysis/       ← Code analysis
│   │   │   │   ├── planner/        ← Planning logic
│   │   │   │   └── agents/         ← Agent system
│   │   │   └── tests/
│   │   │
│   │   ├── semantic-adapter/       ← Semantic Search
│   │   │   └── src/
│   │   │
│   │   └── storage-adapter/        ← Vector Storage
│   │       └── src/
│   │
│   ├── target/                     ← Build output
│   ├── Cargo.toml                  ← Workspace config
│   └── Dockerfile
│
├── 🎨 services/ (Additional Services & Semantic-Store)
│   ├── semantic-store/             ← Model Registry & Vector DB
│   │   ├── ss-api/                 ← HTTP/gRPC API (Ports 8443/9443)
│   │   ├── ss-cli/                 ← Command-line tool
│   │   ├── ss-core/                ← Storage engine
│   │   ├── ss-gf/                  ← .ghost Format
│   │   ├── ss-gp/                  ← .ghost Packer
│   │   ├── ss-index/               ← Indexing
│   │   ├── ss-metrics/             ← Metrics
│   │   ├── ss-pgml/                ← ML pipeline
│   │   ├── ss-plugins/             ← Plugin system
│   │   ├── ss-query/               ← Query engine
│   │   ├── Cargo.toml
│   │   ├── Dockerfile
│   │   └── config/
│   │
│   ├── ghost-server/               ← Main Server
│   │   ├── ghost-server.py
│   │   ├── ghost_api.py
│   │   └── Dockerfile
│   │
│   ├── ghost-portal/               ← Admin Web UI (Phase 4)
│   │   ├── src/
│   │   ├── bin/
│   │   └── README.md
│   │
│   ├── ghost-cli/                  ← CLI Tools (gst, gstrun, gstserver)
│   │   ├── bin/
│   │   ├── lib/
│   │   └── Cargo.toml
│   │
│   ├── ghost-utils/                ← Shared Utilities
│   │   ├── lib/
│   │   └── Cargo.toml
│   │
│   └── mcp-ollama/                 ← Ollama Integration
│       └── Dockerfile
│
├── 🧪 Data & Configuration
│   ├── data/                       ← Runtime data
│   │   ├── ai-server/              ← AI models & cache
│   │   └── semantic-store/         ← Vector DB data
│   │
│   ├── .env.local                  ← Local environment (IGNORED)
│   ├── .env.example                ← Template
│   ├── docker-compose.yml          ← Development compose
│   └── docker-compose.production.yml ← Production compose
│
└── 📜 Configuration Files
    ├── turbo.json                  ← Monorepo config
    ├── package.json                ← Root package
    ├── tsconfig.json               ← TypeScript config
    └── Cargo.toml                  ← Rust workspace config
```

---

## 🎓 Learning Path (Recommended Order)

### Level 1: Basics (30 minutes)
1. **[QUICK_START.md](./QUICK_START.md)** — Get everything running
2. **[README.md](./README.md)** — Project overview
3. **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — System design

### Level 2: Development (1-2 hours)
1. **[docs/DESIGN.md](./docs/DESIGN.md)** — Code patterns & conventions
2. **[docs/SERVICES_MANIFEST.md](./docs/SERVICES_MANIFEST.md)** — All services listed
3. **[docs/API_REFERENCE.md](./docs/API_REFERENCE.md)** — API endpoints
4. **[SERVICE_OPERATIONS.md](./SERVICE_OPERATIONS.md)** — Running & debugging

### Level 3: Advanced (2-4 hours)
1. **[docs/STORAGE_ENGINE.md](./docs/STORAGE_ENGINE.md)** — Database internals
2. **[docs/SERVICES_INTEGRATION.md](./docs/SERVICES_INTEGRATION.md)** — Service communication
3. **[docs/GHOST_FORMAT_IMPLEMENTATION.md](./docs/GHOST_FORMAT_IMPLEMENTATION.md)** — Format spec
4. **[docs/SECURITY_GUIDE.md](./docs/SECURITY_GUIDE.md)** — Security

### Level 4: Phase 2 (4-8 hours)
1. **[PHASE2_CHECKLIST.md](./PHASE2_CHECKLIST.md)** — Prerequisites check
2. **[PHASE2_START.md](./PHASE2_START.md)** — gRPC implementation
3. **[docs/PHASE2_ROADMAP.md](./docs/PHASE2_ROADMAP.md)** — Complete plan
4. **Start coding:** Task 2.1

### Level 5: Production (2-4 hours)
1. **[docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md)** — Deploy guide
2. **[docs/PRODUCTION_READINESS.md](./docs/PRODUCTION_READINESS.md)** — Prod checklist
3. **[docs/OPS_CHECKLIST.md](./docs/OPS_CHECKLIST.md)** — Operations tasks
4. **Deploy!**

---

## 🔍 Quick Reference by Role

### Frontend Developer
```
Start With:
├── QUICK_START.md
├── apps/dashboard/
├── docs/DESIGN.md
└── docs/API_REFERENCE.md

Key Files:
├── apps/dashboard/src/
├── packages/types/
└── docs/UX.md
```

### Backend Developer (Rust)
```
Start With:
├── QUICK_START.md
├── rust-core/
├── docs/STORAGE_ENGINE.md
└── docs/DESIGN.md

Key Files:
├── rust-core/crates/
├── services/semantic-store/
└── SERVICE_OPERATIONS.md
```

### Backend Developer (Node.js)
```
Start With:
├── QUICK_START.md
├── apps/api/
├── docs/API_REFERENCE.md
└── docs/DESIGN.md

Key Files:
├── apps/api/src/
├── packages/
└── SERVICE_OPERATIONS.md
```

### DevOps / Operations
```
Start With:
├── docs/DEPLOYMENT.md
├── SERVICE_OPERATIONS.md
├── docker-compose.yml
└── .env.example

Key Files:
├── docs/OPS_CHECKLIST.md
├── docs/PRODUCTION_READINESS.md
└── Dockerfile files
```

### Project Lead
```
Start With:
├── README.md
├── DOCUMENTATION.md
├── docs/PHASE2_ROADMAP.md
└── me.md

Key Files:
├── FINAL_STATUS.md
├── INDEX.md
└── STATUS.md
```

---

## 🚨 Emergency Reference

### "Something is broken!"
1. Check: **[SERVICE_OPERATIONS.md](./SERVICE_OPERATIONS.md)** → Troubleshooting
2. Check: **[QUICK_START.md](./QUICK_START.md)** → Environment setup
3. Check: **Service specific section** → SERVICES_MANIFEST.md

### "How do I run X?"
1. Check: **[SERVICE_OPERATIONS.md](./SERVICE_OPERATIONS.md)** → Quick Start
2. Check: **Service docs** → docs/SERVICES_MANIFEST.md

### "What does X do?"
1. Check: **[docs/SERVICES_MANIFEST.md](./docs/SERVICES_MANIFEST.md)** → Service inventory
2. Check: **[docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)** → System design
3. Check: **README.md** → Project overview

### "How do I deploy?"
1. Check: **[docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md)** → Full guide
2. Check: **[docs/PRODUCTION_READINESS.md](./docs/PRODUCTION_READINESS.md)** → Checklist

### "Where do I start Phase 2?"
1. Check: **[PHASE2_CHECKLIST.md](./PHASE2_CHECKLIST.md)** → Prerequisites
2. Check: **[PHASE2_START.md](./PHASE2_START.md)** → Implementation
3. Start: **Task 2.1 gRPC Client**

---

## 📊 Service Port Map

```
┌─────────────────────────────────────┐
│      Frontend (Port 4004)           │
│      Next.js Dashboard              │
└──────────────┬──────────────────────┘
               │ WebSocket
               ↓
┌─────────────────────────────────────┐
│      Backend API (Port 3000)        │
│      NestJS + Prisma                │
└──────────────┬──────────────────────┘
    ┌──────────┼──────────┐
    │          │          │
    ↓          ↓          ↓
┌────────┐ ┌────────┐ ┌─────────────┐
│ Helper │ │Vector  │ │  PostSQL    │
│ Core   │ │ Store  │ │             │
│        │ │        │ │             │
│ AI     │ │Semantic│ │ pgvector    │
│Inf.    │ │ Arch.  │ │             │
└────┬───┘ └───┬────┘ └─────────────┘
     │         │
     └────┬────┘
          ↓
    ┌──────────────────┐
    │   AI-Server      │
    │   (Port 5001)    │
    │                  │
    │   Models         │
    │   Chat API       │
    │   Inference      │
    └──────────────────┘
```

---

## ✅ Status Overview

| Component | Status | Port | Docs |
|-----------|--------|------|------|
| AI-Server | 🟢 RUNNING | 5001 | SERVICES_MANIFEST.md |
| Semantic-Store | ✅ Ready | 8443/9443 | STORAGE_ENGINE.md |
| NestJS API | ⏳ Compiled | 3000 | API_REFERENCE.md |
| Dashboard | ⏳ Compiled | 4004 | UX.md |
| PostgreSQL | 🐳 Docker | 5432 | DEPLOYMENT.md |
| Tests | ✅ 20/20 Passing | — | TEST_REPORT.md |
| Phase 1 | ✅ COMPLETE | — | FINAL_STATUS.md |
| Phase 2 | 🟡 READY | — | PHASE2_CHECKLIST.md |

---

## 🎯 Next Steps

### Right Now
```bash
1. npm install
2. npm run dev
3. Open http://localhost:4004
```

### Next Hour
```bash
1. Read QUICK_START.md
2. Read docs/ARCHITECTURE.md
3. Read docs/DESIGN.md
```

### Next Day
```bash
1. Run cargo test --workspace
2. Explore rust-core/ crates
3. Read docs/STORAGE_ENGINE.md
```

### Next Week
```bash
1. Read PHASE2_CHECKLIST.md
2. Review PHASE2_START.md
3. Start Task 2.1 implementation
```

---

**Last Updated:** 31. Oktober 2025  
**Maintained By:** Copilot Agent  
**Version:** 1.0  
**Status:** Phase 1 Complete ✅, Phase 2 Ready 🟡

---

*For the most up-to-date status, check:* **[me.md](./me.md)** *and* **[FINAL_STATUS.md](./FINAL_STATUS.md)**
