# Vereinte Architektur: RAG, Semantic-Store, Helper-Agents und Media-RAG

## Integrierte Open-Source-Repositories

### DB-Schicht (Storage & Indexierung)
- **FreeVA** (whwu95/FreeVA) - Video-Assist und multimodale Storage/Query

### Helper-Layer (Ingestion, Assistenz, etc.)
- **SubtitleAI** (oztrkoguz/SubtitleAI) - Für die Extraktion von Video-Transkripten
- **StarStream** (giaongo/StarStream)
- **python‑whatsapp‑chatbot** (Whapi-Cloud/python-whatsapp-chatbot)
- **ai‑mreflow** (vdutts7/ai-mreflow)
- **vocaltales_storyteller_chatbot** (tszumowski/vocaltales_storyteller_chatbot)
- **crypto‑trade‑chatbot** (taprwhiz/crypto-trade-chatbot)
- **LiveVideoChat** (superstar3222/LiveVideoChat) - Für Echtzeit-Videochat-Funktionalität

Diese Dokumentation beschreibt die integrierte Architektur, die RAG-Service, Semantic-Store, Helper-Agents und Video-RAG zusammenführt.

## Übersicht der Architekturkomponenten

Die Architektur besteht aus vier Hauptschichten:

1. **Storage-Schicht (Semantic Store Core)**: Zuständig für Datenhaltung, Indexierung und Vektorraumlogik
2. **RAG-Service**: Kernpipeline für Ingest, Retrieval und Generation
3. **Helper-Schicht**: Unterstützung für Interaktion, Planung und Echtzeit-Assistenz
4. **Frontend-Schicht**: Benutzeroberfläche über WebSocket und REST-APIs

```
[UI/IDE]
  ├─ HTTP 8647 → RAG-Service (Axum)
  │     ├─ Ingest/Retrieve/Generate
  │     ├─ Adapter → StorageDispatcher (embedded/sql/neodb/vector/media)
  │     ├─ Adapter → VectorIndex (nano-vectordb-rs)
  │     └─ Adapter → LLM/Embeddings (plug-in)
  └─ WS  8650 → Live-Advisor (Helper-Agent)
```

## 1. Storage-Schicht (Semantic Store Core)

Die Storage-Schicht wurde erweitert, um verschiedene Typen von Daten zu unterstützen:

```
rust-core/crates/semantic-store/ss-core/src/storage/
├── mod.rs                # Trait & Dispatcher
├── embedded_backend.rs   # Datei-basierte Engine
├── sql_backend.rs        # SQL-Backend (sqlite)
├── neodb_backend.rs      # Verifizierbare Engine mit WAL + Merkle
├── vector_backend.rs     # Vektor-Indexierung mit nano-vectordb-rs
└── media_backend.rs      # Media-Indexierung für Video/Audio
```

Der `StorageBackend`-Trait bietet eine einheitliche Schnittstelle für alle Backends:

```rust
#[async_trait]
pub trait StorageBackend: Send + Sync {
    async fn put(&self, key: &str, value: &[u8]) -> Result<()>;
    async fn get(&self, key: &str) -> Result<Option<Vec<u8>>>;
    async fn delete(&self, key: &str) -> Result<()>;
    async fn query(&self, expr: &str) -> Result<Vec<(String, Vec<u8>)>>;
    async fn verify(&self, key: &str, proof: &[u8]) -> Result<bool> {
        // default no-op verification for non-verifiable stores
        Ok(false)
    }
}
```

Die `StorageMode`-Enum wurde erweitert:

```rust
#[derive(Debug, Clone)]
pub enum StorageMode {
    Embedded,
    Sql,
    NeoDb,
    Vector,
    Media,
}
```

### Media-Backend

Das Media-Backend bietet spezielle Funktionen für die Verarbeitung von Medieninhalten:

- `MediaMetadata`: Metadaten für Video- und Audiodateien
- `SceneMetadata`: Szeneninformationen für Videos
- `FrameMetadata`: Frame-Informationen mit Zeitstempeln
- `FeatureVector`: Einbettungsvektoren für Frames und Audiodaten

## 2. RAG-Service

Der RAG-Service integriert die Kernpipeline für Retrieval Augmented Generation:

```
rust-core/services/rag/
├── src/
│   ├── adapters/
│   │   ├── storage.rs       # KvStore-Adapter
│   │   ├── vectors.rs       # VectorIndex-Adapter
│   │   └── llm.rs           # LLM-Engine-Adapter
│   ├── pipeline/
│   │   ├── ingest.rs        # Dokumentenverarbeitung
│   │   ├── retrieve.rs      # Kontextsuche
│   │   └── generate.rs      # Antwortgenerierung
│   ├── helper/
│   │   ├── planner.rs       # Planungsunterstützung
│   │   ├── youtube.rs       # YouTube-Integration
│   │   ├── video_rag.rs     # Video-RAG-Optimierung
│   │   ├── live_ws.rs       # WebSocket-Bridge
│   │   └── realtime_agent.rs # Echtzeit-Agent
│   └── server/
│       ├── http.rs          # HTTP-API
│       └── grpc.rs          # gRPC-API
└── Cargo.toml
```

## 3. Helper-Schicht

Die Helper-Schicht bietet erweiterte Funktionen für die Interaktion mit dem System:

### YouTube-Integration (`helper/youtube.rs`)

- Extrahieren von Metadaten und Transkripten aus YouTube-Videos
- Konvertieren in RAG-Dokumente für die Ingestierung
- Unterstützung für Zeitstempel und Szeneninformationen

### Video-RAG-Planer (`helper/video_rag.rs`)

- Optimierung der Retrieval-Strategie für lange Videos
- Segmentidentifikation und -rankierung mit LLM-Unterstützung
- Zusammenführen benachbarter Segmente für besseren Kontext

### Echtzeit-Agent (`helper/realtime_agent.rs`)

- WebSocket-Server für Echtzeit-Interaktion
- Unterstützung für Text- und Audiointeraktionen
- Integration mit Speech-to-Text und Text-to-Speech

## 4. Konfiguration und Umgebungsvariablen

Die wichtigsten Konfigurationsparameter:

```
# Storage
SS_STORAGE_MODE=embedded|sql|neodb|vector|media
SS_STORAGE_PATH=/path/to/storage
SS_MEDIA_PATH=/path/to/media
SS_VECTOR_PATH=/path/to/vectors
SS_VECTOR_DIMS=768

# RAG Service
RAG_HTTP_PORT=8647
RAG_WS_PORT=8650
RAG_VECTOR_MODE=enabled|disabled

# Externe Dienste
RAG_LLM_URL=http://localhost:8000
RAG_STT_URL=http://localhost:8001/speech-to-text
RAG_TTS_URL=http://localhost:8001/text-to-speech
```

## 5. API-Endpunkte

### HTTP-API (Port 8647)

- `POST /ingest`: Dokumente in das System einfügen mit folgendem JSON-Format:
  ```json
  {
    "id": "unique-doc-id",
    "namespace": "collection-name",
    "text": "Document content to be indexed",
    "metadata": { "any": "arbitrary metadata" },
    "embedding": [0.1, 0.2, ...] // optional embedding vector
  }
  ```

- `POST /query`: Abfrage an das System stellen mit folgendem JSON-Format:
  ```json
  {
    "query_embedding": [0.1, 0.2, ...],
    "top_k": 5,                     // optional, default: 5
    "user_query": "User question",  // optional
    "llm_base": "http://llm-api"   // optional
  }
  ```

### WebSocket-API (Port 8650)

Echtzeit-Interaktion mit dem Agenten über strukturierte Nachrichten:

```typescript
type AgentMessage = 
  | { type: 'text', data: string }
  | { type: 'audio', data: string }
  | { type: 'transcript', data: string }
  | { type: 'query_result', data: QueryResult }
  | { type: 'status', data: AgentStatus }
  | { type: 'error', data: string }
```

## 6. Integration und Erweiterbarkeit

### Hinzufügen neuer Storage-Backends

Um ein neues Storage-Backend hinzuzufügen:

1. Implementiere den `StorageBackend`-Trait
2. Erweitere die `StorageMode`-Enum
3. Aktualisiere den `StorageDispatcher` für die Instanziierung

### Hinzufügen neuer Helper-Module

Um einen neuen Helper hinzuzufügen:

1. Erstelle ein neues Modul unter `helper/`
2. Exportiere das Modul in `helper/mod.rs`
3. Integriere es in den entsprechenden Service

## 7. Deployment

Die Architektur unterstützt verschiedene Deployment-Optionen:

- **Entwicklung**: Lokale Ausführung mit `./scripts/start-rag.sh`
- **Docker**: Container für jeden Service
- **Produktion**: Skalierbare Architektur mit mehreren Instanzen

Umgebungsvariablen für die Konfiguration:

```bash
# Storage Backend
SS_STORAGE_MODE=embedded|sql|neodb|media   # Storage-Backend-Typ
SS_STORAGE_PATH=/path/to/storage           # Pfad für Storage-Daten
SS_VECTOR_MODE=enabled                     # Aktiviert Vektor-Indizierung
RAG_VECTOR_PATH=/path/to/vectors           # Pfad für Vektor-Index

# Server
RAG_HTTP_ADDR=0.0.0.0:8647                 # HTTP-API-Adresse

# Logging
RUST_LOG=info                              # Log-Level
```

Docker-Compose-Konfiguration für die Produktionsumgebung:

```yaml
services:
  rag:
    image: ghost-coding-cave/rag-service:v0.1
    environment:
      - SS_STORAGE_MODE=embedded
      - SS_STORAGE_PATH=/data/ss_storage
      - SS_VECTOR_MODE=enabled
      - RAG_VECTOR_PATH=/data/vector_index
      - RUST_LOG=info
    ports:
      - "8647:8647"
    volumes:
      - ./data:/data
```

## RAG Service (Axum)

**Ziele:** Ingest → Vectorize → Retrieve → (optional) Generate

**HTTP**
- `POST /ingest`  
  Request: `{ "text": string, "metadata"?: object, "id"?: uuid }`  
  Response: `{ "id": uuid }` 

- `POST /query`  
  Request: `{ "query": string, "top_k"?: number=3, "generate"?: bool=false }`  
  Response: `{ "contexts": string[], "answer"?: string }` 

**Module**
- `adapters::storage::MemoryStorage` – In-Mem Docs
- `adapters::vectors::MemoryVectorIndex` – In-Mem Vektoren (Cosine)
- `adapters::llm::DummyLlm` – Demo-Embedding + Demo-Antwort
- `pipeline::{ingest, retrieve, generate}` – RAG Steps

## 8. Schnellstart

Um den RAG-Service zu starten und zu testen:

```bash
# RAG-Service starten
./scripts/start-rag.sh

# In einem anderen Terminal: API testen
./scripts/test-rag-api.sh
```

## 9. Nächste Schritte

1. **Implementierung der gRPC-API** für hohe Leistung und Interoperabilität
2. **Erweiterung der Media-Indexierung** für bessere Segmentierung und Szenenidentifikation
3. **Integration mit Embeddings-Services** für verbesserte Vektorrepräsentationen
4. **UI-Komponenten** für Verwaltung und Visualisierung
5. **E2E-Tests** für die gesamte Architektur
