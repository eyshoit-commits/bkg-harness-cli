# Changelog

All notable changes to this project are documented here. This file captures the recent architectural refactor to a single, self-hosted Semantic Store and related API/UI/CI changes.

## [0.2.1] - 2025-10-31

### Patches
- Semantic Store becomes the single source of truth (removes external DB dependency at runtime):
  - New `ss-core` crate: persistent JSON-backed store with RwLock; records for `Model` and `Tokenizer`; atomic index persistence (`index.json`).
  - `ss-api` now embeds `ss-core` and exposes:
    - `GET /v1/models`, `POST /v1/models`
    - `GET /v1/tokenizers`, `POST /v1/tokenizers`
    - Existing Ghost endpoints remain: manifest validate/schema, pack.
  - Data root configurable via `SS_STORAGE`.
- API Gateway (NestJS) talks to Semantic Store over HTTP only:
  - New `SemanticStoreService` (HTTP client) + `SemanticStoreModule`.
  - New `ModelsModule` and `TokenizersModule` exposing `/api/models` and `/api/tokenizers`.
  - Swagger/OpenAPI updated with tags `Models` and `Tokenizers`; DTOs added for requests/responses.
  - Prisma removed from API package.json; DB disabled via `DISABLE_DB=true`.
- Dashboard Admin integration (Next.js):
  - New Admin tabs for `Models` and `Tokenizers`.
  - `AdminModels.tsx`: list + create model via API.
  - `AdminTokenizers.tsx`: list + upsert tokenizer via API.
- Docker/Compose cleanup:
  - `docker-compose.yml` reworked: Semantic Store is the only DB; Postgres/Redis removed.
  - Profiles retained for optional services (`llm`, `ai`, `mirror`).
  - API env now includes `SEMANTIC_STORE_HTTP_URL` and `SEMANTIC_STORE_GRPC_URL` (prep for future gRPC).
  - `.env.example` updated with `DISABLE_DB=true`.
- API Dockerfile streamlined:
  - Removed Prisma generate/engines; lighter final image.
  - `EXPOSE 5906`, defaults `DISABLE_DB=true`.
- E2E tests:
  - API smoke tests (Jest + Supertest):
    - `apps/api/test/models.e2e-spec.ts`
    - `apps/api/test/tokenizers.e2e-spec.ts`
  - CI workflow for API E2E:
    - `.github/workflows/api-e2e.yml` builds/starts `ss-api` and runs API tests.
- Build system / tooling:
  - `scripts/ghost/build_libkrun.sh`: switch from `patchelf --set-needed` to compatibility path `--add-needed` with pre-check; add `verify_elf` sanity validation; improved error handling.
  - `scripts/ghost/Makefile`: `krun` target builds + verifies and prints env exports. Adds ELF diagnostics on failure.
  - `Justfile` at repo root with `ghost-krun` and `ghost-env` helpers.
  - CI workflow for libkrun build verification:
    - `.github/workflows/krun.yml` builds and verifies libkrun artifacts.

### Added
- `semantic-store/ss-core` with persistent index and CRUD for models/tokenizers.
- `semantic-store/ss-api` routes for models/tokenizers.
- `apps/api/src/semantic-store/*` client module.
- `apps/api/src/models/*`, `apps/api/src/tokenizers/*` controllers/modules.
- DTOs for Swagger: `apps/api/src/dto/models.dto.ts`, `apps/api/src/dto/tokenizers.dto.ts`.
- Dashboard components: `AdminModels.tsx`, `AdminTokenizers.tsx` and Admin tabs wiring.
- CI: `api-e2e.yml`, `krun.yml` workflows.
- Full session log for v0.2a published at: [docs/releases/v0.2a_ghost-format.md](docs/releases/v0.2a_ghost-format.md)

### v0.2a – 2025-10-31
- Restored full services workspace.
- Implemented `.ghost` format, CLI (`ghost-pack`), signing, and converter registry.
- All 20 tests passing.
- See [docs/releases/v0.2a_ghost-format.md](docs/releases/v0.2a_ghost-format.md) for the full session log.

### Changed
- `apps/api/src/main.ts` Swagger tags and versioned docs kept at `/api/docs`.
- `apps/api/Dockerfile` simplified; no Prisma.
- `docker-compose.yml` and `docker-compose.production.yml` to Semantic-Store-only DB; envs aligned; profiles preserved.

### Removed
- Prisma dependency from `apps/api/package.json`.
- Prisma generate step and Prisma engines from API image.
- Postgres/Redis services from default compose stack (can be reintroduced separately if needed).

### Fixed
- `build_libkrun.sh` compatibility with patchelf 0.18 by using `--add-needed` and RPATH verification; prevents DT_NEEDED duplication and runtime linkage issues.

### CI/CD
- API E2E workflow starts `ss-api` container, runs `npm ci && npm run build && npm test` in `apps/api`, and uploads logs on failure.
- krun build workflow validates ELF `DT_NEEDED` and `RPATH` via `patchelf`.

### Migration Notes
- API no longer requires a relational DB at runtime. Ensure `SEMANTIC_STORE_HTTP_URL` points to the running `ss-api` (compose sets it automatically).
- Remove any local Prisma caches; API has no Prisma imports anymore.
- Dashboard expects `NEXT_PUBLIC_API_URL` to be set (compose already provides it).

### Known Next Steps
- Extend `ss-core` and `ss-api` with Files/Versions (blob storage, dedup, append-only logs) and migrate API routes accordingly.
- Optional UI Sanity (Playwright) end-to-end tests for the Admin tabs; can be enabled in a follow-up workflow.

---

## [0.2.0] - Previous
- Baseline release for v0.2.0 prior to Semantic Store consolidation.

