#!/bin/bash

# Ghost Coding Cave v0.2a - Development Start Script

echo "🚀 Starting Ghost Coding Cave v0.2a..."
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if .env exists
if [ ! -f .env ]; then
    echo -e "${YELLOW}⚠️  .env not found, copying from .env.example${NC}"
    cp .env.example .env
fi

# Start Docker services
echo -e "${BLUE}📦 Starting Docker services...${NC}"
docker-compose up -d db redis ollama mirror-npm mirror-pypi ghost-server

# Wait for DB
echo -e "${BLUE}⏳ Waiting for PostgreSQL...${NC}"
sleep 5

# Check if Prisma Client is generated
if [ ! -d "node_modules/@prisma/client" ]; then
    echo -e "${BLUE}🔧 Generating Prisma Client...${NC}"
    npm run db:generate
fi

# Push database schema
echo -e "${BLUE}🗄️  Initializing database...${NC}"
DATABASE_URL=postgresql://ghost:ghost@localhost:4000/ghost npm run db:push

# Build API if needed
if [ ! -d "apps/api/dist" ]; then
    echo -e "${BLUE}🔨 Building API...${NC}"
    cd apps/api && npm run build && cd ../..
fi

echo ""
echo -e "${GREEN}✅ Infrastructure ready!${NC}"
echo ""
echo -e "${YELLOW}Starting services...${NC}"
echo ""

# Start API in background
echo -e "${BLUE}🔧 Starting API on port 4003...${NC}"
cd apps/api
JWT_SECRET=ghost-cave-secret-key-2a-production-ready-change-this-32chars \
DATABASE_URL=postgresql://ghost:ghost@localhost:4000/ghost \
GHOST_SERVER_URL=http://localhost:4005 \
GHOST_SERVER_API_KEY=ghost-dev-api \
GHOST_LOG_WS_URL=ws://localhost:4005/ws/logs \
node dist/apps/api/src/main.js > ../../logs/api.log 2>&1 &
API_PID=$!
cd ../..

sleep 3

# Start Dashboard
echo -e "${BLUE}🎨 Starting Dashboard on port 4004...${NC}"
cd apps/dashboard
npm run dev > ../../logs/dashboard.log 2>&1 &
DASHBOARD_PID=$!
cd ../..

sleep 3

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}✨ Ghost Coding Cave v0.2a is running!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${BLUE}🌐 Services:${NC}"
echo -e "   Dashboard:    ${GREEN}http://localhost:4004${NC}"
echo -e "   Admin Panel:  ${GREEN}http://localhost:4004/admin${NC}"
echo -e "   API:          ${GREEN}http://localhost:4003${NC}"
echo -e "   API Docs:     ${GREEN}http://localhost:4003/api/docs${NC}"
echo ""
echo -e "${BLUE}🐳 Docker Services:${NC}"
echo -e "   PostgreSQL:   ${GREEN}localhost:4000${NC}"
echo -e "   Redis:        ${GREEN}localhost:4001${NC}"
echo -e "   Ollama:       ${GREEN}http://localhost:4002${NC}"
echo -e "   Ghost Server: ${GREEN}http://localhost:4005${NC}"
echo -e "   NPM Mirror:   ${GREEN}http://localhost:4008${NC}"
echo -e "   PyPI Mirror:  ${GREEN}http://localhost:4009${NC}"
echo ""
echo -e "${BLUE}📋 Process IDs:${NC}"
echo -e "   API PID:      ${YELLOW}$API_PID${NC}"
echo -e "   Dashboard:    ${YELLOW}$DASHBOARD_PID${NC}"
echo ""
echo -e "${YELLOW}💡 Tips:${NC}"
echo -e "   - View API logs:       tail -f logs/api.log"
echo -e "   - View Dashboard logs: tail -f logs/dashboard.log"
echo -e "   - Stop services:       ./stop-dev.sh"
echo -e "   - View Docker logs:    docker-compose logs -f"
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"

# Save PIDs
echo "$API_PID" > .api.pid
echo "$DASHBOARD_PID" > .dashboard.pid
