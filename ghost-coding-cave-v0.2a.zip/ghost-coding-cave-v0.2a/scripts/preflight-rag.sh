#!/usr/bin/env bash
set -euo pipefail

echo "🚀 RAG Service Production Preflight"
echo "===================================="

# Change to project root
cd "$(dirname "$0")/.."

# 1. Formatting
echo -n "✓ Code formatting... "
cargo fmt --all --check -q && echo "OK" || (echo "FAIL" && exit 1)

# 2. Clippy
echo -n "✓ Clippy lints... "
cargo clippy --workspace --all-targets -q -- -D warnings 2>&1 | grep -q "Finished" && echo "OK" || (echo "FAIL" && exit 1)

# 3. Tests
echo -n "✓ Unit tests... "
cargo test -p rag --lib -q && echo "OK" || (echo "FAIL" && exit 1)

echo -n "✓ E2E tests... "
cargo test -p rag --test e2e --test e2e_test -q && echo "OK" || (echo "FAIL" && exit 1)

# 4. Build
echo -n "✓ Release build... "
cargo build --release -p rag -q && echo "OK" || (echo "FAIL" && exit 1)

# 5. Binary check
echo -n "✓ Binary exists... "
[[ -f "rust-core/target/release/rag" ]] && echo "OK" || (echo "FAIL" && exit 1)

# 6. Start service in background
echo -n "✓ Starting service... "
RUST_LOG=info rust-core/target/release/rag &
RAG_PID=$!
sleep 2
echo "OK (PID: $RAG_PID)"

# 7. Health checks
echo -n "✓ Health endpoint... "
curl -fsS http://localhost:8083/healthz > /dev/null && echo "OK" || (kill $RAG_PID && echo "FAIL" && exit 1)

echo -n "✓ Ready endpoint... "
curl -fsS http://localhost:8083/readyz > /dev/null && echo "OK" || (kill $RAG_PID && echo "FAIL" && exit 1)

echo -n "✓ Version endpoint... "
VERSION=$(curl -fsS http://localhost:8083/version)
echo "OK (v$VERSION)"

echo -n "✓ Metrics endpoint... "
curl -fsS http://localhost:8083/metrics > /dev/null && echo "OK" || (kill $RAG_PID && echo "FAIL" && exit 1)

# 8. Functional tests
echo -n "✓ Ingest endpoint... "
INGEST_RESP=$(curl -fsS -X POST http://localhost:8083/ingest \
  -H 'content-type: application/json' \
  -d '{"text":"preflight test","metadata":{"test":true}}')
DOC_ID=$(echo "$INGEST_RESP" | jq -r '.id')
[[ -n "$DOC_ID" ]] && echo "OK" || (kill $RAG_PID && echo "FAIL" && exit 1)

echo -n "✓ Query endpoint... "
QUERY_RESP=$(curl -fsS -X POST http://localhost:8083/query \
  -H 'content-type: application/json' \
  -d '{"query":"test","top_k":1,"generate":true}')
CONTEXTS=$(echo "$QUERY_RESP" | jq -r '.contexts | length')
[[ "$CONTEXTS" -gt 0 ]] && echo "OK" || (kill $RAG_PID && echo "FAIL" && exit 1)

# 9. Graceful shutdown test
echo -n "✓ Graceful shutdown... "
kill -TERM $RAG_PID
sleep 2
! kill -0 $RAG_PID 2>/dev/null && echo "OK" || echo "WARN (still running)"

echo ""
echo "✅ All preflight checks passed!"
echo "🚢 Ready to ship!"
