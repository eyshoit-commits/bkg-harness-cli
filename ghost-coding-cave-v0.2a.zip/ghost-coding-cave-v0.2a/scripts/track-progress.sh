#!/bin/bash
# Progress Tracking Helper for v0.3a Session
# Usage: ./scripts/track-progress.sh "OPERATION_TYPE" "description" "target_file" "status" "details"

set -e

PROGRESS_FILE="Patches/Progress.json"
ISO_DATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
DATE=$(date +"%d.%m.%Y")
TIME=$(date +"%H:%M:%S")
ACTOR="${USER:-GitHub Copilot}"

OPERATION_TYPE="${1:-CUSTOM}"
DESCRIPTION="${2:-Operation completed}"
TARGET_FILE="${3:-}"
STATUS="${4:-✅}"
DETAILS="${5:-}"

# Prepare operation JSON
OPERATION="{
  \"timestamp\": \"$ISO_DATE\",
  \"date\": \"$DATE\",
  \"time\": \"$TIME\",
  \"actor\": \"$ACTOR\",
  \"operation\": \"$OPERATION_TYPE\",
  \"type\": \"$(echo $OPERATION_TYPE | tr '[:upper:]' '[:lower:]')\",
  \"target\": $([ -n "$TARGET_FILE" ] && echo "[\"$TARGET_FILE\"]" || echo "[]"),
  \"status\": \"$STATUS\",
  \"description\": \"$DESCRIPTION\",
  \"details\": \"$DETAILS\"
}"

# Append to operations array
if [ -f "$PROGRESS_FILE" ]; then
  # Use jq to append if available, otherwise use sed
  if command -v jq &> /dev/null; then
    jq ".operations += [$OPERATION] | .metrics.total_operations += 1" "$PROGRESS_FILE" > "$PROGRESS_FILE.tmp"
    mv "$PROGRESS_FILE.tmp" "$PROGRESS_FILE"
  else
    echo "⚠️  jq not found; install for automatic JSON updates"
  fi
fi

echo "✅ Logged: [$TIME] $OPERATION_TYPE – $DESCRIPTION"
