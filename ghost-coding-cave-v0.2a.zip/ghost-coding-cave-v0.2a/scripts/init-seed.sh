#!/usr/bin/env bash
set -euo pipefail

DATA_DIR="${1:-./data}"
mkdir -p "$DATA_DIR/uploads" "$DATA_DIR/capsules"
echo "Initialisiert: $DATA_DIR (uploads/, capsules/)"
