#!/usr/bin/env bash
set -euo pipefail
export RUST_LOG=${RUST_LOG:-info,axum=info,tower_http=info}
export RAG_PORT=${RAG_PORT:-8083}
cargo run -p rag
