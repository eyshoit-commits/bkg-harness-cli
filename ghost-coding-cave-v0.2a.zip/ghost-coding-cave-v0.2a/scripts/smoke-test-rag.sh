#!/usr/bin/env bash
set -euo pipefail

BASE=${BASE:-http://localhost:8083}

echo "🔍 RAG Service Smoke Test"
echo "=========================="

# Health Check
echo -n "✓ Health... "
curl -sf "$BASE/healthz" > /dev/null && echo "OK" || (echo "FAIL" && exit 1)

# Ready Check
echo -n "✓ Ready... "
curl -sf "$BASE/readyz" > /dev/null && echo "OK" || (echo "FAIL" && exit 1)

# Version Check
echo -n "✓ Version... "
VERSION=$(curl -sf "$BASE/version")
echo "$VERSION"

# Ingest Test
echo -n "✓ Ingest... "
INGEST_RESP=$(curl -sf -X POST "$BASE/ingest" \
  -H 'content-type: application/json' \
  -d '{"text":"Rust RAG service test","metadata":{"test":true}}')
DOC_ID=$(echo "$INGEST_RESP" | jq -r '.id')
[[ -n "$DOC_ID" ]] && echo "OK (id: $DOC_ID)" || (echo "FAIL" && exit 1)

# Query Test
echo -n "✓ Query... "
QUERY_RESP=$(curl -sf -X POST "$BASE/query" \
  -H 'content-type: application/json' \
  -d '{"query":"test","top_k":1,"generate":true}')
CONTEXTS=$(echo "$QUERY_RESP" | jq -r '.contexts | length')
[[ "$CONTEXTS" -gt 0 ]] && echo "OK ($CONTEXTS contexts)" || (echo "FAIL" && exit 1)

echo ""
echo "✅ All smoke tests passed!"
