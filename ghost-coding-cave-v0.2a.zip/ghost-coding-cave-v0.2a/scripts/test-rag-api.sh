#!/usr/bin/env bash
set -euo pipefail
BASE=${BASE:-http://localhost:8083}

echo "[1/2] ingest"
resp=$(curl -sS -X POST "$BASE/ingest" -H 'content-type: application/json' \
  -d '{"text":"Dok A über Crabs in der Cloud.","metadata":{"tag":"demo"}}')
echo "$resp"
id=$(jq -r .id <<< "$resp")

echo "[2/2] query"
curl -sS -X POST "$BASE/query" -H 'content-type: application/json' \
  -d '{"query":"Worum geht es?","top_k":3,"generate":true}' | jq
