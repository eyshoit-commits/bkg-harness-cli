#!/bin/bash
set -e

# Umgebungsvariablen
export SS_STORAGE_MODE=media
export SS_STORAGE_PATH=./data/ss_storage
export SS_VECTOR_MODE=enabled
export RAG_VECTOR_PATH=./data/vector_index

# Verzeichnisse erstellen
mkdir -p data/ss_storage/media
mkdir -p data/vector_index

echo "1. Unit-Tests für Storage-Module ausführen"
cd rust-core/crates/semantic-store
cargo test -p ss-core -- storage::media_backend
cargo test -p ss-core -- storage::vector_backend

echo "2. Kompiliere RAG-Service"
cd ../../services/rag
cargo check --features "vectors"

echo "3. Ingest-Test (wenn RAG-Service implementiert ist)"
# curl -s http://localhost:8647/ingest -d '{"id":"doc1","namespace":"demo","text":"hello world","embedding":[0.0,0.1]}' \
#   -H 'content-type: application/json'

echo "4. Query-Test (wenn RAG-Service implementiert ist)"
# curl -s http://localhost:8647/query -d '{"query_embedding":[0.0,0.1], "top_k":3}' \
#   -H 'content-type: application/json'

echo "Alle Tests abgeschlossen"
