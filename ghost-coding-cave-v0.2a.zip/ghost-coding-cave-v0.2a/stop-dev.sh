#!/bin/bash

# Ghost Coding Cave v0.2a - Stop Script

echo "🛑 Stopping Ghost Coding Cave v0.2a..."

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

# Stop Node processes
if [ -f .api.pid ]; then
    API_PID=$(cat .api.pid)
    echo -e "${RED}Stopping API (PID: $API_PID)...${NC}"
    kill $API_PID 2>/dev/null || echo "API already stopped"
    rm .api.pid
fi

if [ -f .dashboard.pid ]; then
    DASHBOARD_PID=$(cat .dashboard.pid)
    echo -e "${RED}Stopping Dashboard (PID: $DASHBOARD_PID)...${NC}"
    kill $DASHBOARD_PID 2>/dev/null || echo "Dashboard already stopped"
    rm .dashboard.pid
fi

# Stop Docker services
echo -e "${RED}Stopping Docker services...${NC}"
docker-compose down

echo ""
echo -e "${GREEN}✅ All services stopped${NC}"
