#!/bin/bash

# Update ghost:: to gst:: in all Rust files
find ghost-core -name "*.rs" -type f -exec sed -i 's/\bghost::/gst::/g' {} \;

# Update use ghost:: to use gst:: in all Rust files
find ghost-core -name "*.rs" -type f -exec sed -i 's/use ghost::/use gst::/g' {} \;

echo "Updated all ghost:: to gst:: in the ghost-core crate"
