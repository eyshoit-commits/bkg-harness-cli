# <sub><img height="18" src="https://octicons-col.vercel.app/plug/A770EF">&nbsp;&nbsp;MODEL CONTEXT PROTOCOL</sub>

ghost server is also a **Model Context Protocol (MCP) server**, enabling seamless integration with AI tools and agents that support MCP.

<div align="center">
  <video src="https://github.com/user-attachments/assets/d8f8d854-aebe-4385-b447-3e22a065296b" width="800" controls>
  </video>
</div>

#### What is MCP?

The Model Context Protocol (MCP) is an open standard that allows AI models to securely connect to external data sources and tools. It provides a standardized way for AI assistants to access and interact with various services through a unified interface.

With MCP, your AI can:

- Execute code in secure cavees
- Access real-time data and services
- Perform complex operations safely
- Maintain context across interactions

##

#### Connection Details

ghost server supports MCP connections via **Streamable HTTP transport only**.

- **Transport**: HTTP
- **URL**: `http://localhost:5555/mcp`
- **Method**: Streamable HTTP

##### Server Configuration

When running your ghost server, it automatically exposes MCP endpoints at:

```
http://localhost:5555/mcp
```

> [!NOTE]
> The MCP endpoint uses the same host and port as your main ghost server.

##

#### Getting Started

1. **Start your ghost server**:

   ```sh
   gst server start --dev
   ```

2. **Configure your MCP client** with the connection details above

3. **Begin using cave tools** through your AI assistant

   Try these example prompts:

   ```
   "Create a Python cave and run a simple hello world program"
   ```

   ```
   "Start a Node.js cave, install express, and create a basic web server"
   ```

   ```
   "Execute this shell command in a cave: curl -s https://api.github.com/users/octocat"
   ```

##

#### Available Tools

The ghost MCP server provides these tools:

- `cave_start` - Create and start new cavees
- `cave_stop` - Stop running cavees
- `cave_run_code` - Execute code in cavees
- `cave_run_command` - Run shell commands
- `cave_get_metrics` - Monitor cave status
