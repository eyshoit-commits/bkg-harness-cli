//! Management components for the ghost runtime.
//!
//! This module serves as the central management system for ghost, providing
//! functionality for managing cavees, images, environments, root filesystems,
//! and databases. It coordinates the various components needed for container
//! and cave operations.
//!
//! Key components:
//! - `db`: Database management for storing container and cave metadata
//! - `image`: Container image handling and registry operations
//! - `menv`: ghost environment management
//! - `rootfs`: Root filesystem operations for containers
//! - `cave`: Cave creation and management
//! - `orchestra`: Orchestra management for cavees
//! - `home`: Home directory management
//! - `toolchain`: Toolchain management

//--------------------------------------------------------------------------------------------------
// Exports
//--------------------------------------------------------------------------------------------------

pub mod cave;
pub mod config;
pub mod db;
pub mod home;
pub mod image;
pub mod menv;
pub mod orchestra;
pub mod rootfs;
pub mod toolchain;
