//! ghost configuration helpers for cave definitions.

pub mod microcave;

pub use microcave::*;
