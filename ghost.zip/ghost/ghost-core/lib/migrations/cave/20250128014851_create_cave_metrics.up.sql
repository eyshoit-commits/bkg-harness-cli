-- Add up migration script here

-- Create cave_metrics table
CREATE TABLE IF NOT EXISTS cave_metrics (
    id INTEGER PRIMARY KEY,
    cave_id INTEGER NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    cpu_usage_percent REAL,
    memory_usage_bytes INTEGER,
    disk_usage_bytes INTEGER,
    FOREIGN KEY(cave_id) REFERENCES cave(id)
);

-- Create index
CREATE INDEX IF NOT EXISTS idx_cave_metrics_cave_id_timestamp ON cave_metrics(cave_id, timestamp);
