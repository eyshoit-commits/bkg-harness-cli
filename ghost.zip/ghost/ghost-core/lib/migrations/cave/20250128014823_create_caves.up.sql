-- Add up migration script here

-- Create cavees table
CREATE TABLE IF NOT EXISTS cavees (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    config_file TEXT NOT NULL,
    config_last_modified DATETIME NOT NULL,
    status TEXT NOT NULL,
    supervisor_pid INTEGER NOT NULL,
    microvm_pid INTEGER NOT NULL,
    rootfs_paths TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_cavees_name ON cavees(name, config_file);
