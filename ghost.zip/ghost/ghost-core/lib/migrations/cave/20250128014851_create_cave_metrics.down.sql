-- Add down migration script here

-- Drop index first
DROP INDEX IF EXISTS idx_cave_metrics_cave_id_timestamp;

-- Drop cave_metrics table
DROP TABLE IF EXISTS cave_metrics;
