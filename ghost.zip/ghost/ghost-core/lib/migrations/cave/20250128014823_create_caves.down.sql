-- Add down migration script here

-- Drop indexes first
DROP INDEX IF EXISTS idx_cavees_name;

-- Drop cavees table
DROP TABLE IF EXISTS cavees;
