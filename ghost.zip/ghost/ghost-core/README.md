<div align="center">
  <!-- <a href="https://github.com/ghost/ghost" target="_blank">
    <img src="https://raw.githubusercontent.com/ghost/ghost/main/assets/logo-purple-gradient.png" alt="ghost logo" width="100"></img>
  </a> -->

  <h1>ghost-core</h1>
</div>
