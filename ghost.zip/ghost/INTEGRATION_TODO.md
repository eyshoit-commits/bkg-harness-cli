# 🔄 Ghost v0.2a Integration — TODO

**Integrationsplan für ghost-coding-cave-v0.2a Entwicklungen**

---

## 📋 Status: Bereit zum Start

**Analysiert am:** 2. November 2025  
**Basis:** ghost (aktuell)  
**Quelle:** ghost-coding-cave-v0.2a  
**Dokumentation:** `/home/wind/ide/docs/`

---

## 🎯 Phase 1: Foundation (Woche 1-2)

### ✅ Task 1.1: Dokumentation übernehmen
```bash
# Wichtigste Docs aus v0.2a kopieren
cp ../ghost-coding-cave-v0.2a/AGENTS.md ./
cp ../ghost-coding-cave-v0.2a/STATUS.md ./
cp ../ghost-coding-cave-v0.2a/NAVIGATION.md ./
cp ../ghost-coding-cave-v0.2a/QUICK_START.md ./
cp ../ghost-coding-cave-v0.2a/PHASE2_CHECKLIST.md ./
cp ../ghost-coding-cave-v0.2a/SERVICE_OPERATIONS.md ./

# docs/ Verzeichnis erweitern
cp -r ../ghost-coding-cave-v0.2a/docs/* ./docs/
```

**Geschätzte Zeit:** 2 Stunden  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

### ✅ Task 1.2: Environment Setup
```bash
# .env.example erstellen
cat > .env.example << 'EOF'
# Database
DATABASE_URL=postgresql://ghost:ghost@localhost:5432/ghost
HELPER_DB_PATH=./data/helper.db

# Semantic Store
SEMANTIC_STORE_URL=http://localhost:8443
SEMANTIC_STORE_GRPC=http://localhost:9443

# AI Server
AI_SERVER_URL=http://localhost:5001
HELPER_DB_PATH=./data/helper.db

# Gateway
GATEWAY_PORT=8000
GATEWAY_MAX_CONCURRENCY=10

# Monitoring
RUST_LOG=info
OTLP_ENDPOINT=http://localhost:4317

# Security
GHOST_API_KEY=your-api-key-here
EOF

# .gitignore erweitern
cat >> .gitignore << 'EOF'
.env
.env.local
data/
target/
node_modules/
.next/
dist/
EOF
```

**Geschätzte Zeit:** 30 Minuten  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

### ✅ Task 1.3: Semantic-Store Service hinzufügen
```bash
# Struktur erstellen
mkdir -p services/semantic-store

# Service-Code kopieren
cp -r ../ghost-coding-cave-v0.2a/services/semantic-store/* \
      services/semantic-store/

# Workspace-Mitglieder prüfen
ls -la services/semantic-store/
# Sollte enthalten: ss-api, ss-cli, ss-core, ss-gf, ss-gp, etc.
```

**Geschätzte Zeit:** 1 Tag  
**Priorität:** Kritisch  
**Status:** ⏳ Pending

**Checkliste:**
- [ ] Verzeichnis erstellt
- [ ] Code kopiert
- [ ] Dependencies geprüft
- [ ] Build getestet: `cd services/semantic-store && cargo build`
- [ ] Tests ausgeführt: `cargo test -p ss-core`

---

### ✅ Task 1.4: Cargo Workspace konfigurieren

**Datei:** `Cargo.toml` (Root)

```toml
[workspace]
members = [
    "ghost-cli",
    "ghost-core",
    "ghost-portal",
    "ghost-server",
    "ghost-utils",
    "services/semantic-store/ss-api",
    "services/semantic-store/ss-cli",
    "services/semantic-store/ss-core",
    "services/semantic-store/ss-gf",
    "services/semantic-store/ss-gp",
    "services/semantic-store/ss-index",
    "services/semantic-store/ss-metrics",
    "services/semantic-store/ss-pgml",
    "services/semantic-store/ss-plugins",
    "services/semantic-store/ss-query",
]

[workspace.dependencies]
# Core
tokio = { version = "1.35", features = ["full"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"

# Web
axum = "0.7"
tower = "0.4"
tower-http = { version = "0.5", features = ["cors", "trace"] }

# Database
sqlx = { version = "0.7", features = ["postgres", "runtime-tokio-native-tls", "uuid", "json"] }

# Tracing
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter"] }
opentelemetry = "0.21"

# gRPC
tonic = "0.10"
prost = "0.12"

# Crypto
sha3 = "0.10"

# Compression
zstd = "0.13"
tar = "0.4"
```

**Geschätzte Zeit:** 2 Stunden  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

### ✅ Task 1.5: Docker-Compose erweitern

**Datei:** `docker-compose.yml`

```yaml
version: '3.8'

services:
  postgres:
    image: pgvector/pgvector:pg16
    environment:
      POSTGRES_DB: ghost
      POSTGRES_USER: ghost
      POSTGRES_PASSWORD: ghost
    ports:
      - "5432:5432"
    volumes:
      - postgres-data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ghost"]
      interval: 10s
      timeout: 5s
      retries: 5

  semantic-store:
    build:
      context: ./services/semantic-store
      dockerfile: Dockerfile
    ports:
      - "8443:8443"  # HTTP API
      - "9443:9443"  # gRPC API
    environment:
      - DATABASE_URL=postgresql://ghost:ghost@postgres:5432/ghost
      - RUST_LOG=info
      - OTLP_ENDPOINT=http://jaeger:4317
    volumes:
      - semantic-store-data:/data
      - semantic-store-wal:/wal
    depends_on:
      postgres:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8443/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Optional: Monitoring
  jaeger:
    image: jaegertracing/all-in-one:latest
    ports:
      - "16686:16686"  # UI
      - "4317:4317"    # OTLP gRPC
    environment:
      - COLLECTOR_OTLP_ENABLED=true

volumes:
  postgres-data:
  semantic-store-data:
  semantic-store-wal:
```

**Geschätzte Zeit:** 1 Tag  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

## 🎯 Phase 2: Rust-Core Workspace (Woche 3-4)

### ✅ Task 2.1: Rust-Core Struktur erstellen
```bash
mkdir -p rust-core/{crates,services}
mkdir -p rust-core/crates/{ai-server,gateway,helper-core,semantic-adapter,storage-adapter}
```

**Geschätzte Zeit:** 3 Tage  
**Priorität:** Mittel  
**Status:** ⏳ Pending

---

### ✅ Task 2.2: AI-Server integrieren
```bash
cp -r ../ghost-coding-cave-v0.2a/rust-core/crates/ai-server/* \
      rust-core/crates/ai-server/
```

**Features:**
- Model Registry (Port 5001)
- Chat API
- Embeddings
- Multimodal Support

**Geschätzte Zeit:** 2 Tage  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

## 🎯 Phase 3: TypeScript Services (Woche 3-4)

### ✅ Task 3.1: Apps & Packages Struktur
```bash
mkdir -p apps/{api,dashboard}
mkdir -p packages/{database,types}

# NestJS API
cp -r ../ghost-coding-cave-v0.2a/apps/api/* apps/api/

# Next.js Dashboard
cp -r ../ghost-coding-cave-v0.2a/apps/dashboard/* apps/dashboard/

# Packages
cp -r ../ghost-coding-cave-v0.2a/packages/* packages/
```

**Geschätzte Zeit:** 3 Tage  
**Priorität:** Mittel  
**Status:** ⏳ Pending

---

### ✅ Task 3.2: Package.json & Turbo konfigurieren

**Datei:** `package.json` (Root)

```json
{
  "name": "ghost-monorepo",
  "version": "1.0.0",
  "private": true,
  "workspaces": [
    "apps/*",
    "packages/*"
  ],
  "scripts": {
    "dev": "turbo run dev",
    "build": "turbo run build",
    "test": "turbo run test",
    "lint": "turbo run lint",
    "db:generate": "cd packages/database && npx prisma generate",
    "db:migrate": "cd packages/database && npx prisma migrate dev"
  },
  "devDependencies": {
    "turbo": "^1.10.0",
    "typescript": "^5.2.0"
  }
}
```

**Geschätzte Zeit:** 1 Tag  
**Priorität:** Mittel  
**Status:** ⏳ Pending

---

## 🎯 Phase 4: .ghost Format (Woche 5)

### ✅ Task 4.1: Ghost Format Crate entwickeln

**Details:** Siehe `/home/wind/ide/docs/INTEGRATION_PLAN.md` Phase 5

**Checkliste:**
- [ ] GhostManifest Struktur definieren
- [ ] Capsule Container implementieren
- [ ] SHA3-256 Hashing
- [ ] TAR + zstd Kompression
- [ ] CLI-Tool (convert, validate, inspect)

**Geschätzte Zeit:** 1 Woche  
**Priorität:** Mittel  
**Status:** ⏳ Pending

---

## 🎯 Phase 5: Tests & CI/CD (Woche 6)

### ✅ Task 5.1: Integration Tests

**Datei:** `tests/integration_test.rs`

```rust
#[tokio::test]
async fn test_semantic_store_flow() {
    // 1. Modell hochladen
    // 2. Manifest validieren
    // 3. Metadaten abfragen
    // 4. Binary download
}
```

**Geschätzte Zeit:** 2 Tage  
**Priorität:** Hoch  
**Status:** ⏳ Pending

---

### ✅ Task 5.2: GitHub Actions CI/CD

**Datei:** `.github/workflows/rust-ci.yml`

```yaml
name: Rust CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions-rs/toolchain@v1
      - name: Build
        run: cargo build --workspace
      - name: Test
        run: cargo test --workspace
      - name: Clippy
        run: cargo clippy -- -D warnings
      - name: Audit
        run: cargo audit
```

**Geschätzte Zeit:** 1 Tag  
**Priorität:** Mittel  
**Status:** ⏳ Pending

---

## 📊 Fortschritt-Tracking

### Woche 1-2: Foundation
- [ ] Task 1.1: Dokumentation (2h)
- [ ] Task 1.2: Environment (30min)
- [ ] Task 1.3: Semantic-Store (1 Tag)
- [ ] Task 1.4: Cargo Workspace (2h)
- [ ] Task 1.5: Docker-Compose (1 Tag)

**Geschätzte Gesamt-Zeit:** 2-3 Tage

### Woche 3-4: Core Services
- [ ] Task 2.1: Rust-Core Struktur (3 Tage)
- [ ] Task 2.2: AI-Server (2 Tage)
- [ ] Task 3.1: TypeScript Apps (3 Tage)
- [ ] Task 3.2: Package.json (1 Tag)

**Geschätzte Gesamt-Zeit:** 9 Tage

### Woche 5: .ghost Format
- [ ] Task 4.1: Ghost Format (1 Woche)

### Woche 6: Tests & CI/CD
- [ ] Task 5.1: Integration Tests (2 Tage)
- [ ] Task 5.2: CI/CD (1 Tag)

**Gesamtdauer:** ~6 Wochen

---

## 🚨 Kritische Abhängigkeiten

```
Task 1.3 (Semantic-Store) ──> Task 1.4 (Cargo Workspace)
                           └──> Task 1.5 (Docker-Compose)

Task 2.2 (AI-Server) ──────> Task 5.1 (Integration Tests)

Task 3.1 (TypeScript) ─────> Task 3.2 (Package.json)

Task 4.1 (.ghost Format) ──> Task 5.1 (Integration Tests)
```

---

## ✅ Erfolgskriterien

**Phase 1 erfolgreich wenn:**
- [ ] Semantic-Store builds ohne Fehler
- [ ] Docker-Compose startet alle Services
- [ ] Health-Checks sind grün
- [ ] Dokumentation ist aktuell

**Gesamt-Integration erfolgreich wenn:**
- [ ] Alle Tests bestehen (>20 passing)
- [ ] Semantic-Store API läuft (8443/9443)
- [ ] .ghost Format funktioniert
- [ ] CI/CD Pipeline aktiv
- [ ] Production-Deploy möglich

---

## 📞 Ressourcen

**Hauptdokumentation:** `/home/wind/ide/docs/`
- INDEX.md — Übersicht
- INTEGRATION_PLAN.md — Detailplan
- CODE_DIFF_ANALYSIS.md — Technischer Vergleich
- ACTION_ITEMS.md — Konkrete Schritte

**Quell-Projekt:** `/home/wind/code/ghost-coding-cave-v0.2a`

---

**Erstellt:** 2. November 2025  
**Status:** Bereit zur Ausführung  
**Erster Schritt:** Task 1.1 (Dokumentation kopieren)  
**Branch:** `feature/v0.2a-integration` (erstellen!)
