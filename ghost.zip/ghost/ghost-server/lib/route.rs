//! Router configuration for the ghost server.
//!
//! This module handles:
//! - API route definitions
//! - Router configuration and setup
//! - Request routing and handling
//!
//! The module provides:
//! - Router creation and configuration
//! - Route handlers and middleware integration
//! - State management for routes

use axum::{middleware, routing::post, Router};

use crate::{admin, handler, middleware as app_middleware, state::AppState};

//--------------------------------------------------------------------------------------------------
// Functions
//--------------------------------------------------------------------------------------------------

/// Create a new router with the given state
pub fn create_router(state: AppState) -> Router {
    // Create REST API routes - only health endpoint remains here
    let rest_api = Router::new().route("/health", get(handler::health));

    // Create JSON-RPC routes with authentication - a single endpoint that handles all RPC methods
    // This now mirrors the structure used in ghost-portal
    let rpc_api = Router::new()
        .route("/", post(handler::json_rpc_handler))
        .layer(middleware::from_fn_with_state(
            state.clone(),
            app_middleware::auth_middleware,
        ));

    // Create MCP routes - separate endpoint for Model Context Protocol
    // Uses smart auth middleware that handles protocol vs tool methods differently
    let mcp_api =
        Router::new()
            .route("/", post(handler::mcp_handler))
            .layer(middleware::from_fn_with_state(
                state.clone(),
                app_middleware::mcp_smart_auth_middleware,
            ));

    // Create admin UI router (HTML + JSON APIs)
    let admin_ui = admin::router();

    // Combine all routes with logging middleware
    Router::new()
        .nest("/admin", admin_ui)
        .nest("/api/v1", rest_api)
        .nest("/api/v1/rpc", rpc_api)
        .nest("/mcp", mcp_api)
        .layer(middleware::from_fn(app_middleware::logging_middleware))
        .with_state(state)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{admin::AdminContext, config::Config, port::PortManager};
    use axum::{
        body::Body,
        http::{Request, StatusCode},
    };
    use std::sync::Arc;
    use tempfile::tempdir;
    use tokio::sync::RwLock;
    use tower::ServiceExt;

    #[tokio::test]
    async fn admin_route_serves_dashboard() {
        let temp_dir = tempdir().expect("tempdir");
        let config = Arc::new(
            Config::new(
                None,
                "127.0.0.1".to_string(),
                4100,
                Some(temp_dir.path().to_path_buf()),
                true,
            )
            .expect("config"),
        );
        let port_manager = PortManager::new(temp_dir.path())
            .await
            .expect("port manager");
        let admin = Arc::new(AdminContext::new(config.clone()).await.expect("admin"));
        let state = AppState::new(config.clone(), Arc::new(RwLock::new(port_manager)), admin);
        let app = create_router(state);

        let response = app
            .oneshot(
                Request::builder()
                    .uri("/admin")
                    .body(Body::empty())
                    .expect("request"),
            )
            .await
            .expect("response");

        assert_eq!(response.status(), StatusCode::OK);
    }
}
