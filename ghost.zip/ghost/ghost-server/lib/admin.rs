//! Administrative web interface and backend services for the ghost server.
//!
//! This module implements an authenticated admin console backed by a SQLite
//! database. It exposes APIs that the embedded web UI consumes to manage caves,
//! projects, API keys, and Model Context Protocol tooling.

use std::{path::PathBuf, sync::Arc};

use argon2::{
    password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use axum::{
    extract::{Path, State},
    http::StatusCode,
    response::Html,
    routing::{delete, get, post},
    Json, Router,
};
use axum_extra::extract::cookie::{Cookie, CookieJar, SameSite};
use chrono::{DateTime, Duration as ChronoDuration, Utc};
use rand::{distributions::Alphanumeric, rngs::OsRng, Rng as _};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sqlx::{
    sqlite::{SqliteConnectOptions, SqliteJournalMode, SqlitePoolOptions, SqliteSynchronous},
    FromRow, SqlitePool,
};
use time::Duration as TimeDuration;
use tokio::fs;
use tracing::warn;
use uuid::Uuid;

use crate::{
    config::Config,
    error::{AuthenticationError, ServerError, ServerResult},
    ghostServerError, ghostServerResult, management,
    state::AppState,
};

//--------------------------------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------------------------------

const ADMIN_DIR: &str = "admin";
const ADMIN_DB_FILE: &str = "console.sqlite";
const SESSION_COOKIE: &str = "ghost_admin_session";
const SESSION_TOKEN_LENGTH: usize = 64;
const SESSION_DURATION_HOURS: i64 = 12;
const DEFAULT_PASSWORD_LENGTH: usize = 24;

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

#[derive(Clone)]
pub struct AdminContext {
    pool: SqlitePool,
    argon2: Argon2<'static>,
    session_ttl: ChronoDuration,
}

#[derive(Debug, Clone, Serialize)]
struct SessionResponse {
    username: String,
    expires_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize)]
struct CaveOverview {
    namespace: String,
    name: String,
    port: u16,
}

#[derive(Debug, Clone, Serialize)]
struct OverviewResponse {
    session: SessionResponse,
    caves: Vec<CaveOverview>,
    projects: Vec<ProjectRecord>,
    api_keys: Vec<ApiKeyOverview>,
    mcp_tools: Vec<McpToolRecord>,
}

#[derive(Debug, Clone, Serialize)]
struct ApiKeySecretResponse {
    token: String,
    overview: ApiKeyOverview,
}

#[derive(Debug, Clone, Serialize)]
struct ApiKeyOverview {
    label: String,
    namespace: String,
    token: String,
    token_preview: String,
    expires_at: DateTime<Utc>,
    created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize)]
struct ProjectRecord {
    id: String,
    name: String,
    namespace: Option<String>,
    description: Option<String>,
    metadata: Value,
    created_at: DateTime<Utc>,
    updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize)]
struct McpToolRecord {
    id: String,
    name: String,
    endpoint: String,
    description: Option<String>,
    api_key: Option<String>,
    created_at: DateTime<Utc>,
    updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone)]
struct SessionData {
    token: String,
    username: String,
    expires_at: DateTime<Utc>,
}

#[derive(Debug, Clone, FromRow)]
struct ProjectRow {
    id: String,
    name: String,
    namespace: Option<String>,
    description: Option<String>,
    metadata: Option<String>,
    created_at: String,
    updated_at: String,
}

#[derive(Debug, Clone, FromRow)]
struct ApiKeyRow {
    token: String,
    label: String,
    namespace: String,
    expires_at: String,
    created_at: String,
}

#[derive(Debug, Clone, FromRow)]
struct McpToolRow {
    id: String,
    name: String,
    endpoint: String,
    description: Option<String>,
    api_key: Option<String>,
    created_at: String,
    updated_at: String,
}

#[derive(Debug, Clone, FromRow)]
struct AdminUserRow {
    id: i64,
    username: String,
    password_hash: String,
}

#[derive(Debug, Clone, FromRow)]
struct SessionRow {
    token: String,
    expires_at: String,
    username: String,
}

#[derive(Debug, Deserialize)]
struct LoginRequest {
    username: String,
    password: String,
}

#[derive(Debug, Deserialize)]
struct ProjectPayload {
    id: Option<String>,
    name: String,
    namespace: Option<String>,
    description: Option<String>,
    metadata: Option<Value>,
}

#[derive(Debug, Deserialize)]
struct ApiKeyRequest {
    label: String,
    namespace: String,
    expire_hours: Option<i64>,
}

#[derive(Debug, Deserialize)]
struct McpToolPayload {
    id: Option<String>,
    name: String,
    endpoint: String,
    description: Option<String>,
    api_key: Option<String>,
}

//--------------------------------------------------------------------------------------------------
// Router
//--------------------------------------------------------------------------------------------------

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/", get(admin_page))
        .route(
            "/api/session",
            get(session_info)
                .post(create_session)
                .delete(destroy_session),
        )
        .route("/api/overview", get(overview))
        .route("/api/projects", post(upsert_project))
        .route("/api/projects/:id", delete(delete_project))
        .route("/api/api-keys", post(generate_api_key))
        .route("/api/api-keys/:token", delete(delete_api_key))
        .route("/api/mcp-tools", post(upsert_mcp_tool))
        .route("/api/mcp-tools/:id", delete(delete_mcp_tool))
}

pub async fn admin_page() -> Html<&'static str> {
    Html(ADMIN_PAGE_HTML)
}

//--------------------------------------------------------------------------------------------------
// AdminContext
//--------------------------------------------------------------------------------------------------

impl AdminContext {
    pub async fn new(config: Arc<Config>) -> ghostServerResult<Self> {
        let admin_dir = Self::admin_directory(config.get_namespace_dir().clone());
        fs::create_dir_all(&admin_dir).await.map_err(|err| {
            ghostServerError::ConfigError(format!(
                "failed to create admin directory at {}: {}",
                admin_dir.display(),
                err
            ))
        })?;

        let db_path = admin_dir.join(ADMIN_DB_FILE);
        let options = SqliteConnectOptions::new()
            .filename(&db_path)
            .create_if_missing(true)
            .journal_mode(SqliteJournalMode::Wal)
            .synchronous(SqliteSynchronous::Normal);

        let pool = SqlitePoolOptions::new()
            .max_connections(5)
            .connect_with(options)
            .await
            .map_err(|err| {
                ghostServerError::ConfigError(format!(
                    "failed to open admin database {}: {}",
                    db_path.display(),
                    err
                ))
            })?;

        sqlx::query("PRAGMA foreign_keys = ON;")
            .execute(&pool)
            .await
            .map_err(|err| {
                ghostServerError::ConfigError(format!(
                    "failed to enable foreign keys for {}: {}",
                    db_path.display(),
                    err
                ))
            })?;

        let context = Self {
            pool: pool.clone(),
            argon2: Argon2::default(),
            session_ttl: ChronoDuration::hours(SESSION_DURATION_HOURS),
        };

        context.prepare_schema().await?;
        if let Some((username, password)) = context.ensure_default_admin().await? {
            warn!(
                "Created default admin account — username: `{}`, password: `{}`. Please rotate it immediately.",
                username, password
            );
        }

        Ok(context)
    }

    fn admin_directory(namespace_dir: PathBuf) -> PathBuf {
        namespace_dir
            .parent()
            .map(PathBuf::from)
            .unwrap_or(namespace_dir)
            .join(ADMIN_DIR)
    }

    async fn prepare_schema(&self) -> ghostServerResult<()> {
        let statements = [
            "CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS sessions (
                token TEXT PRIMARY KEY,
                admin_id INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                FOREIGN KEY(admin_id) REFERENCES admins(id) ON DELETE CASCADE
            )",
            "CREATE TABLE IF NOT EXISTS admin_projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                namespace TEXT,
                description TEXT,
                metadata TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS admin_api_keys (
                token TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                namespace TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL
            )",
            "CREATE TABLE IF NOT EXISTS admin_mcp_tools (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                endpoint TEXT NOT NULL,
                description TEXT,
                api_key TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )",
        ];

        for statement in statements {
            sqlx::query(statement)
                .execute(&self.pool)
                .await
                .map_err(|err| {
                    ghostServerError::ConfigError(format!(
                        "failed to initialise admin schema: {}",
                        err
                    ))
                })?;
        }

        Ok(())
    }

    async fn ensure_default_admin(&self) -> ghostServerResult<Option<(String, String)>> {
        let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM admins")
            .fetch_one(&self.pool)
            .await
            .map_err(|err| {
                ghostServerError::ConfigError(format!("failed to inspect admin table: {}", err))
            })?;

        if count > 0 {
            return Ok(None);
        }

        let username =
            std::env::var("GHOST_ADMIN_USERNAME").unwrap_or_else(|_| "admin".to_string());
        let password = std::env::var("GHOST_ADMIN_PASSWORD")
            .unwrap_or_else(|_| generate_secret(DEFAULT_PASSWORD_LENGTH));

        let salt = SaltString::generate(&mut OsRng);
        let password_hash = self
            .argon2
            .hash_password(password.as_bytes(), &salt)
            .map_err(|err| {
                ghostServerError::ConfigError(format!(
                    "failed to hash default admin password: {}",
                    err
                ))
            })?
            .to_string();

        let now = Utc::now().to_rfc3339();

        sqlx::query("INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)")
            .bind(&username)
            .bind(&password_hash)
            .bind(&now)
            .execute(&self.pool)
            .await
            .map_err(|err| {
                ghostServerError::ConfigError(format!("failed to insert default admin: {}", err))
            })?;

        Ok(Some((username, password)))
    }

    async fn authenticate(
        &self,
        username: &str,
        password: &str,
    ) -> ServerResult<Option<SessionData>> {
        let maybe_user = sqlx::query_as::<_, AdminUserRow>(
            "SELECT id, username, password_hash FROM admins WHERE username = ?",
        )
        .bind(username)
        .fetch_optional(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        let Some(user) = maybe_user else {
            return Ok(None);
        };

        let parsed = PasswordHash::new(&user.password_hash).map_err(|err| {
            ServerError::InternalError(format!("stored password hash invalid: {}", err))
        })?;

        if self
            .argon2
            .verify_password(password.as_bytes(), &parsed)
            .is_err()
        {
            return Ok(None);
        }

        self.issue_session(user.id, &user.username).await.map(Some)
    }

    async fn issue_session(&self, admin_id: i64, username: &str) -> ServerResult<SessionData> {
        let token = generate_secret(SESSION_TOKEN_LENGTH);
        let now = Utc::now();
        let expires_at = now + self.session_ttl;

        sqlx::query(
            "INSERT INTO sessions (token, admin_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        )
        .bind(&token)
        .bind(admin_id)
        .bind(now.to_rfc3339())
        .bind(expires_at.to_rfc3339())
        .execute(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        Ok(SessionData {
            token,
            username: username.to_string(),
            expires_at,
        })
    }

    async fn resolve_session(&self, token: &str) -> ServerResult<Option<SessionData>> {
        let row = sqlx::query_as::<_, SessionRow>(
            "SELECT s.token, s.expires_at, a.username
             FROM sessions s
             JOIN admins a ON a.id = s.admin_id
             WHERE s.token = ?",
        )
        .bind(token)
        .fetch_optional(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        let Some(row) = row else {
            return Ok(None);
        };

        let expires_at = parse_datetime(&row.expires_at)?;
        if expires_at < Utc::now() {
            self.revoke_session(token).await?;
            return Ok(None);
        }

        Ok(Some(SessionData {
            token: row.token,
            username: row.username,
            expires_at,
        }))
    }

    async fn revoke_session(&self, token: &str) -> ServerResult<()> {
        sqlx::query("DELETE FROM sessions WHERE token = ?")
            .bind(token)
            .execute(&self.pool)
            .await
            .map_err(map_sqlx_error)?;

        Ok(())
    }

    async fn list_projects(&self) -> ServerResult<Vec<ProjectRecord>> {
        let rows = sqlx::query_as::<_, ProjectRow>(
            "SELECT id, name, namespace, description, metadata, created_at, updated_at
             FROM admin_projects
             ORDER BY updated_at DESC",
        )
        .fetch_all(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        rows.into_iter().map(ProjectRecord::try_from).collect()
    }

    async fn upsert_project(&self, payload: ProjectPayload) -> ServerResult<ProjectRecord> {
        let id = payload.id.unwrap_or_else(|| Uuid::new_v4().to_string());
        let metadata = payload.metadata.clone().map(|value| value.to_string());
        let now = Utc::now().to_rfc3339();

        sqlx::query(
            "INSERT INTO admin_projects (id, name, namespace, description, metadata, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,
                namespace=excluded.namespace,
                description=excluded.description,
                metadata=excluded.metadata,
                updated_at=excluded.updated_at",
        )
        .bind(&id)
        .bind(&payload.name)
        .bind(&payload.namespace)
        .bind(&payload.description)
        .bind(&metadata)
        .bind(&now)
        .bind(&now)
        .execute(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        self.get_project(&id).await
    }

    async fn get_project(&self, id: &str) -> ServerResult<ProjectRecord> {
        let row = sqlx::query_as::<_, ProjectRow>(
            "SELECT id, name, namespace, description, metadata, created_at, updated_at
             FROM admin_projects WHERE id = ?",
        )
        .bind(id)
        .fetch_one(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        ProjectRecord::try_from(row)
    }

    async fn delete_project(&self, id: &str) -> ServerResult<()> {
        let result = sqlx::query("DELETE FROM admin_projects WHERE id = ?")
            .bind(id)
            .execute(&self.pool)
            .await
            .map_err(map_sqlx_error)?;

        if result.rows_affected() == 0 {
            return Err(ServerError::NotFound(format!("project {} not found", id)));
        }

        Ok(())
    }

    async fn list_api_keys(&self) -> ServerResult<Vec<ApiKeyOverview>> {
        let rows = sqlx::query_as::<_, ApiKeyRow>(
            "SELECT token, label, namespace, expires_at, created_at FROM admin_api_keys ORDER BY created_at DESC",
        )
        .fetch_all(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        rows.into_iter().map(ApiKeyOverview::try_from).collect()
    }

    async fn store_api_key(
        &self,
        label: &str,
        namespace: &str,
        token: &str,
        expires_at: DateTime<Utc>,
    ) -> ServerResult<ApiKeyOverview> {
        let created_at = Utc::now();

        sqlx::query(
            "INSERT OR REPLACE INTO admin_api_keys (token, label, namespace, expires_at, created_at)
             VALUES (?, ?, ?, ?, ?)",
        )
        .bind(token)
        .bind(label)
        .bind(namespace)
        .bind(expires_at.to_rfc3339())
        .bind(created_at.to_rfc3339())
        .execute(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        ApiKeyOverview::try_from(ApiKeyRow {
            token: token.to_string(),
            label: label.to_string(),
            namespace: namespace.to_string(),
            expires_at: expires_at.to_rfc3339(),
            created_at: created_at.to_rfc3339(),
        })
    }

    async fn delete_api_key(&self, token: &str) -> ServerResult<()> {
        let result = sqlx::query("DELETE FROM admin_api_keys WHERE token = ?")
            .bind(token)
            .execute(&self.pool)
            .await
            .map_err(map_sqlx_error)?;

        if result.rows_affected() == 0 {
            return Err(ServerError::NotFound("API key not found".to_string()));
        }

        Ok(())
    }

    async fn list_mcp_tools(&self) -> ServerResult<Vec<McpToolRecord>> {
        let rows = sqlx::query_as::<_, McpToolRow>(
            "SELECT id, name, endpoint, description, api_key, created_at, updated_at FROM admin_mcp_tools ORDER BY updated_at DESC",
        )
        .fetch_all(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        rows.into_iter().map(McpToolRecord::try_from).collect()
    }

    async fn upsert_mcp_tool(&self, payload: McpToolPayload) -> ServerResult<McpToolRecord> {
        let id = payload.id.unwrap_or_else(|| Uuid::new_v4().to_string());
        let now = Utc::now().to_rfc3339();

        sqlx::query(
            "INSERT INTO admin_mcp_tools (id, name, endpoint, description, api_key, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,
                endpoint=excluded.endpoint,
                description=excluded.description,
                api_key=excluded.api_key,
                updated_at=excluded.updated_at",
        )
        .bind(&id)
        .bind(&payload.name)
        .bind(&payload.endpoint)
        .bind(&payload.description)
        .bind(&payload.api_key)
        .bind(&now)
        .bind(&now)
        .execute(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        self.get_mcp_tool(&id).await
    }

    async fn get_mcp_tool(&self, id: &str) -> ServerResult<McpToolRecord> {
        let row = sqlx::query_as::<_, McpToolRow>(
            "SELECT id, name, endpoint, description, api_key, created_at, updated_at
             FROM admin_mcp_tools WHERE id = ?",
        )
        .bind(id)
        .fetch_one(&self.pool)
        .await
        .map_err(map_sqlx_error)?;

        McpToolRecord::try_from(row)
    }

    async fn delete_mcp_tool(&self, id: &str) -> ServerResult<()> {
        let result = sqlx::query("DELETE FROM admin_mcp_tools WHERE id = ?")
            .bind(id)
            .execute(&self.pool)
            .await
            .map_err(map_sqlx_error)?;

        if result.rows_affected() == 0 {
            return Err(ServerError::NotFound(format!("MCP tool {} not found", id)));
        }

        Ok(())
    }
}

//--------------------------------------------------------------------------------------------------
// Request handlers
//--------------------------------------------------------------------------------------------------

async fn create_session(
    State(state): State<AppState>,
    jar: CookieJar,
    Json(payload): Json<LoginRequest>,
) -> Result<(CookieJar, Json<SessionResponse>), ServerError> {
    let admin = state.get_admin().clone();
    let maybe_session = admin
        .authenticate(&payload.username, &payload.password)
        .await?;

    let Some(session) = maybe_session else {
        return Err(ServerError::Authentication(
            AuthenticationError::InvalidCredentials("invalid credentials".to_string()),
        ));
    };

    let secure_cookie = !state.get_config().get_dev_mode();
    let cookie = Cookie::build((SESSION_COOKIE, session.token.clone()))
        .http_only(true)
        .same_site(SameSite::Strict)
        .secure(secure_cookie)
        .path("/admin")
        .max_age(TimeDuration::hours(SESSION_DURATION_HOURS))
        .finish();

    let jar = jar.add(cookie);

    Ok((
        jar,
        Json(SessionResponse {
            username: session.username,
            expires_at: session.expires_at,
        }),
    ))
}

async fn session_info(
    State(state): State<AppState>,
    jar: CookieJar,
) -> Result<Json<SessionResponse>, ServerError> {
    let session = require_session(&state, &jar).await?;

    Ok(Json(SessionResponse {
        username: session.username,
        expires_at: session.expires_at,
    }))
}

async fn destroy_session(
    State(state): State<AppState>,
    jar: CookieJar,
) -> Result<(CookieJar, StatusCode), ServerError> {
    if let Some(cookie) = jar.get(SESSION_COOKIE) {
        let admin = state.get_admin().clone();
        admin.revoke_session(cookie.value()).await?;
    }

    let cleared = Cookie::build((SESSION_COOKIE, String::new()))
        .path("/admin")
        .http_only(true)
        .same_site(SameSite::Strict)
        .max_age(TimeDuration::seconds(0))
        .finish();

    Ok((jar.remove(cleared), StatusCode::NO_CONTENT))
}

async fn overview(
    State(state): State<AppState>,
    jar: CookieJar,
) -> Result<Json<OverviewResponse>, ServerError> {
    let session = require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();

    let projects = admin.list_projects().await?;
    let api_keys = admin.list_api_keys().await?;
    let mcp_tools = admin.list_mcp_tools().await?;

    let caves = {
        let port_manager = state.get_port_manager().read().await;
        port_manager
            .list_assignments()
            .into_iter()
            .filter_map(|(key, port)| {
                parse_cave_key(&key).map(|(namespace, name)| CaveOverview {
                    namespace,
                    name,
                    port,
                })
            })
            .collect::<Vec<_>>()
    };

    Ok(Json(OverviewResponse {
        session: SessionResponse {
            username: session.username,
            expires_at: session.expires_at,
        },
        caves,
        projects,
        api_keys,
        mcp_tools,
    }))
}

async fn upsert_project(
    State(state): State<AppState>,
    jar: CookieJar,
    Json(payload): Json<ProjectPayload>,
) -> Result<Json<ProjectRecord>, ServerError> {
    require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();
    let record = admin.upsert_project(payload).await?;
    Ok(Json(record))
}

async fn delete_project(
    State(state): State<AppState>,
    jar: CookieJar,
    Path(id): Path<String>,
) -> Result<StatusCode, ServerError> {
    require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();
    admin.delete_project(&id).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn generate_api_key(
    State(state): State<AppState>,
    jar: CookieJar,
    Json(payload): Json<ApiKeyRequest>,
) -> Result<Json<ApiKeySecretResponse>, ServerError> {
    require_session(&state, &jar).await?;

    let admin = state.get_admin().clone();
    let expire_hours = payload.expire_hours.unwrap_or(24).max(1);
    let duration = ChronoDuration::hours(expire_hours);
    let expires_at = Utc::now() + duration;

    let token = management::keygen(Some(duration), payload.namespace.clone())
        .await
        .map_err(|err| ServerError::InternalError(err.to_string()))?;

    let overview = admin
        .store_api_key(&payload.label, &payload.namespace, &token, expires_at)
        .await?;

    Ok(Json(ApiKeySecretResponse { token, overview }))
}

async fn delete_api_key(
    State(state): State<AppState>,
    jar: CookieJar,
    Path(token): Path<String>,
) -> Result<StatusCode, ServerError> {
    require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();
    admin.delete_api_key(&token).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn upsert_mcp_tool(
    State(state): State<AppState>,
    jar: CookieJar,
    Json(payload): Json<McpToolPayload>,
) -> Result<Json<McpToolRecord>, ServerError> {
    require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();
    let record = admin.upsert_mcp_tool(payload).await?;
    Ok(Json(record))
}

async fn delete_mcp_tool(
    State(state): State<AppState>,
    jar: CookieJar,
    Path(id): Path<String>,
) -> Result<StatusCode, ServerError> {
    require_session(&state, &jar).await?;
    let admin = state.get_admin().clone();
    admin.delete_mcp_tool(&id).await?;
    Ok(StatusCode::NO_CONTENT)
}

//--------------------------------------------------------------------------------------------------
// Helpers
//--------------------------------------------------------------------------------------------------

fn map_sqlx_error(err: sqlx::Error) -> ServerError {
    ServerError::DatabaseError(err.to_string())
}

fn parse_datetime(value: &str) -> ServerResult<DateTime<Utc>> {
    DateTime::parse_from_rfc3339(value)
        .map(|dt| dt.with_timezone(&Utc))
        .map_err(|err| ServerError::InternalError(format!("invalid stored timestamp: {}", err)))
}

fn generate_secret(len: usize) -> String {
    OsRng
        .sample_iter(&Alphanumeric)
        .take(len)
        .map(char::from)
        .collect()
}

fn mask_token(token: &str) -> String {
    const VISIBLE: usize = 6;
    if token.len() <= VISIBLE {
        return token.to_string();
    }
    let suffix = &token[token.len() - VISIBLE..];
    format!(
        "{}{}",
        "•".repeat(token.len().saturating_sub(VISIBLE)),
        suffix
    )
}

fn parse_cave_key(key: &str) -> Option<(String, String)> {
    let mut parts = key.splitn(2, '/');
    let namespace = parts.next()?.to_string();
    let name = parts.next()?.to_string();
    Some((namespace, name))
}

async fn require_session(state: &AppState, jar: &CookieJar) -> ServerResult<SessionData> {
    let Some(cookie) = jar.get(SESSION_COOKIE) else {
        return Err(ServerError::Authentication(
            AuthenticationError::InvalidCredentials("session cookie missing".to_string()),
        ));
    };

    let admin = state.get_admin().clone();
    let session = admin.resolve_session(cookie.value()).await?;

    session.ok_or_else(|| {
        ServerError::Authentication(AuthenticationError::InvalidCredentials(
            "session invalid or expired".to_string(),
        ))
    })
}

impl TryFrom<ProjectRow> for ProjectRecord {
    type Error = ServerError;

    fn try_from(row: ProjectRow) -> Result<Self, Self::Error> {
        Ok(Self {
            id: row.id,
            name: row.name,
            namespace: row.namespace,
            description: row.description,
            metadata: row
                .metadata
                .as_deref()
                .and_then(|raw| serde_json::from_str(raw).ok())
                .unwrap_or(Value::Null),
            created_at: parse_datetime(&row.created_at)?,
            updated_at: parse_datetime(&row.updated_at)?,
        })
    }
}

impl TryFrom<ApiKeyRow> for ApiKeyOverview {
    type Error = ServerError;

    fn try_from(row: ApiKeyRow) -> Result<Self, Self::Error> {
        Ok(Self {
            label: row.label,
            namespace: row.namespace,
            token: row.token.clone(),
            token_preview: mask_token(&row.token),
            expires_at: parse_datetime(&row.expires_at)?,
            created_at: parse_datetime(&row.created_at)?,
        })
    }
}

impl TryFrom<McpToolRow> for McpToolRecord {
    type Error = ServerError;

    fn try_from(row: McpToolRow) -> Result<Self, Self::Error> {
        Ok(Self {
            id: row.id,
            name: row.name,
            endpoint: row.endpoint,
            description: row.description,
            api_key: row.api_key,
            created_at: parse_datetime(&row.created_at)?,
            updated_at: parse_datetime(&row.updated_at)?,
        })
    }
}

//--------------------------------------------------------------------------------------------------
// Embedded HTML (defined below)
//--------------------------------------------------------------------------------------------------

const ADMIN_PAGE_HTML: &str = r#"<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>ghost Admin Console</title>
    <style>
        :root {
            color-scheme: dark;
            --bg: #020617;
            --surface: rgba(15, 23, 42, 0.94);
            --border: rgba(148, 163, 184, 0.35);
            --accent: #38bdf8;
            --accent-strong: #0ea5e9;
            --text: #e2e8f0;
            --muted: #94a3b8;
            --danger: #f87171;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        body {
            margin: 0;
            background: var(--bg);
            color: var(--text);
        }

        main {
            max-width: 1100px;
            margin: 0 auto;
            padding: 2rem 1.5rem 3rem;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        h1 {
            font-size: clamp(2rem, 4vw, 3rem);
            margin-bottom: 0.25rem;
        }

        p.lead {
            margin-top: 0;
            color: var(--muted);
        }

        section {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 1.5rem;
        }

        section h2 {
            margin-top: 0;
            font-size: 1.2rem;
        }

        .hidden { display: none; }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 0.35rem;
        }

        input, textarea {
            width: 100%;
            padding: 0.65rem 0.85rem;
            border-radius: 9px;
            border: 1px solid var(--border);
            background: rgba(2, 6, 23, 0.65);
            color: inherit;
            margin-bottom: 0.75rem;
            font-size: 0.95rem;
        }

        textarea { min-height: 96px; }

        button {
            background: var(--accent);
            color: #020617;
            border: none;
            border-radius: 9px;
            padding: 0.6rem 1.25rem;
            font-weight: 600;
            cursor: pointer;
            margin-right: 0.6rem;
        }

        button.secondary {
            background: rgba(148, 163, 184, 0.25);
            color: var(--text);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            font-size: 0.95rem;
        }

        th, td {
            padding: 0.55rem 0.65rem;
            border-bottom: 1px solid rgba(148, 163, 184, 0.25);
            vertical-align: top;
        }

        th {
            text-transform: uppercase;
            font-size: 0.7rem;
            letter-spacing: 0.1em;
            color: var(--muted);
        }

        .status {
            margin-top: 0.5rem;
            font-size: 0.9rem;
            color: var(--muted);
        }

        .status.error { color: var(--danger); }

        .token {
            font-family: 'JetBrains Mono', 'Fira Code', 'SFMono-Regular', Menlo, Consolas, monospace;
        }

        @media (max-width: 720px) {
            table { display: block; overflow-x: auto; }
        }
    </style>
</head>
<body>
    <main>
        <header>
            <h1>ghost Admin Console</h1>
            <p class="lead">Manage caves, projects, API keys, and MCP integrations from a single secure surface.</p>
        </header>

        <section id="login-card">
            <h2>Sign in</h2>
            <form id="login-form">
                <label for="login-username">Username</label>
                <input id="login-username" name="username" autocomplete="username" required />
                <label for="login-password">Password</label>
                <input id="login-password" name="password" type="password" autocomplete="current-password" required />
                <button type="submit">Authenticate</button>
                <div id="login-status" class="status"></div>
            </form>
        </section>

        <section id="session-card" class="hidden">
            <h2>Session</h2>
            <div id="session-info"></div>
            <button id="refresh">Refresh data</button>
            <button id="logout" class="secondary">Sign out</button>
            <div id="session-status" class="status"></div>
        </section>

        <section id="caves-card" class="hidden">
            <h2>Active caves</h2>
            <table>
                <thead>
                    <tr><th>Namespace</th><th>Name</th><th>Portal port</th></tr>
                </thead>
                <tbody id="caves-body"></tbody>
            </table>
        </section>

        <section id="projects-card" class="hidden">
            <h2>Projects</h2>
            <form id="project-form">
                <input type="hidden" id="project-id" />
                <label for="project-name">Name</label>
                <input id="project-name" required />
                <label for="project-namespace">Namespace</label>
                <input id="project-namespace" />
                <label for="project-description">Description</label>
                <textarea id="project-description"></textarea>
                <label for="project-metadata">Metadata (JSON)</label>
                <textarea id="project-metadata" placeholder='{"owner":"ops"}'></textarea>
                <button type="submit">Save project</button>
                <button type="button" class="secondary" id="project-reset">Reset</button>
                <div id="project-status" class="status"></div>
            </form>
            <table>
                <thead>
                    <tr><th>Name</th><th>Namespace</th><th>Updated</th><th>Actions</th></tr>
                </thead>
                <tbody id="projects-body"></tbody>
            </table>
        </section>

        <section id="api-card" class="hidden">
            <h2>API keys</h2>
            <form id="api-form">
                <label for="api-label">Label</label>
                <input id="api-label" required />
                <label for="api-namespace">Namespace</label>
                <input id="api-namespace" required />
                <label for="api-expire">Expires in (hours)</label>
                <input id="api-expire" type="number" min="1" value="24" />
                <button type="submit">Generate token</button>
                <div id="api-status" class="status"></div>
                <div id="api-secret" class="status token"></div>
            </form>
            <table>
                <thead>
                    <tr><th>Label</th><th>Namespace</th><th>Token preview</th><th>Expires</th><th>Created</th><th>Actions</th></tr>
                </thead>
                <tbody id="api-body"></tbody>
            </table>
        </section>

        <section id="mcp-card" class="hidden">
            <h2>MCP tools</h2>
            <form id="mcp-form">
                <input type="hidden" id="mcp-id" />
                <label for="mcp-name">Name</label>
                <input id="mcp-name" required />
                <label for="mcp-endpoint">Endpoint</label>
                <input id="mcp-endpoint" required />
                <label for="mcp-description">Description</label>
                <textarea id="mcp-description"></textarea>
                <label for="mcp-key">API key</label>
                <input id="mcp-key" />
                <button type="submit">Save tool</button>
                <button type="button" class="secondary" id="mcp-reset">Reset</button>
                <div id="mcp-status" class="status"></div>
            </form>
            <table>
                <thead>
                    <tr><th>Name</th><th>Endpoint</th><th>Updated</th><th>Actions</th></tr>
                </thead>
                <tbody id="mcp-body"></tbody>
            </table>
        </section>
    </main>
    <script>
        const qs = (selector) => document.querySelector(selector);
        const qsa = (selector) => Array.from(document.querySelectorAll(selector));

        const loginCard = qs('#login-card');
        const sessionCard = qs('#session-card');
        const cavesCard = qs('#caves-card');
        const projectsCard = qs('#projects-card');
        const apiCard = qs('#api-card');
        const mcpCard = qs('#mcp-card');

        const loginForm = qs('#login-form');
        const loginStatus = qs('#login-status');
        const sessionInfo = qs('#session-info');
        const sessionStatus = qs('#session-status');
        const refreshButton = qs('#refresh');
        const logoutButton = qs('#logout');

        const projectForm = qs('#project-form');
        const projectStatus = qs('#project-status');
        const projectReset = qs('#project-reset');
        const projectsBody = qs('#projects-body');
        const cavesBody = qs('#caves-body');

        const apiForm = qs('#api-form');
        const apiStatus = qs('#api-status');
        const apiSecret = qs('#api-secret');
        const apiBody = qs('#api-body');

        const mcpForm = qs('#mcp-form');
        const mcpStatus = qs('#mcp-status');
        const mcpReset = qs('#mcp-reset');
        const mcpBody = qs('#mcp-body');

        async function request(path, options = {}) {
            const response = await fetch(path, {
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                ...options,
            });

            if (!response.ok) {
                const data = await response.json().catch(() => ({ error: response.statusText }));
                throw new Error(data.error || response.statusText);
            }

            if (response.status === 204) {
                return null;
            }

            return response.json();
        }

        function showDashboard(session) {
            loginCard.classList.add('hidden');
            sessionCard.classList.remove('hidden');
            cavesCard.classList.remove('hidden');
            projectsCard.classList.remove('hidden');
            apiCard.classList.remove('hidden');
            mcpCard.classList.remove('hidden');
            sessionInfo.textContent = `Signed in as ${session.username} — session expires ${new Date(session.expires_at).toLocaleString()}`;
        }

        function showLogin(message) {
            loginCard.classList.remove('hidden');
            sessionCard.classList.add('hidden');
            cavesCard.classList.add('hidden');
            projectsCard.classList.add('hidden');
            apiCard.classList.add('hidden');
            mcpCard.classList.add('hidden');
            loginStatus.textContent = message || '';
            if (message) {
                loginStatus.classList.add('error');
            } else {
                loginStatus.classList.remove('error');
            }
        }

        async function loadOverview() {
            try {
                sessionStatus.textContent = 'Loading…';
                const data = await request('/admin/api/overview');
                sessionStatus.textContent = '';
                showDashboard(data.session);
                renderCaves(data.caves);
                renderProjects(data.projects);
                renderApiKeys(data.api_keys);
                renderMcpTools(data.mcp_tools);
            } catch (error) {
                sessionStatus.textContent = error.message;
                sessionStatus.classList.add('error');
                if (error.message.toLowerCase().includes('invalid')) {
                    showLogin('Session expired. Please sign in again.');
                }
            }
        }

        function renderCaves(caves) {
            cavesBody.innerHTML = caves.length
                ? caves.map((cave) => `<tr><td>${cave.namespace}</td><td>${cave.name}</td><td>${cave.port}</td></tr>`).join('')
                : '<tr><td colspan="3">No active caves.</td></tr>';
        }

        function renderProjects(projects) {
            projectsBody.innerHTML = projects.length
                ? projects.map((project) => `
                    <tr data-id="${project.id}" data-meta='${JSON.stringify(project)}'>
                        <td>${project.name}</td>
                        <td>${project.namespace || ''}</td>
                        <td>${new Date(project.updated_at).toLocaleString()}</td>
                        <td>
                            <button type="button" data-action="edit">Edit</button>
                            <button type="button" class="secondary" data-action="delete">Delete</button>
                        </td>
                    </tr>
                `).join('')
                : '<tr><td colspan="4">No projects have been recorded.</td></tr>';
        }

        function renderApiKeys(keys) {
            apiBody.innerHTML = keys.length
                ? keys.map((key) => `
                    <tr data-token="${key.token}">
                        <td>${key.label}</td>
                        <td>${key.namespace}</td>
                        <td class="token">${key.token_preview}</td>
                        <td>${new Date(key.expires_at).toLocaleString()}</td>
                        <td>${new Date(key.created_at).toLocaleString()}</td>
                        <td><button type="button" class="secondary" data-action="revoke">Revoke</button></td>
                    </tr>
                `).join('')
                : '<tr><td colspan="6">No API keys issued yet.</td></tr>';
        }

        function renderMcpTools(tools) {
            mcpBody.innerHTML = tools.length
                ? tools.map((tool) => `
                    <tr data-id="${tool.id}" data-meta='${JSON.stringify(tool)}'>
                        <td>${tool.name}</td>
                        <td>${tool.endpoint}</td>
                        <td>${new Date(tool.updated_at).toLocaleString()}</td>
                        <td>
                            <button type="button" data-action="edit">Edit</button>
                            <button type="button" class="secondary" data-action="delete">Delete</button>
                        </td>
                    </tr>
                `).join('')
                : '<tr><td colspan="4">No MCP tools registered.</td></tr>';
        }

        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            loginStatus.textContent = 'Authenticating…';
            loginStatus.classList.remove('error');
            const payload = Object.fromEntries(new FormData(loginForm));

            try {
                const session = await request('/admin/api/session', {
                    method: 'POST',
                    body: JSON.stringify(payload),
                });
                loginForm.reset();
                loginStatus.textContent = '';
                showDashboard(session);
                await loadOverview();
            } catch (error) {
                loginStatus.textContent = error.message;
                loginStatus.classList.add('error');
            }
        });

        logoutButton.addEventListener('click', async () => {
            await request('/admin/api/session', { method: 'DELETE' });
            showLogin('Signed out successfully.');
        });

        refreshButton.addEventListener('click', loadOverview);

        projectForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            try {
                const metadataRaw = qs('#project-metadata').value.trim();
                const payload = {
                    id: qs('#project-id').value || null,
                    name: qs('#project-name').value,
                    namespace: qs('#project-namespace').value || null,
                    description: qs('#project-description').value || null,
                    metadata: metadataRaw ? JSON.parse(metadataRaw) : null,
                };
                projectStatus.textContent = 'Saving…';
                projectStatus.classList.remove('error');
                await request('/admin/api/projects', {
                    method: 'POST',
                    body: JSON.stringify(payload),
                });
                projectStatus.textContent = 'Project saved.';
                projectForm.reset();
                await loadOverview();
            } catch (error) {
                projectStatus.textContent = error.message;
                projectStatus.classList.add('error');
            }
        });

        projectReset.addEventListener('click', () => {
            projectForm.reset();
            qs('#project-id').value = '';
            projectStatus.textContent = '';
            projectStatus.classList.remove('error');
        });

        projectsBody.addEventListener('click', async (event) => {
            const button = event.target.closest('button');
            if (!button) return;
            const row = button.closest('tr');
            const meta = JSON.parse(row.dataset.meta);
            if (button.dataset.action === 'edit') {
                qs('#project-id').value = meta.id;
                qs('#project-name').value = meta.name;
                qs('#project-namespace').value = meta.namespace || '';
                qs('#project-description').value = meta.description || '';
                qs('#project-metadata').value = JSON.stringify(meta.metadata ?? {}, null, 2);
                projectStatus.textContent = 'Editing existing project.';
                projectStatus.classList.remove('error');
            } else if (button.dataset.action === 'delete') {
                if (confirm('Delete this project?')) {
                    try {
                        await request(`/admin/api/projects/${meta.id}`, { method: 'DELETE' });
                        await loadOverview();
                    } catch (error) {
                        projectStatus.textContent = error.message;
                        projectStatus.classList.add('error');
                    }
                }
            }
        });

        apiForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            apiSecret.textContent = '';
            apiStatus.textContent = 'Generating…';
            apiStatus.classList.remove('error');
            const payload = {
                label: qs('#api-label').value,
                namespace: qs('#api-namespace').value,
                expire_hours: Number(qs('#api-expire').value) || 24,
            };

            try {
                const response = await request('/admin/api/api-keys', {
                    method: 'POST',
                    body: JSON.stringify(payload),
                });
                apiStatus.textContent = 'Token generated. Copy it now; it will only be shown once.';
                apiSecret.textContent = response.token;
                await loadOverview();
            } catch (error) {
                apiStatus.textContent = error.message;
                apiStatus.classList.add('error');
            }
        });

        apiBody.addEventListener('click', async (event) => {
            const button = event.target.closest('button');
            if (!button || button.dataset.action !== 'revoke') return;
            const token = button.closest('tr').dataset.token;
            if (!confirm('Revoke this API key?')) return;
            try {
                await request(`/admin/api/api-keys/${encodeURIComponent(token)}`, { method: 'DELETE' });
                await loadOverview();
            } catch (error) {
                apiStatus.textContent = error.message;
                apiStatus.classList.add('error');
            }
        });

        mcpForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const payload = {
                id: qs('#mcp-id').value || null,
                name: qs('#mcp-name').value,
                endpoint: qs('#mcp-endpoint').value,
                description: qs('#mcp-description').value || null,
                api_key: qs('#mcp-key').value || null,
            };
            mcpStatus.textContent = 'Saving…';
            mcpStatus.classList.remove('error');
            try {
                await request('/admin/api/mcp-tools', {
                    method: 'POST',
                    body: JSON.stringify(payload),
                });
                mcpStatus.textContent = 'Tool saved.';
                mcpForm.reset();
                await loadOverview();
            } catch (error) {
                mcpStatus.textContent = error.message;
                mcpStatus.classList.add('error');
            }
        });

        mcpReset.addEventListener('click', () => {
            mcpForm.reset();
            qs('#mcp-id').value = '';
            mcpStatus.textContent = '';
            mcpStatus.classList.remove('error');
        });

        mcpBody.addEventListener('click', async (event) => {
            const button = event.target.closest('button');
            if (!button) return;
            const meta = JSON.parse(button.closest('tr').dataset.meta);
            if (button.dataset.action === 'edit') {
                qs('#mcp-id').value = meta.id;
                qs('#mcp-name').value = meta.name;
                qs('#mcp-endpoint').value = meta.endpoint;
                qs('#mcp-description').value = meta.description || '';
                qs('#mcp-key').value = meta.api_key || '';
                mcpStatus.textContent = 'Editing tool.';
                mcpStatus.classList.remove('error');
            } else if (button.dataset.action === 'delete') {
                if (confirm('Delete this MCP tool?')) {
                    try {
                        await request(`/admin/api/mcp-tools/${meta.id}`, { method: 'DELETE' });
                        await loadOverview();
                    } catch (error) {
                        mcpStatus.textContent = error.message;
                        mcpStatus.classList.add('error');
                    }
                }
            }
        });

        async function bootstrap() {
            try {
                const session = await request('/admin/api/session');
                showDashboard(session);
                await loadOverview();
            } catch {
                showLogin('Enter your admin credentials to begin.');
            }
        }

        document.addEventListener('DOMContentLoaded', bootstrap);
    </script>
</body>
</html>"#;
