//! Application state management for the ghost server.
//!
//! This module handles:
//! - Global application state
//! - Configuration state management
//! - Thread-safe state sharing
//!
//! The module provides:
//! - Thread-safe application state container
//! - State initialization and access methods
//! - Configuration state management

use std::sync::Arc;
use tokio::sync::RwLock;

use getset::Getters;

use crate::{
    admin::AdminContext,
    config::Config,
    port::{PortManager, LOCALHOST_IP},
    ServerError, ServerResult,
};

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

/// Application state structure
#[derive(Clone, Getters)]
#[getset(get = "pub with_prefix")]
pub struct AppState {
    /// The application configuration
    config: Arc<Config>,

    /// The port manager for handling cave port assignments
    port_manager: Arc<RwLock<PortManager>>,

    /// Administrative services (authentication, metadata, audit)
    admin: Arc<AdminContext>,
}

//--------------------------------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------------------------------

impl AppState {
    /// Create a new application state instance
    pub fn new(
        config: Arc<Config>,
        port_manager: Arc<RwLock<PortManager>>,
        admin: Arc<AdminContext>,
    ) -> Self {
        Self {
            config,
            port_manager,
            admin,
        }
    }

    /// Get a cave's portal URL
    ///
    /// Returns an error if no port is assigned for the given cave
    pub async fn get_portal_url_for_cave(
        &self,
        namespace: &str,
        cave_name: &str,
    ) -> ServerResult<String> {
        let port_manager = self.port_manager.read().await;
        let key = format!("{}/{}", namespace, cave_name);

        if let Some(port) = port_manager.get_port(&key) {
            Ok(format!("http://{}:{}", LOCALHOST_IP, port))
        } else {
            Err(ServerError::InternalError(format!(
                "No portal port assigned for cave {}",
                key
            )))
        }
    }
}
