//! Port management for the ghost server.
//!
//! This module handles port assignment and management for cavees:
//! - Assigns truly available ports obtained from the OS
//! - Tracks assigned ports for fast lookup
//! - Persists port assignments to disk
//! - Loads existing port assignments on startup
//! - Handles port uniqueness with bidirectional mapping
//!
//! The module provides:
//! - Port manager for tracking assigned ports
//! - Functions for assigning and releasing ports
//! - File-based persistence of port assignments

use ghost_utils::PORTAL_PORTS_FILE;
use once_cell::sync::Lazy;
use serde::{Deserialize, Serialize};
use std::{
    collections::HashMap,
    net::{IpAddr, Ipv4Addr, SocketAddr, TcpListener},
    path::{Path, PathBuf},
};
use tokio::{fs, sync::Mutex};
use tracing::{debug, info, warn};

use crate::{ghostServerError, ghostServerResult};

//--------------------------------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------------------------------

/// The localhost IP address used for all portal connections
pub const LOCALHOST_IP: IpAddr = IpAddr::V4(Ipv4Addr::LOCALHOST);

/// Lock to ensure only one thread gets a port at a time
static PORT_ASSIGNMENT_LOCK: Lazy<Mutex<()>> = Lazy::new(|| Mutex::new(()));

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

/// Port mapping for cave instances - bidirectional for fast lookups
#[derive(Debug, Clone, Default)]
pub struct BiPortMapping {
    /// Maps cave identifiers (namespace/cavename) to assigned port numbers
    cave_to_port: HashMap<String, u16>,

    /// Maps port numbers to cave identifiers for fast reverse lookup
    port_to_cave: HashMap<u16, String>,
}

/// Serializable version of the port mapping for file storage
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PortMapping {
    /// Maps cave identifiers (namespace/cavename) to assigned port numbers
    pub mappings: HashMap<String, u16>,
}

/// Port manager for handling cave port assignments
#[derive(Debug)]
pub struct PortManager {
    /// The port mappings data
    mappings: BiPortMapping,

    /// Path to the port mappings file
    file_path: PathBuf,
}

//--------------------------------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------------------------------

impl BiPortMapping {
    /// Create a new bidirectional port mapping
    pub fn new() -> Self {
        Self {
            cave_to_port: HashMap::new(),
            port_to_cave: HashMap::new(),
        }
    }

    /// Insert a mapping, handling any existing mappings for the port or cave
    pub fn insert(&mut self, cave_key: String, port: u16) {
        // Check if this port is already assigned to a different cave
        if let Some(existing_cave) = self.port_to_cave.get(&port) {
            if existing_cave != &cave_key {
                // Port is already assigned to a different cave - remove that mapping
                warn!(
                    "Port {} was already assigned to cave {}, reassigning to {}",
                    port, existing_cave, cave_key
                );
                self.cave_to_port.remove(existing_cave);
            }
        }

        // Check if this cave already has a different port
        if let Some(existing_port) = self.cave_to_port.get(&cave_key) {
            if *existing_port != port {
                // Cave had a different port - remove that mapping
                self.port_to_cave.remove(existing_port);
            }
        }

        // Insert the new mapping in both directions
        self.cave_to_port.insert(cave_key.clone(), port);
        self.port_to_cave.insert(port, cave_key);
    }

    /// Remove a mapping by cave key
    pub fn remove_by_cave(&mut self, cave_key: &str) -> Option<u16> {
        if let Some(port) = self.cave_to_port.remove(cave_key) {
            self.port_to_cave.remove(&port);
            Some(port)
        } else {
            None
        }
    }

    /// Remove a mapping by port
    pub fn remove_by_port(&mut self, port: u16) -> Option<String> {
        if let Some(cave_key) = self.port_to_cave.remove(&port) {
            self.cave_to_port.remove(&cave_key);
            Some(cave_key)
        } else {
            None
        }
    }

    /// Get port by cave key
    pub fn get_port(&self, cave_key: &str) -> Option<u16> {
        self.cave_to_port.get(cave_key).copied()
    }

    /// Get cave key by port
    pub fn get_cave(&self, port: u16) -> Option<&String> {
        self.port_to_cave.get(&port)
    }

    /// Convert to serializable format
    pub fn to_port_mapping(&self) -> PortMapping {
        PortMapping {
            mappings: self.cave_to_port.clone(),
        }
    }

    /// Load from serializable format
    pub fn from_port_mapping(mapping: PortMapping) -> Self {
        let mut result = Self::new();

        for (cave_key, port) in mapping.mappings {
            result.insert(cave_key, port);
        }

        result
    }
}

impl PortManager {
    /// Create a new port manager
    pub async fn new(namespace_dir: impl AsRef<Path>) -> ghostServerResult<Self> {
        let file_path = namespace_dir.as_ref().join(PORTAL_PORTS_FILE);
        let mappings = Self::load_mappings(&file_path).await?;

        Ok(Self {
            mappings,
            file_path,
        })
    }

    /// Load port mappings from file
    async fn load_mappings(file_path: &Path) -> ghostServerResult<BiPortMapping> {
        if file_path.exists() {
            let contents = fs::read_to_string(file_path).await.map_err(|e| {
                ghostServerError::ConfigError(format!("Failed to read port mappings file: {}", e))
            })?;

            let port_mapping: PortMapping = serde_json::from_str(&contents).map_err(|e| {
                ghostServerError::ConfigError(format!("Failed to parse port mappings file: {}", e))
            })?;

            Ok(BiPortMapping::from_port_mapping(port_mapping))
        } else {
            debug!("No port mappings file found, creating a new one");
            Ok(BiPortMapping::new())
        }
    }

    /// Save port mappings to file
    async fn save_mappings(&self) -> ghostServerResult<()> {
        let port_mapping = self.mappings.to_port_mapping();
        let contents = serde_json::to_string_pretty(&port_mapping).map_err(|e| {
            ghostServerError::ConfigError(format!("Failed to serialize port mappings: {}", e))
        })?;

        // Create parent directory if it doesn't exist
        if let Some(parent) = self.file_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).await.map_err(|e| {
                    ghostServerError::ConfigError(format!(
                        "Failed to create directory for port mappings file: {}",
                        e
                    ))
                })?;
            }
        }

        fs::write(&self.file_path, contents).await.map_err(|e| {
            ghostServerError::ConfigError(format!("Failed to write port mappings file: {}", e))
        })
    }

    /// Assign a port to a cave
    pub async fn assign_port(&mut self, key: &str) -> ghostServerResult<u16> {
        // Check if port is already assigned
        if let Some(port) = self.mappings.get_port(key) {
            // Verify this port is still available
            if self.verify_port_availability(port) {
                return Ok(port);
            } else {
                // Port is no longer available, so we need to assign a new one
                warn!(
                    "Previously assigned port {} for cave {} is no longer available, reassigning",
                    port, key
                );
                self.mappings.remove_by_cave(key);
            }
        }

        // Get a lock to ensure only one thread gets a port at a time
        let _lock = PORT_ASSIGNMENT_LOCK.lock().await;

        // Get a truly available port from the OS
        let port = self.get_available_port_from_os()?;

        // Save the mapping
        self.mappings.insert(key.to_string(), port);
        self.save_mappings().await?;

        info!("Assigned port {} to cave {}", port, key);
        Ok(port)
    }

    /// Release a port assignment
    pub async fn release_port(&mut self, key: &str) -> ghostServerResult<()> {
        if self.mappings.remove_by_cave(key).is_some() {
            self.save_mappings().await?;
            info!("Released port for cave {}", key);
        }

        Ok(())
    }

    /// Get a port for a cave if assigned
    pub fn get_port(&self, key: &str) -> Option<u16> {
        self.mappings.get_port(key)
    }

    /// List all recorded cave to port assignments.
    pub fn list_assignments(&self) -> Vec<(String, u16)> {
        self.mappings
            .cave_to_port
            .iter()
            .map(|(key, port)| (key.clone(), *port))
            .collect()
    }

    /// Verify that a port is still available (not bound by something else)
    fn verify_port_availability(&self, port: u16) -> bool {
        let addr = SocketAddr::new(LOCALHOST_IP, port);
        match TcpListener::bind(addr) {
            Ok(_) => true,   // We could bind, so it's available
            Err(_) => false, // We couldn't bind, so it's not available
        }
    }

    /// Get an available port from the OS
    fn get_available_port_from_os(&self) -> ghostServerResult<u16> {
        // Bind to port 0 to let the OS assign an available port
        let addr = SocketAddr::new(LOCALHOST_IP, 0);
        let listener = TcpListener::bind(addr).map_err(|e| {
            ghostServerError::ConfigError(format!(
                "Failed to bind to address to get available port: {}",
                e
            ))
        })?;

        // Get the port assigned by the OS
        let port = listener
            .local_addr()
            .map_err(|e| {
                ghostServerError::ConfigError(format!(
                    "Failed to get local address from socket: {}",
                    e
                ))
            })?
            .port();

        debug!("OS assigned port {}", port);

        // The listener will be dropped here, releasing the port
        // We return the port value to be used by the caller

        Ok(port)
    }
}
