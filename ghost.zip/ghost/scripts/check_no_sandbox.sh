#!/usr/bin/env bash
set -euo pipefail

pattern="sand""box"

if git grep -I -n -i "$pattern" -- ':!scripts/check_no_sandbox.sh'; then
  echo "Error: detected lingering '$pattern' references. Please rename them to 'cave'." >&2
  exit 1
fi

echo "No '$pattern' references detected."
