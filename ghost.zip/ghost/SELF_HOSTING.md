# <sub><img height="18" src="https://octicons-col.vercel.app/home/A770EF">&nbsp;&nbsp;SELF HOSTING&nbsp;&nbsp;<sup><sup>B E T A</sup></sup></sub>

To get started, you need to host your own cave server. Whether that's on a local machine or in the cloud, it's up to you.

Self hosting lets you manage your own data and code making it easier to comply with security policies. Also, having a cave server set up locally allows you to test and move through ideas quickly.

Let's help you start your first self-hosted cave server. It's easy!

> **Platform-specific requirements:**
>
> - <a href="https://ghost.dev#gh-light-mode-only" target="_blank"><img src="https://cdn.simpleicons.org/apple" height="14"/></a><a href="https://ghost.dev#gh-dark-mode-only" target="_blank"><img src="https://cdn.simpleicons.org/apple/white" height="14"/></a> **macOS** — Requires Apple Silicon (M1/M2/M3/M4)
> - <a href="https://ghost.dev#gh-light-mode-only" target="_blank"><img src="https://cdn.simpleicons.org/linux/black" height="14"/></a><a href="https://ghost.dev#gh-dark-mode-only" target="_blank"><img src="https://cdn.simpleicons.org/linux/white" height="14"/></a> **Linux** <a href="https://github.com/ghost/ghost/issues/224" target="_blank"><sup><sup>#224</sup></sup></a> — KVM virtualization must be enabled
> - <a href="https://ghost.dev#gh-light-mode-only" target="_blank"><img src="https://github.com/user-attachments/assets/1677b695-e359-4b51-9931-f8f5f9488e71" height="14"/></a><a href="https://ghost.dev#gh-dark-mode-only" target="_blank"><img src="https://github.com/user-attachments/assets/e3e5b341-b097-45d9-bea1-eb70e0769340" height="14"/></a> **Windows** <a href="https://github.com/ghost/ghost/issues/224" target="_blank"> — [Coming soon!](https://github.com/ghost/ghost/issues/47)

##

#### 1. Install CLI

```sh
curl -sSL https://get.ghost.dev | sh
```

This will install the `gst` CLI tool, which helps you manage cavees locally.

##

#### 2. Start Cave Server

```sh
gst server start
```

> [!TIP]
>
> Use the `--detach` flag to run the server in the background.
>
> Use the `--dev` flag to skip requiring an API key.
>
> `gst server start --help` for more options.
>
> ##
>
> **ghost server** is also an **MCP server**. See [MCP.md](./MCP.md) for more information.

##

#### 3. Pull SDK Images

```sh
gst pull ghost/python
```

```sh
gst pull ghost/node
```

This pulls and caches the images for the SDKs to use. It is what allows you to run a `PythonCave` or `NodeCave`.

##

#### 4. Generate API Key

If you are started the server in **dev** mode, you can skip the API key.

```sh
gst server keygen --expire 3mo
```

After generating your key, set the `GST_API_KEY` environment variable to the generated key.

##

> [!TIP]
>
> For self-hosting on a cloud provider, refer to our [cloud hosting guide](CLOUD_HOSTING.md) for a list of cloud providers that would support running ghost.
