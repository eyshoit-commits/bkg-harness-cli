#!/bin/bash

# Update gst to gst in all files
grep -rli 'gst' --exclude-dir={.git,node_modules,target} --exclude=update_cli_names.sh . | xargs -I@ sed -i 's/\bmsb\b/gst/g' @

# Update GST to GST in all files
grep -rli 'GST' --exclude-dir={.git,node_modules,target} --exclude=update_cli_names.sh . | xargs -I@ sed -i 's/\bMSB\b/GST/g' @

echo "Updated all instances of 'gst' to 'gst' and 'GST' to 'GST' in the codebase."

# Update file paths and binary names
find . -type f -name "gst*" | while read -r file; do
    new_file=$(echo "$file" | sed 's/\bmsb\b/gst/g')
    if [ "$file" != "$new_file" ]; then
        mv "$file" "$new_file"
        echo "Renamed: $file -> $new_file"
    fi
done
