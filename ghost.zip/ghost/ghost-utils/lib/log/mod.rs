//! `ghost_utils::log` is a module containing logging utilities for the ghost project.

mod rotating;

//--------------------------------------------------------------------------------------------------
// Exports
//--------------------------------------------------------------------------------------------------

pub use rotating::*;
