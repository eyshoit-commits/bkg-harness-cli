#!/bin/bash

# Rename directories
find . -type d -name "*ghost*" | while read -r dir; do
  newdir=$(echo "$dir" | sed 's/ghost/ghost/g')
  if [ "$dir" != "$newdir" ]; then
    mkdir -p "$newdir"
    mv "$dir"/* "$newdir"/ 2>/dev/null
    rmdir "$dir"
  fi
done

# Rename files
find . -type f -name "*ghost*" | while read -r file; do
  newfile=$(echo "$file" | sed 's/ghost/ghost/g')
  if [ "$file" != "$newfile" ]; then
    mv "$file" "$newfile"
  fi
done

# Replace text in files (case insensitive)
find . -type f -not -path "*/.git/*" -not -path "*/target/*" -not -path "*/node_modules/*" -not -path "*/.idea/*" -not -path "*/.vscode/*" -not -path "*/.cargo/*" -not -path "*/.github/*" -not -path "*/dist/*" -not -path "*/build/*" -not -name "*.lock" -not -name "*.png" -not -name "*.jpg" -not -name "*.jpeg" -not -name "*.gif" -not -name "*.ico" -not -name "*.svg" -not -name "*.woff" -not -name "*.woff2" -not -name "*.ttf" -not -name "*.eot" -print0 | xargs -0 sed -i 's/ghost/ghost/gi'

# Replace text in files (case sensitive)
find . -type f -not -path "*/.git/*" -not -path "*/target/*" -not -path "*/node_modules/*" -not -path "*/.idea/*" -not -path "*/.vscode/*" -not -path "*/.cargo/*" -not -path "*/.github/*" -not -path "*/dist/*" -not -path "*/build/*" -not -name "*.lock" -not -name "*.png" -not -name "*.jpg" -not -name "*.jpeg" -not -name "*.gif" -not -name "*.ico" -not -name "*.svg" -not -name "*.woff" -not -name "*.woff2" -not -name "*.ttf" -not -name "*.eot" -print0 | xargs -0 sed -i 's/ghost/Ghost/g'
