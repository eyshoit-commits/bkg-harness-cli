# <sub><img height="18" src="https://octicons-col.vercel.app/device-desktop/A770EF">&nbsp;&nbsp;PROJECTS&nbsp;&nbsp;<sup><sup>B E T A</sup></sup></sub>

The `gst` CLI brings the familiar feel of package managers to cave development. Think of it like npm or cargo, but for cavees! Create a Cavefile, define your environments, and manage your cavees with simple commands.

> [!WARNING]
>
> `ghost` is beta software and not ready for production use.

##

#### Create a Cave Project

```sh
gst init
```

This creates a `Cavefile` in the current directory, which serves as the configuration manifest for your cave environments.

##

#### Add a Cave to the Project

```sh
gst add app \
    --image python \
    --cpus 1 \
    --memory 1024 \
    --start 'python -c "print(\"hello\")"'
```

The command above registers a new cave named `app` in your Cavefile, configured to use the `python` image.

You should now have a `Cavefile` containing a cave named **`app`**:

```sh
cat Cavefile
```

```yaml
# Cave configurations
cavees:
  app:
    image: python
    memory: 1024
    cpus: 1
    scripts:
      start: python -c "print(\"hello\")"
```

> [!TIP]
>
> Run `gst <subcommand> --help` to see all the options available for a subcommand.
>
> For example, `gst add --help`.

##

#### Running a Cave

##### Run a Cave Defined in Your Project

```sh
gst run --cave app
```

<div align="center">

_**or**_

</div>

```sh
gst r app
```

<div align="center">

_**or**_

</div>

```sh
gsr app
```

This executes the default _start_ script of your cave. For more control, you can directly specify which script to run — `gsr app~start`.

When running project cavees, all file changes and installations made inside the cave are automatically persisted to the `./menv` directory. This means you can stop and restart your cave any time without losing your work. Your development environment will be exactly as you left it.

##### Run an Temporary Cave

For experimentation or one-off tasks, temporary cavees provide a clean environment that leaves no trace:

```sh
gst exe --image python
```

<div align="center">

_**or**_

</div>

```sh
gst x python
```

<div align="center">

_**or**_

</div>

```sh
gsx python
```

Temporary cavees are perfect for isolating programs you get from the internet. Once you exit the cave, all changes are completely discarded.

##

#### Installing Cavees

The `gst install` command sets up a cave as a system-wide executable. It installs a slim launcher program that allows you to start your cave from anywhere in your system with a simple command.

```sh
gst install --image alpine
```

<div align="center">

_**or**_

</div>

```sh
gst i alpine
```

<div align="center">

_**or**_

</div>

```sh
gsi alpine
```

After installation, you can start your cave by simply typing its name in any terminal:

```sh
alpine
```

This makes frequently used cavees incredibly convenient to access — no need to navigate to specific directories or remember complex commands. Just type the cave name and it launches immediately with all your configured settings.

> [!TIP]
> You can give your cave a descriptive, easy-to-remember name during installation:
>
> ```sh
> gsi alpine:20250108 slim-linux
> ```
>
> This allows you to create multiple instances of the same cave image with different names and configurations. For example:
>
> - `gsi python python-data-science` - A Python environment for data analysis
> - `gsi python python-web` - A Python environment for web development
>
> Installed cavees maintain their state between sessions, so you can pick up exactly where you left off each time you launch them.

<br />

<a href="https://asciinema.org/a/7eOFf2Ovigi473FsKgr3Lpve1" target="_blank"><img src="https://github.com/user-attachments/assets/3a9d1de4-2370-4d5a-a40d-9aa7315aa934" /></a>
