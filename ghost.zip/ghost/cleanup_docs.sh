#!/bin/bash

# Update documentation files to replace remaining sandbox references
find ./docs -type f -name "*.md" -exec sed -i 's/\bsandbox\b/cave/g' {} \;
find ./docs -type f -name "*.md" -exec sed -i 's/\bSandbox\b/Cave/g' {} \;
find ./docs -type f -name "*.md" -exec sed -i 's/\bSANDBOX\b/CAVE/g' {} \;
find ./docs -type f -name "*.md" -exec sed -i 's/\bsandboxes\b/caves/g' {} \;
find ./docs -type f -name "*.md" -exec sed -i 's/\bSandboxes\b/Caves/g' {} \;
find ./docs -type f -name "*.md" -exec sed -i 's/\bSANDBOXES\b/CAVES/g' {} \;

echo "Documentation files have been updated to replace sandbox with cave."

# Update .gitignore to replace Sandboxfile with Cavefile
sed -i 's/Sandboxfile\*/Cavefile*/g' .gitignore

echo ".gitignore has been updated to replace Sandboxfile with Cavefile."
