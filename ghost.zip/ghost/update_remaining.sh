#!/bin/bash

# Update gst to gst in all files
grep -rli 'gst' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bmsb\b/gst/g' @

# Update GST to GST in all files
grep -rli 'GST' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bMSB\b/GST/g' @

# Update file paths and binary names
find . -type f -name "gst*" | while read -r file; do
    new_file=$(echo "$file" | sed 's/\bmsb\b/gst/g')
    if [ "$file" != "$new_file" ]; then
        mv "$file" "$new_file"
        echo "Renamed: $file -> $new_file"
    fi
done

# Update gstrun to gstrun in all files
grep -rli 'gstrun' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bmsbrun\b/gstrun/g' @

# Update GSTRUN to GSTRUN in all files
grep -rli 'GSTRUN' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bMSBRUN\b/GSTRUN/g' @

# Update gstserver to gstserver in all files
grep -rli 'gstserver' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bmsbserver\b/gstserver/g' @

# Update GSTSERVER to GSTSERVER in all files
grep -rli 'GSTSERVER' --exclude-dir={.git,node_modules,target} --exclude=update_*.sh . | xargs -I@ sed -i 's/\bMSBSERVER\b/GSTSERVER/g' @

echo "Updated all instances in the codebase."
