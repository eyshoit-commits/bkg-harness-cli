package com.ghost

import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class ghostSpec extends AnyFlatSpec with Matchers {
  "ghost.greet" should "return a greeting message containing the name" in {
    val result = ghost.greet("Test")
    result should include("Hello, Test!")
  }
}
