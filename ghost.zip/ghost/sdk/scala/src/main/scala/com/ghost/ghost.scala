package com.ghost

/**
 * ghost Scala SDK
 * A minimal SDK for the ghost project.
 */
object ghost {
  /**
   * Returns a greeting message for the given name.
   *
   * @param name The name to greet
   * @return A greeting message
   */
  def greet(name: String): String = {
    val message = s"Hello, $name! Welcome to ghost!"
    println(message)
    message
  }
}
