module ghost
  ( greet
  ) where

-- | Returns a greeting message for the given name.
--
-- >>> greet "World"
-- "Hello, World! Welcome to ghost!"
greet :: String -> IO String
greet name = do
  let message = "Hello, " ++ name ++ "! Welcome to ghost!"
  putStrLn message
  return message
