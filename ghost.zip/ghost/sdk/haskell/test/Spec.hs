import Test.Hspec
import ghost

main :: IO ()
main = hspec $ do
  describe "ghost.greet" $ do
    it "returns a greeting containing the name" $ do
      greeting <- greet "Test"
      greeting `shouldContain` "Hello, Test!"
