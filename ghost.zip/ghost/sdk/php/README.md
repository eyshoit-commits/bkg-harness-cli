# ghost PHP SDK

A minimal PHP SDK for the ghost project.

## Installation

```bash
composer require yourusername/ghost
```

## Usage

```php
<?php

require_once 'vendor/autoload.php';

use ghost\Hello;

// Print a greeting
Hello::greet('World');
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
