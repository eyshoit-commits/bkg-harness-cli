# ghost Rust SDK

A Rust SDK for ghost - secure self-hosted cavees for executing untrusted code. This SDK allows you to create isolated environments for running code with controlled access to system resources.

## Installation

Add this to your `Cargo.toml`:

```toml
[dependencies]
ghost = "0.1.0"
tokio = { version = "1", features = ["full"] }
```

## Usage

### Simple Python Cave Example

```rust
use ghost::{CaveOptions, PythonCave};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Create a Python cave
    let mut cave = PythonCave::create(CaveOptions::builder().name("test").build()).await?;

    // Run Python code
    let exec = cave.run(r#"name = "Python""#).await?;
    let exec = cave.run(r#"print(f"Hello {name}!")"#).await?;

    // Get the output
    println!("{}", exec.output().await?); // prints Hello Python!

    // Stop the cave
    cave.stop().await?;

    Ok(())
}
```

### Using Environment Variables

The SDK will automatically read environment variables:

- `GST_API_KEY` - Your API key for authentication
- `GST_SERVER_URL` - The URL of the ghost server (defaults to http://127.0.0.1:5555)

You can also set these values programmatically:

```rust
let cave = PythonCave::create(
    CaveOptions::builder()
        .name("test")
        .api_key("gst_your_api_key")
        .server_url("http://your-server-url:5555")
        .build()
).await?;
```

## Features

- **Python Cave** - Run Python code in a secure cave
- **Shell Commands** - Execute shell commands in the cave
- **Fully Async** - Built with modern async/await support

## Examples

Check out the [examples directory](./examples) for sample scripts that demonstrate how to:

- Run Python code in a cave
- Execute shell commands
- Monitor resource usage
- Configure cave options

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
