//! ghost Rust SDK
//!
//! A Rust SDK for the ghost project that provides secure cave environments
//! for executing untrusted code. This SDK allows you to create isolated environments
//! for running code with controlled access to system resources.

use async_trait::async_trait;

// Re-export common types
pub use base::CaveBase;
pub use builder::CaveOptions;
pub use command::Command;
pub use error::CaveError;
pub use execution::Execution;
pub use metrics::Metrics;
pub use node::NodeCave;
pub use python::PythonCave;
pub use start_options::StartOptions;

mod base;
mod builder;
mod command;
mod error;
mod execution;
mod metrics;
mod node;
mod python;
mod start_options;

/// Base trait for cave implementations
#[async_trait]
pub trait BaseCave: Send + Sync {
    /// Get the default Docker image for this cave type
    async fn get_default_image(&self) -> String;

    /// Execute code in the cave
    async fn run(&self, code: &str) -> Result<Execution, Box<dyn std::error::Error + Send + Sync>>;

    /// Run code, automatically starting the cave if needed
    async fn run_or_start(
        &mut self,
        code: &str,
    ) -> Result<Execution, Box<dyn std::error::Error + Send + Sync>> {
        // Check if cave is started
        let is_started = self.is_started().await;

        if !is_started {
            // Start cave
            self.start(None).await?;
        }

        // Run code
        self.run(code).await
    }

    /// Check if the cave is started
    async fn is_started(&self) -> bool {
        false // Override in implementations
    }

    /// Start the cave container
    async fn start(
        &mut self,
        options: Option<StartOptions>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>>;

    /// Stop the cave container
    async fn stop(&mut self) -> Result<(), Box<dyn std::error::Error + Send + Sync>>;

    /// Get the metrics interface for the cave
    async fn metrics(&self) -> Result<Metrics, Box<dyn std::error::Error + Send + Sync>>;
}
