//! Builder pattern implementation for cave options

/// Options for creating a cave
#[derive(Debug, Clone)]
pub struct CaveOptions {
    /// URL of the ghost server
    pub(crate) server_url: Option<String>,

    /// Namespace for the cave
    pub(crate) namespace: Option<String>,

    /// Name of the cave
    pub(crate) name: Option<String>,

    /// API key for ghost server authentication
    pub(crate) api_key: Option<String>,
}

/// Builder for cave options
#[derive(Debug, Clone, Default)]
pub struct CaveOptionsBuilder {
    server_url: Option<String>,
    namespace: Option<String>,
    name: Option<String>,
    api_key: Option<String>,
}

impl CaveOptions {
    /// Create a new builder for CaveOptions
    pub fn builder() -> CaveOptionsBuilder {
        CaveOptionsBuilder::default()
    }
}

impl CaveOptionsBuilder {
    /// Set the server URL
    pub fn server_url(mut self, url: impl Into<String>) -> Self {
        self.server_url = Some(url.into());
        self
    }

    /// Set the namespace
    pub fn namespace(mut self, namespace: impl Into<String>) -> Self {
        self.namespace = Some(namespace.into());
        self
    }

    /// Set the cave name
    pub fn name(mut self, name: impl Into<String>) -> Self {
        self.name = Some(name.into());
        self
    }

    /// Set the API key
    pub fn api_key(mut self, api_key: impl Into<String>) -> Self {
        self.api_key = Some(api_key.into());
        self
    }

    /// Build the CaveOptions
    pub fn build(self) -> CaveOptions {
        CaveOptions {
            server_url: self.server_url,
            namespace: self.namespace,
            name: self.name,
            api_key: self.api_key,
        }
    }
}
