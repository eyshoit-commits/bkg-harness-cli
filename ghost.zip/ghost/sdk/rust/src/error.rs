use std::error::Error;
use std::fmt;

/// Common error types for the ghost SDK
#[derive(Debug)]
pub enum CaveError {
    /// The cave has not been started
    NotStarted,

    /// The request to the server failed
    RequestFailed(String),

    /// The server returned an error
    ServerError(String),

    /// The cave timed out
    Timeout(String),

    /// An error occurred with the HTTP client
    HttpError(String),

    /// Invalid response received from server
    InvalidResponse(String),

    /// General error
    General(String),
}

impl fmt::Display for CaveError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CaveError::NotStarted => write!(f, "Cave is not started. Call start() first."),
            CaveError::RequestFailed(msg) => {
                write!(f, "Failed to communicate with ghost server: {}", msg)
            }
            CaveError::ServerError(msg) => write!(f, "Server error: {}", msg),
            CaveError::Timeout(msg) => write!(f, "Timeout error: {}", msg),
            CaveError::HttpError(msg) => write!(f, "HTTP error: {}", msg),
            CaveError::InvalidResponse(msg) => {
                write!(f, "Invalid response from server: {}", msg)
            }
            CaveError::General(msg) => write!(f, "{}", msg),
        }
    }
}

impl Error for CaveError {}
