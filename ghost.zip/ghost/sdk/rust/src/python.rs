//! Python-specific cave implementation

use std::error::Error;
use std::sync::Arc;

use async_trait::async_trait;
use tokio::sync::Mutex;

use crate::command::Command;
use crate::{BaseCave, Execution, Metrics, CaveBase, CaveOptions, StartOptions};

/// Python-specific cave for executing Python code
pub struct PythonCave {
    /// Base cave implementation
    base: Arc<Mutex<CaveBase>>,
}

impl PythonCave {
    /// Create a new Python cave with a name
    pub async fn create(name: &str) -> Result<Self, Box<dyn Error + Send + Sync>> {
        let options = CaveOptions::builder().name(name).build();
        Self::create_with_options(options).await
    }

    /// Create a new Python cave with options
    pub async fn create_with_options(
        options: CaveOptions,
    ) -> Result<Self, Box<dyn Error + Send + Sync>> {
        let base = CaveBase::new(&options);

        // Create cave
        let cave = Self {
            base: Arc::new(Mutex::new(base)),
        };

        Ok(cave)
    }

    /// Get the command interface for executing shell commands
    pub async fn command(&self) -> Result<Command, Box<dyn Error + Send + Sync>> {
        Ok(Command::new(self.base.clone()))
    }

    /// Get the metrics interface for retrieving cave metrics
    pub async fn metrics(&self) -> Result<Metrics, Box<dyn Error + Send + Sync>> {
        Ok(Metrics::new(self.base.clone()))
    }
}

#[async_trait]
impl BaseCave for PythonCave {
    async fn get_default_image(&self) -> String {
        "ghost/python".to_string()
    }

    async fn is_started(&self) -> bool {
        let base = self.base.lock().await;
        base.is_started
    }

    async fn run(&self, code: &str) -> Result<Execution, Box<dyn Error + Send + Sync>> {
        // Check if cave is started
        let is_started = {
            let base = self.base.lock().await;
            base.is_started
        };

        if !is_started {
            return Err(Box::new(crate::CaveError::NotStarted));
        }

        // Execute code
        let base = self.base.lock().await;
        base.run_code("python", code).await
    }

    async fn start(
        &mut self,
        options: Option<StartOptions>,
    ) -> Result<(), Box<dyn Error + Send + Sync>> {
        let opts = options.unwrap_or_default();

        // Get default image
        let default_image = self.get_default_image().await;
        let image = opts.image.or_else(|| Some(default_image));

        let mut base = self.base.lock().await;
        base.start_cave(image, opts.memory, opts.cpus, opts.timeout)
            .await
    }

    async fn stop(&mut self) -> Result<(), Box<dyn Error + Send + Sync>> {
        // Check if already stopped
        let is_started = {
            let base = self.base.lock().await;
            base.is_started
        };

        if !is_started {
            return Ok(());
        }

        // Stop cave
        let mut base = self.base.lock().await;
        base.stop_cave().await
    }

    async fn metrics(&self) -> Result<Metrics, Box<dyn Error + Send + Sync>> {
        Ok(Metrics::new(self.base.clone()))
    }
}
