//! Advanced example demonstrating the Python cave features.
//!
//! This example shows:
//! 1. Different ways to create and manage cavees
//! 2. Resource configuration (memory, CPU)
//! 3. Error handling
//! 4. Multiple code execution patterns
//! 5. Output handling
//! 6. Timeouts and handling long-running starts
//!
//! Before running this example:
//!     1. Install the package as a dependency
//!     2. Start the ghost server (ghost-server)
//!     3. Run this script: cargo run --example repl
//!
//! Note: If authentication is enabled on the server, set GST_API_KEY in your environment.

use ghost::{BaseCave, PythonCave, CaveOptions, StartOptions};
use std::error::Error;

/// Example demonstrating basic cave creation and cleanup.
async fn example_simple_cave() -> Result<(), Box<dyn Error + Send + Sync>> {
    println!("\n=== Simple Cave Example ===");

    // Create a cave
    let mut cave = PythonCave::create("cave-simple").await?;

    // Start the cave
    cave.start(None).await?;

    // Run some computation
    let code = r#"
print("Hello, world!")
"#;
    let execution = cave.run(code).await?;
    let output = execution.output().await?;
    println!("Output: {}", output);

    // Stop the cave
    cave.stop().await?;

    Ok(())
}

/// Example using custom options and resource constraints.
async fn example_explicit_lifecycle() -> Result<(), Box<dyn Error + Send + Sync>> {
    println!("\n=== Explicit Lifecycle Example ===");

    // Create cave with custom configuration
    let options = CaveOptions::builder()
        .server_url("http://127.0.0.1:5555")
        .name("cave-explicit")
        .build();

    let mut cave = PythonCave::create_with_options(options).await?;

    // Start with resource constraints
    let start_options = StartOptions {
        image: None,
        memory: 1024, // 1GB RAM
        cpus: 2.0,    // 2 CPU cores
        timeout: 180.0,
    };

    // Start the cave
    cave.start(Some(start_options)).await?;

    // Run multiple code blocks with variable assignments
    cave.run("x = 42").await?;
    cave.run("y = [i**2 for i in range(10)]").await?;
    let execution3 = cave.run("print(f'x = {x}')\nprint(f'y = {y}')").await?;

    println!("Output: {}", execution3.output().await?);

    // Demonstrate error handling
    match cave.run("1/0").await {
        // This will raise a ZeroDivisionError
        Ok(error_execution) => {
            println!("Error: {}", error_execution.error().await?);
        }
        Err(e) => {
            println!("Caught error: {}", e);
        }
    }

    // Cleanup
    cave.stop().await?;

    Ok(())
}

/// Example demonstrating state persistence between executions.
async fn example_execution_chaining() -> Result<(), Box<dyn Error + Send + Sync>> {
    println!("\n=== Execution Chaining Example ===");

    // Create a cave
    let mut cave = PythonCave::create("cave-chain").await?;

    // Start the cave
    cave.start(None).await?;

    // Execute a sequence of related code blocks
    cave.run("name = 'Python'").await?;
    cave.run("import sys").await?;
    cave.run("version = sys.version").await?;
    let exec = cave
        .run("print(f'Hello from {name} {version}!')")
        .await?;

    // Only get output from the final execution
    println!("Output: {}", exec.output().await?);

    // Stop the cave
    cave.stop().await?;

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error + Send + Sync>> {
    // Run all examples
    example_simple_cave().await?;
    example_explicit_lifecycle().await?;
    example_execution_chaining().await?;

    Ok(())
}
