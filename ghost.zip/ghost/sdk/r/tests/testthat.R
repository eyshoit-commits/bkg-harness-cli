library(testthat)
library(ghost)

test_check("ghost")
