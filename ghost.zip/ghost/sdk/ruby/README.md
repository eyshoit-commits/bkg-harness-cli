# ghost Ruby SDK

A minimal Ruby SDK for the ghost project.

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'ghost'
```

And then execute:

```bash
bundle install
```

Or install it yourself as:

```bash
gem install ghost
```

## Usage

```ruby
require 'ghost'

# Print a greeting
ghost.greet('World')
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
