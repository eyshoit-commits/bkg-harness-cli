# frozen_string_literal: true

require "test_helper"

class ghostTest < Minitest::Test
  def test_that_it_has_a_version_number
    refute_nil ::ghost::VERSION
  end

  # Add more tests as you develop functionality
end
