# frozen_string_literal: true

module ghost
  VERSION = "0.1.0"
end
