# frozen_string_literal: true

require_relative "lib/ghost/version"

Gem::Specification.new do |spec|
  spec.name = "ghost"
  spec.version = ghost::VERSION
  spec.authors = ["ghost Team"]
  spec.email = ["team@ghost.dev"]

  spec.summary = "ghost Ruby SDK"
  spec.description = "A minimal Ruby SDK for the ghost project"
  spec.homepage = "https://github.com/ghost/ghost"
  spec.license = "Apache-2.0"
  spec.required_ruby_version = ">= 2.6.0"

  spec.metadata["homepage_uri"] = spec.homepage
  spec.metadata["source_code_uri"] = spec.homepage
  spec.metadata["changelog_uri"] = "#{spec.homepage}/blob/main/CHANGELOG.md"

  # Specify which files should be added to the gem
  spec.files = Dir.glob(%w[lib/**/*.rb LICENSE README.md])
  spec.require_paths = ["lib"]

  # Dependencies
  spec.add_development_dependency "bundler", "~> 1.17.0"
  spec.add_development_dependency "rake", "~> 13.0"
  spec.add_development_dependency "rspec", "~> 3.0"
  spec.add_development_dependency "minitest", "~> 5.0"
end
