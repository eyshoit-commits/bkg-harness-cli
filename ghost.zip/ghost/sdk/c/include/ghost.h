#ifndef ghost_H
#define ghost_H

/**
 * Returns a greeting message for the given name.
 *
 * @param name The name to greet
 * @return A dynamically allocated string containing the greeting message.
 *         The caller is responsible for freeing this memory.
 */
char* ghost_greet(const char* name);

#endif /* ghost_H */
