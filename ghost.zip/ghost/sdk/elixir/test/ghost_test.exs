defmodule ghostTest do
  use ExUnit.Case
  doctest ghost

  test "greet/1 returns the correct message" do
    result = ghost.greet("Test")
    assert result =~ "Hello, Test!"
  end
end
