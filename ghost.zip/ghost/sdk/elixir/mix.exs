defmodule ghost.MixProject do
  use Mix.Project

  def project do
    [
      app: :ghost,
      version: "0.1.0",
      elixir: "~> 1.12",
      start_permanent: Mix.env() == :prod,
      description: "A minimal Elixir SDK for the ghost project",
      package: package(),
      deps: deps(),
      name: "ghost",
      source_url: "https://github.com/ghost/ghost"
    ]
  end

  def application do
    [
      extra_applications: [:logger]
    ]
  end

  defp deps do
    [
      {:ex_doc, "~> 0.24", only: :dev, runtime: false}
    ]
  end

  defp package do
    [
      maintainers: ["ghost Team"],
      licenses: ["Apache-2.0"],
      links: %{
        "GitHub" => "https://github.com/ghost/ghost",
        "Website" => "https://ghost.dev"
      }
    ]
  end
end
