defmodule ghost do
  @moduledoc """
  A minimal SDK for the ghost project.
  """

  @doc """
  Returns a greeting message for the given name.

  ## Examples

      iex> ghost.greet("World")
      "Hello, World! Welcome to ghost!"

  """
  @spec greet(String.t()) :: String.t()
  def greet(name) do
    message = "Hello, #{name}! Welcome to ghost!"
    IO.puts(message)
    message
  end
end
