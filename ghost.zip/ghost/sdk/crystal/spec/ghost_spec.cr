require "./spec_helper"

describe ghost do
  it "has a version number" do
    ghost::VERSION.should eq("0.1.0")
  end

  describe ".greet" do
    it "returns a greeting message with the name" do
      result = ghost.greet("Test")
      result.should contain("Hello, Test!")
    end
  end
end
