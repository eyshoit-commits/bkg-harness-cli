require "spec"
require "../src/ghost"
