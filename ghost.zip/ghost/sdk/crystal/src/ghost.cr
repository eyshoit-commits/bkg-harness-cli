require "./ghost/version"

# Main module for the ghost library
module ghost
  # Returns a greeting message with the given name
  #
  # ## Example
  #
  # ```
  # ghost.greet("World") # => "Hello, World!"
  # ```
  def self.greet(name : String) : String
    "Hello, #{name}!"
  end
end
