package dev.ghost;

/**
 * Hello World class for the ghost SDK.
 */
public class HelloWorld {

    /**
     * Returns a greeting message for the given name.
     *
     * @param name The name to greet
     * @return A greeting message
     */
    public static String greet(String name) {
        String message = "Hello, " + name + "! Welcome to ghost!";
        System.out.println(message);
        return message;
    }
}
