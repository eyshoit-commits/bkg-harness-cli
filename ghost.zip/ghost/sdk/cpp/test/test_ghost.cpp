#include <iostream>
#include <string>
#include <cassert>
#include <ghost/ghost.hpp>

bool test_greet() {
    std::string result = ghost::greet("Test");

    // Check if the result contains the expected text
    bool success = (result.find("Hello, Test!") != std::string::npos);

    return success;
}

int main() {
    if (test_greet()) {
        std::cout << "Test passed!" << std::endl;
        return 0;
    } else {
        std::cout << "Test failed!" << std::endl;
        return 1;
    }
}
