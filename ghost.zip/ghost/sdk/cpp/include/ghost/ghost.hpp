#ifndef ghost_HPP
#define ghost_HPP

#include <string>

namespace ghost {
    /**
     * Returns a greeting message for the given name.
     *
     * @param name The name to greet
     * @return A greeting message
     */
    std::string greet(const std::string& name);
}

#endif // ghost_HPP
