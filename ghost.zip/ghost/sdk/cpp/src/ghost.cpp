#include <iostream>
#include <ghost/ghost.hpp>
namespace ghost {
    std::string greet(const std::string& name) {
        std::string message = "Hello, " + name + "! Welcome to ghost!";
        std::cout << message << std::endl;
        return message;
    }
}
