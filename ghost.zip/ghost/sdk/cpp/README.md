# ghost C++ SDK

A minimal C++ SDK for the ghost project.

## Installation

### Using CMake (recommended)

1. Clone this repository:

```bash
git clone https://github.com/yourusername/monocore.git
```

2. Add the SDK to your CMake project:

```cmake
# In your CMakeLists.txt
add_subdirectory(/path/to/monocore/sdk/cpp)
target_link_libraries(your_target ghost)
```

### Using vcpkg

```bash
vcpkg install ghost
```

### Using Conan

```bash
conan install ghost/0.0.1
```

## Usage

```cpp
#include <iostream>
#include <ghost/ghost.hpp>

int main() {
    // Print a greeting
    std::string message = ghost::greet("World");
    std::cout << message << std::endl;
    return 0;
}
```

## License

[MIT](LICENSE)
