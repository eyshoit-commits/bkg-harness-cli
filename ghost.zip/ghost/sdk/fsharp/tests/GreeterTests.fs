module ghost.Tests

open System
open Xunit
open ghost

[<Fact>]
let ``Greeter returns correct message`` () =
    let result = Greeter.greet "Test"
    Assert.Contains("Hello, Test!", result)
