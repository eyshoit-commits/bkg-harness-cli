# ghost Kotlin SDK

A minimal Kotlin SDK for the ghost project.

## Installation

### Gradle

```kotlin
dependencies {
    implementation("dev.ghost:ghost-kotlin:0.1.0")
}
```

### Maven

```xml
<dependency>
    <groupId>dev.ghost</groupId>
    <artifactId>ghost-kotlin</artifactId>
    <version>0.1.0</version>
</dependency>
```

## Usage

```kotlin
import dev.ghost.HelloWorld

fun main() {
    // Print a greeting
    HelloWorld.greet("World")
}
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
