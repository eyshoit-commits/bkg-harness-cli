package dev.ghost

/**
 * Hello World class for the ghost SDK.
 */
object HelloWorld {

    /**
     * Returns a greeting message for the given name.
     *
     * @param name The name to greet
     * @return A greeting message
     */
    fun greet(name: String): String {
        val message = "Hello, $name! Welcome to ghost!"
        println(message)
        return message
    }
}
