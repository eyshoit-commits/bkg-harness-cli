#!/usr/bin/env python3
"""
Advanced example demonstrating the Python cave features.

This example shows:
1. Different ways to create and manage cavees
2. Resource configuration (memory, CPU)
3. Error handling
4. Multiple code execution patterns
5. Output handling
6. Timeouts and handling long-running starts

Before running this example:
    1. Install the package: pip install -e .
    2. Start the ghost server (ghost-server)
    3. Run this script: python -m examples.python_cave

Note: If authentication is enabled on the server, set GST_API_KEY in your environment.
"""

import asyncio

import aiohttp
from ghost import PythonCave


async def example_context_manager():
    """Example using the async context manager pattern."""
    print("\n=== Context Manager Example ===")

    async with PythonCave.create(name="cave-cm") as cave:
        # Run some computation
        code = """
print("Hello, world!")
"""
        execution = await cave.run(code)
        output = await execution.output()
        print("Output:", output)


async def example_explicit_lifecycle():
    """Example using explicit lifecycle management."""
    print("\n=== Explicit Lifecycle Example ===")

    # Create cave with custom configuration
    cave = PythonCave(
        server_url="http://127.0.0.1:5555", name="cave-explicit"
    )

    # Create HTTP session
    cave._session = aiohttp.ClientSession()

    try:
        # Start with resource constraints
        await cave.start(
            memory=1024,  # 1GB RAM
            cpus=2.0,  # 2 CPU cores
        )

        # Run multiple code blocks with variable assignments
        await cave.run("x = 42")
        await cave.run("y = [i**2 for i in range(10)]")
        execution3 = await cave.run("print(f'x = {x}')\nprint(f'y = {y}')")

        print("Output:", await execution3.output())

        # Demonstrate error handling
        try:
            error_execution = await cave.run(
                "1/0"
            )  # This will raise a ZeroDivisionError
            print("Error:", await error_execution.error())
        except RuntimeError as e:
            print("Caught error:", e)

    finally:
        # Cleanup
        await cave.stop()
        await cave._session.close()


async def example_execution_chaining():
    """Example demonstrating execution chaining with variables."""
    print("\n=== Execution Chaining Example ===")

    async with PythonCave.create(name="cave-chain") as cave:
        # Execute a sequence of related code blocks
        await cave.run("name = 'Python'")
        await cave.run("import sys")
        await cave.run("version = sys.version")
        exec = await cave.run("print(f'Hello from {name} {version}!')")

        # Only get output from the final execution
        print("Output:", await exec.output())


async def main():
    """Run all examples."""
    try:
        await example_context_manager()
        await example_explicit_lifecycle()
        await example_execution_chaining()
    except Exception as e:
        print(f"Error running examples: {e}")


if __name__ == "__main__":
    asyncio.run(main())
