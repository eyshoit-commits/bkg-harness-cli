"""
Base cave implementation for the ghost Python SDK.
"""

import asyncio
import os
import uuid
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from typing import Optional

import aiohttp
from dotenv import load_dotenv

from .command import Command
from .metrics import Metrics


class BaseCave(ABC):
    """
    Base cave environment for executing code safely.

    This class provides the base interface for interacting with the ghost server.
    It handles common functionality like cave creation, management, and communication.
    """

    def __init__(
        self,
        server_url: str = None,
        namespace: str = "default",
        name: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        """
        Initialize a base cave instance.

        Args:
            server_url: URL of the ghost server. If not provided, will check GST_SERVER_URL environment variable, then fall back to default.
            namespace: Namespace for the cave
            name: Optional name for the cave. If not provided, a random name will be generated.
            api_key: API key for ghost server authentication. If not provided, it will be read from GST_API_KEY environment variable.
        """
        # Only try to load .env if GST_API_KEY is not already set
        if "GST_API_KEY" not in os.environ:
            # Ignore errors if .env file doesn't exist
            try:
                load_dotenv()
            except Exception:
                pass

        self._server_url = server_url or os.environ.get(
            "GST_SERVER_URL", "http://127.0.0.1:5555"
        )
        self._namespace = namespace
        self._name = name or f"cave-{uuid.uuid4().hex[:8]}"
        self._api_key = api_key or os.environ.get("GST_API_KEY")
        self._session = None
        self._is_started = False

    @abstractmethod
    async def get_default_image(self) -> str:
        """
        Get the default Docker image for this cave type.

        Returns:
            A string containing the Docker image name and tag
        """
        pass

    @classmethod
    @asynccontextmanager
    async def create(
        cls,
        server_url: str = None,
        namespace: str = "default",
        name: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        """
        Create and initialize a new cave as an async context manager.

        Args:
            server_url: URL of the ghost server. If not provided, will check GST_SERVER_URL environment variable, then fall back to default.
            namespace: Namespace for the cave
            name: Optional name for the cave. If not provided, a random name will be generated.
            api_key: API key for ghost server authentication. If not provided, it will be read from GST_API_KEY environment variable.

        Returns:
            An instance of the cave ready for use
        """
        # Only try to load .env if GST_API_KEY is not already set
        if "GST_API_KEY" not in os.environ:
            # Ignore errors if .env file doesn't exist
            try:
                load_dotenv()
            except Exception:
                pass

        cave = cls(
            server_url=server_url,
            namespace=namespace,
            name=name,
            api_key=api_key,
        )
        try:
            # Create HTTP session
            cave._session = aiohttp.ClientSession()
            # Start the cave
            await cave.start()
            yield cave
        finally:
            # Stop the cave
            await cave.stop()
            # Close the HTTP session
            if cave._session:
                await cave._session.close()
                cave._session = None

    async def start(
        self,
        image: Optional[str] = None,
        memory: int = 512,
        cpus: float = 1.0,
        timeout: float = 180.0,
    ) -> None:
        """
        Start the cave container.

        Args:
            image: Docker image to use for the cave (defaults to language-specific image)
            memory: Memory limit in MB
            cpus: CPU limit (will be rounded to nearest integer)
            timeout: Maximum time in seconds to wait for the cave to start (default: 180 seconds)

        Raises:
            RuntimeError: If the cave fails to start
            TimeoutError: If the cave doesn't start within the specified timeout
        """
        if self._is_started:
            return

        cave_image = image or await self.get_default_image()
        request_data = {
            "jsonrpc": "2.0",
            "method": "cave.start",
            "params": {
                "namespace": self._namespace,
                "cave": self._name,
                "config": {
                    "image": cave_image,
                    "memory": memory,
                    "cpus": int(round(cpus)),
                },
            },
            "id": str(uuid.uuid4()),
        }

        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            # Set a client-side timeout that's a bit longer than the server-side timeout
            # to account for network latency and processing time
            client_timeout = aiohttp.ClientTimeout(total=timeout + 30)

            async with self._session.post(
                f"{self._server_url}/api/v1/rpc",
                json=request_data,
                headers=headers,
                timeout=client_timeout,
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Failed to start cave: {error_text}")

                response_data = await response.json()
                if "error" in response_data:
                    raise RuntimeError(
                        f"Failed to start cave: {response_data['error']['message']}"
                    )

                # Check the result message - it might indicate the cave is still initializing
                result = response_data.get("result", "")
                if isinstance(result, str) and "timed out waiting" in result:
                    # Server timed out but still started the cave
                    # We'll raise a warning but still consider it started
                    import warnings

                    warnings.warn(f"Cave start warning: {result}")

                self._is_started = True
        except aiohttp.ClientError as e:
            if isinstance(e, asyncio.TimeoutError):
                raise TimeoutError(
                    f"Timed out waiting for cave to start after {timeout} seconds"
                ) from e
            raise RuntimeError(f"Failed to communicate with ghost server: {e}")

    async def stop(self) -> None:
        """
        Stop the cave container.

        Raises:
            RuntimeError: If the cave fails to stop
        """
        if not self._is_started:
            return

        request_data = {
            "jsonrpc": "2.0",
            "method": "cave.stop",
            "params": {"namespace": self._namespace, "cave": self._name},
            "id": str(uuid.uuid4()),
        }

        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        try:
            async with self._session.post(
                f"{self._server_url}/api/v1/rpc",
                json=request_data,
                headers=headers,
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Failed to stop cave: {error_text}")

                response_data = await response.json()
                if "error" in response_data:
                    raise RuntimeError(
                        f"Failed to stop cave: {response_data['error']['message']}"
                    )

                self._is_started = False
        except aiohttp.ClientError as e:
            raise RuntimeError(f"Failed to communicate with ghost server: {e}")

    @abstractmethod
    async def run(self, code: str):
        """
        Execute code in the cave.

        Args:
            code: Code to execute

        Returns:
            An Execution object representing the executed code

        Raises:
            RuntimeError: If execution fails
        """
        pass

    @property
    def command(self):
        """
        Access the command namespace for executing shell commands in the cave.

        Returns:
            A Command instance bound to this cave
        """
        return Command(self)

    @property
    def metrics(self):
        """
        Access the metrics namespace for retrieving cave metrics.

        Returns:
            A Metrics instance bound to this cave
        """
        return Metrics(self)
