"""
Metrics interface for the ghost Python SDK.
"""

import uuid
from typing import Optional


class Metrics:
    """
    Metrics class for retrieving resource metrics for a cave.

    This class provides methods to access specific metrics (CPU, memory, disk)
    for the cave instance it's attached to.
    """

    def __init__(self, cave_instance):
        """
        Initialize the metrics instance.

        Args:
            cave_instance: The cave instance this metrics object belongs to
        """
        self._cave = cave_instance

    async def _get_metrics(self) -> dict:
        """
        Internal method to fetch current metrics from the server.

        Returns:
            A dictionary containing the metrics data for the cave

        Raises:
            RuntimeError: If the request to the server fails
        """
        if not self._cave._is_started:
            raise RuntimeError("Cave is not started. Call start() first.")

        headers = {"Content-Type": "application/json"}
        if self._cave._api_key:
            headers["Authorization"] = f"Bearer {self._cave._api_key}"

        # Prepare the request data
        request_data = {
            "jsonrpc": "2.0",
            "method": "cave.metrics.get",
            "params": {
                "namespace": self._cave._namespace,
                "cave": self._cave._name,
            },
            "id": str(uuid.uuid4()),
        }

        try:
            async with self._cave._session.post(
                f"{self._cave._server_url}/api/v1/rpc",
                json=request_data,
                headers=headers,
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Failed to get cave metrics: {error_text}")

                response_data = await response.json()
                if "error" in response_data:
                    raise RuntimeError(
                        f"Failed to get cave metrics: {response_data['error']['message']}"
                    )

                result = response_data.get("result", {})
                cavees = result.get("cavees", [])

                # We expect exactly one cave in the response (our own)
                if not cavees:
                    return {}

                # Return the first (and should be only) cave data
                return cavees[0]
        except Exception as e:
            raise RuntimeError(f"Failed to get cave metrics: {e}")

    async def all(self) -> dict:
        """
        Get all metrics for the current cave.

        Returns:
            A dictionary containing all metrics for the cave:
            {
                "name": str,
                "namespace": str,
                "running": bool,
                "cpu_usage": Optional[float],
                "memory_usage": Optional[int],
                "disk_usage": Optional[int]
            }

        Raises:
            RuntimeError: If the cave is not started or if the request fails
        """
        return await self._get_metrics()

    async def cpu(self) -> Optional[float]:
        """
        Get CPU usage percentage for the current cave.

        Returns:
            CPU usage as a percentage (0-100) or None if not available.
            May return 0.0 for idle cavees or when metrics are not precise.

        Raises:
            RuntimeError: If the cave is not started or if the request fails
        """
        metrics = await self._get_metrics()
        return metrics.get("cpu_usage")

    async def memory(self) -> Optional[int]:
        """
        Get memory usage for the current cave.

        Returns:
            Memory usage in MiB or None if not available

        Raises:
            RuntimeError: If the cave is not started or if the request fails
        """
        metrics = await self._get_metrics()
        return metrics.get("memory_usage")

    async def disk(self) -> Optional[int]:
        """
        Get disk usage for the current cave.

        Returns:
            Disk usage in bytes or None if not available

        Raises:
            RuntimeError: If the cave is not started or if the request fails
        """
        metrics = await self._get_metrics()
        return metrics.get("disk_usage")

    async def is_running(self) -> bool:
        """
        Check if the cave is currently running.

        Returns:
            True if the cave is running, False otherwise

        Raises:
            RuntimeError: If the request to the server fails
        """
        metrics = await self._get_metrics()
        return metrics.get("running", False)
