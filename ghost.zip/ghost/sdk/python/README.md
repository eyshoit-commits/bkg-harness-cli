# ghost Python SDK

A Python SDK for interacting with ghost environments.

## Installation

```bash
# Install from PyPI
pip install ghost

# Or install from source
git clone https://github.com/ghost/ghost.git
cd ghost/sdk/python
pip install -e .
```

## Usage

### Running Code

```python
import asyncio
from ghost import PythonCave

async def main():
    # Using the context manager (automatically starts and stops the cave)
    async with PythonCave.create() as cave:
        # Run code in the cave
        await cave.run("name = 'Python'")
        execution = await cave.run("print(f'Hello {name}!')")

        # Get the output
        output = await execution.output()
        print(output)  # prints Hello Python!

# Run the async main function
asyncio.run(main())
```

### Executing Shell Commands

```python
import asyncio
from ghost import PythonCave

async def main():
    async with PythonCave.create() as cave:
        # Execute a command with arguments
        execution = await cave.command.run("echo", ["Hello", "World"])

        # Get the command output
        print(await execution.output())  # prints "Hello World"

        # Check the exit code and success status
        print(f"Exit code: {execution.exit_code}")
        print(f"Success: {execution.success}")

        # Handle command errors
        error_cmd = await cave.command.run("ls", ["/nonexistent"])
        print(await error_cmd.error())  # prints error message

        # Specify a timeout (in seconds)
        try:
            await cave.command.run("sleep", ["10"], timeout=2)
        except RuntimeError as e:
            print(f"Command timed out: {e}")

asyncio.run(main())
```

## Requirements

- Python 3.8+
- Running ghost server (default: http://127.0.0.1:5555)
- API key (if authentication is enabled on the server)

## Environment Variables

- `GST_API_KEY`: Optional API key for authentication with the ghost server
- `GST_SERVER_URL`: URL for the ghost server (default: http://127.0.0.1:5555)

## Examples

Check out the [examples directory](./examples) for sample scripts that demonstrate how to:

- Create and use cavees
- Run code in cave environments
- Execute shell commands in the cave
- Handle execution output and error handling

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
