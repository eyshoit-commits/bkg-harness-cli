-module(ghost).

-export([greet/1]).

%% @doc Returns a greeting message for the given name.
%%
%% Example:
%%   ```
%%   {ok, Greeting} = ghost:greet("World"),
%%   io:format("~s~n", [Greeting]).
%%   '''
-spec greet(string()) -> {ok, string()}.
greet(Name) ->
    Message = "Hello, " ++ Name ++ "! Welcome to ghost!",
    io:format("~s~n", [Message]),
    {ok, Message}.
