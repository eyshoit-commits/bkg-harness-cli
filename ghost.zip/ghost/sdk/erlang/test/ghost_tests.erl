-module(ghost_tests).

-include_lib("eunit/include/eunit.hrl").

greet_test() ->
    {ok, Result} = ghost:greet("Test"),
    ?assertMatch(true, string:find(Result, "Hello, Test!") /= nomatch).
