/// A minimal SDK for the ghost project.
library ghost;

/// Returns a greeting message for the given name.
///
/// Example:
/// ```dart
/// var message = greet('World');
/// print(message); // Prints: Hello, World! Welcome to ghost!
/// ```
String greet(String name) {
  final message = 'Hello, $name! Welcome to ghost!';
  print(message);
  return message;
}
