# ghost Dart SDK

A minimal Dart SDK for the ghost project.

## Installation

```yaml
dependencies:
  ghost: ^0.0.1
```

## Usage

```dart
import 'package:ghost/ghost.dart';

void main() {
  // Print a greeting
  greet('World');
}
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
