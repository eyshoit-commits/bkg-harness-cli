module ghost

"""
    greet(name::String)

Returns a greeting message for the given name.

# Examples
```julia
julia> greet("World")
"Hello, World! Welcome to ghost!"
```
"""
function greet(name::String)
    message = "Hello, $(name)! Welcome to ghost!"
    println(message)
    return message
end

export greet

end # module
