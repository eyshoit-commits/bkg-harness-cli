# ghost.jl

A minimal Julia SDK for the ghost project.

## Installation

```julia
] add ghost
```

Or directly:

```julia
using Pkg
Pkg.add("ghost")
```

## Usage

```julia
using ghost

# Print a greeting
greet("World")
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
