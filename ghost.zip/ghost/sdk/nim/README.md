# ghost Nim SDK

A minimal Nim SDK for the ghost project.

## Installation

```bash
nimble install ghost
```

Or add to your `.nimble` file:

```nim
requires "ghost >= 0.0.1"
```

## Usage

```nim
import ghost

# Print a greeting
let message = greet("World")
```

## License

[MIT](LICENSE)
