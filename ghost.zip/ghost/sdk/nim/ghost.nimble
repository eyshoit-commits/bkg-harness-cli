# Package information
version       = "0.1.0"
author        = "ghost Team <team@ghost.dev>"
description   = "A minimal Nim SDK for the ghost project"
license       = "Apache-2.0"
srcDir        = "src"

# Repository
packageName   = "ghost"
skipDirs      = @["tests"]

# Dependencies
requires "nim >= 1.6.0"

task test, "Run the test suite":
  exec "nim c -r tests/test_ghost.nim"
