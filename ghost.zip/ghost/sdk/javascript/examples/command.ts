/**
 * Example demonstrating how to use cave.command.run to execute shell commands.
 *
 * Before running this example:
 *     1. Install the package: npm install
 *     2. Start the ghost server (ghost-server)
 *     3. Run this script: npx ts-node examples/command.ts
 */

import { PythonCave } from "../src";

/**
 * Example showing basic command execution with context manager.
 */
async function basicExample() {
  console.log("\n=== Basic Command Example ===");

  // Create a cave using a try/finally pattern (equivalent to Python's context manager)
  const cave = await PythonCave.create({ name: "command-example" });

  try {
    // Run a simple command
    const lsExecution = await cave.command.run("ls", ["-la", "/"]);
    console.log("$ ls -la /");
    console.log(`Exit code: ${lsExecution.exitCode}`);
    console.log("Output:");
    console.log(await lsExecution.output());

    // Execute a command with string arguments
    const echoExecution = await cave.command.run("echo", [
      "Hello from",
      "cave command!",
    ]);
    console.log("\n$ echo Hello from cave command!");
    console.log(`Output: ${await echoExecution.output()}`);

    // Get system information
    const unameExecution = await cave.command.run("uname", ["-a"]);
    console.log("\n$ uname -a");
    console.log(`Output: ${await unameExecution.output()}`);
  } finally {
    await cave.stop();
  }
}

/**
 * Example showing how to handle command errors.
 */
async function errorHandlingExample() {
  console.log("\n=== Error Handling Example ===");

  const cave = await PythonCave.create({ name: "error-example" });

  try {
    // Run a command that generates an error
    const errorExecution = await cave.command.run("ls", ["/nonexistent"]);

    console.log("$ ls /nonexistent");
    console.log(`Exit code: ${errorExecution.exitCode}`);
    console.log(`Success: ${errorExecution.success}`);
    console.log("Error output:");
    console.log(await errorExecution.error());

    // Deliberately cause a command not found error
    try {
      await cave.command.run("nonexistentcommand", []);
      // This should not execute if the command fails
      console.log("Command succeeded unexpectedly");
    } catch (e) {
      console.log(
        `\nCaught exception for nonexistent command: ${
          e instanceof Error ? e.message : e
        }`
      );
    }
  } finally {
    await cave.stop();
  }
}

/**
 * Example showing how to use command timeouts.
 */
async function timeoutExample() {
  console.log("\n=== Timeout Example ===");

  const cave = await PythonCave.create({ name: "timeout-example" });

  try {
    console.log("Running command with timeout...");
    try {
      // Run a command that takes longer than the specified timeout
      await cave.command.run("sleep", ["10"], 2);
      console.log("Command completed (unexpected!)");
    } catch (e) {
      console.log(
        `Command timed out as expected: ${e instanceof Error ? e.message : e}`
      );
    }

    // Show that the cave is still usable after a timeout
    const echoExecution = await cave.command.run("echo", ["Still working!"]);
    console.log(`\nCave still works: ${await echoExecution.output()}`);
  } finally {
    await cave.stop();
  }
}

/**
 * Example showing more advanced command usage.
 */
async function advancedExample() {
  console.log("\n=== Advanced Example ===");

  const cave = await PythonCave.create({ name: "advanced-example" });

  try {
    // Write a file
    const writeCmd = await cave.command.run("bash", [
      "-c",
      "echo 'Hello, file content!' > /tmp/test.txt",
    ]);
    console.log(`Created file, exit code: ${writeCmd.exitCode}`);

    // Read the file back
    const readCmd = await cave.command.run("cat", ["/tmp/test.txt"]);
    console.log(`File content: ${await readCmd.output()}`);

    // Run a more complex pipeline
    const pipelineCmd = await cave.command.run("bash", [
      "-c",
      "mkdir -p /tmp/test_dir && " +
        "echo 'Line 1' > /tmp/test_dir/data.txt && " +
        "echo 'Line 2' >> /tmp/test_dir/data.txt && " +
        "cat /tmp/test_dir/data.txt | grep 'Line' | wc -l",
    ]);
    console.log(
      `\nPipeline output (should be 2): ${await pipelineCmd.output()}`
    );

    // Create and run a Python script
    const createScript = await cave.command.run("bash", [
      "-c",
      `cat > /tmp/test.py << 'EOF'
import sys
print("Python script executed!")
print(f"Arguments: {sys.argv[1:]}")
EOF`,
    ]);

    if (createScript.success) {
      // Run the script with arguments
      const scriptCmd = await cave.command.run("python", [
        "/tmp/test.py",
        "arg1",
        "arg2",
        "arg3",
      ]);
      console.log("\nPython script output:");
      console.log(await scriptCmd.output());
    }
  } finally {
    await cave.stop();
  }
}

/**
 * Example showing explicit lifecycle management.
 */
async function explicitLifecycleExample() {
  console.log("\n=== Explicit Lifecycle Example ===");

  // Create cave without context manager
  const cave = new PythonCave({ name: "explicit-lifecycle" });

  try {
    // Manually start the cave
    console.log("Starting cave...");
    await cave.start();

    // Execute commands
    const hostnameCmd = await cave.command.run("hostname");
    console.log(`Hostname: ${await hostnameCmd.output()}`);

    const dateCmd = await cave.command.run("date");
    console.log(`Date: ${await dateCmd.output()}`);
  } finally {
    // Manually stop the cave
    console.log("Stopping cave...");
    await cave.stop();
  }
}

/**
 * Main function to run all examples.
 */
async function main() {
  console.log("Command Execution Examples");
  console.log("=========================");

  try {
    await basicExample();
    await errorHandlingExample();
    await timeoutExample();
    await advancedExample();
    await explicitLifecycleExample();

    console.log("\nAll command examples completed!");
  } catch (e) {
    console.error(
      `Error running examples: ${e instanceof Error ? e.message : e}`
    );
  }
}

main();
