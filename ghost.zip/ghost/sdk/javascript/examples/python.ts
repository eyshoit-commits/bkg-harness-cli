/**
 * Advanced example demonstrating the Python cave features.
 *
 * This example shows:
 * 1. Different ways to create and manage cavees
 * 2. Resource configuration (memory, CPU)
 * 3. Error handling
 * 4. Multiple code execution patterns
 * 5. Output handling
 * 6. Timeouts and handling long-running starts
 *
 * Before running this example:
 *     1. Install the package: npm install
 *     2. Start the ghost server (ghost-server)
 *     3. Run this script: npx ts-node examples/python.ts
 *
 * Note: If authentication is enabled on the server, set GST_API_KEY in your environment.
 */

import { PythonCave } from "../src";

/**
 * Example demonstrating basic cave creation and cleanup.
 */
async function exampleContextManager() {
  console.log("\n=== Simple Cave Example ===");

  // Create and start a cave (equivalent to Python's async with)
  const cave = await PythonCave.create({ name: "cave-cm" });

  try {
    // Run some computation
    const code = `
print("Hello, world!")
`;
    const execution = await cave.run(code);
    const output = await execution.output();
    console.log("Output:", output);
  } finally {
    // Always stop the cave (equivalent to Python's context manager cleanup)
    await cave.stop();
  }
}

/**
 * Example using explicit lifecycle management.
 */
async function exampleExplicitLifecycle() {
  console.log("\n=== Explicit Lifecycle Example ===");

  // Create cave with custom configuration
  const cave = new PythonCave({
    serverUrl: "http://127.0.0.1:5555",
    name: "cave-explicit",
  });

  try {
    // Start with resource constraints
    await cave.start(
      undefined, // use default image
      1024, // 1GB RAM
      2.0 // 2 CPU cores
    );

    // Run multiple code blocks with variable assignments
    await cave.run("x = 42");
    await cave.run("y = [i**2 for i in range(10)]");
    const execution3 = await cave.run(
      "print(f'x = {x}')\nprint(f'y = {y}')"
    );

    console.log("Output:", await execution3.output());

    // Demonstrate error handling
    try {
      const errorExecution = await cave.run("1/0"); // This will raise a ZeroDivisionError
      console.log("Error:", await errorExecution.error());
    } catch (e) {
      console.log("Caught error:", e instanceof Error ? e.message : e);
    }
  } finally {
    // Cleanup
    await cave.stop();
  }
}

/**
 * Example demonstrating execution chaining with variables.
 */
async function exampleExecutionChaining() {
  console.log("\n=== Execution Chaining Example ===");

  const cave = await PythonCave.create({ name: "cave-chain" });

  try {
    // Execute a sequence of related code blocks
    await cave.run("name = 'Python'");
    await cave.run("import sys");
    await cave.run("version = sys.version");
    const exec = await cave.run("print(f'Hello from {name} {version}!')");

    // Only get output from the final execution
    console.log("Output:", await exec.output());
  } finally {
    await cave.stop();
  }
}

/**
 * Run all examples.
 */
async function main() {
  try {
    await exampleContextManager();
    await exampleExplicitLifecycle();
    await exampleExecutionChaining();

    console.log("\nAll Python examples completed!");
  } catch (e) {
    console.error(
      `Error running examples: ${e instanceof Error ? e.message : e}`
    );
  }
}

main();
