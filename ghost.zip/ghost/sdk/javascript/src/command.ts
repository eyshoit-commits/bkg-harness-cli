/**
 * Command execution interface for the ghost TypeScript SDK.
 */

import { v4 as uuidv4 } from "uuid";
import fetch from "node-fetch";

import { CommandExecution } from "./command-execution";
import { BaseCave } from "./base-cave";

export class Command {
  private cave: BaseCave;

  /**
   * Initialize the command instance.
   *
   * @param caveInstance - The cave instance this command belongs to
   */
  constructor(caveInstance: BaseCave) {
    this.cave = caveInstance;
  }

  /**
   * Execute a shell command in the cave.
   *
   * @param command - The command to execute
   * @param args - Optional list of command arguments
   * @param timeout - Optional timeout in seconds
   * @returns A CommandExecution object containing the results
   * @throws Error if the cave is not started or execution fails
   */
  async run(
    command: string,
    args?: string[],
    timeout?: number
  ): Promise<CommandExecution> {
    if (!this.cave.isStarted) {
      throw new Error("Cave is not started. Call start() first.");
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.cave.apiKey) {
      headers["Authorization"] = `Bearer ${this.cave.apiKey}`;
    }

    // Prepare the request data
    const requestData: {
      jsonrpc: string;
      method: string;
      params: {
        cave: string;
        namespace: string;
        command: string;
        args: string[];
        timeout?: number;
      };
      id: string;
    } = {
      jsonrpc: "2.0",
      method: "cave.command.run",
      params: {
        cave: this.cave.name,
        namespace: this.cave.namespace,
        command,
        args: args || [],
      },
      id: uuidv4(),
    };

    // Add timeout if specified
    if (timeout !== undefined) {
      requestData.params.timeout = timeout;
    }

    try {
      const response = await fetch(`${this.cave.serverUrl}/api/v1/rpc`, {
        method: "POST",
        headers,
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to execute command: ${errorText}`);
      }

      const responseData = await response.json();

      if ("error" in responseData) {
        throw new Error(
          `Failed to execute command: ${responseData.error.message}`
        );
      }

      const result = responseData.result || {};

      // Create and return a CommandExecution object with the output data
      return new CommandExecution(result);
    } catch (e) {
      if (e instanceof Error) {
        throw new Error(`Failed to execute command: ${e.message}`);
      }
      throw new Error("Failed to execute command: Unknown error");
    }
  }
}
