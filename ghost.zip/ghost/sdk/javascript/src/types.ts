/**
 * Common types and interfaces for the ghost TypeScript SDK
 */

/**
 * Options for creating a cave
 */
export interface CaveOptions {
  /**
   * URL of the ghost server
   */
  serverUrl?: string;

  /**
   * Namespace for the cave
   */
  namespace?: string;

  /**
   * Name for the cave
   */
  name?: string;

  /**
   * API key for ghost server authentication
   */
  apiKey?: string;

  /**
   * Docker image to use for the cave
   */
  image?: string;

  /**
   * Memory limit in MB
   */
  memory?: number;

  /**
   * CPU limit (will be rounded to nearest integer)
   */
  cpus?: number;

  /**
   * Maximum time in seconds to wait for the cave to start
   */
  timeout?: number;
}

/**
 * Builder pattern for CaveOptions
 */
export class CaveOptionsBuilder {
  private options: CaveOptions = {};

  /**
   * Set server URL
   */
  serverUrl(serverUrl: string): CaveOptionsBuilder {
    this.options.serverUrl = serverUrl;
    return this;
  }

  /**
   * Set namespace
   */
  namespace(namespace: string): CaveOptionsBuilder {
    this.options.namespace = namespace;
    return this;
  }

  /**
   * Set cave name
   */
  name(name: string): CaveOptionsBuilder {
    this.options.name = name;
    return this;
  }

  /**
   * Set API key
   */
  apiKey(apiKey: string): CaveOptionsBuilder {
    this.options.apiKey = apiKey;
    return this;
  }

  /**
   * Set Docker image
   */
  image(image: string): CaveOptionsBuilder {
    this.options.image = image;
    return this;
  }

  /**
   * Set memory limit
   */
  memory(memory: number): CaveOptionsBuilder {
    this.options.memory = memory;
    return this;
  }

  /**
   * Set CPU limit
   */
  cpus(cpus: number): CaveOptionsBuilder {
    this.options.cpus = cpus;
    return this;
  }

  /**
   * Set timeout
   */
  timeout(timeout: number): CaveOptionsBuilder {
    this.options.timeout = timeout;
    return this;
  }

  /**
   * Build CaveOptions object
   */
  build(): CaveOptions {
    return { ...this.options };
  }
}

/**
 * Namespace for CaveOptions
 */
export namespace CaveOptions {
  /**
   * Create a builder for CaveOptions
   */
  export const builder = (): CaveOptionsBuilder =>
    new CaveOptionsBuilder();
}

/**
 * Output line from cave execution
 */
export interface OutputLine {
  stream: "stdout" | "stderr";
  text: string;
}

/**
 * Output data from cave execution
 */
export interface OutputData {
  output?: OutputLine[];
  status?: string;
  language?: string;
  success?: boolean;
  exit_code?: number;
  command?: string;
  args?: string[];
}
