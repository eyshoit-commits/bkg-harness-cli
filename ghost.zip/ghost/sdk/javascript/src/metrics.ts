/**
 * Metrics interface for the ghost TypeScript SDK.
 */

import { v4 as uuidv4 } from "uuid";
import fetch from "node-fetch";

import { BaseCave } from "./base-cave";

export class Metrics {
  private cave: BaseCave;

  /**
   * Initialize the metrics instance.
   *
   * @param caveInstance - The cave instance this metrics object belongs to
   */
  constructor(caveInstance: BaseCave) {
    this.cave = caveInstance;
  }

  /**
   * Internal method to fetch current metrics from the server.
   *
   * @returns A dictionary containing the metrics data for the cave
   * @throws Error if the request to the server fails
   */
  private async getMetrics(): Promise<any> {
    if (!this.cave.isStarted) {
      throw new Error("Cave is not started. Call start() first.");
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (this.cave.apiKey) {
      headers["Authorization"] = `Bearer ${this.cave.apiKey}`;
    }

    // Prepare the request data
    const requestData = {
      jsonrpc: "2.0",
      method: "cave.metrics.get",
      params: {
        namespace: this.cave.namespace,
        cave: this.cave.name,
      },
      id: uuidv4(),
    };

    try {
      const response = await fetch(`${this.cave.serverUrl}/api/v1/rpc`, {
        method: "POST",
        headers,
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to get cave metrics: ${errorText}`);
      }

      const responseData = await response.json();

      if ("error" in responseData) {
        throw new Error(
          `Failed to get cave metrics: ${responseData.error.message}`
        );
      }

      const result = responseData.result || {};
      const cavees = result.cavees || [];

      // We expect exactly one cave in the response (our own)
      if (!cavees.length) {
        return {};
      }

      // Return the first (and should be only) cave data
      return cavees[0];
    } catch (e) {
      if (e instanceof Error) {
        throw new Error(`Failed to get cave metrics: ${e.message}`);
      }
      throw new Error("Failed to get cave metrics: Unknown error");
    }
  }

  /**
   * Get all metrics for the current cave.
   *
   * @returns A dictionary containing all metrics for the cave:
   * {
   *   "name": string,
   *   "namespace": string,
   *   "running": boolean,
   *   "cpu_usage": number | null,
   *   "memory_usage": number | null,
   *   "disk_usage": number | null
   * }
   *
   * @throws Error if the cave is not started or if the request fails
   */
  async all(): Promise<any> {
    return await this.getMetrics();
  }

  /**
   * Get CPU usage percentage for the current cave.
   *
   * @returns CPU usage as a percentage (0-100) or undefined if not available.
   * May return 0.0 for idle cavees or when metrics are not precise.
   *
   * @throws Error if the cave is not started or if the request fails
   */
  async cpu(): Promise<number | undefined> {
    const metrics = await this.getMetrics();
    return metrics.cpu_usage;
  }

  /**
   * Get memory usage for the current cave.
   *
   * @returns Memory usage in MiB or undefined if not available
   *
   * @throws Error if the cave is not started or if the request fails
   */
  async memory(): Promise<number | undefined> {
    const metrics = await this.getMetrics();
    return metrics.memory_usage;
  }

  /**
   * Get disk usage for the current cave.
   *
   * @returns Disk usage in bytes or undefined if not available
   *
   * @throws Error if the cave is not started or if the request fails
   */
  async disk(): Promise<number | undefined> {
    const metrics = await this.getMetrics();
    return metrics.disk_usage;
  }

  /**
   * Check if the cave is currently running.
   *
   * @returns True if the cave is running, False otherwise
   *
   * @throws Error if the request to the server fails
   */
  async isRunning(): Promise<boolean> {
    const metrics = await this.getMetrics();
    return metrics.running || false;
  }
}
