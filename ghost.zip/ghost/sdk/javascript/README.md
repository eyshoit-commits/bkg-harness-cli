# ghost JavaScript/TypeScript SDK

A secure, efficient cave for executing untrusted code from TypeScript/JavaScript applications.

## Installation

```sh
npm install ghost
```

## Requirements

- Node.js 14.x or later
- A running ghost server with a valid API key

## Configuration

Before using the SDK, you need to set your ghost API key:

```sh
export GST_API_KEY=gst_***
```

## Quick Start

Here's a simple example using the NodeCave to execute JavaScript code:

```typescript
import { NodeCave } from "ghost";

async function main() {
  // Create and start a Node.js cave
  const cave = await NodeCave.create({ name: "test" });

  try {
    // Execute JavaScript code in the cave
    let exec = await cave.run("var name = 'JavaScript'");
    exec = await cave.run("console.log(`Hello ${name}!`)");

    // Get the output
    console.log(await exec.output()); // prints Hello JavaScript!
  } finally {
    // Stop the cave when done
    await cave.stop();
  }
}

main().catch(console.error);
```

## Available Cave Types

The SDK provides several specialized cave environments:

- `NodeCave`: For executing JavaScript/TypeScript code
- `PythonCave`: For executing Python code

Each cave type is optimized for its respective language environment.

## Creating a Cave

You can create a cave with custom options:

```typescript
import { NodeCave, CaveOptions } from "ghost";

// Using builder pattern
const options = CaveOptions.builder()
  .name("my-cave")
  .memory(1024)
  .cpus(2)
  .build();

// Create and start the cave
const cave = await NodeCave.create(options);

// Don't forget to stop the cave when done
await cave.stop();
```

## Running Shell Commands

You can execute shell commands in the cave:

```typescript
const cmd = await cave.command.run("ls", ["-la"]);
console.log(await cmd.output());
console.log("Exit code:", cmd.exitCode);
```

## Monitoring Cave Metrics

Get resource usage metrics for your cave:

```typescript
// Get all metrics
const metrics = await cave.metrics.all();
console.log(metrics);

// Get specific metrics
const cpuUsage = await cave.metrics.cpu();
const memoryUsage = await cave.metrics.memory();
const diskUsage = await cave.metrics.disk();
```

## Error Handling

```typescript
try {
  const exec = await cave.run("invalid code");

  if (exec.hasError()) {
    console.error("Execution error:", await exec.error());
  } else {
    console.log("Result:", await exec.output());
  }
} catch (err) {
  console.error("Cave error:", err.message);
}
```

## Development

### Building the SDK

```sh
npm run build
```

### Running Tests

```sh
npm test
```

## License

Apache License 2.0
