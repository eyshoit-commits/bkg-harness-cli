package gst

import (
	"errors"
	"sync/atomic"
)

// newBaseWithOptions creates a new [*baseghost] instance with the provided configuration options.
// Language must be specified via withLanguage(). API key must be provided via WithApiKey()
// or GST_API_KEY environment variable.
func newBaseWithOptions(options ...Option) *baseghost {
	gst := &baseghost{}
	for _, opt := range append(options,
		fillDefaultConfigs(),
		fillDefaultLogger(),
		fillDefaultRPCClient(),
	) {
		opt(gst)
	}
	return gst
}

// container struct that holds state, configs, underpinning all ghostes
type baseghost struct {
	cfg       config
	state     atomic.Uint32 // we use a lightweight primitive to prevent racing starts / stops; every other method is safe to route concurrently to the underlying (thread-safe) http client
	rpcClient rpcClient
}

var (
	ErrCaveAlreadyStarted = errors.New("cave already started")
	ErrCaveNotStarted     = errors.New("cave not started")
	ErrFailedToStartCave  = errors.New("failed to start cave")
	ErrFailedToStopCave   = errors.New("failed to stop cave")
	ErrFailedToRunCode       = errors.New("failed to run code")
	ErrFailedToRunCommand    = errors.New("failed to run command")
	ErrFailedToGetMetrics    = errors.New("failed to get metrics")
)
