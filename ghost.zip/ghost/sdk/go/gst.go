// Package gst provides a Go SDK for interacting with ghost environments.
//
// This SDK provides thread-safe access to running ghost environments for code execution,
// command running, and resource monitoring, without imposing any particular concurrency paradigm.
//
// # Quick Start
//
// Create a Python cave:
//
//	cave := gst.NewPythonCave(gst.WithName("my-cave"))
//	if err := cave.Start("", 512, 1); err != nil {
//		log.Fatal(err)
//	}
//	defer cave.Stop()
//
// Execute Python code:
//
//	execution, err := cave.Code().Run("print('Hello World')")
//	if err != nil {
//		log.Fatal(err)
//	}
//	output, _ := execution.GetOutput()
//	fmt.Println(output)
//
// Run shell commands:
//
//	cmdExec, err := cave.Command().Run("ls", []string{"-la"})
//	if err != nil {
//		log.Fatal(err)
//	}
//
// Monitor resource usage:
//
//	metrics, err := cave.Metrics().All()
//	if err != nil {
//		log.Fatal(err)
//	}
//	fmt.Printf("CPU: %.2f%%, Memory: %d MiB\n", metrics.CPU, metrics.MemoryMiB)
package gst

import (
	"context"
	"encoding/json"
	"fmt"
)

// Core cave interfaces
type (
	// Starter manages cave lifecycle startup.
	Starter interface {
		// Start initializes the cave with the specified configuration.
		// If image is empty, uses the default image for the configured language.
		// If memoryMB <= 0, defaults to 512. If cpus <= 0, defaults to 1.
		Start(image string, memoryMB int, cpus int) error
	}

	// Stopper manages cave lifecycle shutdown.
	Stopper interface {
		// Stop terminates the cave and releases its resources.
		Stop() error
	}

	// CodeRunner executes code in the cave's REPL environment.
	CodeRunner interface {
		// Run executes the provided code and returns detailed execution results.
		// The cave must be started before calling this method.
		Run(code string) (CodeExecution, error)
	}

	// CommandRunner executes shell commands in the cave.
	CommandRunner interface {
		// Run executes a shell command with the given arguments.
		// The cave must be started before calling this method.
		Run(cmd string, args []string) (CommandExecution, error)
	}

	// MetricsReader provides access to cave resource metrics.
	MetricsReader interface {
		// All returns comprehensive metrics for the cave.
		All() (Metrics, error)
		// CPU returns current CPU usage as a percentage (0-100).
		CPU() (float64, error)
		// MemoryMiB returns current memory usage in mebibytes.
		MemoryMiB() (int, error)
		// DiskBytes returns current disk usage in bytes.
		DiskBytes() (int, error)
		// IsRunning reports whether the cave is currently running.
		IsRunning() (bool, error)
	}

	// Metrics contains resource usage information for a cave.
	Metrics struct {
		Name      string  // Cave name
		Namespace string  // Cave namespace
		IsRunning bool    // Whether the cave is currently running
		CPU       float64 // CPU usage percentage (0-100)
		MemoryMiB int     // Memory usage in mebibytes
		DiskBytes int     // Disk usage in bytes
	}
)

// --- API Implementation ---

type starter struct {
	b *baseghost
}

func (s starter) Start(image string, memoryMB int, cpus int) error {
	if s.b.state.Load() == started {
		return ErrCaveAlreadyStarted
	}
	if memoryMB <= 0 {
		memoryMB = 512
	}
	if cpus <= 0 {
		cpus = 1
	}
	err := s.b.rpcClient.startCave(context.Background(), &s.b.cfg, image, memoryMB, cpus)
	if err != nil {
		return fmt.Errorf("%w: %w", ErrFailedToStartCave, err)
	}
	s.b.state.Store(started)
	return nil
}

type stopper struct {
	b *baseghost
}

func (s stopper) Stop() error {
	if s.b.state.Load() == off {
		return ErrCaveNotStarted
	}
	ctx := context.Background()
	err := s.b.rpcClient.stopCave(ctx, &s.b.cfg)
	if err != nil {
		return fmt.Errorf("%w: %w", ErrFailedToStopCave, err)
	}
	s.b.state.Store(off)
	return nil
}

type codeRunner struct {
	b *baseghost
	l progLang
}

func (cr codeRunner) Run(code string) (CodeExecution, error) {
	if cr.b.state.Load() != started {
		return CodeExecution{}, ErrCaveNotStarted
	}
	ctx := context.Background()
	result, err := cr.b.rpcClient.runRepl(ctx, &cr.b.cfg, cr.l, code)
	if err != nil {
		return CodeExecution{}, fmt.Errorf("%w: %w", ErrFailedToRunCode, err)
	}

	exec := CodeExecution{Output: result.output}
	// Parse the output for convenience methods
	if err := json.Unmarshal(result.output, &exec.parsed); err == nil {
		exec.parsedOK = true
	}

	return exec, nil
}

type commandRunner struct {
	b *baseghost
}

func (cr commandRunner) Run(cmd string, args []string) (CommandExecution, error) {
	if cr.b.state.Load() != started {
		return CommandExecution{}, ErrCaveNotStarted
	}
	ctx := context.Background()
	result, err := cr.b.rpcClient.runCommand(ctx, &cr.b.cfg, cmd, args)
	if err != nil {
		return CommandExecution{}, fmt.Errorf("%w: %w", ErrFailedToRunCommand, err)
	}

	exec := CommandExecution{Output: result.output}
	// Parse the output for convenience methods
	if err := json.Unmarshal(result.output, &exec.parsed); err == nil {
		exec.parsedOK = true
	}

	return exec, nil
}

type metricsReader struct {
	b *baseghost
}

func (mr metricsReader) All() (Metrics, error) {
	if mr.b.state.Load() != started {
		return Metrics{}, ErrCaveNotStarted
	}

	ctx := context.Background()
	metrics, err := mr.b.rpcClient.getMetrics(ctx, &mr.b.cfg)
	if err != nil {
		return Metrics{}, fmt.Errorf("%w: %w", ErrFailedToGetMetrics, err)
	}

	return Metrics{
		Name:      metrics.Name,
		Namespace: metrics.Namespace,
		IsRunning: metrics.Running,
		CPU:       metrics.CPUUsage,
		MemoryMiB: metrics.MemoryUsage,
		DiskBytes: metrics.DiskUsage,
	}, nil
}

func (mr metricsReader) CPU() (float64, error) {
	metrics, err := mr.All()
	if err != nil {
		return 0, err
	}
	return metrics.CPU, nil
}

func (mr metricsReader) MemoryMiB() (int, error) {
	metrics, err := mr.All()
	if err != nil {
		return 0, err
	}
	return metrics.MemoryMiB, nil
}

func (mr metricsReader) DiskBytes() (int, error) {
	metrics, err := mr.All()
	if err != nil {
		return 0, err
	}
	return metrics.DiskBytes, nil
}

func (mr metricsReader) IsRunning() (bool, error) {
	metrics, err := mr.All()
	if err != nil {
		return false, err
	}
	return metrics.IsRunning, nil
}
