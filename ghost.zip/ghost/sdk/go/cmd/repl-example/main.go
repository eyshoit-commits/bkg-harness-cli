package main

import (
	"fmt"
	"log"

	gst "github.com/keithang/ghost/sdk/go"
)

// contextManagerEquivalentExample demonstrates the Go equivalent of Python's context manager pattern.
func contextManagerEquivalentExample() {
	fmt.Println("\n=== Context Manager Equivalent Example ===")

	// Create a cave (equivalent to async with PythonCave.create())
	cave := gst.NewPythonCave(
		gst.WithName("cave-cm"),
	)

	// Start the cave
	if err := cave.Start("", 512, 1); err != nil {
		log.Fatalf("Failed to start cave: %v", err)
	}
	// Use defer for automatic cleanup (Go's equivalent of context manager)
	defer func() {
		if err := cave.Stop(); err != nil {
			log.Printf("Failed to stop cave: %v", err)
		}
	}()

	// Run some computation
	code := `print("Hello, world!")`
	execution, err := cave.Code().Run(code)
	if err != nil {
		log.Fatalf("Failed to run code: %v", err)
	}

	if output, err := execution.GetOutput(); err != nil {
		log.Printf("Failed to get output: %v", err)
	} else {
		fmt.Printf("Output: %s\n", output)
	}
}

// explicitLifecycleExample demonstrates explicit lifecycle management.
func explicitLifecycleExample() {
	fmt.Println("\n=== Explicit Lifecycle Example ===")

	// Create cave with custom configuration
	cave := gst.NewPythonCave(
		gst.WithServerUrl("http://127.0.0.1:5555"),
		gst.WithName("cave-explicit"),
	)

	// Start with resource constraints
	if err := cave.Start("", 1024, 2); err != nil { // 1GB RAM, 2 CPU cores
		log.Fatalf("Failed to start cave: %v", err)
	}

	// Manual cleanup without defer (for demonstration)
	var stopErr error
	defer func() {
		if stopErr != nil {
			log.Printf("Failed to stop cave: %v", stopErr)
		}
	}()

	// Run multiple code blocks with variable assignments
	if _, err := cave.Code().Run("x = 42"); err != nil {
		log.Fatalf("Failed to set x: %v", err)
	}

	if _, err := cave.Code().Run("y = [i**2 for i in range(10)]"); err != nil {
		log.Fatalf("Failed to set y: %v", err)
	}

	execution3, err := cave.Code().Run("print(f'x = {x}')\nprint(f'y = {y}')")
	if err != nil {
		log.Fatalf("Failed to run final code: %v", err)
	}

	if output, err := execution3.GetOutput(); err != nil {
		log.Printf("Failed to get output: %v", err)
	} else {
		fmt.Printf("Output: %s\n", output)
	}

	// Demonstrate error handling
	errorExecution, err := cave.Code().Run("1/0") // This will raise a ZeroDivisionError
	if err != nil {
		fmt.Printf("Caught error: %v\n", err)
	} else if errorOutput, err := errorExecution.GetError(); err != nil {
		log.Printf("Failed to get error output: %v", err)
	} else {
		fmt.Printf("Error: %s\n", errorOutput)
	}

	// Manual cleanup
	stopErr = cave.Stop()
}

// executionChainingExample demonstrates execution chaining with variables.
func executionChainingExample() {
	fmt.Println("\n=== Execution Chaining Example ===")

	cave := gst.NewPythonCave(
		gst.WithName("cave-chain"),
	)

	if err := cave.Start("", 512, 1); err != nil {
		log.Fatalf("Failed to start cave: %v", err)
	}
	defer func() {
		if err := cave.Stop(); err != nil {
			log.Printf("Failed to stop cave: %v", err)
		}
	}()

	// Execute a sequence of related code blocks
	if _, err := cave.Code().Run("name = 'Python'"); err != nil {
		log.Fatalf("Failed to set name: %v", err)
	}

	if _, err := cave.Code().Run("import sys"); err != nil {
		log.Fatalf("Failed to import sys: %v", err)
	}

	if _, err := cave.Code().Run("version = sys.version"); err != nil {
		log.Fatalf("Failed to set version: %v", err)
	}

	exec, err := cave.Code().Run("print(f'Hello from {name} {version}!')")
	if err != nil {
		log.Fatalf("Failed to run final code: %v", err)
	}

	// Only get output from the final execution
	if output, err := exec.GetOutput(); err != nil {
		log.Printf("Failed to get output: %v", err)
	} else {
		fmt.Printf("Output: %s\n", output)
	}
}

// dataProcessingExample demonstrates more complex data processing scenarios.
func dataProcessingExample() {
	fmt.Println("\n=== Data Processing Example ===")

	cave := gst.NewPythonCave(
		gst.WithName("cave-data"),
	)

	if err := cave.Start("", 1024, 2); err != nil {
		log.Fatalf("Failed to start cave: %v", err)
	}
	defer func() {
		if err := cave.Stop(); err != nil {
			log.Printf("Failed to stop cave: %v", err)
		}
	}()

	// Set up data processing environment
	setupCode := `
import json
import statistics
from collections import Counter

# Sample data
data = [
    {"name": "Alice", "age": 30, "department": "Engineering", "salary": 75000},
    {"name": "Bob", "age": 25, "department": "Marketing", "salary": 60000},
    {"name": "Charlie", "age": 35, "department": "Engineering", "salary": 85000},
    {"name": "Diana", "age": 28, "department": "Sales", "salary": 55000},
    {"name": "Eve", "age": 32, "department": "Engineering", "salary": 80000},
]

print(f"Loaded {len(data)} employee records")
`
	if _, err := cave.Code().Run(setupCode); err != nil {
		log.Fatalf("Failed to run setup code: %v", err)
	}

	// Process the data
	analysisCode := `
# Calculate statistics
ages = [person["age"] for person in data]
salaries = [person["salary"] for person in data]

print(f"Average age: {statistics.mean(ages):.1f}")
print(f"Average salary: ${statistics.mean(salaries):,.0f}")
print(f"Salary range: ${min(salaries):,} - ${max(salaries):,}")

# Department analysis
departments = [person["department"] for person in data]
dept_counts = Counter(departments)
print(f"\\nDepartment distribution:")
for dept, count in dept_counts.items():
    print(f"  {dept}: {count} employees")

# Find highest paid in each department
dept_salaries = {}
for person in data:
    dept = person["department"]
    if dept not in dept_salaries or person["salary"] > dept_salaries[dept]["salary"]:
        dept_salaries[dept] = person

print(f"\\nHighest paid in each department:")
for dept, person in dept_salaries.items():
    print(f"  {dept}: {person['name']} (${person['salary']:,})")
`
	analysisExecution, err := cave.Code().Run(analysisCode)
	if err != nil {
		log.Fatalf("Failed to run analysis code: %v", err)
	}

	if output, err := analysisExecution.GetOutput(); err != nil {
		log.Printf("Failed to get analysis output: %v", err)
	} else {
		fmt.Println(output)
	}
}

// errorRecoveryExample demonstrates error handling and recovery patterns.
func errorRecoveryExample() {
	fmt.Println("\n=== Error Recovery Example ===")

	cave := gst.NewPythonCave(
		gst.WithName("cave-error-recovery"),
	)

	if err := cave.Start("", 512, 1); err != nil {
		log.Fatalf("Failed to start cave: %v", err)
	}
	defer func() {
		if err := cave.Stop(); err != nil {
			log.Printf("Failed to stop cave: %v", err)
		}
	}()

	// Set up some initial state
	if _, err := cave.Code().Run("counter = 0"); err != nil {
		log.Fatalf("Failed to initialize counter: %v", err)
	}

	// Function that will sometimes fail
	setupCode := `
def risky_operation(value):
    global counter
    counter += 1
    if value < 0:
        raise ValueError("Negative values not allowed!")
    if value > 100:
        raise ValueError("Value too large!")
    return value * 2

print("Risky operation function defined")
`
	if _, err := cave.Code().Run(setupCode); err != nil {
		log.Fatalf("Failed to setup risky operation: %v", err)
	}

	// Test with valid input
	validExecution, err := cave.Code().Run(`
result = risky_operation(25)
print(f"Success: risky_operation(25) = {result}")
print(f"Counter is now: {counter}")
`)
	if err != nil {
		log.Printf("Failed to run valid operation: %v", err)
	} else if output, err := validExecution.GetOutput(); err != nil {
		log.Printf("Failed to get valid output: %v", err)
	} else {
		fmt.Println(output)
	}

	// Test with invalid input (should show error but cave continues)
	invalidExecution, err := cave.Code().Run(`
try:
    result = risky_operation(-5)
    print(f"Unexpected success: {result}")
except ValueError as e:
    print(f"Caught expected error: {e}")
    print(f"Counter is now: {counter}")
`)
	if err != nil {
		log.Printf("Failed to run invalid operation: %v", err)
	} else {
		if output, err := invalidExecution.GetOutput(); err != nil {
			log.Printf("Failed to get invalid output: %v", err)
		} else {
			fmt.Println(output)
		}

		if invalidExecution.HasError() {
			if errorOutput, err := invalidExecution.GetError(); err != nil {
				log.Printf("Failed to get error output: %v", err)
			} else {
				fmt.Printf("Error output: %s\n", errorOutput)
			}
		}
	}

	// Verify cave is still functional
	finalExecution, err := cave.Code().Run(`
print(f"Cave is still working! Final counter: {counter}")
print("Error recovery complete")
`)
	if err != nil {
		log.Printf("Failed to run final check: %v", err)
	} else if output, err := finalExecution.GetOutput(); err != nil {
		log.Printf("Failed to get final output: %v", err)
	} else {
		fmt.Println(output)
	}
}

func main() {
	fmt.Println("Python REPL Cave Examples")
	fmt.Println("============================")

	contextManagerEquivalentExample()
	explicitLifecycleExample()
	executionChainingExample()
	dataProcessingExample()
	errorRecoveryExample()

	fmt.Println("\nAll examples completed!")
}

