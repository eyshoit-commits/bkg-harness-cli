package gst

type state = uint32

const (
	off state = iota
	started
)
