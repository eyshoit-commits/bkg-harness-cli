package gst

import "errors"

// LangCave provides a complete cave interface for a specific programming language.
// It combines lifecycle management (Start/Stop) with execution capabilities (Code/Command)
// and monitoring (Metrics) in a single, easy-to-use interface.
//
// Example usage:
//
//	cave := gst.NewPythonCave(gst.WithName("my-cave"))
//	if err := cave.Start("", 512, 1); err != nil {
//		log.Fatal(err)
//	}
//	defer cave.Stop()
//
//	execution, err := cave.Code().Run("print('Hello World')")
//	if err != nil {
//		log.Fatal(err)
//	}
type LangCave interface {
	Starter
	Stopper
	Code() CodeRunner
	Command() CommandRunner
	Metrics() MetricsReader
}

var _ LangCave = (*langCave)(nil)

type langCave struct {
	b *baseghost
	l progLang
}

// NewPythonCave creates a new Python cave instance with the specified configuration options.
// The cave must be started with Start() before executing code or commands.
//
// Example:
//
//	cave := gst.NewPythonCave(
//		gst.WithName("my-python-cave"),
//		gst.WithServerUrl("http://localhost:5555"),
//	)
func NewPythonCave(options ...Option) *langCave {
	return newLangCave(langPython, options...)
}

// NewNodeCave creates a new Node.js cave instance with the specified configuration options.
// The cave must be started with Start() before executing code or commands.
//
// Example:
//
//	cave := gst.NewNodeCave(
//		gst.WithName("my-node-cave"),
//		gst.WithApiKey("your-api-key"),
//	)
func NewNodeCave(options ...Option) *langCave {
	return newLangCave(langNodeJs, options...)
}

func newLangCave(lang progLang, options ...Option) *langCave {
	b := newBaseWithOptions(options...)
	n := &langCave{
		b: b,
		l: lang,
	}
	return n
}

func (ls *langCave) Start(image string, memoryMB int, cpus int) error {
	if image == "" {
		image = ls.l.DefaultImage()
	}
	return starter{ls.b}.Start(image, memoryMB, cpus)
}

func (ls *langCave) Stop() error {
	return stopper{ls.b}.Stop()
}

func (ls *langCave) Code() CodeRunner {
	return codeRunner{ls.b, ls.l}
}

func (ls *langCave) Command() CommandRunner {
	return commandRunner{ls.b}
}

func (ls *langCave) Metrics() MetricsReader {
	return metricsReader{ls.b}
}

type progLang int

const (
	langUnspecified progLang = iota
	langPython
	langNodeJs
)

// String should be the language's corresponding RPC parameter.
func (p progLang) String() string {
	switch p {
	case langPython:
		return "python"
	case langNodeJs:
		return "nodejs"
	default:
		panic(ErrUnknownLanguage)
	}
}

func (p progLang) DefaultImage() string {
	switch p {
	case langPython:
		return "ghost/python"
	case langNodeJs:
		return "ghost/node"
	default:
		panic(ErrUnknownLanguage)
	}
}

// Language-related errors
var (
	ErrUnknownLanguage = errors.New("unknown language")
)
