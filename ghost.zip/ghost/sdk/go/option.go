package gst

import (
	"crypto/rand"
	"errors"
	"fmt"
	"net/http"
	"os"
)

// Option configures a cave during creation.
// Options are applied in the order they are provided to NewPythonCave or NewNodeCave.
type Option func(*baseghost)

// WithServerUrl configures the ghost server URL.
// If not specified, defaults to GST_SERVER_URL environment variable or http://127.0.0.1:5555.
func WithServerUrl(serverUrl string) Option {
	return func(gst *baseghost) {
		gst.cfg.serverUrl = serverUrl
	}
}

// WithNamespace configures the cave namespace for isolation.
// If not specified, uses the default namespace.
func WithNamespace(namespace string) Option {
	return func(gst *baseghost) {
		gst.cfg.namespace = namespace
	}
}

// WithName sets a custom name for the cave instance.
// If not specified, a random name will be generated.
func WithName(name string) Option {
	return func(gst *baseghost) {
		gst.cfg.name = name
	}
}

// WithApiKey configures the API key for server authentication.
// If not specified, uses the GST_API_KEY environment variable.
func WithApiKey(apiKey string) Option {
	return func(gst *baseghost) {
		gst.cfg.apiKey = apiKey
	}
}

// WithLogger configures a custom logger for the cave.
// If not specified, uses a no-op logger that discards all log output.
func WithLogger(logger Logger) Option {
	return func(gst *baseghost) {
		gst.cfg.logger = logger
	}
}

// WithReqIdProducer configures a custom request ID generator for tracing.
// Request IDs are included in logs and can help with debugging.
func WithReqIdProducer(reqIdPrd ReqIdProducer) Option {
	return func(gst *baseghost) {
		gst.cfg.reqIDPrd = reqIdPrd
	}
}

// WithHTTPClient configures a custom HTTP client for server communication.
// Useful for setting timeouts, proxies, or other HTTP-level configuration.
func WithHTTPClient(c *http.Client) Option {
	return func(gst *baseghost) {
		gst.rpcClient = newJsonRPCHTTPClient(c)
	}
}

// --- internal constructor operations ---

func fillDefaultConfigs() Option {
	return func(gst *baseghost) {
		if gst.cfg.serverUrl == "" {
			if envUrl := os.Getenv("GST_SERVER_URL"); envUrl != "" {
				gst.cfg.serverUrl = envUrl
			} else {
				gst.cfg.serverUrl = defaultServerUrl
			}
		}
		if gst.cfg.namespace == "" {
			gst.cfg.namespace = defaultNamespace
		}
		if gst.cfg.name == "" {
			b := make([]byte, 4) // 4 bytes == 8 hex chars
			if _, err := rand.Read(b); err != nil {
				panic(fmt.Errorf("%w: %w", ErrFailedToGenerateRandomName, err))
			}
			gst.cfg.name = fmt.Sprintf(defaultNameTemplate, b)
		}
		if gst.cfg.apiKey == "" {
			if envApiKey := os.Getenv("GST_API_KEY"); envApiKey != "" {
				gst.cfg.apiKey = envApiKey
			} else {
				panic(ErrAPIKeyMustBeSpecified)
			}
		}
	}
}

func fillDefaultLogger() Option {
	return func(gst *baseghost) {
		if gst.cfg.logger == nil {
			gst.cfg.logger = NoOpLogger{}
		}
	}
}

func fillDefaultRPCClient() Option {
	return func(gst *baseghost) {
		if gst.rpcClient == nil {
			gst.rpcClient = newDefaultJsonRPCHTTPClient()
		}
	}
}

// Option-related errors
var (
	ErrLanguageMustBeSpecified    = errors.New("language must be specified")
	ErrFailedToGenerateRandomName = errors.New("failed to generate random name")
	ErrAPIKeyMustBeSpecified      = errors.New("API key must be specified either via WithApiKey() or GST_API_KEY environment variable")
)
