module github.com/keithang/ghost/sdk/go

go 1.24
