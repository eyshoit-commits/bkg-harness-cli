using System;
using Xunit;
using ghost;

namespace ghost.Tests
{
    public class HelloWorldTests
    {
        [Fact]
        public void Greet_ReturnsCorrectMessage()
        {
            // Arrange & Act
            var result = HelloWorld.Greet("Test");

            // Assert
            Assert.Contains("Hello, Test!", result);
        }
    }
}
