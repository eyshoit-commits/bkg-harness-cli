using System;

namespace ghost
{
    /// <summary>
    /// Core class for the ghost SDK.
    /// </summary>
    public class ghost
    {
        /// <summary>
        /// Gets the version of the ghost SDK.
        /// </summary>
        /// <returns>The version of the SDK</returns>
        public static string GetVersion()
        {
            // This should be updated whenever the SDK version changes
            return "0.1.0";
        }

        /// <summary>
        /// Initializes a new instance of the ghost SDK.
        /// </summary>
        public ghost()
        {
            // Initialization logic will go here
            Console.WriteLine("ghost SDK initialized");
        }
    }
}
