using System;

namespace ghost
{
    /// <summary>
    /// Hello World class for the ghost SDK.
    /// </summary>
    public static class HelloWorld
    {
        /// <summary>
        /// Returns a greeting message for the given name.
        /// </summary>
        /// <param name="name">The name to greet</param>
        /// <returns>A greeting message</returns>
        public static string Greet(string name)
        {
            var message = $"Hello, {name}! Welcome to ghost!";
            Console.WriteLine(message);
            return message;
        }
    }
}
