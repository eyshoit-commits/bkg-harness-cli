# ghost C# SDK

A minimal C# SDK for the ghost project.

## Installation

```bash
dotnet add package ghost
```

Or via the NuGet Package Manager:

```bash
Install-Package ghost
```

## Usage

```csharp
using ghost;

// Print a greeting
HelloWorld.Greet("World");
```

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)
