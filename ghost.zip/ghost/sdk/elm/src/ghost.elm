module ghost exposing (greet)

{-| A minimal SDK for the ghost project.

# Functions
@docs greet

-}

import Html exposing (Html, text)


{-| Returns a greeting message for the given name.

    greet "World" -- Returns a text node with "Hello, World! Welcome to ghost!"

-}
greet : String -> Html msg
greet name =
    text <| "Hello, " ++ name ++ "! Welcome to ghost!"
