#import "GSTGreeter.h"

@implementation GSTGreeter

+ (NSString *)greet:(NSString *)name {
    NSString *message = [NSString stringWithFormat:@"Hello, %@! Welcome to ghost!", name];
    NSLog(@"%@", message);
    return message;
}

@end
