Pod::Spec.new do |s|
  s.name         = "ghost"
  s.version      = "0.1.0"
  s.summary      = "A minimal Objective-C SDK for the ghost project"
  s.description  = <<-DESC
                   A minimal Objective-C SDK for the ghost project.
                   This SDK provides a simple greeting functionality.
                   DESC
  s.homepage     = "https://github.com/ghost/ghost"
  s.license      = { :type => "Apache-2.0", :file => "LICENSE" }
  s.author       = { "ghost Team" => "team@ghost.dev" }
  s.platform     = :ios, "12.0"
  s.source       = { :git => "https://github.com/ghost/ghost.git", :tag => "#{s.version}" }
  s.source_files = "sdk/objc/ghost/**/*.{h,m}"
  s.public_header_files = "sdk/objc/ghost/**/*.h"
  s.requires_arc = true
end
