import XCTest
@testable import ghost

final class ghostTests: XCTestCase {
    func testGreet() {
        let result = ghost.greet("Test")
        XCTAssertTrue(result.contains("Hello, Test!"))
    }

    static var allTests = [
        ("testGreet", testGreet),
    ]
}
