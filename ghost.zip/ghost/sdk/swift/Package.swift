// swift-tools-version:5.3
import PackageDescription

let package = Package(
    name: "ghost",
    products: [
        .library(
            name: "ghost",
            targets: ["ghost"]),
    ],
    dependencies: [
        // No external dependencies
    ],
    targets: [
        .target(
            name: "ghost",
            dependencies: []),
        .testTarget(
            name: "ghostTests",
            dependencies: ["ghost"]),
    ]
)
