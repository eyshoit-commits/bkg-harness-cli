pub const version = "0.1.0";
pub const authors = "ghost Team <team@ghost.dev>";
pub const license = "Apache-2.0";
pub const repository = "https://github.com/ghost/ghost";
pub const website = "https://ghost.dev";

pub const metadata = struct {
    pub const name = "ghost";
    pub const description = "A minimal Zig SDK for the ghost project";
};
