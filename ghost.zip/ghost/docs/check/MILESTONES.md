# MILESTONES — Stand: 2026-09-17_173303

Letzter Check: CHECK_2026-09-17_173303.md

| Milestone | Name                                  | Status | Abhängigkeit | Nachweis |
|-----------|---------------------------------------|--------|-------------|---------|
| M1        | libkrun Build-System einrichten       | TODO   | —           | —       |
| M2        | Server startet + Health-Check         | TODO   | M1          | —       |
| M3        | cave.start / cave.stop E2E (microVM)  | TODO   | M2          | —       |
| M4        | MCP-Integration verifizieren          | TODO   | M3          | —       |

## Nächster ausführbarer Milestone
M1 — libkrun Build-System einrichten

## Blocker
- libkrun-Bibliothek (`build/libkrun.so` / `build/libkrun.dylib`) fehlt auf dem aktuellen System
- Ohne libkrun kann kein Cargo-Build des Workspace durchgeführt werden (ghost-core linkt gegen libkrun)
- `./scripts/build_libkrun.sh` muss erfolgreich ausgeführt werden (benötigt Systemabhängigkeiten: gcc, make, Python, evt. KVM)
