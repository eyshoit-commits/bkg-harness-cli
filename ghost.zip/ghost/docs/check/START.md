# START — Ghost

> Letzter Check: CHECK_2026-09-17_173303.md
> Stand: 2026-09-17

## Projekt
**Name:** Ghost (ehemals "ghost" / gst)  
**Zweck:** Secure Execution Environment für untrusted Code — isolierte microVMs mit <200ms Boot-Zeit, OCI-kompatibel, AI-ready (MCP-Support), self-hosted  
**Domain:** MicroVM-Runtime, Code-Execution-Sandbox, AI-Tooling  
**Version:** 0.2.6  
**Sprachen:** Rust (Kern), Python/JS/TS/Go/… (SDKs)

## Scope
- `ghost-core/` — MicroVM-Runtime-Bibliothek (libkrun FFI, OCI-Pull, cave-Lifecycle, SQLite-DB)
- `ghost-server/` — Axum HTTP-Server (JSON-RPC API, MCP-Endpoint, Admin-UI)
- `ghost-portal/` — Portal-Prozess (läuft IN der microVM, REPL + Command Execution)
- `ghost-cli/` — CLI-Binaries (`gst`, `gstrun`, `gstserver`)
- `ghost-utils/` — Hilfsfunktionen
- `sdk/` — Client-SDKs (Python, JS, Rust, Go, +23 weitere)
- `docs/` — Retype-Dokumentation

## Aktueller Milestone
M1 — libkrun Build-System einrichten

## Milestone-Status
BLOCKED

## Aktueller Blocker
**libkrun-Bibliothek fehlt** auf dem aktuellen System.  
`build/libkrun.so` (Linux) / `build/libkrun.dylib` (macOS) nicht vorhanden.  
`cargo build --workspace` scheitert am Linker (ghost-core linkt gegen `libkrun`).

**Auflösung:**
```bash
cd /srv/bkg/workspace/artifacts/ghost
./scripts/build_libkrun.sh --no-clean
cargo build --workspace
```

## Aktuelle Tasks
→ siehe NEXT_TASKS.md

## Out-of-Scope
- `INTEGRATION_TODO.md` (v0.2a-Integration): Semantic-Store, AI-Server, TypeScript-Apps, .ghost-Format — kein bestätigter Scope für aktuellen Milestone
- Proxy-Handler-Stub (`proxy_request`, `proxy_uri`) — kein aktiver Use-Case
- Externe CI/CD-Pipeline-Einrichtung

## Definition of Done (aktueller Milestone)
- `./scripts/build_libkrun.sh --no-clean` fehlerfrei
- `cargo build --workspace` kompiliert ohne Fehler
- `build/gstserver --help` gibt Ausgabe (Binary ausführbar)
- kein "Build grün" allein — Runtime-Ausführbarkeit muss bestätigt sein

## Verweise
- Milestones:  docs/check/MILESTONES.md
- Next Tasks:  docs/check/NEXT_TASKS.md
- Tasks:       docs/TASKS.md
- Letzter Check: docs/check/CHECK_2026-09-17_173303.md
