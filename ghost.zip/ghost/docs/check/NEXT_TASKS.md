# NEXT_TASKS — Stand: 2026-09-17_173303

Aktueller Milestone: M1 — libkrun Build-System einrichten
Status: BLOCKED

## Blocker
libkrun-Bibliothek fehlt auf dem aktuellen System.  
`build/libkrun.so` (Linux) bzw. `build/libkrun.dylib` (macOS) ist nicht vorhanden.  
Ohne diese Bibliothek scheitert `cargo build --workspace` mit einem Linker-Fehler.

## Nächster möglicher Schritt
Systemabhängigkeiten für libkrun prüfen und Build-Script ausführen:

```bash
# Systemabhängigkeiten prüfen (Linux)
# Benötigt: gcc, make, python3, musl-tools, libkrun build-deps
# Optional: KVM-Support für tatsächliche microVM-Ausführung

# Build starten
cd /srv/bkg/workspace/artifacts/ghost
./scripts/build_libkrun.sh --no-clean

# Dann Workspace bauen
cargo build --workspace
```

## Nicht in diesem Milestone
| Milestone | Name                                  | Status |
|-----------|---------------------------------------|--------|
| M2        | Server startet + Health-Check         | TODO   |
| M3        | cave.start / cave.stop E2E (microVM)  | TODO   |
| M4        | MCP-Integration verifizieren          | TODO   |

## Definition of Done für M1
- [ ] `./scripts/build_libkrun.sh --no-clean` läuft fehlerfrei durch
- [ ] `build/libkrun.so` (Linux) oder `build/libkrun.dylib` (macOS) existiert
- [ ] `cargo build --workspace` kompiliert ohne Fehler
- [ ] `build/gstserver` Binary existiert und ist ausführbar
- [ ] Tatsächlicher Ausführungstest: `./build/gstserver --help` gibt Hilfetext zurück (kein Linker-Error)
- [ ] Kein reines "Build grün" — Binary muss ausführbar sein und Ausgabe produzieren
