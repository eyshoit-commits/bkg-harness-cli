---
order: 1010
icon: tasklist
tags: [status]
---

# Readiness Comparison

This page tracks readiness signals for the two active codebases referenced by the team request: the main `ghost` repository (tagged upstream as `ghost_v0.1.2.3a`) and the `ghost-coding-cave` workspace (latest accessible snapshot: `ghost-coding-cave-v0.2a`, covering the "Phase F" workstream referenced as `ghost-coding-cave-v0.2a-0.3-develop`).

> [!NOTE]
> The workspace name `ghost-coding-cave-v0.2a-0.3-develop` does not exist as a directory in the repo snapshot. The current material matches the `ghost-coding-cave-v0.2a` tree and its Phase F status notes. All findings below reference that checked-in state.

## Snapshot Summary

| Area | `ghost` (v0.1.2.3a) | `ghost-coding-cave-v0.2a` (Phase F) |
| --- | --- | --- |
| Platform Support | macOS & Linux flows documented; Windows flagged as WIP | All core services (Rust gateway, AI server, storage, semantic adapters) compile and run |
| Testing | No central test report in docs; positioning still "beta" | 20/20 automated tests passing across Rust + integration suites |
| Documentation | Introductory docs plus self-hosting guide; overall product labelled beta | 18+ docs, quick-start guides, architecture notes, Phase 2 roadmap |
| Production Readiness | Explicitly not production-ready | Phase 1 marked complete and production-ready for core services; UI & dashboard pending |

## `ghost` (v0.1.2.3a)

### Ready

- Getting-started experience documented (CLI install, server startup, SDK usage).@README.md#81-128
- macOS and Linux flows marked as working for current SDK preview builds.@README.md#73-77
- Self-hosting guide covers CLI install, server lifecycle, image pulls, and key management.@SELF_HOSTING.md#1-76

### Not Yet Ready / Gaps

- Windows support is still marked as "WIP" in the primary README, signalling an incomplete cross-platform story.@README.md#73-77
- Project documentation labels the software as "beta" and "not ready for production use".@PROJECTS.md#1-7
- No consolidated status or test-report artifact inside `docs/`; readiness must be inferred from marketing material. (No explicit counter-document located.)

## `ghost-coding-cave-v0.2a` (Phase F reference)

### Ready

- Phases A–E are complete, covering Rust workspace scaffolding, storage and semantic adapters, gateway integrations, security hardening, documentation, and DevOps pipelines.@STATUS.md#3-38
- Final status report confirms Phase 1 completion with all services compiling, 20/20 tests passing, and extensive documentation produced (18+ files).@FINAL_STATUS.md#8-169
- Production readiness artifacts (deployment, security, ops) and monitoring guidance are documented under `docs/` within the workspace.@PRODUCTION_READINESS.md#1-200

### Not Yet Ready / Gaps

- Phase F (Helper integration & UI upgrade) remains in progress; UI/API deliverables and certain documentation updates are pending.@STATUS.md#40-48
- Remaining TODOs include streaming improvements, expanded capsule operations, and dashboard wiring for semantic-store APIs.@STATUS.md#49-54
- Dashboard (Next.js) and NestJS API are compiled but not yet running per the latest status report.@FINAL_STATUS.md#70-78

## Recommendations

1. Publish an explicit readiness tracker for the main `ghost` repo to surface platform coverage, automated test status, and production gating items.
2. Align naming (`ghost-coding-cave-v0.2a-0.3-develop` vs actual filesystem path) to avoid onboarding confusion; consider adding a symlink or README alias.
3. Prioritise closing the Phase F gaps (UI, dashboard wiring, streaming) before advertising a 0.3 develop milestone, and keep the status file updated as those items land.
