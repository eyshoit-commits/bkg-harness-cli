# TASKS — Ghost

> Stand: CHECK_2026-09-17_173303.md

---

## M1 — libkrun Build-System einrichten [BLOCKED]

> Abhängigkeit: —  
> Blocker: libkrun-Bibliothek fehlt auf dem aktuellen System

- [ ] Systemabhängigkeiten für libkrun prüfen (gcc, make, python3, KVM-Support)
- [ ] `./scripts/build_libkrun.sh --no-clean` ausführen
- [ ] Prüfen: `build/libkrun.so` (Linux) / `build/libkrun.dylib` (macOS) existiert
- [ ] `cargo build --workspace` erfolgreich durchführen
- [ ] Prüfen: `build/gstserver`, `build/gst`, `build/gstrun` existieren und sind ausführbar
- [ ] `./build/gstserver --help` gibt Hilfetext (kein Linker-Error)

---

## M2 — Server startet + Health-Check [TODO]

> Abhängigkeit: M1

- [ ] `./build/gstserver --dev-mode` starten (ohne JWT-Auth)
- [ ] `curl http://localhost:8080/api/v1/health` → `{"message":"Service is healthy"}` verifizieren
- [ ] Admin-Seite `http://localhost:8080/admin` erreichbar (HTTP 200)
- [ ] Default-Admin-Credentials aus Server-Log auslesen
- [ ] Admin-Login erfolgreich (Session-Cookie erhalten)
- [ ] `/admin/api/overview` gibt erwartete JSON-Struktur zurück

---

## M3 — cave.start / cave.stop E2E (microVM) [TODO]

> Abhängigkeit: M2

- [ ] API-Key via Admin-UI generieren (Label + Namespace)
- [ ] `cave.start` JSON-RPC mit Image `ghost/python` aufrufen
- [ ] Bestätigen: microVM tatsächlich gestartet (orchestra::up ohne Fehler)
- [ ] `cave.metrics.get` für laufende cave aufrufen — `running: true` im Response
- [ ] `cave.repl.run` mit Python-Code aufrufen (via Portal-Forwarding)
- [ ] `cave.command.run` mit Shell-Kommando aufrufen (via Portal-Forwarding)
- [ ] `cave.stop` aufrufen
- [ ] `cave.metrics.get` nach Stop — `running: false` verifizieren
- [ ] Port wird korrekt freigegeben (PortManager)

---

## M4 — MCP-Integration verifizieren [TODO]

> Abhängigkeit: M3

- [ ] MCP `initialize` Request → `protocolVersion: "2024-11-05"` im Response
- [ ] MCP `tools/list` → Liste mit `cave_start`, `cave_stop`, `cave_metrics_get`, `cave_run_code`
- [ ] MCP `tools/call` mit `cave_start` über API-Key authentifiziert
- [ ] Voller Round-Trip: MCP `cave_start` → microVM läuft → MCP `cave_stop`
- [ ] Namespace-Validierung: Token mit Namespace A darf nicht auf Namespace B zugreifen

---

## Erkannte Lücken (kein Scope)

- `proxy_request` / `proxy_uri` Stub — kein echter HTTP-Reverse-Proxy implementiert
- INTEGRATION_TODO.md: Semantic-Store (ss-core etc.) — nicht übertragen, 0% Fortschritt
- INTEGRATION_TODO.md: AI-Server (Port 5001) — nicht übertragen
- INTEGRATION_TODO.md: .ghost Format (SHA3-256 + TAR+zstd) — nicht implementiert
- INTEGRATION_TODO.md: TypeScript Apps (NestJS API + Next.js Dashboard) — nicht übertragen
- INTEGRATION_TODO.md: CI/CD GitHub Actions — nicht eingerichtet
- Keine Streaming-Antworten für cave.repl.run (nur synchron/blocking)
- Wildcard-Namespace `*` im Token: cave.start/stop haben eigene Validierung, aber metrics.get erlaubt `*` — inkonsistent
