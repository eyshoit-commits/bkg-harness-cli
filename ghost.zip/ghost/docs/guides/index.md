---
order: 100
# icon: book-24
expanded: true
tags: [guides]
---

# GUIDES

Essential guides to get you started with ghost.

## Guide Documentation

:icon-rocket: [Getting Started](getting-started.md) - Get up and running with ghost

:icon-container: [Cavees](cavees.md) - Understanding cave environments

:icon-key: [API Keys](api-keys.md) - Managing API keys and authentication

:icon-plug: [MCP](mcp.md) - Model Context Protocol integration

:icon-project: [Projects](projects.md) - Working with projects

:icon-browser: [Admin Web UI](admin-webui.md) - Browser-based control panel for cave operations

:icon-organization: [Architecture](architecture.md) - System architecture overview
