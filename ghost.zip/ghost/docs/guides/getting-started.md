---
order: 100
icon: rocket
tags: [guide]
---

# Getting Started

This guide will help you get up and running with secure code execution in minutes.

!!!info **Platform-specific requirements:**

- **macOS** — Requires Apple Silicon (M1/M2/M3/M4). Intel-based Macs are not currently supported due to virtualization requirements.
- **Linux** — KVM virtualization must be enabled. Most modern Linux distributions support this. You can check if KVM is available by running `lsmod | grep kvm`.
- **Windows** — [Coming soon!](https://github.com/ghost/ghost/issues/47)
  !!!

---

### Installation

#### Step 1: Install ghost

The easiest way to install ghost is using our installation script:

```bash
curl -sSL https://get.ghost.dev | sh
```

This will download and install the `gst` command-line tool on your system.

#### Step 2: Start the Server

Start the ghost server in development mode:

```bash
gst server start --dev
```

!!!info MCP Server
The ghost server is also an [MCP server](https://modelcontextprotocol.io), which means it works directly with Claude and other MCP-enabled AI tools out of the box!

[!ref See how to use ghost as an MCP server](/guides/mcp)
!!!

---

### Your First Cave

ghost provides SDKs for multiple programming languages. Choose your preferred language below:

+++ Python
Install the Python SDK:

```bash
pip install ghost
```

Create your first cave:

```python
import asyncio
from ghost import PythonCave

async def main():
    async with PythonCave.create(name="my-first-cave") as cave:
        # Execute some Python code
        exec = await cave.run("name = 'World'")
        exec = await cave.run("print(f'Hello {name}!')")

        # Get the output
        output = await exec.output()
        print(output)  # prints: Hello World!

asyncio.run(main())
```

+++ JavaScript
Install the JavaScript SDK:

```bash
npm install ghost
```

Create your first cave:

```javascript
import { NodeCave } from "ghost";

async function main() {
  const cave = await NodeCave.create({ name: "my-first-cave" });

  try {
    // Execute some JavaScript code
    let exec = await cave.run("var name = 'World'");
    exec = await cave.run("console.log(`Hello ${name}!`)");

    // Get the output
    const output = await exec.output();
    console.log(output); // prints: Hello World!
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

+++ Rust
Add ghost to your `Cargo.toml`:

```bash
cargo add ghost
```

Create your first cave:

```rust
use ghost::{CaveOptions, PythonCave};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut cave = PythonCave::create(
        CaveOptions::builder()
            .name("my-first-cave")
            .build()
    ).await?;

    // Execute some Python code
    let exec = cave.run(r#"name = "World""#).await?;
    let exec = cave.run(r#"print(f"Hello {name}!")"#).await?;

    // Get the output
    let output = exec.output().await?;
    println!("{}", output); // prints: Hello World!

    cave.stop().await?;
    Ok(())
}
```

+++

!!!success Congratulations!
You've successfully created and executed code in your first ghost! The code ran in a completely isolated microVM, protecting your system while providing full execution capabilities.
!!!

---

### Quick Examples

Here are some quick examples to get you started with common use cases:

#### Execute Commands in Cave

+++ Python

```python
import asyncio
from ghost import PythonCave

async def main():
    async with PythonCave.create(name="command-test") as cave:
        # Run shell commands
        result = await cave.command.run("ls", ["-la", "/"])
        print("Directory listing:")
        print(await result.output())

        # Create and execute a script
        await cave.run("""
with open("test.py", "w") as f:
    f.write("print('Hello from cave!')")
        """)

        result = await cave.command.run("python", ["test.py"])
        print("Script output:")
        print(await result.output())

asyncio.run(main())
```

+++ JavaScript

```javascript
import { PythonCave } from "ghost";

async function main() {
  const cave = await PythonCave.create({ name: "command-test" });

  try {
    // Run shell commands
    const result = await cave.command.run("ls", ["-la", "/"]);
    console.log("Directory listing:");
    console.log(await result.output());

    // Create and execute a script
    await cave.run(`
with open("test.py", "w") as f:
    f.write("print('Hello from cave!')")
    `);

    const scriptResult = await cave.command.run("python", ["test.py"]);
    console.log("Script output:");
    console.log(await scriptResult.output());
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

+++ Rust

```rust
use ghost::{BaseCave, PythonCave};
use std::error::Error;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error + Send + Sync>> {
    let mut cave = PythonCave::create("command-test").await?;
    cave.start(None).await?;

    let cmd = cave.command().await?;

    // Run shell commands
    let result = cmd.run("ls", Some(vec!["-la", "/"]), None).await?;
    println!("Directory listing:");
    println!("{}", result.output().await?);

    // Create and execute a script
    cave.run(r#"
with open("test.py", "w") as f:
    f.write("print('Hello from cave!')")
"#, None).await?;

    let script_result = cmd.run("python", Some(vec!["test.py"]), None).await?;
    println!("Script output:");
    println!("{}", script_result.output().await?);

    cave.stop().await?;
    Ok(())
}
```

+++

#### Create and Run Bash Scripts

+++ Python

```python
import asyncio
from textwrap import dedent
from ghost import PythonCave

async def main():
    async with PythonCave.create(name="bash-test") as cave:
        # Create and run a bash script
        await cave.run(
            dedent("""
            with open("hello.sh", "w") as f:
                f.write("#!/bin/bash\\n")
                f.write("echo Hello World\\n")
                f.write("date\\n")
        """)
        )

        # Execute the script
        result = await cave.command.run("bash", ["hello.sh"])
        print("Script output:")
        print(await result.output())

asyncio.run(main())
```

+++ JavaScript

```javascript
import { PythonCave } from "ghost";

async function main() {
  const cave = await PythonCave.create({ name: "bash-test" });

  try {
    // Create and run a bash script
    await cave.run(`
with open("hello.sh", "w") as f:
    f.write("#!/bin/bash\\n")
    f.write("echo Hello World\\n")
    f.write("date\\n")
    `);

    // Execute the script
    const result = await cave.command.run("bash", ["hello.sh"]);
    console.log("Script output:");
    console.log(await result.output());
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

+++ Rust

```rust
use ghost::{BaseCave, PythonCave};
use std::error::Error;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error + Send + Sync>> {
    let mut cave = PythonCave::create("bash-test").await?;
    cave.start(None).await?;

    // Create and run a bash script
    cave.run(r#"
with open("hello.sh", "w") as f:
    f.write("#!/bin/bash\n")
    f.write("echo Hello World\n")
    f.write("date\n")
"#, None).await?;

    // Execute the script
    let cmd = cave.command().await?;
    let result = cmd.run("bash", Some(vec!["hello.sh"]), None).await?;
    println!("Script output:");
    println!("{}", result.output().await?);

    cave.stop().await?;
    Ok(())
}
```

+++

---

### Troubleshooting

#### First Run Takes Long

The first time you create a cave, ghost needs to download the base images. This is normal and subsequent runs will be much faster.

#### Server Won't Start

Check that no other services are using the default ports. You can specify custom ports with:

```bash
gst server start --dev --port 8080
```
