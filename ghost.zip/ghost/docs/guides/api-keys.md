---
order: 75
icon: key
tags: [guide]
---

# API Keys

Learn how to generate, manage, and use API keys for authenticating with the ghost server.

---

### Overview

API keys provide secure authentication for accessing the ghost server. They are required for all API operations unless the server is running in development mode.

---

### Generating API Keys

#### Basic Key Generation

Generate a new API key with default settings:

```bash
gst server keygen
```

This creates an API key with:
- **No expiration** (permanent until manually revoked)
- **Global access** to all namespaces
- **Full permissions** for all cave operations

#### Key with Expiration

Generate an API key that expires after a specific duration:

```bash
gst server keygen --expire 3mo
```

**Supported Duration Formats:**
- `s` - seconds (e.g., `30s`)
- `m` - minutes (e.g., `15m`)
- `h` - hours (e.g., `24h`)
- `d` - days (e.g., `7d`)
- `w` - weeks (e.g., `2w`)
- `mo` - months (e.g., `3mo`)
- `y` - years (e.g., `1y`)

**Examples:**
```bash
# Expires in 1 hour
gst server keygen --expire 1h

# Expires in 7 days
gst server keygen --expire 7d

# Expires in 6 months
gst server keygen --expire 6mo
```

#### Namespace-Specific Keys

Generate an API key limited to a specific namespace:

```bash
gst server keygen --namespace team-alpha
```

This key will only have access to cavees running in the `team-alpha` namespace.

#### Combined Options

Generate a namespace-specific key with expiration:

```bash
gst server keygen --expire 1w --namespace project-web
```

---

### Using API Keys

#### Environment Variable (Recommended)

Set the API key as an environment variable:

```bash
export GST_API_KEY="your-api-key-here"
```

Add this to a `.env` file for persistence:

```bash
echo 'GST_API_KEY="your-api-key-here"' >> .env
```

#### SDK Configuration

**Python SDK:**
```python
from ghost import PythonCave

# Using environment variable (recommended)
async with PythonCave.create(name="my-cave") as cave:
    # API key automatically loaded from GST_API_KEY
    pass

# Explicit API key
async with PythonCave.create(
    name="my-cave",
    api_key="your-api-key-here"
) as cave:
    pass
```

**TypeScript SDK:**
```typescript
import { NodeCave } from 'ghost';

// Using environment variable (recommended)
const cave = await NodeCave.create({
  name: 'my-cave'
  // API key automatically loaded from GST_API_KEY
});

// Explicit API key
const cave = await NodeCave.create({
  name: 'my-cave',
  apiKey: 'your-api-key-here'
});
```

#### HTTP API Requests

Include the API key in the Authorization header:

```bash
curl -X POST http://127.0.0.1:5555/api/v1/rpc \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-api-key-here" \
  -d '{
    "jsonrpc": "2.0",
    "method": "cave.start",
    "params": {
      "cave": "my-env",
      "namespace": "default"
    },
    "id": "1"
  }'
```

---

### Development Mode

For development and testing, you can skip API key requirements:

```bash
gst server start --dev
```

**Development Mode Features:**
- **No authentication** required
- **Faster setup** for local development
- **All operations** permitted without API keys

!!!warning Development Mode Security
Development mode should **never** be used in production environments as it disables all authentication and security measures.
!!!

---

### Key Management

#### Checking Server Status

Verify if the server requires authentication:

```bash
gst server status
```

#### Regenerating Keys

To generate a new API key (previous keys remain valid):

```bash
gst server keygen --expire 30d
```

#### Resetting Server Key

To invalidate all existing API keys and generate a new server key:

```bash
gst server start --reset-key
```

This will:
- **Invalidate all** existing API keys
- **Generate a new** server signing key
- **Require new** API key generation

---

### Security Best Practices

!!!success Recommended Practices

1. **Use expiring keys** - Set reasonable expiration times for enhanced security
2. **Namespace isolation** - Use namespace-specific keys to limit access scope
3. **Environment variables** - Store keys in environment variables, not in code
4. **Regular rotation** - Regenerate keys periodically, especially for long-running services
5. **Secure storage** - Never commit API keys to version control or logs
6. **Monitor usage** - Track API key usage and revoke unused or compromised keys
7. **Principle of least privilege** - Generate keys with minimal required permissions
8. **Secure transmission** - Always use HTTPS in production environments
!!!

!!!danger Production Security

- **Never use development mode** (`--dev`) in production environments
- **Always require authentication** for production deployments
- **Use TLS/SSL** for all API communications in production
- **Implement network security** (firewalls, VPNs) for additional protection
- **Regular security audits** of API key usage and access patterns

!!!
