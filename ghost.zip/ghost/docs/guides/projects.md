---
order: 60
icon: project
tags: [guide]
---

# Projects

Learn how to use ghost's project-based development workflow for managing complex cave environments and persistent development setups.

---

### Overview

ghost supports project-based development similar to npm, cargo, or other package managers. In Ghost every **user account represents exactly one project space**. All caves, files and activity that belong to a user are grouped within that project boundary.

Each project (i.e. user) automatically contains one or more caves. See the [Caves guide](./caves.md) for language-specific runtime details and cave capabilities.

> **Admin project** – Das integrierte Admin-Konto ist selbst ein vollwertiges Projekt. Es verwaltet sein eigenes Cave-Inventar und darf zusätzlich globale Limits setzen (z. B. maximale Cave-Anzahl je Nutzerprojekt oder erlaubte Cave-Typen).

This project-centric approach is perfect for:

- **Development environments** that need to persist between sessions
- **Complex applications** with multiple services or components
- **Team collaboration** with shared cave configurations
- **Reproducible environments** across different machines

---

### Project-Based Development

#### Initialize a Project

Create a new ghost project in your current directory:

```bash
gst init
```

This creates a `Cavefile` in your current directory, which serves as the configuration manifest for your cave environments.

#### Add a Cave to Your Project

Register a new cave in your project:

```bash
gst add myapp \
    --image python \
    --cpus 1 \
    --memory 1024 \
    --start 'python app.py'
```

This command adds a cave named `myapp` to your Cavefile with the specified configuration.

After adding a cave, your `Cavefile` will look like this:

```yaml
# Cave configurations
cavees:
  myapp:
    image: python
    memory: 1024
    cpus: 1
    scripts:
      start: python app.py
```

#### Run Your Project Cave

Execute your project cave:

```bash
gst run --cave myapp
```

or use the shorthand:

```bash
gsr myapp
```

This executes the default _start_ script of your cave. For more control, you can specify which script to run:

```bash
gsr myapp~start
```

---

### Next Steps

[!ref CLI Reference](/references/cli#project-management)
