---
order: 110
icon: browser
tags: [guide]
---

# Admin Web UI

The `/admin` console gives operators a secure, browser-based cockpit for ghost. It bundles a SQLite-backed credential
store, session management, and dashboards for projects, API keys, MCP tools, and live cave activity.

---

## Architecture overview

The admin module lives inside `ghost-server` (`lib/admin.rs`). On startup the server:

1. Creates `${ghost_home}/admin/console.sqlite` if it does not exist.
2. Ensures an admin account is present. If none exists, one is created automatically. The username defaults to `admin` and a
   24-character random password is generated (or read from `GHOST_ADMIN_PASSWORD`). The credentials are emitted to logs once.
3. Serves the embedded single-page app at `/admin` and exposes JSON endpoints under `/admin/api/*` for the frontend.

SQLite keeps track of admin sessions, projects, API keys, and MCP registrations. Sessions are Argon2-hashed and expire after
12 hours by default.

---

## Signing in

1. Start `ghost-server` (the CLI does this automatically when running `gst server start`).
2. Visit `https://<host>/admin`.
3. Enter your admin username and password. The default credentials are printed in the server logs the first time the database
   is created—rotate them immediately.
4. The browser receives a secure, HTTP-only session cookie and gains access to the management panels.

> **Security checklist**
>
> - Always front the console with TLS and restrict access to trusted operators.
> - Rotate the auto-generated default password and store the new hash via the admin UI.
> - SQLite lives in `${ghost_home}/admin`. Apply filesystem permissions so only the ghost user can read/write it.

---

## Dashboard capabilities

### Caves snapshot

The console lists every cave the server knows about, including the namespace and exposed portal port. The list is sourced
from the port manager and refreshes on demand.

### Projects catalog

Use the Projects panel to capture cave-related metadata. The Admin-Projekt repräsentiert das eigene Operator-Projekt und definiert globale Leitplanken für alle Nutzerprojekte:

- **Create/update**: Provide a project name, optional namespace, description, und JSON-Metadaten. Der Admin kann zusätzlich pro Projekt Cave-Limits, erlaubte Cave-Typen sowie Token-Budgets festlegen.
- **Delete**: Remove projects that are no longer relevant. The API enforces referential integrity and will return a 404 if a project is missing.
- **Monitor**: Das Admin-Projekt hat Übersicht über alle Caves aller Nutzerprojekte und kann Limits in Echtzeit anpassen, z. B. maximale Cave-Anzahl oder Ausführungsrechte.

Projects are a lightweight registry meant to track initiatives, owners, or environment hints for operators.

### API key lifecycle

The API Keys panel wraps the existing JWT key generator:

- Choose a label, namespace, and expiry (in hours). The backend invokes `ghost_server::management::keygen` to generate a
  namespaced token and records the issuance in SQLite.
- The freshly generated token is shown once so you can copy it into your vault. Subsequent listings display a masked preview
  plus creation/expiry timestamps.
- Revoke tokens with a single click. Revocation deletes the stored record; operators should manually rotate the JWT secret if
  a key is suspected to be compromised.

### MCP tools

Register Model Context Protocol integrations for the MCP-aware APIs:

- Define the tool name, endpoint URL, optional description, and an API key if the MCP server requires one.
- Edit or delete registrations at any time. The console keeps `created_at` and `updated_at` timestamps for auditing.

The MCP panel does not contact external services; it stores metadata that other components can query for orchestration.

---

## API surface

The web app consumes a dedicated REST API under `/admin/api`. You can script these endpoints directly using any HTTP client.
All responses are JSON. Authentication is performed via the session cookie issued after login.

| Method & Path                 | Description                                           |
|------------------------------|-------------------------------------------------------|
| `POST /admin/api/session`    | Authenticate with username/password.                  |
| `GET /admin/api/session`     | Return the current session metadata.                  |
| `DELETE /admin/api/session`  | Destroy the session (log out).                        |
| `GET /admin/api/overview`    | Aggregate view of caves, projects, API keys, MCP.     |
| `POST /admin/api/projects`   | Create or update a project entry.                     |
| `DELETE /admin/api/projects/:id` | Remove a project by ID.                         |
| `POST /admin/api/api-keys`   | Generate and record a new API key.                    |
| `DELETE /admin/api/api-keys/:token` | Revoke an API key by its token.             |
| `POST /admin/api/mcp-tools`  | Create or update an MCP tool registration.            |
| `DELETE /admin/api/mcp-tools/:id` | Delete an MCP tool registration.              |

All mutation endpoints return structured error messages (`ServerError`) and consistent HTTP status codes to simplify
automation.

---

## Customisation

- **Session duration** – Adjust `SESSION_DURATION_HOURS` in `ghost-server/lib/admin.rs` to change the cookie lifetime.
- **Database location** – Override `GHOST_HOME` or `GHOST_ADMIN_PASSWORD` to control where the SQLite file lives and what the
  bootstrap credentials are.
- **CORS** – The CLI wires `tower-http` CORS middleware in `gstserver`. Adjust the allow-lists there if you are fronting the
  API with a different origin.

---

## Troubleshooting

| Symptom                                     | Resolution                                                                 |
|---------------------------------------------|-----------------------------------------------------------------------------|
| Login succeeds but immediately redirects     | Ensure the browser accepts cookies for the `/admin` path.                   |
| "Session invalid or expired" on every call  | Delete `${ghost_home}/admin/console.sqlite` to reset credentials and restart the server. |
| "Database error" responses                  | Confirm the ghost process can read/write the admin directory and the disk has space. |
| Tokens not revoking                          | Make sure you are signed in with an active session; revoked tokens disappear from the table. |

---

The Admin Web UI now mirrors the full operational surface area of ghost: it authenticates operators, tracks
infrastructure metadata, manages API keys, and keeps MCP integrations organised without touching raw JSON-RPC calls.
