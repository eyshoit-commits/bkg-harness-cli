---
order: 70
icon: plug
tags: [guide]
---

# Model Context Protocol (MCP)

[!embed](https://gist.github.com/user-attachments/assets/d602ddf9-2bea-4b7a-9a90-7d3953926d92)

Learn how to integrate ghost with AI tools using the Model Context Protocol for seamless code execution and cave management.

---

### Overview

The [Model Context Protocol (MCP)](https://modelcontextprotocol.io) is an open standard that enables AI applications to securely connect to external data sources and tools. ghost implements MCP as a built-in server, making it compatible with AI tools like Claude, and other MCP-enabled applications.

---

### Connection Details

- **Endpoint:** `http://127.0.0.1:5555/mcp`
- **Protocol:** Streamable HTTP
- **Authentication:** Bearer token (if not in dev mode)

!!!info Transport Support
ghost server only supports the **Streamable HTTP** transport protocol.
!!!

---

### Tools

ghost exposes tools through the MCP interface for complete cave lifecycle management.

---

### Cave Management Tools

==- `cave_start`
Start a new cave with specified configuration. This creates an isolated environment for code execution.

| Parameter   | Type     | Required | Description                   |
| ----------- | -------- | -------- | ----------------------------- |
| `cave`   | `string` | ✓        | Name of the cave to start  |
| `namespace` | `string` | ✓        | Namespace for the cave     |
| `config`    | `object` |          | Cave configuration options |

#### Configuration Options

| Property  | Type            | Description                                                            |
| --------- | --------------- | ---------------------------------------------------------------------- |
| `image`   | `string`        | Docker image to use (e.g., `ghost/python`, `ghost/node`) |
| `memory`  | `integer`       | Memory limit in MiB                                                    |
| `cpus`    | `integer`       | Number of CPUs                                                         |
| `volumes` | `array[string]` | Volume mounts                                                          |
| `ports`   | `array[string]` | Port mappings                                                          |
| `envs`    | `array[string]` | Environment variables                                                  |

+++ Basic Python Cave

```json
{
  "cave": "my-python-env",
  "namespace": "default"
}
```

+++ Custom Configuration

```json
{
  "cave": "data-analysis",
  "namespace": "research",
  "config": {
    "image": "ghost/python",
    "memory": 1024,
    "cpus": 2,
    "envs": ["PYTHONPATH=/workspace"]
  }
}
```

+++ Node.js Environment

```json
{
  "cave": "node-env",
  "namespace": "development",
  "config": {
    "image": "ghost/node",
    "memory": 512
  }
}
```

+++

!!!warning Important
Always stop the cave when done to prevent it from running indefinitely and consuming resources.
!!!
===

==- `cave_stop`
Stop a running cave and clean up its resources.

| Parameter   | Type     | Required | Description                 |
| ----------- | -------- | -------- | --------------------------- |
| `cave`   | `string` | ✓        | Name of the cave to stop |
| `namespace` | `string` | ✓        | Namespace of the cave    |

```json
{
  "cave": "my-python-env",
  "namespace": "default"
}
```

!!!warning Critical
Always call this when you're finished with a cave to prevent resource leaks and indefinite running. Failing to stop cavees will cause them to consume system resources unnecessarily.
!!!
===

---

### Code Execution Tools

==- `cave_run_code`
Execute code in a running cave environment.

| Parameter   | Type     | Required | Description                                   |
| ----------- | -------- | -------- | --------------------------------------------- |
| `cave`   | `string` | ✓        | Name of the cave (must be already started) |
| `namespace` | `string` | ✓        | Namespace of the cave                      |
| `code`      | `string` | ✓        | Code to execute                               |
| `language`  | `string` | ✓        | Programming language (`python`, `nodejs`)     |

+++ Python Execution

```json
{
  "cave": "my-python-env",
  "namespace": "default",
  "code": "import math\nresult = math.sqrt(16)\nprint(f'Square root: {result}')",
  "language": "python"
}
```

+++ JavaScript Execution

```json
{
  "cave": "node-env",
  "namespace": "development",
  "code": "const fs = require('fs');\nconst data = { message: 'Hello from Node.js!' };\nconsole.log(JSON.stringify(data, null, 2));",
  "language": "nodejs"
}
```

+++

!!! Prerequisites
The target cave must be started first using `cave_start` - this will fail if the cave is not running. Code execution is synchronous and may take time depending on complexity.
!!!
===

==- `cave_run_command`
Execute shell commands in a running cave.

| Parameter   | Type            | Required | Description                                   |
| ----------- | --------------- | -------- | --------------------------------------------- |
| `cave`   | `string`        | ✓        | Name of the cave (must be already started) |
| `namespace` | `string`        | ✓        | Namespace of the cave                      |
| `command`   | `string`        | ✓        | Command to execute                            |
| `args`      | `array[string]` |          | Command arguments                             |

+++ Simple Command

```json
{
  "cave": "my-python-env",
  "namespace": "default",
  "command": "ls"
}
```

+++ Command with Arguments

```json
{
  "cave": "my-python-env",
  "namespace": "default",
  "command": "ls",
  "args": ["-la", "/workspace"]
}
```

+++ Package Installation

```json
{
  "cave": "data-analysis",
  "namespace": "research",
  "command": "pip",
  "args": ["install", "pandas", "numpy", "matplotlib"]
}
```

+++

!!!info Prerequisites
The target cave must be started first using `cave_start` - this will fail if the cave is not running. Command execution is synchronous and may take time depending on complexity.
!!!
===

---

### Monitoring Tools

==- `cave_get_metrics`
Get metrics and status for cavees including CPU usage, memory consumption, and running state.

| Parameter   | Type     | Required | Description                                       |
| ----------- | -------- | -------- | ------------------------------------------------- |
| `namespace` | `string` | ✓        | Namespace to query (use `*` for all namespaces)   |
| `cave`   | `string` |          | Optional specific cave name to get metrics for |

+++ Single Cave

```json
{
  "cave": "my-python-env",
  "namespace": "default"
}
```

+++ All Cavees in Namespace

```json
{
  "namespace": "development"
}
```

+++ All Cavees

```json
{
  "namespace": "*"
}
```

+++

**Returns:** JSON object with metrics including:

- `name` - Cave name
- `namespace` - Cave namespace
- `running` - Boolean running status
- `cpu_usage` - CPU usage percentage
- `memory_usage` - Memory usage in MiB
- `disk_usage` - Disk usage in bytes

!!! Usage
This tool can check the status of any cave regardless of whether it's running or not, making it useful for monitoring and cleanup operations.
!!!
===

---

### Setting Up ghost with an Agent

Let's use [Agno](https://docs.agno.com) to build an AI agent that can execute code in ghost.

#### Prerequisites

1. **Install Agno and dependencies**:

```bash
pip install agno openai
```

2. **Start ghost server**:

```bash
gst server start --dev
```

#### Integration Example

```python
from agno.agent import Agent
from agno.models.openai import OpenAIChat
from agno.tools.mcp import MCPTools

async def main():
    # Connect to ghost MCP server
    server_url = "http://127.0.0.1:5555/mcp"

    async with MCPTools(url=server_url, transport="streamable-http") as mcp_tools:
        # Create agent with ghost tools
        agent = Agent(
            model=OpenAIChat(id="gpt-4o"),
            tools=[mcp_tools],
            description="AI assistant with secure code execution capabilities"
        )

        # Use the agent with ghost integration
        await agent.aprint_response(
            "Create a Python cave and calculate the first 10 fibonacci numbers",
            stream=True
        )

# Run the example
import asyncio
asyncio.run(main())
```

#### Other MCP-Compatible Tools

ghost works with any MCP-compatible application:

- **Claude** - AI chat application
- **Custom MCP clients** - Build your own integrations

---

### Examples

#### Complete Workflow

1. **Start the server:**

```bash
gst server start --dev
```

2. **Configure Claude Desktop** with the MCP server

3. **Test the integration:**

```
Ask Claude: "Can you start a Python cave and run a simple calculation?"
```

4. **Claude will:**
   - Call `cave_start` to create a new Python environment
   - Call `cave_run_code` to execute your calculation
   - Return the results in a natural language response

---

### Next Steps

[!ref API Reference](/references/api)
