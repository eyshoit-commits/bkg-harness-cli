---
order: 90
icon: container
tags: [guide]
---

# Caves

ghost provides different types of cavees optimized for specific programming languages and runtimes. Each cave type comes with pre-configured environments and language-specific optimizations.

---

### PythonCave

The PythonCave provides a complete Python environment with access to the Python interpreter, pip package manager, and the ability to execute both Python code and shell commands.

**Features:**

- Full Python 3.x environment
- Package installation with pip
- File system access
- Shell command execution
- Persistent state between executions

#### Usage Examples

+++ Python

```python
import asyncio
from ghost import PythonCave

async def main():
    async with PythonCave.create(name="python-demo") as cave:
        # Execute Python code directly
        exec = await cave.run("print('Hello from Python!')")
        print(await exec.output())

        # Install and use packages
        await cave.run("pip install requests")
        exec = await cave.run("""
import requests
response = requests.get('https://httpbin.org/json')
print(response.status_code)
        """)
        print(await exec.output())

asyncio.run(main())
```

+++ JavaScript

```javascript
import { PythonCave } from "ghost";

async function main() {
  const cave = await PythonCave.create({ name: "python-demo" });

  try {
    // Execute Python code directly
    const exec = await cave.run("print('Hello from Python!')");
    console.log(await exec.output());

    // Install and use packages
    await cave.run("pip install requests");
    const packageExec = await cave.run(`
import requests
response = requests.get('https://httpbin.org/json')
print(response.status_code)
    `);
    console.log(await packageExec.output());
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

+++ Rust

```rust
use ghost::{BaseCave, PythonCave};
use std::error::Error;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error + Send + Sync>> {
    let mut cave = PythonCave::create("python-demo").await?;
    cave.start(None).await?;

    // Execute Python code directly
    let exec = cave.run("print('Hello from Python!')").await?;
    println!("{}", exec.output().await?);

    // Install and use packages
    cave.run("pip install requests").await?;
    let package_exec = cave
        .run(
            r#"
import requests
response = requests.get('https://httpbin.org/json')
print(response.status_code)
"#,
        )
        .await?;
    println!("{}", package_exec.output().await?);

    cave.stop().await?;
    Ok(())
}
```

+++

---

### NodeCave

The NodeCave provides a complete Node.js environment with access to the Node.js runtime, npm package manager, and built-in Node.js modules.

**Features:**

- Full Node.js runtime environment
- Access to built-in Node.js modules (fs, os, path, etc.)
- Package installation with npm
- File system access
- Persistent state between executions

#### Usage Examples

+++ Python

```python
import asyncio
from ghost import NodeCave

async def main():
    async with NodeCave.create(name="node-demo") as cave:
        # Execute JavaScript code
        exec = await cave.run("console.log('Hello from Node.js!');")
        print("Output:", await exec.output())

        # Use Node.js built-in modules
        node_code = """
const fs = require('fs');
const os = require('os');

// Write and read a file
fs.writeFileSync('/tmp/test.txt', 'Hello from Node.js!');
const content = fs.readFileSync('/tmp/test.txt', 'utf8');
console.log('File content:', content);

// Get system info
console.log('Platform:', os.platform());
console.log('Node.js version:', process.version);
        """
        exec = await cave.run(node_code)
        print(await exec.output())

asyncio.run(main())
```

+++ JavaScript

```javascript
import { NodeCave } from "ghost";

async function main() {
  const cave = await NodeCave.create({ name: "node-demo" });

  try {
    // Execute JavaScript code
    const exec = await cave.run("console.log('Hello from Node.js!');");
    console.log("Output:", await exec.output());

    // Use Node.js built-in modules
    const nodeCode = `
const fs = require('fs');
const os = require('os');

// Write and read a file
fs.writeFileSync('/tmp/test.txt', 'Hello from Node.js!');
const content = fs.readFileSync('/tmp/test.txt', 'utf8');
console.log('File content:', content);

// Get system info
console.log('Platform:', os.platform());
console.log('Node.js version:', process.version);
    `;
    const nodeExec = await cave.run(nodeCode);
    console.log(await nodeExec.output());
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

+++ Rust

```rust
use ghost::{BaseCave, NodeCave};
use std::error::Error;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error + Send + Sync>> {
    let mut cave = NodeCave::create("node-demo").await?;
    cave.start(None).await?;

    // Execute JavaScript code
    let exec = cave.run("console.log('Hello from Node.js!');").await?;
    println!("Output: {}", exec.output().await?);

    // Use Node.js built-in modules
    let node_code = r#"
const fs = require('fs');
const os = require('os');

// Write and read a file
fs.writeFileSync('/tmp/test.txt', 'Hello from Node.js!');
const content = fs.readFileSync('/tmp/test.txt', 'utf8');
console.log('File content:', content);

// Get system info
console.log('Platform:', os.platform());
console.log('Node.js version:', process.version);
"#;
    let node_exec = cave.run(node_code).await?;
    println!("{}", node_exec.output().await?);

    cave.stop().await?;
    Ok(())
}
```

+++

---

### Choosing the Right Cave

#### Use PythonCave when:

- You need to execute Python code
- You want to use Python packages from PyPI
- You need data science libraries (pandas, numpy, etc.)
- You're building Python-based applications
- You need to run shell commands alongside Python code

#### Use NodeCave when:

- You need to execute JavaScript code
- You want to use npm packages
- You're building Node.js applications
- You need access to Node.js built-in modules
- You're working with web-related JavaScript code

---

### Common Patterns

#### State Persistence

Both cave types maintain state between executions within the same session:

```python
# Variables and imports persist between runs
await cave.run("x = 42")
await cave.run("y = x * 2")
exec = await cave.run("print(f'Result: {y}')")  # Outputs: Result: 84
```

#### Error Handling

Both cavees provide comprehensive error handling:

```python
exec = await cave.run("invalid_code_here")
if exec.has_error():
    print("Error occurred:", await exec.error())
else:
    print("Success:", await exec.output())
```
