---
order: 70
icon: terminal
tags: [references]
---

# CLI Reference

Complete reference documentation for the ghost command-line interface.

---

### Installation

```bash
curl -sSL https://get.ghost.dev | sh
```

---

### Quick Start

```bash
# Start the server in development mode
gst server start --dev
```

---

### Global Options

==- Common Flags
| Flag | Description |
|------|-------------|
| `-V, --version` | Show version |
| `--error` | Show logs with error level |
| `--warn` | Show logs with warn level |
| `--info` | Show logs with info level |
| `--debug` | Show logs with debug level |
| `--trace` | Show logs with trace level |
===

---

### Server Management

==- `gst server start`
Start the cave server.

```bash
gst server start [options]
```

| Option              | Description              |
| ------------------- | ------------------------ |
| `--host <host>`     | Host to listen on        |
| `--port <port>`     | Port to listen on        |
| `-p, --path <path>` | Namespace directory path |
| `--dev`             | Run in development mode  |
| `-k, --key <key>`   | Set secret key           |
| `-d, --detach`      | Run in background        |
| `-r, --reset-key`   | Reset the server key     |

**Examples:**

```bash
# Start server in development mode
gst server start --dev

# Start server on custom port
gst server start --port 8080

# Start server on custom host
gst server start --host 0.0.0.0

# Start server in background with custom namespace path
gst server start --detach --path /custom/namespaces

# Start server with a specific key
gst server start --key mySecretKey123
```

===

==- `gst server keygen`
Generate a new API key.

```bash
gst server keygen [options]
```

| Option                 | Description                         |
| ---------------------- | ----------------------------------- |
| `--expire <duration>`  | Token expiration (1s, 2m, 3h, etc.) |
| `-n, --namespace <ns>` | Namespace for the API key           |

**Examples:**

```bash
# Generate an API key for all namespaces
gst server keygen

# Generate an API key that expires in 24 hours, for all namespaces
gst server keygen --expire 24h

# Generate an API key for a specific namespace
gst server keygen --namespace production

# Generate a short-lived key for testing
gst server keygen --expire 30m --namespace testing
```

===

==- `gst server status`
Show server status.

```bash
gst server status [--cave] [names...] [options]
```

| Option                 | Description                  |
| ---------------------- | ---------------------------- |
| `-s, --cave`        | Apply to cavees           |
| `-n, --namespace <ns>` | Namespace to show status for |

**Examples:**

```bash
# Show status for all cavees
gst server status

# Show status for specific cavees
gst server status app database

# Show status for cavees in a specific namespace
gst server status --namespace production
```

===

---

### Project Management

==- `gst init`
Initialize a new ghost project.

```bash
gst init [--file <path>]
```

| Option              | Description                                   |
| ------------------- | --------------------------------------------- |
| `-f, --file <path>` | Path to the cave file or project directory |

**Examples:**

```bash
# Initialize project in current directory
gst init


# Initialize project in a specific directory
gst init --file /path/to/project/

# Initialize project with custom cave file location
gst init --file ./path/to/Cavefile
```

===

==- `gst add`
Add a new cave to a project.

```bash
gst add [--cave] [--build] [--group] <names...> --image <image> [options]
```

| Option                 | Description                           |
| ---------------------- | ------------------------------------- |
| `-s, --cave`        | Apply to a cave (default)          |
| `-b, --build`          | Apply to a build cave              |
| `-g, --group`          | Apply to a group                      |
| `--image <image>`      | Image to use                          |
| `--memory <MiB>`       | Memory limit in MiB                   |
| `--cpus <count>`       | Number of CPUs                        |
| `-v, --volume <map>`   | Volume mappings (host:container)      |
| `-p, --port <map>`     | Port mappings (host:container)        |
| `--env <KEY=VALUE>`    | Environment variables                 |
| `--env-file <path>`    | Environment file                      |
| `--depends-on <deps>`  | Dependencies                          |
| `--workdir <path>`     | Working directory                     |
| `--shell <shell>`      | Shell to use                          |
| `--script <name=cmd>`  | Scripts to add                        |
| `--start <cmd>`        | Start script                          |
| `--import <name=path>` | Files to import                       |
| `--export <name=path>` | Files to export                       |
| `--scope <scope>`      | Network scope (local/public/any/none) |
| `-f, --file <path>`    | Path to cave file                  |

**Examples:**

```bash
# Add a simple cave
gst add --cave app --image node:18

# Add a simple cave (--cave is default)
gst add app --image node:18

# Add a cave with port mapping and environment variables
gst add web --image nginx:alpine --port 8080:80 --env NODE_ENV=production

# Add a cave with volume mounts and resource limits
gst add database --image postgres:15 --volume ./data:/var/lib/postgresql/data --memory 512 --cpus 2

# Add a cave with dependencies and custom scripts
gst add api --image my/api --depends-on database --script test="pytest" --start "python app.py"
```

===

==- `gst remove`
Remove a cave from the project.

```bash
gst remove [--cave] [--build] [--group] <names...> [--file <path>]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to a cave (default) |
| `-b, --build`       | Apply to a build cave     |
| `-g, --group`       | Apply to a group             |
| `-f, --file <path>` | Path to cave file         |

**Examples:**

```bash
# Remove a cave
gst remove --cave app

# Remove a cave (--cave is default)
gst remove app

# Remove multiple cavees
gst remove web api database

# Remove from a specific cave file
gst remove app --file ./path/to/Cavefile
```

===

==- `gst list`
List cavees defined in a project.

```bash
gst list [--cave] [--build] [--group] [--file <path>]
```

| Option              | Description              |
| ------------------- | ------------------------ |
| `-s, --cave`     | List cavees (default) |
| `-b, --build`       | List build cavees     |
| `-g, --group`       | List groups              |
| `-f, --file <path>` | Path to cave file     |

**Examples:**

```bash
# List all cavees
gst list --cave

# List all cavees (--cave is default)
gst list

# List from a specific cave file
gst list --file ./config/cave.yaml
```

===

---

### Cave Operations

==- `gst run`
Run a cave defined in the project.

```bash
gst run [--cave] [--build] <NAME[~SCRIPT]> [options] [-- args...]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to a cave (default) |
| `-b, --build`       | Apply to a build cave     |
| `-f, --file <path>` | Path to cave file         |
| `-d, --detach`      | Run in background            |
| `-e, --exec <cmd>`  | Execute a command            |
| `-- <args...>`      | Additional arguments         |

**Examples:**

```bash
# Run a cave
gst run --cave app

# Run a cave (--cave is default)
gst run app

# Run a specific script in a cave
gst run app~test

# Run a specific script in a cave with additional arguments
gst run app~test -- -a 1 -b 2

# Run in background
gst run app --detach

# Execute a command within a cave
gst run app --exec bash

# Execute a command within a cave with additional arguments
gst run app --exec bash -- -c "echo 'Hello, World!'"
```

===

==- `gst shell`
Open a shell in a cave. This opens whatever shell is configured for the cave image.

```bash
gst shell [--cave] [--build] <name> [options] [-- args...]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to a cave (default) |
| `-b, --build`       | Apply to a build cave     |
| `-f, --file <path>` | Path to cave file         |
| `-d, --detach`      | Run in background            |
| `-- <args...>`      | Additional arguments         |

**Examples:**

```bash
# Open shell in a cave
gst shell --cave app

# Open shell in a cave (--cave is default)
gst shell app

# Open shell with additional arguments
gst shell app -- -c "echo 'Hello, World!'"
```

===

==- `gst exe`
Run a temporary cave. This cave will be removed after it exits.

```bash
gst exe [--image] <NAME[~SCRIPT]> [options] [-- args...]
```

| Option               | Description           |
| -------------------- | --------------------- |
| `--cpus <count>`     | Number of CPUs        |
| `--memory <MiB>`     | Memory in MB          |
| `-v, --volume <map>` | Volume mappings       |
| `-p, --port <map>`   | Port mappings         |
| `--env <KEY=VALUE>`  | Environment variables |
| `--workdir <path>`   | Working directory     |
| `--scope <scope>`    | Network scope         |
| `-e, --exec <cmd>`   | Execute a command     |
| `-- <args...>`       | Additional arguments  |

**Examples:**

```bash
# Run a temporary cave with an image (--image is default)
gst exe python:3.11

# Run with resource limits and volume mounts
gst exe ubuntu:22.04 --memory 256 --cpus 1 --volume ./code:/workspace

# Execute a specific command
gst exe node:18 --exec npm -- test

# Run with environment variables and port mapping
gst exe nginx:alpine --env NODE_ENV=production --port 8080:80

# Pass additional arguments
gst exe python:3.11 -- -c "print('Hello World')"
```

===

==- `gst log`
Show logs of a build, cave, or group.

```bash
gst log [--cave] [--build] [--group] <name> [options]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to a cave (default) |
| `-b, --build`       | Apply to a build cave     |
| `-g, --group`       | Apply to a group             |
| `-f, --file <path>` | Path to cave file         |
| `-f, --follow`      | Follow the logs              |
| `-t, --tail <n>`    | Number of lines to show      |

**Examples:**

```bash
# Show logs for a cave (--cave is default)
gst log app

# Follow logs in real-time
gst log app --follow

# Show last 50 lines
gst log app --tail 50
```

===

==- `gst tree`
Show tree of layers that make up a cave.

!!!warning Coming Soon
This will be available in a future release.
!!!

```bash
gst tree [--cave] [--build] [--group] <names...> [-L <level>]
```

| Option          | Description                  |
| --------------- | ---------------------------- |
| `-s, --cave` | Apply to a cave (default) |
| `-b, --build`   | Apply to a build cave     |
| `-g, --group`   | Apply to a group             |
| `-L <level>`    | Maximum depth level          |

**Examples:**

```bash
# Show tree for a cave (--cave is default)
gst tree app

# Show tree for multiple cavees
gst tree app database

# Limit tree depth
gst tree app -L 3
```

===

---

### Project Lifecycle

==- `gst apply`
Start or stop project cavees based on configuration.

```bash
gst apply [--file <path>] [--detach]
```

| Option              | Description          |
| ------------------- | -------------------- |
| `-f, --file <path>` | Path to cave file |
| `-d, --detach`      | Run in background    |

**Examples:**

```bash
# Apply current project configuration
gst apply

# Apply in background
gst apply --detach

# Apply specific cave file
gst apply --file ./path/to/Cavefile
```

===

==- `gst up`
Run project cavees.

```bash
gst up [--cave] [--build] [--group] [names...] [options]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to cavees (default) |
| `-b, --build`       | Apply to build cavees     |
| `-g, --group`       | Apply to groups              |
| `-f, --file <path>` | Path to cave file         |
| `-d, --detach`      | Run in background            |

**Examples:**

```bash
# Start all cavees
gst up --cave

# Start all cavees (--cave is default)
gst up

# Start specific cavees
gst up app database

# Start in background
gst up --detach
```

===

==- `gst down`
Stop project cavees.

```bash
gst down [--cave] [--build] [--group] [names...] [options]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to cavees (default) |
| `-b, --build`       | Apply to build cavees     |
| `-g, --group`       | Apply to groups              |
| `-f, --file <path>` | Path to cave file         |

**Examples:**

```bash
# Stop all cavees
gst down --cave

# Stop all cavees (--cave is default)
gst down

# Stop specific cavees
gst down app database

# Stop from specific cave file
gst down --file ./path/to/Cavefile
```

===

==- `gst status`
Show statuses of running cavees.

```bash
gst status [--cave] [--build] [--group] [names...] [options]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to cavees (default) |
| `-b, --build`       | Apply to build cavees     |
| `-g, --group`       | Apply to groups              |
| `-f, --file <path>` | Path to cave file         |

**Examples:**

```bash
# Show status of all cavees
gst status --cave

# Show status of all cavees (--cave is default)
gst status

# Show status of specific cavees
gst status app database

# Show status from specific cave file
gst status --file ./path/to/Cavefile
```

===

---

### Image Management

==- `gst build`
Build images.

!!!warning Coming Soon
This will be available in a future release.
!!!

```bash
gst build [--build] [--cave] [--group] <names...> [--snapshot]
```

| Option          | Description                  |
| --------------- | ---------------------------- |
| `-b, --build`   | Build from build definition  |
| `-s, --cave` | Build from cave (default) |
| `-g, --group`   | Build from group             |
| `--snapshot`    | Create a snapshot            |

**Examples:**

```bash
# Build from cave
gst build app --cave

# Build from cave (--cave is default)
gst build app

# Build multiple cavees
gst build app database

# Create a snapshot while building
gst build app --snapshot
```

===

==- `gst pull`
Pull image from a registry.

```bash
gst pull [--image] [--image-group] <name> [options]
```

| Option                    | Description                 |
| ------------------------- | --------------------------- |
| `-i, --image`             | Apply to an image (default) |
| `-G, --image-group`       | Apply to an image group     |
| `-L, --layer-path <path>` | Path to store layer files   |

**Examples:**

```bash
# Pull an image
gst pull --image python:3.11

# Pull an image (--image is default)
gst pull python:3.11

# Pull with custom layer storage path
gst pull ubuntu:22.04 --layer-path /custom/layers
```

===

==- `gst push`
Push image to a registry.

!!!warning Coming Soon
This will be available in a future release.
!!!

```bash
gst push [--image] [--image-group] <name>
```

| Option              | Description                 |
| ------------------- | --------------------------- |
| `-i, --image`       | Apply to an image (default) |
| `-G, --image-group` | Apply to an image group     |

**Examples:**

```bash
# Push an image
gst push --image myapp:latest

# Push an image (--image is default)
gst push myapp:latest
```

===

---

### Maintenance

==- `gst clean`
Clean cached cave layers, metadata, etc.

```bash
gst clean [--cave] [name] [options]
```

| Option              | Description                  |
| ------------------- | ---------------------------- |
| `-s, --cave`     | Apply to a cave (default) |
| `-u, --user`        | Clean user-level caches      |
| `-a, --all`         | Clean all                    |
| `-f, --file <path>` | Path to cave file         |
| `--force`           | Force clean                  |

**Examples:**

```bash
# Clean specific cave
gst clean --cave app

# Clean specific cave (--cave is default)
gst clean app

# Clean all caches
gst clean --all

# Clean user-level caches
gst clean --user

# Force clean without confirmation
gst clean app --force
```

===

==- `gst self upgrade`
Upgrade ghost itself.

!!!warning Coming Soon
This will be available in a future release.
!!!

```bash
gst self upgrade
```

**Examples:**

```bash
# Upgrade to the latest version
gst self upgrade
```

===

==- `gst self uninstall`
Uninstall ghost.

```bash
gst self uninstall
```

**Examples:**

```bash
# Uninstall ghost
gst self uninstall
```

===
