---
order: 90
icon: file-code
tags: [references]
---

# TypeScript SDK Reference

Complete reference documentation for the ghost TypeScript SDK.

---

### Installation

```bash
npm install ghost
```

---

### Quick Start

```typescript
import { PythonCave } from "ghost";

async function main() {
  const cave = await PythonCave.create({ name: "my-cave" });

  try {
    const exec = await cave.run("print('Hello, World!')");
    console.log(await exec.output());
  } finally {
    await cave.stop();
  }
}

main().catch(console.error);
```

---

### PythonCave

The main class for creating and managing Python execution environments.

==- Constructor
```typescript
constructor(options?: CaveOptions)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `options.serverUrl` | `string` | URL of the ghost server (defaults to GST_SERVER_URL env var or "http://127.0.0.1:5555") |
| `options.namespace` | `string` | Namespace for the cave (default: "default") |
| `options.name` | `string` | Cave identifier (auto-generated if undefined) |
| `options.apiKey` | `string` | Authentication key (or set `GST_API_KEY` env var) |
===

#### Class Methods

==- `create()`
Creates and automatically starts a new cave instance.

```typescript
static async create(options?: CaveOptions): Promise<PythonCave>
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `options.serverUrl` | `string` | URL of the ghost server |
| `options.namespace` | `string` | Namespace for the cave |
| `options.name` | `string` | Name for the cave |
| `options.apiKey` | `string` | API key for authentication |
| `options.image` | `string` | Docker image to use |
| `options.memory` | `number` | Memory limit in MB |
| `options.cpus` | `number` | CPU cores |
| `options.timeout` | `number` | Startup timeout in seconds |

**Returns:** A started `PythonCave` instance

```typescript
const cave = await PythonCave.create({ name: "my-cave" });
try {
  const exec = await cave.run("print('Hello!')");
  console.log(await exec.output());
} finally {
  await cave.stop();
}
```
===

#### Instance Methods

==- `start()`
Starts the cave with optional resource constraints.

```typescript
async start(
  image?: string,
  memory?: number,
  cpus?: number,
  timeout?: number
): Promise<void>
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `image` | `string` | Docker image to use (defaults to language-specific image) |
| `memory` | `number` | Memory limit in MB (default: 512) |
| `cpus` | `number` | CPU cores (will be rounded to nearest integer, default: 1.0) |
| `timeout` | `number` | Startup timeout in seconds (default: 180.0) |

```typescript
const cave = new PythonCave({ name: "resource-limited" });
await cave.start("ghost/python", 1024, 2.0);
```
===

==- `stop()`
Stops and cleans up the cave.

```typescript
async stop(): Promise<void>
```
===

==- `run()`
Executes Python code in the cave environment.

```typescript
async run(code: string, options?: { timeout?: number }): Promise<Execution>
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `code` | `string` | Python code to execute |
| `options.timeout` | `number` | Execution timeout in seconds (optional) |

**Returns:** `Execution` object with results

+++ Simple Execution
```typescript
const exec = await cave.run("print('Hello, World!')");
console.log(await exec.output());
```
+++ Multi-line Code
```typescript
const code = `
import math
result = math.sqrt(16)
print(f"Square root of 16 is: {result}")
`;
const exec = await cave.run(code);
```
+++
===

#### Properties

==- `command`
Access to shell command execution interface.

```typescript
get command(): Command
```

```typescript
const result = await cave.command.run("ls", ["-la", "/"]);
console.log(await result.output());
```
===

==- `metrics`
Access to resource monitoring interface.

```typescript
get metrics(): Metrics
```

```typescript
const cpu = await cave.metrics.cpu();
const memory = await cave.metrics.memory();
console.log(`CPU: ${cpu}%, Memory: ${memory} MiB`);
```
===

==- `isStarted`
Returns cave running status.

```typescript
get isStarted(): boolean
```
===

==- `name`
Returns the cave identifier.

```typescript
get name(): string
```
===

==- `serverUrl`
Returns the server URL.

```typescript
get serverUrl(): string
```
===

==- `namespace`
Returns the namespace.

```typescript
get namespace(): string
```
===

==- `apiKey`
Returns the API key.

```typescript
get apiKey(): string | undefined
```
===

---

### NodeCave

JavaScript/Node.js execution environment with identical API to PythonCave.

==- Constructor
```typescript
constructor(options?: CaveOptions)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `options.serverUrl` | `string` | URL of the ghost server |
| `options.namespace` | `string` | Namespace for the cave |
| `options.name` | `string` | Cave identifier (auto-generated if undefined) |
| `options.apiKey` | `string` | Authentication key (or set `GST_API_KEY` env var) |
===

All methods are identical to `PythonCave` but execute JavaScript code.

```typescript
import { NodeCave } from "ghost";

const cave = await NodeCave.create({ name: "js-cave" });
try {
  const exec = await cave.run("console.log('Hello from Node.js!');");
  console.log(await exec.output());
} finally {
  await cave.stop();
}
```

---

### Execution

Represents the result of code execution from `cave.run()`.

#### Methods

==- `output()`
Returns standard output from execution.

```typescript
async output(): Promise<string>
```
===

==- `error()`
Returns standard error from execution.

```typescript
async error(): Promise<string>
```
===

==- `hasError()`
Checks if execution produced errors.

```typescript
hasError(): boolean
```
===

#### Properties

==- `status`
Execution status.

```typescript
get status(): string
```
===

==- `language`
Language used for execution.

```typescript
get language(): string
```
===

!!!warning Example: Handling Execution Results
```typescript
const exec = await cave.run("print('Hello'); import sys; sys.exit(1)");
console.log(`Status: ${exec.status}`);
console.log(`Language: ${exec.language}`);
console.log(`Output: ${await exec.output()}`);
console.log(`Has error: ${exec.hasError()}`);
```
!!!

---

### CommandExecution

Represents the result of command execution from `cave.command.run()`.

#### Methods

==- `output()`
Returns standard output from command execution.

```typescript
async output(): Promise<string>
```
===

==- `error()`
Returns standard error from command execution.

```typescript
async error(): Promise<string>
```
===

#### Properties

==- `exitCode`
Command exit code.

```typescript
get exitCode(): number
```
===

==- `success`
True if command was successful (exit code 0).

```typescript
get success(): boolean
```
===

==- `command`
The command that was executed.

```typescript
get command(): string
```
===

==- `args`
Arguments used for the command.

```typescript
get args(): string[]
```
===

---

### Command

Interface for executing shell commands within cavees.

==- `run()`
Executes shell commands with arguments.

```typescript
async run(
  command: string,
  args?: string[],
  timeout?: number
): Promise<CommandExecution>
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `command` | `string` | Command to execute |
| `args` | `string[]` | Command arguments (optional) |
| `timeout` | `number` | Execution timeout in seconds (optional) |

**Returns:** `CommandExecution` object with results

+++ Simple Command
```typescript
const result = await cave.command.run("ls");
```
+++ With Arguments
```typescript
const result = await cave.command.run("ls", ["-la", "/tmp"]);
```
+++ With Timeout
```typescript
const result = await cave.command.run("sleep", ["10"], 5);
```
+++ Error Handling
```typescript
const result = await cave.command.run("ls", ["/nonexistent"]);
if (result.success) {
  console.log("Output:", await result.output());
} else {
  console.log("Error:", await result.error());
  console.log("Exit code:", result.exitCode);
}
```
+++
===

---

### Metrics

Interface for monitoring cave resource usage and performance.

#### Methods

==- `cpu()`
Current CPU usage percentage.

```typescript
async cpu(): Promise<number | undefined>
```
===

==- `memory()`
Current memory usage in MiB.

```typescript
async memory(): Promise<number | undefined>
```
===

==- `disk()`
Current disk usage in bytes.

```typescript
async disk(): Promise<number | undefined>
```
===

==- `isRunning()`
Cave running status.

```typescript
async isRunning(): Promise<boolean>
```
===

==- `all()`
All metrics as a dictionary.

```typescript
async all(): Promise<any>
```

**Returns:** Object with keys: `name`, `namespace`, `running`, `cpu_usage`, `memory_usage`, `disk_usage`

```typescript
// Individual metrics
const cpu = await cave.metrics.cpu();
const memory = await cave.metrics.memory();
const disk = await cave.metrics.disk();
const running = await cave.metrics.isRunning();

console.log(`CPU: ${cpu !== undefined ? cpu + '%' : 'Not available'}`);
console.log(`Memory: ${memory || 'Not available'} MiB`);
console.log(`Disk: ${disk || 'Not available'} bytes`);
console.log(`Running: ${running}`);

// All metrics at once
const metrics = await cave.metrics.all();
console.log(`All metrics:`, metrics);
```
===

---

### Usage Patterns

#### Automatic Cleanup (Recommended)

Manual resource management with proper cleanup.

```typescript
const cave = await PythonCave.create({ name: "my-cave" });

try {
  const exec = await cave.run("print('Hello, World!')");
  console.log(await exec.output());
} finally {
  await cave.stop(); // Always cleanup
}
```

#### Manual Lifecycle Management

Manual control over cave lifecycle.

```typescript
const cave = new PythonCave({ name: "my-cave" });

try {
  await cave.start(undefined, 1024, 2.0);
  const exec = await cave.run("print('Hello, World!')");
  console.log(await exec.output());
} finally {
  await cave.stop();
}
```

#### State Persistence

Variables and imports persist between executions.

```typescript
const cave = await PythonCave.create({ name: "stateful" });

try {
  await cave.run("x = 42");
  await cave.run("y = x * 2");
  const exec = await cave.run("print(f'Result: {y}')");
  console.log(await exec.output()); // Output: Result: 84
} finally {
  await cave.stop();
}
```

#### Error Handling

Comprehensive error handling patterns.

```typescript
const cave = await PythonCave.create({ name: "error-handling" });

try {
  const exec = await cave.run("1/0"); // Division by zero
  if (exec.hasError()) {
    console.log("Error occurred:", await exec.error());
  }
} catch (error) {
  console.log("Runtime error:", error);
} finally {
  await cave.stop();
}
```

#### File Operations

Creating and manipulating files within cavees.

```typescript
const cave = await PythonCave.create({ name: "files" });

try {
  // Create a file using Python
  await cave.run(`
with open('/tmp/test.txt', 'w') as f:
    f.write('Hello from cave!')
  `);

  // Read the file using shell command
  const result = await cave.command.run("cat", ["/tmp/test.txt"]);
  console.log("File content:", await result.output());
} finally {
  await cave.stop();
}
```

---

### Configuration

#### Environment Variables

| Variable | Description |
|----------|-------------|
| `GST_API_KEY` | API key for authentication |
| `GST_SERVER_URL` | Default server URL (overrides default) |

#### Server Configuration

Default server URL: `http://127.0.0.1:5555`

---

### Error Handling

!!!danger Common Error Types
The SDK throws `Error` for various conditions:

- **Connection failures** — Server unreachable or network issues
- **Authentication errors** — Invalid or missing API key
- **Execution timeouts** — Code/commands exceed time limits
- **Invalid operations** — Attempting operations on stopped cavees
!!!

#### Best Practices

```typescript
try {
  const cave = await PythonCave.create({ name: "error-test" });

  try {
    const exec = await cave.run("potentially_failing_code()");

    if (exec.hasError()) {
      console.log("Execution error:", await exec.error());
    } else {
      console.log("Success:", await exec.output());
    }
  } finally {
    await cave.stop();
  }
} catch (error) {
  console.log(`SDK error: ${error}`);
}
```

---

### Best Practices

!!!success Recommended Practices

1. **Always use try-finally** — Ensures proper cleanup
2. **Set appropriate timeouts** — Prevent hanging operations
3. **Handle errors gracefully** — Use try-catch blocks
4. **Monitor resources** — Use metrics interface
5. **Use meaningful names** — Easier debugging and management
6. **Install packages once** — Reuse cave for multiple executions
7. **Always call stop()** — Prevent resource leaks

!!!

!!!warning Common Pitfalls

- Forgetting to call `stop()` in finally blocks
- Not handling execution errors properly
- Setting timeouts too low for complex operations
- Creating too many concurrent cavees without resource limits

!!!
