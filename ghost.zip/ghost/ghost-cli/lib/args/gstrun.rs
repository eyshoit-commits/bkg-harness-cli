use std::path::PathBuf;

use chrono::{DateTime, Utc};
use clap::{Parser, Subcommand};

use crate::styles;

//--------------------------------------------------------------------------------------------------
// Types
//--------------------------------------------------------------------------------------------------

/// Arguments for the gstrun command
#[derive(Debug, Parser)]
#[command(name = "gstrun", author, styles=styles::styles())]
pub struct McrunArgs {
    /// The subcommand to run
    #[command(subcommand)]
    pub subcommand: McrunSubcommand,
}

/// Available subcommands for managing microvms
#[derive(Subcommand, Debug)]
pub enum McrunSubcommand {
    /// Run as microvm
    Microvm {
        /// Log level
        #[arg(long)]
        log_level: Option<u8>,

        /// Native root filesystem path
        #[arg(long)]
        native_rootfs: Option<PathBuf>,

        /// Overlayfs root filesystem layers
        #[arg(long)]
        overlayfs_layer: Vec<PathBuf>,

        /// Number of virtual CPUs
        #[arg(long)]
        num_vcpus: Option<u8>,

        /// Memory size in MiB
        #[arg(long)]
        memory_mib: Option<u32>,

        /// Working directory path
        #[arg(long)]
        workdir_path: Option<String>,

        /// Executable path
        #[arg(long, required = true)]
        exec_path: String,

        /// Environment variables (KEY=VALUE format)
        #[arg(long)]
        env: Vec<String>,

        /// Directory mappings (host:guest format)
        #[arg(long)]
        mapped_dir: Vec<String>,

        /// Port mappings (host:guest format)
        #[arg(long)]
        port_map: Vec<String>,

        /// Network communication scope
        #[arg(long)]
        scope: Option<String>,

        /// Assigned IP address
        #[arg(long)]
        ip: Option<String>,

        /// Assigned subnet
        #[arg(long)]
        subnet: Option<String>,

        /// Additional arguments after `--`
        #[arg(last = true)]
        args: Vec<String>,
    },

    /// Run as supervisor
    Supervisor {
        /// Directory for log files
        #[arg(long)]
        log_dir: PathBuf,

        /// Path to the cave metrics and metadata database file
        #[arg(long)]
        cave_db_path: PathBuf,

        /// Name of the child process
        #[arg(long)]
        cave_name: String,

        /// Path to the cave config file
        #[arg(long)]
        config_file: String,

        /// Last modified timestamp of the cave config file
        #[arg(long)]
        config_last_modified: DateTime<Utc>,

        /// Log level
        #[arg(long)]
        log_level: Option<u8>,

        /// Whether to forward output to stdout/stderr
        #[arg(long, default_value = "true")]
        forward_output: bool,

        // Cave specific arguments
        /// Native root filesystem path
        #[arg(long)]
        native_rootfs: Option<PathBuf>,

        /// Overlayfs root filesystem layers
        #[arg(long)]
        overlayfs_layer: Vec<PathBuf>,

        /// Number of virtual CPUs
        #[arg(long)]
        num_vcpus: Option<u8>,

        /// Memory size in MiB
        #[arg(long)]
        memory_mib: Option<u32>,

        /// Working directory path
        #[arg(long)]
        workdir_path: Option<String>,

        /// Executable path
        #[arg(long, required = true)]
        exec_path: String,

        /// Environment variables (KEY=VALUE format)
        #[arg(long)]
        env: Vec<String>,

        /// Directory mappings (host:guest format)
        #[arg(long)]
        mapped_dir: Vec<String>,

        /// Port mappings (host:guest format)
        #[arg(long)]
        port_map: Vec<String>,

        /// Network communication scope
        #[arg(long)]
        scope: Option<String>,

        /// Assigned IP address
        #[arg(long)]
        ip: Option<String>,

        /// Assigned subnet
        #[arg(long)]
        subnet: Option<String>,

        /// Additional arguments after `--`
        #[arg(last = true)]
        args: Vec<String>,
    },
}
