# BKG — HARD REALITY CHECK: WAS FEHLT WIRKLICH?

## Build-Status: bkg-cli ✅ — bkg-core: ✅ — bkg-wasm-alpha: ❌ (upstream bug)

---

## ❌ 1. TUI: Atlantean Design ist NICHT fertig integriert
**Status: Existiert als Datei, wird NICHT in allen Bereichen verwendet**
- [ ] `crates/bkg-cli/src/tui/atlantean.rs` — erstellt, aber nur `colors`, `styles`, `symbols` definiert
- [ ] Capsule-Status (CapsuleState) wird nirgendwo in der TUI angezeigt
- [ ] Trust Layer / Katoptron-Status fehlt in TUI
- [ ] SWD-Status fehlt in TUI
- [ ] Model-Routing fehlt in Config-Tab
- [ ] Healing-Status fehlt in TUI

## ❌ 2. Provider System: Unvollständig
- [ ] Ollama: Soll als LOCAL ORCHESTRATOR für Model-Routing dienen — aktuell nur ein Provider wie alle anderen
- [ ] Provider-Registry in `bkg-provider` (nicht in `bkg-core`)
- [ ] Dynamic Model Discovery (Plan Phase 4) nicht vollständig verdrahtet
- [ ] Setup-Wizard läuft IMMER (Bug) statt nur beim ersten Start
- [ ] `BKG_DEFAULT_PROVIDER` env var wird ignoriert (Provider-Registry bug)

## ❌ 3. Bootstrap-System: Nicht vollständig in main.rs integriert
- [ ] `crates/bkg-cli/src/bootstrap.rs` enthält CLI-wrapping aber:
  - Wird nicht von main.rs verwendet (BkgBootstrap aus bkg-core wird stattdessen benutzt)
  - `run_bootstrap` erzeugt die schöne Tabelle, aber es gibt 2 Bootstrap-Implementierungen
  - `--setup` flag existiert nicht
  - `--truth-verify` flag existiert nicht

## ❌ 4. Capsule System: Nicht in TUI oder CLI sichtbar
- [ ] `bkg capsule status` zeigt keine CapsuleEngine-Informationen
- [ ] CapsuleZustand (Healthy/Degraded/Missing) nicht im Dashboard
- [ ] Self-Healing wird nie automatisch ausgelöst
- [ ] Rehydration nur beim Boot, nie manuell triggerbar

## ❌ 5. Trust Layer: Nicht benutzbar
- [ ] `bkg verify run` existiert als Befehl, aber:
  - Keine Verbindung zu Katoptron
  - Kein Drift-Report sichtbar
  - Keine Automatische Heilung beim Start

## ❌ 6. SWD: Nicht benutzbar
- [ ] `bkg snapshot run` existiert als Befehl, aber:
  - Keine SWD-Integration in Agent-Execution
  - Kein Write-Protection-Monitoring

## ❌ 7. Managed Agents: Keine Model-Routing-Integration
- [ ] 6 Presets existieren, aber:
  - Kein Model-Routing (alle nutzen dasselbe Model)
  - Keine Budget-Integration mit Provider-Kosten
  - Keine Provider-spezifischen Optimierungen

## ❌ 8. main.rs: Veraltete Provider-Init
- [ ] Nutzt `bkg_provider::registry::ProviderRegistry` statt `bkg-core` Bootstrap
- [ ] 2 parallele Provider-Systeme (bkg-provider crate vs bkg-core::bootstrap)
- [ ] `register_defaults()` erzeugt NVIDIA als Default trotz BKG_DEFAULT_PROVIDER

---

## ✅ WAS BEREITS FUNKTIONIERT

| Feature | Status | 
|---------|--------|
| CLI Framework (clap) | ✅ Komplett |
| Alle 15 CLI Commands | ✅ Registriert |
| NVIDIA Provider | ✅ API-kompatibel |
| Ollama Provider | ✅ API-kompatibel |
| Tool System (9 Tools) | ✅ Voll implementiert |
| Agent Loop | ✅ Tool-Using Cycle |
| Budget Tracking | ✅ MetricsStore |
| Session Management | ✅ UUID-basiert |
| Memory System | ✅ MEMORY.md |
| Skills System | ✅ 4 Skills |
| Bootstrap Phases | ✅ 6 Phasen |
| CapsuleEngine | ✅ rehydration + self_heal |
| ProviderRegistry (bkg-core) | ✅ ProviderKind + Metadata |
| ModelCatalog | ✅ discover + get_default |
| SetupWizard | ✅ dialoguer-basiert |
| 236 Tests | ✅ Bestanden |
| Build (core) | ✅ Sauber |

---

## 🔥 PRIORITÄTEN

1. **Ollama als Local Orchestrator** (nicht nur Provider) — Model-Routing + Task-Dispatch
2. **TUI mit Atlantean + Capsule + Trust + SWD + Healing** — Einziges echtes UI
3. **Bootstrap in main.rs** — Nur EIN Bootstrap-System
4. **Setup-Wizard fix** — Nur beim ersten Start
5. **Trust Layer in CLI** — verify + heal commands
6. **Managed Agents mit Model-Routing** — Provider-spezifische Presets