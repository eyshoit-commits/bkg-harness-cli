# Ralph Loop Configuration for Anti-Speculum-Tamper-Protokoll (ASTP v1)

This file configures the Ralph autonomous agent to work on implementing the ASTP crate and integrating it into the bKG framework.

## Goal
Implement the Anti-Speculum-Tamper-Protokoll (ASTP v1) specification as outlined in:
`docs/superpowers/plans/2026-05-24-anti-speculum-tamper-protocol.md`

## Tasks
The tasks are defined in the plan file and broken down in:
`plans/astp_production_plan.md`

Each task should be executed as a separate Ralph loop iteration or as part of a larger development branch.

## Phases
1. **Crate Creation & Core Types** (Tasks 1-2)
   - Scaffold bkg-speculum crate
   - Implement Event, EventNode, IntegrityState, hash computation
   - Build SpeculumTree with insert, genesis guard, tamper detection, subtree cut, fork detection

2. **Integration & Bridging** (Tasks 3-6)
   - Create integration with bkg-events (event taxonomy)
   - Build causality bridge to bkg-kernel::causality
   - Implement AntiSpeculumLayer, IsolationLayer, IntegrityWatcher

3. **Testing & Verification** (Task 7-10)
   - Write unit and integration tests
   - Run full test suite
   - Verify compilation and no regressions

4. **Production Readiness** (Tasks 11+)
   - Add CI, documentation, examples
   - Prepare for release

## Completion Criteria
- All tests pass: `cargo test -p bkg-speculum`
- Workspace builds: `cargo build`
- No clippy warnings: `cargo clippy -- -D warnings`
- Documentation generated: `cargo doc --no-deps --open`

## Ralph-Specific Settings
- Max iterations per task: 5
- Rotation strategy: round-robin across task types (coding, testing, docs)
- Verification: after each task, run relevant test subset

## Notes
This RALPH.md is intended to be used with the `/ralph` or `/ralph-draft` commands in the pi coding agent.
It assumes the existence of the plan and tasks as outlined above.
When a task is complete, Ralph should update the plan file or create a PR for review.