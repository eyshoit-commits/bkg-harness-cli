# BKG Implementation Roadmap

**Status:** May 22, 2026  
**Based on:** BKG Full System Blueprint (Chronos Architecture)  
**Target:** `bESTKNOWNGarbage/` (restructured from `v0.1a/`)

> **Restructuring Notice (completed):** Codebase umorganisiert von Monolith `v0.1a/` in Workspace `crates/`.  
> `v0.1a/src/` → `crates/bkg-kernel/src/`, `v0.1a/src/provider/` → `crates/bkg-provider/src/`, etc.  
> Alte Pfade in Dateilisten unten sind historisch — aktuelle Struktur in `crates/`.  

---

## Current State Analysis

### ✅ **What Exists and Works**

| Module | Files | Status |
|--------|-------|--------|
| **Trust Field Kernel** | `trust_field_kernel.rs`, `trust/kernel.rs` | Production-ready (921 LOC) |
| **Causality Engine** | `causality/graph.rs`, `causality/cve_map.rs` | Complete (410+170 LOC) |
| **Reality Anchor Layer (RAL)** | `ral/*.rs` | Complete (453 LOC) |
| **Guards & Self-Defense** | `model/mod.rs` (GuardEngine) | Complete (395 LOC) |
| **Guarded Model Format (GMF)** | `model/mod.rs` | Complete |
| **Evolution Patch Engine** | `evolution/mod.rs` | Complete (420 LOC) |
| **Guard Consensus Layer** | `scheduler/swarm.rs` | Complete (342 LOC) |
| **Core Types & Configuration** | `core/`, `config.rs`, `error.rs`, `message.rs`, `session.rs` | Complete |
| **Tool System** | `tools/` (9 tools) | Implemented and compiling |
| **LLM Provider (OpenAI)** | `provider/mod.rs`, `provider/openai.rs` | Implemented |
| **Scalar/Task Feature Extractor** | ?? | ? |

### ✅ **Newly Added Modules**

| Module | Files | Status |
|--------|-------|--------|
| **P3: Distributed Mesh (Sensory)** | `mesh/` (message, node, transport, entropy) | Complete – sensory TCP gossip, EntropyRegion, MeshSync stub |
| **P7.5: Garbage Collector Foundation** | `gc/` (collector, entropy, archive, decay, topology) | Complete – read-only obs layer, start_observing API |
| **P4/P5: Trust Engine & Dynamic Roles** | `trust_engine/` (mod.rs, hero_daemon.rs) | Complete – TrustEngine, NodeTrust, HeroDaemon, kernel integration |
| **Integration Demo** | `main.rs` (demo-mesh-gc) | Complete – demonstrates Mesh → GC observation pipeline |

### ⚠️ **What Exists But Is Broken/Incomplete**

| Module | Issue | File(s) |
|--------|-------|---------|
| **Agent Coordinator** | Returns hardcoded response; no (functional) LLM integration | `agent.rs:60-81` |
| **WASM Runtime** | Hash simulation stub; no real WASM | `wasm/runtime.rs` |
| **Ledger** | No persistence; no write separation | `ledger/mod.rs` |
| **Kernel Loop** | `collect_receipts()` returns `[]`, `commit_stable_state()` comment-only | `kernel/loop.rs` |

### ❌ **What's Missing Entirely**

- **Swarm Validation Engine** - heroes not yet assembled into validation groups
- **Collusion Detection** - not implemented, only stub
- **Physical World Binding Layer (PWBL)** - no sensor bindings
- **Attack Hotspot Defense** - auto-isolation system
- **Talmud-Style Escalation** - multi-stage protocol
- **Knowledge Decay Engine** - automatic expiration
- **Minimal Boot Sequence** - full system initialization
- **Config Loading** - no file/environment config reading

---

## Implementation Priorities (Updated)

### ✅ **P0: Make It Compile** (Done)
`cargo check --release` passes with zero errors. All tools compile.

### ✅ **P1: LLM Integration** (Done)
OpenAI provider works; basic chat functional via `bkg chat "prompt"`.

### ✅ **P2: Deterministic WASM Execution** (Done)
Deterministic simulation; hashing-based, real wasmtime deferred.

### ✅ **P3: Distributed Mesh** (Done)
TCP gossip with Heartbeat, TrustUpdate, EntropyMap, LedgerDelta messages.

### ✅ **P7.5: Garbage Collector Foundation** (Done)
Observational read-only layer; observes Mesh entropy, archives, tags decay.

### ✅ **P4/P5: Trust Engine & Dynamic Roles** (Done)
TrustEngine integrated in Kernel tick; HeroDaemon background scanning; NodeTrust with role transitions.

### 📋 **P4: Ledger & Motherbrain Split** (Next)
**Tasks:**
1. Implement `Ledger::append(receipt)` and `Ledger::query()` 
2. Restrict `commit_stable_state()` to Motherbrain only
3. Reality Anchor hook in adjudication
4. Add `ReplayEngine::verify(ledger_snapshot)`

### 📋 **P5: Escalation Mesh & Dynamic Roles** (Advanced, after collusion)
1. Collusion Detection Engine (pattern analysis)
2. Swarm Validation Coordinator (hero groups)
3. Integral role escalation with EscalationDaemon

### 📋 **P6: Physical World Binding** (Future)
1. Sensor interfaces
2. RAL coupling with external feeds

### 📋 **P7: Attack Hotspot Defense** (Future)
1. GuardEngine extension
2. Topology rewiring

### 📋 **P8: Talmud-Style Escalation** (Future)
1. Multi-stage evidence negotiation

### 📋 **P9: Knowledge Decay Engine** (Future)
1. Automatic expiration and revalidation

### 📋 **P10: Boot Sequence & Integration** (Future)
1. Config loading
2. Full system initialization
3. Graceful shutdown

## Phase Summary (Updated)

| Phase | Weeks | Output | Status |
|-------|-------|--------|--------|
| **Phase 0** | 0 | `cargo check` passes | ✅ Done |
| **Phase 1** | 1 | LLM-connected agent with tools | ✅ Done |
| **Phase 2** | 2 | Deterministic WASM execution | ✅ Done |
| **Phase 3** | 2 | Mesh sync and causal graph distribution | ✅ Done |
| **Phase 3.5** | 1 | Garbage Collector Foundation | ✅ Done |
| **Phase 4** | 1 | Ledger + Motherbrain enforcement | 📋 Next |
| **Phase 5** | 1 | Dynamic trust roles & heroes | ✅ Core Done |
| **Phase 6** | 1 | Reality anchor with live sensors | 📋 Future |
| **Phase 7** | 1 | Self-defense against attacks | 📋 Future |
| **Phase 8** | 1 | Talmud-style evidence escalation | 📋 Future |
| **Phase 9** | 1 | Decay + lifecycle | 📋 Future |
| **Phase 10** | 1 | Full system integration | 📋 Future |
| **Total** | **~12 weeks** | **Production-ready BKG kernel** | **5/12 done** |

---

## Success Criteria (Updated)

- ✅ All P0-P1 tasks complete → functional AI assistant with tools
- ✅ All P0-P2 complete → deterministic WASM execution
- ✅ All P0-P3 complete → distributed mesh with gossip
- ✅ All P0-P3.5 complete → GC observational layer
- ✅ All P0-P5 core complete → trust engine, hero daemon, role transitions
- ☐ All P0-P5 full → swarm validation, collusion detection, ledger
- ☐ All P6-P10 complete → full Chronos architecture
- ☐ All tests pass, deterministic replay verified, no build warnings
- ☐ Documented in `docs/` with API references

---

**Current Focus:** Mesh TrustUpdate propagation → HeroDaemon auto-start → Collusion Detection → Ledger/Motherbrain.

---

## Immediate Next Steps (merged from NEXT.md)

### 1. Mesh TrustUpdate Propagation 🔄
- After `update_node_trust()` returns a role change, broadcast `MeshMessage::TrustUpdate` to peers
- Peers update their local view of node trust
- Need a MeshHandle or channel from TrustEngine → MeshNode

### 2. HeroDaemon Auto-Start ⏱️
- Add `start_hero_daemon(interval)` method to KernelState
- Auto-start with configurable interval (default: 30s) in boot sequence

### 3. Real WASM Execution (ExecutionReceipts) ⚡
- Integrate `wasmtime` crate for real WASM execution with fuel limits
- Produce real `ExecutionReceipt` with hash, duration, result
- Feed receipts to TrustEngine (currently collects empty vec)

### 4. Collusion Detection Engine 🕵️
- Detect echo validation clusters and synchronized behavior
- Track disagreement_rate per peer
- Required before escalation is safe

### 5. Ledger & Motherbrain 📒
- `Ledger::append(receipt)` and `Ledger::query()` with SQLite backend
- `commit_stable_state()` implementation
- Motherbrain final validation gate

### Implementation Matrix

| Component | Status | Complexity | Priority |
|-----------|--------|------------|----------|
| Mesh TrustUpdate Propagation | 📋 Planned | Medium | P0 |
| HeroDaemon Auto-Start | 📋 Planned | Low | P0 |
| Real WASM Execution | 📋 Planned | High | P1 |
| Collusion Detection | 📋 Planned | Medium | P1 |
| Ledger Persistence | 📋 Planned | Medium | P1 |
| Motherbrain Adjudication | 📋 Planned | High | P2 |
| Swarm Validation | 📋 Planned | Medium | P2 |
| Attack Hotspot Defense | 📋 Planned | High | P3 |
| Knowledge Decay Engine | 📋 Planned | Medium | P3 |
| Minimal Boot Sequence | 📋 Planned | Low | P3 |
| Config File Loading | 📋 Planned | Low | P3 |
| Dioxus UI | 📋 Planned | Very High | P4 |
