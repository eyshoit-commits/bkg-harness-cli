# Dynamic Model Routing Enhancement with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enhance the BKG dynamic model routing system to operate as a Telum realm (deterministic execution) component that enforces strict realm-boundary rules, uses explicit causal contracts for all cross-realm interactions, and emits timeline events for deterministic replay, making model routing an active deterministic execution mechanism within fixed realm boundaries.

**Architecture:** Transform the model router into a realm-bound Telum realm component that:
1. Operates exclusively within the Telum realm boundaries (deterministic execution)
2. Enforces strict ownership rules (no cross-realm resource access without explicit contracts)
3. Provides model routing services via explicit contracts to agent execution (Telum internal) and other realms
4. Emits timeline events for all routing decisions and model operations
5. Uses explicit contracts for cross-realm interactions (Speculum for trust, Mensa for memory, etc.)
6. Maintains deterministic routing with execution seeds for replayability
7. Enforces the Realm-Binding principle that the model router belongs exclusively to the Telum realm

**Tech Stack:** Rust, existing model_router module, bkg-kernel::realm_system, bkg-kernel::timeline

---

### Task 1: Analyze current model routing implementation with Realm-Binding lens

**Files:**
- Read: `crates/bkg-cli/src/model_router.rs` (current model router implementation)
- Read: `projects/bkg-client/crates/bkg-provider/src/ollama.rs` (how model_router is used)
- Read: `crates/bkg-cli/src/agent.rs` (how ChainBuilder uses model routing)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-kernel/src/timeline/` (timeline event system)
- Read: `crates/bkg-kernel/src/trust/kernel.rs` (trust kernel for Speculum realm interactions)
- Read: `crates/bkg-swd/src/lib.rs` (SWD for Mensa realm interactions)

- [ ] **Step 1: Understand current model router capabilities**

```rust
// Review model_router.rs to understand:
// - Current routing logic (planner→largest, coder→medium coding-specialized, etc.)
// - How model capabilities are determined
// - How model sizes are categorized (smallest, medium, largest)
// - What information is available about models
// - Current realm assignment (if any)
// - Missing explicit contract usage for cross-realm interactions
```

- [ ] **Step 2: Understand how model_router is currently used**

```rust
// Review ollama.rs and agent.rs to see:
// - How ChainBuilder uses model_router for task routing
// - How the selected model is actually used for inference
// - What feedback, if any, is provided back to the router
// - Whether model_router (Telum realm) directly accesses trust kernel (Speculum realm)
// - Whether model_router directly accesses SWD (Mensa realm)
// - Missing explicit contract usage for cross-realm interactions
```

- [ ] **Step 3: Understand Telum realm definition and boundaries**

```rust
// Review realm system to see:
// - Telum realm definition: deterministic execution
// - What subsystems belong to Telum (tool execution, model routing, chain building)
// - Realm ownership rules: Telum subsystems MAY NOT access resources outside Telum without explicit contracts
// - Fixed realm boundaries: clear separation from Causa (state), Speculum (truth), Mensa (memory)
// - Causal transition contracts: explicit protocols for Telum ↔ Speculum, Telum ↔ Mensa, etc.
// - Missing enforcement that model router belongs exclusively to Telum realm
```

- [ ] **Step 4: Identify Realm-Binding gaps in current model routing implementation**

```rust
// Determine what's missing for Realm-Binding compliance:
// - No explicit realm ownership declaration (should be Telum)
// - No boundary validation when accessing trust kernel (Speculum realm) for trust-aware routing
// - No boundary validation when accessing SWD (Mensa realm) for model persistence
// - No boundary validation when accessing timeline/event system (Mensa realm)
// - No explicit contract usage for cross-realm interactions
// - No timeline event emission for routing decisions and model operations
// - No execution seeds for deterministic routing replay
// - Model router not operating as a pure Telum realm component
// - Missing deterministic execution guarantees for Telum realm
```

- [ ] **Step 5: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-dynamic-model-routing-enhancement.md
git commit -m "feat(model-routing-realm-binding): analyze current model routing implementation and realm boundaries for realm-binding compliant deterministic execution"
```

### Task 2: Design realm-bound model router with Telum realm enforcement

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`
- Create: `crates/bkg-cli/src/model_router_realm_binding.rs` (model router realm binding layer)

- [ ] **Step 1: Declare explicit Telum realm ownership**

```rust
// Add explicit realm ownership to model router:
// - Add realm annotation: #[realm(Telum)]
// - Add ownership verification at initialization
// - Add boundary checks for all external resource access
// - Document that model router belongs exclusively to Telum realm
// - Model router MAY NOT access resources outside Telum without explicit contracts
```

- [ ] **Step 2: Design Telum realm boundary enforcement**

```rust
// Design boundary checks for all external interactions:
// - Trust kernel access (Speculum realm): require explicit TrustContract
// - SWD access (Mensa realm): require explicit SWDContract
// - Timeline/event system access (Mensa realm): require explicit TimelineContract
// - Capsule store access (Causa realm): require explicit CapsuleContract
// - Healing daemon access (Speculum realm): require explicit HealingContract
// - All boundary crossings must use approved causal transition contracts
// - No direct access permitted - all must go through explicit contracts
```

- [ ] **Step 3: Design explicit causal contract usage**

```rust
// Design how to use explicit contracts for cross-realm interactions:
// - Trust evaluation: use TrustContract::evaluate() instead of direct kernel access
// - Model persistence: use SWDContract::persist() instead of direct SWD access
// - Timeline events: use TimelineContract::emit() instead of direct event emission
// - State queries: use CapsuleContract::query() instead of direct capsule access
// - Healing queries: use HealingContract::query() instead of direct healing access
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
//   * Emit compliance timeline events
//   * Include ExecutionSeed for deterministic replay
```

- [ ] **Step 4: Design deterministic model routing with execution seeds**

```rust
// Design model routing that produces replayable outcomes:
// - Generate ExecutionSeed for each routing decision:
//   * policy_hash: current Mutatio realm policy snapshot
//   * model_hash: selected model's content hash
//   * routing_hash: hash of routing inputs and Telum realm state
//   * timestamp_epoch: deterministic timestamp
// - Include ExecutionSeed in all timeline events
// - Make routing decisions purely deterministic based on inputs + ExecutionSeed
// - Ensure identical inputs always produce identical routing decisions
// - No external state influences routing decisions
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/model_router.rs
git commit -m "feat(model-routing-realm-binding): design telum realm-bound model router with boundary enforcement and explicit contracts"
```

### Task 3: Implement Telum realm ownership declaration and boundary system

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`
- Create: `crates/bkg-cli/src/model_router_realm_binding.rs`

- [ ] **Step 1: Add explicit Telum realm ownership**

```rust
// In model_router.rs:
// - Add realm ownership declaration: #[realm(Telum)]
// - Add ownership verification in new() or init()
// - Add runtime boundary checks for all external calls
// - Add methods to verify current realm assignment
// - Log realm ownership verification on initialization
// - Reject any direct access from outside Telum realm without contract
```

- [ ] **Step 2: Implement realm boundary validation system**

```rust
// Create model_router_realm_binding.rs with:
// - ModelRouterContract struct that validates all model router access
// - TrustAccessContract for Speculum realm interactions (trust-aware routing)
// - SWDAccessContract for Mensa realm interactions (model persistence)
// - TimelineAccessContract for Mensa realm interactions (timeline emission)
// - CapsuleAccessContract for Causa realm interactions (state queries)
// - HealingAccessContract for Speculum realm interactions (healing queries)
// - Each contract validates:
//   * Caller is in Telum realm
//   * Access is permitted by explicit contract
//   * Contract version is compatible
//   * Policy snapshot is recorded
//   * ExecutionSeed is included where applicable
```

- [ ] **Step 3: Commit realm ownership and boundary system**

```bash
git add crates/bkg-cli/src/model_router.rs crates/bkg-cli/src/model_router_realm_binding.rs
git commit -m "feat(model-routing-realm-binding): implement telum realm ownership declaration and boundary validation system"
```

### Task 4: Implement explicit causal contract usage for cross-realm interactions

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`
- Modify: `crates/bkg-cli/src/model_router_realm_binding.rs`

- [ ] **Step 1: Replace direct trust kernel access with TrustContract**

```rust
// Instead of direct trust kernel calls:
// OLD: trust_kernel.evaluate(...)
// NEW: TrustContract::evaluate(trust_kernel, ...)
// Where TrustContract:
//   * Validates Telum realm boundary for caller
//   * Validates Speculum realm boundary for trust kernel
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns trust decision
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 2: Replace direct SWD access with SWDContract**

```rust
// Instead of direct SWD calls:
// OLD: swd.snapshot(...) or swd.apply(...)
// NEW: SWDContract::execute(swd, operation, ...)
// Where SWDContract:
//   * Validates Telum realm boundary for caller
//   * Validates Mensa realm boundary for SWD
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns operation result
//   * Includes ExecutionSeed in timeline event
//   * Ensures operation goes through SWD (no direct filesystem access)
//```

- [ ] **Step 3: Replace direct timeline access with TimelineContract**

```rust
// Instead of direct event emission:
// OLD: event_bus.publish(...)
// NEW: TimelineContract::emit(event_bus, ...)
// Where TimelineContract:
//   * Validates Telum realm boundary for emission
//   * Includes ExecutionSeed in event
//   * Ensures deterministic event ordering
//   * Records policy snapshot context
```

- [ ] **Step 4: Replace direct capsule store access with CapsuleContract**

```rust
// Instead of direct capsule store calls:
// OLD: capsule_store.get_state(...)
// NEW: CapsuleContract::query(capsule_store, ...)
// Where CapsuleContract:
//   * Validates Telum realm boundary for caller
//   * Validates Causa realm boundary for capsule store
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns capsule state
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 5: Replace direct healing daemon access with HealingContract**

```rust
// Instead of direct healing daemon calls:
// OLD: healing_daemon.query(...)
// NEW: HealingContract::query(healing_daemon, ...)
// Where HealingContract:
//   * Validates Telum realm boundary for caller
//   * Validates Speculum realm boundary for healing daemon
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns healing information
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 6: Implement contract versioning and compliance tracking**

```rust
// Add contract system that:
// - Tracks contract versions used
// - Validates contract compatibility
// - Monitors for contract violations
// - Emits contract compliance timeline events
// - Provides debugging information for contract usage
// - Ensures all cross-realm model router interactions use explicit contracts
```

- [ ] **Step 7: Commit causal contract implementation**

```bash
git add crates/bkg-cli/src/model_router.rs crates/bkg-cli/src/model_router_realm_binding.rs
git commit -m "feat(model-routing-realm-binding): implement explicit causal contract usage for all cross-realm interactions"
```

### Task 5: Implement deterministic model routing with execution seeds

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`
- Modify: `crates/bkg-cli/src/model_router_realm_binding.rs`

- [ ] **Step 1: Add ExecutionSeed generation to model routing**

```rust
// In model selection process:
// - Generate ExecutionSeed before routing decision:
//   * policy_hash: get_current_mutatio_policy_snapshot()
//   * model_hash: get_selected_model_content_hash()
//   * routing_hash: hash(route_inputs, current_telum_state, trust_decision if used)
//   * timestamp_epoch: get_deterministic_timestamp()
// - Make routing decision purely function of inputs + ExecutionSeed
// - Store ExecutionSeed with routing decision
```

- [ ] **Step 2: Include ExecutionSeed in all timeline events**

```rust
// For every timeline event emitted:
// - Include ExecutionSeed from routing decision that caused the event
// - Ensure events are deterministic replay triggers
// - Allow reconstruction of exact model selection context
```

- [ ] **Step 3: Ensure deterministic routing behavior**

```rust
// Guarantee that:
// - Identical inputs + ExecutionSeed → identical model selection
// - No external state influences routing decisions
// - All randomness is seeded deterministically
// - Routing is pure function of (inputs, ExecutionSeed)
// - Telum realm execution purity is maintained
```

- [ ] **Step 4: Commit deterministic routing implementation**

```bash
git add crates/bkg-cli/src/model_router.rs crates/bkg-cli/src/model_router_realm_binding.rs
git commit -m "feat(model-routing-realm-binding): implement deterministic model routing with execution seeds for replayability"
```

### Task 6: Implement realm-specific Telum execution guarantees

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`

- [ ] **Step 1: Add Telum execution purity checks**

```rust
// Add verification that:
// - All model router operations are deterministic executions
// - No hidden state mutations occur
// - All side effects are captured via explicit contracts
// - Execution time is bounded and predictable
// - Resource usage is deterministic and reportable
```

- [ ] **Step 2: Implement Telum realm execution logging**

```rust
// Add logging that shows:
// - Telum realm execution entry/exit
// - Contract usage for cross-realm interactions
// - ExecutionSeed for each operation
// - Resource consumption deterministically
// - Any boundary violations (should never occur in production)
```

- [ ] **Step 3: Commit Telum execution guarantees**

```bash
git add crates/bkg-cli/src/model_router.rs
git commit -m "feat(model-routing-realm-binding): implement telum realm execution purity checks and deterministic logging"
```

### Task 7: Verify realm-bound model router functionality

**Files:**
- Modify: `crates/bkg-cli/src/model_router.rs`
- Modify: `crates/bkg-cli/src/model_router_realm_binding.rs`

- [ ] **Step 1: Test Telum realm ownership verification**

```bash
// Test that:
// - Model router correctly declares #[realm(Telum)]
// - Ownership verification passes at initialization
// - Runtime boundary checks are active
// - No subsystem outside Telum can incorrectly claim model router ownership
```

- [ ] **Step 2: Test Telum realm boundary enforcement**

```bash
// Test that:
// - Trust kernel access requires TrustContract
// - SWD access requires SWDContract
// - Timeline access requires TimelineContract
// - Capsule store access requires CapsuleContract
// - Healing daemon access requires HealingContract
// - Direct access without contracts is blocked/logged
// - Contract violations are detected and reported
// - Approved contracts function correctly
```

- [ ] **Step 3: Test explicit causal contract usage**

```bash
// Test that:
// - All cross-realm interactions use explicit contracts
// - Contract versions are tracked and validated
// - Policy snapshot hashes are included in timeline events
// - ExecutionSeeds are included in model router-related timeline events
// - Contract compliance events are emitted
// - Deterministic behavior is maintained
```

- [ ] **Step 4: Test deterministic model routing with execution seeds**

```bash
// Test that:
// - Identical inputs produce identical ExecutionSeeds
// - Identical inputs + ExecutionSeed produce identical model selections
// - ExecutionSeeds are included in all relevant timeline events
// - Timeline events are deterministic replay triggers
// - No non-deterministic influences on routing
```

- [ ] **Step 5: Test Telum execution purity**

```bash
// Test that:
// - All operations are deterministic executions
// - Side effects are captured via explicit contracts
// - No hidden state mutations occur outside contracts
// - Resource usage is deterministic and reportable
// - Realm execution logging shows proper Telum behavior
```

- [ ] **Step 6: Commit verification**

```bash
git add crates/bkg-cli/src/model_router.rs crates/bkg-cli/src/model_router_realm_binding.rs
git commit -m "feat(model-routing-realm-binding): verify telum realm-bound model router with comprehensive testing"
```
