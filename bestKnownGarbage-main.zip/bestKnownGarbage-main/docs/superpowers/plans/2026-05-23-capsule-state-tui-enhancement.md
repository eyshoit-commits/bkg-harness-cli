# CapsuleState TUI Enhancement with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enhance the BKG TUI to provide a dedicated CapsuleState view that shows detailed capsule information within the Causa realm (persistent state), enforcing strict realm-boundary rules where capsules belong exclusively to the Causa realm and all interactions follow explicit causal contracts.

**Architecture:** Add a new tab to the TUI specifically for displaying detailed capsule information in the Causa realm, with strict enforcement of realm ownership (no direct capsule manipulation from other realms) and explicit causal contracts for all cross-realm interactions, emitting timeline events for deterministic replay.

**Tech Stack:** Rust, ratatui, crossterm, bkg-kernel::realm_system, bkg-capsule::

---

### Task 1: Analyze current capsule state display and realm boundaries

**Files:**
- Read: `crates/bkg-cli/src/tui/app.rs` (specifically capsule state handling)
- Read: `crates/bkg-cli/src/tui/status.rs` (CapsuleEvent definitions)
- Read: `crates/bkg-cli/src/capsule/` (capsule implementation)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-cli/src/tui/atlantean.rs` (Atlantean styling)

- [ ] **Step 1: Understand current capsule state tracking in TUI**

```rust
// Review how capsule state is currently tracked and displayed:
// - CapsuleEventKind enum in status.rs
// - Capsule event processing in TuiApp::drain_events()
// - Capsule state summary in render_config()
//- Capsule events in agent log (render_agents())
```

- [ ] **Step 2: Review capsule implementation details**

```rust
// Examine the capsule system to understand what information is available:
// - CapsuleStore and its methods
// - Capsule properties (id, state, healthy, created_at, etc.)
// - Available operations (list, create, repair, etc.)
// - Which realm capsules belong to (should be Causa)
```

- [ ] **Step 3: Understand realm system and Causa realm boundaries**

```rust
// Review realm system to see:
// - Causa realm definition: persistent state
// - What subsystems belong to Causa (capsule store, SWD timeline, persistent storage)
// - Realm ownership rules: Causa subsystems MAY NOT access resources outside Causa without explicit contracts
// - Fixed realm boundaries: clear separation from Aevum (runtime), Telum (execution), etc.
// - Causal transition contracts: explicit protocols for Causa ↔ Telum, Causa ↔ Speculum, etc.
```

- [ ] **Step 4: Identify what's missing for Realm-Binding compliant capsule view**

```rust
// Determine what capsule information would be valuable to display while enforcing Realm-Binding:
// - Individual capsule details (state, health, timestamps) - Causa realm data
// - Capsule histories or change logs - Mensa realm (immutable memory)
// - Repair/rehydration capabilities - require Telum ↔ Speculum contracts
// - Storage usage or content summaries - Causa realm
// - Ownership verification: prove capsules are in Causa realm
// - Contract validation: show explicit contracts used for interactions
```

- [ ] **Step 5: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-capsule-state-tui-enhancement.md
git commit -m "feat(capsule-tui-realm-binding): analyze current capsule state display and realm boundaries for realm-binding compliant implementation"
```

### Task 2: Design dedicated capsule state tab with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Plan new tab integration with realm ownership**

```rust
// Design how to add a new tab:
// - Add to tab_titles array with proper realm labeling
// - Add handling in render_* functions match statement
// - Add state tracking for capsule detailed view
// - Declare tab as belonging to Causa realm: #[realm(Causa)]
// - Ensure all capsule interactions follow Causa realm rules
```

- [ ] **Step 2: Design capsule detailed view layout with Realm-Binding**

```rust
// Plan what information to show in the capsule tab:
// - Header with Atlantean styling showing CAUSA realm (🧬 CAUSA)
// - Table or list of capsules with key properties:
//   * Capsule ID
//   * State (Healthy, Degraded, Missing, etc.) - Causa realm state
//   * Health status - Causa realm health
//   * Created/updated timestamps - Causa realm temporality
//   * Size or content info - Causa realm persistence
// - Detailed view for selected capsule:
//   * Full property list - Causa realm data
//   * History/changelog if available - Mensa realm access via contract
//   * Action buttons (repair, rehydrate, etc.) - require Telum/Speculum contracts
// - Summary statistics - Causa realm aggregation
// - Ownership verification badge - prove capsule is in Causa realm
// - Contract flow indicators - show explicit contracts used
```

- [ ] **Step 3: Plan Atlantean component usage with Causa realm semantics**

```rust
// Determine how to apply Atlantean design to capsule tab with Realm-Binding:
// - Use appropriate symbols (🧬 CAUSA for persistent state)
// - Use relevant colors for different states (green=healthy, yellow=degraded, red=missing)
// - Organize using Atlantean components with Causa semantics:
//   NUCLEUS: Capsule identity and realm ownership
//   PILLAR: Health and state vertical stacks
//   LINTEL: Realm separators and boundary markers (double lines for fixed bounds)
//   ORACLE: Truth/verification state (is capsule valid?)
//   PORTAL: Interaction hints for cross-realm contracts (repair requires Telum contract)
//   CHRONOS: Time-based elements (timestamps, duration)
// - Apply appropriate styles for different information types
// - Show realm boundary visualization
```

- [ ] **Step 4: Plan explicit causal contract usage**

```rust
// Design how to use explicit contracts for cross-realm interactions:
// - Capsule listing: pure Causa realm operation (no contracts needed)
// - Capsule detail view: pure Causa realm operation
// - History access: Causa → Mensa via MemoryContract
// - Repair operation: Causa → Telum via ExecutionContract + Speculum via TrustContract
// - Rehydrate operation: Causa → Telum via ExecutionContract + Speculum via TrustContract
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(capsule-tui-realm-binding): design dedicated capsule state tab with causa realm ownership and explicit causal contracts"
```

### Task 3: Implement capsule state tab infrastructure with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Add capsule tab with realm ownership declaration**

```rust
// Add "Capsules (Causa)" to tab_titles array
// Add handling for new tab index in render_* functions match statement
// Add necessary state fields to TuiApp for capsule tracking
// Declare tab as Causa realm: add realm ownership verification
// Ensure all capsule data accessed respects Causa realm boundaries
```

- [ ] **Step 2: Implement capsule data collection with realm verification**

```rust
// Add methods to:
// - Collect detailed capsule information from CapsuleStore (Causa realm)
// - Verify all accessed capsules are in Causa realm (ownership verification)
// - Format capsule data for display
// - Update capsule information periodically or on demand
// - Emit timeline events for realm viewing (TimelineContract)
// - Detect and report any realm ownership violations
```

- [ ] **Step 3: Implement basic capsule tab rendering with Realm-Binding**

```rust
// Create initial render_capsules function that shows:
// - Simple list of capsules with basic info
// - Atlantean-styled header showing CAUSA realm
// - Ownership verification badge for each capsule
// - Realm boundary visualization (double line separators)
// - Placeholder for detailed view with contract flow indicators
// - All interactions respect Causa realm boundaries
```

- [ ] **Step 4: Commit infrastructure**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(capsule-tui-realm-binding): implement capsule state tab infrastructure with causa realm ownership verification"
```

### Task 4: Implement detailed capsule view with Realm-Binding contracts

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Add capsule selection mechanism with realm awareness**

```rust
// Implement way to select a capsule for detailed view:
// - Keyboard navigation (up/down arrows)
// - Selection highlight
// - Enter key to toggle detailed view
// - All selection operations remain within Causa realm
// - Selection events emit timeline events via TimelineContract
```

- [ ] **Step 2: Implement detailed capsule information display with realm data**

```rust
// Create detailed view showing:
// - All available capsule properties (Causa realm data)
// - Formatted timestamps (Causa realm temporality)
// - Health status with Atlantean indicators (Causa realm health)
// - Available operations for the capsule (require explicit contracts)
// - Ownership verification: proof capsule is in Causa realm
// - History access notice: requires Mensa realm contract
// - Action requirements: show required contracts for each operation
```

- [ ] **Step 3: Implement capsule actions with explicit causal contracts**

```rust
// Add ability to perform actions on selected capsule:
// - Repair capsule: requires Telum ↔ Speculum contracts
//   * Use ExecutionContract for Telum access
//   * Use TrustContract for Speculum access
//   * Emit timeline events for all contract usage
// - View history/log if available: requires Mensa realm contract
//   * Use MemoryContract for Mensa realm access
//   * Emit timeline events for contract usage
// - Refresh capsule information: pure Causa realm operation
//   * No contracts needed
//   * Emit timeline events for realm viewing
// All actions must:
//   * Verify realm boundaries before execution
//   * Use explicit contracts for cross-realm interactions
//   * Emit timeline events showing contract usage
//   * Report any realm-binding violations
```

- [ ] **Step 4: Commit detailed view**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(capsule-tui-realm-binding): implement detailed capsule view with explicit causal contracts and realm ownership verification"
```

### Task 5: Apply Atlantean design principles to capsule tab with Causa realm semantics

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Apply Atlantean styling with Causa realm semantics**

```rust
// Ensure the capsule tab uses Atlantean design properly with Realm-Binding:
// - Appropriate symbols (🧬 CAUSA for persistent state)
// - Relevant colors for different states (green=healthy, yellow=degraded, red=missing, blue=repairing)
// - Proper use of Atlantean styles for headers, text, highlights
// - Atlantean component organization with Causa semantics:
//   * NUCLEUS: Shows capsule identity and Causa realm ownership
//   * PILLAR: Shows health and state as vertical stacks
//   * LINTEL: Shows realm boundaries as double separators
//   * ORACLE: Shows truth/verification state (is capsule valid?)
//   * PORTAL: Shows interaction hints for cross-realm contracts
//   * CHRONOS: Shows time-based elements (timestamps, duration)
// - Use of atlantean_title() for section headers with realm context
```

- [ ] **Step 2: Verify information hierarchy with Realm-Binding**

```rust
// Check that information is presented with proper visual hierarchy:
// - Most important information prominent (capsule ID, state, health)
// - Related information grouped (timestamps, size, content)
// - Realm ownership verification prominent
// - Contract requirements clearly shown for actions
// - Atlantean design principles followed for emphasis and flow
// - Realm boundary visualization clear (double lines, distinct coloring)
// - Ownership violations clearly marked (red borders, warning symbols)
// - Contract flow indicators visible (arrows, flow symbols)
```

- [ ] **Step 3: Commit Atlantean styling**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(capsule-tui-realm-binding): apply atlantean design principles with causa realm semantics and realm-binding enforcement"
```

### Task 6: Verify capsule tab functionality with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Test capsule tab integration with Realm-Binding**

```bash
// Test that:
// - New tab is accessible via keyboard shortcut
// - Tab is properly declared as Causa realm
// - Capsule list displays correctly with ownership verification
// - Selection and detailed view work within Causa realm
// - Actions require and use explicit contracts
// - Timeline events are emitted for all interactions
// - Realm boundary visualization is correct
// - Ownership verification shows correct Causa realm assignment
// - No capsule data is accessed outside Causa realm without contracts
```

- [ ] **Step 2: Test with various capsule states and Realm-Binding**

```bash
// Test functionality with:
// - Healthy capsules (green status, valid ownership)
// - Degraded capsules (yellow status, valid ownership)
// - Missing capsules (red status, valid ownership)
// - Empty capsule store (proper handling)
// - Attempted cross-realm access without contracts (should be blocked/logged)
// - Contract usage verification (correct contracts used for each operation)
// - Timeline event emission for all realm interactions
```

- [ ] **Step 3: Commit verification**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(capsule-tui-realm-binding): verify capsule tab functionality with realm-binding enforcement and explicit causal contracts"
```
