# Atlantean TUI Enhancement with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enhance the BKG TUI Config tab to display the causal realm topology of Reveland, transforming it from a simple information panel into a deterministic realm inspector that shows the current state of all realms with fixed boundaries and explicit causal contracts, enforcing the Realm-Binding principle that every subsystem belongs to exactly one realm.

**Architecture:** Transform the Config tab into a Realm-Rendering system that displays the six realms (Aevum, Causa, Telum, Speculum, Mutatio, Mensa) with their health, state, and active events, while visualizing realm boundaries and causal transition contracts between realms.

**Tech Stack:** Rust, ratatui, crossterm, bkg-kernel::realm_system

---

### Task 1: Analyze current Config tab and realm system with Realm-Binding lens

**Files:**
- Read: `crates/bkg-cli/src/tui/app.rs` (specifically render_config function)
- Read: `crates/bkg-cli/src/tui/atlantean.rs` (existing Atlantean styling)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-cli/src/tui/status.rs` (event definitions)

- [ ] **Step 1: Understand current Config tab rendering**

```rust
// Review render_config() in app.rs to see:
// - What information is currently displayed
// - How Atlantean styling is applied (symbols, colors, title helpers)
// - How data is organized in the current layout
```

- [ ] **Step 2: Understand realm system implementation with Realm-Binding**

```rust
// Review realm system to see:
// - Realm enum definition (Aevum, Causa, Telum, Speculum, Mutatio, Mensa)
// - Realm ownership rules: each subsystem belongs to exactly one realm
// - Fixed realm boundaries: no subsystem can exist outside its realm
// - Causal transition contracts: explicit protocols for cross-realm interactions
// - Realm health and state tracking mechanisms
```

- [ ] **Step 3: Identify Realm-Binding gaps for realm-rendering**

```rust
// Determine what realm information needs to be displayed to enforce Realm-Binding:
// - Current realm of each subsystem (to verify ownership)
// - Health status of each realm (0.0-1.0)
// - Current state/operation in each realm
// - Number of active events/timeline entries per realm
// - Visual representation of realm boundaries (to show fixed borders)
// - Recent causal transitions between realms (to show explicit contracts)
// - Violations of realm ownership (if any, for debugging)
```

- [ ] **Step 4: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-atlantean-tui-enhancement.md
git commit -m "feat(atlantean-tui-realm-binding): analyze current config tab and realm system for realm-rendering implementation with realm-binding principles"
```

### Task 2: Design realm-rendering for Config tab with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`
- Create: `crates/bkg-cli/src/tui/realm_view.rs` (new realm rendering component)

- [ ] **Step 1: Define realm ownership mapping according to Realm-Binding**

```rust
// Map each subsystem to its realm according to Reveland design WITH FIXED BOUNDARIES:
// - Aevum: runtime (agent execution loop) - OWNS: agent main loop, event processing
// - Causa: persistent state (capsule store, SWD timeline) - OWNS: capsule store, SWD snapshots, timeline events
// - Telum: deterministic execution (tool execution, model routing) - OWNS: tool execution, model routing, chain building
// - Speculum: truth + healing (trust kernel, healing daemon, verification) - OWNS: trust kernel, healing daemon, truth verification
// - Mutatio: future policy mutation (policy updates, learning, adaptation) - OWNS: policy system, learning mechanisms, adaptation logic
// - Mensa: immutable global memory (event timeline, audit logs, snapshots) - OWNS: timeline storage, snapshot archive, audit logs
//
// REALM-BINDING RULE: NO SUBSYSTEM MAY EXIST OUTSIDE ITS ASSIGNED REALM
```

- [ ] **Step 2: Design RealmStatus display component with Realm-Binding visualization**

```rust
// Design how to display each realm to enforce Realm-Binding:
// - Realm name with Atlantean symbol (AEVUM→🔥, CAUSA→🧬, TELUM→⚙️, SPECULUM→🔮, MUTATIO→🌱, MENSA→🗄)
// - Health bar or percentage (0.0-1.0) - SHOWS REALM VIABILITY
// - Current state string (ACTIVE, VERIFIED, EXECUTING, DRIFT, POLICY, HEALTHY) - SHOWS REALM OPERATION
// - Active event count - SHOWS REALM ACTIVITY
// - Visual realm boundary indicators (double lines, distinct coloring) - SHOWS FIXED BORDERS
// - Ownership verification badge - SHOWS SUBSYSTEM REALM ASSIGNMENT IS CORRECT
// - Causal transition indicators (arrows, flow symbols) - SHOWS EXPLICIT CONTRACTS
```

- [ ] **Step 3: Design causal contract visualization for Realm-Binding**

```rust
// Design how to show explicit causal contracts between realms to enforce Realm-Binding:
// - Timeline/event flow indicators showing direction of causality
// - Recent cross-realm interactions with contract validation status
// - Boundary enforcement notifications (when subsystems attempt cross-realm access)
// - Transition protocol displays (showing the explicit contracts being used)
// - Contract violation warnings (when realms interact without proper contracts)
```

- [ ] **Step 4: Plan Atlantean component usage for realms with Realm-Binding semantics**

```rust
// Assign Atlantean components to realm display with Realm-Binding meaning:
// - NUCLEUS: Core realm identity (realm name and symbol) - SHOWS REALM ESSENCE
// - PILLAR: Realm health and state vertical stacks - SHOWS REALM STRENGTH AND STATE
// - LINTEL: Realm separators and boundary markers - SHOWS FIXED BOUNDARIES BETWEEN REALMS
// - ORACLE: Truth/verification state displays - SHOWS REALM TRUTH VALIDITY
// - PORTAL: Interaction hints for cross-realm contracts - SHOWS APPROVED TRANSITION POINTS
// - CHRONOS: Time-based elements (uptime, last event timestamps) - SHOWS REALM TEMPORAL STATE
//
// REALM-BINDING PRINCIPLE: EACH ATLANTIAN COMPONENT REINFORCES REALM SOVEREIGNTY
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(atlantean-tui-realm-binding): design realm-rendering with fixed boundaries, causal contracts, and ownership verification"
```

### Task 3: Implement realm status collection with Realm-Binding verification

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`
- Create: `crates/bkg-cli/src/tui/realm_view.rs`

- [ ] **Step 1: Add realm status collection with ownership verification to TuiApp**

```rust
// Add methods to TuiApp to:
// - Query current realm of each subsystem (VERIFY OWNERSHIP)
// - Collect health metrics for each realm
// - Gather state information from realm systems
// - Count active events/timeline entries per realm
// - Detect realm ownership violations (SUBSYSTEM IN WRONG REALM)
// - Monitor causal transition usage (TRACK CONTRACT COMPLIANCE)
// - Cache realm status for efficient rendering
```

- [ ] **Step 2: Implement realm health calculation with Realm-Binding awareness**

```rust
// Implement health calculation for each realm:
// - Aevum: agent execution health, loop stability, event processing timeliness
// - Causa: capsule store integrity, SWD snapshot validity, timeline consistency
// - Telum: tool execution success rate, model routing determinism, chain execution fidelity
// - Speculum: trust kernel health, verification success rate, healing efficacy, truth accuracy
// - Mutatio: policy stability, learning convergence, adaptation success rate
// - Mensa: timeline integrity, snapshot availability, audit log completeness, historical fidelity
//
// HEALTH IS A MEASURE OF REALM SOVEREIGNTY AND INTERNAL CONSISTENCY
```

- [ ] **Step 3: Implement realm ownership verification**

```rust
// For each subsystem, verify:
// - It is executing within its assigned realm
// - Its resources are allocated to its realm
// - Its communications follow realm contracts
// - No unauthorized cross-realm access is occurring
//
// OWNERSHIP VIOLATIONS ARE REALM-BINDING VIOLATIONS
```

- [ ] **Step 4: Commit realm status collection**

```bash
git add crates/bkg-cli/src/tui/app.rs crates/bkg-cli/src/tui/realm_view.rs
git commit -m "feat(atlantean-tui-realm-binding): implement realm status collection with ownership verification and causal transition tracking"
```

### Task 4: Implement realm-rendering UI component with Realm-Binding visualization

**Files:**
- Create: `crates/bkg-cli/src/tui/realm_view.rs`
- Modify: `crates/bkg-cli/src/tui/app.rs` (to use realm view)

- [ ] **Step 1: Create RealmView component with Realm-Binding enforcement visualization**

```rust
// Create RealmView struct that:
// - Takes realm status data including ownership verification
// - Renders the six realms in a structured layout showing FIXED BOUNDARIES
// - Uses Atlantean styling consistently with realm-specific semantics
// - Shows realm boundaries visually (DOUBLE LINES, DISTINCT COLOR BANDS)
// - Displays health, state, and event counts for each realm
// - Visualizes causal transitions between realms (ARROWS, FLOW SYMBOLS)
// - Highlights ownership violations (RED BORDERS, WARNING SYMBOLS)
// - Shows contract compliance status (GREEN FOR VALID, RED FOR VIOLATIONS)
```

- [ ] **Step 2: Implement realm layout with Atlantean components and Realm-Binding semantics**

```rust
// Structure the realm display using Atlantean concepts WITH REALM-BINDING MEANING:
// - NUCLEUS for each realm: realm name + symbol (🔥 AEVUM) - SHOWS REALM IDENTITY
// - PILLAR for health/state: vertical health bar + state text - SHOWS REALM VITALITY
// - LINTEL between realms: DOUBLE separators showing FIXED BOUNDARY - SHOWS REALM SOVEREIGNTY
// - ORACLE for truth state: verification indicators where applicable - SHOWS REALM TRUTH
// - PORTAL for cross-realm hints: small arrows showing APPROVED TRANSITION POINTS - SHOWS EXPLICIT CONTRACTS
// - CHRONOS for time elements: last update timestamps - SHOWS REALM TEMPORAL STATE
// - BOUNDARY VIOLATION INDICATORS: flashing red when ownership violated - SHOWS BINDING BREAKS
// - CONTRACT FLOW INDICATORS: animated arrows showing causal direction - SHOWS TRANSITION USAGE
```

- [ ] **Step 3: Implement realm boundary visualization with Realm-Binding enforcement**

```rust
// Show fixed realm boundaries:
// - Visual DOUBLE separators between realms (unbreakable boundary)
// - Color-coding by realm health (green=healthy, yellow=degraded, red=critical)
// - Symbols indicating realm ownership (realm-specific icons)
// - Tooltips or detailed views on hover/focus showing SUBSYSTEM OWNERSHIP
// - Boundary breach warnings: pulsating red when subsystem detected in wrong realm
// - Contract validation indicators: show which transitions are currently valid
```

- [ ] **Step 4: Commit realm-rendering UI**

```bash
git add crates/bkg-cli/src/tui/realm_view.rs
git commit -m "feat(atlantean-tui-realm-binding): implement realm-rendering UI component with fixed boundary visualization and ownership verification"
```

### Task 5: Integrate realm-rendering into Config tab with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`

- [ ] **Step 1: Replace old config rendering with realm-rendering that enforces Realm-Binding**

```rust
// In render_config():
// - Remove old information display (provider, models, etc. - move to appropriate realm displays if needed)
// - Add RealmView rendering as primary content SHOWING REALM TOPOLOGY
// - Keep essential Atlantean elements (title, symbols) but reframe as realm context
// - Ensure layout uses proper Atlantean spacing and proportions SHOWING REALM SEPARATION
// - MAKE THE CONFIG TAB THE PRIMARY REALM-BINDING VERIFICATION TOOL
```

- [ ] **Step 2: Maintain essential information in proper realm contexts**

```rust
// Determine what essential info to keep and where it belongs according to Realm-Binding:
// - Current model/provider info → TELUM REALM (deterministic execution)
// - Trust/SWD status → SPECULUM/MENSA REALMS (truth and immutable memory)
// - Capsule health → CAUSA REALM (persistent state)
// - Healing status → SPECULUM REALM (truth + healing)
// - Policy information → MUTATIO REALM (future policy mutation)
// - Timeline/audit data → MENSA REALM (immutable global memory)
//
// EACH PIECE OF INFORMATION MUST APPEAR IN ITS CORRECT REALM DISPLAY
```

- [ ] **Step 3: Commit realm-rendering integration**

```bash
git add crates/bkg-cli/src/tui/app.rs
git commit -m "feat(atlantean-tui-realm-binding): integrate realm-rendering into config tab as realm-binding verification panel"
```

### Task 6: Implement causal contract event emission with Realm-Binding tracking

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`
- Modify: `crates/bkg-cli/src/tui/realm_view.rs`
- Modify: `crates/bkg-cli/src/event/` (timeline events if needed)

- [ ] **Step 1: Add timeline event emission for realm viewing with Realm-Binding context**

```rust
// When realm view is rendered or interacted with:
// - Emit RealmViewed timeline event
// - Include which realms were viewed
// - Include timestamp for causality tracking
// - Include realm health snapshot
// - Include ownership verification status
// - Include causal transition usage statistics
//
// EVENTS MUST SHOW REALM-BINDING COMPLIANCE
```

- [ ] **Step 2: Ensure realm interactions emit contract events with Realm-Binding semantics**

```rust
// If user interacts with realm view (e.g., requests details, attempts cross-realm action):
// - Emit appropriate timeline events showing intent
// - Emit RealmBoundaryTested event when user probes realm boundaries
// - Emit ContractValidationRequested event when user requests cross-realm interaction
// - Emit OwnershipVerified event when subsystem realm assignment confirmed
// - All events must contain policy snapshot hashes for replay integrity
// - Events must show whether actions respected realm-binding rules
```

- [ ] **Step 3: Commit causal contract integration**

```bash
git add crates/bkg-cli/src/tui/app.rs crates/bkg-cli/src/tui/realm_view.rs
git commit -m "feat(atlantean-tui-realm-binding): implement causal contract event emission with realm-binding compliance tracking"
```

### Task 7: Verify realm-rendering functionality with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/tui/app.rs`
- Modify: `crates/bkg-cli/src/tui/realm_view.rs`

- [ ] **Step 1: Test realm display accuracy with Realm-Binding**

```rust
// Test that:
// - All six realms are displayed correctly with proper symbols
// - Realm health reflects actual subsystem states
// - Realm state strings match current operations
// - Active event counts are accurate
// - Realm symbols and colors are correct per realm semantics
// - Ownership verification shows correct subsystem assignments
// - Boundary visualization shows fixed realm separators
```

- [ ] **Step 2: Test realm boundary visualization and enforcement**

```rust
// Test that:
// - Realm boundaries are visually distinct (DOUBLE LINES)
// - Health-based color coding works correctly (green/yellow/red)
// - Separators clearly show realm divisions (FIXED BOUNDARIES)
// - Layout remains stable across updates
// - Boundary violation indicators activate when ownership violated
// - Contract flow indicators show proper transition usage
```

- [ ] **Step 3: Test causal contract event emission with Realm-Binding**

```rust
// Test that:
// - RealmViewed events are emitted appropriately
// - Events contain correct realm information
// - Events contain ownership verification status
// - Events contain causal transition usage
// - Events are deterministic and replayable
// - Event ordering matches viewing sequence
// - Events show realm-binding compliance status
```

- [ ] **Step 4: Test integration with realm system and Realm-Binding**

```rust
// Test that:
// - Realm status collection doesn't interfere with realm operations
// - Health calculations are accurate and performant
// - Realm view updates reflect actual realm changes
// - Ownership verification correctly identifies subsystem placements
// - No performance degradation from realm monitoring
// - Realm-binding violations are properly detected and displayed
```

- [ ] **Step 5: Commit verification**

```bash
git add crates/bkg-cli/src/tui/app.rs crates/bkg-cli/src/tui/realm_view.rs
git commit -m "feat(atlantean-tui-realm-binding): verify realm-rendering functionality with realm-binding enforcement and ownership verification"
```
