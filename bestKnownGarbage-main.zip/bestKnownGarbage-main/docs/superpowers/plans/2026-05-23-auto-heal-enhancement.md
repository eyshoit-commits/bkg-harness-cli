# Auto-Heal Functionality Enhancement with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enhance the BKG auto-heal functionality to operate as a Speculum realm (truth + healing) component that enforces strict realm-boundary rules, uses explicit causal contracts for all cross-realm interactions, and emits timeline events for deterministic replay, making healing an active truth-verification and self-repair mechanism within fixed realm boundaries.

**Architecture:** Transform the healing daemon into a realm-bound Speculum realm component that:
1. Operates exclusively within the Speculum realm boundaries (truth + healing)
2. Enforces strict ownership rules (no cross-realm resource access without explicit contracts)
3. Provides healing services via explicit contracts to other realms
4. Emits timeline events for all healing operations and truth verifications
5. Uses explicit contracts for cross-realm interactions (Causa, Telum, Mensa)
6. Maintains deterministic healing with execution seeds for replayability
7. Functions as the Speculum realm's active truth and self-healing mechanism

**Tech Stack:** Rust, tokio for async operations, bkg-kernel::realm_system, bkg-kernel::timeline

---

### Task 1: Analyze current auto-heal implementation with Realm-Binding lens

**Files:**
- Read: `crates/bkg-cli/src/main.rs` (healing daemon startup)
- Read: `crates/bkg-cli/src/healing_daemon.rs` (healing daemon implementation)
- Read: `crates/bkg-cli/src/capsule/` (capsule store and events)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-kernel/src/timeline/` (timeline event system)
- Read: `crates/bkg-kernel/src/trust/kernel.rs` (truth verification)

- [ ] **Step 1: Understand current healing daemon startup**

```rust
// Review main.rs to see:
// - Where start_healing_daemon() is currently called
// - Understand why it's only started for Tui command
// - Check if there are any conditions preventing startup for other commands
// - Missing realm ownership declaration
```

- [ ] **Step 2: Understand healing daemon implementation**

```rust
// Review healing_daemon.rs to understand:
// - Current healing logic (probe every 30 seconds)
// - What conditions trigger healing actions
// - How healing effectiveness is measured
// - What types of issues it can currently detect and fix
// - Missing explicit contract usage for cross-realm interactions
// - Missing timeline event emission
// - Missing execution seeds for deterministic replay
```

- [ ] **Step 3: Understand realm system and Speculum realm boundaries**

```rust
// Review realm system to see:
// - Speculum realm definition: truth + healing
// - What subsystems belong to Speculum (trust kernel, healing daemon, truth verification)
// - Realm ownership rules: Speculum subsystems MAY NOT access resources outside Speculum without explicit contracts
// - Fixed realm boundaries: clear separation from Aevum (runtime), Causa (state), Telum (execution), etc.
// - Causal transition contracts: explicit protocols for Speculum ↔ Causa, Speculum ↔ Telum, etc.
// - Missing enforcement that healing daemon belongs exclusively to Speculum realm
```

- [ ] **Step 4: Identify what's missing for Realm-Binding compliant auto-heal**

```rust
// Determine what healing functionality needs to be enhanced while enforcing Realm-Binding:
// - Healing daemon startup: must declare Speculum realm ownership
// - Healing probes: must verify Speculum realm boundary
// - Capsule healing: requires explicit contracts with Causa realm
// - Truth verification: requires explicit contracts with trust kernel (Speculum internal)
// - Timeline event emission: for all healing operations
// - Execution seeds: for deterministic healing replay
// - Contract usage: for all cross-realm interactions
// - Ownership verification: prove healing daemon is in Speculum realm
```

- [ ] **Step 5: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-auto-heal-enhancement.md
git commit -m "feat(auto-heal-realm-binding): analyze current auto-heal implementation and realm boundaries for realm-binding compliant healing daemon"
```

### Task 2: Design auto-heal enhancement with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/main.rs`
- Modify: `crates/bkg-cli/src/healing_daemon.rs`
- Create: `crates/bkg-cli/src/healing_realm_binding.rs` (healing realm binding layer)

- [ ] **Step 1: Plan Speculum realm ownership declaration**

```rust
// Design how to declare Speculum realm ownership for healing daemon:
// - Add realm ownership declaration: #[realm(Speculum)]
// - Add ownership verification at initialization
// - Add boundary checks for all external resource access
// - Document that healing daemon belongs exclusively to Speculum realm
// - Healing daemon MAY NOT access resources outside Speculum without explicit contracts
```

- [ ] **Step 2: Plan Speculum realm boundary enforcement**

```rust
// Design boundary checks for all external interactions:
// - Capsule store access (Causa realm): require explicit HealingContract
// - Trust kernel access (Speculum realm): internal realm access (allowed)
// - Timeline/event system access (Mensa realm): require explicit TimelineContract
// - Agent execution access (Telum realm): require explicit contract (for execution-triggered healing)
// - All boundary crossings must use approved causal transition contracts
// - No direct access permitted - all must go through explicit contracts
```

- [ ] **Step 3: Plan explicit causal contract usage for healing services**

```rust
// Design how to use explicit contracts for cross-realm healing interactions:
// - Capsule healing: use HealingContract::heal() instead of direct capsule access
// - Truth verification: use TruthContract::verify() instead of direct trust access
// - Timeline events: use TimelineContract::emit() instead of direct event emission
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
//   * Emit compliance timeline events
//   * Include ExecutionSeed for deterministic replay
```

- [ ] **Step 4: Plan deterministic healing with execution seeds**

```rust
// Design how healing functions as Speculum realm deterministic execution:
// - All healing operations generate ExecutionSeed
// - Healing decisions are pure functions of inputs + ExecutionSeed
// - Timeline events reference ExecutionSeed for replay
// - Healing mechanism enforces deterministic truth verification and self-repair
```

- [ ] **Step 5: Plan healing as active Speculum realm mechanism**

```rust
// Design how healing daemon functions as Speculum realm's active truth and self-healing:
// - Continuously verifies truth of realm states (Speculum's primary function)
// - Initiates self-repair when truth deviations are detected
// - Provides healing services to other realms via explicit contracts
// - Emits timeline events showing truth verification and healing actions
// - Operates as active Speculum realm component, not passive background task
```

- [ ] **Step 6: Commit design**

```bash
git add crates/bkg-cli/src/main.rs crates/bkg-cli/src/healing_daemon.rs
git commit -m "feat(auto-heal-realm-binding): design speculum realm-bound healing daemon with boundary enforcement and explicit contracts"
```

### Task 3: Implement Speculum realm ownership declaration and boundary system

**Files:**
- Modify: `crates/bkg-cli/src/main.rs`
- Modify: `crates/bkg-cli/src/healing_daemon.rs`
- Create: `crates/bkg-cli/src/healing_realm_binding.rs`

- [ ] **Step 1: Add explicit Speculum realm ownership to healing daemon**

```rust
// In healing_daemon.rs:
// - Add realm ownership declaration: #[realm(Speculum)]
// - Add ownership verification in new() or init()
// - Add runtime boundary checks for all external calls
// - Add methods to verify current realm assignment
// - Log realm ownership verification on initialization
// - Reject any direct access from outside Speculum realm without contract
```

- [ ] **Step 2: Implement realm boundary validation system**

```rust
// Create healing_realm_binding.rs with:
// - HealingContract struct that validates all healing daemon access
// - CapsuleAccessContract for Causa realm interactions (capsule healing)
// - TruthAccessContract for Speculum realm interactions (truth verification)
// - TimelineAccessContract for Mensa realm interactions (timeline emission)
// - TelumAccessContract for Telum realm interactions (execution-triggered healing)
// - Each contract validates:
//   * Caller is in correct realm
//   * Access is permitted by explicit contract
//   * Contract version is compatible
//   * Policy snapshot is recorded
//   * ExecutionSeed is included where applicable
```

- [ ] **Step 3: Commit realm ownership and boundary system**

```bash
git add crates/bkg-cli/src/main.rs crates/bkg-cli/src/healing_daemon.rs crates/bkg-cli/src/healing_realm_binding.rs
git commit -m "feat(auto-heal-realm-binding): implement speculum realm ownership declaration and boundary validation system"
```

### Task 4: Implement explicit causal contract usage for healing services

**Files:**
- Modify: `crates/bkg-cli/src/healing_daemon.rs`
- Modify: `crates/bkg-cli/src/healing_realm_binding.rs`

- [ ] **Step 1: Replace direct capsule store access with HealingContract**

```rust
// Instead of direct capsule store calls:
// OLD: capsule_store.probe_health() or capsule_store.repair_capsule(...)
// NEW: HealingContract::probe(capsule_store, ...) or HealingContract::heal(capsule_store, ...)
// Where HealingContract:
//   * Validates Speculum realm boundary for caller (healing daemon)
//   * Validates Causa realm boundary for capsule store
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns healing result
//   * Includes ExecutionSeed in timeline event
//   * Ensures operation goes through explicit contract (no direct access)
//```

- [ ] **Step 2: Replace direct truth verification with TruthContract**

```rust
// Instead of direct trust kernel calls:
// OLD: trust_kernel.verify_truth(...)
// NEW: TruthContract::verify(trust_kernel, ...)
// Where TruthContract:
//   * Validates Speculum realm boundary for both caller and trust kernel
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns truth verification result
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 3: Replace direct timeline access with TimelineContract**

```rust
// Instead of direct event emission:
// OLD: event_bus.publish(...)
// NEW: TimelineContract::emit(event_bus, ...)
// Where TimelineContract:
//   * Validates Speculum realm boundary for emission
//   * Includes ExecutionSeed in event
//   * Ensures deterministic event ordering
//   * Records policy snapshot context
```

- [ ] **Step 4: Implement contract versioning and compliance tracking**

```rust
// Add contract system that:
// - Tracks contract versions used
// - Validates contract compatibility
// - Monitors for contract violations
// - Emits contract compliance timeline events
// - Provides debugging information for contract usage
// - Ensures all cross-realm healing interactions use explicit contracts
```

- [ ] **Step 5: Commit causal contract implementation**

```bash
git add crates/bkg-cli/src/healing_daemon.rs crates/bkg-cli/src/healing_realm_binding.rs
git commit -m "feat(auto-heal-realm-binding): implement explicit causal contract usage for all healing services"
```

### Task 5: Implement deterministic healing with execution seeds

**Files:**
- Modify: `crates/bkg-cli/src/healing_daemon.rs`
- Modify: `crates/bkg-cli/src/healing_realm_binding.rs`

- [ ] **Step 1: Add ExecutionSeed generation to healing operations**

```rust
// In healing operations (probe, heal, verify_truth, etc.):
// - Generate ExecutionSeed before operation:
//   * policy_hash: get_current_mutatio_policy_snapshot()
//   * operation_hash: hash(operation_type, parameters, state)
//   * state_hash: hash(current_speculum_state)
//   * timestamp_epoch: get_deterministic_timestamp()
// - Make healing operation purely function of inputs + ExecutionSeed
// - Store ExecutionSeed with operation record
// - Include ExecutionSeed in all timeline events
```

- [ ] **Step 2: Ensure deterministic healing behavior**

```rust
// Guarantee that:
// - Identical inputs + ExecutionSeed → identical healing operation
// - No external state influences healing decisions
// - All randomness is seeded deterministically
// - Healing operation is pure function of (inputs, ExecutionSeed)
// - Healing results are deterministic and replayable
// - Timeline events are deterministic replay triggers
```

- [ ] **Step 3: Commit deterministic healing implementation**

```bash
git add crates/bkg-cli/src/healing_daemon.rs crates/bkg-cli/src/healing_realm_binding.rs
git commit -m "feat(auto-heal-realm-binding): implement deterministic healing with execution seeds for replayability"
```

### Task 6: Implement healing timeline event emission with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/event/` (timeline event definitions)
- Modify: `crates/bkg-cli/src/healing_realm_binding.rs`
- Modify: `crates/bkg-cli/src/main.rs` (healing daemon startup)

- [ ] **Step 1: Define healing timeline events with Realm-Binding context**

```rust
// Add to timeline event system:
// - HealingProbeExecuted { target, execution_seed, policy_hash, result }
// - HealingApplied { target, execution_seed, policy_hash, result }
// - TruthVerified { target, execution_seed, policy_hash, result }
// - HealingContractUsed { contract_type, realms_involved, execution_seed, policy_hash }
// - HealingBoundaryViolated { violation_type, realms_involved, policy_hash }
// - HealingAccessDenied { operation, reason, policy_hash }
// All events must be deterministic and replayable
// All events must show realm-binding compliance
// All events must prove operation went through Speculum realm with explicit contracts
```

- [ ] **Step 2: Implement event emission with Realm-Binding validation**

```rust
// In healing_realm_binding.rs:
// - Emit appropriate timeline events for all healing operations
// - Validate Speculum realm boundary before emission
// - Include policy snapshot hashes for replay integrity
// - Include ExecutionSeed for deterministic replay
// - Emit contract usage events showing explicit contract compliance
// - Emit boundary violation events when contracts are violated
// - Ensure events are emitted synchronously with healing operations
```

- [ ] **Step 3: Commit timeline event integration**

```bash
git add crates/bkg-cli/src/event/ crates/bkg-cli/src/healing_realm_binding.rs
git commit -m "feat(auto-heal-realm-binding): implement healing timeline event emission with realm-binding compliance"
```

### Task 7: Implement Speculum realm healing as active truth mechanism

**Files:**
- Modify: `crates/bkg-cli/src/healing_daemon.rs`

- [ ] **Step 1: Add active truth verification loop**

```rust
// Instead of passive probing every 30 seconds:
// - Implement active truth verification as Speculum realm's primary function
// - Continuously verify truth of realm states (not just capsules)
// - Use truth verification contracts to check realm consistency
// - Initiate healing when truth deviations exceed thresholds
// - Make healing daemon the active Speculum realm mechanism
```

- [ ] **Step 2: Implement healing as Speculum realm self-repair**

```rust
// Design healing daemon to:
// - Verify its own Speculum realm integrity
// - Self-repair when Speculum realm truth deviations detected
// - Operate as Speculum realm's immune system
// - Emit timeline events showing self-verification and self-repair
// - Maintain Speculum realm sovereignty through active truth enforcement
```

- [ ] **Step 3: Commit active truth mechanism**

```bash
git add crates/bkg-cli/src/healing_daemon.rs
git commit -m "feat(auto-heal-realm-binding): implement healing daemon as active speculum realm truth verification and self-repair mechanism"
```

### Task 8: Verify auto-heal functionality with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/main.rs`
- Modify: `crates/bkg-cli/src/healing_daemon.rs`
- Modify: `crates/bkg-cli/src/healing_realm_binding.rs`

- [ ] **Step 1: Test Speculum realm ownership verification**

```bash
// Test that:
// - Healing daemon correctly declares #[realm(Speculum)]
// - Ownership verification passes at initialization
// - Runtime boundary checks are active
// - No subsystem outside Speculum can incorrectly claim healing daemon ownership
// - Direct access from Causa/Telum/Mensa realms without HealingContract is blocked
```

- [ ] **Step 2: Test Speculum realm boundary enforcement**

```bash
// Test that:
// - Capsule store access requires HealingContract
// - Trust kernel access requires TruthContract (or internal access)
// - Timeline access requires TimelineContract
// - Direct access without contracts is blocked/logged
// - Contract violations are detected and reported
// - Approved contracts function correctly with boundary validation
```

- [ ] **Step 3: Test explicit causal contract usage for healing services**

```bash
// Test that:
// - All cross-realm healing interactions use explicit contracts
// - Contract versions are tracked and validated
// - Policy snapshot hashes are included in timeline events
// - ExecutionSeeds are included in healing-related timeline events
// - Contract compliance events are emitted
// - Deterministic behavior is maintained
```

- [ ] **Step 4: Test deterministic healing with execution seeds**

```bash
// Test that:
// - Identical inputs produce identical ExecutionSeeds
// - Identical inputs + ExecutionSeed produce identical healing operations
// - ExecutionSeeds are included in all relevant timeline events
// - Timeline events are deterministic replay triggers
// - Healing results are deterministic and reproducible
```

- [ ] **Step 5: Test Speculum realm active truth mechanism**

```bash
// Test that:
// - Healing daemon continuously verifies truth of realm states
// - Truth verification uses explicit contracts
// - Healing is initiated when truth deviations detected
// - Healing daemon performs self-verification and self-repair
// - Timeline events show active truth verification and healing actions
// - Healing daemon functions as Speculum realm's active mechanism
```

- [ ] **Step 6: Commit verification**

```bash
git add crates/bkg-cli/src/main.rs crates/bkg-cli/src/healing_daemon.rs crates/bkg-cli/src/healing_realm_binding.rs
git commit -m "feat(auto-heal-realm-binding): verify speculum realm-bound healing daemon with realm-binding enforcement and active truth mechanism"
```
