# Trust-Gated Execution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transform the trust layer from a passive event display system into an active trust-gated execution mechanism where the agent evaluates trust before every dangerous operation and mutates trust based on outcomes, creating a causal binding between trust, agent execution, and timeline events.

**Architecture:** Implement trust preflight checks, risk-based policy gates, trust mutation after operations, and timeline event emission for all trust decisions, making trust an active causal force in the agent's decision loop.

**Tech Stack:** Rust, bkg-kernel::trust_field_kernel, timeline event system

---

### Task 1: Analyze current trust and agent execution flow

**Files:**
- Read: `crates/bkg-cli/src/agent.rs` (Coordinator::run() and execute_tool())
- Read: `crates/bkg-kernel/src/trust/kernel.rs` (trust kernel implementation)
- Read: `crates/bkg-kernel/src/trust_field_kernel/` (trust vector implementation)
- Read: `crates/bkg-cli/src/tui/status.rs` (TrustEvent definitions)
- Read: `crates/bkg-cli/src/event/` (timeline event system if exists)

- [ ] **Step 1: Map current agent execution flow**

```rust
// Review Coordinator::run() to understand:
// - Main decision loop
// - Tool execution process
// - Event publishing points
// - Where trust evaluation could be inserted
```

- [ ] **Step 2: Understand current trust capabilities**

```rust
// Review trust kernel to see:
// - TrustVector structure and methods
// - Trust evaluation mechanisms
// - How trust events are currently generated
// - Available trust-related functions
```

- [ ] **Step 3: Identify dangerous operations requiring trust gating**

```rust
// List operations that should require trust evaluation:
// - File writes/deletes
// - Capsule repairs/rehydrations
// - Model pulling
// - Policy mutations
// - SWD operations
// - System modifications
```

- [ ] **Step 4: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-trust-gated-execution.md
git commit -m "feat(trust-gating): analyze current trust and agent execution for trust-gated implementation"
```

### Task 2: Design trust-gated execution architecture

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Create: `crates/bkg-cli/src/trust_gate.rs` (new trust gating layer)

- [ ] **Step 1: Define risk levels for operations**

```rust
// Design risk classification system:
// - Safe: read-only operations, queries
// - Moderate: state reads, non-destructive operations
// - Dangerous: file modifications, capsule operations
// - Catastrophic: system mutations, policy changes
```

- [ ] **Step 2: Design trust preflight evaluation**

```rust
// Design trust evaluation before dangerous operations:
// - TrustKernel::evaluate_operation(operation, risk_level)
// - Returns TrustDecision with allowed/confidence/rationale
// - If not allowed, emit TrustDenied event and suggest alternatives
```

- [ ] **Step 3: Design trust postflight mutation**

```rust
// Design trust updates after operations:
// - Based on operation success/failure and outcome quality
// - Use trust kernel to update trust vectors
// - Emit TrustUpdated event showing change
```

- [ ] **Step 4: Design timeline event integration**

```rust
// Design trust event emission:
// - TrustEvaluated (before operation)
// - TrustApplied (after successful operation)
// - TrustViolated (after failed/untrusted operation)
// - TrustPolicyApplied (when trust influences decision)
// All events must contain policy snapshot hashes for replay
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/agent.rs
git commit -m "feat(trust-gating): design trust-gated execution architecture with preflight, postflight, and timeline integration"
```

### Task 3: Implement trust risk classification system

**Files:**
- Create: `crates/bkg-cli/src/trust_gate.rs`

- [ ] **Step 1: Define RiskLevel enum**

```rust
// Create RiskLevel enum:
// - Safe
// - Moderate
// - Dangerous
// - Catastrophic
```

- [ ] **Step 2: Map operations to risk levels**

```rust
// Create operation risk mapping:
// - File reads: Safe
// - File writes: Dangerous
// - Model pulls: Moderate (if cached) to Dangerous (if network)
// - Capsule repairs: Dangerous
// - Policy mutations: Catastrophic
// - SWD commits: Dangerous
```

- [ ] **Step 3: Commit risk classification**

```bash
git add crates/bkg-cli/src/trust_gate.rs
git commit -m "feat(trust-gating): implement risk classification system for operations"
```

### Task 4: Implement trust preflight evaluation

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs` (in execute_tool path)
- Modify: `crates/bkg-cli/src/trust_gate.rs`

- [ ] **Step 1: Add trust gate access to Coordinator**

```rust
// Add trust gate instance or access to Coordinator:
// - Initialize in Coordinator::new() or with_* methods
// - Handle initialization failures gracefully
```

- [ ] **Step 2: Add preflight trust check**

```rust
// In execute_tool, before tool execution:
// 1. Determine operation risk level
// 2. Call trust_gate.evaluate_preflight(operation, risk_level)
// 3. If not allowed:
//    - Emit TrustDenied timeline event
//    - Return error to caller
//    - Do not execute tool
// 4. If allowed:
//    - Emit TrustEvaluated timeline event
//    - Proceed with tool execution
```

- [ ] **Step 3: Implement trust decision handling**

```rust
// Handle TrustDecision:
// - allowed: proceed
// - not allowed: deny with rationale
// - confidence: use for logging/decision weighting
// - rationale: include in timeline events
```

- [ ] **Step 4: Commit preflight trust evaluation**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_gate.rs
git commit -m "feat(trust-gating): implement trust preflight evaluation before dangerous operations"
```

### Task 5: Implement trust postflight mutation

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs` (in execute_tool path)
- Modify: `crates/bkg-cli/src/trust_gate.rs`

- [ ] **Step 1: Add postflight trust update**

```rust
// After tool execution result is available:
// 1. Determine operation outcome (success/failure/partial)
// 2. Call trust_gate.update_postflight(operation, outcome, result)
// 3. Trust kernel updates trust vectors based on outcome
// 4. Emit TrustUpdated timeline event showing change
```

- [ ] **Step 2: Implement outcome-based trust adjustment**

```rust
// Design trust adjustment logic:
// - Success: small trust increase
// - Failure: trust decrease proportional to risk level
// - Partial success: moderate adjustment
// - Consider execution time, resource usage, side effects
```

- [ ] **Step 3: Commit postflight trust mutation**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_gate.rs
git commit -m "feat(trust-gating): implement trust postflight mutation based on operation outcomes"
```

### Task 6: Implement trust-gated timeline event system

**Files:**
- Modify: `crates/bkg-cli/src/event/` (timeline event definitions)
- Modify: `crates/bkg-cli/src/trust_gate.rs`
- Modify: `crates/bkg-cli/src/agent.rs` (event publishing)

- [ ] **Step 1: Define trust timeline events**

```rust
// Add to timeline event system:
// - TrustEvaluated { operation, risk_level, decision, policy_hash }
// - TrustApplied { operation, outcome, trust_delta, policy_hash }
// - TrustViolated { operation, violation_reason, policy_hash }
// - TrustPolicyApplied { policy_snapshot, reason }
// - TrustDenied { operation, risk_level, decision, policy_hash }
// All events must be deterministic and replayable
```

- [ ] **Step 2: Implement event emission**

```rust
// In trust_gate.rs:
// - Emit appropriate timeline events for all trust decisions
// - Include policy snapshot hashes for replay integrity
// - Ensure events are emitted synchronously with decisions
```

- [ ] **Step 3: Commit timeline event integration**

```bash
git add crates/bkg-cli/src/event/ crates/bkg-cli/src/trust_gate.rs
git commit -m "feat(trust-gating): implement trust timeline event emission for replay integrity"
```

### Task 7: Verify trust-gated execution functionality

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-cli/src/trust_gate.rs`

- [ ] **Step 1: Test trust preflight denial**

```bash
// Test that:
// - High-risk operations are denied when trust is low
// - TrustDenied events are emitted correctly
// - Agent receives appropriate error responses
// - No tool execution occurs when trust denied
```

- [ ] **Step 2: Test trust postflight updates**

```bash
// Test that:
// - Successful operations increase trust appropriately
// - Failed operations decrease trust appropriately
// - TrustUpdated events show correct trust deltas
// - Trust changes persist in trust kernel
```

- [ ] **Step 3: Test timeline event integrity**

```bash
// Test that:
// - All trust decisions emit corresponding timeline events
// - Events contain policy snapshot hashes
// - Events are deterministic and replayable
// - Event ordering matches execution order
```

- [ ] **Step 4: Test risk level classification**

```bash
// Test that:
// - Operations are correctly classified by risk level
// - Safe operations bypass trust gating (if designed)
// - Dangerous operations always require trust evaluation
// - Risk levels match operation potential harm
```

- [ ] **Step 5: Commit verification**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_gate.rs
git commit -m "feat(trust-gating): verify trust-gated execution with comprehensive testing"
```
