# SWD (Strict Write Discipline) Integration with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Integrate the Strict Write Discipline (SWD) system into the BKG agent's tool execution flow as a Mensa realm (immutable global memory) component that enforces realm-boundary rules, uses explicit causal contracts for all cross-realm interactions, and emits timeline events for deterministic replay, making SWD the immutable memory layer that records all causal file operations within fixed realm boundaries.

**Architecture:** Transform the SWD system into a realm-bound Mensa realm component that:
1. Operates exclusively within the Mensa realm boundaries (immutable global memory)
2. Enforces strict ownership rules (no cross-realm resource access without explicit contracts)
3. Provides write operation services via explicit contracts to Telum realm agents
4. Emits timeline events for all file operations and snapshot creations
5. Uses explicit contracts for Telum realm interactions (tool file operations)
6. Maintains deterministic snapshot and replay mechanisms with execution seeds
7. Enforces the Realm-Binding principle that all file writes must go through SWD in the Mensa realm

**Tech Stack:** Rust, bkg-swd crate, bkg-kernel::realm_system, bkg-kernel::timeline

---

### Task 1: Analyze current SWD implementation and agent tool execution with Realm-Binding lens

**Files:**
- Read: `crates/bkg-cli/src/agent.rs` (Coordinator's execute_tool method)
- Read: `crates/bkg-swd/src/lib.rs` (SWD implementation)
- Read: `crates/bkg-cli/src/snapshot/` (snapshot commands if relevant)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-kernel/src/timeline/` (timeline event system)

- [ ] **Step 1: Understand current tool execution in Coordinator**

```rust
// Review Coordinator::execute_tool() in agent.rs to see:
// - How tools are currently looked up and executed
// - What happens before and after tool execution
// - Where SWD integration points would be most effective
// - Whether agent (Telum realm) directly accesses SWD (Mensa realm)
// - Missing explicit contract usage for cross-realm interactions
```

- [ ] **Step 2: Understand SWD capabilities with Realm-Binding**

```rust
// Review bkg-swd/src/lib.rs to understand:
// - Snapshot structure and creation process
// - Operations logging mechanism
// - How to create reversible file operations
// - Available SWD functions for integration
// - Current realm assignment (if any)
// - Whether SWD enforces realm boundaries
```

- [ ] **Step 3: Identify Realm-Binding gaps in SWD implementation**

```rust
// Determine what's missing for Realm-Binding compliance:
// - No explicit realm ownership declaration for SWD (should be Mensa)
// - No boundary validation when agent (Telum) accesses SWD (Mensa)
// - No explicit contract usage for Telum ↔ Mensa SWD interactions
// - No timeline event emission for SWD operations and snapshot creations
// - No execution seeds for deterministic snapshot and replay
// - SWD not operating as a pure Mensa realm component
// - Agent tool executions not bound to SWD as immutable memory layer
// - No enforcement that ALL file writes must go through SWD (Mensa realm)
// - Missing causal contract system for file operation transitions
```

- [ ] **Step 4: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-swd-integration.md
git commit -m "feat(swd-integration-realm-binding): analyze current swd implementation and agent tool execution for realm-binding compliant strict write discipline"
```

### Task 2: Design SWD integration with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Create: `crates/bkg-cli/src/swd_realm_binding.rs` (SWD realm binding layer)
- Modify: `crates/bkg-swd/src/lib.rs` (add realm ownership and contract system)

- [ ] **Step 1: Declare explicit Mensa realm ownership for SWD**

```rust
// Add explicit realm ownership to SWD:
// - Add realm annotation: #[realm(Mensa)] to SWD components
// - Add ownership verification at initialization
// - Add boundary checks for all external resource access
// - Document that SWD belongs exclusively to Mensa realm
// - SWD MAY NOT access resources outside Mensa without explicit contracts
// - ALL file writes MUST go through SWD in Mensa realm (Realm-Binding rule)
```

- [ ] **Step 2: Design Mensa realm boundary enforcement**

```rust
// Design boundary checks for all external interactions:
// - Agent/tool access (Telum realm): require explicit SWDContract
// - Timeline/event system access (Mensa realm): internal realm access (allowed)
// - Capsule store access (Causa realm): require explicit contract
// - Trust kernel access (Speculum realm): require explicit contract
// - All boundary crossings must use approved causal transition contracts
// - No direct file system access permitted - all must go through SWD contracts
```

- [ ] **Step 3: Design explicit causal contract usage for SWD services**

```rust
// Design how to use explicit contracts for cross-realm SWD interactions:
// - File operations: use SWDContract::execute() instead of direct SWD access
// - Snapshot creation: use SWDContract::snapshot() instead of direct snapshot
// - Timeline events: use TimelineContract::emit() instead of direct event emission
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
//   * Emit compliance timeline events
//   * Include ExecutionSeed for deterministic replay
```

- [ ] **Step 4: Design SWD as immutable memory layer with execution seeds**

```rust
// Design how SWD functions as Mensa realm immutable memory:
// - All file operations create deterministic snapshots
// - Each snapshot includes ExecutionSeed for replay
// - Timeline events reference snapshots for causal chains
// - Replay mechanism uses ExecutionSeed to reconstruct exact state
// - SWD enforces append-only timeline of immutable snapshots
// - No mutations permitted - only append operations
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/agent.rs
git commit -m "feat(swd-integration-realm-binding): design mensa realm-bound swd system with boundary enforcement and explicit contracts"
```

### Task 3: Implement Mensa realm ownership declaration and boundary system

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-swd/src/lib.rs`
- Create: `crates/bkg-cli/src/swd_realm_binding.rs`

- [ ] **Step 1: Add explicit Mensa realm ownership to SWD**

```rust
// In SWD implementation:
// - Add realm ownership declaration: #[realm(Mensa)]
// - Add ownership verification in new() or init()
// - Add runtime boundary checks for all external calls
// - Add methods to verify current realm assignment
// - Log realm ownership verification on initialization
// - Reject any direct file system access from outside Mensa realm without SWD contract
// - Enforce that all write operations go through SWD interface
```

- [ ] **Step 2: Implement realm boundary validation system**

```rust
// Create swd_realm_binding.rs with:
// - SWDContract struct that validates all SWD access
// - FileAccessContract for Telum realm interactions (tool file operations)
// - TimelineAccessContract for Mensa realm interactions (internal)
// - CapsuleAccessContract for Causa realm interactions (state persistence)
// - TrustAccessContract for Speculum realm interactions (trust updates)
// - Each contract validates:
//   * Caller is in correct realm (Telum for tools, Mensa for SWD kernel)
//   * Access is permitted by explicit contract
//   * Contract version is compatible
//   * Policy snapshot is recorded
//   * ExecutionSeed is included where applicable
//   * All file operations go through SWD (no direct filesystem access)
//```

- [ ] **Step 3: Commit realm ownership and boundary system**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-swd/src/lib.rs crates/bkg-cli/src/swd_realm_binding.rs
git commit -m "feat(swd-integration-realm-binding): implement mensa realm ownership declaration and boundary validation system"
```

### Task 4: Implement explicit causal contract usage for SWD services

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-swd/src/lib.rs`
- Modify: `crates/bkg-cli/src/swd_realm_binding.rs`

- [ ] **Step 1: Replace direct SWD access with SWDContract**

```rust
// Instead of direct SWD calls from agent/tools (Telum realm):
// OLD: swd.snapshot(...) or swd.apply(...)
// NEW: SWDContract::execute(swd, operation, ...)
// Where SWDContract:
//   * Validates Telum realm boundary for caller
//   * Validates Mensa realm boundary for SWD
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns operation result
//   * Includes ExecutionSeed in timeline event
//   * Ensures operation goes through SWD (no direct filesystem access)
//```

- [ ] **Step 2: Replace direct timeline access with TimelineContract**

```rust
// Instead of direct event emission from SWD:
// OLD: event_bus.publish(...)
// NEW: TimelineContract::emit(event_bus, ...)
// Where TimelineContract:
//   * Validates Mensa realm boundary for emission
//   * Includes ExecutionSeed in event
//   * Ensures deterministic event ordering
//   * Records policy snapshot context
```

- [ ] **Step 3: Implement contract versioning and compliance tracking**

```rust
// Add contract system that:
// - Tracks contract versions used
// - Validates contract compatibility
// - Monitors for contract violations
// - Emits contract compliance timeline events
// - Provides debugging information for contract usage
// - Ensures all cross-realm SWD interactions use explicit contracts
// - Ensures no direct filesystem access occurs outside SWD contracts
```

- [ ] **Step 4: Commit causal contract implementation**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-swd/src/lib.rs crates/bkg-cli/src/swd_realm_binding.rs
git commit -m "feat(swd-integration-realm-binding): implement explicit causal contract usage for all swd services"
```

### Task 5: Implement SWD as immutable memory layer with execution seeds

**Files:**
- Modify: `crates/bkg-swd/src/lib.rs`
- Modify: `crates/bkg-cli/src/swd_realm_binding.rs`

- [ ] **Step 1: Add ExecutionSeed generation to SWD operations**

```rust
// In SWD operations (snapshot, apply, etc.):
// - Generate ExecutionSeed before operation:
//   * policy_hash: get_current_mutatio_policy_snapshot()
//   * operation_hash: hash(operation_type, parameters, state)
//   * state_hash: hash(current_filesystem_state)
//   * timestamp_epoch: get_deterministic_timestamp()
// - Make SWD operation purely function of inputs + ExecutionSeed
// - Store ExecutionSeed with operation record
// - Include ExecutionSeed in all timeline events
```

- [ ] **Step 2: Ensure deterministic SWD behavior**

```rust
// Guarantee that:
// - Identical inputs + ExecutionSeed → identical SWD operation
// - No external state influences SWD decisions
// - All randomness is seeded deterministically
// - SWD operation is pure function of (inputs, ExecutionSeed)
// - Snapshots are deterministic and replayable
// - Timeline events are idaz idaz
```

- [ ] **Step 3: Implement immutable memory enforcement**

```rust
// Enforce Mensa realm immutability:
// - All operations are append-only
// - No modifications to existing snapshots permitted
// - Timeline only grows forward
// - Historical snapshots are read-only
// - SWD rejects any attempt to mutate existing records
```

- [ ] **Step 4: Commit SWD immutable memory implementation**

```bash
git add crates/bkg-swd/src/lib.rs crates/bkg-cli/src/swd_realm_binding.rs
git commit -m "feat(swd-integration-realm-binding): implement swd as mensa realm immutable memory layer with execution seeds"
```

### Task 6: Implement SWD timeline event emission with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/event/` (timeline event definitions)
- Modify: `crates/bkg-cli/src/swd_realm_binding.rs`
- Modify: `crates/bkg-cli/src/agent.rs` (event publishing)

- [ ] **Step 1: Define SWD timeline events with Realm-Binding context**

```rust
// Add to timeline event system:
// - SWDSnapshotCreated { operation, execution_seed, policy_hash, snapshot_id }
// - SWDOperationApplied { operation, execution_seed, policy_hash, result }
// - SWDContractUsed { contract_type, realms_involved, execution_seed, policy_hash }
// - SWDBoundaryViolated { violation_type, realms_involved, policy_hash }
// - SWDFileAccessDenied { operation, reason, policy_hash }
// All events must be deterministic and replayable
// All events must show realm-binding compliance
// All events must prove operation went through SWD (Mensa realm)
//```

- [ ] **Step 2: Implement event emission with Realm-Binding validation**

```rust
// In swd_realm_binding.rs:
// - Emit appropriate timeline events for all SWD operations
// - Validate Mensa realm boundary before emission
// - Include policy snapshot hashes for replay integrity
// - Include ExecutionSeed for deterministic replay
// - Emit contract usage events showing explicit contract compliance
// - Emit boundary violation events when contracts are violated
// - Ensure events are emitted synchronously with SWD operations
```

- [ ] **Step 3: Commit timeline event integration**

```bash
git add crates/bkg-cli/src/event/ crates/bkg-cli/src/swd_realm_binding.rs
git commit -m "feat(swd-integration-realm-binding): implement swd timeline event emission with realm-binding compliance"
```

### Task 7: Verify SWD integration functionality with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-swd/src/lib.rs`
- Modify: `crates/bkg-cli/src/swd_realm_binding.rs`

- [ ] **Step 1: Test Mensa realm ownership verification**

```bash
// Test that:
// - SWD correctly declares #[realm(Mensa)]
// - Ownership verification passes at initialization
// - Runtime boundary checks are active
// - No subsystem outside Mensa can incorrectly claim SWD ownership
// - Direct file system access from Telum realm without SWDContract is blocked
// - All write operations go through SWD interface
```

- [ ] **Step 2: Test Mensa realm boundary enforcement**

```bash
// Test that:
// - SWD access from Telum realm requires SWDContract
// - Timeline access from Mensa realm requires TimelineContract
// - Direct access without contracts is blocked/logged
// - Contract violations are detected and reported
// - Approved contracts function correctly with boundary validation
// - No direct filesystem access occurs outside SWD contracts
```

- [ ] **Step 3: Test explicit causal contract usage for SWD services**

```bash
// Test that:
// - All cross-realm SWD interactions use explicit contracts
// - Contract versions are tracked and validated
// - Policy snapshot hashes are included in timeline events
// - ExecutionSeeds are included in SWD-related timeline events
// - Contract compliance events are emitted
// - Deterministic behavior is maintained
// - Timeline events prove operations went through SWD
```

- [ ] **Step 4: Test SWD as immutable memory layer with execution seeds**

```bash
// Test that:
// - Identical inputs produce identical ExecutionSeeds
// - Identical inputs + ExecutionSeed produce identical SWD operations
// - ExecutionSeeds are included in all relevant timeline events
// - Timeline events are deterministic replay triggers
// - SWD enforces append-only immutable memory
// - No mutations permitted to existing snapshots
// - All file operations go through SWD (Mensa realm)
//```

- [ ] **Step 5: Test Realm-Binding enforcement for file writes**

```bash
// Test that:
// - NO file write occurs outside SWD (Mensa realm)
// - All tool file operations go through SWD contracts
// - Direct filesystem writes are blocked/logged
// - SWD boundary violations trigger appropriate events
// - Realm-Binding principle "All writes through SWD" is enforced
```

- [ ] **Step 6: Commit verification**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-swd/src/lib.rs crates/bkg-cli/src/swd_realm_binding.rs
git commit -m "feat(swd-integration-realm-binding): verify mensa realm-bound swd system with realm-binding enforcement and immutable memory guarantees"
```
