# Ollama Orchestrator Enhancement with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Enhance the BKG Ollama orchestrator to operate within the Telum realm (deterministic execution) with strict realm-boundary enforcement, explicit causal contracts for cross-realm interactions, and deterministic model routing that produces replayable timeline events, enforcing the Realm-Binding principle that the orchestrator belongs exclusively to the Telum realm.

**Architecture:** Transform the Ollama provider into a realm-bound deterministic execution subsystem that:
1. Operates exclusively within the Telum realm boundaries
2. Enforces strict ownership rules (no cross-realm resource access without explicit contracts)
3. Emits timeline events for all causal interactions
4. Uses explicit contracts for Speculum (trust) and Mensa (memory) realm interactions
5. Provides deterministic model routing with execution seeds for replayability

**Tech Stack:** Rust, bkg-kernel::realm_system, bkg-kernel::timeline, existing ollama.rs

---

### Task 1: Analyze current Ollama implementation and realm boundaries

**Files:**
- Read: `projects/bkg-client/crates/bkg-provider/src/ollama.rs` (current Ollama implementation)
- Read: `crates/bkg-cli/src/model_router.rs` (current model router)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-cli/src/agent.rs` (how Ollama is used by Coordinator)
- Read: `crates/bkg-kernel/src/trust/kernel.rs` (trust kernel for Speculum realm interactions)
- Read: `crates/bkg-kernel/src/timeline/` (timeline event system)

- [ ] **Step 1: Understand current Ollama implementation**

```rust
// Review ollama.rs to see:
// - Model discovery (/api/tags)
// - Model routing logic (task_type → model selection)
// - Model pulling mechanism
// - Health checking (basic availability)
// - How it's used by ChainBuilder in agent.rs
```

- [ ] **Step 2: Understand Telum realm definition and boundaries**

```rust
// Review realm system to see:
// - Telum realm definition: deterministic execution
// - What subsystems belong to Telum (tool execution, model routing, chain building)
// - Realm ownership rules: Telum subsystems MAY NOT access resources outside Telum without explicit contracts
// - Fixed realm boundaries: clear separation from Causa (state), Speculum (truth), Mensa (memory)
// - Causal transition contracts: explicit protocols for Telum ↔ Speculum, Telum ↔ Mensa, etc.
```

- [ ] **Step 3: Identify Realm-Binding gaps in current Ollama implementation**

```rust
// Determine what's missing for Realm-Binding compliance:
// - No explicit realm ownership declaration
// - No boundary validation when accessing trust kernel (Speculum realm)
// - No boundary validation when accessing timeline/event system (Mensa realm)
// - No timeline event emission for causal interactions
// - No execution seeds for deterministic replay
// - No explicit contract usage for cross-realm interactions
// - Model routing not bound to Telum realm determinism requirements
```

- [ ] **Step 4: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-ollama-orchestrator-enhancement.md
git commit -m "feat(ollama-realm-binding): analyze current ollama implementation for realm-binding compliance and telum realm boundaries"
```

### Task 2: Design realm-bound Ollama orchestrator with Telum realm enforcement

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`
- Create: `projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs` (realm binding layer)

- [ ] **Step 1: Declare explicit Telum realm ownership**

```rust
// Add explicit realm ownership to Ollama provider:
// - Add realm annotation: #[realm(Telum)]
// - Add ownership verification at initialization
// - Add boundary checks for all external resource access
// - Document that Ollama provider belongs exclusively to Telum realm
```

- [ ] **Step 2: Design Telum realm boundary enforcement**

```rust
// Design boundary checks for all external interactions:
// - Trust kernel access (Speculum realm): require explicit contract
// - Timeline/event system access (Mensa realm): require explicit contract
// - Capsule store access (Causa realm): require explicit contract
// - Healing daemon access (Speculum realm): require explicit contract
// - All boundary crossings must use approved causal transition contracts
```

- [ ] **Step 3: Design explicit causal contract usage**

```rust
// Design how to use explicit contracts for cross-realm interactions:
// - Trust evaluation: use TrustContract::evaluate() instead of direct kernel access
// - Timeline events: use TimelineContract::emit() instead of direct event emission
// - State persistence: use MemoryContract::persist() instead of direct file writes
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
```

- [ ] **Step 4: Design deterministic model routing with execution seeds**

```rust
// Design model routing that produces replayable outcomes:
// - Generate ExecutionSeed for each routing decision:
//   * policy_hash: current Mutatio realm policy snapshot
//   * model_hash: selected model's content hash
//   * routing_hash: hash of routing inputs and state
//   * timestamp_epoch: deterministic timestamp
// - Include ExecutionSeed in all timeline events
// - Make routing decisions purely deterministic based on inputs + seed
// - Ensure identical inputs always produce identical routing decisions
```

- [ ] **Step 5: Commit design**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs
git commit -m "feat(ollama-realm-binding): design telum realm-bound ollama orchestrator with boundary enforcement and explicit contracts"
```

### Task 3: Implement Telum realm ownership declaration and boundary system

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`
- Create: `projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs`

- [ ] **Step 1: Add explicit Telum realm ownership**

```rust
// In ollama.rs:
// - Add realm ownership declaration: #[realm(Telum)]
// - Add ownership verification in new() or init()
// - Add runtime boundary checks for all external calls
// - Add methods to verify current realm assignment
// - Log realm ownership verification on initialization
```

- [ ] **Step 2: Implement realm boundary validation system**

```rust
// Create ollama_realm_binding.rs with:
// - BoundaryChecker struct that validates all external access
// - TrustAccessContract for Speculum realm interactions
// - TimelineAccessContract for Mensa realm interactions
// - StateAccessContract for Causa realm interactions
// - HealingAccessContract for Speculum realm interactions
// - Each contract validates:
//   * Caller is in Telum realm
//   * Access is permitted by explicit contract
//   * Contract version is compatible
//   * Policy snapshot is recorded
```

- [ ] **Step 3: Commit realm ownership and boundary system**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs
git commit -m "feat(ollama-realm-binding): implement telum realm ownership declaration and boundary validation system"
```

### Task 4: Implement explicit causal contract usage for cross-realm interactions

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs`

- [ ] **Step 1: Replace direct trust kernel access with TrustContract**

```rust
// Instead of direct trust kernel calls:
// OLD: trust_kernel.evaluate(...)
// NEW: TrustContract::evaluate(trust_kernel, ...)
// Where TrustContract:
//   * Validates Telum realm boundary
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns trust decision
```

- [ ] **Step 2: Replace direct timeline access with TimelineContract**

```rust
// Instead of direct event emission:
// OLD: event_bus.publish(...)
// NEW: TimelineContract::emit(event_bus, ...)
// Where TimelineContract:
//   * Validates Telum realm boundary for emission
//   * Includes ExecutionSeed in event
//   * Ensures deterministic event ordering
//   * Records policy snapshot context
```

- [ ] **Step 3: Implement contract versioning and compliance tracking**

```rust
// Add contract system that:
// - Tracks contract versions used
// - Validates contract compatibility
// - Monitors for contract violations
// - Emits contract compliance timeline events
// - Provides debugging information for contract usage
```

- [ ] **Step 4: Commit causal contract implementation**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs
git commit -m "feat(ollama-realm-binding): implement explicit causal contract usage for all cross-realm interactions"
```

### Task 5: Implement deterministic model routing with execution seeds

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`
- Modify: `projects/bkg-client/crates/bkg-provider/src/model_router.rs` (if needed)

- [ ] **Step 1: Add ExecutionSeed generation to model routing**

```rust
// In model selection process:
// - Generate ExecutionSeed before routing decision:
//   * policy_hash: get_current_mutatio_policy_snapshot()
//   * model_hash: get_selected_model_content_hash()
//   * routing_hash: hash(route_inputs, current_telum_state)
//   * timestamp_epoch: get_deterministic_timestamp()
// - Make routing decision purely function of inputs + ExecutionSeed
// - Store ExecutionSeed with routing decision
```

- [ ] **Step 2: Include ExecutionSeed in all timeline events**

```rust
// For every timeline event emitted:
// - Include ExecutionSeed from routing decision that caused the event
// - Ensure events are deterministic replay triggers
// - Allow reconstruction of exact model selection context
```

- [ ] **Step 3: Ensure deterministic routing behavior**

```rust
// Guarantee that:
// - Identical inputs + ExecutionSeed → identical model selection
// - No external state influences routing decisions
// - All randomness is seeded deterministically
// - Routing is pure function of (inputs, ExecutionSeed)
```

- [ ] **Step 4: Commit deterministic routing implementation**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs projects/bkg-client/crates/bkg-provider/src/model_router.rs
git commit -m "feat(ollama-realm-binding): implement deterministic model routing with execution seeds for replayability"
```

### Task 6: Implement realm-specific Telum execution guarantees

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`

- [ ] **Step 1: Add Telum execution purity checks**

```rust
// Add verification that:
// - All Ollama operations are deterministic executions
// - No hidden state mutations occur
// - All side effects are captured via explicit contracts
// - Execution time is bounded and predictable
// - Resource usage is deterministic and reportable
```

- [ ] **Step 2: Implement Telum realm execution logging**

```rust
// Add logging that shows:
// - Telum realm execution entry/exit
// - Contract usage for cross-realm interactions
// - ExecutionSeed for each operation
// - Resource consumption deterministically
// - Any boundary violations (should never occur in production)
```

- [ ] **Step 3: Commit Telum execution guarantees**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs
git commit -m "feat(ollama-realm-binding): implement telum realm execution purity checks and deterministic logging"
```

### Task 7: Verify realm-bound Ollama orchestrator functionality

**Files:**
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama.rs`
- Modify: `projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs`

- [ ] **Step 1: Test Telum realm ownership verification**

```bash
// Test that:
// - Ollama provider correctly declares #[realm(Telum)]
// - Ownership verification passes at initialization
// - Runtime boundary checks are active
// - No subsystem outside Telum can incorrectly claim Ollama ownership
```

- [ ] **Step 2: Test realm boundary enforcement**

```bash
// Test that:
// - Trust kernel access requires TrustContract
// - Timeline access requires TimelineContract
// - Direct access without contracts is blocked/logged
// - Contract violations are detected and reported
// - Approved contracts function correctly
```

- [ ] **Step 3: Test explicit causal contract usage**

```bash
// Test that:
// - All cross-realm interactions use explicit contracts
// - Contract versions are tracked and validated
// - Policy snapshot hashes are included in timeline events
// - Contract compliance events are emitted
// - Deterministic behavior is maintained
```

- [ ] **Step 4: Test deterministic model routing with execution seeds**

```bash
// Test that:
// - Identical inputs produce identical ExecutionSeeds
// - Identical inputs + ExecutionSeed produce identical model selections
// - ExecutionSeeds are included in all relevant timeline events
// - Timeline events are deterministic replay triggers
// - No non-deterministic influences on routing
```

- [ ] **Step 5: Test Telum execution purity**

```bash
// Test that:
// - All operations are deterministic executions
// - Side effects are captured via explicit contracts
// - No hidden state mutations occur outside contracts
// - Resource usage is deterministic and reportable
// - Realm execution logging shows proper Telum behavior
```

- [ ] **Step 6: Commit verification**

```bash
git add projects/bkg-client/crates/bkg-provider/src/ollama.rs projects/bkg-client/crates/bkg-provider/src/ollama_realm_binding.rs
git commit -m "feat(ollama-realm-binding): verify telum realm-bound ollama orchestrator with comprehensive testing"
```
