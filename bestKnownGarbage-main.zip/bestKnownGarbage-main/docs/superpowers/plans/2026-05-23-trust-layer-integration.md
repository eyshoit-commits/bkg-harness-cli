# Trust Layer Integration in Agent System with Realm-Binding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Integrate the trust layer into the BKG agent system's decision-making process as an active Speculum realm component that enforces realm-boundary rules, uses explicit causal contracts for all cross-realm interactions, and emits timeline events for deterministic replay, making trust an active causal force in the Speculum realm that governs agent execution in the Telum realm.

**Architecture:** Transform the trust layer into a realm-bound Speculum realm component that:
1. Operates exclusively within the Speculum realm boundaries (truth + healing)
2. Enforces strict ownership rules (no cross-realm resource access without explicit contracts)
3. Provides trust evaluation services via explicit contracts to Telum realm agents
4. Emits timeline events for all trust decisions and mutations
5. Uses explicit contracts for Telum realm interactions (agent trust evaluation)
6. Maintains deterministic trust mutation with execution seeds for replayability

**Tech Stack:** Rust, bkg-kernel::trust_field_kernel, bkg-kernel::realm_system, bkg-kernel::timeline

---

### Task 1: Analyze current trust layer and agent system with Realm-Binding lens

**Files:**
- Read: `crates/bkg-cli/src/agent.rs` (Coordinator implementation)
- Read: `crates/bkg-kernel/src/trust/kernel.rs` (trust kernel implementation)
- Read: `crates/bkg-cli/src/tui/status.rs` (TrustEvent definitions)
- Read: `crates/bkg-kernel/src/trust_field_kernel/` (trust vector implementation)
- Read: `crates/bkg-kernel/src/realm/` (realm system implementation)
- Read: `crates/bkg-kernel/src/timeline/` (timeline event system)

- [ ] **Step 1: Understand current trust layer capabilities**

```rust
// Review the trust kernel and trust field kernel to understand:
// - TrustVector structure and methods
// - Trust evaluation and update mechanisms
// - How trust events are generated and consumed
// - Available trust-related functions and data structures
// - Current realm assignment (if any)
```

- [ ] **Step 2: Understand current agent system trust usage with Realm-Binding**

```rust
// Review Coordinator::run() in agent.rs to see:
// - How the agent currently processes messages and uses tools
// - What trust-related publishing currently happens (if any)
// - Where trust evaluation occurs in relation to realm boundaries
// - Whether agent (Telum realm) directly accesses trust kernel (Speculum realm)
// - Missing explicit contract usage for cross-realm interactions
```

- [ ] **Step 3: Identify Realm-Binding gaps in trust integration**

```rust
// Determine what's missing for Realm-Binding compliance:
// - No explicit realm ownership declaration for trust kernel (should be Speculum)
// - No boundary validation when agent (Telum) accesses trust kernel (Speculum)
// - No explicit contract usage for Telum ↔ Speculum trust interactions
// - No timeline event emission for trust decisions and mutations
// - No execution seeds for deterministic trust mutation replay
// - Trust layer not operating as a pure Speculum realm component
// - Agent not using trust as a governing force for Telum realm execution
```

- [ ] **Step 4: Commit analysis**

```bash
git add docs/superpowers/plans/2026-05-23-trust-layer-integration.md
git commit -m "feat(trust-integration-realm-binding): analyze current trust layer and agent system for realm-binding compliant trust-gated execution"
```

### Task 2: Design trust layer integration with Realm-Binding enforcement

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Create: `crates/bkg-cli/src/trust_realm_binding.rs` (trust realm binding layer)
- Modify: `crates/bkg-kernel/src/trust/kernel.rs` (add realm ownership)

- [ ] **Step 1: Declare explicit Speculum realm ownership for trust kernel**

```rust
// Add explicit realm ownership to trust kernel:
// - Add realm annotation: #[realm(Speculum)] to trust kernel components
// - Add ownership verification at initialization
// - Add boundary checks for all external resource access
// - Document that trust kernel belongs exclusively to Speculum realm
// - Trust kernel MAY NOT access resources outside Speculum without explicit contracts
```

- [ ] **Step 2: Design Speculum realm boundary enforcement**

```rust
// Design boundary checks for all external interactions:
// - Agent access (Telum realm): require explicit TrustContract
// - Timeline/event system access (Mensa realm): require explicit TimelineContract
// - Healing daemon access (Speculum realm): internal realm access (allowed)
// - Capsule store access (Causa realm): require explicit contract
// - All boundary crossings must use approved causal transition contracts
// - No direct access permitted - all must go through explicit contracts
```

- [ ] **Step 3: Design explicit causal contract usage for trust services**

```rust
// Design how to use explicit contracts for cross-realm trust interactions:
// - Trust evaluation: use TrustContract::evaluate() instead of direct kernel access
// - Trust mutation: use TrustContract::mutate() instead of direct kernel mutation
// - Timeline events: use TimelineContract::emit() instead of direct event emission
// - Each contract must:
//   * Be explicitly declared and versioned
//   * Include policy snapshot hashes for replay
//   * Define exact data flow and transformation rules
//   * Be monitored for compliance
//   * Emit compliance timeline events
```

- [ ] **Step 4: Design trust-gated Telum realm execution with execution seeds**

```rust
// Design how trust governs Telum realm agent execution:
// - Before Telum realm execution (agent tool use): require trust evaluation via contract
// - After Telum realm execution: require trust mutation via contract based on outcome
// - Generate ExecutionSeed for each trust decision:
//   * policy_hash: current Mutatio realm policy snapshot
//   * trust_vector_hash: hash of trust vector before decision
//   * decision_hash: hash of trust inputs and state
//   * timestamp_epoch: deterministic timestamp
// - Include ExecutionSeed in all trust-related timeline events
// - Make trust decisions purely deterministic based on inputs + seed
```

- [ ] **Step 5: Commit design**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-kernel/src/trust/kernel.rs
git commit -m "feat(trust-integration-realm-binding): design speculum realm-bound trust layer with boundary enforcement and explicit contracts"
```

### Task 3: Implement Speculum realm ownership declaration and boundary system

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-kernel/src/trust/kernel.rs`
- Create: `crates/bkg-cli/src/trust_realm_binding.rs`

- [ ] **Step 1: Add explicit Speculum realm ownership to trust kernel**

```rust
// In trust kernel:
// - Add realm ownership declaration: #[realm(Speculum)]
// - Add ownership verification in new() or init()
// - Add runtime boundary checks for all external calls
// - Add methods to verify current realm assignment
// - Log realm ownership verification on initialization
// - Reject any direct access from outside Speculum realm without contract
```

- [ ] **Step 2: Implement realm boundary validation system**

```rust
// Create trust_realm_binding.rs with:
// - TrustContract struct that validates all trust kernel access
// - TrustAccessContract for Telum realm interactions (agent trust evaluation)
// - TimelineAccessContract for Mensa realm interactions (trust event emission)
// - HealingAccessContract for Speculum realm interactions (internal)
// - CausaAccessContract for Causa realm interactions (state persistence)
// - Each contract validates:
//   * Caller is in correct realm (Telum for evaluation, Speculum for kernel)
//   * Access is permitted by explicit contract
//   * Contract version is compatible
//   * Policy snapshot is recorded
//   * ExecutionSeed is included where applicable
```

- [ ] **Step 3: Commit realm ownership and boundary system**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-kernel/src/trust/kernel.rs crates/bkg-cli/src/trust_realm_binding.rs
git commit -m "feat(trust-integration-realm-binding): implement speculum realm ownership declaration and boundary validation system"
```

### Task 4: Implement explicit causal contract usage for trust services

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-cli/src/trust_realm_binding.rs`
- Modify: `crates/bkg-kernel/src/trust/kernel.rs`

- [ ] **Step 1: Replace direct trust kernel access with TrustContract**

```rust
// Instead of direct trust kernel calls from agent (Telum realm):
// OLD: trust_kernel.evaluate(...)
// NEW: TrustContract::evaluate(trust_kernel, ...)
// Where TrustContract:
//   * Validates Telum realm boundary for caller
//   * Validates Speculum realm boundary for trust kernel
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns trust decision
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 2: Replace direct trust mutation with TrustContract**

```rust
// Instead of direct trust kernel mutation:
// OLD: trust_kernel.update(...)
// NEW: TrustContract::mutate(trust_kernel, ...)
// Where TrustContract:
//   * Validates appropriate realm boundaries
//   * Records policy snapshot hash
//   * Emits timeline event via TimelineContract
//   * Returns mutation confirmation
//   * Includes ExecutionSeed in timeline event
```

- [ ] **Step 3: Replace direct timeline access with TimelineContract**

```rust
// Instead of direct event emission from trust kernel:
// OLD: event_bus.publish(...)
// NEW: TimelineContract::emit(event_bus, ...)
// Where TimelineContract:
//   * Validates Speculum realm boundary for emission
//   * Includes ExecutionSeed in event
//   * Ensures deterministic event ordering
//   * Records policy snapshot context
```

- [ ] **Step 4: Implement contract versioning and compliance tracking**

```rust
// Add contract system that:
// - Tracks contract versions used
// - Validates contract compatibility
// - Monitors for contract violations
// - Emits contract compliance timeline events
// - Provides debugging information for contract usage
// - Ensures all cross-realm trust interactions use explicit contracts
```

- [ ] **Step 5: Commit causal contract implementation**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_realm_binding.rs
git commit -m "feat(trust-integration-realm-binding): implement explicit causal contract usage for all trust services"
```

### Task 5: Implement trust-gated Telum realm execution with execution seeds

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-cli/src/trust_realm_binding.rs`

- [ ] **Step 1: Add trust preflight evaluation for Telum realm execution**

```rust
// In agent Coordinator::run() loop, before Telum realm execution (tool use):
// 1. Determine operation and risk level
// 2. Call TrustContract::evaluate_preflight(trust_kernel, operation, risk_level)
// 3. TrustContract validates boundaries and returns TrustDecision
// 4. If not allowed:
//    - Emit TrustDenied timeline event via TimelineContract
//    - Return error to caller
//    - Do not execute tool (Telum realm execution blocked)
// 5. If allowed:
//    - Emit TrustEvaluated timeline event via TimelineContract
//    - Include ExecutionSeed from trust decision
//    - Proceed with Telum realm tool execution
```

- [ ] **Step 2: Add trust postflight mutation based on Telum realm execution outcome**

```rust
// After Telum realm tool execution result is available:
// 1. Determine operation outcome (success/failure/partial)
// 2. Call TrustContract::update_postflight(trust_kernel, operation, outcome, result)
// 3. TrustContract validates boundaries and updates trust vectors
// 4. Emit TrustUpdated timeline event via TimelineContract
// 5. Include ExecutionSeed showing trust mutation context
// 6. Trust kernel updates trust vectors based on outcome
```

- [ ] **Step 3: Implement deterministic trust decision with ExecutionSeed**

```rust
// In TrustContract::evaluate and TrustContract::mutate:
// - Generate ExecutionSeed before trust decision:
//   * policy_hash: get_current_mutatio_policy_snapshot()
//   * trust_vector_hash: hash(trust_vector_before)
//   * decision_hash: hash(trust_inputs, operation, risk_level)
//   * timestamp_epoch: get_deterministic_timestamp()
// - Make trust decision purely function of inputs + ExecutionSeed
// - Store ExecutionSeed with trust decision
// - Include ExecutionSeed in all timeline events
```

- [ ] **Step 4: Commit trust-gated execution implementation**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_realm_binding.rs
git commit -m "feat(trust-integration-realm-binding): implement trust-gated telum realm execution with execution seeds"
```

### Task 6: Implement trust timeline event emission with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/event/` (timeline event definitions)
- Modify: `crates/bkg-cli/src/trust_realm_binding.rs`
- Modify: `crates/bkg-cli/src/agent.rs` (event publishing)

- [ ] **Step 1: Define trust timeline events with Realm-Binding context**

```rust
// Add to timeline event system:
// - TrustEvaluated { operation, risk_level, decision, execution_seed, policy_hash }
// - TrustApplied { operation, outcome, trust_delta, execution_seed, policy_hash }
// - TrustViolated { operation, violation_reason, execution_seed, policy_hash }
// - TrustPolicyApplied { policy_snapshot, reason, execution_seed }
// - TrustDenied { operation, risk_level, decision, execution_seed, policy_hash }
// - TrustContractUsed { contract_type, realms_involved, execution_seed, policy_hash }
// All events must be deterministic and replayable
// All events must show realm-binding compliance
```

- [ ] **Step 2: Implement event emission with Realm-Binding validation**

```rust
// In trust_realm_binding.rs:
// - Emit appropriate timeline events for all trust decisions
// - Validate Speculum realm boundary before emission
// - Include policy snapshot hashes for replay integrity
// - Include ExecutionSeed for deterministic replay
// - Emit contract usage events showing explicit contract compliance
// - Ensure events are emitted synchronously with trust decisions
```

- [ ] **Step 3: Commit timeline event integration**

```bash
git add crates/bkg-cli/src/event/ crates/bkg-cli/src/trust_realm_binding.rs
git commit -m "feat(trust-integration-realm-binding): implement trust timeline event emission with realm-binding compliance"
```

### Task 7: Verify trust-gated execution functionality with Realm-Binding

**Files:**
- Modify: `crates/bkg-cli/src/agent.rs`
- Modify: `crates/bkg-cli/src/trust_realm_binding.rs`

- [ ] **Step 1: Test Speculum realm ownership verification**

```bash
// Test that:
// - Trust kernel correctly declares #[realm(Speculum)]
// - Ownership verification passes at initialization
// - Runtime boundary checks are active
// - No subsystem outside Speculum can incorrectly claim trust kernel ownership
// - Direct access from Telum realm without TrustContract is blocked
```

- [ ] **Step 2: Test Speculum realm boundary enforcement**

```bash
// Test that:
// - Trust kernel access from Telum realm requires TrustContract
// - Timeline access from Speculum realm requires TimelineContract
// - Direct access without contracts is blocked/logged
// - Contract violations are detected and reported
// - Approved contracts function correctly with boundary validation
```

- [ ] **Step 3: Test explicit causal contract usage for trust services**

```bash
// Test that:
// - All cross-realm trust interactions use explicit contracts
// - Contract versions are tracked and validated
// - Policy snapshot hashes are included in timeline events
// - ExecutionSeeds are included in trust-related timeline events
// - Contract compliance events are emitted
// - Deterministic behavior is maintained
```

- [ ] **Step 4: Test trust-gated Telum realm execution with execution seeds**

```bash
// Test that:
// - Telum realm tool execution requires trust preflight evaluation
// - Trust denials block Telum realm execution appropriately
// - Trust evaluations include ExecutionSeed in timeline events
// - Identical trust inputs produce identical ExecutionSeeds
// - Identical inputs + ExecutionSeed produce identical trust decisions
// - Trust mutations include ExecutionSeed in timeline events
// - Timeline events are deterministic replay triggers
```

- [ ] **Step 5: Test Speculum realm trust execution purity**

```bash
// Test that:
// - All trust operations are deterministic Speculum realm executions
// - Side effects are captured via explicit contracts
// - No hidden state mutations occur outside contracts
// - Trust kernel resource usage is deterministic and reportable
// - Realm execution logging shows proper Speculum behavior
```

- [ ] **Step 6: Commit verification**

```bash
git add crates/bkg-cli/src/agent.rs crates/bkg-cli/src/trust_realm_binding.rs
git commit -m "feat(trust-integration-realm-binding): verify speculum realm-bound trust layer with telum realm trust-gated execution"
```
