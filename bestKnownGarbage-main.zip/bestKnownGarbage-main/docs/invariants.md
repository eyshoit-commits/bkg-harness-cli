# bESTKNOWNGarbage — System Invariants

> **Verfassung.** Diese Invarianten sind nicht verhandelbar.
>
> Kein LLM, kein Agent, kein menschlicher Entwickler darf sie ohne explizites Review aller 6 Bereichs-Chains ändern.
>
> Status: **v1.0 — Ratifiziert**

---

## Invariant 01 — Ledger Monopoly

> **Only Motherbrain may mutate ledger truth.**

- Mesh ist read-only. GC ist read-only. Client ist read-only.
- Guard LLM ist advisory only — darf niemals Ledger-Zustand ändern.
- Jeder Write durch Nicht-Motherbrain ist ein System-Fehler und muss in Quarantine führen.

---

## Invariant 02 — Mesh Observation Only

> **Mesh is observational only.**

- Mesh-Knoten sammeln, routen, verteilen — aber sie entscheiden nichts.
- Mesh-Topologie-Änderungen werden gemeldet, nicht exekutiert.
- Ein Mesh-Node, der eigenständig Trust- oder Ledger-Entscheidungen trifft, gilt als kompromittiert.

---

## Invariant 03 — GC Autonomy Cap

> **GC may never quarantine autonomously.**

- GC markiert, priorisiert, kompaktiert — aber quarantiniert nicht.
- Quarantine-Entscheidungen durchlaufen Motherbrain Adjudication.
- GC-Entropy-Werte sind Signale, keine Befehle.

---

## Invariant 04 — Replay Supremacy

> **Replay verification outranks trust score.**

- Ein Replay-Fehler überschreibt jeden noch so hohen Trust Score.
- Trust ohne Replay ist Glaube, kein Wissen.
- Jeder Ledger-Commit muss replay-verifizierbar sein (deterministisch).

---

## Invariant 05 — No Raw LLM Output into Ledger

> **No raw LLM output enters ledger.**

- Jeder LLM-Output wird durch einen strukturierten Extraktionsschritt gefiltert.
- Roh-Output ist kein Wissen, sondern Rauschen.
- LLM-Output gilt erst nach Replay-Verifikation als ledger-fähig.

---

## Invariant 06 — deterministische Execution

> **Same input + same environment = same output.**

- Jede Execution ist deterministisch reproduzierbar.
- Nicht-deterministische Operationen (Random, Zeit, IO) werden isoliert und geloggt.
- Jeder Side Effect wird als Event recorded.

---

## Invariant 07 — Guard LLM ist Advisory, nicht Authority

> **Guard LLM may mark, warn, score, prioritize — but never ban, accept, quarantine, or write truth.**

- ML bleibt advisory layer.
- Stochastic Parrots bekommen keine Exekutivgewalt.
- MMGuard LLM-Output ist ein Signal unter vielen in der Adjudication.

---

## Invariant 08 — BKG-DSL: Intent Graph Required

> **DSL → Intent Graph → Motherbrain Approval → Execution.**

- Keine DSL-Operation darf direkt Ledger, Trust oder System-Calls berühren.
- Intent Graph muss von Motherbrain validiert werden.
- Verstoß = System Mode Switch zu ReadOnly.

---

## Invariant 09 — WriteSeparation

> **Only Motherbrain may write. Mesh and GC are read-only.**

- Mesh: liest Topologie, routet Messages — schreibt nichts.
- GC: liest Ledger, markiert Entropy — schreibt nichts in Ledger.
- Motherbrain: einziger Writer für Ledger und Trust.

---

## Invariant 10 — MEASURE > DECIDE > WRITE

> **Never PREDICT > ASSUME > MUTATE.**

- Jede Zustandsänderung basiert auf gemessenen Daten, nicht auf Vorhersagen.
- Annahmen werden als solche markiert und durchlaufen Verifikation.
- Mutation ohne Measurement ist ein Systemfehler.

---

## Invariant 11 — Frozen Interfaces zwischen Phasen

> **Phase Complete → Interface Freeze → Downstream Implementation.**

- Wenn eine Phase abgeschlossen ist, werden ihre API-Verträge eingefroren.
- Änderungen an gefrorenen Interfaces erfordern ein phasenübergreifendes Review.
- Kein Downstream-System implementiert gegen ein nicht-gefrorenes Interface.

---

## Invariant 12 — TaskState als Mini-Ledger

> **Jeder Task-Step in jeder Chain hat einen nachvollziehbaren Zustand.**

- `Planned` → `InProgress` → `Review` → `Verified` — oder → `Blocked` → `Frozen`
- Kein Step springt von `Planned` nach `Verified`.
- `Frozen` Steps können nur durch phasenübergreifendes Review reaktiviert werden.

---

## Verstöße

Ein Invariant-Violation ist schwerer als ein Bug.

1. **Sofort:** System Mode → ReadOnly oder Quarantine
2. **Analyse:** Root Cause im Ledger festhalten
3. **Korrektur:** Invariant-konformer Fix, kein Workaround
4. **Prävention:** Contract-Test für die verletzte Invariante
5. **Dokumentation:** Violation in `docs/incidents/` archivieren

---

## Ratifizierungsgeschichte

| Datum | Version | Änderung |
|-------|---------|----------|
| 2026-05-23 | v1.0 | Initiale 12 Invarianten |
