# BKG Relay Chain - 2-Layer Ledger System

## Überblick

Das BKG Relay Chain ist ein **federiertes Zwei-Layer-Ledger-System** für Code-Wissen. Es ist KEINE Blockchain, sondern:

- **Proof-of-Validation**
- **Content-addressed ledger**
- **Merkle-basierter Review-Cache**
- **Federated code archive**
- **Hub-and-spoke trust network**
- **Deterministic Knowledge Fabric** (layered architecture invariants)

---

## Architektur

```
┌─────────────────────────────────────────────────────────────┐
│                    LAYER 2: MAIN SERVER                     │
│  ┌─────────────────────────────────────────────────────────┐│
│  │ Validator │ Aggregator │ Publisher │ Trust Authority   ││
│  └─────────────────────────────────────────────────────────┘│
│                            ▲                                │
│                            │ validate & republish          │
│                            ▼                                │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    LAYER 1: NODES                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐      │
│  │  Node A  │ │  Node B  │ │  Node C  │ │  Node D  │      │
│  │ Collector│ │ Collector│ │ Collector│ │ Collector│      │
│  │Pre-Valid │ │Pre-Valid │ │Pre-Valid │ │Pre-Valid │      │
│  │Sync Cli  │ │Sync Cli  │ │Sync Cli  │ │Sync Cli  │      │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘      │
└─────────────────────────────────────────────────────────────┘
```

---

## Layer 1: Nodes

Nodes sind **Sammler und Vorprüfer**.

### Rollen
1. **Collector** - Code finden, Snippets extrahieren
2. **Pre-Validator** - Lokale Qualität prüfen
3. **Sync Client** - Mit Main synchronisieren

### Aufgaben
- Code finden
- Snippets extrahieren
- AST-Fragmente erkennen
- Metadaten anhängen
- Lokale Duplikate entfernen
- Signatur erzeugen
- An Main senden
- Neue akzeptierte Einträge synchronisieren

---

## Layer 2: Main Server

Der Main Server ist die **Single Source of Truth**.

### Aufgaben
- Alle Submissions empfangen
- Signaturen prüfen
- Content Hash prüfen
- Semantische Qualität bewerten
- Spam, Müll, Dubletten aussortieren
- Konsens oder Freigabe erzeugen
- Globale Indexe aktualisieren
- Akzeptierte Daten an Nodes zurückgeben

---

## Datenmodell

### Node Identity


### Chunk


### Enhanced Chunk with Deterministic Knowledge Fabric


### Block


### Ledger State


---

## Fluss

### Upload Flow
```
Node                    Main
  │                       │
  ├─── create chunk ─────┤
  ├─── compute hash ─────┤
  ├─── sign ─────────────┤
  ├─── send ────────────►│
  │                       ├── validate format
  │                       ├── check hash
  │                       ├── verify signature
  │                       ├── deduplicate
  │                       ├── quality score
  │                       ├── policy check
  │                       │
  │◄── response ──────────┤
  │                       │
  │  accepted / rejected / quarantined / duplicate_of / needs_more_proof
```

### Download Flow
```
Main                    Node
  │                       │
  ├─── new chunks ───────►│
  ├─── delta index ──────►│
  ├─── synced blocks ────►│
  ├─── revocations ──────►│
```

---

## Freigabe-Regel

### Minimaler Freigabeprozess
1. Format stimmt
2. Signatur stimmt
3. Hash stimmt
4. Duplikatcheck bestanden
5. Qualitätsscore über Schwellwert
6. Optional: Test-/Build-Beleg vorhanden
7. Policy-Check bestanden

### Release Gate (3 Stufen)
- **accept** - Vollständig akzeptiert
- **accept_with_warning** - Akzeptiert mit Warnung
- **quarantine** - Zurückgehalten

---

## Was ins Archive darf

### Gut ✓
- Funktionierende Codezeilen
- Getestete Fixes
- Bekannte Patterns
- API-Beispiele
- Fehlersymptome + Lösung
- AST-Ausschnitte
- Imports
- Compiler-/Linter-konforme Fragmente
- Sicherheits-Patches

### Nicht gut ✗
- Komplette private Repos
- Sensible Secrets
- Müllsnippets ohne Kontext
- Halluzinierte Lösungen
- Daten ohne Herkunft

---

## Sicherheitsmodell

### Regeln
- Nodes dürfen NICHT direkt global schreiben
- Nur der Main darf final committen
- Jeder Node hat eigene Identity
- Jede Submission ist signiert
- Secrets werden nie akzeptiert
- Content wird sandboxed analysiert
- Unsichere Artefakte → Quarantäne

### Quarantäne-Schicht
Alles Unbestätigte landet im Zwischenbereich:
- Unbestätigter Inhalt
- Dubiose Signaturen
- Unklare Herkunft
- Unsichere Patches
- Mögliche Duplikate

---

## Reputation System

### Trust Score steigt durch
- Gute Submissions
- Erfolgreiche Verifikation
- Seltene Dubletten
- Nützliche Beiträge

### Trust Score sinkt durch
- Müll
- Spam
- Fehlerhafte Metadaten
- Falsche Signaturen
- Wiederholt unsichere Inhalte

---

## Erweiterungen

### Semantic Deduplication
Nicht nur exakte Hashes, sondern erkennen:
- Gleiche Funktion mit anderer Formatierung
- Umgeschriebene Imports
- Leicht veränderte Fixes
- Semantisch identische Patterns

Dafür nötig:
- AST-Hash
- Symbol-Graph
- Embeddings
- Normalisierung

### Evidence Pack
Jeder akzeptierte Eintrag trägt Beweispaket:


### Revocation Layer
Wenn ein Chunk problematisch wird:


### Proof-of-Use
Chunk bekommt Punkte wenn:
- Oft wiederverwendet
- Builds verbessert
- Tests bestehen hilft
- Fehlerbehebungen verkürzt
- In mehreren Projekten auftaucht

### Deterministic Knowledge Fabric Enhancements

#### Semantic Lineage Graph


#### Execution Receipts


#### Environment Fingerprint


#### Epistemic States


---

## Konsensmodell

### Main-Authority Consensus
Der Main entscheidet final. Nodes liefern nur Kandidaten.

### Optionale Erweiterungen
- Mehrere Main-Validatoren
- Quorum-Freigabe
- Hot-Standby-Main
- Review-Signaturen von Trusted Nodes

---

## Zwei Ebenen von Wahrheit

| Ebene | Beschreibung |
|-------|--------------|
| **Lokale Wahrheit** | Node glaubt, Snippet ist gut |
| **Globale Wahrheit** | Main bestätigt Aufnahme in gemeinsame Datenbasis |

---

## Formel

```
Node Layer = sammeln, signieren, senden
Main Layer = prüfen, committen, verteilen
```

Oder noch knapper:

```
collect → verify → commit → republish
```

---

## Integrität

Das System garantiert:
- **Unveränderbarkeit** - Durch Hash-Verkettung
- **Auditierbarkeit** - Jeder Eintrag nachvollziehbar
- **Rückverfolgbarkeit** - Herkunft sichtbar
- **Rollback-Schutz** - Revocation statt Löschen

---

## Integration in BKG

### Als Crate
```
crates/
└── bkg-ledger/
    ├── src/
    │   ├── lib.rs
    │   ├── chunk.rs
    │   ├── block.rs
    │   ├── node.rs
    │   ├── main.rs
    │   ├── validator.rs
    │   ├── sync.rs
    │   └── reputation.rs
    └── Cargo.toml
```

### CLI Commands
```bash
bkg ledger status              # Ledger-Status
bkg ledger submit <chunk>      # Chunk einreichen
bkg ledger sync                # Mit Main synchronisieren
bkg ledger search <query>      # Im Ledger suchen
bkg ledger revoke <chunk-id>   # Chunk widerrufen
```

---

## Zusammenfassung

```
Nodes sind die Trichter
Main ist der Filter
Ledger ist das Archiv
```

Das BKG Relay Chain macht aus einem Agenten-Tool ein **echtes Wissenssystem** mit verlässlicher, geprüfter Code-Basis.
