# BKG-WASM UI-Architektur

## Philosophie

BKG UI ist **KEIN** Chatbot-Frontend. Es ist eine **Live Operating Console** für deterministische AI-Ausführung.

### Kein
- Chat Bubbles
- Generic Assistant UX
- Copilot Clone
- Pretty Dashboard Only

### Sondern
- **Observability** - Kernel-Events live
- **Verification** - SWD-Inspektion
- **Orchestration** - DAG-Visualisierung
- **Replay** - Time-travel Debugging
- **Authority** - Memory Authority Viewer
- **Control** - Permission Inspector

---

## Screen Layout

```
┌─────────────────────────────────────────────────────────────┐
│ TOP BAR (Session, Status, Controls)                        │
├────────────┬────────────────────┬───────────────────────────┤
│ EVENT      │ DAG EXECUTION      │ SWD INSPECTOR             │
│ STREAM     │ GRAPH              │ (Semantic Verification)   │
│ (Live)     │ (Animated)         │                           │
├────────────┼────────────────────┼───────────────────────────┤
│ MEMORY     │ LIVE TERMINAL      │ AGENT RUNTIME             │
│ AUTHORITY  │ TOOL OUTPUT        │ INSPECTOR                 │
│ (MEMORY.md)│ (Streaming)        │ (States, Tokens)          │
├────────────┼────────────────────┼───────────────────────────┤
│ REPLAY     │ DIFF VISUALIZER    │ PERMISSIONS               │
│ TIMELINE   │ (Side-by-side)     │ (Capability Graph)        │
│ (Scrubber) │                    │                           │
└────────────┴────────────────────┴───────────────────────────┘
```

---

## 15 Core UI Modules

### 1. Event Stream Panel
Real-time kernel event visualization.

**Features:**
- Live append
- Event coloring by severity
- Filtering and search
- Event replay jump
- JSON inspection



### 2. DAG Execution Graph
Visualize execution orchestration.

**Features:**
- Animated execution edges
- Node state transitions
- Retry indicators
- Cancellation propagation
- Dependency locks
- Sub-agent clustering



### 3. SWD Inspector
Reality verification visualization.

**Features:**
- Before/after hash view
- Semantic validation status
- AST verification
- Patch receipts
- Rollback state
- Trust score

### 4. Diff Visualizer
Git-grade patch visualization.

**Features:**
- Side-by-side diffs
- Syntax highlighting
- AST-aware highlights
- Whitespace suppression
- Rollback preview

### 5. Memory Authority Panel
Real AI memory authority display.

**Features:**
- MEMORY.md live rendering
- Memory mutations
- Dream compression results
- Authority locking
- Historical snapshots

### 6. Agent Runtime Inspector
Active agent monitoring.

**Features:**
- Agent states
- Token usage
- Runtime latency
- Tool usage
- Context size
- Memory usage

### 7. Replay Timeline
Time-travel debugging.

**Features:**
- Replay slider
- Event scrubbing
- Session snapshots
- State restoration
- DAG rewinds

### 8. Permission Inspector
Security visualization.

**Features:**
- Filesystem permissions
- Process permissions
- Network access
- Sandbox violations
- Capability graphs

### 9. CRDT Conflict Viewer
Multi-agent collision resolution.

**Features:**
- Merge previews
- Branch comparison
- Conflict ownership
- Resolution proposals

### 10. Workspace Virtualization Panel
Isolated workspace visualization.

**Features:**
- Active worktrees
- Overlay mounts
- Sandbox roots
- Workspace cloning

### 11. Live Terminal Panel
Kernel shell output.

**Features:**
- Streaming stdout/stderr
- Shell execution history
- Command replay
- PTY integration

### 12. Tool Capability Graph
Visual dependency engine.

**Features:**
- Capability inheritance
- Dependency edges
- Permission resolution
- Execution prerequisites

### 13. Runtime Metrics Panel
Kernel observability.

**Metrics:**
- events/sec
- active agents
- queue depth
- memory usage
- websocket latency
- DAG throughput

### 14. Panic Monitor
Kernel failure tracking.

**Features:**
- Runtime panic logs
- Crash receipts
- State snapshots
- Recovery suggestions

### 15. Session Branching UI
Git-like future branching.

```bash
/session fork exploit-attempt
/session fork architecture-refactor
```

---

## Dioxus Component Tree

```
App
├── TopBar
├── Sidebar
├── EventStreamPanel
├── DAGViewerPanel
├── SWDInspectorPanel
├── DiffPanel
├── ReplayTimeline
├── RuntimeMetrics
├── AgentInspector
├── MemoryPanel
├── PermissionPanel
├── WorkspacePanel
├── PluginPanel
├── NotificationOverlay
└── PanicOverlay
```

---

## WebSocket Protocol



---

## Streaming Engine



---

## Visual Design

### Theme
- **Background**: Black
- **Panels**: Graphite
- **Success**: Emerald
- **Warnings**: Amber
- **Failures**: Crimson
- **Replay**: Violet

### Typography
- Monospace kernel fonts
- Compact density
- Terminal-inspired spacing

### Style
- No rounded SaaS design
- No giant padding
- No bubble-chat UX

**Feels like:**
- Debugger
- Kernel Monitor
- Cybernetic Runtime Console

---

## Rendering Strategy

### Use
- Virtualized lists
- Signal-based updates
- Memoized graph nodes
- Incremental rendering
- WebSocket streaming
- Async task queues

### Avoid
- Full rerenders
- Giant contexts
- Blocking renders
- React-style prop hell

---

## Performance Targets

```
100k events replayable
10k DAG nodes
60fps graph updates
sub-5ms event append
sub-50ms replay scrubbing
```

---

## Build Order

### Stage 1
- Event stream
- WebSocket layer
- Metrics
- Panel layout

### Stage 2
- SWD inspector
- Replay timeline
- Diff engine

### Stage 3
- DAG visualization
- CRDT viewer
- Workspace virtualization

### Stage 4
- Plugin runtime
- RE modules
- Symbolic execution overlays
