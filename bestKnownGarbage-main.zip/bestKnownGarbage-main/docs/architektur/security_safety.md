# Security & Safety Architecture

> Critical defenses before the Relay Network becomes a "juridical landmine-as-a-service".

## Priority Matrix

| Priority | System | Risk Level | Impact |
|----------|--------|------------|--------|
| P0 | Secret Detection | Critical | Data breach, credential leak |
| P0 | License Classification | Critical | Legal liability, GPL infection |
| P0 | Poisoning Defense | Critical | Malware, crypto miners, exploits |
| P0 | Execution Sandbox | Critical | System compromise |
| P1 | Temporal Validity | High | Stale/broken code propagation |
| P1 | Knowledge Decay | High | Fossilization, CVE propagation |
| P1 | Deny Raw LLM Output | High | Hallucination pollution |
| P2 | Failure Knowledge Graph | Medium | Repeated failures, no learning |
| P2 | Hybrid Search | Medium | Poor retrieval quality |
| P2 | Reputation Tiers | Medium | Trust manipulation |
| P3 | Federated Mains | Low-Medium | Single point of failure |
| P3 | Local First | Low-Medium | Offline unusability |

---

## 1. LICENSE + COPYRIGHT LAYER

### Problem
Nodes blindly collecting code run into:
- GPL infection (strong copyleft contamination)
- Copyright violations
- Private company IP leaks
- Legal liability

### Solution



### License Detection Strategy

1. **File-level detection**: Check LICENSE, LICENSE.md, COPYING files
2. **SPDX headers**: Parse `// SPDX-License-Identifier:` comments
3. **Package metadata**: Cargo.toml, package.json, requirements.txt
4. **Heuristic matching**: Compare against license templates
5. **Fallback**: Mark as `Unknown` with high contamination risk

### Acceptance Rules



---

## 2. SECRET DETECTION ENGINE

### Problem
Nodes might submit:
- `.env` files with API keys
- AWS credentials
- SSH private keys
- Database passwords
- JWT secrets

### Solution



### Acceptance Flow

```text
submit chunk
    ↓
secret scanner
    ↓
┌─────────────────┐
│ secrets found?  │
└────────┬────────┘
         │
    ┌────┴────┐
    NO       YES
    │         │
    ↓         ↓
  accept   quarantine
           │
           ↓
    notify submitter
    require remediation
```

---

## 3. POISONING DEFENSE

### Problem
Malicious nodes might submit:
- `unsafe { transmute(...) }` disguised as "memory optimization"
- Cryptominers
- Exploit code
- Obfuscated malware
- Logic bombs

### Solution



---

## 4. EXECUTION SANDBOX

### Problem
Never run untrusted code on Main. Ever.

### Solution: Multi-Layer Containment



### Acceptance Flow

```text
code submitted
    ↓
static analysis (no execution)
    ↓
[if requires testing]
    ↓
sandbox execution
    ↓
monitor for:
  - unexpected network calls
  - file system modifications
  - process spawning
  - resource exhaustion
    ↓
[violations?]
    ↓
quarantine + report
```

---

## 5. TEMPORAL VALIDITY

### Problem
Code ages. A snippet working today may be broken in 6 months.

### Solution



---

## 6. KNOWLEDGE DECAY ENGINE

### Problem
Without decay, the ledger becomes a "digital fossil graveyard".

### Solution



---

## 7. DENY RAW LLM OUTPUT

### Problem
Raw AI output pollutes the ledger with:
- Hallucinated APIs
- Inconsistent patterns
- Unverified code
- StackOverflow fanfiction

### Solution: AI Output Pipeline



---

## 8. FAILURE KNOWLEDGE GRAPH

### The Most Valuable Part



### Query Interface



---

## 9. HYBRID SEARCH

### Problem
Embeddings alone hallucinate. Need structural search.

### Solution



---

## 10. REPUTATION TIERS



---

## Implementation Priority

### Phase 1: Critical (Week 1-2)
1. Secret Detection Engine
2. License Classification
3. Poisoning Defense (static analysis)
4. Basic Sandbox (Wasmtime)

### Phase 2: High Priority (Week 3-4)
1. Temporal Metadata
2. Knowledge Decay Engine
3. AI Output Normalizer
4. Failure Knowledge Graph

### Phase 3: Medium Priority (Month 2)
1. Hybrid Search
2. Reputation Tiers
3. Enhanced Sandbox (Firecracker)

### Phase 4: Future (Month 3+)
1. Federated Mains
2. Build Farm
3. Semantic Merge Engine
4. Deterministic Replay

---

## Key Principle

> "Is this useful?" is NOT enough.
> 
> You need: "Is this DANGEROUS?"

Never accept raw LLM output. Always verify. Always sandbox. Always decay.
