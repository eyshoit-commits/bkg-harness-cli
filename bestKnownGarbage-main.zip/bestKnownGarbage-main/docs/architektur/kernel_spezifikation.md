# BKG-WASM Master Plan — Complete Feature Roadmap

## Vision

**BKG (Chronos)** wird ein **deterministisches agentisches Betriebssystem** für autonome Wissensarbeit. Es vereint:

1. **Crush (Go)** - TUI, LSP/MCP, Provider-Abstraktion
2. **Hackcode (Python/Rust)** - Runtime, Tools, Commands  
3. **Kernel-Architektur** - Workspace Hypervisor, Verification Runtime
4. **Managed Agents** - Manager/Executor, Budget-System
5. **Dioxus UI** - Live Operating Console

---

## Architektur-Übersicht

```
bKG-WASM (aktuell: bESTKNOWNGarbage/)
├── crates/
│   ├── bkg-core/               # Basistypen (Error, Config, Message, Session, Types)
│   ├── bkg-kernel/             # Epistemic Kernel (Trust, Causality, Mesh, Motherbrain, etc.)
│   ├── bkg-provider/           # LLM Provider (OpenAI, Anthropic, Gemini, etc.)
│   ├── bkg-tools/              # Tool System (bash, edit, write, grep, etc.)
│   ├── bkg-api/                # HTTP API Client + Streaming
│   └── bkg-cli/                # CLI Entry Point
├── projects/bkg-web/           # Dioxus Landing Page (bkg-wasm.dev)
├── go/crush/                   # Go Implementation (unverändert)
├── python/hackcode/            # Python Reference (unverändert)
└── docs/                       # Dokumentation

→ Restructured aus v0.1a/ (Monolith) + python/hackcode/rust/ (Production Crates)
```

---

## Teil 1: Core Features

### 1.1 Basis-Typen ✅
| Modul | Status | Datei |
|-------|--------|-------|
| Message | ✅ | `message.rs` |
| Session | ✅ | `session.rs` |
| Error | ✅ | `error.rs` |
| Config | ✅ | `config.rs` |
| Agent Coordinator | ✅ | `agent.rs` |

### 1.2 Tools ✅
| Tool | Status | Datei |
|------|--------|-------|
| bash | ✅ | `tools/bash.rs` |
| edit | ✅ | `tools/edit.rs` |
| multiedit | ✅ | `tools/multiedit.rs` |
| view | ✅ | `tools/view.rs` |
| write | ✅ | `tools/write.rs` |
| grep | ✅ | `tools/grep.rs` |
| glob | ✅ | `tools/glob.rs` |
| ls | ✅ | `tools/ls.rs` |
| fetch | ✅ | `tools/fetch.rs` |
| web_search | 📋 | - |
| download | 📋 | - |
| todos | 📋 | - |

### 1.4 Mesh, GC & Trust Engine (P3, P7.5, P4/P5)

| Module | Status | Datei |
|--------|--------|-------|
| P3: Mesh (Sensory) | ✅ | `mesh/mod.rs`, `mesh/message.rs`, `mesh/node.rs`, `mesh/transport.rs`, `mesh/entropy.rs` |
| P7.5: GC Foundation | ✅ | `gc/mod.rs`, `gc/collector.rs`, `gc/entropy.rs`, `gc/archive.rs`, `gc/decay.rs`, `gc/topology.rs` |
| P4: Trust Engine | ✅ | `trust_engine/mod.rs` |
| P5: HeroDaemon | ✅ | `trust_engine/hero_daemon.rs` |
| Demo (Mesh→GC) | ✅ | `main.rs` (demo-mesh-gc) |

#### Mesh — Sensory Nervous System

**Was Mesh macht:**
- TCP gossip broadcast (tokio::net)
- Heartbeat propagation
- Trust vector updates (pass-through)
- Entropy region distribution (read from local state, broadcast globally)
- Ledger delta hints (hash + depth, not full state)

**Was Mesh NICHT macht:**
- Kein automatisches Quarantine
- Kein Topology Rewiring
- Keine Trust Manipulation
- Keine Isolation Decisions
- Keine Aktion über Forwarding hinaus

**Nachrichtentypen:** Heartbeat, TrustUpdate, EntropyMap, LedgerDelta

#### GC Foundation — Lymphatic System

**GC Action Modes (abgestuft):**
1. `ObserveOnly` — aktuell: nur lesen, messen, markieren
2. `Suggest` — später: Recommendations an Motherbrain
3. `Escalate` — später: Urgent Alerts für Hotspots
4. `Autonomous` — viel später: approved automated actions

**GC Core Responsibilities:**
1. **Entropy Tracking** — Mesh EntropyMaps konsumieren, globale Stabilität berechnen
2. **Archive Tiers** — Daten verschieben: hot → warm → cold → frozen
3. **Replay Dust Cleanup** — identische Replay-Traces komprimieren (Merkle)
4. **Decay Tagging** — Ledger-Einträge mit decay_score markieren (read-only)

**Was GC NICHT macht:**
- Kein Auto-Quarantine
- Kein Autonomous Isolation
- Kein Topology Rewiring
- Kein Node Demotion
- Keine Trust Manipulation

→ Alle disruptiven Aktionen benötigen Motherbrain-Approval.

### 1.5 Provider
| Provider | Status |
|----------|--------|
| Provider Trait | ✅ |
| Anthropic | 📋 |
| OpenAI | ✅ |
| Gemini | 📋 |
| Azure OpenAI | 📋 |
| Streaming Support | 📋 |

---

## Teil 2: Kernel-Architektur

### 2.1 Workspace Hypervisor
AI arbeitet **NIEMALS** direkt auf echten Dateien.

```
/workspaces/
├── session-a/
│   ├── overlay/      # OverlayFS writable layer
│   ├── receipts/     # Operations-Nachweise
│   ├── snapshots/    # Datei-Snapshots
│   ├── memory/       # Session-Memory
│   └── events/       # Event-Logs
└── session-b/
```

| Komponente | Status | Crate |
|------------|--------|-------|
| OverlayFS Integration | 📋 | `bkg-kernel` |
| Snapshot Engine | 📋 | `bkg-kernel` |
| Receipt System | 📋 | `bkg-kernel` |
| Event Log | 📋 | `bkg-events` |

### 2.2 Verification Runtime (SWD++)
**AI darf behaupten, BKG beweist.**

```
AI Output → Action Extraction → Patch Planner → Semantic Verifier
    ↓
AST Verification → Symbol Verification → Build Validation → Test Validation
    ↓
Receipt Engine → Commit or Rollback
```

| Prüfung | Sprache | Tool |
|---------|---------|------|
| AST | Rust | syn |
| AST | TypeScript | swc |
| AST | Python | ruff |
| Build | Rust | cargo check |
| Tests | Rust | cargo test |

**Receipt Model:**


### 2.3 Memory Authority Engine
Memory als **Authority Layer**, nicht als Datenbank.

```
MEMORY.md (Source of Truth)
    │
    ├── FTS5 Index
    ├── Symbol Graph
    ├── Semantic Cache
    ├── Embeddings
    └── Dream Compression
```

| Feature | Status | Crate |
|---------|--------|-------|
| MEMORY.md Parser | 📋 | `bkg-memory` |
| FTS5 Index | 📋 | `bkg-memory` |
| Symbol Graph | 📋 | `bkg-memory` |
| Dream Compression | 📋 | `bkg-memory` |

### 2.4 Capability Security Kernel
**Deny-by-default** Security.

```yaml
agent: reviewer
permissions:
  filesystem:
    - read
  network:
    - docs.rs
  shell:
    - cargo check
```

| Feature | Status | Crate |
|---------|--------|-------|
| Capability Model | 📋 | `bkg-permissions` |
| Tool Contracts | 📋 | `bkg-permissions` |
| WASM Sandbox | 📋 | `bkg-permissions` |

---

## Teil 3: Managed Agents

### 3.1 Rollenmodell
```
Manager (Depth 0)
    │
    └── Executor (Depth 1)
            │
            └── KEINE weiteren Agents!
```

### 3.2 Harte Regeln
1. **Max Depth = 1**
2. **Budget Cap** - Kein Spawn ohne Budget
3. **Isolation** - Eigene Historie/Session-IDs
4. **Max Concurrency** - Default: 5 Executors
5. **Policy Violation = Abort**

### 3.3 Budget-System


### 3.4 Presets
| Name | Manager | Executor | Split |
|------|---------|----------|-------|
| anthropic-tiered | claude-sonnet-4 | claude-3-haiku | 20% |
| google-tiered | gemini-2.0-pro | gemini-2.0-flash | 20% |
| cross-opus | claude-sonnet-4 | gpt-4o-mini | 30% |
| budget | gpt-4o-mini | gpt-4o-mini | 50% |

### 3.5 Implementierung
| Komponente | Status | Datei |
|------------|--------|-------|
| AgentRole | 📋 | `agent/role.rs` |
| ManagedBudget | 📋 | `agent/budget.rs` |
| ManagedOrchestrator | 📋 | `agent/orchestrator.rs` |
| AgentTool | 📋 | `tools/agent.rs` |

---

## Teil 4: Dioxus Kernel UI

### 4.1 UI-Philosophie
Chronos UI ist **KEIN** Chatbot-Frontend. Es ist eine **Live Operating Console**.

**Kein:**
- Chat Bubbles
- Generic Assistant UX
- Copilot Clone
- Pretty Dashboard Only

**Sondern:**
- Observability
- Verification
- Orchestration
- Replay
- Authority
- Control

### 4.2 Screen Layout
```
┌─────────────────────────────────────────────────────────────┐
│ TOP BAR                                                     │
├────────────┬────────────────────┬───────────────────────────┤
│ EVENT      │ DAG EXECUTION      │ SWD INSPECTOR             │
│ STREAM     │ GRAPH              │                           │
├────────────┼────────────────────┼───────────────────────────┤
│ MEMORY     │ LIVE TERMINAL      │ AGENT RUNTIME             │
│ AUTHORITY  │ TOOL OUTPUT        │ INSPECTOR                 │
├────────────┼────────────────────┼───────────────────────────┤
│ REPLAY     │ DIFF VISUALIZER    │ PERMISSIONS               │
│ TIMELINE   │                    │                           │
└────────────┴────────────────────┴───────────────────────────┘
```

### 4.3 Core UI Modules

#### 1. Event Stream Panel
Real-time kernel event visualization.



#### 2. DAG Execution Graph
Execution orchestration visualization.



#### 3. SWD Inspector
Reality verification visualization.

#### 4. Diff Visualizer
Git-grade patch visualization.

#### 5. Memory Authority Panel
Real AI memory authority display.

#### 6. Agent Runtime Inspector
Active agent monitoring.



#### 7. Replay Timeline
Time-travel debugging.



#### 8. Permission Inspector
Security visualization.

#### 9. CRDT Conflict Viewer
Multi-agent collision resolution.

#### 10. Workspace Virtualization Panel
Isolated workspace visualization.

#### 11. Live Terminal Panel
Kernel shell output.

#### 12. Tool Capability Graph
Visual dependency engine.

#### 13. Runtime Metrics Panel
Kernel observability.

#### 14. Panic Monitor
Kernel failure tracking.

#### 15. Session Branching UI
Git-like future branching.

```
/session fork exploit-attempt
/session fork architecture-refactor
```

### 4.4 Dioxus Component Tree
```
App
├── TopBar
├── Sidebar
├── EventStreamPanel
├── DAGViewerPanel
├── SWDInspectorPanel
├── DiffPanel
├── ReplayTimeline
├── RuntimeMetrics
├── AgentInspector
├── MemoryPanel
├── PermissionPanel
├── WorkspacePanel
├── PluginPanel
├── NotificationOverlay
└── PanicOverlay
```

### 4.5 WebSocket Protocol


### 4.6 Streaming Engine


### 4.7 Visual Design
- **Theme**: Black background, graphite panels, neon states
- **Colors**: Emerald success, Amber warnings, Crimson failures, Violet replay
- **Typography**: Monospace, compact density
- **Style**: Debugger, Kernel Monitor, Cybernetic Console

### 4.8 Performance Targets
```
100k events replayable
10k DAG nodes
60fps graph updates
sub-5ms event append
sub-50ms replay scrubbing
```

---

## Teil 5: Build Roadmap

### Phase 1: Core (Woche 1-2) ✅
- [x] Basis-Typen
- [x] 9 Tools
- [x] Provider-Abstraktion (OpenAI)
- [ ] Streaming Support

### Phase 1.5: Mesh, GC & Trust Engine (Woche 2-3) ✅
- [x] P3: Distributed Mesh (gossip protocol, EntropyRegion)
- [x] P7.5: GC Foundation (EntropyTracker, Archive, Decay, Topology)
- [x] P4/P5: Trust Engine + HeroDaemon (role transitions, kernel integration)
- [x] Demo: Mesh→GC Observation Pipeline

### Phase 2: Integration (Woche 3-4)
- [ ] LSP Client
- [ ] MCP Client
- [ ] Hooks System
- [ ] Skills System

### Phase 3: Kernel (Woche 5-8)
- [ ] Workspace Hypervisor
- [ ] Snapshot Engine
- [ ] Verification Runtime (SWD++)
- [ ] Memory Authority
- [ ] Deterministic Knowledge Fabric Core

### Phase 3.5: Relay Chain (Woche 8-9)
- [ ] Node Identity System
- [ ] Chunk/Block Datenmodell
- [ ] Main Validator
- [ ] Sync Protocol
- [ ] Reputation System
- [ ] Split Storage Architecture
- [ ] Semantic Lineage Graph
- [ ] Execution Receipts
- [ ] Deterministic Environments
- [ ] Detonation Sandbox
- [ ] Epistemic States
- [ ] Consensus Through Reproduction
- [ ] Compiler Oracle Layer
- [ ] CVE Correlation Engine
- [ ] Time Travel Queries

### Phase 4: Managed Agents (Woche 10-11)
- [ ] AgentRole Enum
- [ ] Budget-Tracker
- [ ] ManagedOrchestrator
- [ ] AgentTool
- [ ] Presets

### Phase 5: UI Stage 1 (Woche 11-12)
- [ ] Event Stream
- [ ] WebSocket Layer
- [ ] Metrics
- [ ] Panel Layout

### Phase 6: UI Stage 2 (Woche 13-14)
- [ ] SWD Inspector
- [ ] Replay Timeline
- [ ] Diff Engine
- [ ] Knowledge Graph Visualization

### Phase 7: UI Stage 3 (Woche 15-16)
- [ ] DAG Visualization
- [ ] CRDT Viewer
- [ ] Workspace Virtualization
- [ ] Trust Metrics Display

### Phase 8: UI Stage 4 (Woche 17-18)
- [ ] Plugin Runtime
- [ ] RE Modules
- [ ] Symbolic Execution Overlays
- [ ] Collaborative Knowledge Building

---

## Teil 6: CLI Commands

### Standard
```bash
bkg                           # Interactive
bkg "prompt"                  # Non-interactive
bkg --session <id>            # Continue session
bkg --continue                # Last session
bkg --yolo                    # Auto-accept
```

### Kernel
```bash
bkg workspace list            # List workspaces
bkg workspace snapshot        # Create snapshot
bkg workspace rollback        # Rollback
bkg workspace receipts        # Show receipts
```

### Managed Agents
```bash
bkg managed status            # Status
bkg managed enable            # Enable
bkg managed preset <name>     # Select preset
bkg managed budget            # Budget status
```

### Session Branching
```bash
bkg session fork <name>       # Fork session
bkg session merge <id>        # Merge branch
bkg session compare <id>      # Compare branches
```

---

## Zusammenfassung

**BKG (Chronos)** wird:

| Quelle | Features |
|--------|----------|
| Crush (Go) | TUI, LSP, MCP, Provider, Hooks, Skills |
| Hackcode (Python/Rust) | Runtime, Tools, Commands |
| Kernel | Workspace Hypervisor, SWD++, Memory Authority |
| Managed Agents | Manager/Executor, Budgets, Presets |
| Dioxus UI | 15 UI Modules, WebSocket, Replay |

**Total: 200+ Features** in einer einheitlichen Rust-Codebase mit WASM-Support.
