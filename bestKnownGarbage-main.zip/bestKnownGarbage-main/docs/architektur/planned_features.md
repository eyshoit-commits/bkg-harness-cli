# BKG-WASM — Geplante Features

> Alles was noch nicht im Code ist. Implementierte Features → siehe `crates/` und `docs/llm.nfo`.

## Kernel-Architektur
- [ ] Workspace Hypervisor (OverlayFS)
- [ ] Snapshot Engine
- [ ] Verification Runtime (SWD++)
- [ ] Memory Authority Engine
- [ ] Capability Security Kernel

## Managed Agents
- [ ] Manager/Executor Roles
- [ ] Budget-Tracking
- [ ] ManagedOrchestrator
- [ ] Presets (anthropic-tiered, google-tiered, etc.)

## WASM
- [ ] wasm-bindgen Bindings
- [ ] Virtual Filesystem
- [ ] IndexedDB Storage
- [ ] Real WASM execution (wasmtime)
- [ ] Web Demo

## LSP / MCP Integration
- [ ] LSP Manager & Client
- [ ] Diagnostics / References Tools
- [ ] MCP Client & Tool Discovery
- [ ] Hooks System (PreToolUse)
- [ ] Skills System (SKILL.md)
- [ ] Permissions System

## TUI
- [ ] Ratatui App
- [ ] Chat View, Dialogs, Diff View

## Release
- [ ] Config file loading
- [ ] Comprehensive Tests
- [ ] Performance Optimization
- [ ] CI/CD Pipeline
- [ ] Release Build

---

**Implementierte Features:** Siehe Codebase (`crates/`), [roadmap.md](../roadmap.md) und [llm.nfo](../llm.nfo).
