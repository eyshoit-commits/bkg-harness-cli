---
plan name: ucc4-kernel
plan description: Implement UCC-4 self-evolving kernel
plan status: active
---

## Idea
Implement the UCC-4 Self-Evolving Kernel as a 17-file orchestration layer in bkg-core/src/kernel/. Builds on top of the existing capsule module with 84 passing tests. Covers 5 submodules: memory, execution, truth, time, evolution. Core types: ExecutionReceipt, PolicySnapshot, CapsuleSnapshot, TimelineEvent, RepairContext. Key invariants: execution_seed for semantic determinism, convergent repair (max 3, monotonic), causal timeline graph, immutable receipts/truth.

## Implementation
- 1. Create kernel/contracts.rs — constants, invariants, error types
- 2. Create kernel/ucc4.rs — Ucc4Kernel trait, return types
- 3. Create kernel/execution/receipts.rs — ExecutionReceipt, PolicySnapshot, CapsuleSnapshot
- 4. Create kernel/execution/dag.rs — Node, Edge, topological sort
- 5. Create kernel/execution/executor.rs — parallel DAG runner with execution_seed
- 6. Create kernel/truth/drift.rs — DriftType, divergence_score
- 7. Create kernel/truth/verifier.rs — TruthGate (PASS/WARN/DIVERGENT)
- 8. Create kernel/truth/repair.rs — repair engine with MAX_REPAIR_ATTEMPTS=3
- 9. Create kernel/time/timeline.rs — TimelineEvent with parent_event causal linking
- 10. Create kernel/time/replay.rs — ReplayEngine + ReplayContext (4 modes)
- 11. Create kernel/time/diff.rs — ReplayDiff output types
- 12. Create kernel/memory/filesystem.rs — immutable receipt/truth storage
- 13. Create kernel/memory/index.rs — capsule registry/index
- 14. Create kernel/evolution/policy.rs — PolicySnapshot, PolicyRecord
- 15. Create kernel/evolution/learner.rs — history-only learning
- 16. Create kernel/evolution/queue.rs — async evolution event queue
- 17. Create kernel/mod.rs — Ucc4Kernel orchestrator, re-exports, integration
- 18. Wire into lib.rs, verify all 84 capsule tests pass
- 19. Integration tests: full hot path, convergent repair, replay determinism

## Required Specs
<!-- SPECS_START -->
<!-- SPECS_END -->