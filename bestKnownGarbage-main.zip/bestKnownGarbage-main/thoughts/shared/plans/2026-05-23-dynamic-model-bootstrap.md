# Implementation Plan: Dynamic Model Bootstrap System

## Summary

Bootstrap becomes the **System Genesis Layer** — BIOS + Initramfs + Package Manager + Recovery Mode für BKG. Architecture: `Bootstrap → Capsule → Runtime → Coordinator (lazy)`.

Bootstrap lebt in **bkg-core** (nicht CLI), weil API, Daemon, TUI und Replay Engine ihn auch brauchen.

## Phase 1: Bootstrap Core in bkg-core

### Task 1.1 — Create bootstrap module with phase types
- **Dir:** `crates/bkg-core/src/bootstrap/`
- **Files:** `mod.rs`, `phase.rs`, `report.rs`
- **Deps:** None
- **Implements:**
  - `mod.rs` — `pub mod phase; pub mod report;`
  - `phase.rs`:
    ```rust
    pub enum BootstrapPhase {
        ConfigLoad,
        CapsuleRehydration,  // ← NEW: self-healing entry
        ProviderDetection,
        ModelDiscovery,
        CoordinatorResolution,  // ← produces spec, not instance
        SetupWizard,
        Ready,
    }
    pub enum PhaseStatus { Passed, Failed { errors: Vec<String> }, Warned { warnings: Vec<String> } }
    pub struct PhaseResult { pub phase: BootstrapPhase, pub status: PhaseStatus, pub duration: Duration }
    ```
  - `report.rs`:
    ```rust
    pub struct BootstrapReport {
        pub phases: Vec<PhaseResult>,
        pub coordinator_spec: CoordinatorSpec,
        pub provider_registry: ProviderRegistry,
        pub model_catalog: ModelCatalog,
        pub capsule_state: CapsuleState,  // Healthy | Degraded | Missing
        pub needs_setup: bool,
    }
    pub struct CoordinatorSpec {
        pub model: String,
        pub provider_kind: ProviderKind,
        pub system_prompt: String,
        pub max_tokens: u32,
        pub temperature: f32,
    }
    pub enum CapsuleState { Healthy, Degraded { issues: Vec<String> }, Missing }
    ```
  - `impl BootstrapReport { pub fn is_healthy() -> bool; pub fn print_summary() }`
- **Verify:** `cargo build`
- **From hackcode:** `runtime/bootstrap.rs` — phase system pattern

### Task 1.2 — Create BkgBootstrap orchestrator
- **File:** `crates/bkg-core/src/bootstrap/mod.rs` (append)
- **Deps:** Task 1.1
- **Implements:**
  - `pub struct BkgBootstrap { pub report: BootstrapReport, config_path: PathBuf }`
  - `impl BkgBootstrap { pub fn new() -> Self; pub async fn run(&mut self) -> BootstrapReport; }`
  - Phase runner stubs returning `PhaseResult::Passed` (filled in later phases)
- **Verify:** `cargo build`

### Task 1.3 — Register bootstrap module in bkg-core lib.rs
- **File:** `crates/bkg-core/src/lib.rs`
- **Deps:** Task 1.2
- **Implements:** `pub mod bootstrap;`
- **Verify:** `cargo build`

### Task 1.4 — Add Cargo deps to bkg-core + bkg-cli
- **Files:** `crates/bkg-core/Cargo.toml`, `crates/bkg-cli/Cargo.toml`
- **Implements:**
  - bkg-core: `colored = "2"`, `sysinfo = "0.30"`
  - bkg-cli: `dialoguer = "0.11"`, `indicatif = "0.17"`, `sysinfo = "0.30"`, `colored = "2"`
- **Verify:** `cargo build`

## Phase 2: Capsule Rehydration Engine

### Task 2.1 — Create CapsuleEngine
- **Dir:** `crates/bkg-core/src/capsule/`
- **Files:** `mod.rs`, `rehydration.rs`, `self_heal.rs`
- **Deps:** Phase 1
- **Implements:**
  - `mod.rs` — `pub mod rehydration; pub mod self_heal;`
  - `rehydration.rs`:
    ```rust
    pub struct CapsuleEngine { capsules_dir: PathBuf }
    impl CapsuleEngine {
        pub fn new() -> Self;
        pub async fn scan_and_rehydrate(&self) -> CapsuleState;
        pub fn verify_manifest(path: &Path) -> Result<bool>;
        pub fn rebuild_index(memory_path: &Path) -> Result<()>;
        pub fn repair_snapshot(receipt: &Receipt) -> Result<()>;
    }
    ```
  - Self-healing algorithm:
    ```
    if index missing → rebuild from MEMORY.md
    if snapshot missing → restore from receipt + diff
    if receipt invalid → re-verify from filesystem state
    if capsule corrupted → mark degraded + rebuild partial
    ```
  - `self_heal.rs` — repair strategies for each failure mode
- **Verify:** `cargo test --lib capsule`
- **From hackcode:** `runtime/src/worker_boot.rs` — lifecycle patterns

### Task 2.2 — Register capsule module in bkg-core lib.rs
- **File:** `crates/bkg-core/src/lib.rs`
- **Deps:** Task 2.1
- **Implements:** `pub mod capsule;`
- **Verify:** `cargo build`

### Task 2.3 — Fill BootstrapPhase::CapsuleRehydration
- **File:** `crates/bkg-core/src/bootstrap/mod.rs`
- **Deps:** Task 2.1
- **Implements:**
  - `async fn phase_capsule_rehydration(&mut self) -> PhaseResult`
  - Calls `CapsuleEngine::scan_and_rehydrate()`
  - Sets `report.capsule_state`
  - If degraded: warnings with specific issues
  - If missing: `needs_setup = true`
- **Verify:** `cargo test --lib bootstrap`

## Phase 3: Provider Registry (multi-source)

### Task 3.1 — Create ProviderKind + ProviderMetadata
- **File:** `crates/bkg-core/src/provider.rs`
- **Deps:** Phase 1
- **Implements:**
  ```rust
  pub enum ProviderKind { Anthropic, OpenAI, Ollama, Nvidia, Compat }
  pub struct ProviderMetadata {
      pub kind: ProviderKind,
      pub auth_env: &'static str,
      pub base_url_env: &'static str,
      pub default_base_url: &'static str,
      pub name: &'static str,
  }
  pub static ALL_PROVIDERS: &[ProviderMetadata]
  impl ProviderKind { pub fn from_model_prefix(prefix: &str) -> Option<Self> }
  ```
- **Verify:** `cargo test --lib provider`
- **From hackcode:** `api/src/providers/mod.rs`

### Task 3.2 — Create ProviderRegistry
- **File:** `crates/bkg-core/src/provider.rs` (append)
- **Deps:** Task 3.1
- **Implements:**
  ```rust
  pub struct ProviderRegistry { providers: HashMap<String, Box<dyn LLMProvider + Send + Sync>> }
  impl ProviderRegistry {
      pub fn new() -> Self;
      pub async fn probe_and_register(&mut self);
      pub fn route(model: &str) -> Option<&dyn LLMProvider>;
      pub fn register(kind: ProviderKind, env: &HashMap<String, String>) -> bool;
  }
  ```
  - `probe_and_register`: reads env, probes Ollama (`http://localhost:11434/api/tags`), registers each
  - `register`: checks required env var, creates provider, inserts into map
- **Verify:** `cargo test --lib provider` (mock env var tests)
- **From hackcode:** `api/src/providers/mod.rs::env_providers()`, `openai_compat.rs`

### Task 3.3 — Fill BootstrapPhase::ProviderDetection
- **File:** `crates/bkg-core/src/bootstrap/mod.rs`
- **Deps:** Task 3.2
- **Implements:**
  - `async fn phase_provider_detection(&mut self) -> PhaseResult`
  - Creates ProviderRegistry, calls probe_and_register
  - Stores in report
- **Verify:** `cargo test`

### Task 3.4 — Register provider module in bkg-core lib.rs
- **File:** `crates/bkg-core/src/lib.rs`
- **Deps:** Task 3.2
- **Implements:** `pub mod provider;`
- **Verify:** `cargo build`

## Phase 4: ModelCatalog (multi-source)

### Task 4.1 — Create ModelCatalog
- **File:** `crates/bkg-core/src/model.rs`
- **Deps:** Phase 3
- **Implements:**
  ```rust
  pub enum ModelSource { LocalOllama, HuggingFace, NvidiaNIM, OpenAICompatible }
  pub enum QualityTier { Low, Medium, High, Max }
  pub struct ModelEntry {
      pub id: String, pub source: ModelSource, pub size_bytes: u64,
      pub is_local: bool, pub context_window: u32, pub quality_tier: QualityTier,
  }
  pub struct SelectionWeights {
      pub ram_weight: f32, pub gpu_weight: f32, pub latency_weight: f32,
      pub truth_requirement: f32, pub cost_ceiling: f32,
  }
  pub struct ModelCatalog { pub models: Vec<ModelEntry> }
  impl ModelCatalog {
      pub async fn discover() -> Self;  // multi-source discovery
      pub async fn discover_ollama() -> Result<Vec<ModelEntry>>;
      pub async fn discover_huggingface() -> Result<Vec<ModelEntry>>;
      pub async fn discover_nvidia() -> Result<Vec<ModelEntry>>;
      pub fn get_default(weights: &SelectionWeights) -> Option<&ModelEntry>;
  }
  ```
- **Verify:** `cargo test --lib model`
- **From hackcode:** `api/src/providers/mod.rs` — model listing patterns

### Task 4.2 — Fill BootstrapPhase::ModelDiscovery
- **File:** `crates/bkg-core/src/bootstrap/mod.rs`
- **Deps:** Task 4.1
- **Implements:**
  - `async fn phase_model_discovery(&mut self) -> PhaseResult`
  - Calls `ModelCatalog::discover()` across all sources
  - Selects default model based on system specs + user preferences
  - Stores in report
- **Verify:** `cargo test`

### Task 4.3 — Register model module in bkg-core lib.rs
- **File:** `crates/bkg-core/src/lib.rs`
- **Deps:** Task 4.1
- **Implements:** `pub mod model;`
- **Verify:** `cargo build`

## Phase 5: Setup Wizard (bkg-cli)

### Task 5.1 — Create SetupWizard with provider config
- **File:** `crates/bkg-cli/src/setup.rs`
- **Deps:** Phase 1-4 complete
- **Implements:**
  - `pub struct SetupWizard`
  - Step 1: `dialoguer::MultiSelect` for providers (OpenAI, Anthropic, xAI, Ollama, NVIDIA)
  - API key entry via `dialoguer::Password::new()`
- **Verify:** Manual `cargo run -- --setup`

### Task 5.2 — Setup Wizard Step 2: Model Selection
- **File:** `crates/bkg-cli/src/setup.rs` (append)
- **Deps:** Task 4.1
- **Implements:**
  - RAM detection via sysinfo
  - Model tier display with size + rating
  - HuggingFace import option
  - Recommended tiers:
    - ≥8 GB → Qwen2-1.5B-Coder (Q8_0, ~1.5GB)
    - 4-8 GB → Qwen3-0.6B-Uncensored (Q4_K_M, ~500MB)
    - <4 GB → Gemma3-Prompt-Coder-270m (Q4_K_M, ~200MB)
- **Verify:** Manual test

### Task 5.3 — Setup Wizard Step 3: Download + Capsule Creation
- **File:** `crates/bkg-cli/src/setup.rs` (append)
- **Deps:** Task 5.2, Task 2.1
- **Implements:**
  - Ollama pull with indicatif progress bar
  - Create default capsule (`~/.bkg/capsules/default/`)
  - Write MEMORY.md, receipts, manifest
  - Save config.toml + .env

### Task 5.4 — Setup Wizard Step 4: Validation
- **File:** `crates/bkg-cli/src/setup.rs` (append)
- **Deps:** Task 5.3
- **Implements:**
  - Test each provider with simple chat
  - Verify capsule integrity
  - Colored summary

### Task 5.5 — Register setup module in bkg-cli lib.rs
- **File:** `crates/bkg-cli/src/lib.rs`
- **Deps:** Task 5.4
- **Implements:** `pub mod setup;`
- **Verify:** `cargo build`

## Phase 6: Integration into main.rs

### Task 6.1 — Wire bootstrap into main.rs startup
- **File:** `crates/bkg-cli/src/main.rs`
- **Deps:** All prior phases
- **Implements:**
  - Before CLI dispatch: `BkgBootstrap::run()`
  - If `needs_setup` AND no command: auto-run `SetupWizard`
  - If healthy: pass `BootstrapReport` to command handlers
  - CLI creates `Coordinator` lazily from `CoordinatorSpec` via Runtime
  - Add `--setup` flag
  - `--truth-verify` flag for cold-start verification
  - Fallback to old provider path if bootstrap not yet stable

### Task 6.2 — Replace hardcoded model names
- **File:** `crates/bkg-core/src/router.rs`
- **Deps:** Task 6.1
- **Implements:**
  - Replace `DEFAULT_CODER_MODEL` with `Config::default_model()`
  - Router reads from config, falls back to `ollama/qwen2:1.5b-coder`

### Task 6.3 — Add integration tests
- **File:** `crates/bkg-core/tests/bootstrap_integration.rs`
- **Deps:** Task 6.2
- **Implements:**
  - Test: mock config → bootstrap → healthy report
  - Test: empty dir → needs_setup
  - Test: corrupted capsule → degraded state
- **Verify:** `cargo test --test bootstrap_integration`

## Execution Order

```
Phase 1 ──→ Phase 2 ──→ Phase 3 ──→ Phase 4 ──→ Phase 5 ──→ Phase 6
 │            │            │            │            │            │
 1.1          2.1          3.1          4.1          5.1          6.1
 1.2          2.2          3.2          4.2          5.2          6.2
 1.3          2.3          3.3          4.3          5.3          6.3
 1.4                     3.4                      5.4
                                                   5.5
```

**Key dependency chains:**
- 1.1 → 1.2 → 1.3 → 1.4 (bootstrap core)
- 1.x → 2.1 → 2.2 → 2.3 (capsule engine)
- 1.x → 3.1 → 3.2 → 3.3 → 3.4 (provider registry)
- 3.x → 4.1 → 4.2 → 4.3 (model catalog)
- 4.x + 2.x → 5.1 → 5.2 → 5.3 → 5.4 → 5.5 (setup wizard)
- All → 6.1 → 6.2 → 6.3 (integration)

## Default Model Tier (Validated)

| RAM | Recommended Model | HF Repo | Quant | Size |
|-----|------------------|---------|-------|------|
| ≥8 GB | Qwen2-1.5B-Coder | `ICEPVP8977/Uncensored_Replete_Coder_Qwen2_1.5b` | Q8_0 | ~1.5GB |
| 4-8 GB | Qwen3-0.6B-Uncensored | `s3nh/Qwen3-0.6B-Uncensored` | Q4_K_M | ~500MB |
| <4 GB | Gemma3-Prompt-Coder-270m | `WithinUsAI/Gemma3-Prompt.Coder.Uncensored.270m-GGUF` | Q4_K_M | ~200MB |
