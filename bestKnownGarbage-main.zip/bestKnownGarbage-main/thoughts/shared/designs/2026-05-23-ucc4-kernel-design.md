# UCC-4 Self-Evolving Kernel

date: 2026-05-23
topic: "UCC-4 Self-Evolving Execution Kernel"
status: validated

## Problem Statement

Current BKG capsule system tracks execution state but lacks a deterministic, auditable, self-healing kernel with controlled evolution. Capsules are mutable, repair is ad-hoc, and there's no mathematical guarantee that replay produces identical results. We need a sealed execution kernel where:

- **Replay is bit-identical** — same inputs + same seed + same policy → same outputs
- **Truth is final** — receipts and truth reports are immutable, never overwritten
- **Repair is convergent** — monotonic divergence improvement or lock
- **Evolution doesn't break history** — policy changes affect only future executions
- **Timeline is causal** — events link to their DAG parents, not just a flat log

## Constraints

- **UCC-4 spec v1.0 frozen** — all rules and structure must be followed exactly
- **84 existing capsule tests must pass** — kernel composes capsule, doesn't replace it
- **No local duplicates of core types** — kernel imports from capsule, never copies
- **Receipts/truth/snapshots are immutable** — after verification, never overwritten
- **Replay is deterministic** — same inputs → same DAG → same hashes
- **Evolution is async** — never synchronously affects execution
- **Repair has hard bound** — MAX_REPAIR_ATTEMPTS = 3, divergent → lock
- **Policy is frozen at execution time** — replay uses receipt's policy snapshot, never current

## Approach

Build `bkg-core/src/kernel/` as a new orchestration facade on top of the existing `capsule/` module. This keeps the 84 existing tests green and isolates new complexity.

**Key insight:** UCC-4 is not a replacement for capsules — it's the **execution kernel** that orchestrates capsule lifecycles with verifiable determinism.

The system has three hard layers:

```
EVOLUTION LAYER — history-only learning, async policy mutation
TRUTH LAYER     — hash verification, convergent repair, PASS/WARN/DIVERGENT gate
EXECUTION LAYER — deterministic DAG execution with pinned seed + policy
```

## Architecture

### Module Map

```
bkg-core/src/kernel/
├── mod.rs              Ucc4Kernel orchestrator, pub re-exports
├── contracts.rs        Constants + invariants
├── ucc4.rs             Ucc4Kernel trait
│
├── memory/
│   ├── mod.rs
│   ├── filesystem.rs   Immutable receipt/truth storage
│   └── index.rs        Capsule registry
│
├── execution/
│   ├── mod.rs
│   ├── dag.rs          Minimal Node/Edge DAG, topological sort
│   ├── executor.rs     Parallel DAG runner with execution_seed routing
│   └── receipts.rs     ExecutionReceipt + PolicySnapshot + CapsuleSnapshot
│
├── truth/
│   ├── mod.rs
│   ├── verifier.rs     TruthGate: PASS / WARN / DIVERGENT
│   ├── drift.rs        DriftType enum, divergence_score calculation
│   └── repair.rs       Repair engine (convergent, max 3 attempts)
│
├── time/
│   ├── mod.rs
│   ├── timeline.rs     Causal TimelineEvent stream
│   ├── replay.rs       ReplayEngine + ReplayContext (4 modes)
│   └── diff.rs         ReplayDiff output
│
└── evolution/
    ├── mod.rs
    ├── policy.rs       PolicySnapshot + PolicyRecord
    ├── learner.rs      History-only learning
    └── queue.rs        Async evolution event queue
```

### Dependency Direction

```
kernel/ → capsule/  (imports graph, storage, hashing)
kernel/ → ...       (Ucc4Kernel trait consumers)
capsule/ → ⊥        (no dependency on kernel/)
```

## Components

### Ucc4Kernel (Orchestrator, mod.rs + ucc4.rs)

The main entry point. Owns the hot path.

```rust
pub trait Ucc4Kernel {
    fn run(&mut self, capsule_id: &str, input: &str) -> Result<KernelOutput, KernelError>;
    fn replay(&self, receipt_id: &str, mode: ReplayMode) -> Result<ReplayDiff, KernelError>;
    fn rehydrate(&mut self, capsule_id: &str) -> Result<CapsuleStatus, KernelError>;
}
```

### MemoryKernel (memory/)

Loads/saves capsules, persists immutable receipts and truth reports. Filesystem-backed. No mutations after write.

### ExecutionKernel (execution/)

Builds DAG from capsule, executes with topological sort (parallel independent nodes). Generates `execution_seed: u64` for each run. Every tool/LLM call hashes `(execution_seed, policy_snapshot.version, node_id)` for deterministic routing.

### TruthKernel (truth/)

Verifies receipts against expected hashes. Computes `divergence_score` on a 0..1 scale. Runs repair loop with monotonic progress check — if `divergence_score >= previous_score`, immediate lock.

### TimeKernel (time/)

Manages the causal timeline. Each `TimelineEvent` has an optional `parent_event` field linking it to its DAG predecessor. Replay engine supports 4 modes with full pinning.

### EvolutionKernel (evolution/)

Learns from truth results, updates policies asynchronously. Never touches past receipts or truth files. Policy snapshots are frozen at execution time for replay determinism.

## Data Model

### Core Structs

```rust
// ── CapsuleSnapshot: pinned capsule state at execution time ──
pub struct CapsuleSnapshot {
    pub capsule_id: String,
    pub graph_hash: String,
    pub node_hashes: Vec<(String, String)>,
    pub edge_hashes: Vec<(String, String)>,
}

// ── PolicySnapshot: frozen policy environment ──
pub struct PolicySnapshot {
    pub policy_version: String,
    pub routing_weights: HashMap<String, f32>,
    pub retry_limit: u8,
    pub repair_threshold: f32,
}

// ── ExecutionReceipt: immutable record of one execution ──
pub struct ExecutionReceipt {
    pub id: String,
    pub capsule_id: String,
    pub input_hash: String,
    pub output_hash: String,
    pub tool_calls: Vec<ToolCallRecord>,
    pub policy_snapshot: PolicySnapshot,
    pub capsule_snapshot: CapsuleSnapshot,
    pub execution_seed: u64,
    pub runtime_mode: ReplayMode,
    pub timestamp: DateTime<Utc>,
}

// ── TruthReport: immutable verdict ──
pub struct TruthReport {
    pub receipt_id: String,
    pub verdict: Verdict,
    pub score: f64,
    pub confidence: f64,
    pub evidence: Vec<String>,
}

pub enum Verdict { Pass, Warn, Divergent }

// ── CapsuleStatus: extended with terminal states ──
pub enum CapsuleStatus {
    Active, Rehydrated, Verified, Stale,
    Divergent, Repaired, Archived,
    Replaying, Evolving, Frozen,
    Broken,
    Locked,
}

// ── RepairContext: convergent repair tracking ──
pub const MAX_REPAIR_ATTEMPTS: u8 = 3;

pub struct RepairContext {
    pub attempts: u8,
    pub last_error: String,
    pub divergence_score: f64,
    pub previous_score: f64,
}

// ── TimelineEvent: causal graph, not flat log ──
pub struct TimelineEvent {
    pub event_id: String,
    pub capsule_id: String,
    pub parent_event: Option<String>,
    pub event_type: EventType,
    pub payload: serde_json::Value,
}

pub enum EventType {
    ExecutionStarted,
    ExecutionFinished,
    ReceiptStored,
    TruthVerified,
    RepairTriggered,
    ReplayExecuted,
    PolicyUpdated,
}

// ── ReplayContext: full pinning for bit-identical replay ──
pub struct ReplayContext {
    pub receipt: ExecutionReceipt,
    pub policy_snapshot: PolicySnapshot,
    pub capsule_snapshot_hash: String,
}

pub enum ReplayMode {
    Deterministic,  // ReplayContext only
    Live,           // Current provider, same DAG
    Hybrid,         // Deterministic DAG + live LLM
    AnomalyOnly,    // Divergent nodes only
}
```

### Minimal Execution Schema

```rust
pub struct Node {
    pub id: String,
    pub tool: String,
    pub input_ref: String,
    pub dependencies: Vec<String>,
}

pub struct Edge {
    pub from: String,
    pub to: String,
}

pub struct CapsuleGraph {
    pub nodes: Vec<Node>,
    pub edges: Vec<Edge>,
}
```

## Data Flow

### Hot Path (Ucc4Kernel::run())

```
 1. load capsule                 → MemoryKernel.load()
 2. build execution DAG          → ExecutionKernel.build_dag()
 3. execute DAG (topological)    → ExecutionKernel.execute()
    │  execution_seed = generate()
    │  independent nodes → parallel
    │  dependent nodes → serial
    │  every tool call gets (execution_seed, policy_version, node_id)
    ↓
 4. persist receipt              → MemoryKernel.persist_receipt()
    │  receipts/<uuid>.json (IMMUTABLE)
    │  includes PolicySnapshot (frozen at step 3)
    │  includes CapsuleSnapshot (pinned graph state)
    │  includes execution_seed
    ↓
 5. verify receipt               → TruthKernel.verify()
    │  PASS  → step 8
    │  WARN  → log, step 8
    │  DIVERGENT → step 6
    ↓
 6. repair capsule               → TruthKernel.repair()
    │  attempts++
    │  divergence_score >= previous_score → LOCK immediately
    │  attempts >= MAX_REPAIR_ATTEMPTS (3) → LOCK
    │  else → goto 5 (RE-VERIFY)
    ↓
 7. persist capsule              → MemoryKernel.save()
 8. finalize truth               → TruthKernel.finalize()
    │  truth/<uuid>.json (IMMUTABLE)
    ↓
 9. queue evolution event        → EvolutionKernel.queue()
10. return output
```

### Replay Flow

```
replay(receipt_id, mode) →
  1. load receipt from receipts/<uuid>.json
  2. extract policy_snapshot + capsule_snapshot_hash + execution_seed
  3. build ReplayContext { receipt, policy_snapshot, capsule_snapshot_hash }
  4. execute DAG with ReplayContext (bit-identical by construction)
  5. compare output → ReplayDiff
  6. record TimelineEvent { event_type: ReplayExecuted, parent_event: receipt.id }
  7. return ReplayDiff
```

### Rehydration Flow (Error Recovery)

```
rehydrate(capsule_id) →
  1. load manifest → verify → reconstruct capsule state
  2. rebuild index from receipts/ + truth/
  3. replay last successful receipt (Deterministic mode)
  4. compute divergence_score (current vs replayed)
  5. repairs attempts ≤ 3, monotonic → repair
  6. re-verify → must PASS or Lock
```

## File Format

```
~/.bkg/capsules/<id>/
├── capsule.json            ← Capsule (status, graph_hash, etc.)
├── receipts/
│   └── <uuid>.json         ← ExecutionReceipt (IMMUTABLE)
├── truth/
│   └── <uuid>.json         ← TruthReport (IMMUTABLE)
├── timeline.jsonl          ← TimelineEvent[] only (APPEND-ONLY, causal)
├── graph/
│   ├── manifest.json       ← CapsuleGraphManifest
│   ├── nodes/*.json
│   └── edges/*.json
└── evolution/
    ├── policy_records.json
    └── queue/
```

## Hard Invariants

1. **`receipts/*` and `truth/*` are IMMUTABLE** — never overwritten, append-only
2. **Repair only in VERIFY → REPAIR → VERIFY flow** — no repair outside verification
3. **MAX_REPAIR_ATTEMPTS = 3** — lock if exceeded or if divergence doesn't improve
4. **Replay MUST use receipt's policy_snapshot** — never current system policy
5. **Every tool/LLM call MUST hash `(execution_seed, policy_snapshot.version, node_id)`** — semantic determinism
6. **Evolution never synchronously affects execution** — async queue only
7. **Same inputs + same execution_seed → same outputs** — by construction
8. **timeline.jsonl is append-only** — every event has a `parent_event` causal link

## Error Handling

| Failure | Behavior |
|---------|----------|
| Capsule not found | Return KernelError::NotFound |
| Receipt corrupt | Return KernelError::CorruptData |
| Divergence detected | Enter repair loop (max 3, convergent) |
| Repair non-convergent | Lock capsule, emit FailureReport |
| IO error | Return KernelError::Storage, log, no retry |
| Replay with wrong seed | Return KernelError::DeterminismViolation |
| Evolution queue full | Drop event, log, continue execution |

## Edge Cases & Defensive Design

| Edge Case | Rule |
|-----------|------|
| Replay with current policy (not receipt) | HARD VIOLATION — verifier rejects |
| Repair divergence_score = previous_score | Lock immediately (no oscillation) |
| TimelineEvent missing parent_event | Still valid (root event) |
| CapsuleSnapshot doesn't match current capsule | Valid — snapshot is historical |
| Two receipts same execution_seed + input | Allowed — produces same output (idempotent) |
| Capsule status = Locked, replay requested | Allowed — Locked only blocks execution, not replay |

## Testing Strategy

### Unit Tests
- ExecutionReceipt serialization/deserialization (all fields, missing fields)
- PolicySnapshot freeze/unfreeze round-trip
- RepairContext attempt tracking, divergence_score comparison
- TimelineEvent parent_event linking, serialization
- Drift score calculation (0..1 range, edge cases)

### Integration Tests
- Full hot path: load → execute → persist → verify → repair → re-verify
- Divergent detection + repair loop (1, 2, 3 attempts)
- Non-convergent repair → Lock after attempt 2 (worsening score)
- MAX_REPAIR_ATTEMPTS = 3 → Lock on attempt 3
- Replay with receipt's policy_snapshot (deterministic mode)
- Replay with current policy → must fail verification
- Rehydrate: corrupt receipt → replay last good → repair
- Timeline: causal chain across execution + repair + replay

### Property-Based Tests
- Deterministic replay: same receipt + same seed → same output (100 runs)
- Repair monotonicity: divergence_score must decrease or lock
- Snapshot pinning: capsule mutation doesn't affect historical receipts

### 84 Existing Capsule Tests
- Must all pass before and after kernel integration
- No kernel type leaked into capsule module

## Open Questions

None. Design is frozen for v1.0 implementation.
