# Dynamic Model Bootstrap System

date: 2026-05-23
topic: "Dynamic Model Bootstrap for BKG"
status: validated

## Problem Statement

BKG's current model and provider configuration is static and hardcoded. Models are embedded in `router.rs` as constants (`DEFAULT_CODER_MODEL: &str = "meta/llama-3.3-70b-instruct"`), providers are compiled-in, and there is no setup experience for new users. This creates a high barrier to entry and poor UX for local-first usage with Ollama.

## Constraints

- **Must work fully offline** — Ollama local models are the primary use case
- **Must support cloud providers** — OpenAI, Anthropic, xAI, NVIDIA NIM as secondary options
- **Must bootstrap with validation** — Coordinator is only created after all validations pass
- **Must have a first-run setup wizard** — Only if no valid capsule exists
- **Must be in Core, not CLI** — API, daemon, TUI, replay engine all need bootstrap too
- **Must be incremental** — Can coexist with current bkg-provider during migration

## Approach

Bootstrap becomes the **System Genesis Layer** — not just a setup wizard, but the deterministic entry point that reconstructs AI system state from truth capsules.

**Core architecture:** `Bootstrap → Capsule → Runtime → Coordinator (lazy)`

- **Bootstrap** resolves system state (config, providers, models, capsules)
- **Capsule** is the truth source (MEMORY.md + receipts + snapshots)
- **Runtime** owns the Coordinator, creates it lazily after bootstrap
- **Coordinator** is a runtime object, not owned by bootstrap

The **Provider Registry** adopts hackcode's pattern: model names are prefixed with provider IDs (`ollama/`, `openai/`, `anthropic/`). The registry auto-detects available providers via env vars, local service checks (Ollama probe), and NVIDIA NIM detection.

The **Setup Wizard** is optional — it only runs if no valid capsule exists (first-ever start or corrupted state). It detects hardware, recommends a local model based on multi-variable selection (RAM, GPU, latency preference, truth requirement level, cost ceiling), offers to download it via Ollama, collects API keys for cloud providers, and creates the initial capsule.

The **ModelCatalog** is multi-source: LocalOllama, HuggingFace, NvidiaNIM, OpenAICompatible. Not Ollama-centric.

The **CapsuleRehydration phase** scans capsules, verifies manifests, rebuilds indices, repairs missing snapshots, validates receipts, and restores runtime state. This is the self-healing entry point.

## Architecture

```text
main()
  │
  ├── [Phase 1] ConfigLoad
  │     ├── Load ~/.bkg/config.toml + .env
  │     ├── First-run? → SetupWizard → creates initial capsule
  │     └── Validate config structure
  │
  ├── [Phase 2] CapsuleRehydration  ← NEW
  │     ├── scan ~/.bkg/capsules/
  │     ├── verify manifests (hash integrity)
  │     ├── rebuild SQLite index from MEMORY.md if missing
  │     ├── repair missing snapshots from receipts + diffs
  │     ├── validate receipts against filesystem state
  │     ├── mark corrupted capsules as degraded + rebuild partial
  │     └── restore runtime state
  │
  ├── [Phase 3] ProviderDetection
  │     ├── Scan env for API keys (OpenAI, Anthropic, xAI, NVIDIA)
  │     ├── Probe Ollama http://localhost:11434/api/tags
  │     ├── Detect NVIDIA NIM endpoints
  │     └── Build ProviderRegistry (resolves only, doesn't own)
  │
  ├── [Phase 4] ModelDiscovery
  │     ├── Multi-source: Ollama list, HF cache, NIM endpoints, API models
  │     ├── Select default (multi-variable: RAM, GPU, latency, truth, cost)
  │     └── Cache model token limits + context windows
  │
  ├── [Phase 5] CoordinatorSpec  ← changed: spec not instance
  │     ├── Build coordinator_spec from provider_registry + model_catalog
  │     ├── Runtime owns coordinator, creates lazily
  │     └── Dry-run validation (health check)
  │
  └── [Phase 6] Ready
        └── CLI dispatch → Runtime creates Coordinator from spec
```

### Key Components

| Component | Location | Responsibility |
|-----------|----------|----------------|
| `BkgBootstrap` | `bkg-core/src/bootstrap/` | Orchestrates phases, collects diagnostics, produces `BootstrapReport` |
| `ProviderRegistry` | `bkg-core/src/provider.rs` | Dynamic model→provider routing, multi-source detection |
| `ModelCatalog` | `bkg-core/src/model.rs` | Multi-source model discovery (Ollama, HF, NVIDIA, OpenAI) |
| `SetupWizard` | `bkg-cli/src/setup.rs` | Interactive first-run: API keys, model selection, capsule creation |
| `WorkerBoot` | `bkg-core/src/worker.rs` | Worker lifecycle: spawning, trust gating, tool permissions |
| `CapsuleEngine` | `bkg-core/src/capsule/` | Capsule rehydration, self-healing, manifest verification |

### BootstrapReport

```rust
pub struct BootstrapReport {
    pub phases: Vec<PhaseResult>,
    pub coordinator_spec: CoordinatorSpec,  // spec, not instance
    pub provider_registry: ProviderRegistry,
    pub model_catalog: ModelCatalog,
    pub capsule_state: CapsuleState,        // healthy / degraded / missing
    pub needs_setup: bool,                  // only true if no valid capsule
}

pub struct CoordinatorSpec {
    pub model: String,
    pub provider_kind: ProviderKind,
    pub system_prompt: String,
    pub max_tokens: u32,
    pub temperature: f32,
}

pub enum PhaseStatus {
    Passed,
    Failed { errors: Vec<String> },
    Skipped { reason: String },
}
```

### ProviderRegistry Model Routing

Model names use provider prefixes:

| Prefix | Provider | Auth | Detection |
|--------|----------|------|-----------|
| `ollama/` | Ollama (local) | None | HTTP probe :11434 |
| `openai/` | OpenAI | `OPENAI_API_KEY` | env var |
| `anthropic/` | Anthropic | `ANTHROPIC_API_KEY` | env var |
| `xai/` | xAI | `XAI_API_KEY` | env var |
| `nvidia/` | NVIDIA NIM | `NVIDIA_API_KEY` | env var + local probe |
| `compat/` | Any OpenAI-compat | `OPENAI_BASE_URL` + key | env var |
| `hf/` | HuggingFace | `HF_TOKEN` | ollama pull hf.co/* |

### ModelCatalog — Multi-Source

```rust
pub enum ModelSource {
    LocalOllama,
    HuggingFace,
    NvidiaNIM,
    OpenAICompatible,
}

pub struct ModelEntry {
    pub id: String,
    pub source: ModelSource,
    pub size_bytes: u64,
    pub is_local: bool,
    pub context_window: u32,
    pub quality_tier: QualityTier, // low, medium, high, max
}

pub struct ModelCatalog {
    pub models: Vec<ModelEntry>,
    pub selection_weights: SelectionWeights,
}

pub struct SelectionWeights {
    pub ram_weight: f32,
    pub gpu_weight: f32,
    pub latency_weight: f32,
    pub truth_requirement: f32,
    pub cost_ceiling: f32,
}
```

### Capsule Rehydration Engine

Self-healing algorithm:

```text
if index missing:
    rebuild from MEMORY.md
if snapshot missing:
    restore from receipt + diff
if receipt invalid:
    re-verify from filesystem state
if capsule corrupted:
    mark as degraded + rebuild partial state
```

### SetupWizard Flow (only on first-run or --setup flag)

```
Step 1: Provider Selection
  - Checkboxes for OpenAI, Anthropic, xAI, Ollama, NVIDIA
  - API key entry fields for each selected provider
  - Ollama auto-detected (skip if not installed)

Step 2: Model Selection
  - Multi-variable: RAM, GPU, latency, truth requirement, cost ceiling
  - RAM tiers:
    - ≥8 GB → Qwen2-1.5B-Coder (Q8_0, ~1.5GB) — best coder
    - 4-8 GB → Qwen3-0.6B-Uncensored (Q4_K_M, ~500MB)
    - <4 GB → Gemma3-Prompt-Coder-270m (Q4_K_M, ~200MB)
  - HuggingFace import option (enter HF repo name)

Step 3: Ollama Download + Worker Setup
  - Auto-pull selected model via `ollama pull hf.co/<repo>`
  - Progress bar with indicatif
  - Worker pool size (default: num_cpus - 1)
  - Trust mode (auto/manual/off)

Step 4: Initial Capsule Creation
  - Create ~/.bkg/capsules/default/
  - Write MEMORY.md (system state record)
  - Write receipts + manifest
  - Save config.toml + .env

Step 5: Validation
  - Test each configured provider
  - Verify capsule integrity
  - Report success/failure per provider
```

## Data Flow

### Startup Path
```
config.toml + .env → Bootstrap Phase 1 (ConfigLoad)
  → capsules/ → Phase 2 (CapsuleRehydration)
    → env + probes → Phase 3 (ProviderDetection) → ProviderRegistry
      → Phase 4 (ModelDiscovery) → ModelCatalog
        → Phase 5 (CoordinatorSpec → bootstrap report)
          → CLI dispatch → Runtime creates Coordinator from spec
```

### Model Request Resolution
```
User says "write code" → Runtime.create_coordinator(spec)
  → Coordinator.run()
    → Agent determines model from config/CLI
    → ProviderRegistry::route("ollama/qwen2:1.5b-coder")
      → matches prefix "ollama/"
      → OllamaProvider::chat(messages)
        → POST http://localhost:11434/api/chat
```

### Setup Persistence
```
SetupWizard completes
  → Writes ~/.bkg/config.toml:
      [providers]
      ollama = { enabled = true }
      openai = { key = "sk-..." }
      
      [models]
      default = "ollama/qwen2:1.5b-coder"
      
  → Creates ~/.bkg/capsules/default/
      MEMORY.md
      receipts/
      snapshots/
      
  → Writes ~/.bkg/.env (chmod 600):
      OPENAI_API_KEY=sk-...
```

## Self-Healing System

Capsules are self-healing units. Each capsule contains:
- **MEMORY.md** — truth source (canonical state record)
- **SQLite index** — derivative, rebuilt from MEMORY.md if missing
- **Receipts** — execution proofs (hash-verified)
- **Snapshots** — filesystem state at points in time
- **Manifests** — hash integrity verification

The **CapsuleRehydration** phase runs these checks at every startup:
1. Index missing → rebuild from MEMORY.md
2. Snapshot missing → restore from receipt + diff chain
3. Receipt invalid → re-verify from filesystem state
4. Capsule corrupted → mark degraded, rebuild partial state, warn user

## Error Handling

| Scenario | Behavior |
|----------|----------|
| No provider available | `PhaseResult::Failed` → offer Setup Wizard (only if no capsule) |
| Capsule corrupted | Mark degraded, rebuild partial, warn user |
| Ollama not running | Warning, use cloud-only, offer to start Ollama |
| API key missing for selected model | Error at validation, prompt for key in Setup Wizard |
| Model not found locally | Auto-pull via Ollama, report progress |
| Provider dry-run fails | Fatal error with diagnostics (timeout, auth, network) |

## Cold Start Truth Mode

```bash
bkg start --truth-verify
```

Runs:
- Complete capsule verification (all manifests, all receipts)
- Full replay dry-run
- Drift detection (filesystem vs snapshot vs MEMORY.md)
- Provider sanity check (ping each provider)

## Testing Strategy

1. **Unit tests** for BootstrapPhase validation logic
2. **Unit tests** for ProviderRegistry routing (prefix matching)
3. **Unit tests** for CapsuleRehydration (rebuild index, repair snapshot)
4. **Integration test** for SetupWizard output → capsule roundtrip
5. **Integration test** for full bootstrap → coordinator spec
6. **Manual test** for Ollama probe against local instance
7. **Mock tests** for provider detection (mock env vars, mock HTTP probe)

## Migration Path

1. **Phase 1:** Create `bkg-core/src/bootstrap/` module with phase engine + types
2. **Phase 2:** Create `bkg-core/src/provider.rs` with multi-source ProviderRegistry
3. **Phase 3:** Create `bkg-core/src/model.rs` with ModelCatalog
4. **Phase 4:** Create `bkg-core/src/capsule/` with rehydration engine
5. **Phase 5:** Create `bkg-cli/src/setup.rs` with Setup Wizard
6. **Phase 6:** Integrate bootstrap into `main.rs` startup flow
7. **Phase 7:** Replace hardcoded model names with registry lookups
8. **Phase 8:** Remove old provider path after validation

## Open Questions (Resolved)

- ~~Bootstrap in CLI or Core?~~ → **Core.** `bkg-core/src/bootstrap/`
- ~~ProviderRegistry + Coordinator coupling?~~ → **Decoupled.** Bootstrap produces `CoordinatorSpec`, Runtime owns `Coordinator`
- ~~ModelCatalog Ollama-centric?~~ → **Multi-source.** Ollama, HF, NVIDIA, OpenAI
- ~~Setup Wizard always runs?~~ → **Only if no valid capsule exists**
- ~~HuggingFace import?~~ → Via `ollama pull hf.co/<repo>` initially, direct download later
- ~~Self-healing?~~ → **Yes.** CapsuleRehydration phase with repair algorithms

## Default Model Tier (Validated)

| RAM | Recommended Model | HF Repo | Quant | Size |
|-----|------------------|---------|-------|------|
| ≥8 GB | Qwen2-1.5B-Coder | `ICEPVP8977/Uncensored_Replete_Coder_Qwen2_1.5b` | Q8_0 | ~1.5GB |
| 4-8 GB | Qwen3-0.6B-Uncensored | `s3nh/Qwen3-0.6B-Uncensored` | Q4_K_M | ~500MB |
| <4 GB | Gemma3-Prompt-Coder-270m | `WithinUsAI/Gemma3-Prompt.Coder.Uncensored.270m-GGUF` | Q4_K_M | ~200MB |
