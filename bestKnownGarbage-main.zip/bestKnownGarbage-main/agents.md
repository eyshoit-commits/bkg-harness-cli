# BESTKNOWNGarbage — Project Overview

## Structure

```
bESTKNOWNGarbage/
├── Cargo.toml              # Workspace root
│
├── crates/                 # Shared reusable crates
│   ├── bkg-core/           # Legacy core (error, config, message, session)
│   ├── bkg-kernel/         # Legacy kernel (trust, causality, mesh, etc.)
│   ├── bkg-cli/            # Legacy CLI library
│   ├── bkg-types/          # Shared type definitions
│   ├── bkg-common/         # Shared utilities
│   ├── bkg-config/         # Configuration framework
│   ├── bkg-crypto/         # Cryptography primitives
│   ├── bkg-protocol/       # Network protocol definitions
│   ├── bkg-events/         # Event system
│   ├── bkg-storage/        # Storage abstraction
│   ├── bkg-security/       # Security primitives
│   ├── bkg-runtime/        # Runtime abstraction
│   ├── bkg-errors/         # Error types
│   ├── bkg-macros/         # Procedural macros
│   ├── bkg-serde/          # Serialization helpers
│   └── bkg-telemetry/      # Tracing/metrics
│
├── projects/               # Executable systems
│   ├── bkg-motherbrain/    # Motherbrain server (authoritative kernel)
│   ├── bkg-node/           # Garbage/collector node
│   ├── bkg-llm/            # Guard LLM service
│   ├── bkg-lang/           # BKG Language (QL + DSL)
│   ├── bkg-web/            # Web WASM (Dioxus landing page)
│   └── bkg-client/         # CLI + API client
│
├── docs/                   # Documentation
├── tasks/                  # 6 task chains
├── contracts/              # Constitution contracts
├── tools/                  # Developer tooling
├── infra/                  # Infrastructure configs
├── scripts/                # Build/deploy scripts
├── testbeds/               # Test environments
└── replay/                 # Execution replay data
```

## Key Facts

- **Rust Edition 2024** (except `bkg-web` = edition 2021 for wasm compat)
- **Workspace** with 16+ shared crates + 6 project binaries
- **Domain crates** live inside projects (`projects/*/crates/`) — NOT at root
- **Epistemic kernel** in `crates/bkg-kernel/` (legacy, migrating to project sub-crates)
- **Per-project tracking:** Each project has its own `agents.md`, `progress.md`, `truth.md`, `llm.nfo`

## Rule: `bkg-*` naming ONLY

No `bjg`, `bkd`, `young`, `server-final-v2`, or other creative names.
All directories, crates, packages = `bkg-*`.

## Build

```bash
cargo check
cargo check -p motherbrain-server
cargo check -p bkg-node
```

## Origin

Restructured from `v0.1a/` monolith. Old structure preserved at `/home/bkg/workspace/bkg-wasm/`.
