# bESTKNOWNGarbage — Task Index

> **Meta-Index** (Root-Level). Jeder Bereich hat seine eigene Task-Chain in `tasks/`.
>
> **Architektur-Regeln** in `docs/invariants.md` (12 Invarianten).
> **Interface-Contracts** in `contracts/`.
>
> `task.md` selbst enthält nur Gold-Status-Checkliste, Abhängigkeits-Map und Bereichsübersicht.

---

## Phase Structure

| Phase | Bereiche | Ziel |
|-------|----------|------|
| **Phase 0** | `contracts/`, `docs/invariants.md`, Schemas | Constitution + Interface-Definition |
| **Phase 1** | Motherbrain Core: Ledger, Replay, Adjudication | Deterministic Kernel |
| **Phase 2** | Mesh, GC, Trust (Garbage Nodes + TrustEngine) | Netzwerk + Vertrauen |
| **Phase 3** | Client, API, Web-WASM | Zugang + UI |
| **Phase 4** | Guard LLM, BKG Language | Intelligence + Sprache |
| **Phase 5** | Evolutionary Extraction, Gold Audit | Hardening + Extraktion |

---

## Bereichs-übersicht

| # | Bereich | Task-Datei | Phase | Steps | Abhängigkeit |
|---|---------|------------|-------|-------|--------------|
| 1 | **Motherbrain** | `tasks/task-motherbrain.md` | 1 | 46 Steps | Phase 0 (Contracts) |
| 2 | **Client** | `tasks/task-client.md` | 3 | 18 Steps | [1] Motherbrain |
| 3 | **Web-WASM** | `tasks/task-web-wasm.md` | 3 | 12 Steps | [1] Motherbrain |
| 4 | **Garbage Nodes** | `tasks/task-garbage.md` | 2 | 19 Steps | [1] Motherbrain |
| 5 | **Guard LLM** | `tasks/task-guard-llm.md` | 4 | 10 Steps | [1] [4] Motherbrain + Garbage |
| 6 | **BKG Language** | `tasks/task-bkg-lang.md` | 4 | 9 Steps | [1] Motherbrain |

---

## Dependency Map

```
Phase 0 [Contracts + Invariants] ───────────────────────────────────────
    │
Phase 1 [Motherbrain Core] ────────────────────────────────────────────┐
    ├── Phase 2 [Mesh, GC, Trust] ───┐                                 │
    │     └── Guard LLM ──────────────┤                                 │
    ├── Phase 3 [Client, API, WASM] ──┤                                 │
    └── Phase 4 [BKG Lang] ───────────┤                                 │
                                       │                                 │
    Phase 5 [Evolutionary Extraction] ─┘                                 │
    (Gold Audit + Hardening)                                            │
                                                                        │
    [1]→[4]→[2]→[3]→[5]→[6]  (technische Build-Reihenfolge)            │
    Phase 1 + Phase 2 = Alpha                                           │
    Phase 1 + Phase 2 + Phase 3 = Beta                                  │
    Phase 1..4 + Gold Audit = v1.0                                      │
```

---

## Gold Status Checkliste (Bereichs-übergreifend)

> Jeder Bereich liefert validate Gate-Kriterien mit **harten Metriken**.
> Kein "fertig™" ohne gemessene Erfüllung.
> Alle müssen ✅ sein für v1.0.

### Build Gates
- [ ] 🔲 `cargo check --release` — 0 errors, 0 warnings
- [ ] 🔲 `cargo clippy --all-targets -- -D warnings` — clean
- [ ] 🔲 `cargo test` — all green (≥ 80% coverage)
- [ ] 🔲 `cargo fmt --check` — clean
- [ ] 🔲 `cargo audit` — 0 vulnerabilities
- [ ] 🔲 Invariant-Checks: alle 12 aus docs/invariants.md automatisiert getestet
- [ ] 🔲 Contract-Tests: alle 3 contracts/ endpunktgetestet (API ↔ Implementation)

### Motherbrain Gates
- [ ] 🔲 **Ledger persistent + integritätsgeprüft**
  - SQLite-Backend: 100k Receipts in < 500ms
  - Merkle-Root-Verifikation: each block → root matches
  - Replay von Block 0 bis Head → deterministisch identisch
- [ ] 🔲 **WASM Execution mit Fuel-Limits**
  - Fuel-Limit: 1M Units pro Execution
  - Trap bei Limit-Überschreitung (kein silent overflow)
  - 10 bekannte WASM-Edge-Cases alle behandelt
- [ ] 🔲 **Collusion Detection (6 Patterns)**
  - Erkennt 6/6 bekannte Pattern
  - False-Positive-Rate < 2%
  - 1000 simulierte Szenarien bestanden
- [ ] 🔲 **Swarm Validation (Quorum-Konsens)**
  - 3/5 Quorum: gültig
  - 2/5: rejected
  - Timeout (30s): automatic fallback zu Motherbrain Solo
- [ ] 🔲 **Motherbrain Adjudication (6 Entscheidungen)**
  - Accepted / Rejected / NeedsReview / Escalate / Quarantine / Defer
  - Jede Entscheidung replay-verifizierbar
  - 500 simulierte Fälle mit bekannter Ground Truth
- [ ] 🔲 **WriteSeparation (Mesh/GC schreiben nicht)**
  - Mesh Write-Versuch → E002 Error
  - GC Write-Versuch → E002 Error
  - Motherbrain Write → immer erfolgreich
- [ ] 🔲 **Talmud Escalation (5 Stages)**
  - Stage 1–5 durchlaufen: 100 simulierte Escalation-Szenarien
  - Stage 5 (Motherbrain Final) immer deterministisch
- [ ] 🔲 **Replay Verify**
  - Voll-Replay (Block 0 → Head): < 5s bei 10k Blöcken
  - Replay-Klasse Tiny: < 1s
  - Replay-Klasse Standard: < 30s
  - Replay-Klasse Heavy: < 5min
  - Replay-Klasse Dangerous: < 30min
  - NonDeterministic: markiert, nicht voll replayable
- [ ] 🔲 **Config Loading + Boot Sequence**
  - Config aus Datei + ENV + CLI-Args (merge)
  - SystemMode Bootstrap → Alpha bei Ready
  - Boot in < 100ms
- [ ] 🔲 **Graceful Shutdown**
  - SIGTERM → Ledger-Flush in < 1s
  - SIGTERM → alle Daemons stoppen in < 5s
  - SystemMode → ReadOnly während Shutdown

### Client Gates
- [ ] 🔲 `bkg start` — Boot in < 100ms, alle Module grün
- [ ] 🔲 `bkg stop` — Shutdown in < 5s, Exit-Code 0
- [ ] 🔲 `bkg status` — 6/6 Module: mode, ledger, mesh, gc, trust, replay
- [ ] 🔲 `bkg chat "test"` — Antwort in < 2s mit Tool-Execution
- [ ] 🔲 `bkg replay` — 10k Block-Replay in < 5s, Integrity OK
- [ ] 🔲 `bkg config` — zeigt alle 15+ Config-Werte an
- [ ] 🔲 `bkg metrics` — 10+ Metriken (cpu, memory, ledger-height, mesh-peers, trust-nodes, gc-entropy)
- [ ] 🔲 API-Client-Bibliothek (Python SDK, Rust Crate)
- [ ] 🔲 HTTP API Server: alle 7 Endpunkte antworten in < 50ms
- [ ] 🔲 CI/CD Pipeline: Push → Test → Build → Artifact in < 5min

### Web-WASM Gates
- [ ] 🔲 **Dioxus Landing Page (20/20 Sections)**
  - Jede Section lädt in < 1s
  - Keine WASM-Panics (error边界)
- [ ] 🔲 **Web-Demo (Browser läuft)**
  - 3+ Browsern getestet (Chrome, Firefox, Edge)
  - Runtime < 5s bis interaktiv
  - 10 simulierte User-Interaktionen alle erfolgreich
- [ ] 🔲 **WASM-Bindings**
  - 5+ BKG-API-Funktionen via wasm-bindgen exponiert
  - Keine memory leaks (100 Aufrufe → Heap stabil)
- [ ] 🔲 **CI/CD Pipeline**
  - GitHub Actions: cargo check → test → wasm-pack build → deploy
- [ ] 🔲 **Release-Build**
  - wasm-opt Level 4
  - Binary < 1MB
  - wasm-pack build --release erfolgreich

### Garbage Nodes Gates
- [ ] 🔲 **Mesh Full Listener (TCP)**
  - 10 Peers connected in < 5s
  - 3× Heartbeat-Timeout → Peer removed (90s)
  - Nachrichten-Rate: 1000 msg/s ohne Verlust
- [ ] 🔲 **Cold Storage Persistence**
  - 10k Archiveinträge: Write in < 100ms, Read in < 10ms
  - Restore: vollständig, bitgenau
- [ ] 🔲 **Topology Rewiring**
  - 50% Peer Loss → neues Mesh in < 10s
  - Partition-Healing: detect in < 30s
- [ ] 🔲 **Attack Hotspot Defense**
  - 3 Attack-Vektoren (Flood, Sybil, Eclipse) alle erkannt
  - False-Positive: < 1%
  - Reaktion: Quarantine-Vorschlag an Motherbrain in < 5s
- [ ] 🔲 **Knowledge Decay Engine**
  - Entropy-Berechnung: korrekt für 1000 simulierte Receipts
  - Decay-Threshold: konfigurierbar (Default: 30 Tage)
  - Auto-Archivierung: korrekt nach Threshold
- [ ] 🔲 **Entropy Forecasting**
  - 7-Tage-Forecast: < 15% Abweichung
  - 30-Tage-Forecast: < 25% Abweichung

### Guard LLM Gates
- [ ] 🔲 **Custom Guard Model trainiert**
  - Modell < 50MB (quantisiert)
  - Accuracy: ≥ 95% auf Test-Set
  - False-Positive-Rate: < 2%
  - False-Negative-Rate: < 5%
- [ ] 🔲 **In BKG-Kernel integriert**
  - Inference in < 10ms pro Prediction
  - Fallback: wenn Modell nicht ladbar → Rule-Based
  - Kein direkter Ledger-Zugriff (Invariant 07)
- [ ] 🔲 **Collusion/Attack-Erkennung via ML**
  - 1000 synthetische Szenarien: ≥ 95% korrekt
  - Vergleich mit Rule-Based: ML ≥ Rule-Based
- [ ] 🔲 **Trust-Scoring via Modell**
  - Trust-Prediction: ±0.05 Abweichung von Ground Truth
  - 10k Samples: Korrelation ≥ 0.95 mit Ground Truth

### BKG Language Gates
- [ ] 🔲 **BKG-QL (Query Language) spezifiziert**
  - SELECT, WHERE, FILTER, SORT, LIMIT
  - 10 Beispiel-Queries dokumentiert
- [ ] 🔲 **BKG-DSL für Agent-Tasks**
  - 5+ Action-Typen (SWARM_VALIDATE, REPLAY_VERIFY, TRUST_QUERY, MESH_BROADCAST, GC_COLLECT)
  - DSL → Intent Graph → Motherbrain Approval → Execution (Invariant 08)
- [ ] 🔲 **Parser + Interpreter**
  - Parser: 100 synthetische Queries → 100% korrekt
  - Interpreter: korrekte Ergebnisse gegen Ledger
  - Fehlerbehandlung: 10 synthetische Fehler → 100% erkannt
- [ ] 🔲 **In Kernel integriert**
  - `bkg query "<BKG-QL>"` — Antwort in < 50ms
  - `bkg task "<BKG-DSL>"` — Execution + Ergebnis in < 5s

---

## Tracking Chain

| Datei | Rolle | Aktualisierung |
|-------|-------|----------------|
| `task.md` (dieses) | Meta-Index + Gold-Check | Nach jedem Bereichs-Durchlauf |
| `tasks/task-motherbrain.md` | Motherbrain Task Chain | Nach jedem Schritt |
| `tasks/task-client.md` | Client Task Chain | Nach jedem Schritt |
| `tasks/task-web-wasm.md` | Web-WASM Task Chain | Nach jedem Schritt |
| `tasks/task-garbage.md` | Garbage Nodes Task Chain | Nach jedem Schritt |
| `tasks/task-guard-llm.md` | Guard LLM Task Chain | Nach jedem Schritt |
| `tasks/task-bkg-lang.md` | BKG Language Task Chain | Nach jedem Schritt |
| `docs/invariants.md` | System Invariants (Verfassung) | Bei Invariant-Änderung |
| `contracts/motherbrain-api.md` | Motherbrain API Contract | Bei API-Freeze / Change |
| `contracts/ledger-schema.md` | Ledger Schema Contract | Bei Schema-Freeze / Change |
| `contracts/mesh-protocol.md` | Mesh Protocol Contract | Bei Protocol-Freeze / Change |
| `truth.md` | Ground Truth | Nach jedem Schritt |
| `docs/progress.md` | Metriken + % | Nach jedem Schritt |
| `docs/llm.nfo` | LLM-Referenz | Bei Architektur-Änderungen |

**Regel:** `task.md` ⊃ `progress.md` ⊃ `truth.md` ⊃ `llm.nfo`
**Contract-Regel:** `contracts/*` sind Constitution — Implementation muss folgen, nicht umgekehrt.
