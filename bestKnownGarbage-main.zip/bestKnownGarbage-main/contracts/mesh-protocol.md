# Mesh Protocol Contract

> **Netzwerk-Protokoll.** Kommunikation zwischen Garbage Nodes und Motherbrain.
>
> **Status:** Draft — wird mit G004 eingefroren.

---

## Message Types

```rust
pub enum MeshMessage {
    // Discovery
    PeerHello { node_id: NodeId, capabilities: Vec<Capability> },
    PeerBye { node_id: NodeId, reason: String },
    PeerList { peers: Vec<NodeId> },

    // Heartbeat
    Ping { nonce: u64 },
    Pong { nonce: u64, latency_ms: u64 },

    // Observation (read-only)
    Observation { node_id: NodeId, chunk_hash: Hash, trust_evidence: Vec<u8> },

    // Topology
    TopologyChange { node_id: NodeId, old_role: Role, new_role: Role },

    // Swarm
    SwarmProposal { proposal_id: Hash, chunk_hash: Hash, validator_count: u8 },
    SwarmVote { proposal_id: Hash, node_id: NodeId, decision: VoteDecision },
    SwarmResult { proposal_id: Hash, outcome: SwarmOutcome },
}
```

## Transport

- **Layer:** TCP (mTLS optional ab Beta)
- **Port Range:** 42000–42099 (konfigurierbar)
- **Format:** Length-prefixed, bincode-serialized
- **Max Message Size:** 1 MB

## Discovery

- Initial: Seed Nodes aus Konfiguration
- Laufend: Gossip-basiert (PeerList alle 30s)
- Abwesend nach: 3× Heartbeat-Timeout (90s Default)

## Security (Beta+)

- mTLS mit kurzen Session-Keys (24h Rotation)
- Nachrichten-Signatur (Ed25519)
- Rate Limiting: 100 msg/s pro Peer

---

## Protocol Stability

| Phase | Status |
|-------|--------|
| Pre-Alpha | Experimentell |
| Alpha | Unstable |
| Beta | Stable |
| v1.0 | Frozen |
