# Ledger Schema Contract

> **Datenmodell.** Alle Ledger-Operationen folgen diesem Schema.
>
> **Status:** Draft — wird mit M017 eingefroren.

---

## Ledger Block

```rust
pub struct LedgerBlock {
    pub hash: Hash,
    pub parent_hash: Hash,
    pub height: u64,
    pub timestamp: u64,           // UNIX ms
    pub body: Vec<Receipt>,
    pub state_root: Hash,         // Merkle Root des Zustands
    pub system_mode: SystemMode,  // gültig ab diesem Block
}
```

## Receipt

```rust
pub struct Receipt {
    pub id: ReceiptId,
    pub chunk_hash: Hash,
    pub node_id: NodeId,
    pub trust_score: TrustScore,
    pub execution_hash: Hash,
    pub environment_id: EnvironmentId,
    pub events: Vec<Event>,
    pub timestamp: u64,
}
```

## TrustVector

```rust
pub struct TrustVector {
    pub reproduction_accuracy: f32,   // 0.0 – 1.0
    pub cross_node_consistency: f32,  // 0.0 – 1.0
    pub environment_stability: f32,   // 0.0 – 1.0
    pub divergence_rate: f32,         // 0.0 – 1.0 (niedriger = besser)
    pub fraud_detection_penalty: f32, // 0.0 – 1.0 (0 = clean)
}
```

## ReplayClass

```rust
pub enum ReplayClass {
    Tiny,             // < 1s, einfache deterministische Operationen
    Standard,         // < 30s, normale Chunks
    Heavy,            // < 5min, komplexe Chunks
    Dangerous,        // < 30min, riskante Chunks (LLM Output, externe Daten)
    NonDeterministic, // spezielle Behandlung, keine Voll-Replay-Garantie
}
```

## SystemMode

```rust
pub enum SystemMode {
    Bootstrap,  // Minimale Security, initiale Konfiguration
    Alpha,      // Aggressive Logs, schwache Isolation
    Beta,       // Sandbox-Pflicht, strict replay
    Hardened,   // Volle Sicherheit, strict replay + audit
    Recovery,   // Kein Write, Wiederherstellung
    Quarantine, // Isolierte Nodes, untersuchende Adjudication
    ReadOnly,   // Nur Diagnose, kein Write
}
```

---

## Schema Stability

| Version | Status |
|---------|--------|
| v0.1 (current) | Draft, kann sich ändern |
| v1.0 (Alpha) | Eingefroren für Alpha |
| v1.1 (Beta) | Erweiterungen nur additiv |
| v2.0 (v1.0) | Stabil |
