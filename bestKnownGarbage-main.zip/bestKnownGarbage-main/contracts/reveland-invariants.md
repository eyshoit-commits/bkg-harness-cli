# Reveland Invariants Contract

> **Reveland Causality.** Every causal event must be verified, traceable, and aligned with the BKG Reveland taxonomy.
>
> **Status:** Draft — binds the kernel contract layer (PACTA) to the causal timeline invariants.

---

## Causal Proof

```rust
pub struct CausalProof {
    pub id: String,
    pub module_path: String,
    pub parent_id: Option<String>,
    pub hash: String,
    pub timestamp: i64,
    pub metadata: Option<String>,
}
```

## Causal Invariant Checker

```rust
pub trait CausalInvariantChecker {
    fn check_proof(&self, proof: &CausalProof) -> Result<(), CausalError>;
    fn check_chain(&self, proofs: &[CausalProof]) -> Result<(), CausalError>;
}
```

## BKG Reveland Invariants

- **Tempus non frangitur** — every timeline event must have a direct, unbroken causal parent chain or be a verified imported root from `Mnemos`.
- **Module identity validation** — every `module_path` in a `CausalProof` must resolve to a known Reveland Sphäre.
- **Append-only truth** — receipts, truth reports, and timeline records are immutable once written.
- **Covenant binding** — kernel invariants are codified in `crates/bkg-core/src/kernel/contracts.rs` and enforced by the Reveland contract.
- **No live cross-capsule state** — all cross-capsule transfers are asynchronous and materialized through cryptographically-addressed views.
- **Repair limit** — repair loops halt after `MAX_REPAIR_ATTEMPTS = 3` and may transition the capsule to a locked terminal state.

## Contract Semantics

- `CausalProof.id` is the unique identifier for one causal event.
- `CausalProof.parent_id` preserves the direct causal edge in the Tempus stream.
- `CausalProof.hash` is a non-empty integrity anchor for the event payload.
- `CausalProof.module_path` must map to a Reveland name such as `capsule`, `kernel::execution`, `kernel::truth`, `kernel::time`, `kernel::evolution`, `kernel::memory`, or `kernel::contracts`.

## Stability

| Version | Status |
|---------|--------|
| v0.1 | Draft |
| v1.0 | Frozen for alpha |
| v1.1 | Additive extensions only |

---

## Related Artifacts

- `crates/bkg-core/src/reveland.rs`
- `crates/bkg-core/src/kernel/contracts.rs`
- `why.md`
