# Motherbrain API Contract

> **Interface Definition.** Alle Downstream-Systeme (Client, Mesh, GC, Guard) kommunizieren ausschließlich über diese API.
>
> **Status:** Draft — wird mit M046 eingefroren.

---

## Core Endpoints

### System Mode

```
GET  /v1/mode          → SystemMode
POST /v1/mode          → SystemMode (transition)
```

SystemMode enum: `Bootstrap | Alpha | Beta | Hardened | Recovery | Quarantine | ReadOnly`

### Ledger

```
GET  /v1/ledger/head   → LedgerHead { hash, height, timestamp }
GET  /v1/ledger/block  → LedgerBlock (by hash or height)
POST /v1/ledger/commit → Receipt (append only)
```

### Trust

```
GET  /v1/trust/node/:id    → TrustVector
GET  /v1/trust/top         → Vec<(NodeId, TrustScore)> (top N)
POST /v1/trust/evaluate    → TrustEvaluation (adjudication)
```

### Replay

```
POST /v1/replay/verify     → ReplayResult { valid, divergence }
POST /v1/replay/from/:hash → ReplayResult (starting point)
```

### Adjudication

```
POST /v1/adjudicate        → AdjudicationResult
POST /v1/adjudicate/batch  → Vec<AdjudicationResult>
```

---

## Stability Guarantees

| Phase | API Status |
|-------|-----------|
| Pre-Alpha (M001–M017) | **Experimental** — breaking changes expected |
| Alpha (M001–M046) | **Unstable** — changes require chain-wide review |
| Beta | **Stable** — changes need phasenübergreifendes Review |
| v1.0 | **Frozen** — breaking changes = Major Version |

---

## Error Codes

| Code | Meaning |
|------|---------|
| `E001` | Mode mismatch (e.g. Write in ReadOnly) |
| `E002` | Ledger integrity violation |
| `E003` | Trust evaluation failed (divergence) |
| `E004` | Replay verification failed |
| `E005` | Resource limit exceeded (Fuel/Time) |
| `E006` | Adjudication: no quorum |
| `E007` | Contract violation (invariant check failed) |
