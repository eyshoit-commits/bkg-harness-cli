fn main() {
    println!("Entropy Visualizer — not yet implemented");
}
