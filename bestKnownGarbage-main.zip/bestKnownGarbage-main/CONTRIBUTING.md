# Contributing to BKG

Thank you for your interest in contributing! This document outlines guidelines and best practices for development.

## Getting Started

### Prerequisites

- **Rust 1.82+** — Install from [rustup.rs](https://rustup.rs/)
- **Git** — For version control
- **Docker** (optional) — For containerized builds
- **Cargo** — Included with Rust

### Development Setup

```bash
# Clone repository
git clone https://github.com/wwwbkgme-oss/bestKnownGarbage.git
cd bestKnownGarbage

# Set Rust edition
rustup override set 1.82

# Build workspace
cargo build --all

# Run tests
cargo test --all

# Format and lint
cargo fmt --all
cargo clippy --all-targets --all-features
```

## Contribution Workflow

### 1. Create Issue

Before starting work, create an issue describing:
- **Problem** — What issue are you solving?
- **Scope** — Which components are affected?
- **Acceptance Criteria** — How will this be verified?

```markdown
## Issue: [TITLE]

### Problem
Describe the issue or feature request.

### Scope
- [ ] bkg-kernel
- [ ] bkg-cli
- [ ] Other: _____

### Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
```

### 2. Create Feature Branch

```bash
git checkout -b feature/ISSUE_NUMBER-brief-description

# Examples:
git checkout -b feature/42-add-skill-caching
git checkout -b feature/156-fix-policy-evaluation
```

### 3. Implement Changes

Follow the [Coding Standards](#coding-standards) below.

### 4. Test

```bash
# Unit tests for specific crate
cargo test -p bkg-kernel

# Integration tests
cargo test --test '*'

# With output
cargo test -- --nocapture --test-threads=1

# Coverage (with tarpaulin)
cargo tarpaulin --out Html
```

### 5. Format & Lint

```bash
# Format code
cargo fmt --all

# Check with Clippy
cargo clippy --all-targets --all-features -- -D warnings

# Fix common issues
cargo fix --allow-dirty
```

### 6. Commit

Write clear, descriptive commit messages:

```
feat: add skill caching layer

- Implement LRU cache for frequently used skills
- Add configuration options for cache size
- Include cache hit/miss metrics

Closes #42
```

**Format**: `TYPE: description`

**Types**:
- `feat` — New feature
- `fix` — Bug fix
- `docs` — Documentation
- `refactor` — Code restructuring
- `test` — Test additions/fixes
- `perf` — Performance improvements
- `chore` — Maintenance, dependencies
- `ci` — CI/CD configuration

### 7. Push & Create PR

```bash
git push origin feature/ISSUE_NUMBER-brief-description
```

Then open a Pull Request on GitHub with:
- **Title**: Same as commit message
- **Description**: Link to issue, describe changes
- **Testing**: Document how to verify changes

## Coding Standards

### General Principles

- **Production Ready** — All code is for production
- **Documentation** — All public items have doc comments
- **Error Handling** — Use `Result<T>` consistently
- **Testing** — Aim for 80%+ coverage
- **Performance** — Benchmark sensitive code

### Naming Conventions

```rust
// Crates: bkg-* prefix
bkg-kernel
bkg-cli
bkg-my-feature

// Modules: lowercase_with_underscores
pub mod trust_engine;
pub mod policy_rules;

// Functions: lowercase_with_underscores
pub fn execute_policy();
pub fn validate_trust_vector();

// Types: PascalCase
pub struct TrustVector;
pub enum SessionState;

// Constants: SCREAMING_SNAKE_CASE
const MAX_RETRIES: u32 = 3;
const DEFAULT_TIMEOUT: Duration = Duration::from_secs(30);

// Variables: lowercase_with_underscores
let session_id = SessionId::new();
let trust_vector = TrustVector::default();
```

### Documentation

```rust
/// Brief one-line description.
///
/// Longer explanation with more details. Include use cases
/// and any important caveats.
///
/// # Examples
/// ```
/// let result = my_function("input");
/// assert_eq!(result.is_ok(), true);
/// ```
///
/// # Errors
/// Returns `BkgError::InvalidInput` if the input is empty.
///
/// # Panics
/// Never panics.
pub fn my_function(input: &str) -> Result<String> {
    // Implementation
}
```

### Error Handling

```rust
// Use Result for fallible operations
pub fn risky_operation() -> Result<Value> {
    // Use ? operator for error propagation
    let data = read_file("config.json")?;
    let config: Config = serde_json::from_str(&data)?;
    Ok(config.value)
}

// Create domain-specific error types
#[derive(Debug)]
pub enum MyError {
    InvalidInput(String),
    IoError(std::io::Error),
    SerializationError(serde_json::Error),
}

impl From<std::io::Error> for MyError {
    fn from(e: std::io::Error) -> Self {
        MyError::IoError(e)
    }
}
```

### Testing

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_happy_path() {
        let result = my_function("valid input");
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), "expected output");
    }

    #[test]
    fn test_error_handling() {
        let result = my_function("");
        assert!(result.is_err());
        match result {
            Err(MyError::InvalidInput(msg)) => assert!(msg.contains("empty")),
            _ => panic!("unexpected error"),
        }
    }

    #[tokio::test]
    async fn test_async_operation() {
        let result = async_function().await;
        assert!(result.is_ok());
    }
}
```

### Performance-Critical Code

```rust
// Mark hot paths
#[inline]
pub fn hot_path_function(x: i32) -> i32 {
    x.wrapping_mul(2).wrapping_add(1)
}

// Use references for large types
pub fn process_large_data(data: &LargeStruct) {
    // Implementation
}

// Avoid unnecessary allocations
pub fn collect_into_existing(vec: &mut Vec<Item>, items: impl Iterator<Item = Item>) {
    vec.extend(items);
}

// Profile before optimizing
// cargo build --release
// perf record -g ./target/release/binary
// perf report
```

## Project Organization

### Crate Structure

```
crates/bkg-newfeature/
├── Cargo.toml           # Package metadata
├── src/
│   ├── lib.rs           # Public interface
│   ├── error.rs         # Error types
│   ├── config.rs        # Configuration
│   ├── core/            # Main implementation
│   │   ├── mod.rs
│   │   ├── engine.rs
│   │   └── types.rs
│   └── tests/           # Integration tests
└── tests/
    └── integration_test.rs
```

### Module Organization

```rust
// lib.rs — Public exports
pub mod engine;
pub mod config;
pub mod error;

pub use engine::Engine;
pub use error::{Error, Result};
```

```rust
// engine.rs — Main implementation
use crate::config::Config;

pub struct Engine {
    config: Config,
}

impl Engine {
    pub fn new(config: Config) -> Self {
        // Implementation
    }
}
```

## Pull Request Review

### What Reviewers Check

- ✅ Code follows standards
- ✅ Tests pass locally
- ✅ Documentation is complete
- ✅ Performance is acceptable
- ✅ No breaking changes (or justified)
- ✅ Security implications reviewed

### Addressing Review Feedback

1. **Address feedback promptly** — Aim for <24h turnaround
2. **Push updates to same branch** — Don't create new PRs
3. **Respond to each comment** — Use GitHub's reply feature
4. **Request re-review** — When all feedback is addressed

## Release Process

### Version Numbering

We follow **Semantic Versioning** (SemVer):
- `MAJOR.MINOR.PATCH` (e.g., 1.2.3)
- `MAJOR` — Breaking changes
- `MINOR` — New features (backward compatible)
- `PATCH` — Bug fixes

### Release Checklist

- [ ] All tests pass
- [ ] All code reviewed
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
- [ ] Version bumped in Cargo.toml
- [ ] Git tag created (`v1.2.3`)
- [ ] Crates published to crates.io

```bash
# Publish
cargo publish -p bkg-core
cargo publish -p bkg-kernel
# ... other crates

# Tag and push
git tag -a v1.2.3 -m "Release v1.2.3"
git push origin v1.2.3
```

## Code Review Etiquette

### As a Reviewer

- ✅ Be constructive and respectful
- ✅ Explain the "why", not just "no"
- ✅ Suggest improvements with examples
- ✅ Approve quickly for obvious changes
- ✅ Request changes for significant issues

```markdown
## Comment Style ✅

This approach could be optimized by using a HashMap for O(1) lookups:

```rust
let map: HashMap<Key, Value> = items.into_iter()
    .map(|item| (item.key(), item))
    .collect();
```

This avoids the O(N) linear search.
```

### As an Author

- ✅ Accept criticism constructively
- ✅ Don't take comments personally
- ✅ Ask clarifying questions
- ✅ Defend your approach if justified
- ✅ Be open to alternative solutions

```markdown
## Response Style ✅

Good point! I initially chose linear search for simplicity,
but the dataset can grow large. The HashMap approach is better.
Let me update the implementation.
```

## Troubleshooting

### Common Issues

**"Failed to resolve: use of undeclared type"**
```bash
# Ensure module is exported in lib.rs
# Check visibility (pub mod vs mod)
cargo check --all
```

**"test failed with: is_some() at line 42"**
```bash
# Run test with output to see panic message
cargo test -- --nocapture --test-threads=1
```

**"conflicting implementations of trait"**
```bash
# Ensure only one impl block per type
# Check for duplicate trait implementations
cargo expand # Use expand to see macro-generated code
```

**"async fn is not allowed in trait methods"**
```rust
// Use async_trait macro
use async_trait::async_trait;

#[async_trait]
pub trait MyTrait {
    async fn my_method(&self) -> Result<()>;
}
```

## Additional Resources

- [Rust Book](https://doc.rust-lang.org/book/)
- [Rust API Guidelines](https://rust-lang.github.io/api-guidelines/)
- [Cargo Book](https://doc.rust-lang.org/cargo/)
- [Clippy Lints](https://rust-lang.github.io/rust-clippy/)

---

**Questions?** Open a discussion or email dev@example.com

**Report bugs** using the [Issue Tracker](https://github.com/wwwbkgme-oss/bestKnownGarbage/issues)

Thank you for contributing to BKG! 🎉
