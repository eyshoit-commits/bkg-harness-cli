# BestKnownGarbage (BKG) — Deterministic AI Agent Framework

[![Rust](https://img.shields.io/badge/rust-1.82%2B-orange.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Status](https://img.shields.io/badge/status-v0.1%20alpha-yellow.svg)](#development-status)

A production-grade, deterministic framework for building verifiable AI agents with **strict write discipline**, **policy-driven execution**, **session isolation**, **budget tracking**, and **skill injection**.

> **Name Origin**: Every system produces garbage. BKG is about **knowing** it, **tracking** it, and **collecting** it deterministically.

## Features

- ✅ **Deterministic Execution** — Reproducible AI agent workflows with session replays
- ✅ **Policy Engine** — Rule-based governance with trust vectors and escalation handling
- ✅ **Session Management** — Isolated agent contexts with state snapshots and recovery
- ✅ **Strict Write Discipline** — All file operations verified, timestamped, and reversible
- ✅ **Budget Tracking** — Token counting, cost estimation, and spend limits per session
- ✅ **Skill Injection** — Dynamically load domain-specific tools and verified functions
- ✅ **Trust System** — Hierarchical trust verification with entropy regions and causality tracking
- ✅ **Multi-Agent Support** — Managed agent orchestration with coordinator patterns
- ✅ **Mesh Topology** — Distributed mesh networking with garbage collection
- ✅ **Verification System** — Built-in CI/CD verification with finding classification
- ✅ **Observability** — Tracing, telemetry, and replay inspector tools

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/wwwbkgme-oss/bestKnownGarbage.git
cd bestKnownGarbage

# Build all crates
cargo build --release

# Run tests
cargo test --all
```

### Basic Usage

```bash
# Show system status
cargo run -p bkg-cli -- status

# List available AI providers
cargo run -p bkg-cli -- providers

# Run interactive chat
cargo run -p bkg-cli -- chat "write a function to calculate fibonacci numbers"

# Start a coding session
cargo run -p bkg-cli -- session start "refactor authentication module"

# Check budget usage
cargo run -p bkg-cli -- budget status

# Run verification
cargo run -p bkg-cli -- verify run

# List and execute skills
cargo run -p bkg-cli -- skills list
```

### Configuration

Set environment variables for AI providers:

```bash
# NVIDIA NIM (recommended for LLMs)
export NVIDIA_API_KEY=your_key_here

# OpenAI
export OPENAI_API_KEY=your_key_here

# Anthropic
export ANTHROPIC_API_KEY=your_key_here

# Groq
export GROQ_API_KEY=your_key_here

# Local Ollama
export OLLAMA_BASE_URL=http://localhost:11434
```

## Project Structure

```
bestKnownGarbage/
├── crates/                    # 19 shared reusable crates
│   ├── bkg-core/             # Foundational types & bootstrap
│   ├── bkg-kernel/           # Trust engine, policy, mesh, GC
│   ├── bkg-cli/              # CLI library and commands
│   ├── bkg-session/          # Session management
│   ├── bkg-budget/           # Token counting & cost tracking
│   ├── bkg-skills/           # Skill registration & execution
│   ├── bkg-swd/              # Strict Write Discipline
│   ├── bkg-verify/           # CI verification system
│   ├── bkg-memory/           # Memory management
│   ├── bkg-multi-agent/      # Agent orchestration
│   ├── bkg-storage/          # Storage abstraction
│   ├── bkg-telemetry/        # Tracing & metrics
│   ├── bkg-protocol/         # Network protocols
│   ├── bkg-crypto/           # Cryptography primitives
│   ├── bkg-security/         # Security policies
│   ├── bkg-events/           # Event system
│   ├── bkg-serde/            # Serialization helpers
│   ├── bkg-config/           # Configuration framework
│   ├── bkg-types/            # Type definitions
│   ├── bkg-macros/           # Procedural macros
│   ├── bkg-errors/           # Error types
│   └── bkg-common/           # Shared utilities
│
├── projects/                  # 6 executable systems
│   ├── bkg-motherbrain/      # Authoritative kernel server
│   ├── bkg-node/             # Garbage collector node
│   ├── bkg-llm/              # Guard LLM service
│   ├── bkg-lang/             # Query language + DSL
│   ├── bkg-web/              # Web UI (Dioxus + WASM)
│   └── bkg-client/           # CLI + API client
│
├── docs/                      # Architecture & design documents
│   ├── architektur/          # System architecture specs
│   ├── roadmap.md            # Feature roadmap
│   └── invariants.md         # Engineering invariants
│
├── contracts/                 # API & protocol contracts
├── tools/                     # Developer utilities
│   ├── entropy-visualizer/
│   ├── fuzzers/
│   ├── ledger-inspector/
│   └── replay-inspector/
│
├── tasks/                     # Task tracking by project
├── testbeds/                  # Integration test environments
└── schemas/                   # Data schemas
```

## Architecture Overview

### Trust Engine & Policy System

The **Kernel** contains three core systems:

1. **Trust Engine** — Hierarchical trust verification
   - Trust vectors for agent authentication
   - Escalation handlers for policy violations
   - Causality tracking for event dependencies

2. **Policy Engine** — Rule-based governance
   - Policy rules with priorities
   - Condition evaluation and action execution
   - Integration with trust engine

3. **Mesh & Garbage Collection** — Distributed topology
   - Entropy regions for resource allocation
   - Node discovery and health checks
   - Automatic garbage collection of orphaned sessions

### Session Model

```
Session
  ├── Isolation Context
  │   ├── Environment variables
  │   ├── File scope
  │   └── Memory budget
  ├── Snapshot (SWD)
  │   ├── Before state
  │   ├── Operations log
  │   └── After state
  ├── Budget
  │   ├── Token usage
  │   ├── Cost tracking
  │   └── Limits
  └── Skills
      ├── Injected tools
      ├── Execution trace
      └── Results
```

### Strict Write Discipline (SWD)

Every file operation is:
- **Recorded** — Logged to session snapshot
- **Verified** — Integrity checked before/after
- **Reversible** — Can be rolled back if needed
- **Audited** — Part of deterministic replay

## Development Guide

### Building

```bash
# Check code without building
cargo check

# Build debug binaries
cargo build

# Build optimized release
cargo build --release

# Build specific crate
cargo build -p bkg-kernel

# Build with all features
cargo build --all-features
```

### Testing

```bash
# Run all tests
cargo test --all

# Run tests for specific crate
cargo test -p bkg-kernel

# Run tests with output
cargo test -- --nocapture

# Run doc tests
cargo test --doc

# Run integration tests
cargo test --test '*' -- --nocapture
```

### Code Quality

```bash
# Format code
cargo fmt

# Lint with Clippy
cargo clippy --all-targets --all-features

# Check documentation
cargo doc --no-deps --open

# Generate coverage (requires tarpaulin)
cargo tarpaulin --out Html
```

### Adding New Crates

```bash
# Create a new shared crate
cargo new --lib crates/bkg-FEATURE_NAME
cd crates/bkg-FEATURE_NAME

# Add to root Cargo.toml workspace members
```

### Adding New Projects

```bash
# Create a new project
cargo new --bin projects/bkg-PROJECT_NAME
cd projects/bkg-PROJECT_NAME

# Add to root Cargo.toml workspace members
```

## API Documentation

### Core Types

#### `Session`
```rust
pub struct Session {
    pub id: SessionId,
    pub state: SessionState,
    pub snapshot: FileSnapshot,
    pub budget: SessionBudget,
}
```

#### `Skill`
```rust
pub struct Skill {
    pub id: SkillId,
    pub name: String,
    pub description: String,
    pub execute: fn(SkillContext) -> SkillResult,
}
```

#### `PolicyRule`
```rust
pub struct PolicyRule {
    pub id: String,
    pub condition: Box<dyn Fn(&TrustVector) -> bool>,
    pub action: Box<dyn Fn(&mut ExecutionContext) -> Result<()>>,
    pub priority: u32,
}
```

### CLI Commands

```bash
# Session management
bkg session start "task description"
bkg session list
bkg session show SESSION_ID
bkg session resume SESSION_ID
bkg session delete SESSION_ID

# Skills
bkg skills list
bkg skills show SKILL_ID
bkg skills execute SKILL_ID --args "arg1" "arg2"

# Budget tracking
bkg budget status
bkg budget history
bkg budget set-limit 1000000

# Verification
bkg verify run
bkg verify report
bkg verify fix

# Memory
bkg memory search "query"
bkg memory clear
bkg memory export FORMAT

# Managed agents
bkg managed status
bkg managed preset
bkg managed run PRESET "task"
bkg managed validate
```

## Configuration

### Environment Variables

```bash
# AI Provider API keys
NVIDIA_API_KEY          # NVIDIA NIM
OPENAI_API_KEY          # OpenAI
ANTHROPIC_API_KEY       # Claude
GROQ_API_KEY            # Groq
GEMINI_API_KEY          # Google Gemini
OLLAMA_BASE_URL         # Local Ollama

# BKG Configuration
BKG_DATA_DIR            # State directory (default: ~/.bkg)
BKG_LOG_LEVEL           # Log verbosity (debug|info|warn|error)
BKG_BUDGET_TOKENS       # Default token budget per session
BKG_VERIFY_ON_COMMIT    # Auto-verify on file write (true|false)
```

### Configuration File

```yaml
# ~/.bkg/config.yaml
providers:
  default: nvidia
  nvidia:
    api_key: ${NVIDIA_API_KEY}
    base_url: https://integrate.api.nvidia.com/v1
  
session:
  default_budget: 1000000
  isolation_level: session  # session|process|machine
  
verify:
  on_write: true
  auto_fix: false

skills:
  directory: ~/.bkg/skills
  auto_register: true
```

## Deployment

### Docker Deployment

```dockerfile
FROM rust:1.82 as builder
WORKDIR /app
COPY . .
RUN cargo build --release -p motherbrain-server

FROM debian:bookworm-slim
COPY --from=builder /app/target/release/motherbrain-server /usr/local/bin/
EXPOSE 8080
CMD ["motherbrain-server"]
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: bkg-motherbrain
spec:
  replicas: 3
  selector:
    matchLabels:
      app: bkg-motherbrain
  template:
    metadata:
      labels:
        app: bkg-motherbrain
    spec:
      containers:
      - name: motherbrain
        image: bkg-motherbrain:latest
        ports:
        - containerPort: 8080
        env:
        - name: NVIDIA_API_KEY
          valueFrom:
            secretKeyRef:
              name: ai-credentials
              key: nvidia-key
```

## Performance

### Benchmarks

```bash
# Run benchmarks
cargo bench --all

# Profile with perf
cargo build --release
perf record -g ./target/release/bkg-cli status
perf report
```

### Optimization Tips

1. **Enable Release Mode** — Always use `--release` for production
2. **Reduce Features** — Disable unused crate features
3. **Parallel Compilation** — Set `CARGO_BUILD_JOBS`
4. **Incremental Build** — Use `CARGO_INCREMENTAL=1` during development

## Security

- **Trust Verification** — All operations validated against trust vector
- **Policy Enforcement** — Rules prevent unauthorized operations
- **Session Isolation** — No cross-session state leakage
- **Cryptographic Signing** — Operations timestamped and signed
- **Audit Logging** — Complete operation history for forensics

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/FEATURE_NAME`)
3. Make changes following the style guide
4. Run tests and linting (`cargo test && cargo clippy`)
5. Commit with clear messages (`git commit -m "feat: description"`)
6. Push and open a Pull Request

### Coding Standards

- **Rust 2024 Edition** — Required for all new code
- **Doc Comments** — All public items must have documentation
- **Error Handling** — Use `Result<T>` and custom error types
- **Naming** — Use `bkg-*` prefix for all crates and binaries
- **Testing** — Aim for 80%+ test coverage

## Troubleshooting

### Compilation Errors

```bash
# Clear build cache
cargo clean

# Update dependencies
cargo update

# Check for Rust version issues
rustc --version  # Must be 1.82+

# Detailed error messages
RUST_BACKTRACE=1 cargo build
```

### Runtime Issues

```bash
# Enable debug logging
RUST_LOG=debug ./bkg-cli status

# Check session state
./bkg-cli session show SESSION_ID

# Verify file integrity
./bkg-cli verify run

# Inspect replay data
cargo run -p replay-inspector -- SESSION_ID
```

## Roadmap

### Phase 1: Foundation (Q2 2026)
- [x] Core kernel implementation
- [x] Session management
- [x] Trust engine
- [ ] Policy system completion

### Phase 2: Integration (Q3 2026)
- [ ] Multi-provider support
- [ ] Skill marketplace
- [ ] Advanced memory management
- [ ] Distributed mesh

### Phase 3: Production (Q4 2026)
- [ ] Performance optimization
- [ ] Kubernetes integration
- [ ] Enterprise RBAC
- [ ] Compliance auditing

### Phase 4: Intelligence (Q1 2027)
- [ ] Language service (BKG Lang)
- [ ] Guard LLM integration
- [ ] Adaptive learning
- [ ] Autonomous agent coordination

See [Roadmap](docs/roadmap.md) for detailed timeline.

## License

MIT License — See [LICENSE](LICENSE) for details

## Support

- 📖 [Full Documentation](docs/)
- 🐛 [Issue Tracker](https://github.com/wwwbkgme-oss/bestKnownGarbage/issues)
- 💬 [Discussions](https://github.com/wwwbkgme-oss/bestKnownGarbage/discussions)
- 📧 Email: dev@example.com

## Acknowledgments

Built with Rust and love. Special thanks to the AI, systems, and distributed computing communities.

---

**Status**: Pre-release alpha (v0.1). APIs subject to change. Production use at your own risk.

**Last Updated**: May 23, 2026
