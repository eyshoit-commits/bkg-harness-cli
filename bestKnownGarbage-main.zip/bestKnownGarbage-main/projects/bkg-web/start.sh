#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════════════
# BKG-WASM — start.sh
# Production build + dev server with correct WASM MIME types.
#
# Usage:
#   ./start.sh build           Build WASM binary (release)
#   ./start.sh build --dev     Build WASM binary (dev)
#   ./start.sh serve           Serve pkg/ on http://localhost:8080
#   ./start.sh serve --port 9090   Serve on custom port
#   ./start.sh start           Build + serve in background
#   ./start.sh stop            Stop background server
#   ./start.sh restart         Build + restart server
#   ./start.sh dev             Build (dev) + serve in foreground
#   ./start.sh status          Check if server is running
#   ./start.sh logs            Tail server logs
#   ./start.sh clean           Remove build artifacts
# ═══════════════════════════════════════════════════════════════════════════

BKG_ROOT="$(cd "$(dirname "$0")" && pwd)"
export PATH="$HOME/.cargo/bin:$PATH"

PID_FILE="$BKG_ROOT/.bkg-server.pid"
LOG_FILE="$BKG_ROOT/.bkg-server.log"
PORT="${BKG_PORT:-8080}"

# ─── Helpers ───────────────────────────────────────────────────────────────

# Kill any process holding a given port
kill_port() {
    local port="${1:-8080}"
    local pids
    pids=$(lsof -ti :"$port" 2>/dev/null || true)
    if [ -n "$pids" ]; then
        info "Freeing port $port (PID $pids)..."
        kill $pids 2>/dev/null || true
        sleep 0.5
        # Force kill if still hanging
        pids=$(lsof -ti :"$port" 2>/dev/null || true)
        if [ -n "$pids" ]; then
            kill -9 $pids 2>/dev/null || true
            sleep 0.3
        fi
    fi
}

# ─── Server script path ─────────────────────────────────────────────────────
SERVE_SCRIPT="$BKG_ROOT/.bkg-serve.py"

# Write the Python server script once
write_server_script() {
    if [ ! -f "$SERVE_SCRIPT" ]; then
        cat > "$SERVE_SCRIPT" << 'PYEOF'
import http.server, socketserver, mimetypes, socket, sys, time, os
mimetypes.add_type("application/wasm", ".wasm")
mimetypes.add_type("application/javascript", ".mjs")

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
MAX_RETRIES = 5

class ReuseAddrServer(socketserver.TCPServer):
    allow_reuse_address = True
    def server_bind(self):
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except AttributeError:
            pass
        for attempt in range(MAX_RETRIES):
            try:
                self.socket.bind(self.server_address)
                return
            except OSError as e:
                if attempt < MAX_RETRIES - 1:
                    sys.stderr.write(f"[bkg] Port {PORT} busy, retrying ({attempt+1}/{MAX_RETRIES})...\n")
                    sys.stderr.flush()
                    time.sleep(1)
                else:
                    raise e

Handler = http.server.SimpleHTTPRequestHandler
try:
    with ReuseAddrServer(("", PORT), Handler) as httpd:
        sys.stdout.write(f"[bkg] Serving at http://localhost:{PORT}\n")
        sys.stdout.flush()
        httpd.serve_forever()
except OSError as e:
    sys.stderr.write(f"[bkg] ERROR: Could not bind to port {PORT}: {e}\n")
    sys.stderr.write("[bkg] Run ./start.sh stop to free the port.\n")
    sys.stderr.flush()
    sys.exit(1)
PYEOF
        chmod +x "$SERVE_SCRIPT"
    fi
}

# ─── Colors ────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color
info()  { echo -e "${CYAN}[bkg]${NC} $*"; }
ok()    { echo -e "${GREEN}[bkg]${NC} $*"; }
warn()  { echo -e "${YELLOW}[bkg]${NC} $*"; }
err()   { echo -e "${RED}[bkg] ERROR:${NC} $*"; }

# ─── Help ──────────────────────────────────────────────────────────────────
show_help() {
    sed -n '3,20p' "$0"
    exit 0
}

# ─── Prerequisites ─────────────────────────────────────────────────────────
check_prereqs() {
    if ! command -v wasm-pack &>/dev/null; then
        err "wasm-pack not found. Install it:"
        echo "  curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh"
        exit 1
    fi
    if ! command -v rustc &>/dev/null; then
        err "Rust not found. Install it:"
        echo "  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
        exit 1
    fi
    if ! rustup target list --installed 2>/dev/null | grep -q wasm32-unknown-unknown; then
        info "Installing wasm32-unknown-unknown target..."
        rustup target add wasm32-unknown-unknown
    fi
}

# ─── Build ─────────────────────────────────────────────────────────────────
cmd_build() {
    local profile="release"
    local wasm_args="--release"
    if [ "${1:-}" = "--dev" ] || [ "${1:-}" = "-d" ]; then
        wasm_args="--dev"
        profile="debug"
        info "Building in DEV mode..."
    else
        info "Building in RELEASE mode..."
    fi

    check_prereqs

    cd "$BKG_ROOT"
    wasm-pack build --target web $wasm_args --out-dir pkg 2>&1 | sed 's/^/[wasm-pack] /'

    local wasm_file="$BKG_ROOT/pkg/bkg_wasm_alpha_bg.wasm"
    if [ ! -f "$wasm_file" ]; then
        err "Build failed — no WASM output found."
        exit 1
    fi

    local wasm_size
    wasm_size=$(du -h "$wasm_file" | cut -f1)
    ok "Build complete — WASM binary: $wasm_size"

    # Copy deploy configs if they exist
    [ -f "$BKG_ROOT/_redirects" ] && cp "$BKG_ROOT/_redirects" "$BKG_ROOT/pkg/_redirects" 2>/dev/null || true
}

# ─── Serve (foreground) ───────────────────────────────────────────────────
cmd_serve() {
    local port="${1:-$PORT}"

    if [ ! -f "$BKG_ROOT/pkg/bkg_wasm_alpha_bg.wasm" ]; then
        err "No WASM binary found. Run './start.sh build' first."
        exit 1
    fi

    info "Starting server on http://localhost:${port}"
    info "Press Ctrl+C to stop."
    echo ""

    write_server_script
    kill_port "$port"
    sleep 0.3
    python3 "$SERVE_SCRIPT" "$port" 2>&1
}

# ─── Start (background) ───────────────────────────────────────────────────
cmd_start() {
    local build_mode="${1:-}"

    if [ -f "$PID_FILE" ]; then
        local old_pid
        old_pid=$(cat "$PID_FILE")
        if kill -0 "$old_pid" 2>/dev/null; then
            warn "Server already running (PID $old_pid). Use 'restart' or 'stop' first."
            exit 1
        fi
        rm -f "$PID_FILE"
    fi

    # Build (optional: pass --dev to build dev)
    if [ "$build_mode" = "--dev" ] || [ "$build_mode" = "-d" ]; then
        cmd_build --dev
    else
        cmd_build --release
    fi

    # Start server in background
    write_server_script
    kill_port "$PORT"
    sleep 0.3
    cd "$BKG_ROOT"
    nohup python3 "$SERVE_SCRIPT" "$PORT" \
        >> "$LOG_FILE" 2>&1 &
    local pid=$!
    echo "$pid" > "$PID_FILE"

    # Wait for server to start
    sleep 1
    if kill -0 "$pid" 2>/dev/null; then
        ok "Server started (PID $pid)"
        ok "http://localhost:${PORT}"
        info "Use './start.sh stop' to stop."
        info "Use './start.sh logs' to see output."
    else
        err "Server failed to start. Check logs:"
        cat "$LOG_FILE"
        rm -f "$PID_FILE"
        exit 1
    fi
}

# ─── Stop ──────────────────────────────────────────────────────────────────
cmd_stop() {
    local pid=""
    if [ -f "$PID_FILE" ]; then
        pid=$(cat "$PID_FILE")
        info "Stopping server (PID $pid)..."
        kill "$pid" 2>/dev/null || true
        sleep 0.5
        if kill -0 "$pid" 2>/dev/null; then
            warn "Process didn't stop gracefully. Forcing..."
            kill -9 "$pid" 2>/dev/null || true
            sleep 0.3
        fi
        rm -f "$PID_FILE"
    fi

    # Also clean up any orphaned processes on the port
    kill_port "$PORT"
    rm -f "$PID_FILE" 2>/dev/null || true
    ok "Server stopped."
}

# ─── Restart ───────────────────────────────────────────────────────────────
cmd_restart() {
    local build_mode="${1:-}"
    info "Restarting..."
    cmd_stop
    sleep 0.5
    cmd_start "$build_mode"
}

# ─── Status ────────────────────────────────────────────────────────────────
cmd_status() {
    if [ -f "$PID_FILE" ]; then
        local pid
        pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            local uptime_secs
            uptime_secs=$(( $(date +%s) - $(stat -c %Y "$PID_FILE" 2>/dev/null || echo 0) ))
            ok "Server running (PID $pid, port $PORT, up ${uptime_secs}s)"
            echo "  URL:   http://localhost:${PORT}"
            echo "  Logs:  $LOG_FILE"
            echo "  Build: $BKG_ROOT/pkg"
            return 0
        else
            warn "PID file exists but process is dead. Clean up with 'stop'."
            rm -f "$PID_FILE"
        fi
    fi

    # Check for orphaned servers
    local orphans
    orphans=$(lsof -ti :"$PORT" 2>/dev/null || true)
    if [ -n "$orphans" ]; then
        warn "Orphaned server processes found on port $PORT (PIDs: ${orphans//$'\n'/ })"
        echo "  Run './start.sh stop' to clean up."
    else
        warn "No server running."
    fi
}

# ─── Logs ──────────────────────────────────────────────────────────────────
cmd_logs() {
    if [ ! -f "$LOG_FILE" ]; then
        warn "No log file found. Start the server first."
        exit 1
    fi
    if [ "${1:-}" = "--tail" ] || [ "${1:-}" = "-t" ]; then
        tail -f "$LOG_FILE"
    else
        cat "$LOG_FILE"
    fi
}

# ─── Clean ─────────────────────────────────────────────────────────────────
cmd_clean() {
    info "Cleaning build artifacts..."
    rm -rf "$BKG_ROOT/pkg"
    rm -f "$BKG_ROOT/.bkg-server.pid"
    rm -f "$BKG_ROOT/.bkg-server.log"
    rm -f "$BKG_ROOT/.bkg-serve.py"
    ok "Cleaned: pkg/ .bkg-server.pid .bkg-server.log .bkg-serve.py"
}

# ─── DEV mode (alias for build --dev + serve) ─────────────────────────────
cmd_dev() {
    cmd_build --dev
    cmd_serve "${1:-$PORT}"
}

# ─── Command Dispatch ─────────────────────────────────────────────────────
CMD="${1:-help}"
shift 2>/dev/null || true

case "$CMD" in
    build)
        cmd_build "$@"
        ;;
    serve)
        cmd_serve "$@"
        ;;
    start)
        cmd_start "$@"
        ;;
    stop)
        cmd_stop
        ;;
    restart)
        cmd_restart "$@"
        ;;
    status)
        cmd_status
        ;;
    logs)
        cmd_logs "$@"
        ;;
    clean)
        cmd_clean
        ;;
    dev)
        cmd_dev "$@"
        ;;
    --release|-r)
        # Backwards compat: ./start.sh --release
        cmd_build --release
        cmd_serve "$@"
        ;;
    --dev|-d)
        # Backwards compat: ./start.sh --dev
        cmd_build --dev
        cmd_serve "$@"
        ;;
    help|--help|-h|*)
        show_help
        ;;
esac
