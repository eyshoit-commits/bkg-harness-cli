# bkg-web — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-web-wasm.md` (W001–W012)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **WasmBinder** | wasm-bindgen bindings, JS interop | P0 |
| **VfsAgent** | Virtual FS, IndexedDB persistence | P0 |
| **DioxusAgent** | Dioxus landing page, components | P1 |
| **DemoAgent** | Web demo, examples | P2 |

## Dependencies
- `crates/bkg-wasm-bindings/` — wasm-bindgen bindings
- `crates/bkg-vfs/` — virtual file system
- Standalone project (no workspace path deps except planned)

## Entry Points
- `src/main.rs` — Dioxus app entry (wasm32 target)
- `index.html` — static landing page
