use crate::era::Era;
use std::collections::VecDeque;

// ─── Time State ────────────────────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct TimeState {
    pub uptime_cycles: u64,
    pub ledger_height: u64,
    pub consensus_cycle: u64,
    pub last_migration_cycle: u64,
}

impl TimeState {
    pub fn new() -> Self {
        Self {
            uptime_cycles: 0,
            ledger_height: 142_093,
            consensus_cycle: 482_991,
            last_migration_cycle: 377_200,
        }
    }

    pub fn tick(&mut self) {
        self.uptime_cycles += 1;
        self.consensus_cycle += 1;
        if self.consensus_cycle % 7 == 0 {
            self.ledger_height += 1;
        }
    }
}

// ─── Log Event ─────────────────────────────────────────────────────────────

#[derive(Clone, Debug)]
pub enum LogSource {
    Collector,
    Motherbrain,
    Observer,
    TrustEngine,
    Scheduler,
    Archive,
    System,
    Core,
    Maintenance,
    Timeline,
    Guard,
    Unknown,
}

impl LogSource {
    pub fn as_str(&self) -> &'static str {
        match self {
            LogSource::Collector => "collector",
            LogSource::Motherbrain => "motherbrain",
            LogSource::Observer => "observer",
            LogSource::TrustEngine => "trust-engine",
            LogSource::Scheduler => "scheduler",
            LogSource::Archive => "archive",
            LogSource::System => "system",
            LogSource::Core => "core",
            LogSource::Maintenance => "maintenance",
            LogSource::Timeline => "timeline",
            LogSource::Guard => "guard",
            LogSource::Unknown => "unknown",
        }
    }
}

#[derive(Clone, Debug)]
pub enum LogSeverity {
    Debug,
    Info,
    Warn,
    Error,
}

impl LogSeverity {
    pub fn as_str(&self) -> &'static str {
        match self {
            LogSeverity::Debug => "debug",
            LogSeverity::Info => "info",
            LogSeverity::Warn => "warn",
            LogSeverity::Error => "error",
        }
    }
}

#[derive(Clone, Debug)]
pub struct LogEvent {
    pub source: LogSource,
    pub message: String,
    pub severity: LogSeverity,
    pub era_tag: Era,
}

impl LogEvent {
    pub fn new(source: LogSource, message: &str, severity: LogSeverity, era_tag: Era) -> Self {
        Self {
            source,
            message: message.to_string(),
            severity,
            era_tag,
        }
    }

    pub fn display(&self) -> String {
        format!("[{}] {}", self.source.as_str(), self.message)
    }
}

// ─── Guard State (Easter Egg System) ──────────────────────────────────────

#[derive(Clone, Debug, PartialEq)]
pub enum GuardMode {
    PassiveObserver,
    CoCoder,
    MeshArbiter,
    AutonomousSuggestor,
}

impl GuardMode {
    pub fn label(&self) -> &'static str {
        match self {
            GuardMode::PassiveObserver => "PASSIVE OBSERVER",
            GuardMode::CoCoder => "CO-CODER",
            GuardMode::MeshArbiter => "MESH ARBITER",
            GuardMode::AutonomousSuggestor => "AUTONOMOUS SUGGESTOR",
        }
    }
}

#[derive(Clone, Debug)]
pub struct GuardState {
    /// Archive Health click counter (7 clicks = unlock)
    pub archive_health_clicks: u8,
    /// Last terminal messages for command detection
    pub terminal_buffer: VecDeque<String>,
    /// Rolling keypress buffer for /sync.guard.enable detection
    pub command_buffer: String,
    /// Whether the guard node is unlocked
    pub unlocked: bool,
    /// Whether the overlay is currently visible (can be dismissed)
    pub overlay_visible: bool,
    /// Current guard mode
    pub mode: GuardMode,
    /// Editor content
    pub editor_content: String,
    /// Guard agent response log
    pub guard_log: VecDeque<String>,
}

impl GuardState {
    pub fn new() -> Self {
        Self {
            archive_health_clicks: 0,
            terminal_buffer: VecDeque::with_capacity(10),
            command_buffer: String::with_capacity(64),
            unlocked: false,
            overlay_visible: false,
            mode: GuardMode::PassiveObserver,
            editor_content: String::new(),
            guard_log: VecDeque::with_capacity(100),
        }
    }

    /// Check if the terminal buffer contains the unlock command.
    pub fn check_terminal_command(&mut self) -> bool {
        for msg in &self.terminal_buffer {
            if msg.contains("/sync.guard.enable") {
                return true;
            }
        }
        false
    }

    /// Push a terminal message into the rolling buffer.
    pub fn push_terminal_line(&mut self, msg: String) {
        self.terminal_buffer.push_back(msg);
        if self.terminal_buffer.len() > 10 {
            self.terminal_buffer.pop_front();
        }
    }

    /// Feed a keypress character into the command buffer.
    /// Returns true if the trigger sequence was completed.
    pub fn feed_key(&mut self, ch: char) -> bool {
        if ch == '\r' || ch == '\n' {
            // Check the buffer on Enter
            let triggered = self.command_buffer == "/sync.guard.enable";
            self.command_buffer.clear();
            return triggered;
        }
        // Backspace
        if ch == '\u{8}' || ch == '\x7f' {
            self.command_buffer.pop();
            return false;
        }
        self.command_buffer.push(ch);
        // Trim if too long
        if self.command_buffer.len() > 64 {
            self.command_buffer = self.command_buffer[self.command_buffer.len() - 32..].to_string();
        }
        false
    }

    /// Dismiss the guard overlay.
    pub fn dismiss(&mut self) {
        self.overlay_visible = false;
        self.unlocked = false;
    }

    /// Record a guard log entry.
    pub fn log_guard(&mut self, msg: &str) {
        self.guard_log.push_back(msg.to_string());
        if self.guard_log.len() > 100 {
            self.guard_log.pop_front();
        }
    }
}

// ─── System State Machine ──────────────────────────────────────────────────

#[derive(Clone, Debug, PartialEq)]
pub enum SystemState {
    Initializing,
    FalseStillness,
    Awakening,
    StableOperation,
    ObserverDesync,
    Backfill,
    MigrationEvent,
    SilentVoid,
    GuardNodeUnlocked, // Easter egg activated — secret overlay
}

impl SystemState {
    pub fn tick(&self, kernel: &BkgKernel) -> Self {
        // If guard is unlocked, stay in GuardNodeUnlocked until explicitly dismissed
        if matches!(self, SystemState::GuardNodeUnlocked) {
            return SystemState::GuardNodeUnlocked;
        }

        match self {
            SystemState::Initializing => SystemState::FalseStillness,

            SystemState::FalseStillness => {
                if kernel.time.uptime_cycles > 0 {
                    SystemState::Awakening
                } else {
                    SystemState::FalseStillness
                }
            }

            SystemState::Awakening => SystemState::StableOperation,

            SystemState::StableOperation => {
                let roll = kernel.time.consensus_cycle % 23;
                if roll == 0 {
                    SystemState::ObserverDesync
                } else if roll == 7 {
                    SystemState::MigrationEvent
                } else {
                    SystemState::StableOperation
                }
            }

            SystemState::ObserverDesync => SystemState::Backfill,
            SystemState::Backfill => SystemState::StableOperation,
            SystemState::MigrationEvent => SystemState::SilentVoid,
            SystemState::SilentVoid => SystemState::StableOperation,
            SystemState::GuardNodeUnlocked => SystemState::GuardNodeUnlocked,
        }
    }
}

// ─── BKG Kernel (Global State) ─────────────────────────────────────────────

#[derive(Clone)]
pub struct BkgKernel {
    pub time: TimeState,
    pub logs: VecDeque<LogEvent>,
    pub state: SystemState,
    pub guard: GuardState,
}

impl BkgKernel {
    pub fn new() -> Self {
        let mut kernel = Self {
            time: TimeState::new(),
            logs: VecDeque::with_capacity(5000),
            state: SystemState::Initializing,
            guard: GuardState::new(),
        };

        // Seed a few initial log events
        kernel.logs.push_back(LogEvent::new(
            LogSource::System,
            "kernel initialized",
            LogSeverity::Info,
            Era::Modern,
        ));
        kernel.logs.push_back(LogEvent::new(
            LogSource::Core,
            "consensus engine loaded",
            LogSeverity::Info,
            Era::Modern,
        ));

        kernel
    }

    pub fn tick(&mut self) {
        self.time.tick();
        self.state = self.state.tick(self);

        let event = crate::log::generate_event(self);
        let msg = event.display();

        // Feed terminal output into guard buffer for command detection
        self.guard.push_terminal_line(msg.clone());

        self.logs.push_back(event);

        if self.logs.len() > 5000 {
            self.logs.pop_front();
        }

        // Auto-check for terminal unlock command
        if !self.guard.unlocked && self.guard.check_terminal_command() {
            self.unlock_guard();
        }
    }

    /// Unlock the guard node — triggered by easter egg events.
    pub fn unlock_guard(&mut self) {
        self.guard.unlocked = true;
        self.guard.overlay_visible = true;
        self.state = SystemState::GuardNodeUnlocked;
        self.guard
            .log_guard("guard node activated — interface override");

        self.logs.push_back(LogEvent::new(
            LogSource::Guard,
            "node unlocked — alternate interface available",
            LogSeverity::Info,
            Era::Modern,
        ));
    }

    /// Archive Health click handler.
    pub fn click_archive_health(&mut self) {
        if self.guard.unlocked {
            return;
        }
        self.guard.archive_health_clicks += 1;
        if self.guard.archive_health_clicks >= 7 {
            self.unlock_guard();
        }
    }
}
