use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Problem: Git/CI/Observability vs BKG — paradigm comparison.
/// Institutional tone, not marketing.
#[component]
pub fn ProblemPanel(state: Signal<BkgKernel>) -> Element {
    rsx! {
        section {
            class: "problem-panel era-modern",
            id: "problem",

            div { class: "comparison-grid",
                div { class: "comparison-item dimmed",
                    h3 { "Git" }
                    p { "File history. Not truth history." }
                }
                div { class: "comparison-item dimmed",
                    h3 { "CI/CD" }
                    p { "Build history. Not reproducibility proof." }
                }
                div { class: "comparison-item dimmed",
                    h3 { "Observability" }
                    p { "Runtime metrics. Not epistemic evidence." }
                }
                div { class: "comparison-item active",
                    h3 { "BKG" }
                    p { "Knowledge reality history." }
                }
            }
        }
    }
}
