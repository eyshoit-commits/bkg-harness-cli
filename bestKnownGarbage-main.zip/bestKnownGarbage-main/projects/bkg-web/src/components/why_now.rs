use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Why Now: "AI writes code faster than humans can verify it."
/// Single viewport. Minimal. The bottleneck is trust.
#[component]
pub fn WhyNowPanel(state: Signal<BkgKernel>) -> Element {
    rsx! {
        section {
            class: "why-now-panel era-modern",
            id: "why-now",

            div { class: "panel-content",
                h2 { "AI writes code faster than humans can verify it." }
                p { class: "panel-thesis",
                    "The bottleneck is no longer generation. "
                    "The bottleneck is trust."
                }
            }
        }
    }
}
