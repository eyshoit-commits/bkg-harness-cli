use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Consensus Replay — ERA: Proto01 (2004 cluster console).
/// Terminal windows, not cards. ASCII progress bars. Hard borders.
#[component]
pub fn ConsensusReplay(state: Signal<BkgKernel>) -> Element {
    let observers = [
        ("eu-west-01", true, 98usize),
        ("us-east-02", true, 97usize),
        ("lab-node-17", true, 99usize),
        ("archive-observer", true, 96usize),
    ];

    rsx! {
        section {
            class: "consensus-replay era-proto01",
            id: "consensus",

            div { class: "archive-label", "ARCHIVE NODE // CONSENSUS REPLAY" }

            div { class: "observers-grid",
                for (name, status, pct) in observers {
                    div { class: "observer-terminal",
                        div { class: "terminal-header", "[{name}]" }
                        div { class: "terminal-body",
                            pre {
                                "replaying execution..."
                                "\n{ascii_bar(pct)} {pct}%\n"
                                if status { "hash: 0x7F3A...B91E ✓" } else { "MISMATCH" }
                            }
                        }
                    }
                }
            }

            div { class: "consensus-result",
                pre { "CONSENSUS ACHIEVED\n4/4 observers reproduced identical state" }
            }
        }
    }
}

fn ascii_bar(pct: usize) -> String {
    let filled = pct / 5;
    let empty = 20 - filled;
    format!("{}▶{}", "#".repeat(filled), " ".repeat(empty))
}
