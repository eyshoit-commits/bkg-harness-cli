use dioxus::prelude::*;

/// Operational Void — the system has nothing to report.
/// NOT cinematic. Slightly misaligned. Terminal cursor.
/// Use id="silence-1", "silence-2", "silence-3" for the three zones.
#[component]
pub fn SilenceZone(id: String) -> Element {
    rsx! {
        section {
            class: "silence-zone",
            id: "{id}",

            div { class: "void-content",
                span { class: "void-label", "observing..." }
                span { class: "void-line", "receipt archived" }
            }
        }
    }
}
