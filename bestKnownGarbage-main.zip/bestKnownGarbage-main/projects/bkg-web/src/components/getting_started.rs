use dioxus::prelude::*;

/// Getting Started — Terminal prompt style. Shows CLI usage.
/// $ prompts, raw command output. No "quick start". No "docs".
#[component]
pub fn GettingStarted() -> Element {
    rsx! {
        section {
            class: "getting-started era-proto01",
            id: "getting-started",

            div { class: "archive-label", "GETTING STARTED // TERMINAL SESSION" }

            div { class: "gs-terminal",
                pre {
                    "$ bkg --help\n"
                    "\n"
                    "USAGE:\n"
                    "  bkg <command> [options]\n"
                    "\n"
                    "COMMANDS:\n"
                    "  run          Execute a receipt in sandbox\n"
                    "  verify       Replay execution for verification\n"
                    "  trust        Inspect trust vector state\n"
                    "  archive      Query receipt archive\n"
                    "  export       Export receipt as .rv2\n"
                    "\n"
                    "$ bkg trust --status\n"
                    "trust index: 87.3\n"
                    "consensus pressure: stable\n"
                    "observer count: 4\n"
                    "\n"
                    "$ bkg archive --epoch 2026-05\n"
                    "receipt count: 14,203\n"
                    "reproduced: 14,203 (100%)\n"
                    "oldest: 1,827 days"
                }
            }
        }
    }
}
