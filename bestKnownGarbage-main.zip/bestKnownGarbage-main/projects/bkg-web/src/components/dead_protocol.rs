use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Dead Protocol Layer — ERA: Dead (1990s ncurses).
/// Archived. Faded. Non-interactive. "failure reason: unrecoverable variance"
/// Contains early-era terminology and operator ghosts.
#[component]
pub fn DeadProtocolLayer(state: Signal<BkgKernel>) -> Element {
    rsx! {
        section {
            class: "dead-protocol-layer era-dead",
            id: "dead-protocol",

            div { class: "archive-marker", "ARCHIVED STRATUM // BKG-PROTO-02" }

            div { class: "protocol-header",
                span { "status: deprecated" }
                span { "last consensus: 2026-02-14" }
            }

            // ── Terminology mismatch — "quorum stress" is early-era, panel is Dead ──
            div { class: "protocol-failure",
                "failure reason: unrecoverable variance"
            }

            div { class: "protocol-metrics",
                div { class: "protocol-metric", "quorum stress: 0.94" }
                div { class: "protocol-metric", "hash mismatch: 3" }
                div { class: "protocol-metric", "observer timeout: 14s" }
            }

            // ── Human maintenance ghosts (§5) ──
            div { class: "protocol-ghost",
                "// legacy receipt parser retained for compatibility"
            }
            div { class: "protocol-ghost",
                "// do not disable witness fallback — reason unknown"
            }
            div { class: "protocol-ghost",
                "// parser version: 0.7.2 (deprecated)"
            }

            // ── Naming contradiction (§12.5.4) ──
            div { class: "protocol-ghost",
                "// referenced as: witness node / collector / epistemic observer (inconsistent)"
            }

            // ── Documentation rot (§12.5.3) ──
            div { class: "protocol-ghost",
                "// see migration memo #442 — memo not found in archive"
            }
        }
    }
}
