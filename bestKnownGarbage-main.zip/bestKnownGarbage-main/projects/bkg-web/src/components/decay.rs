use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Knowledge Decay Lifecycle — ERA: Proto02.
/// Hot → Warm → Cold → Revalidate lifecycle.
/// Contains terminology from both early and mid eras.
#[component]
pub fn DecayLifecycle(state: Signal<BkgKernel>) -> Element {
    rsx! {
        section {
            class: "decay-lifecycle era-proto02",
            id: "decay",

            div { class: "archive-label", "SYSTEM STATE // KNOWLEDGE DECAY LIFECYCLE" }

            div { class: "decay-flow",
                DecayStage { name: "HOT", desc: "active knowledge", state: "hot" }
                DecayStage { name: "WARM", desc: "recently verified", state: "warm" }
                DecayStage { name: "COLD", desc: "needs revalidation", state: "cold" }
                DecayStage { name: "REVALIDATE", desc: "verification in progress", state: "revalidate" }
            }

            // ── Time accumulation + ghost (§5, §6) ──
            div { class: "timeline-ghost",
                "// clock skew detected — legacy adapter compensating"
            }
            div { class: "timeline-ghost",
                "// historical replay backlog cleared after 71d"
            }
        }
    }
}

#[component]
fn DecayStage(name: String, desc: String, state: String) -> Element {
    rsx! {
        div {
            class: "decay-stage stage-{state}",
            div { class: "stage-name", "{name}" }
            div { class: "stage-desc", "{desc}" }
        }
    }
}
