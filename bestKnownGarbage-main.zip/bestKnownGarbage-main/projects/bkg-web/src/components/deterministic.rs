use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Deterministic Solution: 5 pillars of reproducible execution.
/// Terminal-style. No frills.
#[component]
pub fn DeterministicSolution(state: Signal<BkgKernel>) -> Element {
    let pillars = [
        ("Seeded RNG", "Every run produces identical results"),
        ("Virtual Clocks", "Time is deterministic, not wall-clock"),
        ("Fuel Metering", "Execution is bounded, no infinite loops"),
        ("Syscall Isolation", "No external side effects"),
        (
            "Env Fingerprinting",
            "Every environment has a verifiable identity",
        ),
    ];

    rsx! {
        section {
            class: "deterministic-solution era-proto02",
            id: "deterministic",

            h2 { "How to make software execution into scientific evidence" }

            div { class: "pillars-grid",
                for (i, (title, desc)) in pillars.iter().enumerate() {
                    div {
                        class: "pillar-node",
                        key: "{i}",
                        span { class: "pillar-index", "{i + 1}" }
                        h3 { "{title}" }
                        p { "{desc}" }
                    }
                }
            }
        }
    }
}
