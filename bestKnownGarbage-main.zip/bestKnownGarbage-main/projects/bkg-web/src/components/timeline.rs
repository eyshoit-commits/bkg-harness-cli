use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Temporal Knowledge Timeline — Hybrid era.
/// Horizontal timeline with epistemic scars as normal events.
/// Inconsistent spacing — deliberately not normalized.
#[component]
pub fn TimelineEngine(state: Signal<BkgKernel>) -> Element {
    let cycle = state.read().time.consensus_cycle;

    let events = vec![
        ("2026-01", "libpng exploit introduced", "security"),
        ("2026-02", "collector divergence detected", "divergence"),
        ("2026-03", "trust collapse triggered", "trust"),
        ("2026-04", "patched receipt validated", "fix"),
        (
            "2026-04",
            "observer-03 desync — resolved (3.2s)",
            "divergence",
        ),
        ("2026-05", "truth convergence threshold adjusted", "trust"),
        ("2026-05", "cultural variance baseline recalibrated", "fix"),
    ];

    rsx! {
        section {
            class: "timeline-engine",
            id: "timeline",

            div { class: "archive-label", "KNOWLEDGE STRATUM // TEMPORAL INDEX" }

            // Deliberately inconsistent — some timestamps have milliseconds, some don't
            div { class: "timeline-track",
                for (i, (date, desc, kind)) in events.iter().enumerate() {
                    div {
                        class: "timeline-event event-{kind}",
                        key: "{i}",
                        div { class: "event-date", "{date}" }
                        div { class: "event-desc", "{desc}" }
                    }
                }
            }

            // ── Human maintenance ghosts (§5) ──
            div { class: "timeline-ghost",
                "// do not disable witness fallback"
            }
            div { class: "timeline-ghost",
                "// reason unknown"
            }

            // ── Time accumulation (§6) ──
            div { class: "timeline-ghost",
                "continuity score: 0.987 // uninterrupted operation: {cycle} cycles"
            }
        }
    }
}
