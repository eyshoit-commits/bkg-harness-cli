use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// The Shift — emotional center of the page.
/// "Code is no longer authored. It is selected."
/// Full viewport monolith space. Minimal. Silence.
#[component]
pub fn ShiftMonolith(state: Signal<BkgKernel>) -> Element {
    rsx! {
        section {
            class: "shift-monolith era-modern",
            id: "shift",

            div { class: "monolith-content",
                h2 { class: "shift-line",
                    "Code is no longer authored."
                }
                h2 { class: "shift-line accent",
                    "It is selected."
                }
                p { class: "shift-subtitle",
                    "Software should be scientifically verifiable."
                }
            }
        }
    }
}
