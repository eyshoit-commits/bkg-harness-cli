use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Archive Health — the most minimal panel on the page.
/// Two words. That's it. 1990s ncurses aesthetic.
/// Click it 7 times to unlock the Guard Node.
#[component]
pub fn ArchiveHealth(state: Signal<BkgKernel>) -> Element {
    let clicks = state.read().guard.archive_health_clicks;
    let unlocked = state.read().guard.unlocked;

    let onclick = move |_| {
        state.write().click_archive_health();
    };

    // Show subtle click indicator before unlock
    let show_hint = clicks > 0 && !unlocked;

    rsx! {
        section {
            class: "archive-health era-dead",
            id: "archive-health",
            onclick: onclick,

            div { class: "archive-health-label", "ARCHIVE HEALTH" }
            div { class: "archive-health-value", "nominal" }
            if show_hint {
                div { class: "archive-health-clicks", "[{clicks}]" }
            }
        }
    }
}
