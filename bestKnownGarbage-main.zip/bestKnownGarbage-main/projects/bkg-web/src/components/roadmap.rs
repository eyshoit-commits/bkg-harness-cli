use dioxus::prelude::*;

/// Roadmap — plain table. No polish.
#[component]
pub fn Roadmap() -> Element {
    let items = vec![
        ("Core CLI", "Go", "Working"),
        ("TUI", "Go", "Working"),
        ("Rust Runtime", "Rust", "Exists"),
        ("Trust Field", "Rust", "Complete"),
        ("LLM Provider", "Rust", "Missing"),
        ("WebAssembly", "Rust/WASM", "Planned"),
        ("Web Demo", "HTML/JS", "Planned"),
    ];

    rsx! {
        section {
            class: "roadmap",
            id: "roadmap",

            div { class: "archive-label", "STATUS // IMPLEMENTATION ROADMAP" }

            div { class: "roadmap-table",
                for item in &items {
                    div { class: "roadmap-row",
                        span { class: "row-component", "{item.0}" }
                        span { class: "row-lang", "{item.1}" }
                        span { class: "row-status status-{item.2.to_lowercase()}", "{item.2}" }
                    }
                }
            }
        }
    }
}
