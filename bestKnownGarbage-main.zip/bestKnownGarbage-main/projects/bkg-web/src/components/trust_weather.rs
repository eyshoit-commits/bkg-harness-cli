use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Trust Vector Engine + Epistemic Meteorology — ERA: Proto02/Modern hybrid.
/// Weather panel: climate, pressure, fronts, forecast.
/// Naming: "TRUST SCORE" here, "TRUTH VECTOR" in motherbrain, "consensus confidence" in footer.
/// Never reconciled. Different operators named them differently.
#[component]
pub fn TrustWeather(state: Signal<BkgKernel>) -> Element {
    let cycle = state.read().time.consensus_cycle;
    let trust = 85.0 + ((cycle % 15) as f64).sin() * 8.0;
    let trust_str = format!("{:.1}", trust);

    let climate = if trust > 90.0 {
        "clear"
    } else if trust > 75.0 {
        "unstable"
    } else {
        "degraded"
    };
    let atmosphere = if trust > 80.0 { "transparent" } else { "hazy" };

    rsx! {
        section {
            class: "trust-weather era-proto02",
            id: "trust",

            div { class: "archive-label", "FILE // TRUST VECTOR ENGINE" }

            // ── Naming contradiction (§12.5.4): "TRUST INDEX" here vs "TRUTH VECTOR" elsewhere ──
            div { class: "trust-score-bar",
                div { class: "trust-label", "TRUST INDEX: {trust_str}" }
                div { class: "trust-bar-bg",
                    div {
                        class: "trust-bar-fill",
                        style: "width: {trust_str}%"
                    }
                }
            }

            div { class: "weather-grid",
                Metric { label: "epistemic climate", value: climate.to_string(), direction: "→" }
                Metric { label: "consensus pressure", value: "rising".to_string(), direction: "↑" }
                Metric { label: "confidence atmosphere", value: atmosphere.to_string(), direction: "→" }
                Metric { label: "observer turbulence", value: "low".to_string(), direction: "↓" }
            }

            // ── Time accumulation (§6) ──
            div { class: "weather-front",
                "consensus front moving east — high-pressure validation zone detected"
            }

            div { class: "time-accumulation",
                div { class: "accumulation-line", "oldest active receipt: 1827d" }
                div { class: "accumulation-line", "observer cluster: 4 protocol generations" }
            }
        }
    }
}

#[component]
fn Metric(label: String, value: String, direction: String) -> Element {
    rsx! {
        div { class: "weather-metric",
            span { class: "metric-label", "{label}" }
            span { class: "metric-value", "{value} {direction}" }
        }
    }
}
