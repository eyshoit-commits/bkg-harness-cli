use crate::kernel::{BkgKernel, GuardMode};
use dioxus::prelude::*;

/// Guard Node Editor Overlay — the hidden interface beneath the page.
/// Appears when the easter egg is triggered (7 clicks or /sync.guard.enable).
/// Split layout: editor (left) + guard agent output (right).
/// Includes execute button and Ctrl+Enter shortcut.
#[component]
pub fn GuardNodeOverlay(state: Signal<BkgKernel>) -> Element {
    let unlocked = state.read().guard.overlay_visible;
    let guard_mode = state.read().guard.mode.clone();
    let editor_content = state.read().guard.editor_content.clone();
    let guard_log: Vec<String> = state
        .read()
        .guard
        .guard_log
        .iter()
        .rev()
        .take(20)
        .cloned()
        .collect();

    if !unlocked {
        return rsx! { div { style: "display: none;" } };
    }

    // ─── Actions ────────────────────────────────────────────────────────────
    let ondismiss = move |_| {
        state.write().guard.dismiss();
        state.write().state = crate::kernel::SystemState::StableOperation;
    };

    let oneditor = move |evt: FormEvent| {
        state.write().guard.editor_content = evt.value().clone();
    };

    let onexecute = move |_| {
        let content = state.read().guard.editor_content.clone();
        let trimmed = content.trim().to_string();
        if !trimmed.is_empty() {
            let mode = state.read().guard.mode.clone();
            let response = match mode {
                GuardMode::PassiveObserver => "// observing: no action taken".to_string(),
                GuardMode::CoCoder => {
                    format!("// co-code analysis: reviewed {} chars", trimmed.len())
                }
                GuardMode::MeshArbiter => format!(
                    "// mesh arbitration: forwarded to {} peers",
                    (trimmed.len() % 3) + 1
                ),
                GuardMode::AutonomousSuggestor => format!(
                    "// auto-suggest: optimal path computed | confidence: {:.1}%",
                    70.0 + (trimmed.len() as f64 * 0.5).min(25.0)
                ),
            };
            let mut s = state.write();
            s.guard.log_guard(&format!("[execute] {}", trimmed));
            s.guard.log_guard(&response);
        }
    };

    let onkeydown = move |evt: KeyboardEvent| {
        if evt.key() == keyboard_types::Key::Enter
            && evt.modifiers().contains(keyboard_types::Modifiers::CONTROL)
        {
            let content = state.read().guard.editor_content.clone();
            let trimmed = content.trim().to_string();
            if !trimmed.is_empty() {
                let mode = state.read().guard.mode.clone();
                let response = match mode {
                    GuardMode::PassiveObserver => "// observing: no action taken".to_string(),
                    GuardMode::CoCoder => {
                        format!("// co-code analysis: reviewed {} chars", trimmed.len())
                    }
                    GuardMode::MeshArbiter => format!(
                        "// mesh arbitration: forwarded to {} peers",
                        (trimmed.len() % 3) + 1
                    ),
                    GuardMode::AutonomousSuggestor => format!(
                        "// auto-suggest: optimal path computed | confidence: {:.1}%",
                        70.0 + (trimmed.len() as f64 * 0.5).min(25.0)
                    ),
                };
                // Batch writes together
                let mut s = state.write();
                s.guard.log_guard(&format!("[execute] {}", trimmed));
                s.guard.log_guard(&response);
            }
        }
    };

    let onmode_passive = move |_| {
        state.write().guard.mode = GuardMode::PassiveObserver;
        state
            .write()
            .guard
            .log_guard("mode switched to PASSIVE OBSERVER");
    };
    let onmode_cocode = move |_| {
        state.write().guard.mode = GuardMode::CoCoder;
        state.write().guard.log_guard("mode switched to CO-CODER");
    };
    let onmode_mesh = move |_| {
        state.write().guard.mode = GuardMode::MeshArbiter;
        state
            .write()
            .guard
            .log_guard("mode switched to MESH ARBITER");
    };
    let onmode_auto = move |_| {
        state.write().guard.mode = GuardMode::AutonomousSuggestor;
        state
            .write()
            .guard
            .log_guard("mode switched to AUTONOMOUS SUGGESTOR");
    };

    let is_passive = guard_mode == GuardMode::PassiveObserver;
    let is_cocode = guard_mode == GuardMode::CoCoder;
    let is_mesh = guard_mode == GuardMode::MeshArbiter;
    let is_auto = guard_mode == GuardMode::AutonomousSuggestor;

    rsx! {
        div {
            class: "guard-overlay",
            id: "guard-overlay",

            // ─── Overlay Backdrop ──────────────────────────────────────
            div {
                class: "guard-backdrop",
                onclick: ondismiss,
            }

            // ─── Editor Panel ──────────────────────────────────────────
            div {
                class: "guard-panel",

                // ─── Top Bar ───────────────────────────────────────────
                div {
                    class: "guard-topbar",

                    div {
                        class: "guard-topbar-left",
                        span { class: "guard-topbar-title", "GUARD NODE" }
                        span { class: "guard-topbar-subtitle", "// alternate interface" }
                    }

                    div {
                        class: "guard-topbar-right",
                        button {
                            class: "guard-dismiss-btn",
                            onclick: ondismiss,
                            "✕"
                        }
                    }
                }

                // ─── Mode Selector ──────────────────────────────────────
                div {
                    class: "guard-mode-bar",
                    button {
                        class: "guard-mode-btn{is_passive.then_some(\" active\").unwrap_or(\"\")}",
                        onclick: onmode_passive,
                        "OBSERVE"
                    }
                    button {
                        class: "guard-mode-btn{is_cocode.then_some(\" active\").unwrap_or(\"\")}",
                        onclick: onmode_cocode,
                        "CO-CODE"
                    }
                    button {
                        class: "guard-mode-btn{is_mesh.then_some(\" active\").unwrap_or(\"\")}",
                        onclick: onmode_mesh,
                        "MESH"
                    }
                    button {
                        class: "guard-mode-btn{is_auto.then_some(\" active\").unwrap_or(\"\")}",
                        onclick: onmode_auto,
                        "AUTO"
                    }
                }

                // ─── Content Area ───────────────────────────────────────
                div {
                    class: "guard-body",

                    // ─── Editor ────────────────────────────────────────
                    div {
                        class: "guard-editor-pane",

                        div {
                            class: "guard-pane-header",
                            "EDITOR — {guard_mode.label()}"
                        }

                        textarea {
                            class: "guard-textarea",
                            value: editor_content,
                            oninput: oneditor,
                            onkeydown: onkeydown,
                            placeholder: "// buffer is empty\n// type to begin guard session...\n// Ctrl+Enter to execute",
                            spellcheck: false,
                            autofocus: true,
                        }

                        // ─── Execute button ───────────────────────────
                        div {
                            class: "guard-editor-actions",
                            button {
                                class: "guard-execute-btn",
                                onclick: onexecute,
                                "▶ EXECUTE"
                            }
                            span {
                                class: "guard-execute-hint",
                                "Ctrl+Enter"
                            }
                        }
                    }

                    // ─── Guard Agent Output ────────────────────────────
                    div {
                        class: "guard-output-pane",

                        div {
                            class: "guard-pane-header",
                            "GUARD AGENT"
                        }

                        div {
                            class: "guard-output-log",
                            for line in &guard_log {
                                div {
                                    class: "guard-output-line",
                                    "{line}"
                                }
                            }
                            if guard_log.is_empty() {
                                div {
                                    class: "guard-output-line guard-output-dim",
                                    "// waiting for guard session..."
                                }
                            }
                        }
                    }
                }

                // ─── Bottom Status ─────────────────────────────────────
                div {
                    class: "guard-statusbar",
                    span { "GUARD NODE v0.1.0 | " }
                    span { "mesh: offline | " }
                    span { "peers: 0 | " }
                    span { "mode: {guard_mode.label()}" }
                }
            }
        }
    }
}
