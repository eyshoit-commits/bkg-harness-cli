use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Hero section: false stillness → slow awakening → full rhythm.
/// 8 seconds of apparent frozen state, then minimal activity, then operational.
/// Trust field simulator with wave-based visual feedback.
#[component]
pub fn HeroModule(state: Signal<BkgKernel>) -> Element {
    let s = state.read();
    let elapsed = s.time.uptime_cycles;
    let is_awake = elapsed > 0;
    let cycle = s.time.consensus_cycle;

    // Simulated trust field wave (ASCII approximation)
    let wave = if is_awake {
        let pos = ((cycle % 20) as f64 / 20.0 * 40.0) as usize;
        let bar: String = (0..40).map(|i| if i == pos { '█' } else { '·' }).collect();
        bar
    } else {
        "········································".to_string()
    };

    rsx! {
        section {
            class: "hero-module era-modern",
            id: "hero",

            div { class: "hero-content",
                h1 { class: "hero-title",
                    if !is_awake {
                        "CODE IS NOT TRUTH.\nREPRODUCIBILITY IS."
                    } else if elapsed < 10 {
                        "CODE IS NOT TRUTH.\nREPRODUCIBILITY IS."
                    } else {
                        "CODE WAS NEVER TRUTH."
                    }
                }

                p { class: "hero-subtitle",
                    "BKG-WASM :: deterministic knowledge operating system"
                }
            }

            // ── Trust field simulator ──
            div { class: "trust-field-section",
                div { class: "trust-field-label", "TRUST FIELD // {wave}" }
            }
        }
    }
}
