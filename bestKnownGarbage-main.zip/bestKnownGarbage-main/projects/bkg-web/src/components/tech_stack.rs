use dioxus::prelude::*;

/// Tech Stack — boring list. No glamour.
#[component]
pub fn TechStack() -> Element {
    let techs = [
        "Rust",
        "Go",
        "WebAssembly",
        "Python",
        "Dioxus",
        "WASM Runtime",
        "Trust Engine",
        "Event Ledger",
        "MCP Protocol",
        "LSP Client",
    ];

    rsx! {
        section {
            class: "tech-stack",
            id: "tech-stack",

            div { class: "archive-label", "STACK // BUILD SYSTEM" }

            div { class: "tech-grid",
                for tech in techs {
                    div { class: "tech-item", "{tech}" }
                }
            }
        }
    }
}
