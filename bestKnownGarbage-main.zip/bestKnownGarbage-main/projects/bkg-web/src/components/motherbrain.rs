use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Motherbrain Core — ERA: Modern.
/// Clean. Institutional authority. The core architecture.
/// Contains half-migration artifacts and operator ghosts.
#[component]
pub fn MotherbrainCore(state: Signal<BkgKernel>) -> Element {
    let cycle = state.read().time.consensus_cycle;

    rsx! {
        section {
            class: "motherbrain-core era-modern",
            id: "motherbrain",

            div { class: "philosophy-banner",
                "BKG is NOT decentralized truth. "
                "BKG is verifiable centralized truth with distributed observation."
            }

            // ── Half-migration artifact (§3): temporary shim that became permanent ──
            div { class: "migration-artifact",
                "[scheduler] temporary validation shim active — uptime: 417d"
            }
            div { class: "migration-artifact",
                "[archive] PROTO-02 compatibility bridge enabled — 14,203 receipts affected"
            }

            div { class: "layers-stack",
                Layer { name: "Knowledge Layer", desc: "Causality Graph, Timeline Queries" }
                Layer { name: "Trust Layer", desc: "Trust Vector Engine, Hero Escalation" }
                Layer { name: "Validation Layer", desc: "Receipt Verification, Consensus" }
                Layer { name: "Execution Layer", desc: "WASM Sandbox, Deterministic Replay" }
                Layer { name: "Reality Layer", desc: "Env Fingerprinting, System Identity" }
            }

            // ── Human maintenance ghost (§5) ──
            div { class: "motherbrain-ghost",
                "// temporary fix for replay saturation — pending review"
            }
            div { class: "motherbrain-ghost",
                "// — operator: @x"
            }

            // ── Time accumulation (§6) ──
            div { class: "motherbrain-ghost",
                "consensus cycle {cycle} // uninterrupted operation: {cycle} cycles"
            }
        }
    }
}

#[component]
fn Layer(name: String, desc: String) -> Element {
    rsx! {
        div { class: "architecture-layer",
            div { class: "layer-name", "{name}" }
            div { class: "layer-desc", "{desc}" }
        }
    }
}
