use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Live Replay Demo — ERA: Proto02 (2010 operator console).
/// Functional, minimal, grey-on-dark. "Run deterministic replay" button.
/// Shows animated replay feedback: RUNNING → VERIFYING → REPRODUCED.
#[component]
pub fn LiveDemo(state: Signal<BkgKernel>) -> Element {
    let cycle = state.read().time.consensus_cycle;
    let hash = format!("0x{:X}...B91E", cycle % 0xFFFF);

    // Replay animation state: idle, running, verifying, done
    let mut replay_state = use_signal(|| "idle".to_string());

    let onclick = move |_| {
        // Clone handles first (before any write borrow)
        let mut state_clone = replay_state.clone();
        let mut kernel_clone = state.clone();
        // Start replay animation
        replay_state.set("running".to_string());
        state
            .write()
            .guard
            .log_guard("replay: execution started...");
        spawn(async move {
            // Phase 1: Running execution
            gloo_timers::future::sleep(std::time::Duration::from_millis(800)).await;
            state_clone.set("verifying".to_string());
            kernel_clone
                .write()
                .guard
                .log_guard("replay: verifying execution trace...");

            // Phase 2: Verifying
            gloo_timers::future::sleep(std::time::Duration::from_millis(1200)).await;
            state_clone.set("done".to_string());
            kernel_clone
                .write()
                .guard
                .log_guard("replay: execution reproduced — hash verified");

            // Phase 3: Reset
            gloo_timers::future::sleep(std::time::Duration::from_millis(2000)).await;
            state_clone.set("idle".to_string());
        });
    };

    let state_val = replay_state.read().clone();
    let status_text = match state_val.as_str() {
        "running" => "status: RUNNING",
        "verifying" => "status: VERIFYING",
        "done" => "status: REPRODUCED ✓",
        _ => "status: REPRODUCED ✓",
    };

    let trust_delta = match state_val.as_str() {
        "idle" => "+0.04",
        "running" => "+0.02",
        "verifying" => "+0.03",
        "done" => "+0.05 ✓",
        _ => "+0.04",
    };

    let btn_disabled = state_val == "running" || state_val == "verifying";
    let btn_class = format!(
        "demo-replay-btn{}",
        if btn_disabled {
            " demo-replay-btn-disabled"
        } else {
            ""
        }
    );

    let anim_class = match state_val.as_str() {
        "running" => "demo-anim-running",
        "verifying" => "demo-anim-verifying",
        "done" => "demo-anim-done",
        _ => "",
    };

    rsx! {
        section {
            class: "live-demo era-proto02 {anim_class}",
            id: "live-demo",

            div { class: "demo-header", "FIELD REPORT // LIVE REPLAY" }

            div { class: "demo-execution",
                pre {
                    "execution hash: {hash}\n"
                    "environment: linux-6.8.0-arch // rustc-1.84.0\n"
                    "{status_text}\n"
                    "trust delta: {trust_delta}"
                }
            }

            button {
                class: "{btn_class}",
                disabled: btn_disabled,
                onclick: onclick,
                if btn_disabled { "Replaying..." } else { "Run deterministic replay" }
            }
        }
    }
}
