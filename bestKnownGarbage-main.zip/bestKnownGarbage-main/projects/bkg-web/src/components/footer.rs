use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Footer — Terminal prompt style. Lore drop: "Best Known Garbage".
/// AUTHORIZED OBSERVERS with PGP fingerprints.
/// No team. No about. No founders.
/// Compliance sediment, time accumulation, continuity score.
#[component]
pub fn FooterTerminal(state: Signal<BkgKernel>) -> Element {
    let uptime = state.read().time.uptime_cycles;
    let ledger = state.read().time.ledger_height;

    rsx! {
        footer {
            class: "footer-terminal era-proto01",
            id: "footer",

            div { class: "footer-lore-drop",
                pre {
                    "\n"
                    "BKG\n"
                    "Best Known Garbage\n"
                    "\n"
                    "Evolution does not preserve perfection.\n"
                    "Only what survives.\n"
                    "\n"
                }
            }

            div { class: "footer-operators",
                "AUTHORIZED OBSERVERS\n"
                "@ghost    0x7F3A...B91E    eu-west-01\n"
                "@x        0x9C2E...D44F    us-east-02\n"
                "@sys      0xE541...A83B    lab-node-17"
            }

            // ── Time accumulation (§6) ──
            div { class: "footer-continuity",
                "continuity score: 0.987 // uninterrupted operation: {uptime} cycles"
            }
            div { class: "footer-continuity",
                "ledger height: {ledger} // oldest active receipt: 1827d"
            }

            // ── Non-human time (§6) ──
            div { class: "footer-continuity",
                "observer uptime: 203d 7h 32m // revalidation running for 17h 14m"
            }

            // ── Compliance/legal sediment (§12.5.6) ──
            div { class: "footer-legal",
                "NOTICE: observer telemetry retained for continuity verification\n"
                "retention window may exceed regional archival guidelines\n"
                "audit interface unavailable in public node mode\n"
                "\n"
                "observer variance policy v1.4 applies\n"
                "policy deprecated since 2025\n"
                "\n"
                "MIT License · GitHub"
            }

            // ── Deprecated hotkey (§13) ──
            div { class: "footer-legal",
                "[C+Q] quick-archive (deprecated — use [C+W])"
            }
        }
    }
}
