use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Receipt Anatomy — Raw terminal output.
/// Shows a real execution receipt. Some fields redacted.
/// Ghost comments from previous operators throughout.
#[component]
pub fn ReceiptAnatomy(state: Signal<BkgKernel>) -> Element {
    let cycle = state.read().time.consensus_cycle;
    let hash = format!("0x{:X}...B91E", cycle % 0xFFFF);

    rsx! {
        section {
            class: "receipt-anatomy era-proto01",
            id: "receipts",

            pre { class: "receipt-json",
                "{{\n"
                "  \"execution_hash\": \"{hash}\",\n"
                "  \"environment\": {{\n"
                "    \"os\": \"linux-6.8.0-arch\",\n"
                "    \"compiler\": \"rustc-1.84.0\",\n"
                "    \"deps_merkle\": \"0x9C2E...D44F\"\n"
                "  }},\n"
                "  \"sandbox\": {{\n"
                "    \"rng_seed\": \"0xDEADBEEF\",\n"
                "    \"fuel_used\": 1423,\n"
                "    \"syscalls\": [\"open\", \"read\", \"write\"]\n"
                "  }},\n"
                "  \"verification\": \"REPRODUCED\",\n"
                "  \"trace\": \"INTENTIONALLY WITHHELD\"\n"
                "}}"
            }

            // ── Human maintenance ghosts (§5) ──
            div { class: "receipt-ghost",
                "// operator: @ghost — reason unknown"
            }
            div { class: "receipt-ghost",
                "// legacy receipt parser retained for compatibility"
            }
            div { class: "receipt-ghost",
                "// parser version: 0.7.2 (deprecated)"
            }

            // ── Time accumulation (§6) ──
            div { class: "receipt-ghost",
                "// PROTO-01 archival window exceeded by 944d"
            }
            div { class: "receipt-ghost",
                "// legacy variance records imported: 14,033 records (2024-01-17 → 2026-05-22)"
            }
        }
    }
}
