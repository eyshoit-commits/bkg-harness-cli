use crate::kernel::BkgKernel;
use dioxus::prelude::*;

/// Always-visible terminal stream overlay.
/// This is NOT a UI element — it is physical background reality.
/// No colors, no emphasis, no importance sorting.
/// Includes a hidden key-catcher for guard node easter egg command.
#[component]
pub fn GlobalLogOverlay(state: Signal<BkgKernel>) -> Element {
    let logs: Vec<String> = state
        .read()
        .logs
        .iter()
        .rev()
        .take(30)
        .map(|log| log.display())
        .collect();

    // Hidden input for guard node keypress detection (uses onkeydown for reliability)
    let onkeydown = move |evt: KeyboardEvent| {
        let key_str = evt.key().to_string();
        if key_str == "Enter" {
            let mut kernel = state.write();
            let triggered = kernel.guard.feed_key('\n');
            if triggered && !kernel.guard.unlocked {
                kernel.unlock_guard();
            }
        } else if key_str.len() == 1 {
            let c = key_str.chars().next().unwrap();
            let mut kernel = state.write();
            let triggered = kernel.guard.feed_key(c);
            if triggered && !kernel.guard.unlocked {
                kernel.unlock_guard();
            }
        }
    };

    rsx! {
        div {
            class: "log-overlay",

            // Hidden key-catcher (invisible but focused)
            input {
                class: "guard-key-catcher",
                onkeydown: onkeydown,
                autofocus: true,
            }

            for log in logs {
                div { class: "log-line", "{log}" }
            }
        }
    }
}
