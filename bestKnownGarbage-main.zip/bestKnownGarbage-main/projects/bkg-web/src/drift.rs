use crate::era::Era;

// ─── Semantic Drift Engine ─────────────────────────────────────────────────
//
// Different operational eras use different terminology for the same concepts.
// This engine resolves terms based on which era's panel is rendering them.
// No unification. No normalization. The system does not reconcile its own history.
//
// Uses flat arrays instead of HashMap to avoid pulling in hashing infrastructure
// into the WASM binary — saves ~15-20KB.

const PROTO01: &[(&str, &str)] = &[
    ("trust", "quorum stress"),
    ("verify", "hash check"),
    ("observer", "witness node"),
    ("consensus", "node agreement"),
    ("replay", "trace rerun"),
    ("receipt", "execution record"),
    ("drift", "clock skew"),
    ("failure", "syscall abort"),
    ("divergence", "hash mismatch"),
    ("climate", "load average"),
    ("pressure", "queue depth"),
    ("stability", "uptime ratio"),
];

const PROTO02: &[(&str, &str)] = &[
    ("trust", "trust contamination"),
    ("verify", "cross-validate"),
    ("observer", "collector node"),
    ("consensus", "consensus instability"),
    ("replay", "deterministic replay"),
    ("receipt", "execution receipt"),
    ("drift", "environment divergence"),
    ("failure", "validation error"),
    ("divergence", "state mismatch"),
    ("climate", "trust atmosphere"),
    ("pressure", "consensus pressure"),
    ("stability", "system stability index"),
];

const MODERN: &[(&str, &str)] = &[
    ("trust", "epistemic climate"),
    ("verify", "truth verification"),
    ("observer", "epistemic observer"),
    ("consensus", "truth convergence"),
    ("replay", "reproducible execution"),
    ("receipt", "reality receipt"),
    ("drift", "temporal divergence"),
    ("failure", "truth invalidation"),
    ("divergence", "reality mismatch"),
    ("climate", "epistemic climate"),
    ("pressure", "consensus pressure gradient"),
    ("stability", "epistemic stability"),
];

/// Resolve a term according to the given era's vocabulary.
/// Falls back to the raw term if no mapping exists.
pub fn resolve_term<'a>(term: &'a str, era: &Era) -> &'a str {
    let map = match era {
        Era::Proto01 => PROTO01,
        Era::Proto02 => PROTO02,
        Era::Modern => MODERN,
        Era::Dead => return term,
    };
    for &(k, v) in map {
        if k == term {
            return v;
        }
    }
    term
}
