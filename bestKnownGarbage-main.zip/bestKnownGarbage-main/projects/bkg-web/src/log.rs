use crate::era::Era;
use crate::kernel::{BkgKernel, LogEvent, LogSeverity, LogSource};
use crate::rng::rng;

// ─── Log Stream Engine ──────────────────────────────────────────────────────
//
// This is the "system is alive" effect.
// Generates a continuous stream of log events with 92/7/1 ratio:
//  - 92% banal: routine operational messages
//  -  7% interesting: notable but not alarming
//  -  1% disturbing: rare, unsettling, unexplained
//
// ALL categories rendered identically — no colors, no emphasis.
// The system does not signal importance through tone.

/// Generate a single log event based on current kernel state.
pub fn generate_event(kernel: &BkgKernel) -> LogEvent {
    let cycle = kernel.time.consensus_cycle;
    let roll = cycle % 100;

    if roll < 92 {
        banal_event(kernel)
    } else if roll < 99 {
        interesting_event(kernel)
    } else {
        disturbing_event()
    }
}

/// Poisson-like interval in milliseconds (500-2000ms, clustered around 800-1200ms).
pub fn next_interval() -> u64 {
    let base: f64 = rng().next_f32() as f64;
    let ms: f64 = 500.0 + (-((1.0 as f64) - base).ln() * 400.0);
    (ms.min(2000.0).max(300.0)) as u64
}

// ─── Helper — pick a random source for variety ──────────────────────────────

fn any_source() -> LogSource {
    match rng().next_usize(11) {
        0 => LogSource::Collector,
        1 => LogSource::Motherbrain,
        2 => LogSource::Observer,
        3 => LogSource::TrustEngine,
        4 => LogSource::Scheduler,
        5 => LogSource::Archive,
        6 => LogSource::System,
        7 => LogSource::Core,
        8 => LogSource::Maintenance,
        9 => LogSource::Timeline,
        _ => LogSource::Unknown,
    }
}

// ─── Banal Events (92%) ────────────────────────────────────────────────────
// The vast majority of system output. Boring. Routine.
// This is the baseline reality of the system.

fn banal_event(kernel: &BkgKernel) -> LogEvent {
    let cycle = kernel.time.consensus_cycle;
    let roll = cycle % 32;

    match roll {
        // ── Standard operational (heart of the 92%) ──
        0 => LogEvent::new(
            LogSource::Collector,
            "receipt archived",
            LogSeverity::Info,
            Era::Proto01,
        ),
        1 => LogEvent::new(
            LogSource::Observer,
            "heartbeat acknowledged",
            LogSeverity::Info,
            Era::Modern,
        ),
        2 => LogEvent::new(
            LogSource::Scheduler,
            "queue depth nominal",
            LogSeverity::Debug,
            Era::Proto02,
        ),
        3 => LogEvent::new(
            LogSource::Maintenance,
            "replay cache compacted",
            LogSeverity::Debug,
            Era::Proto01,
        ),
        4 => LogEvent::new(
            LogSource::Archive,
            "retention sweep complete",
            LogSeverity::Info,
            Era::Proto02,
        ),
        5 => LogEvent::new(
            LogSource::Observer,
            "observer-11 idle",
            LogSeverity::Debug,
            Era::Proto01,
        ),
        6 => LogEvent::new(
            LogSource::Core,
            "scheduled audit passed",
            LogSeverity::Info,
            Era::Modern,
        ),
        7 => LogEvent::new(
            LogSource::System,
            "backfill complete",
            LogSeverity::Info,
            Era::Proto01,
        ),
        8 => LogEvent::new(
            LogSource::TrustEngine,
            "variance within expected range",
            LogSeverity::Info,
            Era::Proto02,
        ),
        9 => LogEvent::new(
            LogSource::Collector,
            "collector-eu-03 receipt archived",
            LogSeverity::Info,
            Era::Modern,
        ),
        10 => LogEvent::new(
            LogSource::Observer,
            "observer-04 idle",
            LogSeverity::Debug,
            Era::Proto01,
        ),
        11 => LogEvent::new(
            LogSource::TrustEngine,
            "trust baseline stable",
            LogSeverity::Info,
            Era::Proto02,
        ),
        12 => LogEvent::new(
            LogSource::System,
            "cycle complete — awaiting dispatch",
            LogSeverity::Debug,
            Era::Modern,
        ),
        13 => LogEvent::new(
            LogSource::Archive,
            "retention window: nominal",
            LogSeverity::Info,
            Era::Proto01,
        ),

        // ── Half-migration artifacts (§3) ──
        14 => LogEvent::new(
            LogSource::System,
            "legacy trust adapter active (PROTO-01 compatibility bridge)",
            LogSeverity::Info,
            Era::Proto01,
        ),
        15 => LogEvent::new(
            LogSource::Archive,
            "PROTO-02 compatibility bridge enabled — 14,203 receipts affected",
            LogSeverity::Info,
            Era::Proto02,
        ),

        // ── Temporary fixes that became permanent (§3, §13) ──
        16 => LogEvent::new(
            LogSource::Scheduler,
            "temporary validation shim active — uptime: 417d",
            LogSeverity::Info,
            Era::Proto01,
        ),
        17 => LogEvent::new(
            LogSource::Core,
            "fallback observer codec loaded // reason unknown",
            LogSeverity::Info,
            Era::Dead,
        ),

        // ── Deprecation warnings in the stream (§3) ──
        18 => LogEvent::new(
            LogSource::Observer,
            "warning: using deprecated quorum semantics — migrate to consensus pressure",
            LogSeverity::Debug,
            Era::Proto01,
        ),
        19 => LogEvent::new(
            LogSource::Core,
            "migration rollback support loaded — PROTO-01 → PROTO-02 transition",
            LogSeverity::Info,
            Era::Proto02,
        ),

        // ── Maintenance windows (§12.5.7) ──
        20 => LogEvent::new(
            LogSource::Maintenance,
            "scheduled replay maintenance window active",
            LogSeverity::Info,
            Era::Proto02,
        ),
        21 => LogEvent::new(
            LogSource::Maintenance,
            "observer synchronization degraded during archive compaction",
            LogSeverity::Info,
            Era::Proto01,
        ),

        // ── Compliance/legal sediment (§12.5.6) ──
        22 => LogEvent::new(
            LogSource::System,
            "external witness exports disabled pending review",
            LogSeverity::Info,
            Era::Modern,
        ),

        // ── Naming contradictions in logs (§12.5.4) ──
        23 => LogEvent::new(
            LogSource::TrustEngine,
            "TRUST INDEX: baseline stable",
            LogSeverity::Info,
            Era::Proto02,
        ),
        24 => LogEvent::new(
            LogSource::Motherbrain,
            "truth vector: nominal",
            LogSeverity::Info,
            Era::Modern,
        ),

        // ── Dead observer regions still referenced (§13) ──
        25 => LogEvent::new(
            LogSource::Observer,
            "observer-12 queue: TEMPORARILY DISABLED — last active: 2024-09-03",
            LogSeverity::Info,
            Era::Proto01,
        ),

        // ── Old export formats no one uses (§12.5.8) ──
        26 => LogEvent::new(
            LogSource::Archive,
            "LEGACY EXPORT FORMATS: .rv1, .rv2, .rv2b all available",
            LogSeverity::Debug,
            Era::Dead,
        ),

        // ── Time accumulation artifacts (§6) ──
        27 => LogEvent::new(
            LogSource::Archive,
            "oldest active receipt: 1827d",
            LogSeverity::Info,
            Era::Proto01,
        ),
        28 => LogEvent::new(
            LogSource::Archive,
            "PROTO-01 archival window exceeded by 944d",
            LogSeverity::Debug,
            Era::Proto01,
        ),
        29 => LogEvent::new(
            LogSource::System,
            "continuity score: 0.987",
            LogSeverity::Info,
            Era::Modern,
        ),
        30 => LogEvent::new(
            LogSource::Timeline,
            "observer cluster migrated across 4 protocol generations",
            LogSeverity::Info,
            Era::Modern,
        ),

        // ── Observers with contradictory IDs (§12.5.5) ──
        _ => LogEvent::new(
            any_source(),
            "observer_id: eu-west-03 // OBSERVER-ID: eu_west_legacy_03 unresolved",
            LogSeverity::Debug,
            Era::Proto01,
        ),
    }
}

// ─── Interesting Events (7%) ────────────────────────────────────────────────
// Notable enough to register. Not alarming.
// The system handles these and moves on.

fn interesting_event(_kernel: &BkgKernel) -> LogEvent {
    let roll = rng().next_usize(14);

    match roll {
        0 => LogEvent::new(
            LogSource::TrustEngine,
            "consensus pressure rising — auto-correcting",
            LogSeverity::Info,
            Era::Modern,
        ),
        1 => LogEvent::new(
            LogSource::Motherbrain,
            "observer desync resolved\nbackfill complete",
            LogSeverity::Info,
            Era::Proto02,
        ),
        2 => LogEvent::new(
            LogSource::TrustEngine,
            "trust drift detected — automatic correction applied",
            LogSeverity::Warn,
            Era::Proto02,
        ),
        3 => LogEvent::new(
            LogSource::Collector,
            "variance outside expected range — revalidating",
            LogSeverity::Warn,
            Era::Proto01,
        ),
        4 => LogEvent::new(
            LogSource::Motherbrain,
            "consensus drift normalized",
            LogSeverity::Info,
            Era::Modern,
        ),
        5 => LogEvent::new(
            LogSource::TrustEngine,
            "climate shifting — recovery window 12-18min",
            LogSeverity::Info,
            Era::Modern,
        ),
        6 => LogEvent::new(
            LogSource::Observer,
            "observer-07 resync required — auto-scheduled",
            LogSeverity::Warn,
            Era::Proto02,
        ),
        7 => LogEvent::new(
            LogSource::System,
            "migration progress: 73% — within expected latency",
            LogSeverity::Info,
            Era::Proto01,
        ),
        8 => LogEvent::new(
            LogSource::Observer,
            "desync resolved",
            LogSeverity::Info,
            Era::Proto02,
        ),
        9 => LogEvent::new(
            LogSource::Archive,
            "historical replay backlog cleared after 71d",
            LogSeverity::Info,
            Era::Proto02,
        ),
        10 => LogEvent::new(
            LogSource::Maintenance,
            "observer-03 variance outside expected range — compensated",
            LogSeverity::Info,
            Era::Proto02,
        ),
        11 => LogEvent::new(
            LogSource::Collector,
            "collector-07 hash mismatch — auto-retry scheduled",
            LogSeverity::Warn,
            Era::Proto01,
        ),
        12 => LogEvent::new(
            LogSource::System,
            "validation semantics updated in PROTO-02 // see migration memo #442",
            LogSeverity::Info,
            Era::Dead,
        ),
        _ => LogEvent::new(
            LogSource::Motherbrain,
            "epistemic climate: shifting — no action required",
            LogSeverity::Info,
            Era::Modern,
        ),
    }
}

// ─── Disturbing Events (1%) ─────────────────────────────────────────────────
// Rare. Unsettling. Never explained.
// Identical rendering to banal events — the 1% works because of the 92%.

fn disturbing_event() -> LogEvent {
    let roll = rng().next_usize(10);

    match roll {
        0 => LogEvent::new(
            LogSource::Timeline,
            "14 previously accepted truths invalidated retroactively",
            LogSeverity::Warn,
            Era::Modern,
        ),
        1 => LogEvent::new(
            LogSource::Motherbrain,
            "historical contradiction preserved — no resolution path",
            LogSeverity::Warn,
            Era::Proto02,
        ),
        2 => LogEvent::new(
            LogSource::TrustEngine,
            "consensus reached without human intervention",
            LogSeverity::Info,
            Era::Modern,
        ),
        3 => LogEvent::new(
            LogSource::Archive,
            "receipt unavailable — archive corruption detected // recovery: impossible",
            LogSeverity::Error,
            Era::Proto01,
        ),
        4 => LogEvent::new(
            LogSource::Observer,
            "unauthorized variance archived — source unknown",
            LogSeverity::Warn,
            Era::Proto02,
        ),
        5 => LogEvent::new(
            LogSource::System,
            "[DATA EXPUNGED]",
            LogSeverity::Warn,
            Era::Dead,
        ),
        6 => LogEvent::new(
            LogSource::Observer,
            "observer-06 transcript incomplete — 14s missing — gap unexplained",
            LogSeverity::Warn,
            Era::Proto01,
        ),
        7 => LogEvent::new(
            LogSource::Timeline,
            "epoch boundary: 14 previously accepted truths invalidated",
            LogSeverity::Warn,
            Era::Modern,
        ),
        8 => LogEvent::new(
            LogSource::System,
            "consensus reached on receipt without matching execution record",
            LogSeverity::Error,
            Era::Proto02,
        ),
        _ => LogEvent::new(
            LogSource::Unknown,
            "// operator: @ghost — no known operator with this handle",
            LogSeverity::Warn,
            Era::Dead,
        ),
    }
}
