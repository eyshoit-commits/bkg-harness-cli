pub mod components;
pub mod drift;
pub mod era;
pub mod kernel;
pub mod log;
pub mod rng;

use components::*;
use dioxus::prelude::*;
use kernel::BkgKernel;
use std::time::Duration;

/// BKG-WASM Alpha — Infrastructure Mythography Runtime
#[allow(non_snake_case)]
fn App() -> Element {
    let mut kernel = use_signal(|| BkgKernel::new());

    // ─── Global Runtime Loop ──────────────────────────────────────────────
    //
    // 1. 8 seconds of false stillness
    // 2. Slow awakening over ~28 seconds
    // 3. Full operational rhythm (Poisson-distributed, continuous)
    use_effect(move || {
        spawn(async move {
            // Phase 1: False Stillness
            gloo_timers::future::sleep(Duration::from_secs(8)).await;

            // Phase 2: Slow Awakening
            for i in 0..5 {
                gloo_timers::future::sleep(Duration::from_millis(1500 + i * 500)).await;
                kernel.write().tick();
            }

            // Phase 3: Full Operational Rhythm
            loop {
                let interval_ms = log::next_interval();
                gloo_timers::future::sleep(Duration::from_millis(interval_ms)).await;
                kernel.write().tick();
            }
        });
    });

    // ─── Scheduled maintenance state indicator ─────────────────────────────
    let maint_active = (kernel.read().time.consensus_cycle / 500) % 3 == 0;

    rsx! {
        GlobalLogOverlay { state: kernel }
        GuardNodeOverlay { state: kernel }

        // ── Compliance/legal notice bar (§12.5.6) ──
        div { class: "compliance-notice",
            "NOTICE: observer telemetry retained for continuity verification · "
            "audit interface unavailable in public node mode · "
            "external witness exports disabled pending review"
        }

        // ── Non-dramatic maintenance indicator (§12.5.7) ──
        if maint_active {
            div { class: "maintenance-indicator",
                "scheduled replay maintenance window active"
            }
        }

        div { class: "bkg-content",

            // 1. HERO
            HeroModule { state: kernel }

            // 2. WHY NOW
            WhyNowPanel { state: kernel }

            // 3. THE PROBLEM
            ProblemPanel { state: kernel }

            // 4. THE SHIFT
            ShiftMonolith { state: kernel }

            // 5. SILENCE ZONE — Operational Void (First)
            SilenceZone { id: "silence-1" }

            // 6. DETERMINISTIC SOLUTION
            DeterministicSolution { state: kernel }

            // 7. CONSENSUS REPLAY — ~2004 console
            ConsensusReplay { state: kernel }

            // 8. DEAD PROTOCOL LAYER — ~1990s ncurses
            DeadProtocolLayer { state: kernel }

            // 9. LIVE REPLAY DEMO — ~2010 operator console
            LiveDemo { state: kernel }

            // 10. ARCHIVE HEALTH — absurdly sparse
            ArchiveHealth { state: kernel }

            // 11. MOTHERBRAIN ARCHITECTURE
            MotherbrainCore { state: kernel }

            // 12. SILENCE ZONE — Transitional Void (Second)
            SilenceZone { id: "silence-2" }

            // 13. TRUST VECTOR + EPISTEMIC METEOROLOGY
            TrustWeather { state: kernel }

            // 14. TEMPORAL KNOWLEDGE TIMELINE
            TimelineEngine { state: kernel }

            // 15. RECEIPT ANATOMY
            ReceiptAnatomy { state: kernel }

            // 16. KNOWLEDGE DECAY LIFECYCLE
            DecayLifecycle { state: kernel }

            // 17. TECH STACK
            TechStack {}

            // 18. ROADMAP
            Roadmap {}

            // 19. SILENCE ZONE — Final Void (Third)
            SilenceZone { id: "silence-3" }

            // 20. GETTING STARTED + FOOTER
            GettingStarted {}
        }

        FooterTerminal { state: kernel }
    }
}

/// Entry point for WASM target (called by wasm-pack generated JS)
#[wasm_bindgen::prelude::wasm_bindgen(start)]
pub fn run() {
    dioxus::launch(App);
}
