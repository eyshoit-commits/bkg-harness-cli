// ─── Era System ─────────────────────────────────────────────────────────────
//
// Each component gets its own historical reality.
// No global theme. No unification. Each node lives in its own epoch.

#[derive(Clone, Debug, PartialEq)]
pub enum Era {
    Proto01, // 2004 ASCII console — brutal, monospace, hard borders
    Proto02, // 2013 dashboard proto-UI — slightly civilized, still raw
    Modern,  // 2026 canvas UI — clean, minimal, isolated
    Dead,    // 1990s ncurses — faded, broken terminal aesthetic
}

impl Era {
    pub fn label(&self) -> &'static str {
        match self {
            Era::Proto01 => "PROTO-01",
            Era::Proto02 => "PROTO-02",
            Era::Modern => "MODERN",
            Era::Dead => "DEAD",
        }
    }

    /// Returns a CSS class suffix for era-specific styling.
    /// Each era gets its own visual treatment via CSS.
    pub fn css_class(&self) -> &'static str {
        match self {
            Era::Proto01 => "era-proto01",
            Era::Proto02 => "era-proto02",
            Era::Modern => "era-modern",
            Era::Dead => "era-dead",
        }
    }
}

// ─── Era Engine ─────────────────────────────────────────────────────────────

/// Resolves which UI epoch a component belongs to.
/// No central design system — each component is historically isolated.
pub fn resolve_era(component: &str) -> Era {
    match component {
        "ConsensusReplay" => Era::Proto01,
        "DeadProtocolLayer" => Era::Dead,
        "LiveDemo" => Era::Proto02,
        "TrustWeather" => Era::Proto02,
        "TimelineEngine" => Era::Proto02,
        "ArchiveHealth" => Era::Dead,
        "ReceiptAnatomy" => Era::Proto01,
        "MotherbrainCore" => Era::Modern,
        "HeroModule" => Era::Modern,
        "ProblemPanel" => Era::Modern,
        "ShiftMonolith" => Era::Modern,
        "WhyNowPanel" => Era::Modern,
        "DeterministicSolution" => Era::Proto02,
        "DecayLifecycle" => Era::Proto02,
        "FooterTerminal" => Era::Proto01,
        _ => Era::Proto02, // default fallback
    }
}
