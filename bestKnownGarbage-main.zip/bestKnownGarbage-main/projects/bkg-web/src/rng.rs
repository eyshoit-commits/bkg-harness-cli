// Simple Linear Congruential Generator (LCG) for non-cryptographic random numbers
// Replaces rand = "0.8" dependency to reduce WASM size
// Parameters from Numerical Recipes
const LCG_A: u64 = 1664525;
const LCG_C: u64 = 1013904223;
const LCG_M: u64 = 0xFFFFFFFF_FFFFFFFF; // 2^64 - 1

use std::sync::{Mutex, OnceLock};

static GLOBAL_RNG: OnceLock<Mutex<SimpleRng>> = OnceLock::new();

#[derive(Clone, Copy, Default)]
pub struct SimpleRng {
    state: u64,
}

impl SimpleRng {
    pub fn new(seed: u64) -> Self {
        Self { state: seed }
    }

    /// Generate next u64 in sequence
    pub fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_mul(LCG_A).wrapping_add(LCG_C);
        self.state
    }

    /// Generate f32 in [0, 1)
    pub fn next_f32(&mut self) -> f32 {
        // Convert to [0, 1) float
        ((self.next_u64() as f64) * (1.0 / (LCG_M as f64 + 1.0))) as f32
    }

    /// Generate usize in [0, bound)
    pub fn next_usize(&mut self, bound: usize) -> usize {
        if bound == 0 {
            return 0;
        }
        // Use rejection modulo to avoid bias
        let threshold = (!0usize).wrapping_sub((!0usize).wrapping_rem(bound));
        loop {
            let val = self.next_u64() as usize;
            if val < threshold {
                return val % bound;
            }
        }
    }

    /// Generate bool with probability p (0.0 to 1.0)
    pub fn next_bool(&mut self, p: f32) -> bool {
        self.next_f32() < p
    }
}

// Global RNG instance seeded from system time
/// Initialize the global RNG with a seed
pub fn init_rng(seed: u64) {
    let _ = GLOBAL_RNG.set(Mutex::new(SimpleRng::new(seed)));
}

/// Get a reference to the global RNG, initializing with default seed if needed
pub fn rng() -> impl std::ops::DerefMut<Target = SimpleRng> {
    let rng = GLOBAL_RNG.get_or_init(|| {
        // Seed with some fixed value for determinism in demo
        Mutex::new(SimpleRng::new(0xDEADBEEF_CAFE_BABE))
    });
    rng.lock().unwrap()
}

// Helper functions for common distributions
pub fn gen_range<T: RngRange>(low: T, high: T) -> T {
    low.gen_range(high)
}

pub trait RngRange {
    fn gen_range(self, high: Self) -> Self;
}

impl RngRange for f32 {
    fn gen_range(self, high: Self) -> Self {
        let range = high - self;
        self + (rng().next_f32() * range)
    }
}

impl RngRange for i32 {
    fn gen_range(self, high: Self) -> Self {
        let range = high - self;
        self + (rng().next_usize(range as usize) as i32)
    }
}

impl RngRange for usize {
    fn gen_range(self, high: Self) -> Self {
        self + rng().next_usize(high - self)
    }
}
