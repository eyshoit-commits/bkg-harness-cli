# bkg-web — PROGRESS

> **Milestones tracked in:** `../../tasks/task-web-wasm.md` (W001–W012)

## Phase 3: Web-WASM (W001–W012)
- [ ] W001 — wasm-bindgen bindings
- [ ] W002–W003 — Virtual FS + IndexedDB
- [ ] W004–W008 — Dioxus landing page
- [ ] W009–W010 — Web demo
- [ ] W011–W012 — wasm-opt release build

## Status
- **Task file:** `../../tasks/task-web-wasm.md`
- **Task ref:** W001–W012
- **Progress:** 0 / 12 steps
