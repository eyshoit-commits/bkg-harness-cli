//! BKG web-socket — stub crate
