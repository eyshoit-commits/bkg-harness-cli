//! BKG web-client — stub crate
