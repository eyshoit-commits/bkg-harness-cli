//! BKG ui-state — stub crate
