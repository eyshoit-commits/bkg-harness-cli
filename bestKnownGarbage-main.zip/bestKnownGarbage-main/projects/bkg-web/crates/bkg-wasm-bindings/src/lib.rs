//! BKG wasm-bindings — stub crate
