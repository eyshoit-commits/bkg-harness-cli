# bkg-web — TRUTH

> **Project-local truths.** Cross-reference with `../../truth.md` for global truths.

## Identity
- **Package:** `bkg-wasm-alpha` (Cargo.toml, edition 2021)
- **Directory:** `projects/bkg-web/`
- **Purpose:** Web WASM — Dioxus landing page, wasm-bindgen, demo

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | Dioxus app entry |
| `src/lib.rs` | wasm-bindgen bindings |
| `src/pages/` | Dioxus page components |
| `src/components/` | Shared UI components |
| `src/vfs.rs` | Virtual file system |
| `src/storage.rs` | IndexedDB persistence |
| `index.html` | Static landing page |
| `netlify.toml` | Netlify deployment config |

## Depends On
- `bkg-wasm-bindings` (crate, optional dep)
- `bkg-vfs` (crate, optional dep)
- Standalone wasm32-unknown-unknown target
