# BKG-WASM — Infrastructure Mythography v7

**Date:** 2026-05-22
**Status:** Production-Ready — Implemented at `/workspaces/alpha/`
**Build:** `wasm-pack build --target web` — 0 errors, 0 warnings
**Serve:** `python3 -m http.server 8080` from `/workspaces/alpha/`
**Identity:** A publicly accessible node of a system never designed for public access. Expanded across so many operational eras that its own history has become visible in its interfaces. Accidental legitimacy.

---

## 0. THE FINAL EVOLUTION

### The Arc

```
v1-v5: A mysterious infrastructure
v6:    An old infrastructure
v7:    An infrastructure that survived multiple eras
```

### The Category

The page is no longer navigated through design.

It is navigated through:
> **Sedimented operational history.**

### The Core Principle

Real decades-old infrastructure is NOT perfectly coherent.

It contains:
- Different terminology from different eras
- Multiple UI paradigms coexisting
- Historical naming conflicts
- Old color semantics
- Half-migrated panels
- Contradictory documentation
- **Operational sediment**

BKG has been too philosophically coherent.
Real infrastructure doesn't emerge from a manifesto. It emerges from:
- Survival pressure
- Migrations
- Team changes
- Legacy constraints
- Improvised patches
- Historical layers

### What v7 Must Achieve

Not chaos. Not bad UX.

**Visible historical stratification.**

The page should feel like:
> computational archaeology.

---

## 0.1 The New Highest Compliment (Updated)

| Version | Highest Compliment |
|---------|-------------------|
| v5 | "Is this real?" |
| v6 | "Why does this feel old?" |
| **v7** | **"I can see the different eras it went through."** |

---

## 1. TERMINOLOGY DRIFT

### Current Problem

The system uses too-consistent terminology across all surfaces.
Real systems don't.

### Solution: Three Eras of Language

Different parts of the page use vocabulary from different operational eras:

| Era | Style | Examples | Where Visible |
|-----|-------|----------|--------------|
| **Early (PROTO-01)** | Technical-direct | `hash mismatch`, `clock drift`, `observer timeout`, `quorum stress` | Archived panels, dead protocol layers, legacy observer groups |
| **Mid (PROTO-02)** | Proto-philosophical | `trust contamination`, `consensus instability`, `environment divergence`, `validation load` | Some metrics, older active panels |
| **Modern (current)** | Epistemic vocabulary | `epistemic climate`, `truth visibility`, `consensus pressure`, `historical contradiction` | New panels, active metrics |

### Implementation

- All three terminologies exist simultaneously on the page
- They are NOT reconciled. No attempt to unify them.
- A visitor reading left to right may encounter `quorum stress` in an archived panel and `consensus pressure` in the live trust display
- No tooltip explaining they mean similar things
- The system does not care about consistency across eras

---

## 2. MULTIPLE UI GENERATIONS

### Current Problem

Every component uses the same visual language.
Real infrastructure accumulates interface paradigms over decades.

### Solution: Deliberate UI Era Mixing

| Component | Era Aesthetic | Details |
|-----------|--------------|---------|
| **Consensus Replay** | ~2004 cluster console | Bitmap-ish spacing, hard borders, ASCII progress bars, terminal-green-on-black, no border-radius |
| **Trust Weather** | ~2013 scientific dashboard | Cleaner typography, slight modernisation, restrained color use, still functional |
| **Knowledge Timeline** | Half-migrated internal tooling | Inconsistent spacing rules, mix of old and new visual language |
| **Dead Protocol Layer** | ~1990s ncurses | Faux-terminal, blocky, character-cell alignment, no anti-aliasing feel |
| **Live Replay Demo** | ~2010 operator console | Functional, minimal styling, grey-on-dark, no gradient |
| **Receipt Anatomy** | Raw terminal output | Plain monospace, no syntax highlighting, cursor selection |
| **Hero / Trust Field** | Modern (current gen) | Canvas-based, the only "modern" component |
| **Getting Started / Footer** | Terminal session | `$ ` prompts, raw command output |

### Rules

- No transitional animation between eras
- No visual bridge reconciling them
- They just sit adjacent to each other
- Like different monitors in a control room from different procurement cycles

---

## 3. HALF-MIGRATED SYSTEMS

### The Concept

Real infrastructure is full of:
- Deprecated terminology still in active use
- Compatibility bridges that became permanent
- Temporary adapters that ran for years
- Migration rollback support still loaded

### Visible Artifacts

Embedded in terminal output, section headers, and metrics:

```
[system] legacy trust adapter active (PROTO-01 compatibility bridge)
```

```
[archive] PROTO-02 compatibility bridge enabled — 14,203 receipts affected
```

```
[observer] warning: using deprecated quorum semantics — migrate to consensus pressure
```

```
[core] migration rollback support loaded — PROTO-01 → PROTO-02 transition
```

Or the most real line possible:

```
[scheduler] temporary validation shim active — uptime: 417d
```

Nothing signals "real infrastructure" more than a temporary fix that has been running for over a year.

### Visual

- These appear in the terminal stream like any other log
- Or as small warning banners on archived/migrated components
- `[system]` prefix for global migration artifacts
- Yellow warning triangle for deprecated semantics (very restrained)

---

## 4. UNEVEN INFORMATION DENSITY

### Current Problem

Every section is equally curated and equally dense.
Real infrastructure has **institutional asymmetry**.

### Solution: Deliberately Uneven Sections

| Section | Density | Example |
|---------|---------|---------|
| **Archive Health** | Absurdly sparse | `ARCHIVE HEALTH\nnominal` — two words, nothing else |
| **Consensus Replay** | Dense, technical | Multiple observer panels, hash strings, progress bars |
| **Live Demo** | Moderate | Button, progress, result — clean |
| **Trust Weather** | Dense (but atmospheric) | Climate, pressure, fronts, forecast |
| **Dead Protocol Layer** | Sparse, archival | Version, date, failure reason — faded |
| **Timeline** | Dense | Multiple events, causality arrows, replay buttons |

### Why This Works

A real control room has:
- Some panels covered in密密麻麻 data
- Some panels showing a single number
- Some screens blank except for a timestamp

The asymmetry itself signals operational reality.

---

## 5. HUMAN MAINTENANCE GHOSTS

### The Concept

Not team photos. Not founder stories.
But traces of previous operators embedded in the system.

### Implementation

Extremely subtle artifacts scattered through the interface:

```
// TODO: remove after migration cycle
// — operator: @ghost
```

```
observer naming collision unresolved
// collision: observer-03 and observer-17 resolved to same node
```

```
legacy receipt parser retained for compatibility
// parser version: 0.7.2 (deprecated)
```

```
// do not disable witness fallback
// — reason unknown
```

```
// temporary fix for replay saturation — pending review
// — operator: @x
```

### The Power

The last line — `// reason unknown` — implies:
- A decision was made
- The person who made it is gone
- The system still runs because of it
- No one knows why anymore

This single artifact makes the infrastructure feel **decades old**.

### Frequency

- 3-5 total across the entire page
- Invisible on first visit (buried in receipts, archive panels, terminal history)
- Found by curious visitors who inspect closely
- Never explained

---

## 6. TIME ACCUMULATION

### More Than Uptime Counters

The system needs **historical density** — evidence that years have passed.

### Implementation

Various time-related displays:

```
oldest active receipt: 1827d
```

```
PROTO-01 archival window exceeded by 944d
```

```
historical replay backlog cleared after 71d
```

```
observer cluster migrated across 4 protocol generations
```

```
legacy variance records imported successfully
// 14,033 records (2024-01-17 → 2026-05-22)
```

```
continuity score: 0.987
// uninterrupted operation: 827d
```

### Non-Human Time (from v5, retained)

```
consensus cycle 482991
observer uptime: 203d 7h 32m
revalidation running for 17h 14m
ledger height: 1,247,093
```

---

## 7. BORING FAILURE RECOVERY

### Current Problem

Failures still have slight dramaturgy. A desync event is treated as a moment.

### The Fix

In real infrastructure, recovery is boring. The system handled it. The end.

### Old (dramatic):

```
[observer-03] temporal offset exceeds threshold ← attention
[motherbrain] cross-verification mismatch ← concern
...recovery sequence...
[observer-03] temporal offset resolved ← relief
```

### New (boring):

```
[observer-03] desync resolved
backfill complete
```

Three lines. No emotion. No emphasis.

The desync event might have been severe. The system does not communicate severity through tone. It communicates through action.

### Rule

All failure states end the same way:
1. The problem occurs
2. The system handles it
3. Log: `[component] resolved`
4. Log: `backfill complete` (or equivalent)
5. System continues

No triumph. No relief. Just operation.

---

## 8. REVISED SECTION MAP (v7)

```
 1. HERO — False Stillness → Slow Awakening
    - 8s stillness, then minimal pulse, then gradual ramp to full rhythm
    - Terminal: 92% banal, 7% interesting, 1% disturbing — all equal treatment
    - System does not react to user

 2. WHY NOW
    - Single viewport. "AI writes code faster than humans can verify it."

 3. THE PROBLEM
    - Git/CI/Observability vs BKG. Institutional tone.

 4. THE SHIFT (Monolith Space)
    - "Code is no longer authored. It is selected."
    - Full viewport. Silence. Sedimented context.

 5. SILENCE ZONE — Operational Void
    - Slightly misaligned. Terminal cursor. "observing..."
    - The system has nothing to report.

 6. DETERMINISTIC SOLUTION
    - 5 pillars. Terminal-style. Early-era language in places.

 7. CONSENSUS REPLAY — SSH Moment (ERA: ~2004)
    - Terminal windows, ASCII bars, hard borders
    - 2004 cluster console aesthetic
    - Click opens xterm-style overlay

 8. DEAD PROTOCOL LAYER (ERA: ~1990s ncurses)
    - Archived. Faded. "failure reason: unrecoverable variance"
    - Early-era language: "quorum stress", "hash mismatch"
    - Human ghost: "// legacy receipt parser retained"

 9. LIVE REPLAY DEMO (ERA: ~2010 operator console)
    - Functional, minimal, grey-on-dark

10. ARCHIVE HEALTH (Uneven Density)
    - "ARCHIVE HEALTH\nnominal" — two words, nothing else

11. MOTHERBRAIN ARCHITECTURE
    - 5 Layers with dead protocol layer behind
    - Half-migration artifact: "temporary validation shim active — 417d"
    - NOT AI. Institutional authority.

12. SILENCE ZONE — Transitional Void

13. TRUST VECTOR + EPISTEMIC METEOROLOGY (ERA: ~2013 scientific dashboard)
    - Weather panel with atmospheric terminology
    - Mid-era language: "trust contamination", "consensus instability"
    - Time accumulation: "oldest active receipt: 1827d"

14. TEMPORAL KNOWLEDGE TIMELINE (ERA: half-migrated internal tool)
    - Inconsistent spacing, mix of old/new
    - Epistemic scars as normal events
    - Human ghost: "// do not disable witness fallback — reason unknown"

15. RECEIPT ANATOMY
    - Raw terminal output
    - Redacted fields, [DATA EXPUNGED] (sparse)

16. KNOWLEDGE DECAY LIFECYCLE
    - Hot → Warm → Cold → Revalidate
    - Early terminology visible in archived parts

17. TECH STACK
    - Plain list. Minimal styling.

18. ROADMAP
    - Plain table. No polish.

19. SILENCE ZONE — Final Void

20. GETTING STARTED + FOOTER
    - `$ ` prompts, raw command output
    - BKG lore drop: "Best Known Garbage" (once, cold, final)
    - AUTHORIZED OBSERVERS (handles + PGP + node IDs)
    - No team. No about. No founders.
    - MIT License. GitHub.

    - Time accumulation: "continuity score: 0.987 // 827d uninterrupted"
```

---

## 9. THE ERA MAP

| Component | Era Aesthetic | Terminology Era | Visual Style |
|-----------|--------------|-----------------|-------------|
| Hero + Trust Field | Current | Modern | Canvas, current gen |
| Consensus Replay | ~2004 | Early | Terminal windows, hard borders, ASCII |
| Dead Protocol | ~1990s | Early | Ncurses-like, blocky |
| Live Demo | ~2010 | Mid | Functional, grey-on-dark |
| Archive Health | ~1990s | Early | Two words, absurdly minimal |
| Motherbrain | Current | Modern | Clean layers, institutional |
| Trust Weather | ~2013 | Mid→Modern | Scientific dashboard |
| Timeline | Mixed | All eras | Half-migrated internal tool |
| Receipt Anatomy | ~2004 | Early | Raw terminal |
| Decay Lifecycle | ~2013 | Mid→Modern | Functional diagram |
| Tech Stack | Current | Modern | Minimal list |
| Roadmap | ~2010 | Mid | Plain table |
| Getting Started | Current | Modern | Terminal session |

---

## 10. DESIGN PRINCIPLES (v7 Final)

### Prioritize Stratification Over Cohesion
The page should not look like one designer built it.
It should look like different eras built different parts.

### Prioritize Accumulation Over Design
The page should not feel "made."
It should feel like it grew.

### Prioritize Sediment Over Polish
Visible history is more valuable than perfect alignment.

### Prioritize Banality Over Drama
92% of the terminal stream is routine.
That is what makes the other 8% matter.

### Prioritize Indifference Over Engagement
The system does not need you.
That is its authority.

---

## 11. DESIGN VIOLATIONS INDEX (v7 Expanded)

| Violation | Why Banned |
|-----------|------------|
| Floating/pulsing CTA buttons | Startup signifier |
| "Get Started" → email form | Conversion energy |
| Cookie banner | Institutional infra doesn't have these |
| Chat bubble "How can I help?" | Motherbrain is not a chatbot |
| Testimonials | Social proof is for products |
| Pricing table | BKG is infra, not SaaS |
| "Book a demo" | System is already running |
| Brain icons / neural networks | Motherbrain is not AI |
| Animated human illustrations | Wrong genre entirely |
| Gradient meshes / multi-color sweeps | Too playful |
| Particle backgrounds (generic) | Every AI startup does this |
| Loading spinners | System is always on |
| "Built with ❤️" | Cringe |
| Smiley faces / emoji in copy | Institutional coldness |
| `ease-in-out` on system animations | Too smooth, too web |
| Floating elements that follow scroll | SaaS dashboard pattern |
| About page / Team page / Founder story | Infrastructure doesn't have founders |
| Full names of contributors | Operators, not people |
| Too many anxiety lines | Tips into ARG/SCP |
| Too many [DATA EXPUNGED] | Sparsity is everything |
| Interactive lore dumps | System doesn't explain itself |
| Hover celebrations | System does not react to you |
| Scroll-linked animations | No dopamine reward for scrolling |
| Confetti / micro-interactions | SaaS delight patterns |
| Sound effects | Not a video game |
| Polished empty states | Beautiful nothing = still marketing |
| Perfect terminological consistency | Real systems have terminology drift |
| Single uniform UI era | Real systems accumulate interface generations |
| Equal information density across sections | Real systems have institutional asymmetry |
| Emotionally reactive failure states | Real infrastructure recovers boringly |
| Transitional animations between eras | Systems don't apologize for their history |

---

## 12. THE FINAL TEST

### Show the page to someone with no context.

| Reaction | Verdict |
|----------|---------|
| "I can see the different eras it went through" | ✓✓ (highest possible) |
| "Why does this feel old?" | ✓ |
| "Is this a real system?" | ✓ |
| "This makes me uncomfortable" | ✓ |
| "What am I looking at?" (and keeps scrolling) | ✓ |
| "Who maintains this?" | ✓ (right question) |
| "Is this open source?" | ✓ (right question) |
| "Cool website!" | ✗ |
| "Beautiful design!" | ✗ |
| "Is this a game?" | ✗ |
| "Let me see pricing" | ✗ |
| "Who made this?" | ✗ (wrong question) |

---

## 12.5 OPERATIONAL ASYMMETRY (v7.1 Layer)

Not every panel should look equally intelligent. Real infrastructure has authority gradients — some parts are official and audited, others are operationally abandoned or compliance-overlaid.

### 12.5.1 Panel Authority Hierarchy

**Official Panels** (Trust Weather, Motherbrain Core, Consensus Ledger):
- Consistent spacing, stable typography, restrained borders
- Few warnings, no visible TODOs
- Signal: institutional authority

**Unloved Panels** (Legacy Replay Queue, Observer Recovery, Archive Import, Compatibility Bridges):
- 1px wrong padding, different header heights, odd scrollbars
- Old monospace font, random uppercase labels, text overflow nearly breaking
- Inconsistent timestamps, not broken but **operationally abandoned**
- Signal: nobody has owned this panel in years

### 12.5.2 Procurement Era Collision

Different hardware/software procurement cycles visible in adjacent panels:

```
~1998:  bitmap-ish monospace, olive/green, hard borders, 4px padding
~2007:  Verdana, inset shadows, compact tables, forbidden gradients still present
~2014:  Open Sans, flat dashboard era, thin separators, muted blues
~2026:  variable font, canvas rendering, ultra-clean spacing, dark graphite
```

These sit adjacent. No explanation. No visual bridge.

### 12.5.3 Documentation Rot

Embedded references that have decayed:

```
validation semantics updated in PROTO-02
see migration memo #442
```

(Memo #442 does not exist. The link goes nowhere or opens an archived stub.)

```
observer variance policy v1.4 applies
policy deprecated since 2025
```

Both visible simultaneously. Contradictory. Unreconciled.

### 12.5.4 Naming Contradictions

Left panel: `TRUST INDEX`
Right panel: `TRUTH VECTOR`
Footer: `consensus confidence layer`

Never harmonized. Different operators from different eras named them differently.

### 12.5.5 Non-Designed Micro-Inconsistencies

Not systematic:
- Some panels use `:` after labels, some don't
- Some timestamps have milliseconds, some don't
- Some IDs are uppercase (`OBSERVER_ID`), some lowercase (`observer_id`)
- Some use underscores, some use hyphens
- Adjacent panels: `observer_id: eu-west-03` vs `OBSERVER-ID eu_west_legacy_03`

These emerge during implementation by deliberately NOT normalizing.

### 12.5.6 Boring Legal/Compliance Sediment

NOT a cookie banner. Institutional administrative dust:

```
NOTICE:
observer telemetry retained for continuity verification
retention window may exceed regional archival guidelines
```

```
audit interface unavailable in public node mode
```

```
external witness exports disabled pending review
```

### 12.5.7 Maintenance Windows

Non-dramatic operational state indicators:

```
observer synchronization degraded during archive compaction
```

```
scheduled replay maintenance window active
```

No modal. No banner. No UX apology. Just state.

### 12.5.8 Operational Dead Weight

Visible functionality that serves no apparent purpose anymore:

```
LEGACY EXPORT FORMATS
- .rv1
- .rv2
- .rv2b
```

Nobody uses `.rv1`. But removing it would be riskier than keeping it.

```
fallback observer codec loaded
```

Why? No one knows. But it stays.

### 12.5.9 Critical Implementation Rule

Some of this must **happen** during development, not be designed upfront.

When building:
- Deliberately leave naming inconsistencies unresolved
- Let some panels have slightly wrong padding
- Keep old terminology alongside new
- Don't harmonize timestamp formats across sections

If everything is unified, the sediment disappears.

---

## 13. ADMINISTRATIVE ENTROPY (Implementation Principle)

This is NOT a v8 feature. This is a design principle for the build phase.

The page should contain artifacts that feel like they accumulated through operational neglect, not deliberate design:

**Old warnings never removed:**
```
// TEMPORARY FIX: replay saturation workaround
// — applied 2025-08-14 by @x
// status: still active
```

**Panels with "migration pending":**
```
OBSERVER GROUP: eu-west-03
status: migration pending (since 2025-11-02)
```

**Deprecated hotkeys still displayed:**
```
[C+Q] quick-archive (deprecated — use [C+W])
```

**Contradictory date formats:**
```
2024-07-14  (ISO)
03/12/2025  (US)
14.06.2026  (EU)
```
appearing in different panels.

**Two names for the same thing:**
```
Truth Score  (motherbrain panel)
Trust Index  (observer log)
```
Never reconciled.

**Observer regions that no longer exist:**
Referenced in terminal logs but absent from the active node map.

**Panels showing "temporarily disabled" for 600+ days:**
```
[scheduler] observer-12 queue: TEMPORARILY DISABLED
— last active: 2024-09-03 (620 days ago)
```

### Rule

These must feel DISCOVERED during implementation, not DESIGNED in advance.
The power comes from their accidental quality.

If they feel authored, they fail.

---

## 14. THE FINAL POSITIONING

### Not a product. Not a brand. Not a website.

The system no longer feels designed.
It feels:
- Accumulated
- Migrated
- Extended
- Patched
- Institutionalized
- **Accidentally exposed**

### The Category

> Infrastructure for continuity of synthetic truth.

This does not sound like marketing.
It sounds like a term that emerged from within the system itself.

### The Achievement

BKG no longer works because it is "mysterious."

It works because it behaves like infrastructure that was never built for public access.

That is the difference between:
- An art project
- Accidentally visible reality

### The Single Quality That Makes This Rare

The system no longer seems to be under full conscious control.

Not in a horror sense.
In a "been operational too long" sense.

This is exactly the zone where real infrastructure lives.
And it cannot be faked by adding more design.

It can only be accumulated.

---

## 15. THE FINAL WORD

BKG-WASM has stopped being a designed artifact.

It has become:
- Accumulated
- Migrated
- Extended
- Patched
- Institutionalized

It no longer looks like a website.
It looks like a system that has survived multiple eras,
is still running,
and does not require your attention
to verify whether code works or not.

**The age of handcrafted software is ending.**
**The age of reproducible computation has begun.**

**Code is no longer authored.**
**It is selected.**

---

## 16. DIOXUS/WASM RUNTIME KERNEL — BUILD SPEC

This is the distilled, implementable architecture. No theory — only the 5 kernel layers that transform the v7 spec into a running Dioxus 0.6+ WASM system.

### 16.1 System Architecture (5 Kernel Layers)

```
┌──────────────────────────────┐
│        Dioxus App Root       │
├──────────────────────────────┤
│  UI Layer (Era Components)   │
├──────────────────────────────┤
│  Render Resolver (EraEngine) │
├──────────────────────────────┤
│  Semantic Drift Engine       │
├──────────────────────────────┤
│  Log Stream Engine (async)   │
├──────────────────────────────┤
│  Core State Machine          │
└──────────────────────────────┘
```

This is NOT a frontend. This is a simulated infrastructure process in the browser.

### 16.2 Core State Machine (Heart)

Not Redux-style UI state. Infrastructure state machine.

```rust
#[derive(Clone)]
pub enum SystemState {
    Initializing,
    FalseStillness,
    Awakening,
    StableOperation,
    ObserverDesync,
    Backfill,
    MigrationEvent,
    SilentVoid,
}
```

**Transition Engine:**

```rust
impl SystemState {
    pub fn tick(&self, kernel: &BkgKernel) -> Self {
        match self {
            SystemState::Initializing => SystemState::FalseStillness,

            SystemState::FalseStillness => {
                if kernel.time.uptime_days > 0 {
                    SystemState::Awakening
                } else {
                    SystemState::FalseStillness
                }
            }

            SystemState::Awakening => SystemState::StableOperation,

            SystemState::StableOperation => {
                let roll = kernel.time.consensus_cycle % 23;
                if roll == 0 {
                    SystemState::ObserverDesync
                } else if roll == 7 {
                    SystemState::MigrationEvent
                } else {
                    SystemState::StableOperation
                }
            }

            SystemState::ObserverDesync => SystemState::Backfill,
            SystemState::Backfill => SystemState::StableOperation,
            SystemState::MigrationEvent => SystemState::SilentVoid,
            SystemState::SilentVoid => SystemState::StableOperation,
        }
    }
}
```

**Key:** No UX states. Only infrastructure states.

### 16.3 BKG Kernel (Global State)

Single source of truth:

```rust
pub struct BkgKernel {
    pub time: TimeState,
    pub logs: Vec<LogEvent>,
    pub state: SystemState,
    pub era: EraMap,
    pub drift: SemanticDriftState,
}

pub struct TimeState {
    pub uptime_days: u64,
    pub ledger_height: u64,
    pub consensus_cycle: u64,
    pub last_migration_epoch: u64,
}

pub struct LogEvent {
    pub timestamp: u64,
    pub source: LogSource,
    pub message: String,
    pub severity: LogSeverity,
    pub era_tag: Era,
}
```

### 16.4 Era Engine (UI Time Machine)

Each component has its own historical reality. No global theme. Each node lives historically isolated.

```rust
#[derive(Clone)]
pub enum Era {
    Proto01,   // 2004 ASCII console
    Proto02,   // 2013 dashboard proto-UI
    Modern,    // 2026 canvas UI
    Dead,      // 1990s ncurses
}

pub fn resolve_era(component: &str) -> Era {
    match component {
        "ConsensusReplay"   => Era::Proto01,
        "DeadProtocolLayer" => Era::Dead,
        "LiveDemo"          => Era::Proto02,
        "TrustWeather"      => Era::Proto02,
        "MotherbrainCore"   => Era::Modern,
        _                   => Era::Proto02,
    }
}
```

### 16.5 Semantic Drift Engine (Real Feature)

This is what makes terminology timelines real:

```rust
pub struct SemanticDriftState {
    pub proto01: HashMap<String, String>,
    pub proto02: HashMap<String, String>,
    pub modern: HashMap<String, String>,
}

pub fn resolve_term(term: &str, era: &Era, drift: &SemanticDriftState) -> String {
    match era {
        Era::Proto01 => drift.proto01.get(term).cloned().unwrap_or(term.to_string()),
        Era::Proto02 => drift.proto02.get(term).cloned().unwrap_or(term.to_string()),
        Era::Modern  => drift.modern.get(term).cloned().unwrap_or(term.to_string()),
        Era::Dead    => term.to_string(),
    }
}
```

### 16.6 Log Stream Engine (Kernel of the Illusion)

This is the "system is alive" effect.

```rust
pub fn tick_logs(kernel: &mut BkgKernel) {
    let e = generate_event(kernel);
    kernel.logs.push(e);
    if kernel.logs.len() > 5000 {
        kernel.logs.remove(0);
    }
}
```

**92/7/1 Reality Ratio:**

```rust
pub fn generate_event(kernel: &BkgKernel) -> LogEvent {
    let cycle = kernel.time.consensus_cycle;

    match cycle % 100 {
        0..=91 => banal_event(kernel),       // 92%
        92..=98 => interesting_event(),      // 7%
        _ => disturbing_event(),             // 1%
    }
}
```

**Banal (92%):**
```
heartbeat acknowledged
receipt archived
queue nominal
observer-11 idle
retention sweep complete
backfill complete
```

**Interesting (7%):**
```
consensus pressure rising
trust drift detected
observer desync resolved
variance outside expected range
climate shifting — recovery window 12-18min
```

**Disturbing (1%):**
```
historical contradiction preserved
14 previously accepted truths invalidated
consensus reached without human intervention
[DATA EXPUNGED]
unauthorized variance archived
```

### 16.7 Dioxus Component Tree

```rust
rsx! {
    GlobalLogOverlay { state }

    HeroModule { state }
    WhyNowPanel { state }
    ProblemPanel { state }
    ShiftMonolith { state }

    SilenceZone {}

    DeterministicSolution { state }

    ConsensusReplay { state }      // ERA: Proto01
    DeadProtocolLayer { state }    // ERA: Dead
    LiveDemo { state }             // ERA: Proto02
    ArchiveHealth {}

    MotherbrainCore { state }

    TrustWeather { state }
    TimelineEngine { state }

    ReceiptAnatomy { state }
    DecayLifecycle { state }

    TechStack {}
    Roadmap {}

    FooterTerminal { state }
}
```

### 16.8 Global Runtime Loop (WASM Core)

```rust
spawn(async move {
    // 8s false stillness
    sleep(Duration::from_secs(8)).await;

    // Continuous operation
    loop {
        let interval = poisson_interval(); // 500-2000ms

        sleep(interval).await;

        kernel.write().state = kernel.read().state.tick(&kernel.read());
        tick_logs(&mut kernel.write());
        kernel.write().time.consensus_cycle += 1;
    }
});
```

### 16.9 Global Log Overlay (Key Feel System)

This is NOT a UI element. It is physical background reality in the browser.

```rust
fn GlobalLogOverlay(state: Signal<BkgKernel>) -> Element {
    rsx! {
        div {
            class: "log-overlay",
            for log in state.read().logs.iter().rev().take(30) {
                div { class: "log-line", "{log.message}" }
            }
        }
    }
}
```

No colors. No emphasis. No importance sorting.

### 16.10 Critical Design Shift

You are NOT building UI.

You are building a **persistent, self-running infrastructure simulation in the browser**.

All classical frontend principles are violated:
- No theme system
- No UX consistency
- No animation logic as design
- No "user interaction flow"
- No navigation as concept

### 16.11 Optional Upgrade: Drift Inspector (Meta-System)

```rust
pub struct DriftInspector {
    pub proto01: f32,   // % of active PROTO-01 terminology
    pub proto02: f32,   // % of active PROTO-02 terminology
    pub modern: f32,    // % of modern terminology
}
```

Shows how old the system currently "feels." Not technical. Historical.

### 16.12 Final Reality Check

When this runs, you have:
- A WASM system that simulates itself
- UI displaying historical layers simultaneously
- Logs that exist independently of UI
- Components with different "ages"
- Terminology that never normalizes
- A state machine that behaves like infrastructure

**This is not a frontend. This is a running, simulated, historically drifting operating system in the browser.**

---

## 17. SECRET ALPHA — GUARD NODE EDITOR GRID

A hidden entry point within the BKG-WASM system. Not a feature. An **alternate mode of existence**.

### 17.0 Concept

The page looks like an infrastructure artifact. But buried within it is a **P2P code collective with a local AI arbiter**, accessible only via easter egg triggers. When activated, the UI "peels open" — the terminal layer becomes editable, an editor emerges inside a "log fracture," and peers join a shared code mesh.

**Final form:** A self-organizing code collective in the browser, with a local AI guard agent as mediator.

### 17.1 Architecture

```
BKG App
 ├── UI Shell (Dioxus WASM)
 ├── Easter Egg Trigger System
 ├── Guard Runtime (WebLLM)
 ├── P2P Mesh Layer (WebRTC)
 ├── Shared State Bus (CRDT — Yjs/Automerge)
 ├── Code Editor (Monaco / CodeMirror 6)
 └── External API Bridge Layer (sandboxed)
```

### 17.2 Easter Egg Activation

No button. Hidden state triggers:

| Trigger | Effect |
|---------|--------|
| 7x click on Archive Health | Unlock candidate |
| Terminal: `/sync.guard.enable` | Direct unlock |
| Log pattern `[observer] anomaly detected` | Gradual unlock |
| Konami code | Classic easter egg |

On unlock: `SystemState::GuardNodeUnlocked` — the Guard overlay mounts.

### 17.3 Guard Runtime (WebLLM Core)

Runs locally in browser via WASM/WebGPU.

```rust
struct GuardAgent {
    model: WebLLMHandle,
    context: SharedContext,
    mode: GuardMode,
}

enum GuardMode {
    PassiveObserver,    // watches, does not intervene
    CoCoder,            // suggests completions inline
    MeshArbiter,        // resolves P2P conflicts
    AutonomousSuggestor, // proactive suggestions
}
```

**Guard Core Loop:**
1. User types code
2. CRDT syncs to mesh
3. Guard evaluates diff via WebLLM
4. Optional: suggest fix, broadcast hint, call external model
5. Other peers receive suggestion overlay

### 17.4 P2P Mesh Layer (WebRTC)

```rust
struct PeerNode {
    id: String,
    connection: WebRtcConnection,
    state: NodeState,
}
```

- Mesh topology (no central server required)
- Optional relay node for bootstrap
- Auto-discovery via DHT / signaling server / QR invite
- Full mesh sync: code state, cursor positions, guard messages

### 17.5 Shared State Bus (CRDT)

Using Yjs or Automerge for conflict-free operation:

```rust
struct SharedWorkspace {
    code: CRDTDocument,
    logs: CRDTLogStream,
    guard_events: CRDTEventBus,
}
```

- Conflict-free merges
- Offline sync
- Eventual consistency

### 17.6 External API Bridge (Sandboxed)

Users can add their own models via external APIs — with strict sandboxing:

```rust
struct ExternalModelBridge {
    endpoint: String,
    auth: Option<String>,
    capability: ModelCapability,
}

enum ModelCapability {
    CodeCompletion,
    GuardReasoning,
    Embedding,
    ToolUse,
}
```

**Safety:** Request throttling, per-peer isolation, no raw code execution from external models — only suggestion outputs.

### 17.7 UX: "UI Peels Open"

Visual concept:

```
[ ARCHIVE HEALTH ]
        ↓ cracks
[ CODE NODE INTERFACE ]
        ↓ opens
[ P2P GRID ACTIVE ]
```

The normal BKG UI fades out. The terminal layer becomes editable. The editor emerges inside a "log fracture." `SystemState::GuardNodeUnlocked` triggers the overlay component mount.

### 17.8 Dioxus Component

```rust
// Only mounted when SystemState::GuardNodeUnlocked
#[component]
fn GuardNodeOverlay(state: Signal<BkgKernel>, peers: Vec<PeerNode>) -> Element {
    // Editor overlay + P2P status + Guard agent panel
}
```

### 17.9 Reality Constraints

- WebLLM: GPU-heavy (mobile may struggle)
- WebRTC mesh: fragile at scale (10+ peers increases complexity exponentially)
- CRDT: must be carefully tuned for code editing latency
- Monaco: large WASM bundle (~5MB) — significant page weight increase

### 17.10 Clean MVP Path

| Phase | Scope | Complexity |
|-------|-------|-----------|
| **Phase 1** | Hidden Monaco editor, single local WebLLM guard, no P2P | 2-3 weeks |
| **Phase 2** | 2-5 peer WebRTC mesh, shared cursors, shared code | 3-4 weeks |
| **Phase 3** | CRDT sync layer, guard arbitration mode | 2-3 weeks |
| **Phase 4** | External model APIs, plugin system | 2-3 weeks |

### 17.11 Final Form

This is not an editor.

This is a **self-organizing code collective in the browser, with a local AI arbiter**.

The BKG-WASM page is the shell. The Guard Node Editor Grid is the **living core** — hidden until the system decides you're ready to see it.

---

## 18. PRODUCTION DEPLOYMENT

### Build

```bash
wasm-pack build --target web --out-dir pkg
```

Output: `pkg/bkg_wasm_alpha_bg.wasm` (~686KB gzip: ~220KB), `pkg/bkg_wasm_alpha.js` (~63KB)

### Serve

Any static file server:
```bash
python3 -m http.server 8080
```

### Deploy Targets

| Platform | Notes |
|----------|-------|
| **GitHub Pages** | Zero config. Push `index.html + style.css + pkg/` |
| **Vercel** | Set `public` dir, SPA fallback not needed |
| **Netlify** | Drag-drop `index.html + style.css + pkg/` |
| **IPFS** | `ipfs add -r .` — fits the infrastructure mythography |

### Production Checks

- [x] 0 Rust warnings, 0 errors, clean release build
- [x] wasm-opt binary optimization applied automatically
- [x] Cargo.toml has description, repository, license
- [x] LICENSE file (MIT) present
- [x] index.html has meta tags (og, twitter, theme-color, viewport)
- [x] index.html has SVG favicon (no external dependencies)
- [x] index.html shows loading state before WASM init
- [x] index.html shows error state if WASM fails to load
- [x] CSS is self-contained (Google Fonts via preconnect, no other CDNs)
- [x] Zero JS dependencies (Rust/WASM only)
- [x] `prefers-reduced-motion` respected throughout
- [x] Responsive layout (768px breakpoint for mobile)
- [x] Font display swap for performance

### File Inventory

```
/workspaces/alpha/
├── index.html              (2.3KB)
├── style.css               (35KB)
├── Cargo.toml              (460B)
├── LICENSE                 (1.1KB)
├── src/
│   ├── lib.rs              (4.2KB)
│   ├── kernel.rs           (11KB)
│   ├── era.rs              (2.3KB)
│   ├── drift.rs            (4.1KB)
│   ├── log.rs              (12KB)
│   └── components/
│       ├── mod.rs
│       ├── archive_health.rs
│       ├── consensus_replay.rs
│       ├── dead_protocol.rs
│       ├── decay.rs
│       ├── deterministic.rs
│       ├── footer.rs
│       ├── getting_started.rs
│       ├── global_log.rs
│       ├── guard_node.rs
│       ├── hero.rs
│       ├── live_demo.rs
│       ├── motherbrain.rs
│       ├── problem.rs
│       ├── receipt.rs
│       ├── roadmap.rs
│       ├── shift.rs
│       ├── silence.rs
│       ├── tech_stack.rs
│       ├── timeline.rs
│       ├── trust_weather.rs
│       └── why_now.rs
├── pkg/
│   ├── bkg_wasm_alpha_bg.wasm     (686KB)
│   ├── bkg_wasm_alpha.js           (63KB)
│   └── ... (wasm-pack generated)
└── LICENSE
```
