# bkg-client — TRUTH

> **Project-local truths.** Cross-reference with `../../truth.md` for global truths.

## Identity
- **Package:** `bkg-client` (Cargo.toml)
- **Directory:** `projects/bkg-client/`
- **Purpose:** BKG Client — CLI, API, provider integration

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | CLI entry |
| `crates/bkg-api/` | API server |
| `crates/bkg-tools/` | Tool system |
| `crates/bkg-provider/` | Provider integration |

## Depends On
- `bkg-api`, `bkg-tools`, `bkg-provider`
- `bkg-core` (root crate, legacy)
