# bkg-client — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-client.md` (C001–C018)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **CLIAgent** | Command-line interface, REPL | P0 |
| **APIAgent** | REST/WS API server | P0 |
| **ProviderAgent** | AI provider integration | P1 |
| **ToolAgent** | Tool system, plugin loader | P1 |

## Dependencies
- `crates/bkg-api/` — API server
- `crates/bkg-tools/` — tool system
- `crates/bkg-provider/` — provider integration
- `bkg-core` (root crate, legacy)

## Entry Points
- `src/main.rs` — CLI binary
