# bkg-client — PROGRESS

> **Milestones tracked in:** `../../tasks/task-client.md` (C001–C018)

## Phase 1: Client (C001–C018)
- [ ] C001 — C018 — CLI, API, provider integration, tools

## Status
- **Task file:** `../../tasks/task-client.md`
- **Task ref:** C001–C018
- **Progress:** 0 / 18 steps
