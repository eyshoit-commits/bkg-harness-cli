//! Fetch tool - Fetch content from URLs.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};

/// Fetch tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FetchParams {
    /// The URL to fetch.
    pub url: String,
    /// Maximum size to fetch in bytes (default 100KB).
    #[serde(default = "default_max_size")]
    pub max_size: usize,
}

fn default_max_size() -> usize {
    100 * 1024 // 100KB
}

/// Fetch tool implementation.
pub struct FetchTool {
    client: reqwest::Client,
}

impl FetchTool {
    /// Create a new fetch tool.
    pub fn new() -> Self {
        Self {
            client: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(30))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
        }
    }
}

impl Default for FetchTool {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl Tool for FetchTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "fetch".to_string(),
            description: "Fetch content from a URL. Returns text content. Max 100KB by default."
                .to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "The URL to fetch content from"
                    },
                    "max_size": {
                        "type": "integer",
                        "description": "Maximum size to fetch in bytes (default 102400)"
                    }
                },
                "required": ["url"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: FetchParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let response = self
            .client
            .get(&params.url)
            .header("User-Agent", "bkg/0.1.0")
            .send()
            .await
            .map_err(|e| crate::Error::Http(format!("Request failed: {}", e)))?;

        if !response.status().is_success() {
            return Ok(ToolResponse::error(format!(
                "HTTP {}: {}",
                response.status(),
                params.url
            )));
        }

        let content_type = response
            .headers()
            .get("content-type")
            .and_then(|v| v.to_str().ok())
            .unwrap_or("text/plain")
            .to_string();

        let bytes = response
            .bytes()
            .await
            .map_err(|e| crate::Error::Http(format!("Failed to read response: {}", e)))?;

        if bytes.len() > params.max_size {
            return Ok(ToolResponse::error(format!(
                "Response too large: {} bytes (max {})",
                bytes.len(),
                params.max_size
            )));
        }

        let content = String::from_utf8_lossy(&bytes);
        let result = format!(
            "URL: {}\nContent-Type: {}\n\n{}",
            params.url, content_type, content
        );

        Ok(ToolResponse::text(result))
    }
}
