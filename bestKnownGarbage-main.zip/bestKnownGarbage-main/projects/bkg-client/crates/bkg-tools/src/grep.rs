//! Grep tool - Search file contents.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use regex::Regex;
use serde::{Deserialize, Serialize};
use tokio;

/// Grep tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GrepParams {
    /// The pattern to search for (regex).
    pub pattern: String,
    /// The path to search in.
    #[serde(default = "default_path")]
    pub path: String,
    /// Case insensitive.
    #[serde(default)]
    pub ignore_case: bool,
}

fn default_path() -> String {
    ".".to_string()
}

/// Grep tool implementation.
pub struct GrepTool {
    working_dir: Option<String>,
}

impl GrepTool {
    /// Create a new grep tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for GrepTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "grep".to_string(),
            description: "Search for pattern in files.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "pattern": { "type": "string", "description": "Regex pattern" },
                    "path": { "type": "string", "description": "Search path" },
                    "ignore_case": { "type": "boolean", "description": "Case insensitive" }
                },
                "required": ["pattern"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: GrepParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let pattern = if params.ignore_case {
            Regex::new(&format!("(?i){}", params.pattern))
        } else {
            Regex::new(&params.pattern)
        }
        .map_err(|e| crate::Error::Tool(format!("Invalid regex: {}", e)))?;

        let search_path = self
            .working_dir
            .as_ref()
            .map(|d| std::path::Path::new(d).join(&params.path))
            .unwrap_or_else(|| std::path::Path::new(&params.path).to_path_buf());

        let mut results = Vec::new();

        if search_path.is_file() {
            if let Ok(content) = tokio::fs::read_to_string(&search_path).await {
                for (i, line) in content.lines().enumerate() {
                    if pattern.is_match(line) {
                        results.push(format!("{}:{}:{}", search_path.display(), i + 1, line));
                    }
                }
            }
        } else if search_path.is_dir() {
            let mut entries = tokio::fs::read_dir(&search_path)
                .await
                .map_err(|e| crate::Error::Tool(format!("Read dir failed: {}", e)))?;

            while let Ok(Some(entry)) = entries.next_entry().await {
                let path = entry.path();
                if path.is_file() {
                    if let Ok(content) = tokio::fs::read_to_string(&path).await {
                        for (i, line) in content.lines().enumerate() {
                            if pattern.is_match(line) {
                                results.push(format!("{}:{}:{}", path.display(), i + 1, line));
                            }
                        }
                    }
                }
            }
        }

        if results.is_empty() {
            Ok(ToolResponse::text("No matches found"))
        } else {
            Ok(ToolResponse::text(results.join("\n")))
        }
    }
}
