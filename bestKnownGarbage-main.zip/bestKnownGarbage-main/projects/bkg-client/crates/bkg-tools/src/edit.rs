//! Edit tool - Edit files with find-and-replace.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio;

/// Edit tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditParams {
    /// The file path to edit.
    pub file_path: String,
    /// The text to find.
    pub old_string: String,
    /// The replacement text.
    pub new_string: String,
    /// Replace all occurrences.
    #[serde(default)]
    pub replace_all: bool,
}

/// Edit tool implementation.
pub struct EditTool {
    working_dir: Option<String>,
}

impl EditTool {
    /// Create a new edit tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for EditTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "edit".to_string(),
            description: "Edit a file by finding and replacing text.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "file_path": { "type": "string", "description": "File path" },
                    "old_string": { "type": "string", "description": "Text to find" },
                    "new_string": { "type": "string", "description": "Replacement text" },
                    "replace_all": { "type": "boolean", "description": "Replace all" }
                },
                "required": ["file_path", "old_string", "new_string"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: EditParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let path = self
            .working_dir
            .as_ref()
            .map(|d| Path::new(d).join(&params.file_path))
            .unwrap_or_else(|| Path::new(&params.file_path).to_path_buf());

        let content = tokio::fs::read_to_string(&path)
            .await
            .map_err(|e| crate::Error::Tool(format!("Read failed: {}", e)))?;

        let count = content.matches(&params.old_string).count();
        if count == 0 {
            return Ok(ToolResponse::error("old_string not found"));
        }
        if count > 1 && !params.replace_all {
            return Ok(ToolResponse::error(
                "old_string appears multiple times, use replace_all",
            ));
        }

        let new_content = if params.replace_all {
            content.replace(&params.old_string, &params.new_string)
        } else {
            content.replacen(&params.old_string, &params.new_string, 1)
        };

        tokio::fs::write(&path, &new_content)
            .await
            .map_err(|e| crate::Error::Tool(format!("Write failed: {}", e)))?;

        Ok(ToolResponse::text(format!("Edited {}", path.display())))
    }
}
