//! LS tool - List directory contents.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use glob;
use serde::{Deserialize, Serialize};
use std::path::Path;

/// LS tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LsParams {
    /// The directory path to list.
    #[serde(default = "default_path")]
    pub path: String,
    /// Ignore patterns.
    #[serde(default)]
    pub ignore: Vec<String>,
}

fn default_path() -> String {
    ".".to_string()
}

/// LS tool implementation.
pub struct LsTool {
    working_dir: Option<String>,
}

impl LsTool {
    /// Create a new ls tool.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for LsTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "ls".to_string(),
            description: "List files and directories in a tree-like format.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "The directory to list (default: current directory)"
                    },
                    "ignore": {
                        "type": "array",
                        "description": "Glob patterns to ignore",
                        "items": { "type": "string" }
                    }
                }
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: LsParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let path = if let Some(dir) = &self.working_dir {
            Path::new(dir).join(&params.path)
        } else {
            Path::new(&params.path).to_path_buf()
        };

        let mut result = Vec::new();

        fn list_dir(path: &Path, prefix: String, result: &mut Vec<String>, ignore: &[String]) {
            if let Ok(entries) = std::fs::read_dir(path) {
                let mut entries: Vec<_> = entries.filter_map(|e| e.ok()).collect();
                entries.sort_by_key(|e| e.file_name());

                for entry in entries {
                    let name = entry.file_name().to_string_lossy().to_string();

                    // Skip hidden files
                    if name.starts_with('.') {
                        continue;
                    }

                    // Check ignore patterns
                    let should_ignore = ignore.iter().any(|pattern| {
                        glob::Pattern::new(pattern)
                            .map(|p| p.matches(&name))
                            .unwrap_or(false)
                    });

                    if should_ignore {
                        continue;
                    }

                    let entry_path = entry.path();
                    if entry_path.is_dir() {
                        result.push(format!("{}{}/", prefix, name));
                        list_dir(&entry_path, format!("{}  ", prefix), result, ignore);
                    } else {
                        result.push(format!("{}{}", prefix, name));
                    }
                }
            }
        }

        if path.is_dir() {
            result.push(format!("{}/", path.display()));
            list_dir(&path, "  ".to_string(), &mut result, &params.ignore);
        } else if path.exists() {
            result.push(path.display().to_string());
        } else {
            return Ok(ToolResponse::error(format!(
                "Path not found: {}",
                path.display()
            )));
        }

        Ok(ToolResponse::text(result.join("\n")))
    }
}
