//! View tool - Read file contents.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio;

/// View tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ViewParams {
    /// The file path to read.
    pub file_path: String,
    /// Starting line offset (0-based).
    #[serde(default)]
    pub offset: usize,
    /// Number of lines to read.
    #[serde(default = "default_limit")]
    pub limit: usize,
}

fn default_limit() -> usize {
    2000
}

/// View tool implementation.
pub struct ViewTool {
    working_dir: Option<String>,
}

impl ViewTool {
    /// Create a new view tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for ViewTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "view".to_string(),
            description: "Read file contents with line numbers.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "file_path": { "type": "string", "description": "File path" },
                    "offset": { "type": "integer", "description": "Start line (0-based)" },
                    "limit": { "type": "integer", "description": "Max lines" }
                },
                "required": ["file_path"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: ViewParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let path = self
            .working_dir
            .as_ref()
            .map(|d| Path::new(d).join(&params.file_path))
            .unwrap_or_else(|| Path::new(&params.file_path).to_path_buf());

        let content = tokio::fs::read_to_string(&path)
            .await
            .map_err(|e| crate::Error::Tool(format!("Read failed: {}", e)))?;

        let lines: Vec<&str> = content.lines().collect();
        let total = lines.len();
        let start = params.offset.min(total);
        let end = (start + params.limit).min(total);

        let result: String = lines[start..end]
            .iter()
            .enumerate()
            .map(|(i, line)| format!("{:6}\t{}", start + i + 1, line))
            .collect::<Vec<_>>()
            .join("\n");

        Ok(ToolResponse::text(format!(
            "File: {} ({}-{} of {})\n{}\n{}",
            path.display(),
            start + 1,
            end,
            total,
            "─".repeat(50),
            result
        )))
    }
}
