//! Tool definitions for BKG.

mod bash;
mod edit;
mod fetch;
mod glob;
mod grep;
mod ls;
mod multiedit;
mod view;
mod write;

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Result type alias for tool operations.
pub type AgentResult<T> = std::result::Result<T, Error>;

/// Tool error type.
#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("invalid input: {0}")]
    InvalidInput(String),

    #[error("HTTP error: {0}")]
    Http(String),

    #[error("tool error: {0}")]
    Tool(String),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
}

/// Result alias for tool operations.
pub type Result<T> = std::result::Result<T, Error>;

pub use bash::BashTool;
pub use edit::EditTool;
pub use fetch::FetchTool;
pub use glob::GlobTool;
pub use grep::GrepTool;
pub use ls::LsTool;
pub use multiedit::MultieditTool;
pub use view::ViewTool;
pub use write::WriteTool;

/// Tool information.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolInfo {
    /// Tool name.
    pub name: String,
    /// Tool description.
    pub description: String,
    /// Input schema (JSON Schema).
    pub input_schema: serde_json::Value,
}

/// Tool call parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCall {
    /// Tool call ID.
    pub id: String,
    /// Tool name.
    pub name: String,
    /// Tool input as JSON.
    pub input: serde_json::Value,
}

impl ToolCall {
    /// Create a new tool call.
    pub fn new(id: impl Into<String>, name: impl Into<String>, input: serde_json::Value) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            input,
        }
    }
}

/// Tool response metadata.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ToolResponseMetadata {
    /// Additional metadata fields.
    #[serde(flatten)]
    pub fields: HashMap<String, serde_json::Value>,
}

/// Tool response.
#[derive(Debug, Clone)]
pub struct ToolResponse {
    /// Response content.
    pub content: String,
    /// Whether this is an error.
    pub is_error: bool,
    /// Whether to stop the turn.
    pub stop_turn: bool,
    /// Additional metadata.
    pub metadata: ToolResponseMetadata,
}

impl ToolResponse {
    /// Create a new text response.
    pub fn text(content: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            is_error: false,
            stop_turn: false,
            metadata: ToolResponseMetadata::default(),
        }
    }

    /// Create a new error response.
    pub fn error(content: impl Into<String>) -> Self {
        Self {
            content: content.into(),
            is_error: true,
            stop_turn: false,
            metadata: ToolResponseMetadata::default(),
        }
    }

    /// Create a permission denied response.
    pub fn permission_denied() -> Self {
        Self {
            content: "User denied permission".to_string(),
            is_error: true,
            stop_turn: true,
            metadata: ToolResponseMetadata::default(),
        }
    }

    /// Add metadata to the response.
    pub fn with_metadata(mut self, key: impl Into<String>, value: serde_json::Value) -> Self {
        self.metadata.fields.insert(key.into(), value);
        self
    }
}

/// Tool trait.
#[async_trait]
pub trait Tool: Send + Sync {
    /// Get tool information.
    fn info(&self) -> ToolInfo;

    /// Run the tool.
    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse>;
}

/// Tool registry.
pub struct ToolRegistry {
    tools: HashMap<String, Box<dyn Tool>>,
}

impl ToolRegistry {
    /// Create a new tool registry.
    pub fn new() -> Self {
        Self {
            tools: HashMap::new(),
        }
    }

    /// Register a tool.
    pub fn register(&mut self, tool: Box<dyn Tool>) {
        let info = tool.info();
        self.tools.insert(info.name, tool);
    }

    /// Get a tool by name.
    pub fn get(&self, name: &str) -> Option<&dyn Tool> {
        self.tools.get(name).map(|t| t.as_ref())
    }

    /// List all tools.
    pub fn list(&self) -> Vec<&dyn Tool> {
        self.tools.values().map(|t| t.as_ref()).collect()
    }

    /// Get tool infos.
    pub fn infos(&self) -> Vec<ToolInfo> {
        self.tools.values().map(|t| t.info()).collect()
    }

    /// Register all built-in tools.
    pub fn register_builtin(&mut self, working_dir: Option<String>) {
        self.register(Box::new(BashTool::new(working_dir.clone())));
        self.register(Box::new(EditTool::new(working_dir.clone())));
        self.register(Box::new(MultieditTool::new(working_dir.clone())));
        self.register(Box::new(ViewTool::new(working_dir.clone())));
        self.register(Box::new(WriteTool::new(working_dir.clone())));
        self.register(Box::new(GrepTool::new(working_dir.clone())));
        self.register(Box::new(GlobTool::new(working_dir.clone())));
        self.register(Box::new(LsTool::new(working_dir)));
        self.register(Box::new(FetchTool::new()));
    }
}

impl Default for ToolRegistry {
    fn default() -> Self {
        Self::new()
    }
}
