//! Write tool - Write or overwrite files.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio;

/// Write tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WriteParams {
    /// The file path to write.
    pub file_path: String,
    /// The content to write.
    pub content: String,
}

/// Write tool implementation.
pub struct WriteTool {
    working_dir: Option<String>,
}

impl WriteTool {
    /// Create a new write tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for WriteTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "write".to_string(),
            description: "Write content to a file.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "file_path": { "type": "string", "description": "File path" },
                    "content": { "type": "string", "description": "Content to write" }
                },
                "required": ["file_path", "content"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: WriteParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let path = self
            .working_dir
            .as_ref()
            .map(|d| Path::new(d).join(&params.file_path))
            .unwrap_or_else(|| Path::new(&params.file_path).to_path_buf());

        if let Some(parent) = path.parent() {
            tokio::fs::create_dir_all(parent)
                .await
                .map_err(|e| crate::Error::Tool(format!("Create dir failed: {}", e)))?;
        }

        tokio::fs::write(&path, &params.content)
            .await
            .map_err(|e| crate::Error::Tool(format!("Write failed: {}", e)))?;

        Ok(ToolResponse::text(format!(
            "Wrote {} lines to {}",
            params.content.lines().count(),
            path.display()
        )))
    }
}
