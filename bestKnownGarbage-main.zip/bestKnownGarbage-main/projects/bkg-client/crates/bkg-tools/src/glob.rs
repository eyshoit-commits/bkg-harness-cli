//! Glob tool - Find files by pattern.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use glob;
use serde::{Deserialize, Serialize};

/// Glob tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlobParams {
    /// The glob pattern.
    pub pattern: String,
    /// The path to search in.
    #[serde(default = "default_path")]
    pub path: String,
}

fn default_path() -> String {
    ".".to_string()
}

/// Glob tool implementation.
pub struct GlobTool {
    working_dir: Option<String>,
}

impl GlobTool {
    /// Create a new glob tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for GlobTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "glob".to_string(),
            description: "Find files matching glob pattern.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "pattern": { "type": "string", "description": "Glob pattern (e.g. **/*.rs)" },
                    "path": { "type": "string", "description": "Search path" }
                },
                "required": ["pattern"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: GlobParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let search_path = self
            .working_dir
            .as_ref()
            .map(|d| std::path::Path::new(d).join(&params.path))
            .unwrap_or_else(|| std::path::Path::new(&params.path).to_path_buf());

        let full_pattern = search_path.join(&params.pattern);
        let mut results = Vec::new();

        for entry in glob::glob(&full_pattern.to_string_lossy())
            .map_err(|e| crate::Error::Tool(format!("Invalid pattern: {}", e)))?
            .flatten()
        {
            results.push(entry.display().to_string());
        }

        results.sort();
        results.dedup();

        if results.is_empty() {
            Ok(ToolResponse::text("No files found"))
        } else {
            Ok(ToolResponse::text(results.join("\n")))
        }
    }
}
