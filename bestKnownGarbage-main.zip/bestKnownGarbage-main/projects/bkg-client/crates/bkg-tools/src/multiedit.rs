//! Multiedit tool - Apply multiple edits to a file.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::path::Path;
use tokio;

/// Single edit operation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditOperation {
    /// The text to find.
    pub old_string: String,
    /// The replacement text.
    pub new_string: String,
    /// Replace all occurrences.
    #[serde(default)]
    pub replace_all: bool,
}

/// Multiedit tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MultieditParams {
    /// The file path to edit.
    pub file_path: String,
    /// The edit operations.
    pub edits: Vec<EditOperation>,
}

/// Multiedit tool implementation.
pub struct MultieditTool {
    working_dir: Option<String>,
}

impl MultieditTool {
    /// Create a new multiedit tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for MultieditTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "multiedit".to_string(),
            description: "Apply multiple edits to a file.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "file_path": { "type": "string", "description": "File path" },
                    "edits": {
                        "type": "array",
                        "description": "Edit operations",
                        "items": {
                            "type": "object",
                            "properties": {
                                "old_string": { "type": "string" },
                                "new_string": { "type": "string" },
                                "replace_all": { "type": "boolean" }
                            },
                            "required": ["old_string", "new_string"]
                        }
                    }
                },
                "required": ["file_path", "edits"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: MultieditParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let path = self
            .working_dir
            .as_ref()
            .map(|d| Path::new(d).join(&params.file_path))
            .unwrap_or_else(|| Path::new(&params.file_path).to_path_buf());

        let mut content = tokio::fs::read_to_string(&path)
            .await
            .map_err(|e| crate::Error::Tool(format!("Read failed: {}", e)))?;

        let mut successful = 0;
        let mut errors = Vec::new();

        for (i, edit) in params.edits.iter().enumerate() {
            let count = content.matches(&edit.old_string).count();

            if count == 0 {
                errors.push(format!("Edit {}: not found", i + 1));
                continue;
            }

            if count > 1 && !edit.replace_all {
                errors.push(format!("Edit {}: multiple matches", i + 1));
                continue;
            }

            content = if edit.replace_all {
                content.replace(&edit.old_string, &edit.new_string)
            } else {
                content.replacen(&edit.old_string, &edit.new_string, 1)
            };

            successful += 1;
        }

        tokio::fs::write(&path, &content)
            .await
            .map_err(|e| crate::Error::Tool(format!("Write failed: {}", e)))?;

        if errors.is_empty() {
            Ok(ToolResponse::text(format!(
                "Applied {} edits to {}",
                successful,
                path.display()
            )))
        } else {
            Ok(ToolResponse::text(format!(
                "Applied {}/{} edits:\n{}",
                successful,
                params.edits.len(),
                errors.join("\n")
            )))
        }
    }
}
