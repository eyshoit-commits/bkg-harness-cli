//! Bash tool - Execute shell commands.

use crate::AgentResult;
use crate::{Tool, ToolCall, ToolInfo, ToolResponse};
use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use std::process::Command;

/// Bash tool parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BashParams {
    /// The command to execute.
    pub command: String,
    /// Working directory.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub working_dir: Option<String>,
    /// Description of the command.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
}

/// Bash tool implementation.
pub struct BashTool {
    working_dir: Option<String>,
}

impl BashTool {
    /// Create a new bash tool with optional working directory.
    pub fn new(working_dir: Option<String>) -> Self {
        Self { working_dir }
    }
}

#[async_trait]
impl Tool for BashTool {
    fn info(&self) -> ToolInfo {
        ToolInfo {
            name: "bash".to_string(),
            description: "Execute a shell command.".to_string(),
            input_schema: serde_json::json!({
                "type": "object",
                "properties": {
                    "command": {
                        "type": "string",
                        "description": "The command to execute"
                    },
                    "working_dir": {
                        "type": "string",
                        "description": "The working directory"
                    },
                    "description": {
                        "type": "string",
                        "description": "Brief description of the command"
                    }
                },
                "required": ["command"]
            }),
        }
    }

    async fn run(&self, call: ToolCall) -> AgentResult<ToolResponse> {
        let params: BashParams = serde_json::from_value(call.input)
            .map_err(|e| crate::Error::InvalidInput(e.to_string()))?;

        let output = if cfg!(target_os = "windows") {
            Command::new("cmd")
                .args(["/C", &params.command])
                .current_dir(self.working_dir.as_deref().unwrap_or("."))
                .output()
        } else {
            Command::new("sh")
                .args(["-c", &params.command])
                .current_dir(self.working_dir.as_deref().unwrap_or("."))
                .output()
        }
        .map_err(|e| crate::Error::Tool(format!("Failed to execute: {}", e)))?;

        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);

        let result = if output.status.success() {
            if stdout.is_empty() {
                "no output".to_string()
            } else {
                stdout.to_string()
            }
        } else {
            format!("Error: {}\n{}", output.status, stderr)
        };

        Ok(ToolResponse::text(result))
    }
}
