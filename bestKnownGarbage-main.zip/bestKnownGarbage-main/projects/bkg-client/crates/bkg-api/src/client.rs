//! Generic HTTP API client for LLM providers.

use crate::BkgResult;
use bkg_core::BkgError;
use reqwest::Client as HttpClient;
use std::time::Duration;

/// Configuration for an API client.
#[derive(Debug, Clone)]
pub struct ApiClientConfig {
    /// Base URL for the API.
    pub base_url: String,
    /// API key.
    pub api_key: Option<String>,
    /// Request timeout.
    pub timeout: Duration,
    /// Custom headers.
    pub headers: Vec<(String, String)>,
}

impl Default for ApiClientConfig {
    fn default() -> Self {
        Self {
            base_url: String::new(),
            api_key: None,
            timeout: Duration::from_secs(120),
            headers: Vec::new(),
        }
    }
}

/// Generic HTTP API client.
#[derive(Debug, Clone)]
pub struct ApiClient {
    pub config: ApiClientConfig,
    pub client: HttpClient,
}

impl ApiClient {
    /// Create a new API client.
    pub fn new(config: ApiClientConfig) -> BkgResult<Self> {
        let client = HttpClient::builder()
            .timeout(config.timeout)
            .build()
            .map_err(|e| BkgError::Provider(format!("Failed to create HTTP client: {e}")))?;

        Ok(Self { config, client })
    }

    /// Build headers for a request, merging defaults with extras.
    pub fn build_headers(&self) -> Vec<(String, String)> {
        self.config.headers.clone()
    }
}
