//! Streaming response handling for SSE-based providers.

use crate::{BkgResult, StreamChunk, StreamIterator};
use async_trait::async_trait;

/// Iterator over SSE stream chunks.
pub struct SseStream {
    chunks: Vec<BkgResult<StreamChunk>>,
    position: usize,
}

impl SseStream {
    /// Create a new SSE stream from a vector of chunks.
    pub fn new(chunks: Vec<BkgResult<StreamChunk>>) -> Self {
        Self {
            chunks,
            position: 0,
        }
    }
}

#[async_trait]
impl StreamIterator for SseStream {
    async fn next(&mut self) -> Option<BkgResult<StreamChunk>> {
        if self.position < self.chunks.len() {
            let result = self.chunks.remove(self.position);
            Some(result)
        } else {
            None
        }
    }
}
