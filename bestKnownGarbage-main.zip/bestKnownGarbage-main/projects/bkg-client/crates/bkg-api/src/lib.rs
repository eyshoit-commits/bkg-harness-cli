//! LLM API client — HTTP transport layer for provider communication.
//!
//! This crate handles:
//! - HTTP request construction and signing
//! - Response parsing
//! - Streaming response handling (SSE)
//! - Retry and error handling

use async_trait::async_trait;

pub mod client;
pub mod streaming;

pub use client::*;
pub use streaming::*;

/// Result type for API operations.
pub type BkgResult<T> = std::result::Result<T, bkg_core::BkgError>;

/// A chunk of a streaming response.
#[derive(Debug, Clone)]
pub struct StreamChunk {
    /// The text content of this chunk (may be partial).
    pub content: String,
    /// Whether this is the final chunk.
    pub is_final: bool,
}

/// Async iterator over stream chunks.
#[async_trait]
pub trait StreamIterator: Send {
    /// Get the next chunk from the stream.
    async fn next(&mut self) -> Option<BkgResult<StreamChunk>>;
}
