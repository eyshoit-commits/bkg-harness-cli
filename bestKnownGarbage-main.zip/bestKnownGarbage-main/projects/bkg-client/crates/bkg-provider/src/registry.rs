//! Provider registry — runtime registration and lookup of LLM providers.

use super::LLMProvider;
use std::collections::HashMap;
use std::sync::Arc;

/// Registry of available LLM providers.
#[derive(Default, Clone)]
pub struct ProviderRegistry {
    providers: HashMap<String, Arc<dyn LLMProvider + Send + Sync>>,
}

impl ProviderRegistry {
    /// Create a new empty registry.
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a provider by name.
    pub fn register(
        &mut self,
        name: impl Into<String>,
        provider: Arc<dyn LLMProvider + Send + Sync>,
    ) {
        self.providers.insert(name.into(), provider);
    }

    /// Get a provider by name.
    pub fn get(&self, name: &str) -> Option<&Arc<dyn LLMProvider + Send + Sync>> {
        self.providers.get(name)
    }

    /// List all registered provider names.
    pub fn list(&self) -> Vec<String> {
        self.providers.keys().cloned().collect()
    }

    /// Check if a provider is registered.
    pub fn has(&self, name: &str) -> bool {
        self.providers.contains_key(name)
    }

    /// Get the total number of registered providers.
    pub fn len(&self) -> usize {
        self.providers.len()
    }

    /// Check if the registry is empty.
    pub fn is_empty(&self) -> bool {
        self.providers.is_empty()
    }

    /// Register all default providers from environment variables.
    pub fn register_defaults(&mut self) {
        // OpenAI
        if let Ok(key) = std::env::var("OPENAI_API_KEY") {
            if !key.is_empty() {
                let provider = super::OpenAIProvider::new(key.clone());
                self.register("openai", Arc::new(provider));
                // Also try to register with custom base URL
                if let Ok(base_url) = std::env::var("OPENAI_BASE_URL") {
                    if !base_url.is_empty() {
                        let provider = super::OpenAIProvider::with_base_url(key, base_url);
                        self.register("openai-custom", Arc::new(provider));
                    }
                }
            }
        }

        // Anthropic
        if let Ok(key) = std::env::var("ANTHROPIC_API_KEY") {
            if !key.is_empty() {
                let provider = super::AnthropicProvider::new(key);
                self.register("anthropic", Arc::new(provider));
            }
        }

        // Google Gemini
        if let Ok(key) = std::env::var("GEMINI_API_KEY") {
            if !key.is_empty() {
                let provider = super::GeminiProvider::new(key);
                self.register("gemini", Arc::new(provider));
            }
        }

        // Ollama (local, no API key needed)
        let ollama_url =
            std::env::var("OLLAMA_URL").unwrap_or_else(|_| "http://localhost:11434".to_string());
        {
            let provider = super::OllamaProvider::new(&ollama_url);
            self.register("ollama", Arc::new(provider));
        }

        // Groq
        if let Ok(key) = std::env::var("GROQ_API_KEY") {
            if !key.is_empty() {
                let provider = super::GroqProvider::new(key);
                self.register("groq", Arc::new(provider));
            }
        }

        // OpenRouter
        if let Ok(key) = std::env::var("OPENROUTER_API_KEY") {
            if !key.is_empty() {
                let provider = super::OpenRouterProvider::new(key);
                self.register("openrouter", Arc::new(provider));
            }
        }

        // NVIDIA NIM (main provider — checked early for priority)
        if let Ok(key) = std::env::var("NVIDIA_API_KEY") {
            if !key.is_empty() {
                let base_url = std::env::var("NVIDIA_BASE_URL")
                    .unwrap_or_else(|_| "https://integrate.api.nvidia.com/v1".to_string());
                let provider = super::NvidiaProvider::with_base_url(key.clone(), base_url.clone());
                self.register("nvidia", Arc::new(provider));
                // Also register a variant with explicit base URL label
                if base_url != "https://integrate.api.nvidia.com/v1" {
                    let provider2 = super::NvidiaProvider::new(key);
                    self.register("nvidia-custom", Arc::new(provider2));
                }
            }
        }

        // BKG_DEFAULT_PROVIDER env var can override ordering for `get_default()`
    }

    /// Get the default provider — checks BKG_DEFAULT_PROVIDER, then NVIDIA, then OpenAI, then first available.
    pub fn get_default(&self) -> Option<&Arc<dyn LLMProvider + Send + Sync>> {
        // Check env override first
        if let Ok(name) = std::env::var("BKG_DEFAULT_PROVIDER") {
            if let Some(p) = self.get(&name) {
                return Some(p);
            }
        }

        // Prefer NVIDIA if available
        if let Some(p) = self.get("nvidia") {
            return Some(p);
        }

        // Then OpenAI
        if let Some(p) = self.get("openai") {
            return Some(p);
        }

        // Then Anthropic
        if let Some(p) = self.get("anthropic") {
            return Some(p);
        }

        // Fall back to first available
        self.providers.values().next()
    }
}
