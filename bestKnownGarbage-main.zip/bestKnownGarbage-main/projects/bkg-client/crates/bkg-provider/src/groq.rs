//! Groq LLM Provider.
//!
//! Uses Groq's OpenAI-compatible API.
//! API reference: https://console.groq.com/docs/api-reference

use super::*;
use reqwest::Client;
use serde_json::Value;

/// Groq provider using OpenAI-compatible API.
pub struct GroqProvider {
    client: Client,
    api_key: String,
}

impl GroqProvider {
    /// Create a new Groq provider.
    pub fn new(api_key: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
        }
    }
}

#[async_trait]
impl LLMProvider for GroqProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let url = "https://api.groq.com/openai/v1/chat/completions";

        let msgs: Vec<Value> = messages
            .iter()
            .map(|m| {
                let role_str = match m.role {
                    MessageRole::User => "user",
                    MessageRole::Assistant => "assistant",
                    MessageRole::System => "system",
                    MessageRole::Tool => "tool",
                };
                let text = m.content.clone().unwrap_or_default();
                serde_json::json!({
                    "role": role_str,
                    "content": text
                })
            })
            .collect();

        let mut req_body = serde_json::Map::new();
        req_body.insert("model".to_string(), Value::String(options.model.clone()));
        req_body.insert("messages".to_string(), Value::Array(msgs));

        if let Some(max_tokens) = options.max_tokens {
            req_body.insert("max_tokens".to_string(), serde_json::json!(max_tokens));
        }
        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), serde_json::json!(temp));
        }

        let response = self
            .client
            .post(url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        let content = json
            .get("choices")
            .and_then(|c| c.get(0))
            .and_then(|c| c.get("message"))
            .and_then(|m| m.get("content"))
            .and_then(|c| c.as_str())
            .unwrap_or("")
            .to_string();

        let usage = json.get("usage").and_then(|u| {
            let prompt_tokens = u.get("prompt_tokens")?.as_u64()? as u32;
            let completion_tokens = u.get("completion_tokens")?.as_u64()? as u32;
            let total_tokens = u.get("total_tokens")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls: vec![],
            finish_reason: None,
            usage,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        Err(ProviderError::Provider(
            "Groq streaming not yet implemented".to_string(),
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "llama-3.3-70b-versatile".to_string(),
                name: "Llama 3.3 70B".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "llama-3.1-8b-instant".to_string(),
                name: "Llama 3.1 8B (Instant)".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "mixtral-8x7b-32768".to_string(),
                name: "Mixtral 8x7B".to_string(),
                context_length: 32768,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "gemma2-9b-it".to_string(),
                name: "Gemma 2 9B".to_string(),
                context_length: 8192,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}
