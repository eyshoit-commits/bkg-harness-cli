//! Google Gemini LLM Provider.
//!
//! Uses the Google Gemini API directly via HTTP.
//! API reference: https://ai.google.dev/api/generate-content

use super::*;
use reqwest::Client;
use serde_json::Value;

/// Gemini provider using direct HTTP.
pub struct GeminiProvider {
    client: Client,
    api_key: String,
}

impl GeminiProvider {
    /// Create a new Gemini provider.
    pub fn new(api_key: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
        }
    }
}

#[async_trait]
impl LLMProvider for GeminiProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let model = &options.model;
        let url = format!(
            "https://generativelanguage.googleapis.com/v1/models/{}:generateContent?key={}",
            model, self.api_key
        );

        // Build Gemini-format contents
        let mut contents: Vec<Value> = Vec::new();
        let mut system_instruction: Option<String> = None;

        for msg in messages {
            match msg.role {
                MessageRole::System => {
                    system_instruction = msg.content.clone();
                }
                _ => {
                    let role_str = match msg.role {
                        MessageRole::User => "user",
                        MessageRole::Assistant => "model",
                        _ => "user",
                    };
                    let text = msg.content.clone().unwrap_or_default();
                    contents.push(serde_json::json!({
                        "role": role_str,
                        "parts": [{"text": text}]
                    }));
                }
            }
        }

        let mut req_body = serde_json::Map::new();
        req_body.insert("contents".to_string(), Value::Array(contents));

        if let Some(system) = system_instruction {
            req_body.insert(
                "system_instruction".to_string(),
                serde_json::json!({
                    "parts": [{"text": system}]
                }),
            );
        }

        // Generation config
        let mut gen_config = serde_json::Map::new();
        if let Some(max_tokens) = options.max_tokens {
            gen_config.insert("maxOutputTokens".to_string(), serde_json::json!(max_tokens));
        }
        if let Some(temp) = options.temperature {
            gen_config.insert("temperature".to_string(), serde_json::json!(temp));
        }
        if !gen_config.is_empty() {
            req_body.insert("generationConfig".to_string(), Value::Object(gen_config));
        }

        let response = self
            .client
            .post(&url)
            .header("Content-Type", "application/json")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        // Extract text from Gemini response
        let content = json
            .get("candidates")
            .and_then(|c| c.get(0))
            .and_then(|c| c.get("content"))
            .and_then(|c| c.get("parts"))
            .and_then(|p| p.as_array())
            .and_then(|parts| {
                parts
                    .iter()
                    .find_map(|part| part.get("text").and_then(|t| t.as_str()).map(String::from))
            })
            .unwrap_or_default();

        // Gemini doesn't return token counts in the same way
        let usage = json.get("usageMetadata").and_then(|u| {
            let prompt_tokens = u.get("promptTokenCount")?.as_u64()? as u32;
            let completion_tokens = u.get("candidatesTokenCount")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens: prompt_tokens + completion_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls: vec![],
            finish_reason: None,
            usage,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        Err(ProviderError::Provider(
            "Gemini streaming not yet implemented".to_string(),
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "gemini-2.5-pro-exp-03-25".to_string(),
                name: "Gemini 2.5 Pro (experimental)".to_string(),
                context_length: 1_000_000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "gemini-2.0-flash".to_string(),
                name: "Gemini 2.0 Flash".to_string(),
                context_length: 1_000_000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "gemini-2.0-flash-lite".to_string(),
                name: "Gemini 2.0 Flash Lite".to_string(),
                context_length: 1_000_000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}
