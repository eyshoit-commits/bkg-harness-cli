//! LLM Provider abstraction for BKG.
//!
//! Defines a unified interface for interacting with various LLM backends
//! (OpenAI, Anthropic, etc.).

use async_trait::async_trait;
use serde::{Deserialize, Serialize};

pub mod anthropic;
pub mod gemini;
pub mod groq;
pub mod nvidia;
pub mod ollama;
pub mod openai;
pub mod openrouter;
pub mod registry;

pub use anthropic::AnthropicProvider;
pub use gemini::GeminiProvider;
pub use groq::GroqProvider;
pub use nvidia::NvidiaProvider;
pub use ollama::OllamaProvider;
pub use openai::OpenAIProvider;
pub use openrouter::OpenRouterProvider;
pub use registry::ProviderRegistry;

/// A tool call from the LLM.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LLMToolCall {
    /// Tool call ID.
    pub id: String,
    /// Tool name.
    pub name: String,
    /// JSON arguments string.
    pub arguments: String,
}

/// A tool definition to send to the LLM provider.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolDefinition {
    /// Tool name.
    pub name: String,
    /// Tool description.
    pub description: String,
    /// Input schema (JSON Schema).
    pub input_schema: serde_json::Value,
}

/// A message in a conversation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatMessage {
    /// The role of the message sender.
    pub role: MessageRole,
    /// The content of the message (None for tool-call-only assistant messages).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content: Option<String>,
    /// Tool calls (for assistant messages).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tool_calls: Option<Vec<LLMToolCall>>,
    /// Tool call ID (for tool-result messages).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tool_call_id: Option<String>,
}

impl ChatMessage {
    /// Create a user message.
    pub fn user(content: impl Into<String>) -> Self {
        Self {
            role: MessageRole::User,
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    /// Create an assistant text message.
    pub fn assistant(content: impl Into<String>) -> Self {
        Self {
            role: MessageRole::Assistant,
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    /// Create a system message.
    pub fn system(content: impl Into<String>) -> Self {
        Self {
            role: MessageRole::System,
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    /// Create a tool result message.
    pub fn tool_result(tool_call_id: impl Into<String>, content: impl Into<String>) -> Self {
        Self {
            role: MessageRole::Tool,
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: Some(tool_call_id.into()),
        }
    }

    /// Create an assistant message with tool calls (no text content).
    pub fn tool_call(tool_calls: Vec<LLMToolCall>) -> Self {
        Self {
            role: MessageRole::Assistant,
            content: None,
            tool_calls: Some(tool_calls),
            tool_call_id: None,
        }
    }

    /// Get the text content, if any.
    pub fn text(&self) -> Option<&str> {
        self.content.as_deref()
    }
}

/// Role of the message sender.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    /// User message.
    User,
    /// Assistant message.
    Assistant,
    /// System message.
    System,
    /// Tool result message.
    Tool,
}

/// Options for a provider call.
#[derive(Debug, Clone)]
pub struct ProviderOptions {
    /// Model to use (e.g., "gpt-4", "claude-sonnet-4").
    pub model: String,
    /// Maximum tokens to generate.
    pub max_tokens: Option<u32>,
    /// Temperature for sampling.
    pub temperature: Option<f32>,
    /// Stop sequences.
    pub stop: Vec<String>,
    /// Tool definitions to send to the provider.
    pub tools: Vec<ToolDefinition>,
    /// Additional provider-specific parameters.
    pub extra: serde_json::Value,
}

impl Default for ProviderOptions {
    fn default() -> Self {
        Self {
            model: String::new(),
            max_tokens: Some(4096),
            temperature: Some(0.7),
            stop: Vec::new(),
            tools: Vec::new(),
            extra: serde_json::Value::Null,
        }
    }
}

/// Result of a provider call.
#[derive(Debug, Clone)]
pub struct ProviderResponse {
    /// The generated content (empty string if only tool calls).
    pub content: String,
    /// Tool calls requested by the model.
    pub tool_calls: Vec<LLMToolCall>,
    /// Token usage statistics if available.
    pub usage: Option<TokenUsage>,
    /// Finish reason.
    pub finish_reason: Option<String>,
    /// Raw provider response for debugging.
    pub raw: Option<serde_json::Value>,
}

/// Token usage statistics.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenUsage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub total_tokens: u32,
}

/// A streaming chunk from a provider.
#[derive(Debug, Clone)]
pub struct StreamChunk {
    /// The text content of this chunk (may be partial).
    pub content: String,
    /// Whether this is the final chunk.
    pub is_final: bool,
    /// Any accumulated usage (usually sent in final chunk).
    pub usage: Option<TokenUsage>,
}

/// Errors that can occur during provider operations.
#[derive(Debug, thiserror::Error)]
pub enum ProviderError {
    #[error("authentication error: {0}")]
    Auth(String),

    #[error("network error: {0}")]
    Network(String),

    #[error("provider error: {0}")]
    Provider(String),

    #[error("rate limited: {0}")]
    RateLimited(String),

    #[error("invalid request: {0}")]
    InvalidRequest(String),

    #[error("model not found: {0}")]
    ModelNotFound(String),

    #[error("unknown error: {0}")]
    Unknown(String),
}

/// Result type for provider operations.
pub type ProviderResult<T> = Result<T, ProviderError>;

/// Async trait for LLM providers.
#[async_trait]
pub trait LLMProvider: Send + Sync {
    /// Send a non-streaming chat completion request.
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse>;

    /// Send a streaming chat completion request.
    async fn chat_stream(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>>;

    /// List available models for this provider.
    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>>;

    /// Check if the provider is properly configured/authenticated.
    async fn health_check(&self) -> ProviderResult<()>;
}

/// Information about an LLM model.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInfo {
    /// Model identifier (e.g., "gpt-4").
    pub id: String,
    /// Human-readable name.
    pub name: String,
    /// Maximum context length.
    pub context_length: u32,
    /// Pricing information (per 1k tokens) if available.
    pub pricing: Option<ModelPricing>,
}

/// Pricing details for a model.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelPricing {
    pub prompt_per_1k: f64,
    pub completion_per_1k: f64,
}
