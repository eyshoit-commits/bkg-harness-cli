//! OpenAI LLM Provider (reqwest-based implementation with tool support).

use super::*;
use reqwest::Client;
use serde_json::Value;

/// OpenAI provider using direct HTTP.
pub struct OpenAIProvider {
    client: Client,
    api_key: String,
    base_url: Option<String>,
}

impl OpenAIProvider {
    /// Create a new OpenAI provider with the given API key.
    pub fn new(api_key: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url: None,
        }
    }

    /// Create with custom base URL.
    pub fn with_base_url(api_key: impl Into<String>, base_url: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url: Some(base_url.into()),
        }
    }
}

#[async_trait]
impl LLMProvider for OpenAIProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let url = self
            .base_url
            .as_deref()
            .unwrap_or("https://api.openai.com/v1/chat/completions");

        // Build request body
        let mut req_body = serde_json::Map::new();
        req_body.insert(
            "model".to_string(),
            serde_json::Value::String(options.model.clone()),
        );

        // Build messages array
        let msgs: Vec<Value> = messages
            .iter()
            .map(|m| {
                let mut msg = serde_json::Map::new();
                msg.insert(
                    "role".to_string(),
                    serde_json::Value::String(m.role.to_string()),
                );

                // Content field (null for tool-call-only assistant messages)
                msg.insert(
                    "content".to_string(),
                    match &m.content {
                        Some(c) => serde_json::Value::String(c.clone()),
                        None => serde_json::Value::Null,
                    },
                );

                // Tool calls (for assistant messages)
                if let Some(tool_calls) = &m.tool_calls {
                    let tc_array: Vec<Value> = tool_calls
                        .iter()
                        .map(|tc| {
                            serde_json::json!({
                                "id": tc.id,
                                "type": "function",
                                "function": {
                                    "name": tc.name,
                                    "arguments": tc.arguments
                                }
                            })
                        })
                        .collect();
                    msg.insert("tool_calls".to_string(), serde_json::Value::Array(tc_array));
                }

                // Tool call ID (for tool result messages)
                if let Some(tc_id) = &m.tool_call_id {
                    msg.insert(
                        "tool_call_id".to_string(),
                        serde_json::Value::String(tc_id.clone()),
                    );
                }

                serde_json::Value::Object(msg)
            })
            .collect();
        req_body.insert("messages".to_string(), serde_json::Value::Array(msgs));

        // Add tools if provided
        if !options.tools.is_empty() {
            let tools_array: Vec<Value> = options
                .tools
                .iter()
                .map(|t| {
                    serde_json::json!({
                        "type": "function",
                        "function": {
                            "name": t.name,
                            "description": t.description,
                            "parameters": t.input_schema
                        }
                    })
                })
                .collect();
            req_body.insert("tools".to_string(), serde_json::Value::Array(tools_array));
        }

        if let Some(max_tokens) = options.max_tokens {
            req_body.insert("max_tokens".to_string(), max_tokens.into());
        }
        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), temp.into());
        }
        if !options.stop.is_empty() {
            req_body.insert(
                "stop".to_string(),
                serde_json::to_value(&options.stop).unwrap(),
            );
        }

        let response = self
            .client
            .post(url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        // Extract content
        let choices = json
            .get("choices")
            .and_then(|v| v.get(0))
            .ok_or_else(|| ProviderError::Provider("no choices returned".to_string()))?;

        let message = choices
            .get("message")
            .ok_or_else(|| ProviderError::Provider("no message in choice".to_string()))?;

        // Content may be null when there are tool calls
        let content = message
            .get("content")
            .and_then(|c| c.as_str())
            .unwrap_or("")
            .to_string();

        // Parse tool calls
        let tool_calls = message
            .get("tool_calls")
            .map(|tc| {
                tc.as_array()
                    .map(|arr| {
                        arr.iter()
                            .filter_map(|item| {
                                let id = item.get("id")?.as_str()?;
                                let function = item.get("function")?;
                                let name = function.get("name")?.as_str()?;
                                let arguments = function.get("arguments")?.as_str()?;
                                Some(LLMToolCall {
                                    id: id.to_string(),
                                    name: name.to_string(),
                                    arguments: arguments.to_string(),
                                })
                            })
                            .collect::<Vec<_>>()
                    })
                    .unwrap_or_default()
            })
            .unwrap_or_default();

        // Finish reason
        let finish_reason = choices
            .get("finish_reason")
            .and_then(|f| f.as_str())
            .map(|s| s.to_string());

        // Extract usage
        let usage = json.get("usage").and_then(|u| {
            let prompt_tokens = u.get("prompt_tokens")?.as_u64()? as u32;
            let completion_tokens = u.get("completion_tokens")?.as_u64()? as u32;
            let total_tokens = u.get("total_tokens")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls,
            usage,
            finish_reason,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        // Not implemented yet
        Err(ProviderError::Provider(
            "streaming not implemented".to_string(),
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "gpt-4o".to_string(),
                name: "GPT-4o".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0025,
                    completion_per_1k: 0.01,
                }),
            },
            ModelInfo {
                id: "gpt-4o-mini".to_string(),
                name: "GPT-4o Mini".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.00015,
                    completion_per_1k: 0.0006,
                }),
            },
            ModelInfo {
                id: "gpt-4-turbo".to_string(),
                name: "GPT-4 Turbo".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.01,
                    completion_per_1k: 0.03,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}

// Helper: convert MessageRole to string for API
impl std::fmt::Display for MessageRole {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            MessageRole::User => write!(f, "user"),
            MessageRole::Assistant => write!(f, "assistant"),
            MessageRole::System => write!(f, "system"),
            MessageRole::Tool => write!(f, "tool"),
        }
    }
}
