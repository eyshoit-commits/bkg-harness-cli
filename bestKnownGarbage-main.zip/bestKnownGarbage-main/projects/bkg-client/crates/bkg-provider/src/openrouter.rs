//! OpenRouter LLM Provider.
//!
//! Uses OpenRouter's unified API (OpenAI-compatible).
//! API reference: https://openrouter.ai/docs/api-reference

use super::*;
use reqwest::Client;
use serde_json::Value;

/// OpenRouter provider using OpenAI-compatible API.
pub struct OpenRouterProvider {
    client: Client,
    api_key: String,
}

impl OpenRouterProvider {
    /// Create a new OpenRouter provider.
    pub fn new(api_key: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
        }
    }
}

#[async_trait]
impl LLMProvider for OpenRouterProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let url = "https://openrouter.ai/api/v1/chat/completions";

        let msgs: Vec<Value> = messages
            .iter()
            .map(|m| {
                let role_str = match m.role {
                    MessageRole::User => "user",
                    MessageRole::Assistant => "assistant",
                    MessageRole::System => "system",
                    MessageRole::Tool => "tool",
                };
                let text = m.content.clone().unwrap_or_default();
                serde_json::json!({
                    "role": role_str,
                    "content": text
                })
            })
            .collect();

        let mut req_body = serde_json::Map::new();
        req_body.insert("model".to_string(), Value::String(options.model.clone()));
        req_body.insert("messages".to_string(), Value::Array(msgs));

        if let Some(max_tokens) = options.max_tokens {
            req_body.insert("max_tokens".to_string(), serde_json::json!(max_tokens));
        }
        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), serde_json::json!(temp));
        }

        let response = self
            .client
            .post(url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            // Identify the app to OpenRouter
            .header("HTTP-Referer", "https://github.com/charmbracelet/bkg-wasm")
            .header("X-Title", "BKG")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        let content = json
            .get("choices")
            .and_then(|c| c.get(0))
            .and_then(|c| c.get("message"))
            .and_then(|m| m.get("content"))
            .and_then(|c| c.as_str())
            .unwrap_or("")
            .to_string();

        let usage = json.get("usage").and_then(|u| {
            let prompt_tokens = u.get("prompt_tokens")?.as_u64()? as u32;
            let completion_tokens = u.get("completion_tokens")?.as_u64()? as u32;
            let total_tokens = u.get("total_tokens")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls: vec![],
            finish_reason: None,
            usage,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        Err(ProviderError::Provider(
            "OpenRouter streaming not yet implemented".to_string(),
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "anthropic/claude-sonnet-4".to_string(),
                name: "Claude Sonnet 4 (via OpenRouter)".to_string(),
                context_length: 200000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.003,
                    completion_per_1k: 0.015,
                }),
            },
            ModelInfo {
                id: "openai/gpt-4o".to_string(),
                name: "GPT-4o (via OpenRouter)".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0025,
                    completion_per_1k: 0.01,
                }),
            },
            ModelInfo {
                id: "google/gemini-2.0-flash-001".to_string(),
                name: "Gemini 2.0 Flash (via OpenRouter)".to_string(),
                context_length: 1_000_000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "meta-llama/llama-3.3-70b-instruct".to_string(),
                name: "Llama 3.3 70B (via OpenRouter)".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}
