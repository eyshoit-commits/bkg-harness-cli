//! NVIDIA NIM (OpenAI-compatible) LLM Provider.
//!
//! Uses NVIDIA's OpenAI-compatible API for running NIM microservices.
//! API reference: https://build.nvidia.com/docs
//!
//! Env vars:
//!   NVIDIA_API_KEY  — required, NVIDIA API key
//!   NVIDIA_BASE_URL — optional, defaults to https://api.nvcf.nvidia.com/v1

use super::*;
use futures_util::stream::StreamExt;
use reqwest::Client;
use serde_json::Value;
use tokio::sync::mpsc;

/// NVIDIA NIM provider using OpenAI-compatible API.
#[derive(Clone)]
pub struct NvidiaProvider {
    client: Client,
    api_key: String,
    base_url: String,
}

impl NvidiaProvider {
    /// Create a new NVIDIA NIM provider.
    pub fn new(api_key: impl Into<String>) -> Self {
        let base_url = std::env::var("NVIDIA_BASE_URL")
            .unwrap_or_else(|_| "https://integrate.api.nvidia.com/v1".to_string());
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url,
        }
    }

    /// Create with custom base URL.
    pub fn with_base_url(api_key: impl Into<String>, base_url: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url: base_url.into(),
        }
    }

    /// Check if HTTP response is successful.
    async fn is_success(&self, response: &reqwest::Response) -> bool {
        response.status().is_success()
    }
}

#[async_trait]
impl LLMProvider for NvidiaProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let url = format!("{}/chat/completions", self.base_url);

        let msgs: Vec<Value> = messages
            .iter()
            .map(|m| {
                let role_str = match m.role {
                    MessageRole::User => "user",
                    MessageRole::Assistant => "assistant",
                    MessageRole::System => "system",
                    MessageRole::Tool => "tool",
                };
                let text = m.content.clone().unwrap_or_default();
                serde_json::json!({
                    "role": role_str,
                    "content": text
                })
            })
            .collect();

        let mut req_body = serde_json::Map::new();
        req_body.insert("model".to_string(), Value::String(options.model.clone()));
        req_body.insert("messages".to_string(), Value::Array(msgs));

        if let Some(max_tokens) = options.max_tokens {
            req_body.insert("max_tokens".to_string(), serde_json::json!(max_tokens));
        }
        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), serde_json::json!(temp));
        }
        if !options.stop.is_empty() {
            req_body.insert(
                "stop".to_string(),
                serde_json::to_value(&options.stop).unwrap(),
            );
        }

        let response = self
            .client
            .post(&url)
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        let content = json
            .get("choices")
            .and_then(|c| c.get(0))
            .and_then(|c| c.get("message"))
            .and_then(|m| m.get("content"))
            .and_then(|c| c.as_str())
            .unwrap_or("")
            .to_string();

        let usage = json.get("usage").and_then(|u| {
            let prompt_tokens = u.get("prompt_tokens")?.as_u64()? as u32;
            let completion_tokens = u.get("completion_tokens")?.as_u64()? as u32;
            let total_tokens = u.get("total_tokens")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls: vec![],
            finish_reason: None,
            usage,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        let url = format!("{}/chat/completions", self.base_url);

        // Prepare request body (same as non-streaming)
        let msgs: Vec<Value> = messages
            .iter()
            .map(|m| {
                let role_str = match m.role {
                    MessageRole::User => "user",
                    MessageRole::Assistant => "assistant",
                    MessageRole::System => "system",
                    MessageRole::Tool => "tool",
                };
                let text = m.content.clone().unwrap_or_default();
                serde_json::json!({
                    "role": role_str,
                    "content": text
                })
            })
            .collect();

        let mut req_body = serde_json::Map::new();
        req_body.insert("model".to_string(), Value::String(options.model.clone()));
        req_body.insert("messages".to_string(), Value::Array(msgs));
        req_body.insert("stream".to_string(), Value::Bool(true)); // Enable streaming

        if let Some(max_tokens) = options.max_tokens {
            req_body.insert("max_tokens".to_string(), serde_json::json!(max_tokens));
        }
        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), serde_json::json!(temp));
        }
        if !options.stop.is_empty() {
            req_body.insert(
                "stop".to_string(),
                serde_json::to_value(&options.stop).unwrap(),
            );
        }

        // Create channel for streaming chunks
        let (tx, rx) = mpsc::channel(32);

        // Clone self to avoid lifetime issues in spawned task
        let this = self.clone();

        // Spawn streaming task
        tokio::spawn(async move {
            let result = async {
                let response = this
                    .client
                    .post(&url)
                    .header("Authorization", format!("Bearer {}", this.api_key))
                    .header("Content-Type", "application/json")
                    .json(&req_body)
                    .send()
                    .await
                    .map_err(|e| ProviderError::Network(e.to_string()))?;

                if !this.is_success(&response).await {
                    let status = response.status().as_u16();
                    let err_text = response
                        .text()
                        .await
                        .unwrap_or_else(|_| "Unknown error".to_string());
                    return Err(ProviderError::Provider(format!(
                        "HTTP {}: {}",
                        status, err_text
                    )));
                }

                let mut stream = response.bytes_stream();
                let mut buffer = String::new();

                while let Some(chunk_result) = stream.next().await {
                    let chunk = chunk_result.map_err(|e| ProviderError::Network(e.to_string()))?;
                    buffer.push_str(&String::from_utf8_lossy(&chunk));

                    // Process SSE lines - use take to avoid borrow conflicts
                    let lines_buf = std::mem::take(&mut buffer);
                    let mut lines: Vec<&str> = lines_buf.split('\n').collect();
                    // Keep last line (might be incomplete) in buffer
                    buffer = lines.pop().unwrap_or("").to_string();

                    for line in lines.iter() {
                        let line = line.trim();
                        if line.starts_with("data: ") {
                            let data = &line[6..]; // Skip "data: "
                            if data == "[DONE]" {
                                // Send final chunk
                                let _ = tx
                                    .send(StreamChunk {
                                        content: String::new(),
                                        is_final: true,
                                        usage: None,
                                    })
                                    .await;
                                return Ok(());
                            }

                            // Parse JSON chunk
                            if let Ok(json) = serde_json::from_str::<Value>(data) {
                                if let Some(choices) =
                                    json.get("choices").and_then(|c| c.as_array())
                                {
                                    for choice in choices {
                                        if let Some(delta) =
                                            choice.get("delta").and_then(|d| d.as_object())
                                        {
                                            if let Some(content) =
                                                delta.get("content").and_then(|c| c.as_str())
                                            {
                                                let _ = tx
                                                    .send(StreamChunk {
                                                        content: content.to_string(),
                                                        is_final: false,
                                                        usage: None,
                                                    })
                                                    .await;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Send final chunk if stream ended naturally
                let _ = tx
                    .send(StreamChunk {
                        content: String::new(),
                        is_final: true,
                        usage: None,
                    })
                    .await;
                Ok(())
            }
            .await;

            // Handle errors
            if let Err(e) = result {
                let _ = tx
                    .send(StreamChunk {
                        content: format!("Error: {e}"),
                        is_final: true,
                        usage: None,
                    })
                    .await;
            }
        });

        Ok(rx)
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "nvidia/llama-3.1-nemotron-70b-instruct".to_string(),
                name: "Llama 3.1 Nemotron 70B".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "meta/llama-3.1-405b-instruct".to_string(),
                name: "Llama 3.1 405B".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "mistralai/mistral-large-2411".to_string(),
                name: "Mistral Large 2".to_string(),
                context_length: 128000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
            ModelInfo {
                id: "google/gemma-2-27b-it".to_string(),
                name: "Gemma 2 27B".to_string(),
                context_length: 8192,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0,
                    completion_per_1k: 0.0,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}
