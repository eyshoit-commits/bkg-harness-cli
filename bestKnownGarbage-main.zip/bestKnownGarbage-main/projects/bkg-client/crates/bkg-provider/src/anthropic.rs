//! Anthropic (Claude) LLM Provider.
//!
//! Uses the Anthropic Messages API directly via HTTP.
//! API reference: https://docs.anthropic.com/en/api/messages

use super::*;
use reqwest::Client;
use serde_json::Value;

/// Anthropic provider using direct HTTP to the Messages API.
pub struct AnthropicProvider {
    client: Client,
    api_key: String,
    base_url: String,
}

impl AnthropicProvider {
    /// Create a new Anthropic provider.
    pub fn new(api_key: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url: "https://api.anthropic.com/v1".to_string(),
        }
    }

    /// Create with custom base URL.
    pub fn with_base_url(api_key: impl Into<String>, base_url: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            api_key: api_key.into(),
            base_url: base_url.into(),
        }
    }
}

#[async_trait]
impl LLMProvider for AnthropicProvider {
    async fn chat(
        &self,
        messages: &[ChatMessage],
        options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        let url = format!("{}/messages", self.base_url);

        // Build Anthropic-format messages
        let mut anthropic_messages: Vec<Value> = Vec::new();
        let mut system_content: Option<String> = None;

        for msg in messages {
            match msg.role {
                MessageRole::System => {
                    // Anthropic uses a separate "system" parameter
                    system_content = msg.content.clone();
                }
                _ => {
                    let role_str = match msg.role {
                        MessageRole::User => "user",
                        MessageRole::Assistant => "assistant",
                        _ => "user",
                    };
                    anthropic_messages.push(serde_json::json!({
                        "role": role_str,
                        "content": msg.content
                    }));
                }
            }
        }

        let mut req_body = serde_json::Map::new();
        req_body.insert("model".to_string(), Value::String(options.model.clone()));
        req_body.insert("messages".to_string(), Value::Array(anthropic_messages));
        req_body.insert(
            "max_tokens".to_string(),
            Value::Number(serde_json::Number::from(options.max_tokens.unwrap_or(4096))),
        );

        if let Some(temp) = options.temperature {
            req_body.insert("temperature".to_string(), serde_json::json!(temp));
        }

        if let Some(system) = system_content {
            req_body.insert("system".to_string(), Value::String(system));
        }

        let response = self
            .client
            .post(&url)
            .header("x-api-key", &self.api_key)
            .header("anthropic-version", "2023-06-01")
            .header("Content-Type", "application/json")
            .json(&req_body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        let status = response.status();
        let bytes = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !status.is_success() {
            let err_text = String::from_utf8_lossy(&bytes).to_string();
            return Err(ProviderError::Provider(format!(
                "HTTP {}: {}",
                status, err_text
            )));
        }

        let json: Value = serde_json::from_slice(&bytes)
            .map_err(|e| ProviderError::Provider(format!("JSON parse error: {}", e)))?;

        // Extract text content from Anthropic response
        let content = json
            .get("content")
            .and_then(|c| c.as_array())
            .and_then(|blocks| {
                blocks.iter().find_map(|block| {
                    if block.get("type").and_then(|t| t.as_str()) == Some("text") {
                        block.get("text").and_then(|t| t.as_str()).map(String::from)
                    } else {
                        None
                    }
                })
            })
            .unwrap_or_default();

        // Extract usage (Anthropic uses input_tokens/output_tokens)
        let usage = json.get("usage").and_then(|u| {
            let prompt_tokens = u.get("input_tokens")?.as_u64()? as u32;
            let completion_tokens = u.get("output_tokens")?.as_u64()? as u32;
            Some(TokenUsage {
                prompt_tokens,
                completion_tokens,
                total_tokens: prompt_tokens + completion_tokens,
            })
        });

        Ok(ProviderResponse {
            content,
            tool_calls: vec![],
            finish_reason: None,
            usage,
            raw: Some(json),
        })
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        Err(ProviderError::Provider(
            "Anthropic streaming not yet implemented".to_string(),
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        Ok(vec![
            ModelInfo {
                id: "claude-sonnet-4-20250514".to_string(),
                name: "Claude Sonnet 4".to_string(),
                context_length: 200000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.003,
                    completion_per_1k: 0.015,
                }),
            },
            ModelInfo {
                id: "claude-3-5-sonnet-20241022".to_string(),
                name: "Claude 3.5 Sonnet".to_string(),
                context_length: 200000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.003,
                    completion_per_1k: 0.015,
                }),
            },
            ModelInfo {
                id: "claude-3-5-haiku-20241022".to_string(),
                name: "Claude 3.5 Haiku".to_string(),
                context_length: 200000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.0008,
                    completion_per_1k: 0.004,
                }),
            },
            ModelInfo {
                id: "claude-opus-4-20250514".to_string(),
                name: "Claude Opus 4".to_string(),
                context_length: 200000,
                pricing: Some(ModelPricing {
                    prompt_per_1k: 0.015,
                    completion_per_1k: 0.075,
                }),
            },
        ])
    }

    async fn health_check(&self) -> ProviderResult<()> {
        Ok(())
    }
}
