//! Ollama — **Reiner Local Orchestrator** für Model-Routing und Discovery.
//!
//! Ollama führt KEINE Chat-Completions aus. Seine Aufgaben:
//!
//! 1. **Orchestrierung**: `/api/tags` → installierte Models entdecken
//! 2. **Routing**: Task-Typ → bestes verfügbares Model
//! 3. **Model-Management**: `/api/pull` → Models bei Bedarf laden
//! 4. **Health**: `/api/tags` → prüfen ob Ollama läuft
//!
//! Die eigentliche Chat-Execution läuft über NVIDIA NIM, OpenAI, etc.
//! Ollama dient nur als lokaler Model-Katalog und Router.

use super::*;
use reqwest::Client;
use serde::Deserialize;
use serde_json::Value;

/// Ollama — der lokale Orchestrator (kein Chat-Provider)
pub struct OllamaProvider {
    client: Client,
    base_url: String,
}

/// Response von Ollama's `/api/tags` Endpoint
#[derive(Debug, Deserialize)]
struct OllamaTagsResponse {
    models: Vec<OllamaModel>,
}

#[derive(Debug, Deserialize)]
struct OllamaModel {
    name: String,
    #[serde(default)]
    modified_at: String,
    #[serde(default)]
    size: u64,
    #[serde(default)]
    digest: String,
    #[serde(default)]
    details: Option<OllamaModelDetails>,
}

#[derive(Debug, Deserialize)]
struct OllamaModelDetails {
    #[serde(default)]
    parameter_size: String,
    #[serde(default)]
    quantization_level: String,
    #[serde(default)]
    family: String,
    #[serde(default)]
    families: Vec<String>,
    #[serde(default)]
    parent_model: String,
    #[serde(default)]
    format: String,
}

impl OllamaProvider {
    pub fn new(base_url: impl Into<String>) -> Self {
        Self {
            client: Client::new(),
            base_url: base_url.into(),
        }
    }

    /// **Orchestrator**: Entdecke installierte Models via `/api/tags`.
    /// Gibt Liste der Model-Namen zurück die lokal verfügbar sind.
    #[allow(dead_code)]
    pub async fn probe_installed_models(&self) -> ProviderResult<Vec<String>> {
        let url = format!("{}/api/tags", self.base_url);
        let response = self
            .client
            .get(&url)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        if !response.status().is_success() {
            return Ok(Vec::new());
        }

        let body = response
            .bytes()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        match serde_json::from_slice::<OllamaTagsResponse>(&body) {
            Ok(tags) => Ok(tags.models.into_iter().map(|m| m.name).collect()),
            Err(_) => Ok(Vec::new()),
        }
    }

    /// **Orchestrator**: Erstelle Model-Katalog aus installierten Models.
    /// Sortiert nach Größe/Kapazität für Routing-Entscheidungen.
    pub async fn get_available_routing_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        let installed = self.probe_installed_models().await?;
        let installed_set: std::collections::HashSet<String> =
            installed.into_iter().collect();

        let mut available = Vec::new();

        // Große Models (complex reasoning) — bevorzugt für Planner/Overseer
        for (id, name, ctx) in &[
            ("qwen2.5:32b", "Qwen 2.5 32B", 128000u32),
            ("qwen2.5:14b", "Qwen 2.5 14B", 32000u32),
            ("llama3.3:70b", "Llama 3.3 70B", 128000u32),
            ("deepseek-r1:32b", "DeepSeek R1 32B", 128000u32),
            ("deepseek-r1:14b", "DeepSeek R1 14B", 32000u32),
            ("mixtral:8x7b", "Mixtral 8x7B", 32000u32),
            ("qwen2.5:72b", "Qwen 2.5 72B", 128000u32),
        ] {
            if installed_set.contains(*id) {
                available.push(ModelInfo {
                    id: id.to_string(),
                    name: name.to_string(),
                    context_length: *ctx,
                    pricing: Some(ModelPricing {
                        prompt_per_1k: 0.0,
                        completion_per_1k: 0.0,
                    }),
                });
            }
        }

        // Mittlere Models (coding, review) — für Coder/Reviewer
        for (id, name, ctx) in &[
            ("codellama:7b", "Code Llama 7B", 16000u32),
            ("codellama:13b", "Code Llama 13B", 16000u32),
            ("deepseek-coder:6.7b", "DeepSeek Coder 6.7B", 16000u32),
            ("deepseek-coder:33b", "DeepSeek Coder 33B", 16000u32),
            ("qwen2.5-coder:7b", "Qwen 2.5 Coder 7B", 32000u32),
            ("qwen2.5-coder:14b", "Qwen 2.5 Coder 14B", 32000u32),
            ("mistral:7b", "Mistral 7B", 32000u32),
            ("mistral:8x7b", "Mixtral 8x7B", 32000u32),
        ] {
            if installed_set.contains(*id) {
                available.push(ModelInfo {
                    id: id.to_string(),
                    name: name.to_string(),
                    context_length: *ctx,
                    pricing: Some(ModelPricing {
                        prompt_per_1k: 0.0,
                        completion_per_1k: 0.0,
                    }),
                });
            }
        }

        // Kleine Models (docs, simple tasks) — für Docs
        for (id, name, ctx) in &[
            ("llama3.2:3b", "Llama 3.2 3B", 128000u32),
            ("llama3.2:1b", "Llama 3.2 1B", 128000u32),
            ("phi3:3.8b", "Phi-3 3.8B", 128000u32),
            ("phi3:14b", "Phi-3 14B", 128000u32),
            ("gemma2:2b", "Gemma 2 2B", 8192u32),
            ("gemma2:9b", "Gemma 2 9B", 8192u32),
            ("tinyllama:1.1b", "TinyLlama 1.1B", 2048u32),
        ] {
            if installed_set.contains(*id) {
                available.push(ModelInfo {
                    id: id.to_string(),
                    name: name.to_string(),
                    context_length: *ctx,
                    pricing: None,
                });
            }
        }

        // Fallback: alle installierten Models wenn kein Standard gefunden
        if available.is_empty() {
            let all_tags = self.probe_installed_models().await?;
            for name in all_tags {
                let ctx = if name.contains("70b") || name.contains("32b") || name.contains("30b") {
                    128000
                } else if name.contains("13b") || name.contains("14b") || name.contains("8x7b") {
                    32000
                } else {
                    8192
                };
                available.push(ModelInfo {
                    id: name.clone(),
                    name,
                    context_length: ctx,
                    pricing: None,
                });
            }
        }

        Ok(available)
    }

    /// **Orchestrator**: Route Task-Typ zum besten verfügbaren Model.
    pub async fn route_for_task(&self, task_type: &str) -> String {
        let available = self.get_available_routing_models().await.unwrap_or_default();
        if available.is_empty() {
            return "llama3.2:3b".to_string();
        }

        let task_type = task_type.to_lowercase();
        let names: Vec<&str> = available.iter().map(|m| m.id.as_str()).collect();

        match task_type.as_str() {
            "planner" | "architecture" | "design" => {
                // Größtes verfügbares Model
                for name in &names {
                    if name.contains("72b") || name.contains("70b") || name.contains("32b") || name.contains("30b") {
                        return name.to_string();
                    }
                }
                // Fallback: längster Kontext
                let best = available.iter().max_by_key(|m| m.context_length);
                if let Some(b) = best { return b.id.clone(); }
                names.first().map(|s| s.to_string()).unwrap_or("llama3.2:3b".to_string())
            }
            "coder" | "implementation" | "writer" => {
                // Coding-spezialisiertes Model bevorzugt
                for name in &names {
                    if name.contains("coder") || name.contains("deepseek-coder") {
                        return name.to_string();
                    }
                }
                // Dann: mittleres Model (7b-14b)
                for name in &names {
                    if name.contains("14b") || name.contains("13b") || name.contains("8x7b") {
                        return name.to_string();
                    }
                }
                for name in &names {
                    if name.contains("7b") {
                        return name.to_string();
                    }
                }
                names.first().map(|s| s.to_string()).unwrap_or("llama3.2:3b".to_string())
            }
            "reviewer" | "verify" | "tester" | "critic" => {
                // Mittleres Model reicht
                for name in &names {
                    if name.contains("7b") || name.contains("6.7b") || name.contains("8b") {
                        return name.to_string();
                    }
                }
                names.first().map(|s| s.to_string()).unwrap_or("llama3.2:3b".to_string())
            }
            "docs" | "simple" | "scribe" => {
                // Kleinstes Model bevorzugt
                for name in &names {
                    if name.contains("1b") || name.contains("2b") || name.contains("270m") {
                        return name.to_string();
                    }
                }
                for name in &names {
                    if name.contains("3b") || name.contains("3.8b") {
                        return name.to_string();
                    }
                }
                available.last().map(|m| m.id.clone()).unwrap_or_else(|| "llama3.2:3b".to_string())
            }
            "overseer" | "manager" | "coordinator" => {
                // Großes Model für Meta-Kognition
                for name in &names {
                    if name.contains("70b") || name.contains("72b") || name.contains("32b") || name.contains("30b") {
                        return name.to_string();
                    }
                }
                let best = available.iter().max_by_key(|m| m.context_length);
                if let Some(b) = best { return b.id.clone(); }
                names.first().map(|s| s.to_string()).unwrap_or("llama3.2:3b".to_string())
            }
            _ => {
                // Default: höchster Kontext
                let best = available.iter().max_by_key(|m| m.context_length);
                if let Some(b) = best { return b.id.clone(); }
                names.first().map(|s| s.to_string()).unwrap_or("llama3.2:3b".to_string())
            }
        }
    }

    /// **Orchestrator**: Ziehe ein Model via `/api/pull`.
    pub async fn pull_model(&self, model_name: &str) -> ProviderResult<bool> {
        let url = format!("{}/api/pull", self.base_url);
        let body = serde_json::json!({
            "name": model_name,
            "stream": false,
        });

        let response = self
            .client
            .post(&url)
            .json(&body)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;

        Ok(response.status().is_success())
    }

    /// **Orchestrator**: Prüfe ob ein bestimmtes Model installiert ist.
    pub async fn is_model_installed(&self, model_name: &str) -> bool {
        let installed = self.probe_installed_models().await.unwrap_or_default();
        installed.iter().any(|m| m == model_name)
    }

    /// **Orchestrator**: Stelle sicher dass ein Model verfügbar ist (pulled bei Bedarf).
    pub async fn ensure_model(&self, model_name: &str) -> ProviderResult<bool> {
        if self.is_model_installed(model_name).await {
            return Ok(true);
        }
        // Model automatisch pulled
        self.pull_model(model_name).await
    }
}

// ⚠️  LLMProvider BRIDGE — Ollama ist primär Orchestrator.
// chat/chat_stream schlagen explizit fehl — Execution läuft über NVIDIA/OpenAI.
// Der Orchestrator entdeckt Models und routet Tasks.
#[async_trait]
impl LLMProvider for OllamaProvider {
    async fn chat(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<ProviderResponse> {
        Err(ProviderError::Provider(
            "Ollama: reiner Orchestrator — Chat via -P nvidia oder --provider openai".to_string()
        ))
    }

    async fn chat_stream(
        &self,
        _messages: &[ChatMessage],
        _options: ProviderOptions,
    ) -> ProviderResult<tokio::sync::mpsc::Receiver<StreamChunk>> {
        Err(ProviderError::Provider(
            "Ollama: reiner Orchestrator — Streaming via NVIDIA/OpenAI".to_string()
        ))
    }

    async fn list_models(&self) -> ProviderResult<Vec<ModelInfo>> {
        self.get_available_routing_models().await
    }

    async fn health_check(&self) -> ProviderResult<()> {
        let url = format!("{}/api/tags", self.base_url);
        let response = self
            .client
            .get(&url)
            .send()
            .await
            .map_err(|e| ProviderError::Network(e.to_string()))?;
        if response.status().is_success() {
            Ok(())
        } else {
            Err(ProviderError::Provider("Ollama not available".to_string()))
        }
    }
}