//! BKG Client — CLI entry point
//! Legacy binary will be migrated here during Phase 1 (M001).

fn main() {
    println!("BKG Client — awaiting Phase 1 migration");
}
