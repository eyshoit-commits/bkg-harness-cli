# bkg-motherbrain — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-motherbrain.md` (M001–M046)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`
- **Root task:** `../../task.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **TrustEngine** | Evidence scoring, trust vectors | P0 |
| **EscalationEngine** | Hero promotion/demotion | P0 |
| **HeroDaemon** | Cache layer, validation delegation | P1 |
| **ReplayEngine** | Execution replay, receipts | P1 |
| **MotherbrainKernel** | Final adjudication, ledger writes | P0 |

## Dependencies
- `crates/bkg-kernel/` — core kernel logic
- `crates/bkg-ledger/` — ledger operations
- `crates/bkg-common/` — shared types
- `contracts/motherbrain-api.md` — API contract
- `contracts/ledger-schema.md` — ledger schema

## Entry Points
- `src/main.rs` — server binary
- CLI flags defined in `Cargo.toml` (clap)
