//! BKG adjudicator — stub crate
