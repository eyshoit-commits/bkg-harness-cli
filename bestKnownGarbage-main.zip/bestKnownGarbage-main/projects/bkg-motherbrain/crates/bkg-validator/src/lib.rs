//! BKG validator — stub crate
