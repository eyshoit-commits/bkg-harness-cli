//! BKG policy — stub crate
