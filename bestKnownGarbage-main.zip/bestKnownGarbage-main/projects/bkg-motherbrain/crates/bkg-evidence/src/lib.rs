//! BKG evidence — stub crate
