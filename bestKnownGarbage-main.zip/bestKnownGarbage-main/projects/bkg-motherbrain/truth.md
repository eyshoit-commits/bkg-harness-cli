# bkg-motherbrain — TRUTH

## Identity
- **Package:** `motherbrain-server` (Cargo.toml)
- **Directory:** `projects/bkg-motherbrain/`
- **Purpose:** BKG Motherbrain — Kernel server, ledger authority, trust adjudication

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | Server entry |
| `../../crates/bkg-kernel/` | Kernel library |
| `../../crates/bkg-ledger/` | Ledger operations |
| `../../contracts/motherbrain-api.md` | API contract |
| `../../contracts/ledger-schema.md` | Ledger schema |

## Depends On
- `bkg-kernel`, `bkg-ledger`, `bkg-common`, `bkg-types`, `bkg-events`, `bkg-crypto`
- `bkg-core` (legacy, migration planned)
