//! BKG rag — stub crate
