//! BKG normalizer — stub crate
