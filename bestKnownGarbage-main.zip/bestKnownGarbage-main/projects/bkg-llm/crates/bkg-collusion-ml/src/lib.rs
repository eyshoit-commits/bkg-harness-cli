//! BKG collusion-ml — stub crate
