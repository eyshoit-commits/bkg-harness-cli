//! BKG guard — stub crate
