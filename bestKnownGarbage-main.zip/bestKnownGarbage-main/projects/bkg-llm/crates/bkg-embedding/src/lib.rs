//! BKG embedding — stub crate
