//! BKG tokenizer — stub crate
