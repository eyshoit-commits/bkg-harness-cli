# bkg-llm — TRUTH

> **Project-local truths.** Cross-reference with `../../truth.md` for global truths.

## Identity
- **Package:** `bkg-llm` (Cargo.toml)
- **Directory:** `projects/bkg-llm/`
- **Purpose:** Guard LLM — LLM call validation, context management

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | Guard LLM entry |
| `../../crates/bkg-llm-core/` | LLM client abstraction |
| `../../crates/bkg-llm-guard/` | Guard/validation logic |

## Depends On
- `bkg-llm-core`, `bkg-llm-guard`, `bkg-common`, `bkg-types`
