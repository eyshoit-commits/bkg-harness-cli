# bkg-llm — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-guard-llm.md` (L001–L010)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **GuardAgent** | LLM call validation, prompt guard | P0 |
| **RewriteEngine** | Intent preservation, output sanitization | P0 |
| **ContextManager** | Token budget, contextual window | P1 |

## Dependencies
- `crates/bkg-llm-core/` — LLM client abstraction
- `crates/bkg-llm-guard/` — guard/validation logic
- `crates/bkg-common/` — shared types

## Entry Points
- `src/main.rs` — guard LLM binary
