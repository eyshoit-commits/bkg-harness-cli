# bkg-lang — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-bkg-lang.md` (B001–B009)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **QLParser** | BKG-QL query parsing (SELECT, WHERE, FROM) | P0 |
| **Interpreter** | BKG-QL + DSL execution engine | P0 |
| **DSLCompiler** | BKG-DSL → intent graph compilation | P1 |

## Dependencies
- `crates/bkg-ast/` — parser, AST, interpreter
- `crates/bkg-semantic/` — semantic analysis
- `crates/bkg-search/` — search index queries
- `crates/bkg-common/` — shared types

## Entry Points
- `src/main.rs` — language CLI binary
