//! BKG typecheck — stub crate
