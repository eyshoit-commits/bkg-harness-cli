//! BKG parser — stub crate
