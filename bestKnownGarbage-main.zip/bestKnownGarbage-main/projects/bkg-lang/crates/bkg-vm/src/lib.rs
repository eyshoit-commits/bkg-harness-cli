//! BKG vm — stub crate
