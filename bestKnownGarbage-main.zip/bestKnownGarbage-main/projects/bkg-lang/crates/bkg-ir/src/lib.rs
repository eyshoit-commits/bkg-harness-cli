//! BKG ir — stub crate
