//! BKG lexer — stub crate
