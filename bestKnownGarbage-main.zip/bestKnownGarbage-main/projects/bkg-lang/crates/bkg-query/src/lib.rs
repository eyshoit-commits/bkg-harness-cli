//! BKG query — stub crate
