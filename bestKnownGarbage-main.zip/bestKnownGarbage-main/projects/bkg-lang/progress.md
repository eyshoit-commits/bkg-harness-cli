# bkg-lang — PROGRESS

> **Milestones tracked in:** `../../tasks/task-bkg-lang.md` (B001–B009)

## Phase 4: BKG Language (B001–B009)
- [ ] B001 — Language design doc
- [ ] B002–B003 — Parser + interpreter
- [ ] B004 — DSL (intent graph)
- [ ] B005 — B009 — Integration, testing, docs

## Status
- **Task file:** `../../tasks/task-bkg-lang.md`
- **Task ref:** B001–B009
- **Progress:** 0 / 9 steps
