# bkg-lang — TRUTH

## Identity
- **Package:** `bkg-lang` (Cargo.toml)
- **Directory:** `projects/bkg-lang/`
- **Purpose:** BKG Language — QL query engine + DSL agent task runner

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | CLI entry |
| `../../crates/bkg-ast/` | Parser, AST, interpreter |
| `../../crates/bkg-semantic/` | Semantic analysis |
| `../../crates/bkg-search/` | Search index |

## Depends On
- `bkg-ast`, `bkg-semantic`, `bkg-search`, `bkg-common`, `bkg-types`, `bkg-events`
