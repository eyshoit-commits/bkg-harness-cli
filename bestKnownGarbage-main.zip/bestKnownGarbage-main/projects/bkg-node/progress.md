# bkg-node — PROGRESS

> **Milestones tracked in:** `../../tasks/task-garbage.md` (G001–G019)

## Phase 2: Garbage Nodes (G001–G019)
- [ ] G001 — G019 — Collector, sync, GC, topology, entropy, demo

## Status
- **Task file:** `../../tasks/task-garbage.md`
- **Task ref:** G001–G019
- **Progress:** 0 / 19 steps
