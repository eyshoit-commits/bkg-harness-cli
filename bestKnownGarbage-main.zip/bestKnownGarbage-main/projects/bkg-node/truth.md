# bkg-node — TRUTH

> **Project-local truths.** Cross-reference with `../../truth.md` for global truths.

## Identity
- **Package:** `bkg-node` (Cargo.toml)
- **Directory:** `projects/bkg-node/`
- **Purpose:** BKG Node — distributed collector, mesh gossip, GC

## Key Paths
| Path | Purpose |
|------|---------|
| `src/main.rs` | Node entry |
| `crates/bkg-collector/` | Data collection |
| `crates/bkg-sync/` | Sync protocol |
| `crates/bkg-search/` | Search index |
| `crates/bkg-topology/` | Network topology |
| `crates/bkg-entropy/` | Entropy |

## Depends On
- `bkg-collector`, `bkg-sync`, `bkg-search`, `bkg-topology`, `bkg-entropy`
- `bkg-mesh`, `bkg-gc` (from motherbrain project)
- `bkg-common`, `bkg-types`, `bkg-events`, `bkg-crypto` (root crates)
