# bkg-node — AGENTS

## Project Context
- **Task Chain:** `task.md` ← `task-garbage.md` (G001–G019)
- **Root truth:** `../../truth.md`
- **Root progress:** `../../progress.md`

## Agent Roles

| Agent | Scope | Priority |
|-------|-------|----------|
| **CollectorAgent** | Data collection, raw evidence | P0 |
| **SyncAgent** | Mesh synchronization, gossip | P0 |
| **GCAgent** | Garbage collection, compaction | P1 |
| **TopologyAgent** | Network topology, node discovery | P1 |
| **EntropyAgent** | Entropy measurement, randomness | P1 |

## Dependencies
- `crates/bkg-collector/` — data collection
- `crates/bkg-sync/` — sync protocol
- `crates/bkg-search/` — search index
- `crates/bkg-topology/` — network topology
- `crates/bkg-entropy/` — entropy measurement
- External: `bkg-mesh`, `bkg-gc` (motherbrain)

## Entry Points
- `src/main.rs` — node binary
