//! BKG collector — stub crate
