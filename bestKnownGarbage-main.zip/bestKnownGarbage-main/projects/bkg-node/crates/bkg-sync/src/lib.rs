//! BKG sync — stub crate
