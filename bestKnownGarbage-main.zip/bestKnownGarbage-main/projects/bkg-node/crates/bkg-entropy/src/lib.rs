//! BKG entropy — stub crate
