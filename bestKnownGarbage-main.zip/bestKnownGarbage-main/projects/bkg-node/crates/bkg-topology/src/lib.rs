//! BKG topology — stub crate
