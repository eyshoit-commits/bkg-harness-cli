//! BKG local-ledger — stub crate
