//! BKG prevalidator — stub crate
