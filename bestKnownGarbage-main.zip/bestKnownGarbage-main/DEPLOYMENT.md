# BKG Deployment Guide

This guide covers production deployment of BestKnownGarbage across different environments.

## Prerequisites

- **Rust 1.82+** — For building from source
- **Docker & Docker Compose** — For containerized deployments
- **Kubernetes 1.24+** — For cloud deployments
- **PostgreSQL 13+** — For ledger storage (optional)
- **S3-compatible storage** — For session archives (optional)

## Local Development Deployment

### Single-Machine Setup

```bash
# Clone and build
git clone https://github.com/wwwbkgme-oss/bestKnownGarbage.git
cd bestKnownGarbage
cargo build --release

# Set environment
export NVIDIA_API_KEY=your_key
export BKG_DATA_DIR=~/.bkg

# Run motherbrain server
cargo run -p bkg-motherbrain --release

# In another terminal, run CLI
cargo run -p bkg-cli -- status
```

### Docker Compose Stack

```yaml
# docker-compose.yml
version: '3.9'

services:
  motherbrain:
    build:
      context: .
      dockerfile: Dockerfile.motherbrain
    ports:
      - "8080:8080"
    environment:
      NVIDIA_API_KEY: ${NVIDIA_API_KEY}
      RUST_LOG: info
    volumes:
      - bkg-data:/root/.bkg
    depends_on:
      - postgres
      - minio

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: bkg
      POSTGRES_USER: bkg
      POSTGRES_PASSWORD: changeme
    volumes:
      - postgres-data:/var/lib/postgresql/data

  minio:
    image: minio/minio:latest
    ports:
      - "9000:9000"
      - "9001:9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    volumes:
      - minio-data:/data
    command: server /data --console-address ":9001"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  bkg-data:
  postgres-data:
  minio-data:
```

Start stack:
```bash
docker-compose up -d
docker-compose logs -f motherbrain
```

## Production Deployment

### Prerequisites Checklist

- [ ] PostgreSQL database provisioned
- [ ] S3-compatible storage configured
- [ ] Redis cluster running (optional)
- [ ] TLS certificates installed
- [ ] API keys secured in secrets manager
- [ ] Backup strategy implemented
- [ ] Monitoring configured
- [ ] Network security groups configured

### Docker Image Build

```dockerfile
# Dockerfile.motherbrain
FROM rust:1.82 AS builder

WORKDIR /build
COPY . .

# Install dependencies
RUN apt-get update && apt-get install -y \
    pkg-config libssl-dev \
    && rm -rf /var/lib/apt/lists/*

# Build release binary
RUN cargo build --release -p bkg-motherbrain

# Runtime image
FROM debian:bookworm-slim

RUN apt-get update && apt-get install -y \
    ca-certificates libssl3 \
    && rm -rf /var/lib/apt/lists/*

COPY --from=builder /build/target/release/bkg-motherbrain /usr/local/bin/

EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
    CMD curl -f http://localhost:8080/health || exit 1

CMD ["bkg-motherbrain"]
```

Build and push:
```bash
# Build
docker build -f Dockerfile.motherbrain -t registry.example.com/bkg-motherbrain:1.0.0 .

# Push
docker push registry.example.com/bkg-motherbrain:1.0.0
```

### Kubernetes Deployment

```yaml
# k8s/deployment.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: bkg

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: bkg-config
  namespace: bkg
data:
  log_level: "info"
  timeout_seconds: "300"

---
apiVersion: v1
kind: Secret
metadata:
  name: bkg-credentials
  namespace: bkg
type: Opaque
stringData:
  nvidia_api_key: "${NVIDIA_API_KEY}"
  db_password: "${DB_PASSWORD}"

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: motherbrain
  namespace: bkg
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels:
      app: motherbrain
  template:
    metadata:
      labels:
        app: motherbrain
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8080"
    spec:
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - motherbrain
              topologyKey: kubernetes.io/hostname
      containers:
      - name: motherbrain
        image: registry.example.com/bkg-motherbrain:1.0.0
        imagePullPolicy: IfNotPresent
        ports:
        - name: http
          containerPort: 8080
          protocol: TCP
        env:
        - name: NVIDIA_API_KEY
          valueFrom:
            secretKeyRef:
              name: bkg-credentials
              key: nvidia_api_key
        - name: BKG_DATABASE_URL
          value: "postgresql://bkg:$(DB_PASSWORD)@postgres:5432/bkg"
        - name: BKG_LOG_LEVEL
          valueFrom:
            configMapKeyRef:
              name: bkg-config
              key: log_level
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: bkg-credentials
              key: db_password
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 2
        securityContext:
          allowPrivilegeEscalation: false
          readOnlyRootFilesystem: true
          runAsNonRoot: true
          runAsUser: 1000
        volumeMounts:
        - name: tmp
          mountPath: /tmp
        - name: home
          mountPath: /home/bkg
      volumes:
      - name: tmp
        emptyDir: {}
      - name: home
        emptyDir: {}

---
apiVersion: v1
kind: Service
metadata:
  name: motherbrain
  namespace: bkg
spec:
  type: ClusterIP
  selector:
    app: motherbrain
  ports:
  - name: http
    port: 8080
    targetPort: 8080

---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: bkg
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        ports:
        - containerPort: 5432
        env:
        - name: POSTGRES_DB
          value: bkg
        - name: POSTGRES_USER
          value: bkg
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: bkg-credentials
              key: db_password
        volumeMounts:
        - name: data
          mountPath: /var/lib/postgresql/data
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 50Gi
```

Deploy:
```bash
# Create namespace and secrets
kubectl create namespace bkg
kubectl create secret generic bkg-credentials \
  --from-literal=nvidia_api_key=${NVIDIA_API_KEY} \
  --from-literal=db_password=${DB_PASSWORD} \
  -n bkg

# Deploy
kubectl apply -f k8s/

# Verify
kubectl get pods -n bkg
kubectl logs -n bkg -f deployment/motherbrain
```

## Configuration Management

### Environment Variables

```bash
# Core
BKG_DATA_DIR=/var/lib/bkg                    # State directory
BKG_LOG_LEVEL=info                            # debug|info|warn|error
BKG_LISTEN_ADDR=0.0.0.0:8080                 # Server address

# Database
BKG_DATABASE_URL=postgresql://user:pass@host/db
BKG_DATABASE_POOL_SIZE=20
BKG_DATABASE_TIMEOUT=30s

# Storage
BKG_STORAGE_TYPE=s3                           # file|s3|gcs|azure
BKG_S3_BUCKET=bkg-sessions
BKG_S3_REGION=us-east-1
BKG_S3_ENDPOINT=s3.amazonaws.com

# AI Providers
NVIDIA_API_KEY=...
OPENAI_API_KEY=...
ANTHROPIC_API_KEY=...

# Security
BKG_TLS_CERT=/etc/ssl/bkg/cert.pem
BKG_TLS_KEY=/etc/ssl/bkg/key.pem
BKG_JWT_SECRET=your-secret-key

# Performance
BKG_WORKER_THREADS=8
BKG_MAX_CONNECTIONS=1000
BKG_REQUEST_TIMEOUT=30s
```

### Configuration Files

```yaml
# /etc/bkg/config.yaml
server:
  listen: 0.0.0.0:8080
  tls:
    enabled: true
    cert: /etc/ssl/bkg/cert.pem
    key: /etc/ssl/bkg/key.pem

database:
  url: postgresql://user:pass@postgres:5432/bkg
  pool_size: 20
  timeout: 30s

storage:
  type: s3
  bucket: bkg-sessions
  region: us-east-1

session:
  default_budget: 1000000
  max_duration: 3600s
  isolation_level: session

logging:
  level: info
  format: json
  output: stdout
```

## Monitoring & Observability

### Prometheus Metrics

BKG exposes metrics on `/metrics`:

```bash
# Query metrics
curl http://localhost:8080/metrics

# Key metrics
bkg_sessions_active           # Active sessions
bkg_tokens_used_total         # Total tokens consumed
bkg_operations_total          # Total operations
bkg_errors_total              # Total errors
bkg_policy_violations_total   # Policy violations
bkg_latency_ms                # Operation latency
```

### Kubernetes Monitoring

```yaml
# k8s/servicemonitor.yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: bkg-motherbrain
  namespace: bkg
spec:
  selector:
    matchLabels:
      app: motherbrain
  endpoints:
  - port: http
    interval: 30s
    path: /metrics
```

### Logging

```bash
# View logs
kubectl logs -n bkg deployment/motherbrain

# Tail logs
kubectl logs -n bkg -f deployment/motherbrain

# With timestamps
kubectl logs -n bkg deployment/motherbrain --timestamps=true
```

## Backup & Recovery

### Database Backups

```bash
# Backup
pg_dump -h postgres -U bkg bkg > backup.sql

# Restore
psql -h postgres -U bkg bkg < backup.sql

# Automated backup (Kubernetes)
kubectl exec -n bkg postgres-0 -- \
  pg_dump -U bkg bkg | gzip > backup-$(date +%Y%m%d).sql.gz
```

### Session Archives

```bash
# Archive sessions to S3
aws s3 sync /var/lib/bkg/sessions s3://bkg-backup/sessions/

# Restore from archive
aws s3 sync s3://bkg-backup/sessions/ /var/lib/bkg/sessions/
```

## Scaling

### Horizontal Scaling

```bash
# Scale deployment
kubectl scale deployment motherbrain --replicas=5 -n bkg

# Auto-scaling
kubectl autoscale deployment motherbrain \
  --min=3 --max=10 \
  --cpu-percent=70 -n bkg
```

### Database Scaling

```bash
# Add read replicas for PostgreSQL
# Configure in PostgreSQL replication settings

# Connection pooling (pgBouncer)
# Deploy pgBouncer between app and database
```

## Security

### Network Policy

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: bkg-netpolicy
  namespace: bkg
spec:
  podSelector:
    matchLabels:
      app: motherbrain
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: bkg-client
    ports:
    - protocol: TCP
      port: 8080
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: postgres
    ports:
    - protocol: TCP
      port: 5432
```

### RBAC

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: bkg
  namespace: bkg

---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: bkg-role
  namespace: bkg
rules:
- apiGroups: [""]
  resources: ["configmaps"]
  verbs: ["get", "list"]
- apiGroups: [""]
  resources: ["secrets"]
  verbs: ["get"]

---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: bkg-rolebinding
  namespace: bkg
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: bkg-role
subjects:
- kind: ServiceAccount
  name: bkg
  namespace: bkg
```

## Troubleshooting Deployments

### Check Pod Status

```bash
kubectl describe pod <pod-name> -n bkg
kubectl logs <pod-name> -n bkg --previous  # Crashed pod logs
```

### Common Issues

**ImagePullBackOff**
```bash
# Check image exists in registry
docker pull registry.example.com/bkg-motherbrain:1.0.0

# Check credentials
kubectl get secrets -n bkg
```

**CrashLoopBackOff**
```bash
# Check logs
kubectl logs -n bkg <pod-name> --previous

# Check resources
kubectl top pod -n bkg

# Check environment
kubectl exec -n bkg <pod-name> -- env | grep BKG
```

**Database Connection Error**
```bash
# Test connectivity
kubectl exec -n bkg <pod-name> -- nc -zv postgres 5432

# Check secret
kubectl get secret bkg-credentials -n bkg -o yaml
```

---

For more help, see [README.md](README.md) and [Troubleshooting](README.md#troubleshooting)
