#!/usr/bin/env bash
set -euo pipefail
set -x

PLANS_DIR="/home/bkg/workspace/bestKnownGarbage/docs/superpowers/plans"
TASKS_ROOT="/home/bkg/workspace/bestKnownGarbage/task"

rm -rf "$TASKS_ROOT"
mkdir -p "$TASKS_ROOT"

for plan_path in "$PLANS_DIR"/*.md; do
  filename=$(basename "$plan_path")
  slug="${filename%.md}"
  out_dir="$TASKS_ROOT/$slug"
  mkdir -p "$out_dir"

  echo "Generating tasks for $slug ..." >&2

  # Extract title: first line of file, remove leading '# ' and trailing spaces
  title=$(head -1 "$plan_path" | sed 's/^# //; s/ *$//')
  if [ -z "$title" ]; then title="$slug"; fi
  # Escape double quotes and remove any newlines (should be single line)
  title=$(echo "$title" | sed 's/"/\\"/g; s/\n/ /g; s/\r/ /g')

  # Extract objective from Goal line if present
  objective=$(grep -m1 '^Goal:' "$plan_path" 2>/dev/null | sed 's/^Goal: *//; s/ *$//' || true)
  if [ -z "$objective" ]; then
    objective="$title"
  fi
  objective=$(echo "$objective" | sed 's/"/\\"/g; s/\n/ /g; s/\r/ /g')

  task_json="$out_dir/task.json"
  cat > "$task_json" <<EOF
{
  "id": "$slug",
  "name": "$title",
  "status": "active",
  "objective": "$objective",
  "context_files": ["docs/superpowers/plans/$filename"],
  "reference_files": [],
  "exit_criteria": ["All subtasks completed"],
  "subtask_count": 0,
  "completed_count": 0,
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "completed_at": null
}
EOF

  # Generate subtasks using awk
  awk -v out_dir="$out_dir" -v slug="$slug" -v plan_file="$filename" '
    BEGIN { seq=0; in_task=0; nsteps=0; }
    /^### Task [0-9]+:/ {
      if (in_task) write_task();
      in_task=1; seq++;
      # Extract title after colon
      title = $0;
      sub(/^### Task [0-9]+: */, "", title);
      # Trim whitespace
      sub(/^[ \t]+/, "", title);
      sub(/[ \t]+$/, "", title);
      gsub(/"/, "\\\"", title);
      nsteps=0;
      next;
    }
    in_task && /^- \[ \] / {
      line = $0;
      sub(/^- \[ \] /, "", line);
      gsub(/\*\*/, "", line);
      sub(/^[ \t]+/, "", line);
      sub(/[ \t]+$/, "", line);
      if (length(line) > 0) steps[nsteps++] = line;
      next;
    }
    # Skip lines that are not steps (headings, code fences, git blocks, etc.)
    in_task && /^(\#|\*|\[|\]|```|git |\$ )/ { next; }
    END { if (in_task) write_task(); }
    function write_task() {
      filename = sprintf("subtask_%02d.json", seq);
      filepath = out_dir "/" filename;
      print "{" > filepath;
      print "  \"id\": \"" slug "-" sprintf("%02d", seq) "\"," >> filepath;
      print "  \"seq\": \"" sprintf("%02d", seq) "\"," >> filepath;
      print "  \"title\": \"" title "\"," >> filepath;
      print "  \"status\": \"pending\"," >> filepath;
      if (seq == 1) {
        print "  \"depends_on\": []," >> filepath;
      } else {
        prev = sprintf("%02d", seq-1);
        print "  \"depends_on\": [\"" slug "-" prev "\"]," >> filepath;
      }
      print "  \"parallel\": false," >> filepath;
      print "  \"suggested_agent\": \"coder-agent\"," >> filepath;
      print "  \"context_files\": [\"docs/superpowers/plans/" plan_file "\"]," >> filepath;
      print "  \"reference_files\": []," >> filepath;
      print "  \"acceptance_criteria\": [" >> filepath;
      for (i=0; i<nsteps; i++) {
        step = steps[i];
        gsub(/"/, "\\\"", step);
        if (i>0) printf ", " >> filepath;
        printf "\"%s\"", step >> filepath;
      }
      print "]," >> filepath;
      print "  \"deliverables\": []," >> filepath;
      print "  \"started_at\": null," >> filepath;
      print "  \"completed_at\": null," >> filepath;
      print "  \"completion_summary\": null" >> filepath;
      print "}" >> filepath;
    }
  ' "$plan_path"

  # Update subtask_count in task.json
  count=$(ls -1 "$out_dir"/subtask_*.json 2>/dev/null | wc -l)
  if [ "$count" -gt 0 ]; then
    sed -i "s/\"subtask_count\": [0-9]*,/\"subtask_count\": $count,/" "$task_json"
  fi

done

echo "All tasks generated in $TASKS_ROOT"