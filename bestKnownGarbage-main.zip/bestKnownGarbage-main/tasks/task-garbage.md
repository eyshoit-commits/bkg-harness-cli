# bESTKNOWNGarbage — Task: Garbage Nodes

> **Distributed Network.** GC-Nodes, Cold Storage, Topology, Decay.
>
> **Depends on:** Motherbrain (task-motherbrain.md) + Mesh Foundation.
>
> **Chain:** `task.md` ← `task-garbage.md`

---

## Chain

```
G001 ─→ G002 ─→ G003 ─→ G004 ─→ G005 ─→ G006 ─→ G007 ─→ G008 ─→ G009 ─→ G010
 │        │        │        │        │        │        │        │        │        │
G011 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
G012 ─→ G013 ─→ G014 ─→ G015 ─→ G016 ─→ G017 ─→ G018 ─→ G019 ─→ G020
                                                                      │
G021 ────────────────────────────────────────────────────────────────┘
  │
G022 ─→ ... ─→ G060
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN G001–G060

### G001 — Mesh Full Listener: TCP Bind + Accept

**State:** Planned  
**Depends on:** Mesh Foundation (existiert), Motherbrain M022  
**Files:** `crates/bkg-kernel/src/mesh/listener.rs`

- `📋` G001.001 — `MeshListener` Struct
- `📋` G001.002 — `MeshListener::bind(addr)` — TCP bind
- `📋` G001.003 — `MeshListener::accept() -> Option<(TcpStream, SocketAddr)>`
- `📋` G001.004 — Connection-Handshake: `MeshHandshake` mit Protokoll-Version
- `📋` G001.005 — Read-Timeout: 30s / Write-Timeout: 30s
- `📋` G001.006 — Max Connections: 256
- `📋` G001.007 — Connection-Pool: `ActiveConnections`

### G002 — Message Routing

**Status:** 📋  
**Depends on:** G001  
**Files:** `crates/bkg-kernel/src/mesh/router.rs`

- `📋` G002.001 — Length-Prefixed Framing (4B Length + Payload)
- `📋` G002.002 — `MessageRouter`: type → handler dispatch
- `📋` G002.003 — Handler: Heartbeat, TrustUpdate, EntropyMap, LedgerDelta
- `📋` G002.004 — Handler: CollusionReport, SwarmTask
- `📋` G002.005 — Unknown-Type → log + ignore
- `📋` G002.006 — Malformed → disconnect peer

### G003 — Connection Lifecycle

**Status:** 📋  
**Depends on:** G002  
**Files:** `crates/bkg-kernel/src/mesh/connection.rs`

- `📋` G003.001 — Outgoing: `MeshNode::connect(addr)`
- `📋` G003.002 — Incoming: register in pool
- `📋` G003.003 — Reconnect: exponential backoff (1s→2s→...→60s, max 10)
- `📋` G003.004 — Heartbeat: alle 10s, 3 fehlende → Disconnect
- `📋` G003.005 — Graceful Disconnect: `Disconnect`-Message

### G004 — Mesh Tests

**Status:** 📋  
**Depends on:** G003  
**Files:** `crates/bkg-kernel/tests/mesh_test.rs`

- `📋` G004.001 — `test_mesh_listener_bind()`, `test_mesh_accept_connection()`
- `📋` G004.002 — `test_mesh_handshake_version()`, `test_mesh_message_roundtrip()`
- `📋` G004.003 — `test_mesh_heartbeat()`, `test_mesh_reconnect()`, `test_mesh_broadcast()`

### G005 — Mesh TrustUpdate Propagation

**Status:** 📋  
**Depends on:** G003, Motherbrain TrustEngine  
**Files:** `crates/bkg-kernel/src/mesh/trust_propagation.rs`

- `📋` G005.001 — `TrustUpdateBroadcaster`: `tokio::sync::broadcast`
- `📋` G005.002 — TrustEngine → broadcaster bei Role-Change
- `📋` G005.003 — MeshNode subscribed → sendet an Peers
- `📋` G005.004 — `PeerTrustView`: lokale Sicht der Peers
- `📋` G005.005 — Hohe Divergenz → Collusion-Detection triggern

### G006 — ArchiveManager Cold Storage

**Status:** 📋  
**Depends on:** GC Foundation, Motherbrain M017  
**Files:** `crates/bkg-kernel/src/gc/archive.rs`

- `📋` G006.001 — `ColdStorage` Struct: base_path, zstd-compression
- `📋` G006.002 — Tiers: `hot/`, `warm/`, `cold/`, `frozen/`
- `📋` G006.003 — `store(tier, key, data)`, `retrieve(key)`, `list(tier)`, `prune(tier, older_than)`
- `📋` G006.004 — SHA256-Checksum pro Item
- `📋` G006.005 — `ArchiveManager::with_persistence(path, config)`
- `📋` G006.006 — `flush()` + Auto-Flush (60s / 100 Items)

### G007 — GC Persistence Tests

**Status:** 📋  
**Depends on:** G006  

- `📋` G007.001 — `test_cold_storage_store_retrieve()`, `test_cold_storage_tiers()`
- `📋` G007.002 — `test_cold_storage_compression()`, `test_cold_storage_checksum()`
- `📋` G007.003 — `test_archive_persistence_flush()`, `test_archive_auto_flush()`

### G008 — Replay Compactor (Merkle)

**Status:** 📋  
**Depends on:** G006, Motherbrain M036 (Replay)  
**Files:** `crates/bkg-kernel/src/gc/compactor.rs`

- `📋` G008.001 — `MerkleCompactor` Struct
- `📋` G008.002 — `build_tree(traces) -> MerkleRoot`
- `📋` G008.003 — `deduplicate(traces)`: Identisch → Referenz zählen, Ähnlich → Diff
- `📋` G008.004 — GC-Tick: `compactor.run(archive)` aufrufen
- `📋` G008.005 — `test_merkle_dedup_identical()`, `test_compactor_compression_rate()`

### G009 — Topology Rewiring Guards

**Status:** 📋  
**Depends on:** G004, GC Foundation, Motherbrain M034  
**Files:** `crates/bkg-kernel/src/gc/topology.rs`

- `📋` G009.001 — `TopologyAnalyzer` Struct
- `📋` G009.002 — `find_unhealthy_subnets(topology) -> Vec<SubnetReport>`
- `📋` G009.003 — Kriterium: hohe Latenz, einseitige Validierung, hohe Collusion-Dichte
- `📋` G009.004 — GC sendet `TopologyProposal` an Motherbrain
- `📋` G009.005 — Motherbrain: Approval / Rejection / Modify
- `📋` G009.006 — `test_topology_unhealthy_subnet()`, `test_topology_proposal_approved()`

### G010 — Attack Hotspot Defense

**Status:** 📋  
**Depends on:** G009  
**Files:** `crates/bkg-kernel/src/guards/attack.rs`

- `📋` G010.001 — `AttackDetector` mit 5 Patterns
- `📋` G010.002 — Pattern 1: Flood (>1000 msg/s)
- `📋` G010.003 — Pattern 2: InvalidReceipt (>50% ungültig)
- `📋` G010.004 — Pattern 3: TrustManipulation (künstliche Steigerung)
- `📋` G010.005 — Pattern 4: LedgerSpam
- `📋` G010.006 — Pattern 5: ReplayAttack
- `📋` G010.007 — Severity: Low→warn, Medium→drosseln, High→isolieren, Critical→bannen
- `📋` G010.008 — Motherbrain-Bestätigung (außer Critical)

### G011 — Attack Defense Tests

**Status:** 📋  
**Depends on:** G010  

- `📋` G011.001 — `test_attack_flood_detection()`, `test_attack_invalid_receipt()`
- `📋` G011.002 — `test_attack_trust_manipulation()`, `test_attack_severity_critical()`
- `📋` G011.003 — `test_attack_isolation_temporary()`

### G012 — Entropy Forecasting

**Status:** 📋  
**Depends on:** GC Foundation  
**Files:** `crates/bkg-kernel/src/gc/entropy.rs`

- `📋` G012.001 — `EntropyForecaster` Struct: Fenster von EntropySnapshots
- `📋` G012.002 — 3 Trend-Modelle: linear, exponential, moving average
- `📋` G012.003 — `forecast() -> Forecast`: trend_direction, confidence, next_peak_estimate
- `📋` G012.004 — Bei Instabilität → Mesh warnen
- `📋` G012.005 — `test_forecast_rising_trend()`, `test_forecast_confidence()`

### G013 — Knowledge Decay Engine

**Status:** 📋  
**Depends on:** G006 (Archive), Motherbrain M017 (Ledger)  
**Files:** `crates/bkg-kernel/src/knowledge/decay.rs`

- `📋` G013.001 — `DecayEngine` Struct + Config (default_ttl, revalidation_interval, max_age)
- `📋` G013.002 — `register(knowledge_id, ttl, source)`
- `📋` G013.003 — `expire()` — abgelaufene Einträge finden
- `📋` G013.004 — `decay_score(entry) -> f32` (0.0 frisch – 1.0 verfallen)
- `📋` G013.005 — Verfallen = archivieren (nicht löschen)
- `📋` G013.006 — Reanimation: neuer Receipt → Score 0.0
- `📋` G013.007 — Kernel-Tick: `decay_engine.expire()` aufrufen
- `📋` G013.008 — Ledger-Append: neuen Eintrag registrieren

### G014 — Decay Engine Tests

**Status:** 📋  
**Depends on:** G013  

- `📋` G014.001 — `test_decay_register_expire()`, `test_decay_revalidate()`
- `📋` G014.002 — `test_decay_score_time()`, `test_decay_archive_not_delete()`

### G015 — Garbage Collector Deep Tests

**Status:** 📋  
**Depends on:** G013  
**Files:** `crates/bkg-kernel/tests/gc_test.rs`

- `📋` G015.001 — `test_gc_entropy_tracker()`, `test_gc_decay_tagger()`
- `📋` G015.002 — `test_gc_topology_health()`, `test_gc_read_only_enforce()`
- `📋` G015.003 — `test_gc_start_observing()`

### G016 — Integration: Full GC → Mesh → Trust

**Status:** 📋  
**Depends on:** G015  

- `📋` G016.001 — `test_integration_mesh_gc_pipeline()` — Entropy→GC
- `📋` G016.002 — `test_integration_gc_trust_feedback()` — GC-Health→Trust

### G017 — Performance (Garbage Nodes)

**Status:** 📋  
**Depends on:** G016  

- `📋` G017.001 — Mesh Message-Batching optimieren
- `📋` G017.002 — GC Entropy-Processing parallelisieren

### G018 — Documentation (Garbage Nodes)

**Status:** 📋  
**Depends on:** G016  

- `📋` G018.001 — `docs/architektur/security_safety.md` syncen
- `📋` G018.002 — Mesh/GC-Architektur in `docs/llm.nfo` aktualisieren

### G019 — Update Tracking Files

**Status:** 📋  
**Depends on:** G018  

- `📋` G019.001 — Garbage-Status in `truth.md`
- `📋` G019.002 — `docs/progress.md` Garbage = 100%
- `📋` G019.003 — `task.md` Gold-Check

---

**✅ Garbage Alpha:** G001–G007 (Mesh Listener + Archive)  
**✅ Garbage Beta:** G001–G014 (+ Compactor, Topology, Attack, Decay)  
**✅ Garbage v1.0:** G001–G019 (+ Tests + Integration + Docs)
