# bESTKNOWNGarbage — Task: BKG Language

> **Eigene Sprache.** BKG-QL (Query Language) + BKG-DSL für Agent-Tasks.
>
> **Depends on:** Motherbrain (task-motherbrain.md)
>
> **Chain:** `task.md` ← `task-bkg-lang.md`

---

## Chain

```
B001 ─→ B002 ─→ B003 ─→ B004 ─→ B005 ─→ B006 ─→ B007 ─→ B008 ─→ B009 ─→ B010
 │        │        │        │        │        │        │        │        │        │
B011 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
B012 ─→ B013 ─→ B014 ─→ B015 ─→ B016 ─→ B017 ─→ B018 ─→ B019 ─→ B020
                                                                      │
B021 ────────────────────────────────────────────────────────────────┘
  │
B022 ─→ ... ─→ B030
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN B001–B009

### B001 — Language Design Document

**Status:** 📋  
**Depends on:** Motherbrain M043  
**Files:** `docs/architektur/bkg_language_spec.md`

- `📋` B001.001 — BKG-QL (Query Language): Ledger-Abfragen natürlichsprachlich
- `📋` B001.002 — BKG-DSL: Task-Beschreibungssprache für Agenten
- `📋` B001.003 — Syntax-Grundlagen: was macht die Sprache einzigartig?
- `📋` B001.004 — Beispiele: "Find alle Receipts von Node X mit Trust > 0.8"
- `📋` B001.005 — Beispiele: "Swarm-Validierung für Chunk Y anfordern"
- `📋` B001.006 — Abgrenzung: keine vollständige Programmiersprache, sondern eine Query/Action-Sprache

### B002 — BKG-QL: Parser (Tokens + AST)

**Status:** 📋  
**Depends on:** B001  
**Files:** `crates/bkg-ast/src/parser.rs`, `crates/bkg-ast/src/ast.rs`

- `📋` B002.001 — Token-Definition: SELECT, WHERE, FROM, FILTER, SORT, LIMIT
- `📋` B002.002 — Token-Definition: Schlüsselwörter für Trust, Receipt, Mesh, GC, Ledger
- `📋` B002.003 — Lexer: String → `Vec<Token>`
- `📋` B002.004 — AST-Nodes: `Query { select, from, filter, sort, limit }`
- `📋` B002.005 — AST-Nodes: `Filter { field, operator, value }`
- `📋` B002.006 — AST-Nodes: `Sort { field, direction }`

### B003 — BKG-QL: Interpreter

**Status:** 📋  
**Depends on:** B002  
**Files:** `crates/bkg-ast/src/interpreter.rs`

- `📋` B003.001 — `Interpreter::new(kernel_state)` — Zugriff auf Kernel
- `📋` B003.002 — `interpreter.execute(query) -> QueryResult`
- `📋` B003.003 — SELECT from Ledger: Receipts, Trust, Status
- `📋` B003.004 — SELECT from Mesh: Peers, Topologie, Messages
- `📋` B003.005 — SELECT from GC: Entropy, Archive, Health
- `📋` B003.006 — FILTER + SORT + LIMIT auf Resultsets
- `📋` B003.007 — Error-Handling: Unbekanntes Feld, Syntaxfehler

### B004 — BKG-DSL: Task-Sprache

**Status:** 📋  
**Depends on:** B002  
**Files:** `crates/bkg-ast/src/dsl.rs`

- `📋` B004.001 — Syntax: `TASK <name> { action: <type>, target: <id>, params: {…} }`
- `📋` B004.002 — Action: `SWARM_VALIDATE(chunk_id)` — Swarm-Validierung starten
- `📋` B004.003 — Action: `REPLAY_VERIFY(ledger_hash)` — Replay starten
- `📋` B004.004 — Action: `TRUST_QUERY(node_id)` — Trust-Status abfragen
- `📋` B004.005 — Action: `MESH_BROADCAST(message)` — Nachricht senden
- `📋` B004.006 — Action: `GC_COLLECT(region)` — GC-Lauf anstoßen
- `📋` B004.007 — Parser + Interpreter für DSL

### B005 — BKG-QL + DSL Tests

**Status:** 📋  
**Depends on:** B003, B004  
**Files:** `crates/bkg-ast/tests/`

- `📋` B005.001 — `test_ql_select_all()` — SELECT *
- `📋` B005.002 — `test_ql_select_filter()` — SELECT + WHERE
- `📋` B005.003 — `test_ql_sort_limit()` — SORT + LIMIT
- `📋` B005.004 — `test_ql_invalid_syntax()` — Syntaxfehler erkannt
- `📋` B005.005 — `test_dsl_swarm_task()` — SWARM_VALIDATE parsed
- `📋` B005.006 — `test_dsl_invalid_action()` — Unbekannte Action → Error

### B006 — CLI Integration

**Status:** 📋  
**Depends on:** B005  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` B006.001 — `bkg query "<BKG-QL>"` — Query ausführen
- `📋` B006.002 — `bkg task "<BKG-DSL>"` — Task ausführen
- `📋` B006.003 — `bkg shell` — REPL für BKG Language
- `📋` B006.004 — Tabellen-Output für Query-Ergebnisse
- `📋` B006.005 — JSON-Output (`--json`)

### B007 — API Integration

**Status:** 📋  
**Depends on:** B006  

- `📋` B007.001 — `POST /api/v1/query` — BKG-QL via REST
- `📋` B007.002 — `POST /api/v1/task` — BKG-DSL via REST

### B008 — BKG Language Docs

**Status:** 📋  
**Depends on:** B006  

- `📋` B008.001 — `docs/bkg-lang.md` (proj: `projects/bkg-lang`): Sprachreferenz mit Beispielen
- `📋` B008.002 — Cheat Sheet: häufige Queries + Tasks

### B009 — Update Tracking Files

**Status:** 📋  
**Depends on:** B008  

- `📋` B009.001 — BKG-Language in `truth.md`
- `📋` B009.002 — `docs/progress.md` BKG-Lang = 100%
- `📋` B009.003 — `docs/llm.nfo` syncen (Sprach-Referenz)
- `📋` B009.004 — `task.md` Gold-Check

---

**✅ BKG Lang Alpha:** B001–B004 (Design + Parser)  
**✅ BKG Lang Beta:** B001–B006 (+ Interpreter + CLI)  
**✅ BKG Lang v1.0:** B001–B009 (+ Tests + API + Docs)
