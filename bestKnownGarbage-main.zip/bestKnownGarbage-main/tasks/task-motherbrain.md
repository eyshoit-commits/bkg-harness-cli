# bESTKNOWNGarbage — Task: Motherbrain

> **Der Kern.** Adjudication, Trust, Ledger, WASM, Config, Boot.
>
> Kein anderer Bereich kann starten bevor Motherbrain läuft.
>
> **Chain:** `task.md` ← `task-motherbrain.md` → `task-client.md`, `task-web-wasm.md`, `task-garbage.md`

---

## Chain

```
M001 ─→ M002 ─→ M003 ─→ M004 ─→ M005 ─→ M006 ─→ M007 ─→ M008 ─→ M009 ─→ M010
 │        │        │        │        │        │        │        │        │        │
M011 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
M012 ─→ M013 ─→ M014 ─→ M015 ─→ M016 ─→ M017 ─→ M018 ─→ M019 ─→ M020
 │        │        │        │        │        │        │        │
M021 ────┴────────┴────────┴────────┴────────┘        │        │
                                                       │        │
M022 ──────────────────────────────────────────────────┘        │
                                                                  │
M023 ─────────────────────────────────────────────────────────────┘
  │
M024 ─→ M025 ─→ M026 ─→ M027 ─→ M028 ─→ M029 ─→ M030 ─→ M031 ─→ M032
  │        │        │        │        │        │        │        │
M033 ────┴────────┴────────┴────────┴────────┘        │        │
                                                       │        │
M034 ──────────────────────────────────────────────────┘        │
                                                                  │
M035 ─────────────────────────────────────────────────────────────┘
  │
M036 ─→ M037 ─→ M038 ─→ M039 ─→ M040 ─→ M041 ─→ M042 ─→ M043 ─→ M044
  │        │        │        │        │        │        │        │
M045 ────┴────────┴────────┴────────┘        │        │        │
                                               │        │        │
M046 ──────────────────────────────────────────┘        │        │
                                                          │        │
M047 ─────────────────────────────────────────────────────┘        │
                                                                    │
M048 ───────────────────────────────────────────────────────────────┘
  │
M049 ─→ M050 ─→ M051 ─→ M052 ─→ M053 ─→ M054 ─→ M055 ─→ M056 ─→ M057
  │        │        │        │        │        │        │        │
M058 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
M059 ─→ M060 ─→ ... ─→ M100  (Weiterleitung an Client/Web-WASM/Garbage)
  │
  └──→ [task-client.md] startet
  └──→ [task-web-wasm.md] startet
  └──→ [task-garbage.md] startet
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN M001–M100

### M001 — Dependency Upgrades

**State:** Planned  
**Depends on:** —  
**Files:** `Cargo.toml`, `crates/*/Cargo.toml`

Steps:
- `📋` M001.001 — `wasmtime` auf stabilste Version — `crates/bkg-kernel/Cargo.toml`
- `📋` M001.002 — `tokio` 1.x neuster Minor — `Cargo.toml`
- `📋` M001.003 — `thiserror`, `serde`, `serde_json`, `tracing` updaten
- `📋` M001.004 — `rusqlite` hinzufügen — `crates/bkg-kernel/Cargo.toml`
- `📋` M001.005 — `toml`, `dirs` hinzufügen — `crates/bkg-core/Cargo.toml`
- `📋` M001.006 — `signal-hook` hinzufügen — `crates/bkg-cli/Cargo.toml`
- `📋` M001.007 — `cargo update` + `cargo check --release` bestätigen

### M002 — Error Handling Overhaul

**Status:** 📋  
**Depends on:** M001  
**Files:** `crates/bkg-core/src/error.rs`

- `📋` M002.001 — Alle `unwrap()/expect()/panic!()` in `crates/bkg-kernel` ersetzen
- `📋` M002.002 — `TrustError`, `MeshError`, `LedgerError`, `WasmError` mit Varianten
- `📋` M002.003 — `BkgError` mit From-Impls
- `📋` M002.004 — Nicht-fatale Errors: Retry mit exponential backoff
- `📋` M002.005 — Fatale Errors: Shutdown-Sequenz triggern

### M003 — Build Infra + Workspace

**Status:** 📋  
**Depends on:** M001, M002  
**Files:** Root-`Cargo.toml`, `Makefile`, `rust-toolchain.toml`

- `📋` M003.001 — Release-Profile: LTO, `codegen-units=1`
- `📋` M003.002 — `rust-toolchain.toml` (stable) + `rustfmt.toml` + `clippy.toml`
- `📋` M003.003 — `Makefile`: check, test, lint, build-release
- `📋` M003.004 — `cargo clippy --all-targets -- -D warnings` durchsetzen

### M004 — Logging & Observability

**Status:** 📋  
**Depends on:** M001  
**Files:** `crates/bkg-core/src/logging.rs`

- `📋` M004.001 — `tracing-subscriber` mit JSON-Format
- `📋` M004.002 — `BKG_LOG` Environment-Variable
- `📋` M004.003 — Structured Fields: `node_id`, `module`, `phase`
- `📋` M004.004 — Span-basiertes Tracing

### M005 — Config Schema

**Status:** 📋  
**Depends on:** M001, M004  
**Files:** `crates/bkg-core/src/config.rs`, `bkg.example.toml`

- `📋` M005.001 — `BkgConfig` Struct: `[kernel]`, `[kernel.wasm]`, `[kernel.ledger]`, `[kernel.mesh]`, `[kernel.trust]`, `[logging]`, `[providers.*]`
- `📋` M005.002 — `serde::Deserialize` + `Default`
- `📋` M005.003 — Config-Validierung (fuel_limit > 0, tick_interval > 0)
- `📋` M005.004 — `bkg.example.toml`

### M006 — Config Loading

**Status:** 📋  
**Depends on:** M005  
**Files:** `crates/bkg-core/src/config.rs`

- `📋` M006.001 — Such-Pfade: `./bkg.toml` → `~/.config/bkg/bkg.toml` → `/etc/bkg/bkg.toml`
- `📋` M006.002 — `BkgConfig::load()` + `load_from(path)` + `merge_env()`
- `📋` M006.003 — CLI `--config` + `--print-config`
- `📋` M006.004 — Fehlerfall: Datei nicht gefunden → Defaults (kein Crash)

### M007 — Config Tests

**Status:** 📋  
**Depends on:** M006  
**Files:** `crates/bkg-core/tests/config_test.rs`

- `📋` M007.001 — `test_config_defaults()`, `test_config_toml_parse()`, `test_config_env_override()`
- `📋` M007.002 — `test_config_search_paths()`, `test_config_validation()`, `test_config_not_found()`

### M008 — wasmtime Engine Integration

**Status:** 📋  
**Depends on:** M001  
**Files:** `crates/bkg-kernel/src/wasm/engine.rs`

- `📋` M008.001 — `WasmEngine::new()`: wasmtime Engine mit Fuel + Memory-Limit
- `📋` M008.002 — `WasmEngine::compile_module(bytes) -> WasmModule`
- `📋` M008.003 — `WasmModule` Struct: Module, Hash, Size
- `📋` M008.004 — `WasmEngine::instantiate(module, env) -> WasmInstance`
- `📋` M008.005 — `WasmInstance::call(func, args) -> WasmValue`
- `📋` M008.006 — Fuel-Exhausted → `WasmError::FuelExhausted`
- `📋` M008.007 — Trap → `WasmError::Trap`
- `📋` M008.008 — Timeout → `WasmError::Timeout`

### M009 — Host-Funktionen (Imports)

**Status:** 📋  
**Depends on:** M008  
**Files:** `crates/bkg-kernel/src/wasm/host.rs`

- `📋` M009.001 — `WasmHostApi` Trait: print, read_input, write_output, emit_event
- `📋` M009.002 — Linker mit allen Imports
- `📋` M009.003 — Sandbox: kein FS, kein Netzwerk, kein Process

### M010 — ExecutionReceipt aus WASM

**Status:** 📋  
**Depends on:** M009  
**Files:** `crates/bkg-kernel/src/wasm/receipt.rs`

- `📋` M010.001 — `ExecutionReceipt` mit wasm_hash, fuel_used, result
- `📋` M010.002 — `ExecutionReceipt::hash()` deterministisch
- `📋` M010.003 — Serialisierung: serde

### M011 — WASM Engine Tests

**Status:** 📋  
**Depends on:** M010  
**Files:** `crates/bkg-kernel/tests/wasm_test.rs`

- `📋` M011.001 — `test_wasm_simple_add()`, `test_wasm_fuel_exhausted()`, `test_wasm_timeout()`
- `📋` M011.002 — `test_wasm_deterministic_hash()`, `test_receipt_from_wasm()`
- `📋` M011.003 — `test_wasm_host_print()`, `test_wasm_host_error()`

### M012 — WASM → Kernel Integration

**Status:** 📋  
**Depends on:** M011  
**Files:** `crates/bkg-kernel/src/kernel/mod.rs`

- `📋` M012.001 — `KernelState` mit `Arc<WasmEngine>`
- `📋` M012.002 — `collect_receipts()` produziert echte Receipts
- `📋` M012.003 — Receipts an `TrustEngine::update_node_trust()` übergeben
- `📋` M012.004 — Batch: 100 Receipts pro Tick

### M013 — SQLite Schema + LedgerStore

**Status:** 📋  
**Depends on:** M001  
**Files:** `crates/bkg-kernel/src/ledger/store.rs`, `migrations/001_init.sql`

- `📋` M013.001 — Tabellen: `ledger_entries`, `node_trust`, `execution_receipts`
- `📋` M013.002 — Indizes + WAL-Mode + Cache-Pragmas
- `📋` M013.003 — `LedgerStore::new(path)`, `new_in_memory()`
- `📋` M013.004 — Migration-System: Versionstabelle + auto-migrate

### M014 — Ledger CRUD

**Status:** 📋  
**Depends on:** M013  
**Files:** `crates/bkg-kernel/src/ledger/store.rs`

- `📋` M014.001 — `append()`, `query()`, `get_range()`, `get_latest()`, `height()`
- `📋` M014.002 — `prune()`, `integrity_check()`, `export()`, `import()`

### M015 — Ledger Trait + Adapter

**Status:** 📋  
**Depends on:** M014  
**Files:** `crates/bkg-kernel/src/ledger/mod.rs`

- `📋` M015.001 — `Ledger` Trait: append, query, height, integrity_check
- `📋` M015.002 — `RamLedger` (Tests) + `SqliteLedger` (Production)
- `📋` M015.003 — `LedgerFactory::create(config)`

### M016 — Ledger Tests

**Status:** 📋  
**Depends on:** M015  
**Files:** `crates/bkg-kernel/tests/ledger_test.rs`

- `📋` M016.001 — `test_ledger_append_query()`, `test_ledger_hash_chain()`, `test_ledger_integrity_tampered()`
- `📋` M016.002 — `test_ledger_concurrent()`, `test_ledger_large_entries(10000)`
- `📋` M016.003 — `test_ram_ledger_adapter()`, `test_sqlite_ledger_adapter()`

### M017 — Ledger → Kernel Integration

**Status:** 📋  
**Depends on:** M016  
**Files:** `crates/bkg-kernel/src/kernel/mod.rs`

- `📋` M017.001 — `KernelState` mit `Box<dyn Ledger>`
- `📋` M017.002 — Ledger aus Config erstellen
- `📋` M017.003 — `integrity_check()` im Kernel-Tick

### M018 — Async Tick Refactor

**Status:** 📋  
**Depends on:** — (parallel zu WASM/Ledger Chains)  
**Files:** `crates/bkg-kernel/src/kernel/loop.rs`

- `📋` M018.001 — `tick()` → `async fn tick()`
- `📋` M018.002 — Alle Sub-Funktionen async: collect_receipts, commit_stable_state, update_trust, poll_mesh, poll_gc, poll_heroes
- `📋` M018.003 — `tokio::time::interval(duration)` statt `thread::sleep`
- `📋` M018.004 — Tick lag tracking

### M019 — Spawn Elimination

**Status:** 📋  
**Depends on:** M018  
**Files:** `crates/bkg-kernel/src/kernel/loop.rs`

- `📋` M019.001 — TrustEngine-Update: direkt await statt spawn
- `📋` M019.002 — Mesh/GC/HeroDaemon: `tokio::select!` statt spawn
- `📋` M019.003 — Error-Propagation: Fehler → log + continue

### M020 — Async Tick Tests

**Status:** 📋  
**Depends on:** M019  
**Files:** `crates/bkg-kernel/tests/kernel_test.rs`

- `📋` M020.001 — `test_tick_async_execution()`, `test_tick_components_linearized()`
- `📋` M020.002 — `test_tick_error_nonfatal()`, `test_tick_interval()`, `test_tick_lag_warning()`

### M021 — Boot Phase 1–5

**Status:** 📋  
**Depends on:** M006 (Config), M012 (WASM), M017 (Ledger), M020 (Async)  
**Files:** `crates/bkg-kernel/src/boot.rs`

- `📋` M021.001 — `BootSequence` Struct: Phasen + Status + Timeout
- `📋` M021.002 — Phase 1: Config laden
- `📋` M021.003 — Phase 2: Logging init
- `📋` M021.004 — Phase 3: Ledger öffnen
- `📋` M021.005 — Phase 4: WASM Engine starten
- `📋` M021.006 — Phase 5: Kernel init

### M022 — Boot Phase 6–10

**Status:** 📋  
**Depends on:** M021  
**Files:** `crates/bkg-kernel/src/boot.rs`

- `📋` M022.001 — Phase 6: Mesh starten
- `📋` M022.002 — Phase 7: TrustEngine starten
- `📋` M022.003 — Phase 8: HeroDaemon starten
- `📋` M022.004 — Phase 9: GC starten
- `📋` M022.005 — Phase 10: Kernel-Tick starten
- `📋` M022.006 — Jede Phase loggen (start/success/failure)
- `📋` M022.007 — Fehler in Phase N → Cleanup N-1 .. 1 rückwärts
- `📋` M022.008 — Timeout pro Phase: 30s

### M023 — Boot Tests

**Status:** 📋  
**Depends on:** M022  
**Files:** `crates/bkg-kernel/tests/boot_test.rs`

- `📋` M023.001 — `test_boot_sequence_happy()`, `test_boot_phase_failure()`
- `📋` M023.002 — `test_boot_timeout()`, `test_boot_partial_cleanup()`

### M024 — Graceful Shutdown: Signal Handling

**Status:** 📋  
**Depends on:** M022  
**Files:** `crates/bkg-cli/src/shutdown.rs`

- `📋` M024.001 — SIGTERM + SIGINT → Shutdown
- `📋` M024.002 — SIGQUIT → Core-Dump
- `📋` M024.003 — SIGHUP → Config Reload (kein Shutdown)
- `📋` M024.004 — 1. Ctrl+C: Graceful (30s) / 2. Ctrl+C: Force-Kill

### M025 — Shutdown Phases 1–9

**Status:** 📋  
**Depends on:** M024  
**Files:** `crates/bkg-cli/src/shutdown.rs`

- `📋` M025.001 — Phase 1: Mesh drainen / Phase 2: GC flush / Phase 3: Ledger flush
- `📋` M025.002 — Phase 4: WASM cancel / Phase 5: TrustEngine persist
- `📋` M025.003 — Phase 6: Tick stoppen / Phase 7: Daemons joinen
- `📋` M025.004 — Phase 8: Ressourcen free / Phase 9: Log-Flush
- `📋` M025.005 — Result: "Shutdown complete (9/9 phases)"

### M026 — Shutdown Tests

**Status:** 📋  
**Depends on:** M025  
**Files:** `crates/bkg-cli/tests/shutdown_test.rs`

- `📋` M026.001 — `test_shutdown_sigterm()`, `test_shutdown_pending_persisted()`
- `📋` M026.002 — `test_shutdown_force_kill()`, `test_shutdown_timeout()`

### M027 — WriteSeparation: Motherbrain-only

**Status:** 📋  
**Depends on:** M015 (Ledger Trait)  
**Files:** `crates/bkg-kernel/src/ledger/mod.rs`, `crates/bkg-kernel/src/motherbrain/mod.rs`

- `📋` M027.001 — `WriteToken` Struct: nur Motherbrain erstellt Token
- `📋` M027.002 — `Ledger::append(entry, &WriteToken) -> Result`
- `📋` M027.003 — `Motherbrain::commit(entries) -> Result<()>` als einzige Schreibstelle
- `📋` M027.004 — Mesh/GC: kein WriteToken-Zugriff (Compile-Error)

### M028 — Collusion Detection: 6 Patterns

**Status:** 📋  
**Depends on:** TrustEngine existiert  
**Files:** `crates/bkg-kernel/src/trust_engine/collusion.rs`

- `📋` M028.001 — `CollusionDetector` Struct + Config
- `📋` M028.002 — Pattern 1: Echo-Score (identische Vektoren)
- `📋` M028.003 — Pattern 2: Sync-Burst (gleichzeitige Änderung)
- `📋` M028.004 — Pattern 3: Circular-Validation (A→B→C→A)
- `📋` M028.005 — Pattern 4: Rogue-Island (keine externe Bestätigung)
- `📋` M028.006 — Pattern 5: Trust-Farming (Steigerung ohne Arbeit)
- `📋` M028.007 — Pattern 6: Sybil-Cluster (gleicher Fingerabdruck)
- `📋` M028.008 — Score-Gewichtung + Confidence-Level + Schwellwert

### M029 — Collusion Integration + Tests

**Status:** 📋  
**Depends on:** M028  
**Files:** `crates/bkg-kernel/tests/collusion_test.rs`

- `📋` M029.001 — In TrustEngine integriert
- `📋` M029.002 — Bei Detektion: Event ans Mesh + Ledger-Log
- `📋` M029.003 — Alle 6 Patterns getestet + False-Positive-Test

### M030 — Swarm Validation: Formation

**Status:** 📋  
**Depends on:** M029  
**Files:** `crates/bkg-kernel/src/swarm/formation.rs`

- `📋` M030.001 — `SwarmCoordinator` Struct + Config
- `📋` M030.002 — `ValidationSwarm`: id, heroes (min 3, max 11), status, timeout
- `📋` M030.003 — Hero-Auswahl: TrustScore + Diversity + Availability

### M031 — Swarm Validation: Protocol

**Status:** 📋  
**Depends on:** M030  
**Files:** `crates/bkg-kernel/src/swarm/protocol.rs`

- `📋` M031.001 — `dispatch_validation(swarm, chunk)` + `collect_results(swarm)`
- `📋` M031.002 — Consensus: Quorum-Regel
- `📋` M031.003 — Dissent-Report + Timeout-Handling
- `📋` M031.004 — Retry bei fehlendem Consensus

### M032 — Swarm Tests

**Status:** 📋  
**Depends on:** M031  
**Files:** `crates/bkg-kernel/tests/swarm_test.rs`

- `📋` M032.001 — `test_swarm_consensus_majority()`, `test_swarm_consensus_failure()`
- `📋` M032.002 — `test_swarm_timeout_handling()`, `test_swarm_retry_on_failure()`

### M033 — Motherbrain Adjudication Engine

**Status:** 📋  
**Depends on:** M029 (Collusion), M031 (Swarm), M027 (WriteSeparation)  
**Files:** `crates/bkg-kernel/src/motherbrain/adjudication.rs`

- `📋` M033.001 — `AdjudicationEngine`: Rules 1–6
- `📋` M033.002 — Rule 1: Trusted Collector → Accepted
- `📋` M033.003 — Rule 2: Swarm-validiert → Accepted (höheres Gewicht)
- `📋` M033.004 — Rule 3: Unknown Node → PendingReview
- `📋` M033.005 — Rule 4: Widerspricht Ledger → Contested
- `📋` M033.006 — Rule 5: Collusion-Verdacht → Rejected
- `📋` M033.007 — Rule 6: Swarm-Verdikt überschreibt Collector-Trust

### M034 — GlobalState + Adjudication Tests

**Status:** 📋  
**Depends on:** M033  
**Files:** `crates/bkg-kernel/src/motherbrain/state.rs`, `crates/bkg-kernel/tests/motherbrain_test.rs`

- `📋` M034.001 — `GlobalState`: truth, consensus, divergence, stability
- `📋` M034.002 — Rule-Tests: accept/swarm/reject/contested
- `📋` M034.003 — `test_motherbrain_commit_cycle()`

### M035 — Reality Anchor (RAL/PWBL)

**Status:** 📋  
**Depends on:** M017 (Ledger)  
**Files:** `crates/bkg-kernel/src/ral/pwbl.rs`

- `📋` M035.001 — `PhysicalWorldBindingLayer` Trait
- `📋` M035.002 — `NullPWBL` + `RAL::reality_check(entry) -> RealityScore`
- `📋` M035.003 — Score < 0.5 → PendingReview / < 0.2 → Contested
- `📋` M035.004 — RAL-Hook in Adjudication aufrufen

### M036 — Replay Engine Verify

**Status:** 📋  
**Depends on:** M012 (WASM), M017 (Ledger)  
**Files:** `crates/bkg-kernel/src/replay/verify.rs`

- `📋` M036.001 — `ReplayEngine::verify(ledger_snapshot) -> ReplayVerdict`
- `📋` M036.002 — Schritt 1–6: Ledger iterieren, Receipts neu ausführen, Hashes vergleichen
- `📋` M036.003 — Divergenz: mark + continue (nicht abbrechen)

### M037 — Talmud-Style Escalation

**Status:** 📋  
**Depends on:** M034 (Adjudication)  
**Files:** `crates/bkg-kernel/src/escalation/talmud.rs`

- `📋` M037.001 — Stage 1: Direct Negotiation (10s)
- `📋` M037.002 — Stage 2: Peer Review, 2 Heroes (30s)
- `📋` M037.003 — Stage 3: Panel Hearing, 5 Heroes (60s)
- `📋` M037.004 — Stage 4: Oracle Call via RAL (120s)
- `📋` M037.005 — Stage 5: Final Adjudication (Motherbrain)
- `📋` M037.006 — Escalation-Record + Abort-Möglichkeit

### M038 — HeroDaemon Auto-Start

**Status:** 📋  
**Depends on:** M022 (Boot)  
**Files:** `crates/bkg-kernel/src/trust_engine/hero_daemon.rs`

- `📋` M038.001 — `HeroDaemon::start()` + `stop()` via CancellationToken
- `📋` M038.002 — Config-Interval (30s) + Jitter (±25%)
- `📋` M038.003 — Boot Phase 8 integriert, Shutdown Phase 6 integriert

### M039 — Trust Engine Deep Tests

**Status:** 📋  
**Depends on:** TrustEngine existiert  
**Files:** `crates/bkg-kernel/tests/trust_engine_test.rs`

- `📋` M039.001 — `test_trust_vector_update()`, `test_escalation_promotion/demotion()`
- `📋` M039.002 — `test_trust_engine_batch_update(100)` + concurrent

### M040 — Deterministic Replay Tests

**Status:** 📋  
**Depends on:** M036 (Replay)  
**Files:** `crates/bkg-kernel/tests/determinism_test.rs`

- `📋` M040.001 — `test_same_input_same_output()`, `test_same_receipt_same_hash()`
- `📋` M040.002 — `test_no_hidden_io()`, `test_replay_identical()`, `test_replay_divergent()`

### M041 — Error Handling + Logging Tests

**Status:** 📋  
**Depends on:** M002  
**Files:** `crates/bkg-kernel/tests/error_test.rs`

- `📋` M041.001 — `test_error_display()`, `test_error_propagation_kernel()`
- `📋` M041.002 — `test_error_nonfatal_continues()`, `test_error_no_panics()`

### M042 — HeroDaemon Tests

**Status:** 📋  
**Depends on:** M038  
**Files:** `crates/bkg-kernel/tests/hero_daemon_test.rs`

- `📋` M042.001 — `test_hero_daemon_start_stop()`, `test_hero_daemon_interval()`
- `📋` M042.002 — `test_hero_daemon_promotion_executed()`, `test_hero_daemon_demotion_executed()`

### M043 — Integration: Mesh → GC → Trust

**Status:** 📋  
**Depends on:** Alle Module implementiert  
**Files:** `crates/bkg-kernel/tests/integration_test.rs`

- `📋` M043.001 — `test_integration_mesh_gc_pipeline()`
- `📋` M043.002 — `test_integration_trust_mesh_propagation()`
- `📋` M043.003 — `test_integration_full_pipeline(Mesh→GC→Trust→Motherbrain→Ledger)`
- `📋` M043.004 — `test_integration_boot_to_shutdown()`
- `📋` M043.005 — `test_integration_100_nodes()`

### M044 — Performance Tuning (Motherbrain)

**Status:** 📋  
**Depends on:** M043  
**Files:** Diverse

- `📋` M044.001 — Lock-Contention-Analyse (`tokio-console`)
- `📋` M044.002 — `tick()` Hot Path messen
- `📋` M044.003 — Ledger: Batch-Appends (100 Receipts → 1 TX)
- `📋` M044.004 — WASM: Engine-Caching

### M045 — Documentation (Motherbrain)

**Status:** 📋  
**Depends on:** M043  

- `📋` M045.001 — `docs/architektur/kernel_spezifikation.md` syncen
- `📋` M045.002 — `docs/architektur/trust_engine_design.md` syncen
- `📋` M045.003 — `docs/architektur/relay_chain.md` syncen

### M046 — Update Tracking Files

**Status:** 📋  
**Depends on:** M043  
**Files:** `truth.md`, `docs/progress.md`, `task.md`

- `📋` M046.001 — Motherbrain-Status in `truth.md` eintragen
- `📋` M046.002 — `docs/progress.md` Phase 1+2 = 100%
- `📋` M046.003 — `task.md` Gold-Check aktualisieren
- `📋` M046.004 — `docs/llm.nfo` bei Architektur-Änderungen syncen

---

**✅ Motherbrain Alpha erreicht:** M001–M017 komplett  
**✅ Motherbrain Beta erreicht:** M001–M037 komplett  
**✅ Motherbrain v1.0 erreicht:** M001–M046 komplett  
**→ Übergabe an:** `task-client.md`, `task-web-wasm.md`, `task-garbage.md`
