# bESTKNOWNGarbage — Task: Guard LLM

> **Eigener Guard LLM.** Ein spezialisiertes Modell, das Trust-Scoring, Collusion-Erkennung und Attack-Detection im BKG-Kernel übernimmt.
>
> **Depends on:** Motherbrain (task-motherbrain.md) + Garbage (task-garbage.md)
>
> **Chain:** `task.md` ← `task-guard-llm.md`

---

## Chain

```
L001 ─→ L002 ─→ L003 ─→ L004 ─→ L005 ─→ L006 ─→ L007 ─→ L008 ─→ L009 ─→ L010
 │        │        │        │        │        │        │        │        │        │
L011 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
L012 ─→ L013 ─→ L014 ─→ L015 ─→ L016 ─→ L017 ─→ L018 ─→ L019 ─→ L020
                                                                      │
L021 ────────────────────────────────────────────────────────────────┘
  │
L022 ─→ ... ─→ L040
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN L001–L010

### L001 — Guard LLM: Requirements & Design

**Status:** 📋  
**Depends on:** Motherbrain M043 (Integration fertig)  
**Files:** `docs/architektur/guard_llm_design.md`

- `📋` L001.001 — Anforderungsdokument: was soll der Guard LLM können?
- `📋` L001.002 — Use Cases: Trust-Scoring, Collusion-Detection, Attack-Erkennung, Anomalie-Scoring
- `📋` L001.003 — Modell-Architektur: Small LM (< 1B Parameter) oder Embedding-basiert?
- `📋` L001.004 — Entscheid: eigenes Modell trainieren vs. Fine-Tune vs. Rule-based + ML
- `📋` L001.005 — Datengrundlage: welche Features fließen ein? (Trust-Vektoren, Receipts, Mesh-Topologie, Entropy)

### L002 — Training Data Pipeline

**Status:** 📋  
**Depends on:** L001  
**Files:** `guard-llm/data/pipeline.rs`, `guard-llm/data/`

- `📋` L002.001 — Data Extractor: TrustEngine-Zustände als Trainingsdaten exportieren
- `📋` L002.002 — Data Extractor: Collusion-Patterns als Labeled Data
- `📋` L002.003 — Data Extractor: Attack-Szenarien (simuliert)
- `📋` L002.004 — Feature-Vector-Definition: welche Felder aus dem Kernel?
- `📋` L002.005 — Preprocessing: Normalisierung, Encoding, Balancing
- `📋` L002.006 — Dataset-Split: Train/Validation/Test (70/15/15)
- `📋` L002.007 — Synthetic Data Generation für Edge Cases

### L003 — Modell-Architektur

**Status:** 📋  
**Depends on:** L001  
**Files:** `guard-llm/model/`

- `📋` L003.001 — Entscheid: Transformer, XGBoost, Random Forest, oder Hybrid?
- `📋` L003.002 — Input-Encoding: TrustVector + Receipt-Hash + Mesh-Status als Embedding
- `📋` L003.003 — Output: Collusion-Score (0.0–1.0), Attack-Classification, Trust-Prediction
- `📋` L003.004 — Modell-Größe: Ziel < 50MB für schnelle Inference
- `📋` L003.005 — ONNX-Export für Runtime-Inference

### L004 — Training Pipeline

**Status:** 📋  
**Depends on:** L002 (Data), L003 (Architektur)  
**Files:** `guard-llm/train/`

- `📋` L004.001 — Python-Trainings-Skript (PyTorch / JAX)
- `📋` L004.002 — Loss-Funktion: Binary Cross-Entropy + Focal Loss für Imbalance
- `📋` L004.003 — Hyperparameter-Optimierung (Learning Rate, Batch Size, Epochs)
- `📋` L004.004 — Evaluation: Precision, Recall, F1, AUC-ROC
- `📋` L004.005 — Overfitting-Check: Early Stopping + Regularization
- `📋` L004.006 — Modell-Export: ONNX + quantisiert (INT8)

### L005 — Model Evaluation

**Status:** 📋  
**Depends on:** L004  
**Files:** `guard-llm/eval/`

- `📋` L005.001 — Test-Suite: 1000 synthetische Szenarien
- `📋` L005.002 — False-Positive-Rate < 1% (kein normaler Node als Angreifer)
- `📋` L005.003 — False-Negative-Rate < 5% (Angreifer wird erkannt)
- `📋` L005.004 — Inference-Latenz: < 10ms pro Prediction
- `📋` L005.005 — Vergleich mit Rule-Based Detection (Konsistenz-Check)

### L006 — Rust Inference Engine

**Status:** 📋  
**Depends on:** L005  
**Files:** `crates/bkg-kernel/src/guard_llm/`

- `📋` L006.001 — `tract-onnx` oder `ort` (ONNX Runtime) als Dependency
- `📋` L006.002 — `GuardLlm` Struct: `model: OnnxModel`, config
- `📋` L006.303 — `GuardLlm::new(model_path) -> Result<Self>`
- `📋` L006.004 — `GuardLlm::predict(features) -> GuardPrediction`
- `📋` L006.005 — `GuardPrediction`: collusion_score, attack_class, confidence
- `📋` L006.006 — Batch-Prediction: 100 Samples pro Aufruf
- `📋` L006.007 — Caching: identische Inputs cached (LRU, 1000 Einträge)

### L007 — Kernel Integration

**Status:** 📋  
**Depends on:** L006  
**Files:** `crates/bkg-kernel/src/kernel/mod.rs`

- `📋` L007.001 — `GuardLlm` in `KernelState` integriert
- `📋` L007.002 — TrustEngine-Tick: Features sammeln → GuardLlm.predict()
- `📋` L007.003 — Prediction fließt in CollusionDetection + Adjudication ein
- `📋` L007.004 — Fallback: wenn Guard LLM nicht verfügbar → Rule-Based Detection

### L008 — Guard LLM Tests

**Status:** 📋  
**Depends on:** L007  

- `📋` L008.001 — `test_guard_llm_load_model()` — Modell lädt
- `📋` L008.002 — `test_guard_llm_predict()` — Prediction korrekt
- `📋` L008.003 — `test_guard_llm_batch()` — Batch-Prediction
- `📋` L008.004 — `test_guard_llm_cache()` — Cache trifft
- `📋` L008.005 — `test_guard_llm_fallback()` — Ohne Modell → Rule-Based
- `📋` L008.006 — `test_guard_llm_integration()` — Im Kernel-Tick integriert

### L009 — Performance: Guard LLM

**Status:** 📋  
**Depends on:** L008  

- `📋` L009.001 — Inference-Latenz optimieren (< 5ms)
- `📋` L009.002 — Quantisiertes Modell (INT8) vs. FP32 vergleichen
- `📋` L009.003 — GPU-Beschleunigung (CUDA / Metal) optional
- `📋` L009.004 — Modell-Update ohne Kernel-Neustart (Hot-Reload)

### L010 — Documentation + Update

**Status:** 📋  
**Depends on:** L009  

- `📋` L010.001 — `docs/architektur/guard_llm_design.md` fertigstellen
- `📋` L010.002 — Guard LLM in `truth.md` eintragen
- `📋` L010.003 — `docs/progress.md` Guard LLM = 100%
- `📋` L010.004 — `docs/llm.nfo` syncen

---

**✅ Guard LLM Alpha:** L001–L005 (Design + Data + Training)  
**✅ Guard LLM Beta:** L001–L007 (+ Rust Engine + Kernel Integration)  
**✅ Guard LLM v1.0:** L001–L010 (+ Tests + Performance + Docs)
