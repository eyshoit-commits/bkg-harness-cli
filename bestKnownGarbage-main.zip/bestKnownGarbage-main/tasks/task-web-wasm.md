# bESTKNOWNGarbage — Task: Web-WASM

> **Web Presence.** Dioxus Landing Page, WASM-Bindings, Web-Demo.
>
> **Depends on:** Motherbrain (task-motherbrain.md) M012 (WASM Engine).
>
> **Chain:** `task.md` ← `task-web-wasm.md`

---

## Chain

```
W001 ─→ W002 ─→ W003 ─→ W004 ─→ W005 ─→ W006 ─→ W007 ─→ W008 ─→ W009 ─→ W010
 │        │        │        │        │        │        │        │        │        │
W011 ────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┴────────┘
  │
W012 ─→ W013 ─→ W014 ─→ W015 ─→ W016 ─→ W017 ─→ W018 ─→ W019 ─→ W020
                                                                      │
W021 ────────────────────────────────────────────────────────────────┘
  │
W022 ─→ ... ─→ W050
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN W001–W050

### W001 — wasm-bindgen Bindings

**State:** Planned  
**Depends on:** Motherbrain M012 (WASM Engine)  
**Files:** `projects/bkg-web/src/lib.rs`

- `📋` W001.001 — `wasm-bindgen` als Dependency in `projects/bkg-web/Cargo.toml`
- `📋` W001.002 — `#[wasm_bindgen]`-Export: `BkgKernel`-Wrapper für Browser
- `📋` W001.003 — `BkgKernel::new(config)` — Kernel im Browser initialisieren
- `📋` W001.004 — `BkgKernel::chat(prompt) -> String`
- `📋` W001.005 — `BkgKernel::status() -> JsValue` (JSON)
- `📋` W001.006 — `BkgKernel::process_wasm(bytes) -> String`
- `📋` W001.007 — JS-Callback für Events (`on_receipt`, `on_error`)

### W002 — Virtual Filesystem (WASM)

**Status:** 📋  
**Depends on:** W001  
**Files:** `projects/bkg-web/src/vfs.rs`

- `📋` W002.001 — `VirtualFileSystem` Struct: in-memory
- `📋` W002.002 — `vfs.read(path) -> Option<Vec<u8>>`
- `📋` W002.003 — `vfs.write(path, data)`
- `📋` W002.004 — `vfs.list(dir) -> Vec<String>`
- `📋` W002.005 — `vfs.mount_js(js_object)` — aus JS injecten

### W003 — IndexedDB Storage

**Status:** 📋  
**Depends on:** W002  
**Files:** `projects/bkg-web/src/storage.rs`

- `📋` W003.001 — `IndexedDbStorage` Struct via `wasm-bindgen`
- `📋` W003.002 — `storage.save(key, value)` — persist in Browser
- `📋` W003.003 — `storage.load(key) -> Option<Vec<u8>>`
- `📋` W003.004 — `storage.delete(key)`
- `📋` W003.005 — Ledger-Persistence via IndexedDB im Browser

### W004 — Dioxus Landing Page: Content

**Status:** 📋  
**Depends on:** —  
**Files:** `projects/bkg-web/src/main.rs`, `projects/bkg-web/src/pages/`

- `📋` W004.001 — Section 1: Hero (Vision Statement)
- `📋` W004.002 — Section 2: Architecture Diagram (interaktiv)
- `📋` W004.003 — Section 3: Trust Engine Visualisierung
- `📋` W004.004 — Section 4: Mesh → GC Demo (animiert)
- `📋` W004.005 — Section 5: Live Trust-Stream
- `📋` W004.006 — Section 6: Execution Receipt Explorer
- `📋` W004.007 — Section 7: Swarm Validation Panel
- `📋` W004.008 — Section 8: Collusion Heatmap
- `📋` W004.009 — Section 9–20: Restliche Panels (Doku, API, Team, etc.)

### W005 — Dioxus UI Components

**Status:** 📋  
**Depends on:** W004  
**Files:** `projects/bkg-web/src/components/`

- `📋` W005.001 — `StatusBar`: Kernel online/offline, peers, health
- `📋` W005.002 — `TrustMeter`: Trust-Score-Diagramm
- `📋` W005.003 — `MeshGraph`: Node-Topologie (SVG/Canvas)
- `📋` W005.004 — `LiveTerminal`: Echtzeit-Logs
- `📋` W005.005 — `ReceiptExplorer`: Durch Receipts browsen
- `📋` W005.006 — `GuardNode`-Widget: Security-Status
- `📋` W005.007 — Responsive Design: Mobile + Desktop

### W006 — Dioxus Build + Optimierung

**Status:** 📋  
**Depends on:** W005  
**Files:** `projects/bkg-web/Dioxus.toml`, `projects/bkg-web/Cargo.toml`

- `📋` W006.001 — Dioxus CLI: `dx build --release`
- `📋` W006.002 — WASM-Größe: `wasm-opt -Oz` (Ziel: < 500KB)
- `📋` W006.003 — Lazy-Loading für Sections
- `📋` W006.004 — CSS: Tailwind oder Dioxus-Stil-System
- `📋` W006.005 — Assets: Bilder, Fonts, Favicon

### W007 — Web-Demo (Browser)

**Status:** 📋  
**Depends on:** W006  
**Files:** `projects/bkg-web/demo/`

- `📋` W007.001 — Mini-Kernel im Browser: wasm-bindgen kompiliert
- `📋` W007.002 — Demo-Panel: "Start Mesh", "Run WASM", "Check Trust"
- `📋` W007.003 — Live-Output-Fenster für Receipts
- `📋` W007.004 — Beispiel-WASM-Modul zum Ausführen
- `📋` W007.005 — Interaktives Trust-Diagramm

### W008 — Performance: WASM im Browser

**Status:** 📋  
**Depends on:** W007  
**Files:** `projects/bkg-web/src/`

- `📋` W008.001 — Web-Worker für Kernel (nicht UI-Thread blockieren)
- `📋` W008.002 — Message-Passing: UI ↔ Worker
- `📋` W008.003 — WASM-Lazy-Loading: Kernel erst bei Bedarf laden
- `📋` W008.004 — Bundle-Splitting für Sections

### W009 — Web-WASM Tests

**Status:** 📋  
**Depends on:** W008  

- `📋` W009.001 — `wasm-pack test --chrome` — Browser-Tests
- `📋` W009.002 — `test_wasm_bindgen_kernel()` — Kernel via wasm-bindgen
- `📋` W009.003 — `test_vfs_read_write()` — Virtual FS roundtrip
- `📋` W009.004 — `test_indexeddb_persist()` — IndexedDB Speicher
- `📋` W009.005 — UI-Komponenten-Tests (Dioxus)

### W010 — CI/CD (Web-WASM)

**Status:** 📋  
**Depends on:** W009  

- `📋` W010.001 — CI-Step: `dx build --release`
- `📋` W010.002 — CI-Step: `wasm-pack test --chrome`
- `📋` W010.003 — CI: wasm-opt + size-check
- `📋` W010.004 — Deploy: GitHub Pages / Netlify / Vercel

### W011 — Web-WASM Release

**Status:** 📋  
**Depends on:** W010  

- `📋` W011.001 — Domain: bkg-wasm.dev (oder neue)
- `📋` W011.002 — HTTPS + CDN
- `📋` W011.003 — SEO: Meta-Tags, OG-Images, Sitemap
- `📋` W011.004 — Analytics (optional, datenschutzkonform)

### W012 — Update Tracking Files

**Status:** 📋  
**Depends on:** W011  

- `📋` W012.001 — Web-WASM in `truth.md` ergänzen
- `📋` W012.002 — `docs/progress.md` Web-WASM = 100%
- `📋` W012.003 — `docs/llm.nfo` bei Architektur-Änderungen syncen

---

**✅ Web-WASM Alpha:** W001–W006 (Dioxus Page + WASM-Bindings)  
**✅ Web-WASM Beta:** W001–W009 (+ Web-Demo + Tests)  
**✅ Web-WASM v1.0:** W001–W012 (+ CI/CD + Release)
