# bESTKNOWNGarbage — Task: Client

> **Public Interface.** CLI, API, SDK, Metrics.
>
> **Depends on:** Motherbrain (task-motherbrain.md) M046 abgeschlossen.
>
> **Chain:** `task.md` ← `task-client.md` → `task-web-wasm.md`

---

## Chain

```
C001 ─→ C002 ─→ C003 ─→ C004 ─→ C005 ─→ C006 ─→ C007 ─→ C008 ─→ C009 ─→ C010
                                                                                │
C011 ──────────────────────────────────────────────────────────────────────────┘
  │
C012 ─→ C013 ─→ C014 ─→ C015 ─→ C016 ─→ C017 ─→ C018 ─→ C019 ─→ C020
                                                                      │
C021 ────────────────────────────────────────────────────────────────┘
  │
C022 ─→ ... ─→ C040
```

---

## TaskState Machine

> Jeder Step hat einen nachvollziehbaren Zustand (Mini-Ledger).

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

| State | Bedeutung |
|-------|-----------|
| `Planned` | Noch nicht bearbeitet (Default) |
| `InProgress` | Wird aktuell bearbeitet |
| `Review` | Fertig, wartet auf Verifikation |
| `Verified` | Akzeptiert, abgeschlossen |
| `Blocked` | Abhängigkeit nicht erfüllt |
| `Frozen` | Bewusst eingefroren (Interface-Change nötig) |

---

## CHAIN C001–C040

### C001 — CLI `bkg start`

**State:** Planned  
**Depends on:** Motherbrain M022 (Boot Sequence)  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` C001.001 — `bkg start` ruft `BootSequence::run()` auf
- `📋` C001.002 — Start-Log mit Phasen-Fortschritt
- `📋` C001.003 — Daemon-Mode: fork in Hintergrund (`bkg start --daemon`)

### C002 — CLI `bkg stop`

**Status:** 📋  
**Depends on:** Motherbrain M025 (Shutdown)  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` C002.001 — `bkg stop` sendet SIGTERM an laufenden Prozess
- `📋` C002.002 — Wartet auf Shutdown-Bestätigung (max 30s)

### C003 — CLI `bkg status`

**Status:** 📋  
**Depends on:** Motherbrain M022  
**Files:** `crates/bkg-cli/src/status.rs`

- `📋` C003.001 — Summary: Kernel running/stopped, uptime, tick-count
- `📋` C003.002 — Trust: hero-count, collector-count, avg-trust
- `📋` C003.003 — Mesh: peers, messages-sent/received, connected
- `📋` C003.004 — GC: entropy-level, archive-size, health-score
- `📋` C003.005 — Ledger: height, entries, integrity-ok
- `📋` C003.006 — `--verbose` für detaillierte Metriken
- `📋` C003.007 — `--json` für JSON-Output
- `📋` C003.008 — `--watch` für Live-Update alle 2s

### C004 — CLI `bkg chat`

**Status:** 📋  
**Depends on:** —  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` C004.001 — Bestehenden Chat-Befehl aufräumen (aktuell hardcoded response)
- `📋` C004.002 — LLM-Provider aus Config laden
- `📋` C004.003 — Streaming-Response in Terminal
- `📋` C004.004 — Tool-Execution in Chat integrieren

### C005 — CLI `bkg replay`

**Status:** 📋  
**Depends on:** Motherbrain M036 (Replay)  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` C005.001 — `bkg replay` → vollständiges Replay
- `📋` C005.002 — `bkg replay --quick` → nur Hash-Check
- `📋` C005.003 — `bkg replay --since <hash>` → ab bestimmten Punkt
- `📋` C005.004 — Report: valid/invalid + Divergenzen

### C006 — CLI `bkg config`

**Status:** 📋  
**Depends on:** Motherbrain M006 (Config)  
**Files:** `crates/bkg-cli/src/main.rs`

- `📋` C006.001 — `bkg config --print` zeigt aktive Config
- `📋` C006.002 — `bkg config --path` zeigt Config-Pfad
- `📋` C006.003 — `bkg config --validate` prüft Config

### C007 — CLI `bkg metrics`

**Status:** 📋  
**Depends on:** C003 (Status)  
**Files:** `crates/bkg-cli/src/metrics.rs`

- `📋` C007.001 — `bkg metrics` als CLI-Command
- `📋` C007.002 — `bkg metrics --json` für JSON-Export

### C008 — CLI Tests

**Status:** 📋  
**Depends on:** C007  
**Files:** `crates/bkg-cli/tests/cli_test.rs`

- `📋` C008.001 — `test_cli_start_stop()`, `test_cli_status_summary()`, `test_cli_status_json()`
- `📋` C008.002 — `test_cli_replay()`, `test_cli_config()` 

### C009 — Prometheus Metrics Endpoint

**Status:** 📋  
**Depends on:** C007  
**Files:** `crates/bkg-cli/src/metrics.rs`

- `📋` C009.001 — `GET /metrics` auf localhost:9090
- `📋` C009.002 — `bkg_wasm_executions_total`, `bkg_trust_updates_total`
- `📋` C009.003 — `bkg_mesh_messages_total`, `bkg_ledger_entries_total`
- `📋` C009.004 — `bkg_hero_count`, `bkg_mesh_peers`

### C010 — Health Endpoint

**Status:** 📋  
**Depends on:** C009  
**Files:** `crates/bkg-cli/src/metrics.rs`

- `📋` C010.001 — `GET /health` → 200 OK oder 503 Service Unavailable
- `📋` C010.002 — Health-Check: Kernel, Trust, Mesh, GC, Ledger

### C011 — Public API Library

**Status:** 📋  
**Depends on:** Motherbrain M043 (Integration)  
**Files:** `crates/bkg-api/src/`

- `📋` C011.001 — Rust Client Lib: `BkgClient::connect(url)`
- `📋` C011.002 — `client.status() -> StatusResponse`
- `📋` C011.003 — `client.chat(prompt) -> Streaming<Response>`
- `📋` C011.004 — `client.replay() -> ReplayReport`
- `📋` C011.005 — `client.metrics() -> MetricsSnapshot`
- `📋` C011.006 — Error-Handling: ConnectionRefused, Timeout, AuthFailed

### C012 — HTTP Server (für API)

**Status:** 📋  
**Depends on:** C011  
**Files:** `crates/bkg-api/src/server.rs`

- `📋` C012.001 — HTTP-Server (axum/actix) für Remote-API
- `📋` C012.002 — `GET /api/v1/status` → StatusResponse
- `📋` C012.003 — `POST /api/v1/chat` → SSE-Stream
- `📋` C012.004 — `GET /api/v1/metrics` → Prometheus
- `📋` C012.005 — `GET /api/v1/health` → Health
- `📋` C012.006 — `POST /api/v1/replay` → ReplayReport
- `📋` C012.007 — Rate-Limiting pro Endpoint
- `📋` C012.008 — API-Key Authentifizierung (optional)

### C013 — API Tests

**Status:** 📋  
**Depends on:** C012  
**Files:** `crates/bkg-api/tests/`

- `📋` C013.001 — `test_api_status()`, `test_api_chat()`, `test_api_metrics()`
- `📋` C013.002 — `test_api_health()`, `test_api_rate_limit()`, `test_api_auth()`

### C014 — CLI Polish: Output-Formatierung

**Status:** 📋  
**Depends on:** C007  

- `📋` C014.001 — Tabellen-Output für `bkg status` (pretty tables)
- `📋` C014.002 — Farben: grün/rot/gelb für Status
- `📋` C014.003 — Progress-Bar für Boot-Sequenz

### C015 — CI/CD Pipeline (Client-Teil)

**Status:** 📋  
**Depends on:** C013  
**Files:** `.github/workflows/ci.yml`

- `📋` C015.001 — CI-Step: `cargo check --release`
- `📋` C015.002 — CI-Step: `cargo clippy --all-targets -- -D warnings`
- `📋` C015.003 — CI-Step: `cargo test`
- `📋` C015.004 — CI-Step: `cargo fmt --check`
- `📋` C015.005 — CI-Step: `cargo audit`
- `📋` C015.006 — CI-Cache für `~/.cargo` und `target/`
- `📋` C015.007 — CI-Matrix: stable + nightly (nightly darf failen)
- `📋` C015.008 — Dependabot: weekly updates

### C016 — Release Build

**Status:** 📋  
**Depends on:** C015  
**Files:** `.github/workflows/release.yml`, `Makefile`

- `📋` C016.001 — `cargo build --release` (LTO, codegen-units=1)
- `📋` C016.002 — Binary-Stripping: `strip target/release/bkg`
- `📋` C016.003 — Tarball: `bkg-{version}-{arch}-{os}.tar.gz` + SHA256
- `📋` C016.004 — GitHub Release: Tag → Upload Assets
- `📋` C016.005 — `bkg --version` korrekt

### C017 — Client Documentation

**Status:** 📋  
**Depends on:** C016  

- `📋` C017.001 — `docs/cli.md`: alle Befehle mit Beispielen
- `📋` C017.002 — `docs/api.md`: REST-API-Referenz
- `📋` C017.003 — `docs/config.md`: Config-Reference

### C018 — Update Tracking Files

**Status:** 📋  
**Depends on:** C017  

- `📋` C018.001 — Client-Status in `truth.md`: CLI, API, Metrics
- `📋` C018.002 — `docs/progress.md` Client = 100%
- `📋` C018.003 — `task.md` Gold-Check aktualisieren

---

**✅ Client Alpha:** C001–C008  
**✅ Client Beta:** C001–C014  
**✅ Client v1.0:** C001–C018  
**→ Übergabe an:** `task-web-wasm.md`
