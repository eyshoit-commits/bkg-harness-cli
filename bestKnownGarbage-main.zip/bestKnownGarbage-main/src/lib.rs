//! bKG - AI Agent Framework
//!
//! A modular, extensible framework for building AI agents with Rust.
//! This crate re-exports all the core bKG crates for convenient use.

//! Re-export all bKG crates
pub use bkg_budget::*;
pub use bkg_common::*;
pub use bkg_config::*;
pub use bkg_core::*;
pub use bkg_crypto::*;
pub use bkg_errors::*;
pub use bkg_events::*;
pub use bkg_kernel::*;
pub use bkg_macros::*;
pub use bkg_memory::*;
pub use bkg_multi_agent::*;
pub use bkg_protocol::*;
pub use bkg_runtime::*;
pub use bkg_security::*;
pub use bkg_serde::*;
pub use bkg_session::*;
pub use bkg_skills::*;
pub use bkg_storage::*;
pub use bkg_swd::*;
pub use bkg_telemetry::*;
pub use bkg_types::*;
pub use bkg_verify::*;
pub use bkg_cli::*;

// Re-export commonly used types and traits
pub use bkg_types::{
    Result,
    Error,
};

pub use bkg_kernel::{
    Kernel,
    KernelBuilder,
    KernelConfig,
};

pub use bkg_memory::{
    MemoryManager,
    MemoryEntry,
};

pub use bkg_session::{
    SessionManager,
    SessionState,
    SessionConfig,
};

pub use bkg_skills::{
    Skill,
    SkillSet,
    SkillsProtocol,
};

pub use bkg_swd::{
    ActionIntent,
    FileOperation,
    FileAction,
    VerificationStatus,
    FileSnapshot,
    FileSnapshotSummary,
    SwdEngine,
    SwdConfig,
};

pub use bkg_budget::{
    BudgetConfig,
    TokenUsage,
    SessionBudget,
    BudgetManager,
};

pub use bkg_verify::{
    VerifyReport,
    Finding,
    FindingSeverity,
    CiVerifier,
};

pub use bkg_cli::{
    Cli,
    CliConfig,
    CliCommand,
};
