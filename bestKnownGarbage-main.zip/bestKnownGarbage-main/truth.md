# bESTKNOWNGarbage — TRUTH

> **Ground truth. Agents lesen das als erstes.**  
> Nur implementierte Fakten, keine Spekulation.

---

## Identity

- **Name:** bESTKNOWNGarbage (Chronos Kernel, was BKG-WASM)
- **Project root:** `/home/bkg/workspace/bESTKNOWNGarbage/`
- **Purpose:** Deterministic agent operating system for autonomous knowledge work
- **Language:** Rust (primary, edition 2024), Go (legacy TUI, `go/crush/`), Python (reference, `python/hackcode/`)
- **Build:** `cargo check --release` — 0 errors
- **Chat:** `cargo run --release -- chat "hi"` — works
- **Demo:** `cargo run --release -- demo-mesh-gc` — works

---

## Architecture (Implemented)

```
Collectors → Mesh (sensory gossip) → GC (observational measurement)
↓
TrustEngine → EscalationEngine → HeroDaemon → Motherbrain (adjudication)
↓
Ledger (append-only) → RAL (reality anchoring) → ReplayEngine
```

### Invariants (Never Break)
1. Mesh and GC are **read-only** — never write truth, never quarantine
2. Only **Motherbrain** commits to the Ledger
3. Trust is earned by **reproducible accuracy**, not reputation or votes
4. No autonomous action without Motherbrain approval
5. All side effects must be recorded as events
6. Collected evidence must be reproducible
7. GC is an **epistemic biologist**, not a file deleter

---

## Codebase Structure

| Path | Content | LOC (approx) |
|------|---------|--------------|
| `crates/bkg-core/` | Types, Config, Error, Message, Session | ~800 |
| `crates/bkg-tools/` | 9 tools: bash, edit, multiedit, view, write, grep, glob, ls, fetch | ~1200 |
| `crates/bkg-provider/` | 8 providers: OpenAI, Anthropic, Gemini, Groq, Nvidia, Ollama, OpenRouter, Bedrock | ~900 |
| `crates/bkg-kernel/` | Trust, Causality, RAL, Guards, Mesh, GC, TrustEngine, Motherbrain, Ledger, Replay, WASM | ~4500 |
| `crates/bkg-api/` | HTTP client + streaming | ~200 |
| `crates/bkg-cli/` | CLI entry + agent coordinator | ~500 |
| **Total Rust** | | **~8100** |
| `projects/bkg-web/` | Dioxus landing page (bkg-wasm.dev) | ~1400 |
| `go/crush/` | Go TUI implementation (legacy, rebranded from Crush) | — |
| `python/hackcode/` | Python reference (preserved) | — |

---

## Implementation Status

### ✅ Complete (in code, production-level)
- Core type system + error handling (`bkg-core`)
- All 9 tools (`bkg-tools`)
- All 8 LLM providers (`bkg-provider`)
- Agent coordinator + CLI (`bkg-cli`)
- Trust Engine: TrustField v2, TrustVector, EscalationEngine
- Causality Engine: DAG + CVE correlation
- Reality Anchor Layer (RAL): 453 LOC
- Guards & Self-Defense: GuardEngine, GMF (395 LOC)
- Evolution Patch Engine (420 LOC)
- Guard Consensus Layer / Swarm (342 LOC)
- Distributed Mesh: TCP gossip, heartbeat, EntropyRegion (P3)
- Garbage Collector: EntropyTracker, ArchiveManager, DecayTagger, TopologyObserver (P7.5)
- Hero Daemon: auto-promotion/demotion (P4/P5)
- TrustEngine → Kernel Integration: `KernelState` with `Arc<TrustEngine>`
- Ledger: append-only, 257 LOC (RAM only)
- WASM Runtime: deterministic hash simulation, 278 LOC
- Replay Engine
- Integration Demo: `bkg demo-mesh-gc`
- CLI: `bkg chat`, `bkg demo-mesh-gc`
- Web-WASM Landing Page (20/20 sections, 77/97 tasks done)

### 📋 Planned (not yet in code or incomplete)
- **Ledger Persistence** → SQLite backend
- **Ledger Write Separation** → Motherbrain-only `commit_stable_state()`
- **Collusion Detection** → Stub, needs pattern analysis
- **Swarm Validation** → Hero groups not formed yet
- **Motherbrain Full Adjudication** → Local trust only, no global
- **Real WASM Execution** → `wasmtime` integration, fuel limits
- **Mesh Full Listener** → `start_mesh_listener()` stub
- **Mesh TrustUpdate Propagation** → TrustEngine → Mesh channel missing
- **HeroDaemon Auto-Start** → Manual spawn only
- **Config File Loading** → `bkg.toml` / env
- **Boot Sequence** → No structured init
- **Graceful Shutdown** → Signal handling
- **ArchiveManager Persistence** → RAM only
- **Knowledge Decay Engine** → Not started
- **Attack Hotspot Defense** → Not started
- **Talmud-Style Escalation** → Not started
- **PWBL (Physical World Binding Layer)** → Not started
- **Workspace Hypervisor** → OverlayFS, not started
- **Snapshot Engine** → Not started
- **Verification Runtime (SWD++)** → Not started
- **Memory Authority Engine** → Not started
- **Capability Security Kernel** → Not started
- **Managed Agents** → Manager/Executor, Budget, Orchestrator
- **LSP / MCP Integration** → LSP Manager, MCP Client, Skills, Permissions
- **Dioxus Kernel UI** → 15 panels
- **Comprehensive Tests** → Unit + Integration
- **CI/CD** → GitHub Actions
- **Release Build** → Binary publishing

---

## System Invariants (Verfassung)

> **12 nicht-verhandelbare Invarianten** in `docs/invariants.md`
>
> Jeder Code-Commit, jede Task-Ausführung, jede Architektur-Entscheidung wird gegen diese Invarianten geprüft.

Kern-Regeln:
- **I01:** Only Motherbrain may mutate ledger truth.
- **I02:** Mesh is observational only.
- **I03:** GC may never quarantine autonomously.
- **I04:** Replay verification outranks trust score.
- **I05:** No raw LLM output enters ledger.
- **I06:** Deterministische Execution (same input + env = same output)
- **I07:** Guard LLM ist advisory, nicht authority.
- **I08:** DSL → Intent Graph → Motherbrain Approval → Execution
- **I09:** WriteSeparation (Motherbrain schreibt, Mesh/GC lesen)
- **I10:** MEASURE > DECIDE > WRITE (nie PREDICT > ASSUME > MUTATE)
- **I11:** Frozen Interfaces zwischen Phasen
- **I12:** TaskState als Mini-Ledger (Planned → InProgress → Review → Verified)

---

## Contracts (Constitution Files)

> **Interface-Verträge** in `contracts/`. Nur diese gelten als Wahrheit für API-Grenzen.

| Contract | File | Status |
|----------|------|--------|
| Motherbrain API | `contracts/motherbrain-api.md` | Draft (freeze bei M046) |
| Ledger Schema | `contracts/ledger-schema.md` | Draft (freeze bei M017) |
| Mesh Protocol | `contracts/mesh-protocol.md` | Draft (freeze bei G004) |

---

## SystemModes

> **6 Betriebsmodi** für das gesamte System. Jeder Mode ändert erlaubte Operationen.

| Mode | Write | Replay | Security | Use Case |
|------|-------|--------|----------|----------|
| Bootstrap | ✅ | Optional | Minimal | Initiale Konfiguration |
| Alpha | ✅ | Required | Schwach | Entwicklung, aggressive Logs |
| Beta | ✅ | Required | Sandbox | Integration, Sandbox-Pflicht |
| Hardened | ✅ | Required | Strict | Produktion, volle Sicherheit |
| Recovery | ❌ | Required | Strict | Wiederherstellung nach Fehler |
| Quarantine | ❌ | Required | Strict | Isolierte Nodes untersuchen |
| ReadOnly | ❌ | Optional | N/A | Diagnose, kein Write |

Implementation: Phase 1 (Motherbrain Core) — `SystemMode` in KernelState.

---

## ReplayClasses

> **5 Replay-Klassen** verhindern, dass das System unterschiedliche Workloads gleich behandelt.

| Class | Time Limit | Garantie | Beispiel |
|-------|-----------|----------|----------|
| Tiny | < 1s | Voll | Simple deterministische Operation |
| Standard | < 30s | Voll | Normale Chunks |
| Heavy | < 5min | Voll | Komplexe Chunks |
| Dangerous | < 30min | Eingeschränkt | LLM Output, externe Daten |
| NonDeterministic | k.A. | Keine | GPU, Browser, Kernel-Kompilierung |

Implementation: Phase 1 (ReplayEngine) — `ReplayClass` in Replay-Verifikation.

---

## TaskState Machine

> **Jeder Task-Step** in jeder Chain hat einen nachvollziehbaren Zustand.

```
Planned → InProgress → Review → Verified
  ↓          ↓
Frozen     Blocked
```

- `Planned`: Noch nicht bearbeitet
- `InProgress`: Wird aktuell bearbeitet
- `Review`: Fertig, wartet auf Verifikation
- `Verified`: Akzeptiert, abgeschlossen
- `Blocked`: Abhängigkeit nicht erfüllt
- `Frozen`: Bewusst eingefroren (Interface-Change nötig für Reaktivierung)

---

## Task Tracking

> **6 Aufgabenbereiche, jeder mit eigener Task-Chain:**

| Bereich | Task-Datei | Steps | Status |
|---------|------------|-------|--------|
| Motherbrain (Kernel) | `tasks/task-motherbrain.md` | M001–M046 | 📋 |
| Client (CLI/API) | `tasks/task-client.md` | C001–C018 | 📋 |
| Web-WASM | `tasks/task-web-wasm.md` | W001–W012 | 📋 |
| Garbage Nodes | `tasks/task-garbage.md` | G001–G019 | 📋 |
| Guard LLM | `tasks/task-guard-llm.md` | L001–L010 | 📋 |
| BKG Language | `tasks/task-bkg-lang.md` | B001–B009 | 📋 |

`truth.md`, `progress.md`, und `docs/llm.nfo` werden nach jedem Schritt aktualisiert.

---

## Project ↔ Task Mapping

> **Damit keine Verwirrung entsteht:** Task-Dateiname ≠ Project-Dir-Name.

| Project Dir | Package Name | Task File | Domain |
|-------------|-------------|-----------|--------|
| `projects/bkg-motherbrain/` | `motherbrain-server` | `tasks/task-motherbrain.md` | Motherbrain Kernel |
| `projects/bkg-node/` | `bkg-node` | `tasks/task-garbage.md` | Garbage Nodes (Mesh/GC) |
| `projects/bkg-llm/` | `bkg-llm` | `tasks/task-guard-llm.md` | Guard LLM |
| `projects/bkg-lang/` | `bkg-lang` | `tasks/task-bkg-lang.md` | BKG Language |
| `projects/bkg-web/` | `bkg-wasm-alpha` | `tasks/task-web-wasm.md` | Web-WASM |
| `projects/bkg-client/` | `bkg-client` | `tasks/task-client.md` | Client (CLI/API) |

---

## Key Documents

| File | Purpose |
|------|---------|
| `task.md` | Meta-Index: 6 Aufgabenbereiche bis Production-Ready Gold |
| `tasks/task-motherbrain.md` | Motherbrain (Kernel): M001–M046 |
| `tasks/task-client.md` | Client (CLI/API): C001–C018 |
| `tasks/task-web-wasm.md` | Web-WASM: W001–W012 |
| `tasks/task-garbage.md` | Garbage Nodes: G001–G019 |
| `tasks/task-guard-llm.md` | Guard LLM: L001–L010 |
| `tasks/task-bkg-lang.md` | BKG Language: B001–B009 |
| `docs/progress.md` | Development Progress — Metriken, Checklisten |
| `docs/invariants.md` | System Invariants (12 Verfassungsregeln) |
| `docs/roadmap.md` | Strategische Roadmap — Phasen, Prioritäten |
| `contracts/motherbrain-api.md` | Motherbrain API Contract |
| `contracts/ledger-schema.md` | Ledger Schema (TrustVector, ReplayClass, SystemMode) |
| `contracts/mesh-protocol.md` | Mesh Network Protocol Contract |
| `docs/llm.nfo` | Single large text block for LLM reference / semantic DB ingestion |
| `agents.md` | Agent instructions |
| `docs/architektur/trust_engine_design.md` | Trust scoring, heroes, collusion, swarm design |
| `docs/architektur/kernel_spezifikation.md` | Kernel/UI specs |
| `docs/architektur/relay_chain.md` | Ledger design |
| `docs/architektur/ui_architecture.md` | Dioxus UI plan |
| `docs/architektur/security_safety.md` | Security model |
| `docs/architektur/planned_features.md` | Feature-oriented planned items |

---

## Quick Reference

```bash
# Build & check
cargo check --release          # → 0 errors, 0 warnings
cargo build --release          # → binary at target/release/bkg

# Run
cargo run --release -- chat "hi"          # LLM chat
cargo run --release -- demo-mesh-gc       # Mesh → GC demo

# Tests
cargo test                     # → (currently minimal)
```

### Tool List (bkg-tools)
`bash`, `edit`, `multiedit`, `view`, `write`, `grep`, `glob`, `ls`, `fetch`

### Provider List (bkg-provider)
OpenAI, Anthropic, Gemini, Groq, Nvidia, Ollama, OpenRouter, Bedrock
