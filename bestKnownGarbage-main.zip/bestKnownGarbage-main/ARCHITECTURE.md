# BKG Architecture

## System Overview

BestKnownGarbage (BKG) is a **deterministic, policy-driven AI agent framework** built in Rust with the following core principles:

1. **Determinism** — Every operation is reproducible and verifiable
2. **Auditability** — Complete operation history with cryptographic signatures
3. **Isolation** — Sessions are completely isolated with no shared state
4. **Governance** — Policy engine enforces execution constraints
5. **Reversibility** — All writes are snapshottable and rollback-capable

## Layered Architecture

```
┌─────────────────────────────────────────────────┐
│           CLI / User Interface Layer             │
│  (bkg-cli, bkg-web, bkg-client)                 │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│         Session & Orchestration Layer            │
│  (bkg-session, bkg-multi-agent, bkg-skills)     │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│      Execution & Governance Layer                │
│  (bkg-kernel, bkg-swd, bkg-verify)              │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│        Infrastructure & Storage Layer            │
│  (bkg-storage, bkg-memory, bkg-telemetry)       │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│          Foundational Layer                      │
│  (bkg-core, bkg-types, bkg-errors, bkg-config)  │
└─────────────────────────────────────────────────┘
```

## Component Responsibilities

### Layer 1: Foundational (Core)

| Crate | Purpose |
|-------|---------|
| `bkg-core` | Bootstrap, base types, session models |
| `bkg-types` | Canonical type definitions |
| `bkg-errors` | Error hierarchy and Result types |
| `bkg-config` | Configuration framework |
| `bkg-common` | Shared utilities |
| `bkg-serde` | Serialization helpers |
| `bkg-macros` | Procedural macros for boilerplate |

### Layer 2: Infrastructure

| Crate | Purpose |
|-------|---------|
| `bkg-storage` | Abstract storage interface (file, DB) |
| `bkg-memory` | Memory management and caching |
| `bkg-telemetry` | Tracing, metrics, observability |
| `bkg-events` | Event system and pubsub |
| `bkg-protocol` | Network protocol definitions |
| `bkg-crypto` | Cryptographic primitives |
| `bkg-security` | Security policies and validators |

### Layer 3: Execution & Governance

| Crate | Purpose |
|-------|---------|
| `bkg-kernel` | Core trust engine, policy system, mesh |
| `bkg-swd` | Strict Write Discipline system |
| `bkg-verify` | Verification and CI integration |
| `bkg-budget` | Token counting and cost tracking |
| `bkg-runtime` | Runtime abstraction layer |

### Layer 4: Session & Orchestration

| Crate | Purpose |
|-------|---------|
| `bkg-session` | Session lifecycle management |
| `bkg-multi-agent` | Multi-agent coordination |
| `bkg-skills` | Skill registration and execution |
| `bkg-cli` | CLI command implementations |

### Layer 5: Projects (Executable Systems)

| Project | Purpose |
|---------|---------|
| `bkg-motherbrain` | Authoritative kernel server |
| `bkg-node` | Garbage collector node |
| `bkg-llm` | Guard LLM advisory service |
| `bkg-lang` | Query language and DSL |
| `bkg-web` | Web UI (Dioxus + WASM) |
| `bkg-client` | CLI client and API wrapper |

## Core Systems

### 1. Trust Engine

**Location**: `crates/bkg-kernel/src/trust_engine/`

The Trust Engine verifies the legitimacy of operations before execution.

```rust
pub struct TrustEngine {
    kernel: RwLock<TrustKernel>,
    escalation: EscalationEngine,
}

pub struct TrustVector {
    agent_id: AgentId,
    permissions: PermissionSet,
    created_at: Timestamp,
    signature: CryptoSignature,
}
```

**Key Responsibilities**:
- Validate agent identity
- Verify cryptographic signatures
- Check permission scopes
- Escalate violations to policy engine

### 2. Policy Engine

**Location**: `crates/bkg-kernel/src/policy.rs`

The Policy Engine enforces execution constraints through rules.

```rust
pub struct PolicyRule {
    id: String,
    condition: Condition,
    action: Action,
    priority: u32,
}

pub struct PolicyEngine {
    rules: Vec<PolicyRule>,
}

impl PolicyEngine {
    pub fn evaluate(&self, ctx: &ExecutionContext) -> Result<()>
    pub fn add_rule(&mut self, rule: PolicyRule)
}
```

**Rule Types**:
- **Threshold Rules** — Token/cost limits
- **Time Rules** — Execution time constraints
- **Scope Rules** — File access restrictions
- **Capability Rules** — Function call whitelisting

### 3. Strict Write Discipline (SWD)

**Location**: `crates/bkg-swd/`

SWD ensures all file operations are recorded, verified, and reversible.

```rust
pub struct FileSnapshot {
    session_id: SessionId,
    timestamp: Timestamp,
    operations: Vec<FileOperation>,
    before_state: BTreeMap<Path, FileState>,
    after_state: BTreeMap<Path, FileState>,
}

pub enum FileOperation {
    Create { path: Path, content: Vec<u8> },
    Modify { path: Path, before: Vec<u8>, after: Vec<u8> },
    Delete { path: Path },
}
```

**Workflow**:
```
1. Plan  → FileOperation created with intent
2. Record → Added to session snapshot
3. Execute → Actual file write occurs
4. Verify → Checksum/hash validation
5. Commit → Added to immutable ledger
```

### 4. Session Management

**Location**: `crates/bkg-session/`

Sessions are isolated execution contexts with complete state encapsulation.

```rust
pub struct Session {
    id: SessionId,
    state: SessionState,
    snapshot: FileSnapshot,
    budget: SessionBudget,
    memory_context: MemoryContext,
    skills: SkillSet,
}

pub enum SessionState {
    Initializing,
    Active,
    Suspended,
    Completed,
    Failed(String),
}
```

**Isolation Guarantees**:
- Environment variables scoped to session
- File operations sandboxed to session directory
- Memory completely isolated
- No shared state between sessions
- Cross-session operations require explicit coordination

### 5. Mesh & Garbage Collection

**Location**: `crates/bkg-kernel/src/mesh.rs`

Distributed topology with automatic garbage collection.

```rust
pub struct MeshNode {
    id: NodeId,
    entropy_region: EntropyRegion,
    trust_vector: TrustVector,
    peers: Vec<NodeId>,
}

pub struct GarbageCollector {
    tracked_sessions: HashMap<SessionId, SessionMetadata>,
}

impl GarbageCollector {
    pub fn collect(&mut self) -> Vec<SessionId>
}
```

**GC Strategy**:
- Sessions marked for collection when completed/failed
- Entropy region re-allocated to other sessions
- Peer nodes notified via gossip protocol
- Ledger entries archived after TTL

## Data Flow

### Session Lifecycle

```
1. Create Session
   └── Generate SessionId
   └── Allocate memory budget
   └── Initialize snapshot
   
2. Load Skills
   └── Query skill registry
   └── Verify signatures
   └── Inject into session context
   
3. Execute Task
   └── Trust check (TrustEngine)
   └── Policy check (PolicyEngine)
   └── Run user code
   
4. Write Operations
   └── Plan operation (SWD)
   └── Verify integrity
   └── Record to snapshot
   └── Commit to ledger
   
5. Complete Session
   └── Finalize snapshot
   └── Calculate costs
   └── Archive metadata
   └── Mark for GC
```

### Request Flow

```
User Input
   ↓
CLI Parser
   ↓
Route to Command Handler
   ↓
Create/Resume Session
   ↓
Trust Engine Validation
   ↓
Policy Engine Check
   ↓
Execute Operation
   ↓
SWD Recording & Verification
   ↓
Update Budget
   ↓
Return Result
   ↓
Persist Snapshot
```

## Security Model

### Trust Hierarchy

```
┌─────────────────┐
│  Root CA Cert   │
└────────┬────────┘
         ↓
┌─────────────────┐
│  Motherbrain    │  (Authoritative signer)
└────────┬────────┘
         ↓
┌─────────────────────────────┐
│   Agent Certificates        │
│   (Signed by Motherbrain)   │
└────────┬────────────────────┘
         ↓
┌──────────────────────────┐
│  Agent Operations        │
│  (Signed by Agent Cert)  │
└──────────────────────────┘
```

### Verification Levels

| Level | Applies To | Verification |
|-------|-----------|--------------|
| L0 | Session metadata | Hash integrity |
| L1 | File operations | Signature + hash |
| L2 | Agent credentials | Full cert chain |
| L3 | Policy rules | Motherbrain approval |
| L4 | Budget modifications | Multi-sig consensus |

## Performance Considerations

### Session Isolation Cost

- **Memory**: ~10KB overhead per session
- **CPU**: Minimal (OS process overhead)
- **Latency**: <1ms context switch

### Policy Engine Performance

```
N = number of rules
M = conditions per rule

Worst case: O(N×M) rule evaluation
Typical case: O(N) with early exit
Optimized: O(1) with indexed lookup
```

**Optimization Strategies**:
- Cached policy compilations
- Early termination on high-priority rules
- Rule indexing by condition type

### SWD Overhead

- **Snapshot creation**: ~5KB per 100 ops
- **Verification**: <1ms per operation
- **Ledger append**: O(log N) with B-tree

## Extensibility

### Adding New Skills

```rust
#[derive(Serialize, Deserialize)]
pub struct MySkill;

impl Skill for MySkill {
    fn name(&self) -> &str { "my-skill" }
    fn execute(&self, ctx: SkillContext) -> SkillResult {
        // Implementation
    }
}

// Register
skill_registry.register(Box::new(MySkill))?;
```

### Custom Policy Rules

```rust
let rule = PolicyRule {
    id: "custom-rule".to_string(),
    condition: Box::new(|trust_vec| {
        trust_vec.permissions.contains(&Permission::FileWrite)
    }),
    action: Box::new(|ctx| {
        // Allow or deny operation
        Ok(())
    }),
    priority: 10,
};

policy_engine.add_rule(rule);
```

### Storage Backends

```rust
pub trait StorageBackend: Send + Sync {
    async fn read(&self, key: &str) -> Result<Vec<u8>>;
    async fn write(&self, key: &str, value: Vec<u8>) -> Result<()>;
    async fn delete(&self, key: &str) -> Result<()>;
}

// Implementations: FileStorage, SQLiteStorage, S3Storage, etc.
```

## Deployment Architecture

### Single-Node Deployment

```
┌──────────────────────┐
│   bkg-cli (user)     │
└──────────┬───────────┘
           ↓
┌──────────────────────┐
│ bkg-motherbrain      │
│  - kernel            │
│  - policy engine     │
│  - ledger            │
└──────────────────────┘
```

### Distributed Deployment

```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  bkg-cli    │  │  bkg-cli    │  │  bkg-cli    │
│  (user 1)   │  │  (user 2)   │  │  (user N)   │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┼────────────────┘
                        ↓
        ┌───────────────────────────────┐
        │  Load Balancer (nginx/HAProxy)│
        └───────────┬───────────────────┘
                    ↓
        ┌───────────────────────────────┐
        │  Motherbrain Cluster (3+)     │
        │  ┌────┐  ┌────┐  ┌────┐      │
        │  │ MB │  │ MB │  │ MB │      │
        │  └────┘  └────┘  └────┘      │
        └────┬────────────────────┬─────┘
             ↓                    ↓
        ┌─────────────┐  ┌─────────────┐
        │ Ledger DB   │  │ Storage     │
        │ (PostgreSQL)│  │ (S3/GCS)    │
        └─────────────┘  └─────────────┘
```

## Future Enhancements

- [ ] Sharded ledger for horizontal scaling
- [ ] Confidential computing integration
- [ ] AI Model routing and optimization
- [ ] Advanced agent coordination patterns
- [ ] Blockchain anchoring for immutability

---

For more details, see [Invariants](docs/invariants.md), [Kernel Specification](docs/architektur/kernel_spezifikation.md).
