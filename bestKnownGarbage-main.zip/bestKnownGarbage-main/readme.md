# BKG-WASM — BESTKNOWNGarbage

**Restructured Workspace (v0.2a)**

Clean, modular Rust workspace — der epistemic kernel in Crates organisiert, keine Monolithen, keine toten Ordner.

## Architektur

```
bESTKNOWNGarbage/
├── crates/                   # Shared reusable primitives
│   ├── bkg-types/            # Type definitions
│   ├── bkg-common/           # Utilities
│   ├── bkg-crypto/           # Cryptography
│   ├── bkg-core/             # Legacy core
│   ├── bkg-kernel/           # Legacy kernel
│   └── (10+ weitere)         # config, events, storage, etc.
│
├── projects/                 # Executable systems
│   ├── bkg-motherbrain/      # Motherbrain server
│   ├── bkg-node/             # Garbage/collector node
│   ├── bkg-llm/              # Guard LLM
│   ├── bkg-lang/             # BKG Language
│   ├── bkg-web/              # Dioxus Landing Page (Netlify → bkg-wasm.dev)
│   └── bkg-client/           # CLI + API client
│
├── docs/                     # Documentation
├── tasks/                    # 6 task chains
└── contracts/                # System contracts
```

## Workspace

```bash
cargo check                 # kontrolliert alle Projekte
cargo check -p bkg-node     # einzelnes Projekt
```

## Regeln

- **Alles `bkg-*`:** `bjg`, `bkd`, `young` sind verboten
- **Jedes Project hat eigene `crates/`:** Domain-Logik gehört zum Projekt, nicht zu Root
- **Root `crates/` = nur shared Primitives** (types, crypto, config, events, storage, protocol)

## Ursprung

Neu organisiert aus `v0.1a/` (Rust monolith) + `python/hackcode/rust/` (production crates).
Alte Verzeichnisse bleiben als Backup unter `/home/bkg/workspace/bkg-wasm/`.
