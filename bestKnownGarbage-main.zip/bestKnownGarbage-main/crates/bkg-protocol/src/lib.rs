// bkg-bkg-protocol — stub. Code migrates from crates/bkg-kernel in Phase 1
