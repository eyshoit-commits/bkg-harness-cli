//! BKG macros — shared crate
