// BKG Kernel - Convergence Metrics (P4/P5)
// Measures system stability: trust variance, drift detection, convergence estimation

pub struct ConvergenceMetrics;

impl ConvergenceMetrics {
    /// Compute variance of a series (higher = more volatile)
    pub fn variance(history: &[f32]) -> f32 {
        if history.len() < 2 {
            return 1.0; // indefinite
        }

        let mean = history.iter().sum::<f32>() / history.len() as f32;

        history.iter().map(|v| (v - mean).powi(2)).sum::<f32>() / history.len() as f32
    }

    /// Compute standard deviation
    pub fn std_dev(history: &[f32]) -> f32 {
        Self::variance(history).sqrt()
    }

    /// Check if system is stable (variance below threshold)
    pub fn is_stable(history: &[f32], threshold: f32) -> bool {
        Self::variance(history) < threshold
    }

    /// Convergence estimate over recent window: smaller variance = more converged
    pub fn convergence_estimate(history: &[f32], window: usize) -> f32 {
        if history.len() < window {
            return 0.0;
        }

        let recent = &history[history.len() - window..];
        Self::variance(recent)
    }

    /// Compute drift rate: absolute difference between recent and older half
    pub fn drift_rate(history: &[f32]) -> f32 {
        if history.len() < 4 {
            return 0.0;
        }

        let mid = history.len() / 2;
        let old_avg: f32 = history[..mid].iter().sum::<f32>() / mid as f32;
        let new_avg: f32 = history[mid..].iter().sum::<f32>() / (history.len() - mid) as f32;

        (new_avg - old_avg).abs()
    }

    /// Check if system is converging (drift decreasing over time)
    pub fn is_converging(history: &[f32], window: usize) -> bool {
        if history.len() < window * 2 {
            return false;
        }

        let half = window * 2;
        let first_half = &history[history.len() - half..history.len() - window];
        let second_half = &history[history.len() - window..];

        let var1 = Self::variance(first_half);
        let var2 = Self::variance(second_half);

        var2 < var1
    }

    /// Compute trust entropy: diversity of trust values across nodes (lower = more uniform = good for consensus)
    pub fn trust_entropy(trust_values: &[f32]) -> f32 {
        if trust_values.is_empty() {
            return 0.0;
        }

        // Bin trust values into 10 buckets (0.0, 0.1, ..., 1.0)
        let mut bins = [0usize; 10];
        for &t in trust_values {
            let bucket = (t * 10.0).floor() as usize;
            let bucket = bucket.min(9);
            bins[bucket] += 1;
        }

        let total = trust_values.len() as f32;
        let mut entropy = 0.0;
        for &count in &bins {
            if count > 0 {
                let p = count as f32 / total;
                entropy -= p * p.log2();
            }
        }

        entropy
    }

    /// Overall system health score (0..1)
    pub fn system_health(trust_history: &[f32], recent_window: usize) -> (f32, SystemHealthInfo) {
        let variance = Self::variance(trust_history);
        let drift = Self::drift_rate(trust_history);
        let converging = Self::is_converging(trust_history, recent_window);

        // Health decreases with high variance and high drift
        let variance_penalty = (variance * 10.0).min(1.0);
        let drift_penalty = (drift * 5.0).min(1.0);
        let convergence_bonus = if converging { 1.0 } else { 0.0 };

        let health = (1.0 - variance_penalty - drift_penalty + convergence_bonus).clamp(0.0, 1.0);

        let info = SystemHealthInfo {
            variance,
            drift,
            converging,
            variance_penalty,
            drift_penalty,
            convergence_bonus,
        };

        (health, info)
    }
}

#[derive(Debug)]
pub struct SystemHealthInfo {
    pub variance: f32,
    pub drift: f32,
    pub converging: bool,
    pub variance_penalty: f32,
    pub drift_penalty: f32,
    pub convergence_bonus: f32,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_variance() {
        let data = vec![0.5, 0.5, 0.5, 0.5];
        assert!(ConvergenceMetrics::variance(&data) < 0.001);
    }

    #[test]
    fn test_drift() {
        let data = vec![0.1, 0.2, 0.3, 0.4]; // increasing
        assert!(ConvergenceMetrics::drift_rate(&data) > 0.0);
    }

    #[test]
    fn test_converging() {
        let data = vec![0.9, 0.95, 0.98, 0.99, 0.995, 0.998]; // converging
        assert!(ConvergenceMetrics::is_converging(&data, 3));
    }

    #[test]
    fn test_entropy() {
        let uniform = vec![0.5, 0.5, 0.5, 0.5];
        let diverse = vec![0.1, 0.3, 0.7, 0.9];
        assert!(
            ConvergenceMetrics::trust_entropy(&uniform)
                < ConvergenceMetrics::trust_entropy(&diverse)
        );
    }
}
