//! Truth function implementation for BKG-WASM
//!
//! This module implements the formal truth function that defines what makes
//! knowledge "true" in the BKG system - based on the principle that
//! "No truth without adversarial survival."

use crate::{CounterfactualResult, CounterfactualTest, ExecutionProof, TemporalTruth, TrustVector};

/// The fundamental truth function for BKG-WASM
///
/// Truth(chunk) := survives(all perturbations) && temporal_consistency &&
///                cross_environment_stability && reproducibility
#[derive(Debug)]
pub struct TruthFunction;

impl TruthFunction {
    /// Determine if a chunk is truly true according to BKG's principles
    ///
    /// This implements the core principle: "No truth without adversarial survival"
    pub fn is_truthful(
        _chunk_id: &str,
        _execution_proof: &ExecutionProof,
        counterfactual_tests: &[&CounterfactualTest],
        temporal_truth: &TemporalTruth,
        trust_vector: &TrustVector,
    ) -> bool {
        // 1. Must survive adversarial tests (counterfactual survival)
        let counterfactual_survival = Self::check_counterfactual_survival(counterfactual_tests);

        // 2. Must be temporally consistent
        let temporal_consistency = temporal_truth.is_stable();

        // 3. Must have high reproducibility from trust vector
        let reproducibility = trust_vector.reproducibility >= 0.95;

        // 4. Must be adversarially resistant
        let adversarial_resistance = trust_vector.adversarial_resistance >= 0.90;

        // 5. Must have cross-environment stability
        let cross_env_stability = trust_vector.cross_env_stability >= 0.90;

        // Return true only if all core constraints are met
        counterfactual_survival
            && temporal_consistency
            && reproducibility
            && adversarial_resistance
            && cross_env_stability
    }

    /// Check if truths survive adversarial perturbations
    fn check_counterfactual_survival(tests: &[&CounterfactualTest]) -> bool {
        // A chunk is adversarially robust if most counterfactual tests pass
        if tests.is_empty() {
            return true; // No tests means no evidence of failure
        }

        let total_tests = tests.len();
        let surviving_tests: usize = tests
            .iter()
            .filter(|test| matches!(test.test_result, CounterfactualResult::Survived))
            .count();

        // At least 80% must survive to be considered robust
        surviving_tests as f32 / total_tests as f32 >= 0.80
    }

    /// Calculate the strength of a truth claim
    pub fn truth_strength(
        _chunk_id: &str,
        _execution_proof: &ExecutionProof,
        counterfactual_tests: &[&CounterfactualTest],
        temporal_truth: &TemporalTruth,
        trust_vector: &TrustVector,
    ) -> f32 {
        // Weighted combination of all truth factors
        let counterfactual_score = if Self::check_counterfactual_survival(counterfactual_tests) {
            1.0
        } else {
            0.0
        };

        let temporal_score = if temporal_truth.is_stable() { 1.0 } else { 0.0 };

        // Use trust vector scores as base weights
        let reproducibility_weight = trust_vector.reproducibility;
        let adversarial_weight = trust_vector.adversarial_resistance;
        let cross_env_weight = trust_vector.cross_env_stability;

        // Weighted average
        counterfactual_score * 0.25
            + temporal_score * 0.25
            + reproducibility_weight * 0.20
            + adversarial_weight * 0.20
            + cross_env_weight * 0.10
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_truth_function() {
        // Create mock components
        let execution_proof = ExecutionProof::new(
            "input_hash_123".to_string(),
            "env_hash_456".to_string(),
            "output_hash_789".to_string(),
            1.0,
        );

        let temporal_truth = TemporalTruth::new("chunk_123".to_string());
        let trust_vector = TrustVector::new(0.98, 0.95, 0.92, 0.96, 0.94);

        // Create counterfactual tests
        let counterfactual_tests = vec![];

        // Verify the function works
        let is_truthful = TruthFunction::is_truthful(
            "chunk_123",
            &execution_proof,
            &counterfactual_tests,
            &temporal_truth,
            &trust_vector,
        );

        assert!(is_truthful);
    }

    #[test]
    fn test_counterfactual_survival() {
        // Test with surviving tests
        let test1 = CounterfactualTest::new(
            ExecutionProof::new(
                "input_a".to_string(),
                "env_a".to_string(),
                "out_a".to_string(),
                1.0,
            ),
            ExecutionProof::new(
                "input_b".to_string(),
                "env_b".to_string(),
                "out_a".to_string(),
                1.0,
            ),
            CounterfactualResult::Survived,
        );

        let test2 = CounterfactualTest::new(
            ExecutionProof::new(
                "input_a".to_string(),
                "env_a".to_string(),
                "out_a".to_string(),
                1.0,
            ),
            ExecutionProof::new(
                "input_c".to_string(),
                "env_c".to_string(),
                "out_b".to_string(),
                1.0,
            ),
            CounterfactualResult::Failed,
        );

        let tests = vec![&test1, &test2];
        let result = TruthFunction::check_counterfactual_survival(&tests);

        // Only 1 out of 2 passed, should be less than 80% so failure
        assert!(!result);
    }
}
