//! BKG Replay Engine
//!
//! Deterministic re-execution for truth verification.

use crate::core::*;
use crate::wasm::{ExecutionSnapshot, WasmRuntime};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Replay engine for deterministic verification
#[derive(Debug, Clone)]
pub struct ReplayEngine {
    /// Snapshot storage
    pub snapshots: HashMap<String, ExecutionSnapshot>,
    /// WASM runtime for re-execution
    pub wasm_runtime: WasmRuntime,
    /// Replay statistics
    pub stats: ReplayStats,
}

/// Result of a replay operation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayResult {
    /// Original output hash
    pub original_hash: Hash,
    /// Replayed output hash
    pub replayed_hash: Hash,
    /// Whether hashes match exactly
    pub match_exact: bool,
    /// CPU time for replay in ms
    pub replay_time_ms: u64,
    /// Whether replay succeeded
    pub success: bool,
    /// Divergence amount (0.0 = exact match)
    pub divergence: f32,
}

/// Replay statistics
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ReplayStats {
    /// Total replays attempted
    pub total_replays: u64,
    /// Successful replays
    pub successful_replays: u64,
    /// Failed replays (divergence)
    pub failed_replays: u64,
    /// Total replay time in ms
    pub total_time_ms: u64,
}

impl ReplayEngine {
    /// Create a new replay engine
    pub fn new() -> Self {
        Self {
            snapshots: HashMap::new(),
            wasm_runtime: WasmRuntime::new(),
            stats: ReplayStats::default(),
        }
    }

    /// Store a snapshot for future replay
    pub fn store_snapshot(&mut self, snapshot: ExecutionSnapshot) {
        self.snapshots
            .insert(snapshot.snapshot_id.clone(), snapshot);
    }

    /// Replay a specific snapshot
    pub fn replay(&mut self, snapshot_id: &str) -> Option<ReplayResult> {
        let snapshot = self.snapshots.get(snapshot_id)?.clone();

        self.stats.total_replays += 1;
        let start_time = std::time::Instant::now();

        // Execute with WASM runtime
        let result = self
            .wasm_runtime
            .execute(&snapshot.module_id, &snapshot.input);

        let replay_time_ms = start_time.elapsed().as_millis() as u64;
        self.stats.total_time_ms += replay_time_ms;

        let match_exact = result.output_hash == snapshot.output_hash;
        let divergence = if match_exact {
            0.0
        } else {
            // Calculate hash divergence
            Self::calculate_divergence(&result.output_hash, &snapshot.output_hash)
        };

        if match_exact {
            self.stats.successful_replays += 1;
        } else {
            self.stats.failed_replays += 1;
        }

        Some(ReplayResult {
            original_hash: snapshot.output_hash.clone(),
            replayed_hash: result.output_hash,
            match_exact,
            replay_time_ms,
            success: result.success && match_exact,
            divergence,
        })
    }

    /// Replay all snapshots
    pub fn replay_all(&mut self) -> Vec<(String, ReplayResult)> {
        let snapshot_ids: Vec<String> = self.snapshots.keys().cloned().collect();

        snapshot_ids
            .into_iter()
            .filter_map(|id| {
                let result = self.replay(&id)?;
                Some((id, result))
            })
            .collect()
    }

    /// Calculate divergence between two hashes
    fn calculate_divergence(hash1: &str, hash2: &str) -> f32 {
        if hash1.len() != hash2.len() {
            return 1.0;
        }

        let mut diff = 0;
        for (c1, c2) in hash1.chars().zip(hash2.chars()) {
            if c1 != c2 {
                diff += 1;
            }
        }

        diff as f32 / hash1.len() as f32
    }

    /// Get snapshots with high divergence
    pub fn high_divergence_snapshots(&mut self, threshold: f32) -> Vec<String> {
        let ids: Vec<String> = self.snapshots.keys().cloned().collect();
        ids.into_iter()
            .filter_map(|id| {
                self.replay(&id).and_then(|result| {
                    if result.divergence > threshold {
                        Some(id)
                    } else {
                        None
                    }
                })
            })
            .collect()
    }

    /// Get replay success rate
    pub fn success_rate(&self) -> f32 {
        if self.stats.total_replays == 0 {
            return 1.0;
        }
        self.stats.successful_replays as f32 / self.stats.total_replays as f32
    }

    /// Clear old snapshots
    pub fn cleanup(&mut self, max_age_ms: u64) {
        let now = Timestamp::now().0;
        self.snapshots
            .retain(|_, snap| now - snap.timestamp.0 < max_age_ms);
    }
}

impl Default for ReplayEngine {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wasm::WasmModule;

    #[test]
    fn test_replay_engine_creation() {
        let engine = ReplayEngine::new();
        assert_eq!(engine.snapshots.len(), 0);
    }

    #[test]
    fn test_snapshot_storage() {
        let mut engine = ReplayEngine::new();

        let snapshot = ExecutionSnapshot {
            snapshot_id: "snap_1".to_string(),
            module_id: "test".to_string(),
            input: vec![1, 2, 3],
            input_hash: "input_hash".to_string(),
            output_hash: "output_hash".to_string(),
            env_hash: "env_hash".to_string(),
            timestamp: Timestamp::now(),
        };

        engine.store_snapshot(snapshot);

        assert!(engine.snapshots.contains_key("snap_1"));
    }

    #[test]
    fn test_replay_execution() {
        let mut engine = ReplayEngine::new();

        // Register module
        let module = WasmModule {
            module_id: "test".to_string(),
            hash: "hash".to_string(),
            wasm_bytes: vec![],
            memory_limit_mb: 64,
            deterministic: true,
            created_at: Timestamp::now(),
        };
        engine.wasm_runtime.register_module(module);

        // Create and store snapshot
        let snapshot = engine.wasm_runtime.create_snapshot(
            "test",
            &[1, 2, 3],
            "expected_hash".to_string(),
            "env_hash".to_string(),
        );

        engine.store_snapshot(snapshot.clone());

        // Replay
        let result = engine.replay(&snapshot.snapshot_id);

        assert!(result.is_some());
    }
}
