//! HeroDaemon – Background task for automated trust promotion and demotion.
//!
//! Runs in a loop, periodically scanning all nodes and applying
//! escalation rules. Nodes move between roles based on trust scores.

use crate::trust_engine::TrustEngine;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;
use tokio::time::interval;

/// HeroDaemon manages background trust re-evaluation.
#[derive(Debug)]
pub struct HeroDaemon {
    engine: Arc<TrustEngine>,
    tick_interval: Duration,
    running: Arc<AtomicBool>,
}

impl HeroDaemon {
    pub fn new(engine: Arc<TrustEngine>, tick_interval: Duration) -> Self {
        Self {
            engine,
            tick_interval,
            running: Arc::new(AtomicBool::new(false)),
        }
    }

    /// Start the daemon in a background task.
    pub fn start(&self) {
        let running = self.running.clone();
        let engine = self.engine.clone();
        let tick_interval = self.tick_interval;

        tokio::spawn(async move {
            running.store(true, Ordering::Relaxed);
            let mut ticker = interval(tick_interval);
            loop {
                ticker.tick().await;
                Self::tick(&engine).await;
            }
        });
    }

    /// Stop the daemon (sets flag, task will exit on next tick).
    pub fn stop(&self) {
        self.running.store(false, Ordering::Relaxed);
    }

    /// One daemon tick: evaluate all nodes and apply promotion/demotion.
    async fn tick(engine: &Arc<TrustEngine>) {
        // Get all nodes currently in trust store
        let nodes = {
            // Snapshot of all NodeTrust
            engine
                .trust_store
                .read()
                .await
                .values()
                .cloned()
                .collect::<Vec<_>>()
        };

        for node in nodes {
            let role_before = node.role.clone();
            // Simple rule: if trust >= threshold → TrustHero; else → Collector
            // (More elaborate rules would use EscalationEngine properly)
            let new_role = if node.trust_score >= engine.threshold() {
                crate::escalation::Role::TrustHero
            } else {
                crate::escalation::Role::Collector
            };

            if new_role != role_before {
                tracing::info!(
                    "HeroDaemon: node {} role changed from {:?} to {:?} (trust={:.3})",
                    node.node_id,
                    role_before,
                    new_role,
                    node.trust_score
                );
                let mut store = engine.trust_store.write().await;
                if let Some(entry) = store.get_mut(&node.node_id) {
                    entry.role = new_role;
                }
            }
        }
    }
}
