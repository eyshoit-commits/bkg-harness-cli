//! Collusion Detection Engine
//!
//! Detects coordinated trust farming, echo validation clusters,
//! and synchronized behavior patterns among mesh nodes.
//!
//! ## Detection Signals
//!
//! - **Low trust-score variance + high mean**: groups gaming the system
//! - **Synchronized timestamp patterns**: nodes that always act together
//! - **Echo validation clusters**: A always validates B, B always validates A
//! - **Reproducibility anomalies**: impossibly perfect reproduction chains

use crate::core::types::NodeId;
use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, UNIX_EPOCH};

/// Classification of a detected collusion pattern.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PatternType {
    /// Low variance + high mean among scores (trust farming)
    CoordinatedTrust,
    /// A group that always validates each other's work (echo chamber)
    EchoValidation,
    /// Suspiciously perfect reproduction chains
    FakeReproducibility,
    /// Timestamps and vote patterns that suggest coordination
    SynchronizedBehavior,
}

/// Detailed report from a collusion scan.
#[derive(Debug, Clone)]
pub struct CollusionReport {
    /// Whether collusion was detected
    pub is_collusive: bool,
    /// Overall anomaly score (0.0 = honest, 1.0 = definitely colluding)
    pub anomaly_score: f32,
    /// What kind of pattern was detected
    pub pattern: PatternType,
    /// Confidence in the detection (0.0..1.0)
    pub confidence: f32,
    /// The nodes involved (subset of the queried set)
    pub implicated_nodes: Vec<NodeId>,
    /// Human-readable explanation
    pub details: String,
}

/// A single historical observation for collusion analysis.
#[derive(Debug, Clone)]
pub struct TrustObservation {
    pub timestamp: u64,
    pub trust_score: f32,
}

/// Per-node history for temporal pattern analysis.
#[derive(Debug, Clone, Default)]
pub struct CollusionHistory {
    /// Trust score history per node
    pub node_history: HashMap<NodeId, Vec<TrustObservation>>,
    /// Which nodes validated which chunks (for echo detection)
    pub validations: HashMap<String, Vec<NodeId>>,
}

impl CollusionHistory {
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a trust score observation for a node.
    pub fn record_trust(&mut self, node_id: NodeId, score: f32) {
        let obs = TrustObservation {
            timestamp: current_timestamp(),
            trust_score: score,
        };
        self.node_history
            .entry(node_id.clone())
            .or_default()
            .push(obs);

        // Keep at most 100 observations per node (LIFO)
        if let Some(history) = self.node_history.get(&node_id) {
            if history.len() > 100 {
                self.node_history.get_mut(&node_id).unwrap().remove(0);
            }
        }
    }

    /// Record a validation event (which nodes validated a chunk).
    pub fn record_validation(&mut self, chunk_id: String, validators: Vec<NodeId>) {
        self.validations.insert(chunk_id, validators);
    }

    /// Clear all history.
    pub fn reset(&mut self) {
        self.node_history.clear();
        self.validations.clear();
    }
}

/// Collusion detection engine with temporal pattern analysis.
#[derive(Debug, Clone)]
pub struct CollusionEngine {
    /// Historical trust observations
    pub history: CollusionHistory,
    /// Threshold for anomaly detection (default: 0.7)
    pub anomaly_threshold: f32,
}

impl Default for CollusionEngine {
    fn default() -> Self {
        Self::new()
    }
}

impl CollusionEngine {
    pub fn new() -> Self {
        Self {
            history: CollusionHistory::new(),
            anomaly_threshold: 0.7,
        }
    }

    /// Run all detection heuristics on a set of nodes.
    ///
    /// Returns a `CollusionReport` summarizing the findings.
    pub fn detect(&self, node_ids: &[NodeId]) -> CollusionReport {
        // 1. Score-based detection (low variance + high mean)
        let score_result = self.detect_coordinated_trust(node_ids);

        // 2. Echo validation detection
        let echo_result = self.detect_echo_validation(node_ids);

        // 3. Synchronized behavior detection
        let sync_result = self.detect_synchronized_behavior(node_ids);

        // Combine results — take the strongest signal
        let candidates: [(f32, f32, Vec<NodeId>, PatternType); 3] = [
            (
                score_result.1,
                score_result.2,
                score_result.3,
                PatternType::CoordinatedTrust,
            ),
            (
                echo_result.1,
                echo_result.2,
                echo_result.3,
                PatternType::EchoValidation,
            ),
            (
                sync_result.1,
                sync_result.2,
                sync_result.3,
                PatternType::SynchronizedBehavior,
            ),
        ];

        let mut best: Option<(f32, f32, Vec<NodeId>, PatternType)> = None;
        for (score, confidence, nodes, pattern) in &candidates {
            let is_better = match &best {
                None => true,
                Some((best_score, _, _, _)) => *score > *best_score,
            };
            if *score > 0.0 && is_better {
                best = Some((*score, *confidence, nodes.clone(), *pattern));
            }
        }

        if let Some((anomaly_score, confidence, implicated, pattern)) = best {
            let num_implicated = implicated.len();
            CollusionReport {
                is_collusive: anomaly_score >= self.anomaly_threshold,
                anomaly_score,
                confidence,
                pattern,
                implicated_nodes: implicated,
                details: format!(
                    "Collusion detected via {:?}: score={:.3}, confidence={:.3}, {} nodes implicated",
                    pattern, anomaly_score, confidence, num_implicated
                ),
            }
        } else {
            CollusionReport {
                is_collusive: false,
                anomaly_score: 0.0,
                pattern: PatternType::CoordinatedTrust,
                confidence: 0.0,
                implicated_nodes: Vec::new(),
                details: "No collusion detected".to_string(),
            }
        }
    }

    /// Detect coordinated trust farming: low standard deviation + high mean.
    fn detect_coordinated_trust(&self, node_ids: &[NodeId]) -> (bool, f32, f32, Vec<NodeId>) {
        let scores: Vec<f32> = node_ids
            .iter()
            .filter_map(|id| {
                self.history
                    .node_history
                    .get(id)
                    .and_then(|h| h.last())
                    .map(|o| o.trust_score)
            })
            .collect();

        if scores.len() < 2 {
            return (false, 0.0, 0.0, Vec::new());
        }

        let count = scores.len() as f32;
        let mean: f32 = scores.iter().sum::<f32>() / count;
        let variance: f32 = scores.iter().map(|s| (s - mean).powi(2)).sum::<f32>() / count;
        let std_dev = variance.sqrt();

        let anomaly = if std_dev < 0.05 && mean > 0.8 {
            // Low dispersion + high mean → suspicious
            1.0 - (std_dev / 0.05).min(1.0)
        } else if mean < 0.3 {
            // Consistently low trust could indicate coordinated sabotage
            (0.3 - mean) / 0.3
        } else {
            0.0
        };

        if anomaly > 0.0 {
            let implicated: Vec<NodeId> = scores
                .iter()
                .enumerate()
                .filter(|(_, s)| **s > 0.8 || **s < 0.3)
                .map(|(i, _)| node_ids[i].clone())
                .collect();
            (true, anomaly, anomaly, implicated)
        } else {
            (false, 0.0, 0.0, Vec::new())
        }
    }

    /// Detect echo validation clusters.
    ///
    /// If the same nodes always validate each other's chunks with no
    /// external cross-checks, that's an echo chamber signal.
    fn detect_echo_validation(&self, node_ids: &[NodeId]) -> (bool, f32, f32, Vec<NodeId>) {
        let query_set: HashSet<&NodeId> = node_ids.iter().collect();

        // Count how often each pair appears together in a validation group
        let mut pair_counts: HashMap<(&NodeId, &NodeId), usize> = HashMap::new();

        for validators in self.history.validations.values() {
            for a in validators {
                if !query_set.contains(a) {
                    continue;
                }
                for b in validators {
                    if a != b && query_set.contains(b) {
                        *pair_counts.entry((a, b)).or_insert(0) += 1;
                    }
                }
            }
        }

        if pair_counts.is_empty() {
            return (false, 0.0, 0.0, Vec::new());
        }

        // If a pair co-validates more than 80% of the time, that's suspicious
        let total_validations = self.history.validations.len().max(1);
        let mut implicated_set: HashSet<&NodeId> = HashSet::new();
        let mut max_ratio = 0.0_f32;

        for ((a, b), count) in &pair_counts {
            let ratio = *count as f32 / total_validations as f32;
            if ratio > 0.8 {
                implicated_set.insert(a);
                implicated_set.insert(b);
                max_ratio = max_ratio.max(ratio);
            }
        }

        if !implicated_set.is_empty() {
            let implicated: Vec<NodeId> = implicated_set.into_iter().cloned().collect();
            let anomaly = max_ratio.min(1.0);
            (true, anomaly, anomaly, implicated)
        } else {
            (false, 0.0, 0.0, Vec::new())
        }
    }

    /// Detect synchronized behavior: nodes that always update at the same time.
    ///
    /// If two nodes always report new trust scores within a narrow time window,
    /// that may indicate coordination.
    fn detect_synchronized_behavior(&self, node_ids: &[NodeId]) -> (bool, f32, f32, Vec<NodeId>) {
        if node_ids.len() < 2 {
            return (false, 0.0, 0.0, Vec::new());
        }

        // Compare the most recent N timestamps for each node
        let windows: Vec<Vec<u64>> = node_ids
            .iter()
            .filter_map(|id| {
                self.history
                    .node_history
                    .get(id)
                    .map(|h| h.iter().rev().take(10).map(|o| o.timestamp).collect())
            })
            .collect();

        if windows.len() < 2 {
            return (false, 0.0, 0.0, Vec::new());
        }

        // Count how often timestamps are within 1 second of each other
        let mut sync_hits = 0usize;
        let mut total_comparisons = 0usize;

        for i in 0..windows.len() {
            for j in (i + 1)..windows.len() {
                for (t1, t2) in windows[i].iter().zip(windows[j].iter()) {
                    total_comparisons += 1;
                    if t1.abs_diff(*t2) <= 1 {
                        sync_hits += 1;
                    }
                }
            }
        }

        if total_comparisons == 0 {
            return (false, 0.0, 0.0, Vec::new());
        }

        let sync_ratio = sync_hits as f32 / total_comparisons as f32;
        let anomaly = if sync_ratio > 0.7 { sync_ratio } else { 0.0 };

        if anomaly > 0.0 {
            let implicated: Vec<NodeId> = node_ids.to_vec();
            (true, anomaly, anomaly, implicated)
        } else {
            (false, 0.0, 0.0, Vec::new())
        }
    }
}

fn current_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_clean_nodes_no_collusion() {
        let engine = CollusionEngine::new();
        let report = engine.detect(&["alice".into(), "bob".into()]);
        assert!(!report.is_collusive);
    }

    #[test]
    fn test_coordinated_trust_detection() {
        let mut engine = CollusionEngine::new();

        // Both nodes have the same high score (0.95) — suspicious
        let node_a: NodeId = "node_a".into();
        let node_b: NodeId = "node_b".into();

        engine.history.record_trust(node_a.clone(), 0.95);
        engine.history.record_trust(node_b.clone(), 0.95);

        let report = engine.detect(&[node_a, node_b]);
        assert!(report.is_collusive);
        assert_eq!(report.pattern, PatternType::CoordinatedTrust);
    }

    #[test]
    fn test_echo_validation_detection() {
        let mut engine = CollusionEngine::new();

        let alice: NodeId = "alice".into();
        let bob: NodeId = "bob".into();

        // Alice and Bob always validate each other's work exclusively
        for i in 0..10 {
            let chunk = format!("chunk_{}", i);
            engine
                .history
                .record_validation(chunk, vec![alice.clone(), bob.clone()]);
        }

        let report = engine.detect(&[alice, bob]);
        assert!(report.is_collusive, "echo validation should be detected");
        assert_eq!(report.pattern, PatternType::EchoValidation);
    }

    #[test]
    fn test_synchronized_behavior() {
        let mut engine = CollusionEngine::new();
        let now = current_timestamp();

        // Inject trust observations with identical timestamps
        engine
            .history
            .node_history
            .entry("sync_a".into())
            .or_default()
            .extend((0..5).map(|i| TrustObservation {
                timestamp: now + i,
                trust_score: 0.5,
            }));
        engine
            .history
            .node_history
            .entry("sync_b".into())
            .or_default()
            .extend((0..5).map(|i| TrustObservation {
                timestamp: now + i,
                trust_score: 0.5,
            }));

        let report = engine.detect(&["sync_a".into(), "sync_b".into()]);
        assert!(
            report.is_collusive,
            "synchronized timestamps should be detected"
        );
    }

    #[test]
    fn test_no_false_positive_legitimate_nodes() {
        let mut engine = CollusionEngine::new();
        let now = current_timestamp();

        // Honest nodes have varied trust scores and different timestamps
        engine
            .history
            .node_history
            .entry("honest_a".into())
            .or_default()
            .extend((0..5).map(|i| TrustObservation {
                timestamp: now + i * 10,
                trust_score: 0.7 + (i as f32 * 0.05),
            }));
        engine
            .history
            .node_history
            .entry("honest_b".into())
            .or_default()
            .extend((0..5).map(|i| TrustObservation {
                timestamp: now + i * 10 + 3,
                trust_score: 0.5 + (i as f32 * 0.08),
            }));

        // No echo validations
        let report = engine.detect(&["honest_a".into(), "honest_b".into()]);
        assert!(
            !report.is_collusive,
            "honest nodes should not trigger collusion"
        );
    }
}
