//! Trust Engine – automated trust scoring, hero promotion/demotion, collusion detection.
//!
//! Integrates:
//! - TrustKernel (scores)
//! - EscalationEngine (role transitions)
//! - Collusion detection
//! - Swarm validation coordination (stub)

pub mod collusion;

use crate::core::types::NodeId;
use crate::escalation::EscalationEngine;
use crate::escalation::Role;
use crate::kernel::ExecutionReceipt;
use crate::mesh::MeshNode;
use crate::trust::TrustKernel;
use crate::trust_field_kernel::TrustVector;
use std::collections::HashMap;
use std::sync::Arc;
use std::sync::Mutex;
use tokio::sync::RwLock;

/// NodeTrust – detailed trust record per node.
#[derive(Debug, Clone)]
pub struct NodeTrust {
    pub node_id: NodeId,
    pub trust_score: f32,
    pub trust_vector: TrustVector,
    pub role: Role,
    pub last_updated: u64,
}

impl NodeTrust {
    pub fn new(node_id: NodeId) -> Self {
        Self {
            node_id,
            trust_score: 0.0,
            trust_vector: TrustVector::new(0.0, 0.0, 0.0, 0.0, 0.0),
            role: Role::Collector,
            last_updated: 0,
        }
    }
}

/// TrustEngine combines scoring and escalation.
///
/// Optionally wired to a [MeshNode] for propagating trust updates to peers.
#[derive(Debug)]
pub struct TrustEngine {
    kernel: RwLock<TrustKernel>,
    #[allow(dead_code)]
    escalation: EscalationEngine,
    trust_store: RwLock<HashMap<NodeId, NodeTrust>>,
    trust_threshold: f32,
    /// Optional mesh node for broadcasting trust updates.
    mesh_node: Option<Arc<MeshNode>>,
    /// Collusion detection engine with temporal history.
    collusion: Mutex<collusion::CollusionEngine>,
}

impl TrustEngine {
    /// Create a new TrustEngine with given threshold (default 0.8).
    pub fn new(trust_threshold: f32) -> Self {
        Self {
            kernel: RwLock::new(TrustKernel::new()),
            escalation: EscalationEngine::new(),
            trust_store: RwLock::new(HashMap::new()),
            trust_threshold,
            mesh_node: None,
            collusion: Mutex::new(collusion::CollusionEngine::new()),
        }
    }

    /// Optionally attach a mesh node for trust update propagation.
    pub fn set_mesh_node(&mut self, mesh_node: Arc<MeshNode>) {
        self.mesh_node = Some(mesh_node);
    }

    /// Create a TrustEngine with an attached mesh node (convenience for KernelState init).
    pub fn with_mesh(trust_threshold: f32, mesh_node: Arc<MeshNode>) -> Self {
        Self {
            kernel: RwLock::new(TrustKernel::new()),
            escalation: EscalationEngine::new(),
            trust_store: RwLock::new(HashMap::new()),
            trust_threshold,
            mesh_node: Some(mesh_node),
            collusion: Mutex::new(collusion::CollusionEngine::new()),
        }
    }

    /// Update trust for a node from receipts and compute role changes.
    pub async fn update_node_trust(
        &self,
        node_id: NodeId,
        receipts: Vec<ExecutionReceipt>,
    ) -> Result<(), TrustError> {
        // Update kernel scores (simplified: now just use receipts to adjust trust)
        let score = {
            let mut kernel = self.kernel.write().await;
            let mut current = kernel.get(&node_id);
            // Very simple heuristic: successful receipts increase trust
            let success_rate = if receipts.is_empty() {
                0.0
            } else {
                receipts.iter().filter(|r| r.success).count() as f32 / receipts.len() as f32
            };
            current = (current * 0.9) + (success_rate * 0.1);
            kernel.update(node_id.clone(), current);
            current
        };

        // Ensure entry exists
        let mut store = self.trust_store.write().await;
        let entry = store
            .entry(node_id.clone())
            .or_insert_with(|| NodeTrust::new(node_id.clone()));
        entry.trust_score = score;
        entry.last_updated = current_timestamp();

        // Simple role logic: if score >= threshold -> TrustHero, else Collector
        let new_role = if score >= self.trust_threshold {
            Role::TrustHero
        } else {
            Role::Collector
        };
        if new_role != entry.role {
            tracing::info!(
                "Node {} role changed to {:?} (trust={:.3})",
                node_id,
                new_role,
                score
            );
            entry.role = new_role;
        }

        // Record trust score in collusion history
        if let Ok(mut collusion) = self.collusion.lock() {
            collusion.history.record_trust(node_id.clone(), score);
        }

        // Propagate trust update to mesh (if wired)
        if let Some(ref mesh_node) = self.mesh_node {
            let trust_vec = TrustVector::new(score, score, score, (1.0 - score).min(0.5), 0.0);
            mesh_node.set_local_trust(trust_vec).await;
        }

        Ok(())
    }

    /// Get current trust score for a node.
    pub async fn get_trust(&self, node_id: &NodeId) -> f32 {
        self.trust_store
            .read()
            .await
            .get(node_id)
            .map(|e| e.trust_score)
            .unwrap_or(0.0)
    }

    /// Get NodeTrust for a node.
    pub async fn get_node_trust(&self, node_id: &NodeId) -> Option<NodeTrust> {
        self.trust_store.read().await.get(node_id).cloned()
    }

    /// Force-promote a node (used by HeroDaemon or admin).
    pub async fn promote_node(&self, node_id: NodeId) -> Result<(), TrustError> {
        let mut store = self.trust_store.write().await;
        if let Some(entry) = store.get_mut(&node_id) {
            // EscalationEngine doesn't expose set_role yet; we'll approximate
            // For now, set to TrustHero if threshold met
            if entry.trust_score >= self.trust_threshold {
                entry.role = Role::TrustHero;
                Ok(())
            } else {
                Err(TrustError::InsufficientTrust(entry.trust_score))
            }
        } else {
            Err(TrustError::UnknownNode(node_id))
        }
    }

    /// Force-demote a node.
    pub async fn demote_node(&self, node_id: NodeId) -> Result<(), TrustError> {
        let mut store = self.trust_store.write().await;
        if let Some(entry) = store.get_mut(&node_id) {
            entry.role = Role::Collector;
            Ok(())
        } else {
            Err(TrustError::UnknownNode(node_id))
        }
    }

    /// Get all heroes (TrustHero).
    pub async fn get_heroes(&self) -> Vec<NodeTrust> {
        self.trust_store
            .read()
            .await
            .values()
            .filter(|e| matches!(e.role, Role::TrustHero))
            .cloned()
            .collect()
    }

    /// Detect collusion among a set of nodes using the [CollusionEngine].
    ///
    /// Runs all detection heuristics (coordinated trust farming, echo validation,
    /// synchronized behavior) against the historical trust scores accumulated
    /// by [update_node_trust].
    pub async fn detect_collusion(&self, node_ids: &[NodeId]) -> Result<bool, TrustError> {
        if node_ids.len() < 2 {
            return Ok(false);
        }

        let report = self.collusion.lock().unwrap().detect(node_ids);

        if report.is_collusive {
            tracing::warn!(
                "Collusion detected: score={:.3}, confidence={:.3}, nodes={:?}",
                report.anomaly_score,
                report.confidence,
                report.implicated_nodes,
            );
        }

        Ok(report.is_collusive)
    }

    /// The trust threshold for promotion.
    pub fn threshold(&self) -> f32 {
        self.trust_threshold
    }
}

fn current_timestamp() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs()
}

#[derive(Debug, thiserror::Error)]
pub enum TrustError {
    #[error("unknown node: {0}")]
    UnknownNode(NodeId),
    #[error("insufficient trust: {0}")]
    InsufficientTrust(f32),
    #[error("escalation error: {0}")]
    EscalationError(String),
}

pub mod hero_daemon;
