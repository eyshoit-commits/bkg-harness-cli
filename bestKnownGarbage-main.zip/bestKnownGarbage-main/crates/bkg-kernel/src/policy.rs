//! Policy Engine — condition-based policy evaluation for BKG.
//!
//! Defines a rule evaluation engine where PolicyRules with conditions
//! and actions are matched against runtime context. Used by Motherbrain
//! for automated governance decisions (escalation, replay, quarantine, GC).

use bkg_core::types::{Entropy, TrustScore};

// ──────────────────────────────────────────────
// Core Types
// ──────────────────────────────────────────────

/// A condition that can be evaluated against runtime context.
#[derive(Debug, Clone, PartialEq)]
pub enum PolicyCondition {
    /// All sub-conditions must match.
    And(Vec<PolicyCondition>),
    /// Any sub-condition must match.
    Or(Vec<PolicyCondition>),
    /// Negation of a condition.
    Not(Box<PolicyCondition>),
    /// Trust score is below the given threshold.
    TrustBelow(TrustScore),
    /// Entropy is above the given maximum.
    EntropyAbove(Entropy),
    /// Chunk determinism score is below threshold.
    ChunkDeterminismBelow(f32),
    /// Node stability is below threshold.
    NodeStabilityBelow(f32),
    /// Time since last replay exceeds the given hours.
    TimeSinceLastReplay { hours: u64 },
}

impl PolicyCondition {
    /// Evaluate this condition against the given context.
    #[must_use]
    pub fn matches(&self, context: &PolicyContext) -> bool {
        match self {
            Self::And(conditions) => conditions.iter().all(|c| c.matches(context)),
            Self::Or(conditions) => conditions.iter().any(|c| c.matches(context)),
            Self::Not(inner) => !inner.matches(context),
            Self::TrustBelow(threshold) => context.avg_trust < *threshold,
            Self::EntropyAbove(max_allowed) => context.entropy > *max_allowed,
            Self::ChunkDeterminismBelow(threshold) => context.chunk_determinism < *threshold,
            Self::NodeStabilityBelow(threshold) => context.node_stability < *threshold,
            Self::TimeSinceLastReplay { hours } => {
                let threshold_secs = hours * 3600;
                let elapsed = context.now_secs.saturating_sub(context.last_replay_secs);
                elapsed > threshold_secs
            }
        }
    }
}

/// An action to take when a rule matches.
#[derive(Debug, Clone, PartialEq)]
pub enum PolicyAction {
    /// Escalate the situation to Motherbrain for adjudication.
    EscalateToMotherbrain,
    /// Trigger a replay verification.
    TriggerReplay,
    /// Quarantine the node.
    QuarantineNode,
    /// Force garbage collection.
    ForceGC,
    /// Emergency rollback to last known good state.
    EmergencyRollback,
    /// Log a warning message.
    LogWarning(String),
}

/// A policy rule that pairs a condition with an action.
#[derive(Debug, Clone, PartialEq)]
pub struct PolicyRule {
    /// Human-readable rule name.
    pub name: String,
    /// Condition to evaluate.
    pub condition: PolicyCondition,
    /// Action to take if the condition matches.
    pub action: PolicyAction,
    /// Priority (higher = evaluated first).
    pub priority: u32,
}

impl PolicyRule {
    /// Create a new policy rule.
    #[must_use]
    pub fn new(
        name: impl Into<String>,
        condition: PolicyCondition,
        action: PolicyAction,
        priority: u32,
    ) -> Self {
        Self {
            name: name.into(),
            condition,
            action,
            priority,
        }
    }

    /// Check if this rule matches the given context.
    #[must_use]
    pub fn matches(&self, context: &PolicyContext) -> bool {
        self.condition.matches(context)
    }
}

/// Runtime context for policy evaluation.
#[derive(Debug, Clone)]
pub struct PolicyContext {
    /// Average trust score across the node's history.
    pub avg_trust: TrustScore,
    /// Current entropy measure.
    pub entropy: Entropy,
    /// Chunk determinism score (0.0–1.0).
    pub chunk_determinism: f32,
    /// Node stability score (0.0–1.0).
    pub node_stability: f32,
    /// Unix timestamp of last replay.
    pub last_replay_secs: u64,
    /// Current Unix timestamp.
    pub now_secs: u64,
}

impl PolicyContext {
    /// Create a new policy context with default values.
    #[must_use]
    pub fn new() -> Self {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        Self {
            avg_trust: 0.5,
            entropy: 0.0,
            chunk_determinism: 1.0,
            node_stability: 1.0,
            last_replay_secs: now,
            now_secs: now,
        }
    }

    /// Set the average trust score.
    #[must_use]
    pub fn with_trust(mut self, trust: TrustScore) -> Self {
        self.avg_trust = trust;
        self
    }

    /// Set the entropy.
    #[must_use]
    pub fn with_entropy(mut self, entropy: Entropy) -> Self {
        self.entropy = entropy;
        self
    }

    /// Set chunk determinism.
    #[must_use]
    pub fn with_determinism(mut self, d: f32) -> Self {
        self.chunk_determinism = d;
        self
    }

    /// Set node stability.
    #[must_use]
    pub fn with_stability(mut self, s: f32) -> Self {
        self.node_stability = s;
        self
    }

    /// Set time since last replay in hours (relative to now).
    #[must_use]
    pub fn with_replay_hours_ago(mut self, hours: u64) -> Self {
        self.last_replay_secs = self.now_secs.saturating_sub(hours * 3600);
        self
    }
}

impl Default for PolicyContext {
    fn default() -> Self {
        Self::new()
    }
}

/// A matched rule result with context.
#[derive(Debug, Clone)]
pub struct PolicyMatch {
    /// The rule that matched.
    pub rule: PolicyRule,
    /// The context at match time.
    pub context: PolicyContext,
}

/// The policy engine — evaluates rules against context.
#[derive(Debug, Clone)]
pub struct PolicyEngine {
    /// Registered rules, sorted by priority (highest first).
    rules: Vec<PolicyRule>,
}

impl PolicyEngine {
    /// Create a new empty policy engine.
    #[must_use]
    pub fn new() -> Self {
        Self { rules: Vec::new() }
    }

    /// Register a rule. Rules are kept sorted by priority descending.
    pub fn add_rule(&mut self, rule: PolicyRule) {
        self.rules.push(rule);
        // Sort by priority descending so evaluate returns highest-priority first
        self.rules.sort_by(|a, b| b.priority.cmp(&a.priority));
    }

    /// Register multiple rules at once.
    pub fn add_rules(&mut self, rules: impl IntoIterator<Item = PolicyRule>) {
        for rule in rules {
            self.add_rule(rule);
        }
    }

    /// Evaluate all rules against context, returning matched actions sorted by priority.
    #[must_use]
    pub fn evaluate(&self, context: &PolicyContext) -> Vec<PolicyMatch> {
        self.rules
            .iter()
            .filter(|rule| rule.matches(context))
            .map(|rule| PolicyMatch {
                rule: rule.clone(),
                context: context.clone(),
            })
            .collect()
    }

    /// Evaluate and return just the actions for matched rules.
    #[must_use]
    pub fn evaluate_actions(&self, context: &PolicyContext) -> Vec<PolicyAction> {
        self.evaluate(context)
            .into_iter()
            .map(|m| m.rule.action)
            .collect()
    }

    /// Check if any rule matches (short-circuit).
    #[must_use]
    pub fn any_match(&self, context: &PolicyContext) -> bool {
        self.rules.iter().any(|rule| rule.matches(context))
    }

    /// Get the number of registered rules.
    #[must_use]
    pub fn rule_count(&self) -> usize {
        self.rules.len()
    }

    /// Remove all rules.
    pub fn clear(&mut self) {
        self.rules.clear();
    }

    /// Build a standard set of default rules for BKG operation.
    #[must_use]
    pub fn with_defaults() -> Self {
        let mut engine = Self::new();

        engine.add_rule(PolicyRule::new(
            "low-trust-escalation",
            PolicyCondition::TrustBelow(0.3),
            PolicyAction::EscalateToMotherbrain,
            100,
        ));

        engine.add_rule(PolicyRule::new(
            "medium-trust-replay",
            PolicyCondition::And(vec![
                PolicyCondition::TrustBelow(0.6),
                PolicyCondition::TrustBelow(0.3).not(),
            ]),
            PolicyAction::TriggerReplay,
            80,
        ));

        engine.add_rule(PolicyRule::new(
            "high-entropy-gc",
            PolicyCondition::EntropyAbove(0.7),
            PolicyAction::ForceGC,
            90,
        ));

        engine.add_rule(PolicyRule::new(
            "stale-replay-trigger",
            PolicyCondition::TimeSinceLastReplay { hours: 24 },
            PolicyAction::TriggerReplay,
            60,
        ));

        engine.add_rule(PolicyRule::new(
            "unstoppable-node-escalation",
            PolicyCondition::NodeStabilityBelow(0.2),
            PolicyAction::EscalateToMotherbrain,
            110,
        ));

        engine.add_rule(PolicyRule::new(
            "low-determinism-warning",
            PolicyCondition::ChunkDeterminismBelow(0.5),
            PolicyAction::LogWarning("Chunk determinism below 0.5 — possible divergence".into()),
            40,
        ));

        engine
    }
}

impl Default for PolicyEngine {
    fn default() -> Self {
        Self::new()
    }
}

// ──────────────────────────────────────────────
// Negation helper
// ──────────────────────────────────────────────

impl PolicyCondition {
    /// Create the logical negation of this condition.
    /// Double negation cancels out (Not(Not(x)) → x).
    #[must_use]
    pub fn not(self) -> Self {
        match self {
            Self::Not(inner) => *inner,
            other => Self::Not(Box::new(other)),
        }
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn simple_condition_matches() {
        let ctx = PolicyContext::new().with_trust(0.2);
        let cond = PolicyCondition::TrustBelow(0.5);
        assert!(cond.matches(&ctx));
    }

    #[test]
    fn simple_condition_does_not_match() {
        let ctx = PolicyContext::new().with_trust(0.8);
        let cond = PolicyCondition::TrustBelow(0.5);
        assert!(!cond.matches(&ctx));
    }

    #[test]
    fn and_all_matches() {
        let ctx = PolicyContext::new().with_trust(0.2).with_entropy(0.8);
        let cond = PolicyCondition::And(vec![
            PolicyCondition::TrustBelow(0.5),
            PolicyCondition::EntropyAbove(0.5),
        ]);
        assert!(cond.matches(&ctx));
    }

    #[test]
    fn and_one_fails() {
        let ctx = PolicyContext::new().with_trust(0.8).with_entropy(0.8);
        let cond = PolicyCondition::And(vec![
            PolicyCondition::TrustBelow(0.5),
            PolicyCondition::EntropyAbove(0.5),
        ]);
        assert!(!cond.matches(&ctx));
    }

    #[test]
    fn or_any_matches() {
        let ctx = PolicyContext::new().with_trust(0.8).with_entropy(0.8);
        let cond = PolicyCondition::Or(vec![
            PolicyCondition::TrustBelow(0.5),
            PolicyCondition::EntropyAbove(0.5),
        ]);
        assert!(cond.matches(&ctx));
    }

    #[test]
    fn or_none_match() {
        let ctx = PolicyContext::new().with_trust(0.8).with_entropy(0.2);
        let cond = PolicyCondition::Or(vec![
            PolicyCondition::TrustBelow(0.5),
            PolicyCondition::EntropyAbove(0.5),
        ]);
        assert!(!cond.matches(&ctx));
    }

    #[test]
    fn rule_matches_and_produces_action() {
        let rule = PolicyRule::new(
            "test-rule",
            PolicyCondition::TrustBelow(0.5),
            PolicyAction::EscalateToMotherbrain,
            50,
        );
        let ctx = PolicyContext::new().with_trust(0.3);
        assert!(rule.matches(&ctx));
    }

    #[test]
    fn evaluate_empty_engine() {
        let engine = PolicyEngine::new();
        let ctx = PolicyContext::new().with_trust(0.1);
        let matches = engine.evaluate(&ctx);
        assert!(matches.is_empty());
    }

    #[test]
    fn evaluate_single_rule_match() {
        let mut engine = PolicyEngine::new();
        engine.add_rule(PolicyRule::new(
            "low-trust",
            PolicyCondition::TrustBelow(0.5),
            PolicyAction::EscalateToMotherbrain,
            50,
        ));
        let ctx = PolicyContext::new().with_trust(0.3);
        let matches = engine.evaluate(&ctx);
        assert_eq!(matches.len(), 1);
        assert_eq!(matches[0].rule.name, "low-trust");
        assert_eq!(matches[0].rule.action, PolicyAction::EscalateToMotherbrain);
    }

    #[test]
    fn evaluate_respects_priority_order() {
        let mut engine = PolicyEngine::new();
        engine.add_rule(PolicyRule::new(
            "low-priority",
            PolicyCondition::TrustBelow(0.9),
            PolicyAction::LogWarning("low".into()),
            10,
        ));
        engine.add_rule(PolicyRule::new(
            "high-priority",
            PolicyCondition::TrustBelow(0.9),
            PolicyAction::EscalateToMotherbrain,
            100,
        ));
        let ctx = PolicyContext::new().with_trust(0.3);
        let matches = engine.evaluate(&ctx);
        assert_eq!(matches.len(), 2);
        assert_eq!(matches[0].rule.name, "high-priority");
        assert_eq!(matches[1].rule.name, "low-priority");
    }

    #[test]
    fn evaluate_actions_returns_action_list() {
        let mut engine = PolicyEngine::new();
        engine.add_rule(PolicyRule::new(
            "low-trust",
            PolicyCondition::TrustBelow(0.5),
            PolicyAction::EscalateToMotherbrain,
            50,
        ));
        engine.add_rule(PolicyRule::new(
            "high-entropy",
            PolicyCondition::EntropyAbove(0.5),
            PolicyAction::ForceGC,
            50,
        ));
        let ctx = PolicyContext::new().with_trust(0.3).with_entropy(0.8);
        let actions = engine.evaluate_actions(&ctx);
        assert!(actions.contains(&PolicyAction::EscalateToMotherbrain));
        assert!(actions.contains(&PolicyAction::ForceGC));
    }

    #[test]
    fn any_match_short_circuits() {
        let mut engine = PolicyEngine::new();
        engine.add_rule(PolicyRule::new(
            "low-trust",
            PolicyCondition::TrustBelow(0.5),
            PolicyAction::EscalateToMotherbrain,
            50,
        ));
        let ctx = PolicyContext::new().with_trust(0.9);
        assert!(!engine.any_match(&ctx));
        let ctx2 = PolicyContext::new().with_trust(0.3);
        assert!(engine.any_match(&ctx2));
    }

    #[test]
    fn default_rules_are_set_up() {
        let engine = PolicyEngine::with_defaults();
        assert_eq!(engine.rule_count(), 6);
    }

    #[test]
    fn clear_removes_all_rules() {
        let mut engine = PolicyEngine::new();
        engine.add_rule(PolicyRule::new(
            "test",
            PolicyCondition::TrustBelow(0.5),
            PolicyAction::LogWarning("test".into()),
            50,
        ));
        assert_eq!(engine.rule_count(), 1);
        engine.clear();
        assert_eq!(engine.rule_count(), 0);
    }

    #[test]
    fn time_since_last_replay_matches() {
        let ctx = PolicyContext::new().with_replay_hours_ago(48);
        let cond = PolicyCondition::TimeSinceLastReplay { hours: 24 };
        assert!(cond.matches(&ctx));
    }

    #[test]
    fn time_since_last_replay_does_not_match() {
        let ctx = PolicyContext::new().with_replay_hours_ago(12);
        let cond = PolicyCondition::TimeSinceLastReplay { hours: 24 };
        assert!(!cond.matches(&ctx));
    }

    #[test]
    fn node_stability_detection() {
        let ctx = PolicyContext::new().with_stability(0.1);
        let cond = PolicyCondition::NodeStabilityBelow(0.2);
        assert!(cond.matches(&ctx));
        let ctx2 = PolicyContext::new().with_stability(0.5);
        assert!(!cond.matches(&ctx2));
    }

    #[test]
    fn chunk_determinism_detection() {
        let ctx = PolicyContext::new().with_determinism(0.3);
        let cond = PolicyCondition::ChunkDeterminismBelow(0.5);
        assert!(cond.matches(&ctx));
        let ctx2 = PolicyContext::new().with_determinism(0.9);
        assert!(!cond.matches(&ctx2));
    }
}
