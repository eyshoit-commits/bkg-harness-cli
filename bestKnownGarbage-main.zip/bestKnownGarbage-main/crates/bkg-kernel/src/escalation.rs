// BKG Kernel — Escalation Engine + Recovery Recipes (P5)
//
// Dynamic role promotion/demotion based on trust metrics.
// + Structured failure recovery with ledger-backed attempt tracking.
//
// ## Design
//
// No permanent status; roles are purely behavioral reflection.
// Recovery follows a deterministic recipe pattern:
//   FailureScenario → RecoveryRecipe (steps) → RecoveryLedger (attempts) → Escalation

use bkg_core::result::Result;
use bkg_events::{BkgEvent, EventBuilder, EventName, EventProvenance, EventStatus, FailureClass};
use sha2::{Digest, Sha256};
use std::fmt::Write as FmtWrite;
use std::time::{SystemTime, UNIX_EPOCH};

// ──────────────────────────────────────────────
// Role System (existing, extended)
// ──────────────────────────────────────────────

/// Node role in the trust mesh.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub enum Role {
    Collector,
    TrustHero,
    Motherbrain,
}

impl Role {
    /// Rank for ordering (higher = more authority)
    #[must_use]
    pub fn rank(&self) -> u32 {
        match self {
            Role::Collector => 0,
            Role::TrustHero => 1,
            Role::Motherbrain => 2,
        }
    }
}

/// A recorded role transition event.
#[derive(Clone, Debug)]
pub struct TrustRecord {
    pub node_id: String,
    pub timestamp: u64,
    pub old_role: Role,
    pub new_role: Role,
    pub trust: f32,
    pub reason: String,
}

/// Thresholds for role transitions.
#[derive(Clone, Debug)]
pub struct EscalationThresholds {
    pub hero_promotion_min: f32,
    pub collector_demotion_max: f32,
    pub hero_demotion_max: f32,
    pub min_epochs_before_promotion: u64,
}

impl Default for EscalationThresholds {
    fn default() -> Self {
        Self {
            hero_promotion_min: 0.85,
            collector_demotion_max: 0.40,
            hero_demotion_max: 0.60,
            min_epochs_before_promotion: 10,
        }
    }
}

// ──────────────────────────────────────────────
// Failure Scenarios
// ──────────────────────────────────────────────

/// BKG-specific failure scenarios that can trigger recovery.
#[derive(Clone, Debug, PartialEq)]
pub enum FailureScenario {
    /// Mesh partition — peers unreachable
    MeshPartition { peer_count: u32, min_required: u32 },
    /// Ledger write stall or corruption
    LedgerStall { receipt_id: String, attempt: u32 },
    /// Trust gap — average trust below threshold
    TrustGap { avg_trust: f32, threshold: f32 },
    /// Replay hash mismatch
    ReplayMismatch {
        chunk_id: String,
        expected_hash: String,
        actual_hash: String,
    },
    /// Entropy spike above maximum
    EntropySpike { entropy: f32, max_allowed: f32 },
    /// Collusion pattern detected
    CollusionDetected { pattern_id: String, severity: f32 },
    /// WASM execution failure
    WasmExecution {
        module_id: String,
        fuel_used: u64,
        fuel_limit: u64,
    },
}

impl FailureScenario {
    /// Human-readable label for this scenario.
    #[must_use]
    pub fn label(&self) -> &str {
        match self {
            FailureScenario::MeshPartition { .. } => "mesh_partition",
            FailureScenario::LedgerStall { .. } => "ledger_stall",
            FailureScenario::TrustGap { .. } => "trust_gap",
            FailureScenario::ReplayMismatch { .. } => "replay_mismatch",
            FailureScenario::EntropySpike { .. } => "entropy_spike",
            FailureScenario::CollusionDetected { .. } => "collusion_detected",
            FailureScenario::WasmExecution { .. } => "wasm_execution",
        }
    }

    /// Convert to an event FailureClass for event emission.
    #[must_use]
    pub fn to_failure_class(&self) -> FailureClass {
        match self {
            FailureScenario::MeshPartition { .. } => FailureClass::MeshPartition,
            FailureScenario::LedgerStall { .. } => FailureClass::LedgerStall,
            FailureScenario::TrustGap { .. } => FailureClass::TrustGap,
            FailureScenario::ReplayMismatch { .. } => FailureClass::ReplayMismatch,
            FailureScenario::EntropySpike { .. } => FailureClass::EntropySpike,
            FailureScenario::CollusionDetected { .. } => FailureClass::CollusionDetected,
            FailureScenario::WasmExecution { .. } => FailureClass::WasmExecution,
        }
    }

    /// A deterministic fingerprint for this scenario instance.
    #[must_use]
    pub fn fingerprint(&self) -> String {
        let payload = format!("{:?}", self);
        let mut hasher = Sha256::new();
        hasher.update(payload.as_bytes());
        let digest = hasher.finalize();
        let mut fp = String::with_capacity(16);
        for byte in &digest[..8] {
            write!(&mut fp, "{byte:02x}").expect("fingerprint write");
        }
        fp
    }
}

// ──────────────────────────────────────────────
// Recovery Steps
// ──────────────────────────────────────────────

/// An actionable recovery step.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum RecoveryStep {
    /// Reconnect to mesh, retry peer discovery
    ReconnectMesh,
    /// Retry the failed operation
    RetryOperation,
    /// Force a full replay verification
    TriggerReplay,
    /// Escalate to Motherbrain for adjudication
    EscalateToMotherbrain,
    /// Quarantine the affected node(s)
    QuarantineNode { node_id: String },
    /// Force garbage collection / entropy recompute
    ForceGc,
    /// Perform an emergency rollback
    EmergencyRollback,
    /// Log and continue (advisory only)
    LogAndContinue,
    /// Signal operator for manual intervention
    SignalOperator { message: String },
}

/// Severity level for recovery recipes.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RecoverySeverity {
    Info,
    Warning,
    Critical,
}

// ──────────────────────────────────────────────
// Recovery Recipe
// ──────────────────────────────────────────────

/// A recipe = a sequence of recovery steps for a given failure scenario.
#[derive(Clone, Debug)]
pub struct RecoveryRecipe {
    /// The failure scenario this recipe handles
    pub scenario: FailureScenario,
    /// Ordered steps to attempt
    pub steps: Vec<RecoveryStep>,
    /// Severity classification
    pub severity: RecoverySeverity,
    /// Maximum number of attempts before escalation
    pub max_attempts: u32,
    /// Cooldown between attempts (seconds)
    pub cooldown_secs: u64,
}

impl RecoveryRecipe {
    /// Build a recipe for a given failure scenario.
    #[must_use]
    pub fn for_scenario(scenario: &FailureScenario) -> Self {
        let (steps, severity, max_attempts, cooldown_secs) = match scenario {
            FailureScenario::MeshPartition { .. } => (
                vec![RecoveryStep::ReconnectMesh, RecoveryStep::LogAndContinue],
                RecoverySeverity::Warning,
                3,
                30,
            ),
            FailureScenario::LedgerStall { .. } => (
                vec![
                    RecoveryStep::RetryOperation,
                    RecoveryStep::TriggerReplay,
                    RecoveryStep::EscalateToMotherbrain,
                ],
                RecoverySeverity::Critical,
                2,
                10,
            ),
            FailureScenario::TrustGap { .. } => (
                vec![
                    RecoveryStep::TriggerReplay,
                    RecoveryStep::ForceGc,
                    RecoveryStep::EscalateToMotherbrain,
                ],
                RecoverySeverity::Warning,
                3,
                60,
            ),
            FailureScenario::ReplayMismatch { .. } => (
                vec![
                    RecoveryStep::RetryOperation,
                    RecoveryStep::TriggerReplay,
                    RecoveryStep::EscalateToMotherbrain,
                ],
                RecoverySeverity::Critical,
                2,
                15,
            ),
            FailureScenario::EntropySpike { .. } => (
                vec![
                    RecoveryStep::ForceGc,
                    RecoveryStep::TriggerReplay,
                    RecoveryStep::SignalOperator {
                        message: "Entropy spike detected — manual review recommended".to_string(),
                    },
                ],
                RecoverySeverity::Warning,
                3,
                120,
            ),
            FailureScenario::CollusionDetected { .. } => (
                vec![
                    RecoveryStep::QuarantineNode {
                        node_id: String::new(), // caller fills in
                    },
                    RecoveryStep::EscalateToMotherbrain,
                    RecoveryStep::SignalOperator {
                        message: "Collusion pattern detected — immediate action required"
                            .to_string(),
                    },
                ],
                RecoverySeverity::Critical,
                1,
                0,
            ),
            FailureScenario::WasmExecution { .. } => (
                vec![
                    RecoveryStep::RetryOperation,
                    RecoveryStep::EscalateToMotherbrain,
                ],
                RecoverySeverity::Warning,
                3,
                5,
            ),
        };

        Self {
            scenario: scenario.clone(),
            steps,
            severity,
            max_attempts,
            cooldown_secs,
        }
    }

    /// Get the current step index based on attempt number (wraps around).
    #[must_use]
    pub fn current_step(&self, attempt: u32) -> Option<&RecoveryStep> {
        if attempt >= self.max_attempts {
            return None;
        }
        let idx = attempt as usize % self.steps.len();
        self.steps.get(idx)
    }

    /// Check if we've exceeded max attempts and should escalate.
    #[must_use]
    pub fn should_escalate(&self, attempt: u32) -> bool {
        attempt >= self.max_attempts
    }
}

// ──────────────────────────────────────────────
// Recovery Ledger
// ──────────────────────────────────────────────

/// Tracks recovery attempts for deduplication and coalescing.
#[derive(Clone, Debug)]
pub struct RecoveryEntry {
    /// Fingerprint of the failure scenario
    pub fingerprint: String,
    /// Number of attempts made
    pub attempts: u32,
    /// Timestamp of last attempt
    pub last_attempt_at: u64,
    /// Whether this failure has been escalated
    pub escalated: bool,
    /// Whether recovery succeeded
    pub resolved: bool,
}

/// Ledger for tracking recovery attempts with coalescing/backoff.
#[derive(Clone, Debug, Default)]
pub struct RecoveryLedger {
    entries: Vec<RecoveryEntry>,
}

impl RecoveryLedger {
    /// Create a new empty recovery ledger.
    #[must_use]
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
        }
    }

    /// Get the current entry for a fingerprint, if any.
    #[must_use]
    pub fn get_entry(&self, fingerprint: &str) -> Option<&RecoveryEntry> {
        self.entries.iter().find(|e| e.fingerprint == fingerprint)
    }

    /// Register a new attempt. Returns the attempt number (1-based).
    pub fn register_attempt(&mut self, fingerprint: &str) -> u32 {
        let now = now_secs();

        if let Some(entry) = self
            .entries
            .iter_mut()
            .find(|e| e.fingerprint == fingerprint)
        {
            entry.attempts += 1;
            entry.last_attempt_at = now;
            entry.resolved = false;
            entry.escalated = false;
            entry.attempts
        } else {
            self.entries.push(RecoveryEntry {
                fingerprint: fingerprint.to_string(),
                attempts: 1,
                last_attempt_at: now,
                escalated: false,
                resolved: false,
            });
            1
        }
    }

    /// Mark a failure as resolved.
    pub fn mark_resolved(&mut self, fingerprint: &str) {
        if let Some(entry) = self
            .entries
            .iter_mut()
            .find(|e| e.fingerprint == fingerprint)
        {
            entry.resolved = true;
        }
    }

    /// Mark a failure as escalated.
    pub fn mark_escalated(&mut self, fingerprint: &str) {
        if let Some(entry) = self
            .entries
            .iter_mut()
            .find(|e| e.fingerprint == fingerprint)
        {
            entry.escalated = true;
        }
    }

    /// Check if a failure is already resolved.
    #[must_use]
    pub fn is_resolved(&self, fingerprint: &str) -> bool {
        self.entries
            .iter()
            .any(|e| e.fingerprint == fingerprint && e.resolved)
    }

    /// Check if we're in cooldown for a fingerprint.
    #[must_use]
    pub fn in_cooldown(&self, fingerprint: &str, cooldown_secs: u64) -> bool {
        self.entries.iter().any(|e| {
            e.fingerprint == fingerprint
                && !e.resolved
                && (now_secs() - e.last_attempt_at) < cooldown_secs
        })
    }

    /// Number of unique failure fingerprints tracked.
    #[must_use]
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the ledger is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// All unresolved entries.
    #[must_use]
    pub fn unresolved(&self) -> Vec<&RecoveryEntry> {
        self.entries.iter().filter(|e| !e.resolved).collect()
    }

    /// All entries that require escalation.
    #[must_use]
    pub fn pending_escalation(&self) -> Vec<&RecoveryEntry> {
        self.entries
            .iter()
            .filter(|e| !e.resolved && !e.escalated && e.attempts >= 3)
            .collect()
    }
}

// ──────────────────────────────────────────────
// Escalation Engine (extended with Recovery)
// ──────────────────────────────────────────────

/// Combined escalation engine with role management + recovery recipes.
#[derive(Debug)]
pub struct EscalationEngine {
    // Role management
    role_history: Vec<TrustRecord>,
    thresholds: EscalationThresholds,

    // Recovery
    recovery_ledger: RecoveryLedger,
    event_sink: Vec<BkgEvent>,
}

impl Default for EscalationEngine {
    fn default() -> Self {
        Self::new()
    }
}

impl EscalationEngine {
    /// Create a new escalation engine.
    #[must_use]
    pub fn new() -> Self {
        Self {
            role_history: Vec::new(),
            thresholds: EscalationThresholds::default(),
            recovery_ledger: RecoveryLedger::new(),
            event_sink: Vec::new(),
        }
    }

    /// Create with custom thresholds.
    #[must_use]
    pub fn with_thresholds(thresholds: EscalationThresholds) -> Self {
        Self {
            role_history: Vec::new(),
            thresholds,
            recovery_ledger: RecoveryLedger::new(),
            event_sink: Vec::new(),
        }
    }

    // ── Role Management ──

    /// Evaluate what role a node should have.
    #[must_use]
    pub fn evaluate_role(&self, current_role: &Role, trust: f32, _epoch: u64) -> Role {
        if *current_role == Role::Motherbrain {
            return Role::Motherbrain;
        }
        if trust >= self.thresholds.hero_promotion_min {
            Role::TrustHero
        } else if trust < self.thresholds.collector_demotion_max {
            Role::Collector
        } else {
            current_role.clone()
        }
    }

    /// Update a node's role and record the transition.
    pub fn update_role(
        &mut self,
        node_id: &str,
        old_role: Role,
        new_role: Role,
        trust: f32,
        reason: &str,
    ) -> bool {
        if old_role == new_role {
            return false;
        }

        self.role_history.push(TrustRecord {
            node_id: node_id.to_string(),
            timestamp: now_secs(),
            old_role: old_role.clone(),
            new_role: new_role.clone(),
            trust,
            reason: reason.to_string(),
        });

        // Emit role event
        let event_name = if new_role.rank() > old_role.rank() {
            EventName::TrustPromoted
        } else {
            EventName::TrustDemoted
        };
        let event = EventBuilder::new(
            event_name,
            EventStatus::Completed,
            iso_timestamp(),
            0,
            EventProvenance::Live,
        )
        .with_emitter("escalation_engine")
        .with_detail(format!(
            "node {}: {:?} → {:?} (trust: {:.2})",
            node_id, old_role, new_role, trust
        ))
        .build();
        self.event_sink.push(event);

        true
    }

    /// Check if a node is eligible for promotion.
    #[must_use]
    pub fn can_promote(&self, _node_id: &str, trust: f32, _epoch: u64) -> bool {
        trust >= self.thresholds.hero_promotion_min
    }

    /// Get promotion/demotion statistics.
    #[must_use]
    pub fn stats(&self) -> EscalationStats {
        let promotions = self
            .role_history
            .iter()
            .filter(|r| r.new_role.rank() > r.old_role.rank())
            .count();
        let demotions = self
            .role_history
            .iter()
            .filter(|r| r.new_role.rank() < r.old_role.rank())
            .count();

        EscalationStats {
            total_transitions: self.role_history.len(),
            promotions,
            demotions,
        }
    }

    /// Get the full role transition history.
    #[must_use]
    pub fn role_history(&self) -> &[TrustRecord] {
        &self.role_history
    }

    // ── Recovery Recipes ──

    /// Attempt recovery for a given failure scenario.
    ///
    /// Returns the step to execute, or `None` if in cooldown/already resolved.
    pub fn attempt_recovery(&mut self, scenario: &FailureScenario) -> Result<Option<RecoveryStep>> {
        let recipe = RecoveryRecipe::for_scenario(scenario);
        let fp = scenario.fingerprint();

        // Already resolved?
        if self.recovery_ledger.is_resolved(&fp) {
            return Ok(None);
        }

        // In cooldown?
        if self.recovery_ledger.in_cooldown(&fp, recipe.cooldown_secs) {
            return Ok(None);
        }

        let attempt = self.recovery_ledger.register_attempt(&fp);

        // Emit recovery attempt event
        let event = EventBuilder::new(
            EventName::TrustEscalation,
            EventStatus::Pending,
            iso_timestamp(),
            0,
            EventProvenance::Live,
        )
        .with_emitter("escalation_engine")
        .with_detail(format!("recovery attempt {} for {:?}", attempt, scenario))
        .build();
        self.event_sink.push(event);

        // Check if we should escalate instead
        if recipe.should_escalate(attempt) {
            self.recovery_ledger.mark_escalated(&fp);
            return Ok(Some(RecoveryStep::EscalateToMotherbrain));
        }

        // Return the current step
        Ok(recipe.current_step(attempt).cloned())
    }

    /// Mark a failure as resolved.
    pub fn resolve(&mut self, scenario: &FailureScenario) {
        let fp = scenario.fingerprint();
        self.recovery_ledger.mark_resolved(&fp);

        let event = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            iso_timestamp(),
            0,
            EventProvenance::Live,
        )
        .with_emitter("escalation_engine")
        .with_detail(format!("recovery resolved for {:?}", scenario))
        .build();
        self.event_sink.push(event);
    }

    /// Drain emitted events (for integration with event bus).
    #[must_use]
    pub fn drain_events(&mut self) -> Vec<BkgEvent> {
        std::mem::take(&mut self.event_sink)
    }

    /// Get a reference to the recovery ledger.
    #[must_use]
    pub fn recovery_ledger(&self) -> &RecoveryLedger {
        &self.recovery_ledger
    }

    /// Get a mutable reference to the recovery ledger.
    pub fn recovery_ledger_mut(&mut self) -> &mut RecoveryLedger {
        &mut self.recovery_ledger
    }
}

// ──────────────────────────────────────────────
// Statistics
// ──────────────────────────────────────────────

#[derive(Debug)]
pub struct EscalationStats {
    pub total_transitions: usize,
    pub promotions: usize,
    pub demotions: usize,
}

// ──────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn iso_timestamp() -> String {
    // Simple ISO-8601 timestamp without pulling in extra deps
    let secs = now_secs();
    let days = secs / 86400;
    let time_secs = secs % 86400;
    let hours = time_secs / 3600;
    let mins = (time_secs % 3600) / 60;
    let secs_remainder = time_secs % 60;

    // Simple offset from Unix epoch (1970 + days/365.25 approx)
    let year = 1970 + (days / 365) as u64;
    format!(
        "{year}-{:02}-{:02}T{:02}:{:02}:{:02}Z",
        1 + ((days % 365) / 28).min(11) as u8,
        1 + (days % 28) as u8,
        hours,
        mins,
        secs_remainder
    )
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── Role Evaluation Tests (existing) ──

    #[test]
    fn test_role_evaluation() {
        let engine = EscalationEngine::new();
        assert_eq!(
            engine.evaluate_role(&Role::Collector, 0.95, 100),
            Role::TrustHero
        );
        assert_eq!(
            engine.evaluate_role(&Role::TrustHero, 0.95, 100),
            Role::TrustHero
        );
        assert_eq!(
            engine.evaluate_role(&Role::TrustHero, 0.30, 100),
            Role::Collector
        );
        assert_eq!(
            engine.evaluate_role(&Role::Collector, 0.30, 100),
            Role::Collector
        );
        assert_eq!(
            engine.evaluate_role(&Role::Collector, 0.70, 100),
            Role::Collector
        );
    }

    #[test]
    fn test_transition_recording() {
        let mut engine = EscalationEngine::new();
        let changed = engine.update_role(
            "node1",
            Role::Collector,
            Role::TrustHero,
            0.92,
            "high trust",
        );
        assert!(changed);
        assert_eq!(engine.role_history().len(), 1);
        assert_eq!(
            engine.role_history().last().unwrap().new_role,
            Role::TrustHero
        );
    }

    #[test]
    fn test_no_transition_for_same_role() {
        let mut engine = EscalationEngine::new();
        let changed =
            engine.update_role("node1", Role::TrustHero, Role::TrustHero, 0.90, "no change");
        assert!(!changed);
        assert!(engine.role_history().is_empty());
    }

    #[test]
    fn test_motherbrain_is_permanent() {
        let engine = EscalationEngine::new();
        assert_eq!(
            engine.evaluate_role(&Role::Motherbrain, 0.10, 100),
            Role::Motherbrain
        );
    }

    // ── Recovery Recipe Tests ──

    #[test]
    fn test_recipe_for_mesh_partition() {
        let scenario = FailureScenario::MeshPartition {
            peer_count: 2,
            min_required: 5,
        };
        let recipe = RecoveryRecipe::for_scenario(&scenario);
        assert_eq!(recipe.severity as u32, RecoverySeverity::Warning as u32);
        assert_eq!(recipe.steps[0], RecoveryStep::ReconnectMesh);
    }

    #[test]
    fn test_recipe_for_ledger_stall() {
        let scenario = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        let recipe = RecoveryRecipe::for_scenario(&scenario);
        assert_eq!(recipe.severity as u32, RecoverySeverity::Critical as u32);
        assert_eq!(recipe.steps[0], RecoveryStep::RetryOperation);
        assert!(recipe.should_escalate(2)); // max_attempts = 2
    }

    #[test]
    fn test_recipe_for_collusion() {
        let scenario = FailureScenario::CollusionDetected {
            pattern_id: "sybil-01".into(),
            severity: 0.95,
        };
        let recipe = RecoveryRecipe::for_scenario(&scenario);
        assert_eq!(recipe.max_attempts, 1); // immediate escalation
        assert!(recipe.should_escalate(1));
    }

    #[test]
    fn test_recipe_step_progression() {
        let scenario = FailureScenario::EntropySpike {
            entropy: 0.85,
            max_allowed: 0.5,
        };
        let recipe = RecoveryRecipe::for_scenario(&scenario);
        assert_eq!(recipe.current_step(0), Some(&RecoveryStep::ForceGc));
        assert_eq!(recipe.current_step(1), Some(&RecoveryStep::TriggerReplay));
        // Exhausted: should be None
        assert_eq!(recipe.current_step(3), None);
    }

    // ── Recovery Ledger Tests ──

    #[test]
    fn test_recovery_ledger_tracks_attempts() {
        let mut ledger = RecoveryLedger::new();
        let scenario = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        let fp = scenario.fingerprint();

        let a1 = ledger.register_attempt(&fp);
        assert_eq!(a1, 1);

        let a2 = ledger.register_attempt(&fp);
        assert_eq!(a2, 2);

        assert_eq!(ledger.len(), 1);
    }

    #[test]
    fn test_recovery_ledger_cooldown() {
        let mut ledger = RecoveryLedger::new();
        let scenario = FailureScenario::MeshPartition {
            peer_count: 1,
            min_required: 3,
        };
        let fp = scenario.fingerprint();

        ledger.register_attempt(&fp);
        // Should be in cooldown (cooldown > 0 secs)
        assert!(ledger.in_cooldown(&fp, 60));
    }

    #[test]
    fn test_recovery_ledger_resolved() {
        let mut ledger = RecoveryLedger::new();
        let fp = "test-fp";
        ledger.register_attempt(fp);
        ledger.mark_resolved(fp);
        assert!(ledger.is_resolved(fp));
        assert!(!ledger.in_cooldown(fp, 60));
    }

    #[test]
    fn test_recovery_ledger_mark_escalated() {
        let mut ledger = RecoveryLedger::new();
        let fp = "test-fp";
        ledger.register_attempt(fp);
        ledger.register_attempt(fp);
        ledger.register_attempt(fp);
        ledger.mark_escalated(fp);
        assert!(ledger.pending_escalation().is_empty()); // already escalated
    }

    #[test]
    fn test_recovery_ledger_multiple_failures() {
        let mut ledger = RecoveryLedger::new();
        ledger.register_attempt("mesh-fail");
        ledger.register_attempt("ledger-fail");
        ledger.register_attempt("mesh-fail");
        assert_eq!(ledger.len(), 2);
    }

    // ── Recovery Attempt Integration ──

    #[test]
    fn test_attempt_recovery_returns_step() {
        let mut engine = EscalationEngine::new();
        let scenario = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };

        let step = engine.attempt_recovery(&scenario).unwrap();
        assert!(step.is_some());
        assert_eq!(step.unwrap(), RecoveryStep::RetryOperation);
    }

    #[test]
    fn test_attempt_recovery_returns_none_in_cooldown() {
        let mut engine = EscalationEngine::new();
        let scenario = FailureScenario::MeshPartition {
            peer_count: 1,
            min_required: 3,
        };

        // First attempt
        let step1 = engine.attempt_recovery(&scenario).unwrap();
        assert!(step1.is_some());

        // Second attempt immediately should be in cooldown
        let step2 = engine.attempt_recovery(&scenario).unwrap();
        assert!(step2.is_none());
    }

    #[test]
    fn test_attempt_recovery_escalates_after_max_attempts() {
        let mut engine = EscalationEngine::new();
        let scenario = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };

        // Exhaust attempts (max = 2)
        engine.attempt_recovery(&scenario).unwrap(); // 1: RetryOperation
        engine.attempt_recovery(&scenario).unwrap(); // 2: TriggerReplay

        // 3rd attempt should escalate (exceeded max)
        let step = engine.attempt_recovery(&scenario).unwrap();
        assert_eq!(step, Some(RecoveryStep::EscalateToMotherbrain));
    }

    #[test]
    fn test_resolve_clears_failure() {
        let mut engine = EscalationEngine::new();
        let scenario = FailureScenario::MeshPartition {
            peer_count: 1,
            min_required: 3,
        };

        engine.attempt_recovery(&scenario).unwrap();
        engine.resolve(&scenario);

        // After resolution, no recovery step returned
        let step = engine.attempt_recovery(&scenario).unwrap();
        assert!(step.is_none());
    }

    // ── Event Emission ──

    #[test]
    fn test_drain_events_after_recovery() {
        let mut engine = EscalationEngine::new();
        let scenario = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };

        engine.attempt_recovery(&scenario).unwrap();

        let events = engine.drain_events();
        assert!(!events.is_empty());
        assert_eq!(events[0].event, EventName::TrustEscalation);
    }

    #[test]
    fn test_drain_events_after_role_update() {
        let mut engine = EscalationEngine::new();
        engine.update_role("node1", Role::Collector, Role::TrustHero, 0.95, "promoted");

        let events = engine.drain_events();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].event, EventName::TrustPromoted);

        // Second drain should be empty
        assert!(engine.drain_events().is_empty());
    }

    // ── Failure Scenario Tests ──

    #[test]
    fn test_failure_scenario_label() {
        let s = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        assert_eq!(s.label(), "ledger_stall");
    }

    #[test]
    fn test_failure_scenario_fingerprint_is_deterministic() {
        let s1 = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        let s2 = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        assert_eq!(s1.fingerprint(), s2.fingerprint());
    }

    #[test]
    fn test_failure_scenario_fingerprint_differs_for_different_scenarios() {
        let s1 = FailureScenario::LedgerStall {
            receipt_id: "r1".into(),
            attempt: 1,
        };
        let s2 = FailureScenario::LedgerStall {
            receipt_id: "r2".into(),
            attempt: 1,
        };
        assert_ne!(s1.fingerprint(), s2.fingerprint());
    }

    #[test]
    fn test_failure_scenario_to_failure_class() {
        let s = FailureScenario::ReplayMismatch {
            chunk_id: "c1".into(),
            expected_hash: "abc".into(),
            actual_hash: "def".into(),
        };
        assert_eq!(s.to_failure_class(), FailureClass::ReplayMismatch);
    }

    #[test]
    fn test_role_rank() {
        assert_eq!(Role::Collector.rank(), 0);
        assert_eq!(Role::TrustHero.rank(), 1);
        assert_eq!(Role::Motherbrain.rank(), 2);
    }

    #[test]
    fn test_escalation_stats() {
        let mut engine = EscalationEngine::new();
        assert_eq!(engine.stats().total_transitions, 0);

        engine.update_role("n1", Role::Collector, Role::TrustHero, 0.9, "promote");
        engine.update_role("n2", Role::TrustHero, Role::Collector, 0.3, "demote");

        let stats = engine.stats();
        assert_eq!(stats.total_transitions, 2);
        assert_eq!(stats.promotions, 1);
        assert_eq!(stats.demotions, 1);
    }
}
