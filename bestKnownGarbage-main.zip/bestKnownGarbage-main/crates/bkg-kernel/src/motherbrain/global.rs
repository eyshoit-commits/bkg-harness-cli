//! BKG Motherbrain Global Interface
//!
//! Federated truth consensus across distributed Motherbrain mesh.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Global Motherbrain for federated consensus
#[derive(Debug, Clone)]
pub struct GlobalMotherbrain {
    /// Federated nodes
    pub federated_nodes: HashMap<NodeId, FederatedNode>,
    /// Consensus threshold
    pub consensus_threshold: f32,
    /// Global adjudication history
    pub global_history: Vec<GlobalAdjudication>,
    /// Minimum nodes required for consensus
    pub min_nodes_for_consensus: usize,
}

/// Federated node in the global mesh
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FederatedNode {
    /// Node identifier
    pub node_id: NodeId,
    /// Trust score of this federated node
    pub trust_score: TrustScore,
    /// Last heartbeat
    pub last_heartbeat: Timestamp,
    /// Weight in consensus
    pub weight: f32,
}

/// Global adjudication record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlobalAdjudication {
    /// Claim identifier
    pub claim_id: String,
    /// Votes from federated nodes
    pub votes: Vec<(NodeId, bool)>,
    /// Final decision
    pub decision: bool,
    /// Consensus strength
    pub consensus_strength: f32,
    /// Timestamp
    pub timestamp: Timestamp,
}

/// Consensus result from global adjudication
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlobalConsensus {
    /// Whether consensus was reached
    pub reached: bool,
    /// Final score
    pub score: f32,
    /// Nodes participating
    pub participating_nodes: usize,
    /// Nodes agreeing
    pub agreeing_nodes: usize,
}

impl GlobalMotherbrain {
    /// Create a new global Motherbrain
    pub fn new() -> Self {
        Self {
            federated_nodes: HashMap::new(),
            consensus_threshold: 0.67,
            global_history: Vec::new(),
            min_nodes_for_consensus: 3,
        }
    }

    /// Register a federated node
    pub fn register_node(&mut self, node: FederatedNode) {
        self.federated_nodes.insert(node.node_id.clone(), node);
    }

    /// Remove a federated node
    pub fn remove_node(&mut self, node_id: &NodeId) {
        self.federated_nodes.remove(node_id);
    }

    /// Adjudicate claims from federated nodes
    pub fn adjudicate(&mut self, claims: Vec<(NodeId, TrustScore)>) -> GlobalConsensus {
        if claims.len() < self.min_nodes_for_consensus {
            return GlobalConsensus {
                reached: false,
                score: 0.0,
                participating_nodes: claims.len(),
                agreeing_nodes: 0,
            };
        }

        let mut weighted_sum = 0.0;
        let mut total_weight = 0.0;
        let mut agreeing = 0;

        for (node_id, score) in &claims {
            if let Some(node) = self.federated_nodes.get(node_id) {
                let weight = node.weight * node.trust_score;
                weighted_sum += score * weight;
                total_weight += weight;

                if *score > 0.5 {
                    agreeing += 1;
                }
            }
        }

        if total_weight == 0.0 {
            return GlobalConsensus {
                reached: false,
                score: 0.0,
                participating_nodes: claims.len(),
                agreeing_nodes: 0,
            };
        }

        let final_score = weighted_sum / total_weight;
        let reached = final_score >= self.consensus_threshold
            && agreeing as f32 / claims.len() as f32 >= self.consensus_threshold;

        GlobalConsensus {
            reached,
            score: final_score,
            participating_nodes: claims.len(),
            agreeing_nodes: agreeing,
        }
    }

    /// Heartbeat from a federated node
    pub fn heartbeat(&mut self, node_id: &NodeId) {
        if let Some(node) = self.federated_nodes.get_mut(node_id) {
            node.last_heartbeat = Timestamp::now();
        }
    }

    /// Get active federated nodes (recent heartbeat)
    pub fn active_nodes(&self, max_age_ms: u64) -> Vec<&FederatedNode> {
        let now = Timestamp::now().0;
        self.federated_nodes
            .values()
            .filter(|n| now - n.last_heartbeat.0 < max_age_ms)
            .collect()
    }

    /// Compute global trust score
    pub fn compute_global_trust(&self) -> TrustScore {
        if self.federated_nodes.is_empty() {
            return 0.0;
        }

        let active = self.active_nodes(60000); // 1 minute
        if active.is_empty() {
            return 0.0;
        }

        let total: f32 = active.iter().map(|n| n.trust_score * n.weight).sum();
        let weight: f32 = active.iter().map(|n| n.weight).sum();

        total / weight
    }
}

impl Default for GlobalMotherbrain {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_global_motherbrain_creation() {
        let mb = GlobalMotherbrain::new();
        assert_eq!(mb.federated_nodes.len(), 0);
    }

    #[test]
    fn test_node_registration() {
        let mut mb = GlobalMotherbrain::new();

        let node = FederatedNode {
            node_id: "node_1".into(),
            trust_score: 0.9,
            last_heartbeat: Timestamp::now(),
            weight: 1.0,
        };

        mb.register_node(node);

        assert!(mb.federated_nodes.contains_key("node_1"));
    }

    #[test]
    fn test_consensus_adjudication() {
        let mut mb = GlobalMotherbrain::new();

        // Register nodes
        for i in 1..=5 {
            mb.register_node(FederatedNode {
                node_id: format!("node_{}", i),
                trust_score: 0.9,
                last_heartbeat: Timestamp::now(),
                weight: 1.0,
            });
        }

        // Submit claims
        let claims: Vec<(NodeId, TrustScore)> =
            (1..=5).map(|i| (format!("node_{}", i), 0.9)).collect();

        let consensus = mb.adjudicate(claims);

        assert!(consensus.reached);
        assert!(consensus.score > 0.8);
    }
}
