//! BKG Motherbrain Local Interface
//!
//! Domain-level truth adjudication for local kernel instances.

use crate::causality::graph::CausalityGraph;
use crate::core::*;
use crate::trust::TrustKernel;
use serde::{Deserialize, Serialize};

/// Truth decision from adjudication
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TruthDecision {
    /// Verified as true
    Verified,
    /// Rejected as false
    Rejected,
    /// Needs revalidation
    NeedsRevalidation,
    /// Quarantined
    Quarantined,
}

impl TruthDecision {
    /// Check if this decision allows truth claims
    pub fn is_valid_truth(&self) -> bool {
        matches!(self, TruthDecision::Verified)
    }
}

/// Local Motherbrain for domain-level adjudication
#[derive(Debug, Clone)]
pub struct LocalMotherbrain {
    /// Trust threshold for acceptance
    pub trust_threshold: f32,
    /// Maximum allowed entropy
    pub max_entropy: f32,
    /// Adjudication history
    pub history: Vec<AdjudicationRecord>,
}

/// Record of an adjudication decision
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdjudicationRecord {
    /// Chunk being adjudicated
    pub chunk_id: ChunkId,
    /// Decision made
    pub decision: TruthDecision,
    /// Average trust at decision time
    pub avg_trust: f32,
    /// Entropy at decision time
    pub entropy: f32,
    /// Timestamp
    pub timestamp: Timestamp,
}

impl LocalMotherbrain {
    /// Create a new local Motherbrain
    pub fn new() -> Self {
        Self {
            trust_threshold: 0.85,
            max_entropy: 0.3,
            history: Vec::new(),
        }
    }

    /// Adjudicate based on graph and trust
    pub fn adjudicate(&mut self, _graph: &CausalityGraph, trust: &TrustKernel) -> TruthDecision {
        let avg_trust = if trust.scores.is_empty() {
            0.0
        } else {
            trust.scores.values().sum::<f32>() / trust.scores.len() as f32
        };

        let entropy = trust.global_entropy;

        let decision = if avg_trust > self.trust_threshold && entropy < self.max_entropy {
            TruthDecision::Verified
        } else if avg_trust > 0.6 {
            TruthDecision::NeedsRevalidation
        } else if avg_trust > 0.3 {
            TruthDecision::Quarantined
        } else {
            TruthDecision::Rejected
        };

        // Record adjudication
        self.history.push(AdjudicationRecord {
            chunk_id: "global".to_string(),
            decision,
            avg_trust,
            entropy,
            timestamp: Timestamp::now(),
        });

        decision
    }

    /// Adjudicate a specific chunk
    pub fn adjudicate_chunk(
        &mut self,
        chunk_id: &ChunkId,
        graph: &CausalityGraph,
        trust: &TrustKernel,
    ) -> TruthDecision {
        let node = match graph.nodes.get(chunk_id) {
            Some(n) => n,
            None => return TruthDecision::Rejected,
        };

        let node_trust = trust.get(&node.node_id);
        let entropy = trust.global_entropy;

        let decision = if node_trust > self.trust_threshold && entropy < self.max_entropy {
            TruthDecision::Verified
        } else if node_trust > 0.6 {
            TruthDecision::NeedsRevalidation
        } else if node_trust > 0.3 {
            TruthDecision::Quarantined
        } else {
            TruthDecision::Rejected
        };

        self.history.push(AdjudicationRecord {
            chunk_id: chunk_id.clone(),
            decision,
            avg_trust: node_trust,
            entropy,
            timestamp: Timestamp::now(),
        });

        decision
    }

    /// Get recent adjudication history
    pub fn recent_decisions(&self, count: usize) -> &[AdjudicationRecord] {
        let start = self.history.len().saturating_sub(count);
        &self.history[start..]
    }
}

impl Default for LocalMotherbrain {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_local_motherbrain_creation() {
        let mb = LocalMotherbrain::new();
        assert_eq!(mb.history.len(), 0);
    }

    #[test]
    fn test_adjudication() {
        let mut mb = LocalMotherbrain::new();
        let graph = CausalityGraph::new();
        let trust = TrustKernel::new();

        let decision = mb.adjudicate(&graph, &trust);

        // Empty trust should be rejected
        assert_eq!(decision, TruthDecision::Rejected);
    }
}
