//! BKG Motherbrain Module
//!
//! Final adjudication layer for truth decisions.

pub mod global;
pub mod local;

pub use global::{FederatedNode, GlobalAdjudication, GlobalConsensus, GlobalMotherbrain};
pub use local::{AdjudicationRecord, LocalMotherbrain, TruthDecision};
