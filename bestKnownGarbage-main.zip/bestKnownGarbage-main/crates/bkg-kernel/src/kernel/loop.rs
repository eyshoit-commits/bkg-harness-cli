//! BKG Kernel Loop
//!
//! The heart of the BKG system - a closed-loop scientific runtime
//! that integrates causality, trust, replay, WASM, and swarm validation.

use crate::causality::cve_map::CveDiffusionEngine;
use crate::causality::graph::{CausalEdge, CausalityGraph, FailureEvent, Relation};
use crate::core::types::NodeId;
use crate::core::*;
use crate::evolution::MotherbrainEvolutionLoop;
use crate::mesh::MeshSync;
use crate::model::{BkgModel, DefenseLoop};
use crate::motherbrain::{GlobalMotherbrain, LocalMotherbrain, TruthDecision};
use crate::ral::{RealityAnchor, RealityShockDetector, RealityValidator, TruthPressureField};
use crate::replay::ReplayEngine;
use crate::scheduler::{SwarmScheduler, ValidationStrategy};
use crate::trust::TrustKernel;
use crate::trust_engine::TrustEngine;
use crate::trust_engine::hero_daemon::HeroDaemon;
use crate::trust_field_kernel::{ExecutionProof, TemporalTruth};
use crate::wasm::{WasmModule, WasmRuntime};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;
use tokio::spawn;
use tracing;

/// Full kernel state integrating all components
#[derive(Debug)]
pub struct KernelState {
    /// Causality graph
    pub causality: CausalityGraph,
    /// Trust kernel
    pub trust: TrustKernel,
    /// Trust engine (scoring + escalation)
    pub trust_engine: Arc<TrustEngine>,
    /// WASM runtime
    pub wasm: WasmRuntime,
    /// Replay engine
    pub replay: ReplayEngine,
    /// Swarm scheduler
    pub swarm: SwarmScheduler,
    /// Local Motherbrain
    pub local_mb: LocalMotherbrain,
    /// Global Motherbrain
    pub global_mb: GlobalMotherbrain,
    /// Mesh sync
    pub mesh: MeshSync,
    /// Evolution loop
    pub evolution: MotherbrainEvolutionLoop,
    /// Model defense
    pub defense: DefenseLoop,
    /// Reality anchor
    pub reality: RealityAnchor,
    /// Shock detector
    pub shock_detector: RealityShockDetector,
    /// Truth pressure
    pub truth_pressure: TruthPressureField,
    /// CVE engine
    pub cve_engine: CveDiffusionEngine,
    /// Execution receipts
    pub receipts: HashMap<String, ExecutionReceipt>,
    /// Temporal truths
    pub temporal_truths: HashMap<ChunkId, TemporalTruth>,
    /// Kernel statistics
    pub stats: KernelStats,
    /// Background trust daemon (optional, started via initialize).
    pub hero_daemon: Option<HeroDaemon>,
}

/// Execution receipt with full context
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionReceipt {
    /// Receipt identifier
    pub receipt_id: String,
    /// Chunk identifier
    pub chunk_id: ChunkId,
    /// Node identifier
    pub node_id: NodeId,
    /// Execution output hash
    pub output_hash: Hash,
    /// Environment hash
    pub env_hash: Hash,
    /// Deterministic score
    pub deterministic_score: f32,
    /// Execution time in ms
    pub execution_time_ms: u64,
    /// Success flag
    pub success: bool,
    /// Timestamp
    pub timestamp: Timestamp,
    /// Execution proof
    pub proof: ExecutionProof,
}

/// Kernel statistics
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct KernelStats {
    /// Total ticks
    pub ticks: u64,
    /// Total receipts processed
    pub receipts_processed: u64,
    /// Total failures detected
    pub failures_detected: u64,
    /// Total replays performed
    pub replays_performed: u64,
    /// Total swarm validations
    pub swarm_validations: u64,
    /// Evolution epochs
    pub evolution_epochs: u64,
    /// Reality violations
    pub reality_violations: u64,
}

impl KernelState {
    /// Create a new kernel state
    pub fn new() -> Self {
        Self {
            causality: CausalityGraph::new(),
            trust: TrustKernel::new(),
            trust_engine: Arc::new(TrustEngine::new(0.8)),
            wasm: WasmRuntime::new(),
            replay: ReplayEngine::new(),
            swarm: SwarmScheduler::new(),
            local_mb: LocalMotherbrain::new(),
            global_mb: GlobalMotherbrain::new(),
            mesh: MeshSync::new(),
            evolution: MotherbrainEvolutionLoop::new(),
            defense: DefenseLoop::new(),
            reality: RealityAnchor::new(),
            shock_detector: RealityShockDetector::new(),
            truth_pressure: TruthPressureField::new(),
            cve_engine: CveDiffusionEngine::new(),
            receipts: HashMap::new(),
            temporal_truths: HashMap::new(),
            stats: KernelStats::default(),
            hero_daemon: None,
        }
    }

    /// Initialize the kernel: start mesh, wire trust → mesh, start HeroDaemon.
    pub fn initialize(&mut self, local_node_id: NodeId, daemon_interval: Duration) {
        // 1. Start mesh transport & gossip
        self.mesh.initialize(local_node_id.clone());

        // 2. Wire trust engine → mesh (trust updates propagate via gossip)
        if let Some(mesh_node) = self.mesh.node() {
            let engine = TrustEngine::with_mesh(0.8, mesh_node);
            self.trust_engine = Arc::new(engine);
        }

        // 3. Start HeroDaemon in background (scan nodes, promote/demote)
        let daemon = HeroDaemon::new(self.trust_engine.clone(), daemon_interval);
        daemon.start();
        self.hero_daemon = Some(daemon);

        tracing::info!(
            "kernel: initialized node {} (daemon interval={:?})",
            local_node_id,
            daemon_interval
        );
    }

    /// Single kernel tick - the main execution loop
    pub fn tick(&mut self) {
        self.stats.ticks += 1;

        // 1. Collect new receipts
        let new_receipts = self.collect_receipts();

        // 2. Update causality graph
        self.causality.ingest_receipts(&new_receipts);

        // 3. Recompute trust field
        self.trust.recompute(&self.causality);

        // 4. Detect failures
        let failures = self.causality.detect_failures();
        self.stats.failures_detected += failures.len() as u64;

        // 5. Trigger replay for unstable nodes
        self.replay_failed_nodes(&failures);

        // 6. Propagate CVE risks
        self.propagate_risks();

        // 7. Evaluate swarm validation
        self.swarm.evaluate(&self.trust);
        self.stats.swarm_validations += self.swarm.active_jobs.len() as u64;

        // 8. Check reality anchor
        self.check_reality();

        // 9. Commit stable state
        self.commit_stable_state();

        // 10. Update global state metrics
        self.update_global_state();

        // 11. Asynchronously update trust engine from receipts (fire-and-forget)
        let engine = self.trust_engine.clone();
        let receipts = new_receipts; // move into task
        spawn(async move {
            // Group receipts by node_id
            let mut by_node: HashMap<NodeId, Vec<ExecutionReceipt>> = HashMap::new();
            for r in receipts {
                by_node.entry(r.node_id.clone()).or_default().push(r);
            }
            for (n_id, recs) in by_node {
                if let Err(e) = engine.update_node_trust(n_id.clone(), recs).await {
                    tracing::warn!("Trust update failed for {}: {}", n_id, e);
                }
            }
        });
    }

    /// Collect execution receipts
    fn collect_receipts(&mut self) -> Vec<ExecutionReceipt> {
        // In real implementation, this would pull from event queue
        Vec::new()
    }

    /// Ingest a receipt into the kernel
    pub fn ingest_receipt(&mut self, receipt: ExecutionReceipt) {
        self.stats.receipts_processed += 1;

        // Store receipt
        self.receipts
            .insert(receipt.receipt_id.clone(), receipt.clone());

        // Add to causality graph
        let edge = CausalEdge {
            from: receipt.chunk_id.clone(),
            to: receipt.receipt_id.clone(),
            weight: receipt.deterministic_score,
            confidence: receipt.deterministic_score,
            relation: Relation::Derived,
            timestamp: receipt.timestamp,
        };
        self.causality.add_edge(edge);

        // Update trust
        self.trust
            .update(receipt.node_id.clone(), receipt.deterministic_score);

        // Create temporal truth tracker
        let temporal = self
            .temporal_truths
            .entry(receipt.chunk_id.clone())
            .or_insert_with(|| TemporalTruth::new(receipt.chunk_id.clone()));
        temporal.add_truth_point(
            receipt.success,
            receipt.deterministic_score,
            receipt.env_hash.clone(),
        );

        // Create execution snapshot for replay
        let snapshot = self.wasm.create_snapshot(
            &receipt.chunk_id,
            &[],
            receipt.output_hash.clone(),
            receipt.env_hash,
        );
        self.replay.store_snapshot(snapshot);
    }

    /// Replay failed nodes
    fn replay_failed_nodes(&mut self, failures: &[FailureEvent]) {
        for failure in failures {
            // Downgrade trust
            self.trust.penalize(&failure.node_id, failure.severity);

            // Trigger replay validation
            self.stats.replays_performed += 1;

            // Trigger swarm validation if needed
            if failure.severity > 0.5 {
                self.swarm.spawn_validation_swarm(
                    failure.node_id.clone(),
                    vec![failure.chunk_id.clone()],
                    ValidationStrategy::Emergency,
                );
            }
        }
    }

    /// Propagate risks through causality graph
    fn propagate_risks(&mut self) {
        for chunk_id in self.causality.high_risk_chunks.clone() {
            self.causality.diffuse_risk(&chunk_id, 0.1);
        }
    }

    /// Check reality anchor
    fn check_reality(&mut self) {
        let predicted = self.trust.global_entropy;
        let observed = self.reality.compute_external_signal();

        // Update truth pressure
        let divergence = (predicted - observed).abs();
        self.truth_pressure.update(divergence, observed);

        // Check for reality violations
        let validator = RealityValidator::new();
        let verdict = validator.validate_with_anchor(&self.reality, predicted, observed);

        if verdict == crate::ral::RealityVerdict::Violation {
            self.stats.reality_violations += 1;

            // Trigger reality shock response
            self.handle_reality_violation(divergence);
        }

        // Detect shocks
        self.shock_detector.observe(predicted);
        if self.shock_detector.detect_shock() {
            self.handle_reality_shock();
        }
    }

    /// Handle reality violation
    fn handle_reality_violation(&mut self, divergence: f32) {
        // Quarantine affected nodes
        for node_id in self.trust.low_trust_nodes() {
            self.swarm.spawn_validation_swarm(
                node_id.clone(),
                vec![],
                ValidationStrategy::Emergency,
            );
        }

        // Consider evolution rollback if divergence is severe
        if divergence > 0.5 {
            self.evolution.force_rollback();
        }
    }

    /// Handle reality shock
    fn handle_reality_shock(&mut self) {
        // Force recalibration
        crate::ral::RealityCalibration::hard_reset(&mut self.reality, 0.5);

        // Reset trust for highly volatile nodes
        // Collect unstable node IDs to avoid borrowing conflict
        let unstable_ids: Vec<NodeId> = self.trust.unstable_nodes().into_iter().cloned().collect();
        for node_id in &unstable_ids {
            self.trust.penalize(node_id, 0.5);
        }

        // Trigger full swarm validation
        for node_id in self.trust.scores.keys() {
            self.swarm.spawn_validation_swarm(
                node_id.clone(),
                vec![],
                ValidationStrategy::FullReplay,
            );
        }
    }

    /// Commit stable state to ledger
    fn commit_stable_state(&mut self) {
        // Check if we can commit
        let decision = self.local_mb.adjudicate(&self.causality, &self.trust);

        if decision == TruthDecision::Verified {
            // State is stable, can commit
            // In real implementation, this would persist to ledger
        }
    }

    /// Update global state metrics
    fn update_global_state(&mut self) {
        // Compute entropy
        self.causality.compute_entropy();

        // Update global trust
        self.global_mb.compute_global_trust();
    }

    /// Run continuous kernel loop
    pub fn run(&mut self, max_ticks: Option<u64>) {
        let target = max_ticks.unwrap_or(u64::MAX);

        while self.stats.ticks < target {
            self.tick();

            // Check for system collapse
            if self.truth_pressure.collapse_risk() {
                self.handle_collapse_risk();
            }
        }
    }

    /// Handle collapse risk
    fn handle_collapse_risk(&mut self) {
        // Emergency recalibration
        crate::ral::RealityCalibration::hard_reset(&mut self.reality, 1.0);

        // Reset trust kernel
        for node_id in self.trust.scores.keys().cloned().collect::<Vec<_>>() {
            self.trust.update(node_id, 0.5);
        }

        // Clear high-risk chunks
        self.causality.high_risk_chunks.clear();
    }

    /// Register a WASM module
    pub fn register_module(&mut self, module: WasmModule) {
        self.wasm.register_module(module);
    }

    /// Submit a model for verification
    pub fn submit_model(&mut self, model: BkgModel) -> bool {
        let result = self.defense.guard.verify_model(&model);

        if result.accepted {
            self.defense
                .guard
                .register_receipt(&model.model_id, &model.weights_hash);
        }

        result.accepted
    }

    /// Get system health score
    pub fn health_score(&self) -> f32 {
        let trust_avg = if self.trust.scores.is_empty() {
            1.0
        } else {
            self.trust.scores.values().sum::<f32>() / self.trust.scores.len() as f32
        };

        let entropy_factor = 1.0 - self.causality.global_entropy;
        let pressure_factor = self.truth_pressure.pressure.clamp(0.0, 1.0);
        let reality_factor = self.reality.anchor_strength;

        trust_avg * 0.3 + entropy_factor * 0.2 + pressure_factor * 0.2 + reality_factor * 0.3
    }
}

impl Default for KernelState {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_kernel_state_creation() {
        let state = KernelState::new();
        assert_eq!(state.stats.ticks, 0);
    }

    #[tokio::test]
    async fn test_kernel_tick() {
        let mut state = KernelState::new();
        state.tick();

        assert_eq!(state.stats.ticks, 1);
    }

    #[test]
    fn test_receipt_ingestion() {
        let mut state = KernelState::new();

        let receipt = ExecutionReceipt {
            receipt_id: "receipt_1".into(),
            chunk_id: "chunk_1".into(),
            node_id: "node_1".into(),
            output_hash: "hash".into(),
            env_hash: "env".into(),
            deterministic_score: 0.95,
            execution_time_ms: 100,
            success: true,
            timestamp: Timestamp::now(),
            proof: ExecutionProof::new("input".into(), "env".into(), "output".into(), 0.95),
        };

        state.ingest_receipt(receipt);

        assert_eq!(state.stats.receipts_processed, 1);
        assert!(state.receipts.contains_key("receipt_1"));
    }

    #[test]
    fn test_health_score() {
        let state = KernelState::new();
        let score = state.health_score();

        assert!((0.0..=1.0).contains(&score));
    }

    #[test]
    fn test_model_submission() {
        let mut state = KernelState::new();

        let model = BkgModel {
            model_id: "model_1".into(),
            weights_hash: "hash".into(),
            architecture_hash: "arch".into(),
            trust_score: 0.9,
            stability_index: 0.95,
            reproducibility_index: 0.92,
            parent_models: vec![],
            derived_from_chunks: vec!["chunk_1".into()],
            guard_profile: Default::default(),
            mesh_signature: Signature::new("sig"),
            created_at: Timestamp::now(),
            metadata: HashMap::new(),
        };

        let accepted = state.submit_model(model);

        assert!(accepted);
    }
}
