//! Stale Branch Detection — detects and manages stale conversation branches.
//!
//! Tracks branching factor, depth, and staleness heuristics to detect
//! conversation forks that have gone stale and should be pruned.

use std::collections::BTreeMap;
use std::time::{Duration, SystemTime};

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────

/// Unique identifier for a conversation branch node.
pub type BranchId = u64;

/// Depth in the branch tree (root = 0).
pub type BranchDepth = u32;

/// Configuration for stale branch detection.
#[derive(Debug, Clone)]
pub struct StaleConfig {
    /// Maximum allowed depth before a branch is considered stale.
    pub max_depth: BranchDepth,
    /// Age (seconds) after which a branch with no activity is stale.
    pub max_idle_secs: u64,
    /// Maximum number of sibling branches before staleness kicks in.
    pub max_sibling_count: u32,
    /// Whether to auto-prune stale branches.
    pub auto_prune: bool,
    /// Grace period (seconds) before a branch is actually removed.
    pub grace_period_secs: u64,
}

impl Default for StaleConfig {
    fn default() -> Self {
        Self {
            max_depth: 5,
            max_idle_secs: 300, // 5 minutes
            max_sibling_count: 3,
            auto_prune: false,
            grace_period_secs: 60,
        }
    }
}

/// Status of a branch.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BranchStatus {
    /// Branch is active and should be kept.
    Active,
    /// Branch is stale (exceeds depth or idle limits).
    Stale,
    /// Branch is scheduled for pruning (after grace period).
    ScheduledForPrune,
    /// Branch has been pruned.
    Pruned,
}

/// A node in the branch tree.
#[derive(Debug, Clone)]
pub struct BranchNode {
    /// Unique branch identifier.
    pub id: BranchId,
    /// Parent branch ID (None for root).
    pub parent: Option<BranchId>,
    /// Depth from root.
    pub depth: BranchDepth,
    /// Timestamp of last activity.
    pub last_activity: SystemTime,
    /// Current status.
    pub status: BranchStatus,
    /// Reason for staleness (if applicable).
    pub stale_reason: Option<String>,
}

/// Result of a staleness check.
#[derive(Debug, Clone)]
pub struct StalenessResult {
    /// All branches that are stale.
    pub stale_branches: Vec<BranchId>,
    /// All branches scheduled for pruning.
    pub scheduled: Vec<BranchId>,
    /// Total branch count.
    pub total_branches: usize,
    /// Maximum depth observed.
    pub max_depth_observed: BranchDepth,
    /// Average sibling count.
    pub avg_sibling_count: f64,
}

// ──────────────────────────────────────────────
// Branch Tree
// ──────────────────────────────────────────────

/// A tree structure maintaining conversation branches.
#[derive(Debug, Clone)]
pub struct BranchTree {
    /// All branches indexed by ID.
    branches: BTreeMap<BranchId, BranchNode>,
    /// Next branch ID to assign.
    next_id: BranchId,
    /// Configuration for staleness detection.
    config: StaleConfig,
}

impl BranchTree {
    /// Create a new branch tree with a root node.
    #[must_use]
    pub fn new() -> Self {
        let mut branches = BTreeMap::new();
        branches.insert(
            0,
            BranchNode {
                id: 0,
                parent: None,
                depth: 0,
                last_activity: SystemTime::now(),
                status: BranchStatus::Active,
                stale_reason: None,
            },
        );
        Self {
            branches,
            next_id: 1,
            config: StaleConfig::default(),
        }
    }

    /// Create a branch tree with custom config.
    #[must_use]
    pub fn with_config(config: StaleConfig) -> Self {
        let mut tree = Self::new();
        tree.config = config;
        tree
    }

    /// Fork a new branch from an existing branch.
    pub fn fork(&mut self, parent_id: BranchId) -> Option<BranchId> {
        let parent = self.branches.get(&parent_id)?;
        if parent.status == BranchStatus::Pruned {
            return None;
        }

        let id = self.next_id;
        self.next_id += 1;

        self.branches.insert(
            id,
            BranchNode {
                id,
                parent: Some(parent_id),
                depth: parent.depth + 1,
                last_activity: SystemTime::now(),
                status: BranchStatus::Active,
                stale_reason: None,
            },
        );
        Some(id)
    }

    /// Mark a branch as active (reset idle timer).
    pub fn touch(&mut self, branch_id: BranchId) {
        if let Some(branch) = self.branches.get_mut(&branch_id) {
            branch.last_activity = SystemTime::now();
            branch.status = BranchStatus::Active;
        }
    }

    /// Get the branch's status.
    #[must_use]
    pub fn status(&self, branch_id: BranchId) -> Option<BranchStatus> {
        self.branches.get(&branch_id).map(|b| b.status)
    }

    /// Get the depth of a branch.
    #[must_use]
    pub fn depth(&self, branch_id: BranchId) -> Option<BranchDepth> {
        self.branches.get(&branch_id).map(|b| b.depth)
    }

    /// Get a reference to a branch node.
    #[must_use]
    pub fn get(&self, branch_id: BranchId) -> Option<&BranchNode> {
        self.branches.get(&branch_id)
    }

    /// Count total branches.
    #[must_use]
    pub fn total_branches(&self) -> usize {
        self.branches.len()
    }

    /// Get the config.
    #[must_use]
    pub fn config(&self) -> &StaleConfig {
        &self.config
    }

    /// Get mutable reference to config.
    pub fn config_mut(&mut self) -> &mut StaleConfig {
        &mut self.config
    }

    /// Run staleness detection. Returns results with stale branches.
    #[must_use]
    pub fn detect_stale(&self) -> StalenessResult {
        let mut stale = Vec::new();
        let mut scheduled = Vec::new();
        let now = SystemTime::now();

        let total_branches = self.branches.len();
        let mut max_depth: BranchDepth = 0;

        // Count siblings per parent
        let mut sibling_counts: BTreeMap<Option<BranchId>, u32> = BTreeMap::new();
        for branch in self.branches.values() {
            *sibling_counts.entry(branch.parent).or_insert(0) += 1;
        }

        for branch in self.branches.values() {
            if branch.status == BranchStatus::Pruned
                || branch.status == BranchStatus::ScheduledForPrune
            {
                continue;
            }

            max_depth = max_depth.max(branch.depth);

            let mut reasons: Vec<String> = Vec::new();

            // Check depth limit
            if branch.depth > self.config.max_depth {
                reasons.push(format!(
                    "depth {} exceeds max {}",
                    branch.depth, self.config.max_depth
                ));
            }

            // Check idle time
            let idle = now
                .duration_since(branch.last_activity)
                .unwrap_or(Duration::ZERO);
            if idle.as_secs() > self.config.max_idle_secs {
                reasons.push(format!(
                    "idle {}s exceeds max {}s",
                    idle.as_secs(),
                    self.config.max_idle_secs
                ));
            }

            // Check sibling count
            let sibling_count = sibling_counts.get(&branch.parent).copied().unwrap_or(0);
            if sibling_count > self.config.max_sibling_count {
                reasons.push(format!(
                    "sibling count {} exceeds max {}",
                    sibling_count, self.config.max_sibling_count
                ));
            }

            if !reasons.is_empty() {
                stale.push(branch.id);
                if self.config.auto_prune {
                    scheduled.push(branch.id);
                }
            }
        }

        let avg_sibling = if total_branches > 0 {
            sibling_counts.values().copied().sum::<u32>() as f64 / sibling_counts.len() as f64
        } else {
            0.0
        };

        StalenessResult {
            stale_branches: stale,
            scheduled,
            total_branches,
            max_depth_observed: max_depth,
            avg_sibling_count: avg_sibling,
        }
    }

    /// Prune a branch (mark as Pruned).
    pub fn prune(&mut self, branch_id: BranchId) -> bool {
        if let Some(branch) = self.branches.get_mut(&branch_id) {
            branch.status = BranchStatus::Pruned;
            true
        } else {
            false
        }
    }

    /// Schedule a branch for pruning (marks as ScheduledForPrune).
    pub fn schedule_prune(&mut self, branch_id: BranchId) -> bool {
        if let Some(branch) = self.branches.get_mut(&branch_id) {
            branch.status = BranchStatus::ScheduledForPrune;
            branch.stale_reason = Some("scheduled for pruning".into());
            true
        } else {
            false
        }
    }

    /// Execute pending prunes (move ScheduledForPrune → Pruned).
    pub fn execute_pending_prunes(&mut self) -> usize {
        let ids: Vec<BranchId> = self
            .branches
            .iter()
            .filter(|(_, b)| b.status == BranchStatus::ScheduledForPrune)
            .map(|(id, _)| *id)
            .collect();

        let count = ids.len();
        for id in ids {
            self.prune(id);
        }
        count
    }
}

impl Default for BranchTree {
    fn default() -> Self {
        Self::new()
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_tree_has_root() {
        let tree = BranchTree::new();
        assert_eq!(tree.total_branches(), 1);
        assert_eq!(tree.depth(0), Some(0));
    }

    #[test]
    fn fork_creates_branch() {
        let mut tree = BranchTree::new();
        let branch_id = tree.fork(0).unwrap();
        assert_eq!(tree.depth(branch_id), Some(1));
        assert_eq!(tree.status(branch_id), Some(BranchStatus::Active));
    }

    #[test]
    fn cannot_fork_from_pruned() {
        let mut tree = BranchTree::new();
        tree.prune(0);
        assert!(tree.fork(0).is_none());
    }

    #[test]
    fn touch_resets_idle() {
        let mut tree = BranchTree::new();

        // Create a branch with very short timeout
        tree.config.max_idle_secs = 3600; // 1 hour
        let branch_id = tree.fork(0).unwrap();

        // Touch it to reset idle timer
        tree.touch(branch_id);
        assert_eq!(tree.status(branch_id), Some(BranchStatus::Active));
    }

    #[test]
    fn detect_stale_by_depth() {
        let mut tree = BranchTree::new();
        tree.config.max_depth = 0; // Only root allowed

        let child = tree.fork(0).unwrap();
        let result = tree.detect_stale();
        assert!(result.stale_branches.contains(&child));
    }

    #[test]
    fn prune_marks_as_pruned() {
        let mut tree = BranchTree::new();
        let branch = tree.fork(0).unwrap();
        assert!(tree.prune(branch));
        assert_eq!(tree.status(branch), Some(BranchStatus::Pruned));
    }

    #[test]
    fn execute_pending_prunes() {
        let mut tree = BranchTree::new();
        let branch = tree.fork(0).unwrap();
        tree.config.auto_prune = true;

        // Mark as stale and schedule
        tree.schedule_prune(branch);
        assert_eq!(tree.execute_pending_prunes(), 1);
        assert_eq!(tree.status(branch), Some(BranchStatus::Pruned));
    }

    #[test]
    fn stale_detection_with_sibling_limit() {
        let mut tree = BranchTree::new();
        tree.config.max_sibling_count = 1; // Only 1 sibling allowed

        // Create 3 siblings
        let _a = tree.fork(0).unwrap();
        let _b = tree.fork(0).unwrap();
        let c = tree.fork(0).unwrap();

        let result = tree.detect_stale();
        assert!(result.stale_branches.contains(&c));
    }

    #[test]
    fn avg_sibling_count() {
        let mut tree = BranchTree::new();
        // Fork 2 from root
        let _a = tree.fork(0).unwrap();
        let _b = tree.fork(0).unwrap();
        // Fork 2 from a
        let a = _a;
        let _c = tree.fork(a).unwrap();
        let _d = tree.fork(a).unwrap();

        let result = tree.detect_stale();
        assert_eq!(result.total_branches, 5); // root + 2 + 2
        assert!(result.avg_sibling_count > 0.0);
    }

    #[test]
    fn schedule_prune_then_execute() {
        let mut tree = BranchTree::new();
        let branch = tree.fork(0).unwrap();
        assert!(tree.schedule_prune(branch));
        assert_eq!(tree.status(branch), Some(BranchStatus::ScheduledForPrune));
        assert_eq!(tree.execute_pending_prunes(), 1);
        assert_eq!(tree.status(branch), Some(BranchStatus::Pruned));
    }

    #[test]
    fn stale_result_fields() {
        let mut tree = BranchTree::new();
        let _a = tree.fork(0).unwrap();
        let _b = tree.fork(0).unwrap();
        let result = tree.detect_stale();
        assert_eq!(result.total_branches, 3);
        assert!(result.max_depth_observed >= 1);
    }
}
