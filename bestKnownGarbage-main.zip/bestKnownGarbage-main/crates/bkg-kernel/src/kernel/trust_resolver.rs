//! Trust Resolver — validates and resolves trust levels for worker-to-worker
//! and worker-to-orchestrator communication within the mesh.
//!
//! Trust is a typed capability system. Each worker declares its capabilities,
//! and the resolver validates whether a caller has sufficient trust to invoke
//! a given capability on a target.

use std::collections::{BTreeMap, BTreeSet};

// ──────────────────────────────────────────────
// Trust Levels
// ──────────────────────────────────────────────

/// Trust levels in increasing order of privilege.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum TrustLevel {
    /// Unauthenticated / anonymous — minimal trust.
    Anonymous,
    /// Observer — can read public state.
    Observer,
    /// Participant — can propose work.
    Participant,
    /// Operator — can manage other workers.
    Operator,
    /// Admin — full control.
    Admin,
}

impl TrustLevel {
    /// Check if this level is at least `required`.
    #[must_use]
    pub fn satisfies(&self, required: TrustLevel) -> bool {
        *self >= required
    }

    /// Get the string representation.
    #[must_use]
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Anonymous => "anonymous",
            Self::Observer => "observer",
            Self::Participant => "participant",
            Self::Operator => "operator",
            Self::Admin => "admin",
        }
    }
}

/// Identity of a worker in the mesh.
pub type WorkerId = String;

/// A capability that a worker can perform.
pub type Capability = String;

/// A trust certificate issued to a worker.
#[derive(Debug, Clone)]
pub struct TrustCertificate {
    /// The worker this certificate is issued to.
    pub worker_id: WorkerId,
    /// The trust level granted.
    pub level: TrustLevel,
    /// Capabilities scoped to this certificate.
    pub capabilities: BTreeSet<Capability>,
    /// Issuing authority.
    pub issuer: String,
    /// Whether this certificate has been revoked.
    pub revoked: bool,
}

impl TrustCertificate {
    /// Create a new trust certificate.
    #[must_use]
    pub fn new(
        worker_id: impl Into<String>,
        level: TrustLevel,
        capabilities: BTreeSet<Capability>,
        issuer: impl Into<String>,
    ) -> Self {
        Self {
            worker_id: worker_id.into(),
            level,
            capabilities,
            issuer: issuer.into(),
            revoked: false,
        }
    }

    /// Check if this certificate grants a specific capability.
    #[must_use]
    pub fn can(&self, capability: &str) -> bool {
        !self.revoked && self.capabilities.contains(capability)
    }

    /// Revoke this certificate.
    pub fn revoke(&mut self) {
        self.revoked = true;
    }
}

// ──────────────────────────────────────────────
// Trust Resolver
// ──────────────────────────────────────────────

/// Resolution of a trust check.
#[derive(Debug, Clone)]
pub struct TrustResolution {
    /// Whether the operation is permitted.
    pub permitted: bool,
    /// The trust level of the caller.
    pub caller_level: TrustLevel,
    /// The required trust level.
    pub required_level: TrustLevel,
    /// Reason for denial (if not permitted).
    pub reason: Option<String>,
}

/// The trust resolver — validates inter-worker trust relationships.
#[derive(Debug, Clone)]
pub struct TrustResolver {
    /// Registered certificates indexed by worker ID.
    certificates: BTreeMap<WorkerId, TrustCertificate>,
    /// Capability-to-minimum-trust-level mapping.
    capability_requirements: BTreeMap<Capability, TrustLevel>,
}

impl TrustResolver {
    /// Create a new empty trust resolver.
    #[must_use]
    pub fn new() -> Self {
        Self {
            certificates: BTreeMap::new(),
            capability_requirements: Self::default_requirements(),
        }
    }

    /// Default capability trust requirements.
    fn default_requirements() -> BTreeMap<Capability, TrustLevel> {
        let mut req = BTreeMap::new();
        req.insert("observe".into(), TrustLevel::Observer);
        req.insert("read_state".into(), TrustLevel::Observer);
        req.insert("propose_work".into(), TrustLevel::Participant);
        req.insert("execute".into(), TrustLevel::Participant);
        req.insert("manage_workers".into(), TrustLevel::Operator);
        req.insert("deploy".into(), TrustLevel::Operator);
        req.insert("shutdown".into(), TrustLevel::Admin);
        req.insert("reconfigure".into(), TrustLevel::Admin);
        req
    }

    /// Register a trust certificate for a worker.
    pub fn register(&mut self, certificate: TrustCertificate) -> Result<(), TrustError> {
        let id = certificate.worker_id.clone();
        if self.certificates.contains_key(&id) {
            return Err(TrustError::AlreadyRegistered(id));
        }
        self.certificates.insert(id, certificate);
        Ok(())
    }

    /// Get a certificate by worker ID.
    #[must_use]
    pub fn get(&self, worker_id: &str) -> Option<&TrustCertificate> {
        self.certificates.get(worker_id)
    }

    /// Get mutable reference to a certificate.
    #[must_use]
    pub fn get_mut(&mut self, worker_id: &str) -> Option<&mut TrustCertificate> {
        self.certificates.get_mut(worker_id)
    }

    /// Revoke all certificates for a worker.
    pub fn revoke(&mut self, worker_id: &str) -> bool {
        if let Some(cert) = self.certificates.get_mut(worker_id) {
            cert.revoke();
            true
        } else {
            false
        }
    }

    /// Remove a worker's certificate entirely.
    pub fn remove(&mut self, worker_id: &str) -> bool {
        self.certificates.remove(worker_id).is_some()
    }

    /// Resolve whether `caller` is trusted to invoke `capability`.
    #[must_use]
    pub fn resolve(&self, caller: &str, capability: &str) -> TrustResolution {
        let required_level = self
            .capability_requirements
            .get(capability)
            .copied()
            .unwrap_or(TrustLevel::Admin);

        let caller_cert = match self.certificates.get(caller) {
            Some(c) => c,
            None => {
                return TrustResolution {
                    permitted: false,
                    caller_level: TrustLevel::Anonymous,
                    required_level,
                    reason: Some(format!("worker '{caller}' has no trust certificate")),
                };
            }
        };

        if caller_cert.revoked {
            return TrustResolution {
                permitted: false,
                caller_level: caller_cert.level,
                required_level,
                reason: Some(format!(
                    "worker '{caller}' trust certificate has been revoked"
                )),
            };
        }

        // Check trust level satisfies requirement
        if !caller_cert.level.satisfies(required_level) {
            return TrustResolution {
                permitted: false,
                caller_level: caller_cert.level,
                required_level,
                reason: Some(format!(
                    "caller trust level {:?} < required {:?}",
                    caller_cert.level, required_level
                )),
            };
        }

        // Check specific capability grant
        if !caller_cert.capabilities.contains(capability) {
            return TrustResolution {
                permitted: false,
                caller_level: caller_cert.level,
                required_level,
                reason: Some(format!("caller lacks capability '{capability}'")),
            };
        }

        TrustResolution {
            permitted: true,
            caller_level: caller_cert.level,
            required_level,
            reason: None,
        }
    }

    /// Register a custom capability requirement.
    pub fn require_capability(&mut self, capability: Capability, level: TrustLevel) {
        self.capability_requirements.insert(capability, level);
    }

    /// Check if a capability has a requirement registered.
    #[must_use]
    pub fn get_capability_requirement(&self, capability: &str) -> Option<TrustLevel> {
        self.capability_requirements.get(capability).copied()
    }

    /// List all registered workers.
    #[must_use]
    pub fn registered_workers(&self) -> impl Iterator<Item = &WorkerId> {
        self.certificates.keys()
    }

    /// Count registered workers.
    #[must_use]
    pub fn worker_count(&self) -> usize {
        self.certificates.len()
    }
}

impl Default for TrustResolver {
    fn default() -> Self {
        Self::new()
    }
}

// ──────────────────────────────────────────────
// Error Types
// ──────────────────────────────────────────────

/// Errors that can occur during trust operations.
#[derive(Debug, Clone)]
pub enum TrustError {
    /// Worker already has a registered certificate.
    AlreadyRegistered(String),
}

impl std::fmt::Display for TrustError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::AlreadyRegistered(id) => write!(f, "worker '{id}' is already registered"),
        }
    }
}

impl std::error::Error for TrustError {}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn make_cert(id: &str, level: TrustLevel, caps: &[&str], issuer: &str) -> TrustCertificate {
        TrustCertificate::new(
            id,
            level,
            caps.iter().map(|s| s.to_string()).collect(),
            issuer,
        )
    }

    #[test]
    fn anonymous_callers_are_denied() {
        let resolver = TrustResolver::new();
        let result = resolver.resolve("unknown", "observe");
        assert!(!result.permitted);
        assert_eq!(result.caller_level, TrustLevel::Anonymous);
    }

    #[test]
    fn sufficient_trust_level_permits() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("worker-1", TrustLevel::Observer, &["observe"], "admin");
        resolver.register(cert).unwrap();

        let result = resolver.resolve("worker-1", "observe");
        assert!(result.permitted);
    }

    #[test]
    fn insufficient_trust_level_denies() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("worker-1", TrustLevel::Observer, &["observe"], "admin");
        resolver.register(cert).unwrap();

        let result = resolver.resolve("worker-1", "shutdown");
        assert!(!result.permitted);
        let reason = result.reason.unwrap();
        assert!(
            reason.contains("Observer") || reason.contains("caller"),
            "reason was: {reason}"
        );
    }

    #[test]
    fn revoked_certificate_denies() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("worker-1", TrustLevel::Admin, &["shutdown"], "admin");
        resolver.register(cert).unwrap();
        resolver.revoke("worker-1");

        let result = resolver.resolve("worker-1", "shutdown");
        assert!(!result.permitted);
    }

    #[test]
    fn missing_capability_denies() {
        let mut resolver = TrustResolver::new();
        // Grant observer but not the "observe" capability
        let cert = make_cert("worker-1", TrustLevel::Observer, &[], "admin");
        resolver.register(cert).unwrap();

        let result = resolver.resolve("worker-1", "observe");
        assert!(!result.permitted);
    }

    #[test]
    fn duplicate_registration_fails() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("worker-1", TrustLevel::Observer, &["observe"], "admin");
        resolver.register(cert).unwrap();

        let cert2 = make_cert("worker-1", TrustLevel::Admin, &["shutdown"], "admin");
        let err = resolver.register(cert2).unwrap_err();
        assert!(matches!(err, TrustError::AlreadyRegistered(_)));
    }

    #[test]
    fn register_custom_requirement() {
        let mut resolver = TrustResolver::new();
        resolver.require_capability("custom_op".into(), TrustLevel::Operator);

        assert_eq!(
            resolver.get_capability_requirement("custom_op"),
            Some(TrustLevel::Operator)
        );
    }

    #[test]
    fn trust_level_satisfies() {
        assert!(TrustLevel::Admin.satisfies(TrustLevel::Admin));
        assert!(TrustLevel::Admin.satisfies(TrustLevel::Observer));
        assert!(TrustLevel::Observer.satisfies(TrustLevel::Observer));
        assert!(!TrustLevel::Observer.satisfies(TrustLevel::Operator));
        assert!(!TrustLevel::Anonymous.satisfies(TrustLevel::Observer));
    }

    #[test]
    fn worker_count_increases() {
        let mut resolver = TrustResolver::new();
        assert_eq!(resolver.worker_count(), 0);

        let cert = make_cert("w1", TrustLevel::Observer, &["observe"], "admin");
        resolver.register(cert).unwrap();
        assert_eq!(resolver.worker_count(), 1);
    }

    #[test]
    fn remove_worker_certificate() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("w1", TrustLevel::Observer, &["observe"], "admin");
        resolver.register(cert).unwrap();
        assert!(resolver.remove("w1"));

        let result = resolver.resolve("w1", "observe");
        assert!(!result.permitted);
    }

    #[test]
    fn get_mut_and_revoke() {
        let mut resolver = TrustResolver::new();
        let cert = make_cert("w1", TrustLevel::Admin, &["shutdown"], "admin");
        resolver.register(cert).unwrap();

        let cert_mut = resolver.get_mut("w1").unwrap();
        cert_mut.revoke();
        assert!(cert_mut.revoked);
    }
}
