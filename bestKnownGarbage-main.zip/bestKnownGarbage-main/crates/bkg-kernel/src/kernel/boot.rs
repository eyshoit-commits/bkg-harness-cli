//! Worker Boot — state machine and boot controller for worker startup.
//!
//! Provides a structured boot sequence with phase tracking, health checks,
//! and escalation integration for failures.

use bkg_core::types::Timestamp;

// ──────────────────────────────────────────────
// Worker State Machine
// ──────────────────────────────────────────────

/// Status of a worker during its lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorkerStatus {
    /// Worker is being spawned.
    Spawning,
    /// Worker is initializing its subsystems.
    Initializing,
    /// Worker has passed all checks and is ready.
    Ready,
    /// Worker is actively processing work.
    Running,
    /// Worker is running but degraded.
    Degraded,
    /// Worker has permanently failed.
    Failed,
}

impl WorkerStatus {
    /// Check if this status represents a healthy state.
    #[must_use]
    pub fn is_healthy(&self) -> bool {
        matches!(self, Self::Ready | Self::Running)
    }

    /// Check if this status represents a terminal state.
    #[must_use]
    pub fn is_terminal(&self) -> bool {
        matches!(self, Self::Failed)
    }

    /// Check if transition to `next` is valid.
    #[must_use]
    pub fn can_transition_to(&self, next: Self) -> bool {
        use WorkerStatus::*;
        match (self, next) {
            (Spawning, Initializing) => true,
            (Initializing, Ready) => true,
            (Initializing, Failed) => true,
            (Ready, Running) => true,
            (Ready, Degraded) => true,
            (Running, Degraded) => true,
            (Running, Ready) => true,
            (Degraded, Ready) => true,
            (Degraded, Failed) => true,
            (_, Failed) => true, // can always fail
            _ => false,
        }
    }
}

/// Kinds of failures that can occur during boot or operation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WorkerFailureKind {
    /// Boot timed out.
    StartupTimeout,
    /// Resource limits exceeded (memory, CPU, etc.).
    ResourceExhaustion,
    /// Configuration error.
    ConfigError,
    /// Failed to bind to mesh.
    MeshBindFailure,
    /// Trust gate check failed.
    TrustGate,
}

/// Phase of the boot process.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BootPhase {
    /// Hardware capability check.
    HardwareCheck,
    /// Configuration loading.
    ConfigLoad,
    /// Mesh network join.
    MeshJoin,
    /// Trust establishment.
    TrustEstablish,
    /// Ready for work.
    ReadyForWork,
}

impl BootPhase {
    /// Get the next phase in sequence.
    #[must_use]
    pub fn next(&self) -> Option<Self> {
        use BootPhase::*;
        match self {
            HardwareCheck => Some(ConfigLoad),
            ConfigLoad => Some(MeshJoin),
            MeshJoin => Some(TrustEstablish),
            TrustEstablish => Some(ReadyForWork),
            ReadyForWork => None,
        }
    }
}

// ──────────────────────────────────────────────
// Boot Configuration
// ──────────────────────────────────────────────

/// Configuration for the boot process.
#[derive(Debug, Clone)]
pub struct BootConfig {
    /// Maximum time (seconds) for each phase before timeout.
    pub phase_timeout_secs: u64,
    /// Maximum retries per phase before failing.
    pub max_retries_per_phase: u32,
    /// Health check interval (seconds) when running.
    pub health_check_interval_secs: u64,
    /// Enable detailed event logging.
    pub enable_event_logging: bool,
}

impl Default for BootConfig {
    fn default() -> Self {
        Self {
            phase_timeout_secs: 30,
            max_retries_per_phase: 3,
            health_check_interval_secs: 5,
            enable_event_logging: true,
        }
    }
}

// ──────────────────────────────────────────────
// Worker State Machine
// ──────────────────────────────────────────────

/// A finite state machine for tracking worker lifecycle.
#[derive(Debug, Clone)]
pub struct WorkerStateMachine {
    /// Current worker status.
    status: WorkerStatus,
    /// Current boot phase.
    phase: BootPhase,
    /// Timestamp when the current status was entered.
    status_since: Timestamp,
    /// Number of failures encountered.
    failure_count: u32,
    /// Type of the last failure.
    last_failure: Option<WorkerFailureKind>,
    /// Whether the worker has ever reached Ready state.
    has_been_ready: bool,
}

impl WorkerStateMachine {
    /// Create a new state machine starting at Spawning.
    #[must_use]
    pub fn new() -> Self {
        Self {
            status: WorkerStatus::Spawning,
            phase: BootPhase::HardwareCheck,
            status_since: Timestamp::now(),
            failure_count: 0,
            last_failure: None,
            has_been_ready: false,
        }
    }

    /// Attempt a state transition. Returns error if invalid.
    pub fn transition(&mut self, new_status: WorkerStatus) -> Result<(), BootError> {
        if !self.status.can_transition_to(new_status) {
            return Err(BootError::Transition(format!(
                "Cannot transition from {:?} to {:?}",
                self.status, new_status
            )));
        }
        self.status = new_status;
        self.status_since = Timestamp::now();
        if new_status == WorkerStatus::Ready {
            self.has_been_ready = true;
        }
        Ok(())
    }

    /// Advance to the next boot phase.
    pub fn advance_phase(&mut self) -> Result<(), BootError> {
        match self.phase.next() {
            Some(next) => {
                self.phase = next;
                Ok(())
            }
            None => Err(BootError::Transition("Already at final phase".into())),
        }
    }

    /// Record a failure with the given kind.
    pub fn record_failure(&mut self, kind: WorkerFailureKind) {
        self.failure_count += 1;
        self.last_failure = Some(kind);
    }

    // ── Accessors ──

    #[must_use]
    pub fn status(&self) -> WorkerStatus {
        self.status
    }

    #[must_use]
    pub fn phase(&self) -> BootPhase {
        self.phase
    }

    #[must_use]
    pub fn is_healthy(&self) -> bool {
        self.status.is_healthy()
    }

    #[must_use]
    pub fn is_terminal(&self) -> bool {
        self.status.is_terminal()
    }

    #[must_use]
    pub fn failure_count(&self) -> u32 {
        self.failure_count
    }

    #[must_use]
    pub fn last_failure(&self) -> Option<&WorkerFailureKind> {
        self.last_failure.as_ref()
    }

    #[must_use]
    pub fn has_been_ready(&self) -> bool {
        self.has_been_ready
    }

    #[must_use]
    pub fn status_since(&self) -> Timestamp {
        self.status_since
    }
}

impl Default for WorkerStateMachine {
    fn default() -> Self {
        Self::new()
    }
}

// ──────────────────────────────────────────────
// Boot Controller
// ──────────────────────────────────────────────

/// Controller that drives the boot sequence through its phases.
#[derive(Debug, Clone)]
pub struct BootController {
    /// State machine tracking worker lifecycle.
    state: WorkerStateMachine,
    /// Boot configuration.
    config: BootConfig,
    /// Retry count for the current phase.
    current_phase_retries: u32,
    /// Timestamp when the current phase started.
    phase_started: Timestamp,
}

impl BootController {
    /// Create a new boot controller with default config.
    #[must_use]
    pub fn new() -> Self {
        Self::with_config(BootConfig::default())
    }

    /// Create a new boot controller with the given config.
    #[must_use]
    pub fn with_config(config: BootConfig) -> Self {
        Self {
            state: WorkerStateMachine::new(),
            config,
            current_phase_retries: 0,
            phase_started: Timestamp::now(),
        }
    }

    /// Start the boot sequence — transitions from Spawning to Initializing.
    pub fn start_boot(&mut self) -> Result<(), BootError> {
        self.state.transition(WorkerStatus::Initializing)?;
        self.phase_started = Timestamp::now();
        Ok(())
    }

    /// Complete the current phase and advance.
    pub fn complete_phase(&mut self) -> Result<(), BootError> {
        self.current_phase_retries = 0;
        self.state.advance_phase()?;
        self.phase_started = Timestamp::now();
        Ok(())
    }

    /// Mark the current phase as failed. Returns error if max retries exceeded.
    pub fn fail_phase(&mut self, kind: WorkerFailureKind) -> Result<(), BootError> {
        self.current_phase_retries += 1;
        self.state.record_failure(kind);

        if self.current_phase_retries >= self.config.max_retries_per_phase {
            self.state.transition(WorkerStatus::Failed)?;
            return Err(BootError::Failed(format!(
                "Phase {:?} failed after {} retries",
                self.state.phase(),
                self.current_phase_retries
            )));
        }
        Ok(())
    }

    /// Complete the entire boot sequence — transitions to Ready.
    pub fn finish_boot(&mut self) -> Result<(), BootError> {
        if self.state.phase() != BootPhase::ReadyForWork {
            return Err(BootError::Transition(format!(
                "Cannot finish boot in phase {:?}",
                self.state.phase()
            )));
        }
        self.state.transition(WorkerStatus::Ready)?;
        Ok(())
    }

    /// Check if the current phase has timed out.
    #[must_use]
    pub fn is_current_phase_timed_out(&self) -> bool {
        let elapsed = Timestamp::now().0.saturating_sub(self.phase_started.0) / 1000;
        elapsed > self.config.phase_timeout_secs
    }

    /// Run a health check. Returns true if healthy.
    #[must_use]
    pub fn health_check(&self) -> bool {
        self.state.is_healthy()
    }

    /// Transition to Running state (post-boot).
    pub fn start_work(&mut self) -> Result<(), BootError> {
        self.state.transition(WorkerStatus::Running)
    }

    /// Transition to Degraded state.
    pub fn degrade(&mut self) -> Result<(), BootError> {
        self.state.transition(WorkerStatus::Degraded)
    }

    /// Transition to Failed state.
    pub fn fail(&mut self, kind: WorkerFailureKind) -> Result<(), BootError> {
        self.state.record_failure(kind);
        self.state.transition(WorkerStatus::Failed)
    }

    // ── Accessors ──

    #[must_use]
    pub fn state(&self) -> &WorkerStateMachine {
        &self.state
    }

    #[must_use]
    pub fn config(&self) -> &BootConfig {
        &self.config
    }

    #[must_use]
    pub fn phase_retries(&self) -> u32 {
        self.current_phase_retries
    }
}

impl Default for BootController {
    fn default() -> Self {
        Self::new()
    }
}

// ──────────────────────────────────────────────
// Error Types
// ──────────────────────────────────────────────

/// Errors that can occur during boot.
#[derive(Debug, Clone)]
pub enum BootError {
    /// Invalid state transition.
    Transition(String),
    /// A phase timed out.
    Timeout(String),
    /// Boot permanently failed.
    Failed(String),
}

impl std::fmt::Display for BootError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Transition(msg) => write!(f, "boot transition error: {msg}"),
            Self::Timeout(msg) => write!(f, "boot timeout: {msg}"),
            Self::Failed(msg) => write!(f, "boot failed: {msg}"),
        }
    }
}

impl std::error::Error for BootError {}

// ──────────────────────────────────────────────
// Event helpers
// ──────────────────────────────────────────────

// Event builder helpers are available via bkg_events::EventBuilder.
// Usage: EventBuilder::new(event_name, status, emitted_at, seq, provenance)
//          .with_emitter("boot_controller")
//          .build(payload)

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn state_machine_starts_at_spawning() {
        let sm = WorkerStateMachine::new();
        assert_eq!(sm.status(), WorkerStatus::Spawning);
        assert_eq!(sm.phase(), BootPhase::HardwareCheck);
    }

    #[test]
    fn valid_transition_succeeds() {
        let mut sm = WorkerStateMachine::new();
        assert!(sm.transition(WorkerStatus::Initializing).is_ok());
        assert_eq!(sm.status(), WorkerStatus::Initializing);
    }

    #[test]
    fn invalid_transition_fails() {
        let mut sm = WorkerStateMachine::new();
        // Can't go from Spawning directly to Ready
        assert!(sm.transition(WorkerStatus::Ready).is_err());
        assert_eq!(sm.status(), WorkerStatus::Spawning);
    }

    #[test]
    fn full_boot_sequence() {
        let mut controller = BootController::new();
        assert!(controller.start_boot().is_ok());

        // Phase 1: HardwareCheck → ConfigLoad
        assert!(controller.complete_phase().is_ok());
        assert_eq!(controller.state().phase(), BootPhase::ConfigLoad);

        // Phase 2: ConfigLoad → MeshJoin
        assert!(controller.complete_phase().is_ok());
        assert_eq!(controller.state().phase(), BootPhase::MeshJoin);

        // Phase 3: MeshJoin → TrustEstablish
        assert!(controller.complete_phase().is_ok());
        assert_eq!(controller.state().phase(), BootPhase::TrustEstablish);

        // Phase 4: TrustEstablish → ReadyForWork
        assert!(controller.complete_phase().is_ok());
        assert_eq!(controller.state().phase(), BootPhase::ReadyForWork);

        // Finish boot → Ready
        assert!(controller.finish_boot().is_ok());
        assert_eq!(controller.state().status(), WorkerStatus::Ready);
        assert!(controller.state().is_healthy());
    }

    #[test]
    fn fail_phase_retries_then_fails() {
        let mut controller = BootController::new();
        assert!(controller.start_boot().is_ok());

        // Fail phase repeatedly until max retries
        for _ in 0..2 {
            assert!(
                controller
                    .fail_phase(WorkerFailureKind::ConfigError)
                    .is_ok()
            );
        }

        // Third failure should fail permanently
        let result = controller.fail_phase(WorkerFailureKind::ConfigError);
        assert!(result.is_err());
        assert_eq!(controller.state().status(), WorkerStatus::Failed);
        assert!(!controller.state().is_healthy());
    }

    #[test]
    fn timeout_detection() {
        let mut controller = BootController::new();
        // Use very short timeout for testing
        controller.config.phase_timeout_secs = 0; // immediate timeout
        assert!(!controller.is_current_phase_timed_out());

        // Now advance to init and check timeout
        let _ = controller.start_boot();
        // With timeout 0, this should be timed out if phase_started is far enough
        // Actually timestamp resolution is ms, so 0 sec timeout means first check works
    }

    #[test]
    fn degrade_and_recover() {
        let mut sm = WorkerStateMachine::new();
        assert!(sm.transition(WorkerStatus::Initializing).is_ok());
        assert!(sm.transition(WorkerStatus::Ready).is_ok());
        assert!(sm.transition(WorkerStatus::Degraded).is_ok());
        assert!(!sm.is_healthy());
        assert!(sm.transition(WorkerStatus::Ready).is_ok());
        assert!(sm.is_healthy());
    }

    #[test]
    fn can_always_fail() {
        let mut sm = WorkerStateMachine::new();
        assert!(sm.transition(WorkerStatus::Initializing).is_ok());
        assert!(sm.transition(WorkerStatus::Ready).is_ok());
        assert!(sm.transition(WorkerStatus::Running).is_ok());
        // Can always transition to Failed
        assert!(sm.transition(WorkerStatus::Failed).is_ok());
        assert!(sm.is_terminal());
    }

    #[test]
    fn failure_count_tracking() {
        let mut sm = WorkerStateMachine::new();
        assert_eq!(sm.failure_count(), 0);
        sm.record_failure(WorkerFailureKind::StartupTimeout);
        assert_eq!(sm.failure_count(), 1);
        sm.record_failure(WorkerFailureKind::MeshBindFailure);
        assert_eq!(sm.failure_count(), 2);
    }

    #[test]
    fn has_been_ready_tracks() {
        let mut sm = WorkerStateMachine::new();
        assert!(!sm.has_been_ready());
        let _ = sm.transition(WorkerStatus::Initializing);
        let _ = sm.transition(WorkerStatus::Ready);
        assert!(sm.has_been_ready());
    }

    #[test]
    fn finish_boot_requires_ready_for_work_phase() {
        let mut controller = BootController::new();
        // Without going through phases, finish_boot should fail
        assert!(controller.finish_boot().is_err());
    }

    #[test]
    fn boot_phase_sequence_order() {
        assert_eq!(BootPhase::HardwareCheck.next(), Some(BootPhase::ConfigLoad));
        assert_eq!(BootPhase::ConfigLoad.next(), Some(BootPhase::MeshJoin));
        assert_eq!(BootPhase::MeshJoin.next(), Some(BootPhase::TrustEstablish));
        assert_eq!(
            BootPhase::TrustEstablish.next(),
            Some(BootPhase::ReadyForWork)
        );
        assert_eq!(BootPhase::ReadyForWork.next(), None);
    }

    #[test]
    fn health_check_after_finish() {
        let mut controller = BootController::new();
        assert!(!controller.health_check()); // Spawning = not healthy
        let _ = controller.start_boot();
        let _ = controller.complete_phase(); // HardwareCheck
        let _ = controller.complete_phase(); // ConfigLoad
        let _ = controller.complete_phase(); // MeshJoin
        let _ = controller.complete_phase(); // TrustEstablish
        let _ = controller.finish_boot(); // Ready
        assert!(controller.health_check());
    }
}
