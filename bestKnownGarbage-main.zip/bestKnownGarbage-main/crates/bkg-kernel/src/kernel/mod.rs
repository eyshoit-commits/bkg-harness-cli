//! BKG Kernel Module
//!
//! Core kernel loop, worker boot, branch management, trust resolution,
//! and managed agent orchestration.

pub mod boot;
pub mod r#loop;
pub mod stale_branch;
pub mod trust_resolver;

pub use boot::{
    BootConfig, BootController, BootError, BootPhase, WorkerFailureKind, WorkerStateMachine,
    WorkerStatus,
};
pub use r#loop::{ExecutionReceipt, KernelState, KernelStats};
pub use stale_branch::{
    BranchId, BranchNode, BranchStatus, BranchTree, StaleConfig, StalenessResult,
};
pub use trust_resolver::{
    Capability, TrustCertificate, TrustError, TrustLevel, TrustResolution, TrustResolver, WorkerId,
};
