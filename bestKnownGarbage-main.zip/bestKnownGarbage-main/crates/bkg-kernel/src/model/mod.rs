//! BKG Guarded Model Format (GMF)
//!
//! Self-verifying model format with immune system protection.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

/// BKG Model with epistemic properties
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BkgModel {
    /// Model identifier
    pub model_id: String,
    /// Weights hash
    pub weights_hash: Hash,
    /// Architecture hash
    pub architecture_hash: Hash,
    /// Trust score
    pub trust_score: TrustScore,
    /// Stability index
    pub stability_index: StabilityIndex,
    /// Reproducibility index
    pub reproducibility_index: ReproducibilityScore,
    /// Parent models
    pub parent_models: Vec<String>,
    /// Derived from chunks
    pub derived_from_chunks: Vec<ChunkId>,
    /// Guard profile
    pub guard_profile: GuardProfile,
    /// Mesh signature
    pub mesh_signature: Signature,
    /// Creation timestamp
    pub created_at: Timestamp,
    /// Model metadata
    pub metadata: HashMap<String, String>,
}

/// Guard profile for model protection
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GuardProfile {
    /// Anti-poisoning enabled
    pub anti_poisoning: bool,
    /// Anti-replay enabled
    pub anti_replay: bool,
    /// Anti-sybil enabled
    pub anti_sybil: bool,
    /// Causal integrity check
    pub causal_integrity: bool,
    /// Drift detection enabled
    pub drift_detection: bool,
    /// Execution verification required
    pub execution_verification_required: bool,
}

impl Default for GuardProfile {
    fn default() -> Self {
        Self {
            anti_poisoning: true,
            anti_replay: true,
            anti_sybil: true,
            causal_integrity: true,
            drift_detection: true,
            execution_verification_required: true,
        }
    }
}

/// Guard result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GuardResult {
    /// Whether accepted
    pub accepted: bool,
    /// Guard score
    pub score: f32,
    /// Violations detected
    pub violations: Vec<String>,
}

/// Guard engine for model verification
#[derive(Debug, Clone)]
pub struct GuardEngine {
    /// Poisoning threshold
    pub threshold_poison: f32,
    /// Replay threshold
    pub threshold_replay: f32,
    /// Sybil threshold
    pub threshold_sybil: f32,
    /// Execution receipts for verification
    pub receipts: HashMap<String, Vec<String>>,
}

impl Default for GuardEngine {
    fn default() -> Self {
        Self {
            threshold_poison: 0.7,
            threshold_replay: 0.7,
            threshold_sybil: 0.7,
            receipts: HashMap::new(),
        }
    }
}

impl GuardEngine {
    /// Create a new guard engine
    pub fn new() -> Self {
        Self::default()
    }

    /// Verify a model
    pub fn verify_model(&self, model: &BkgModel) -> GuardResult {
        let mut score: f32 = 1.0;
        let mut violations = Vec::new();

        // 1. Replay attack detection
        if model.guard_profile.anti_replay && self.detect_replay(model) {
            score -= 0.4;
            violations.push("Replay attack detected".to_string());
        }

        // 2. Poisoning detection
        if model.guard_profile.anti_poisoning && self.detect_poisoning(model) {
            score -= 0.3;
            violations.push("Poisoning detected".to_string());
        }

        // 3. Sybil consistency check
        if model.guard_profile.anti_sybil && self.detect_sybil_signals(model) {
            score -= 0.3;
            violations.push("Sybil signals detected".to_string());
        }

        // 4. Causal integrity
        if model.guard_profile.causal_integrity && model.derived_from_chunks.is_empty() {
            score -= 0.2;
            violations.push("No causal lineage".to_string());
        }

        // 5. Drift detection
        if model.guard_profile.drift_detection && model.stability_index < 0.5 {
            score -= 0.2;
            violations.push("High drift detected".to_string());
        }

        GuardResult {
            accepted: score >= 0.7,
            score: score.max(0.0),
            violations,
        }
    }

    /// Detect replay attacks
    fn detect_replay(&self, model: &BkgModel) -> bool {
        // Check for duplicate output hashes in receipts
        if let Some(receipts) = self.receipts.get(&model.model_id) {
            let unique: HashSet<_> = receipts.iter().collect();
            unique.len() < receipts.len()
        } else {
            false
        }
    }

    /// Detect model poisoning
    fn detect_poisoning(&self, model: &BkgModel) -> bool {
        model.trust_score < 0.4 && model.stability_index < 0.5
    }

    /// Detect sybil attack signals
    fn detect_sybil_signals(&self, model: &BkgModel) -> bool {
        // Unnatural graph fan-in suggests sybil behavior
        model.parent_models.len() > 20
    }

    /// Register an execution receipt
    pub fn register_receipt(&mut self, model_id: &str, output_hash: &str) {
        self.receipts
            .entry(model_id.to_string())
            .or_default()
            .push(output_hash.to_string());
    }
}

/// Model packet for P2P propagation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelPacket {
    /// The model
    pub model: BkgModel,
    /// Time to live
    pub ttl: u8,
    /// Origin node
    pub origin_node: NodeId,
    /// Hop signature chain
    pub hop_signature_chain: Vec<Signature>,
}

/// Model sync engine for P2P propagation
#[derive(Debug, Clone, Default)]
pub struct ModelSyncEngine {
    /// Known models
    pub models: HashMap<String, BkgModel>,
    /// Propagation history
    pub propagation_history: Vec<ModelPacket>,
}

impl ModelSyncEngine {
    /// Create a new model sync engine
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a model
    pub fn register(&mut self, model: BkgModel) {
        self.models.insert(model.model_id.clone(), model);
    }

    /// Propagate a model packet
    pub fn propagate(&mut self, packet: &mut ModelPacket) -> bool {
        if packet.ttl == 0 {
            return false;
        }

        packet.ttl -= 1;

        // Each hop re-signs model integrity
        packet
            .hop_signature_chain
            .push(Signature::new(format!("sig::{}", packet.model.model_id)));

        self.propagation_history.push(packet.clone());
        true
    }

    /// Create a model packet
    pub fn create_packet(&self, model: BkgModel, origin: NodeId, ttl: u8) -> ModelPacket {
        ModelPacket {
            model,
            ttl,
            origin_node: origin,
            hop_signature_chain: Vec::new(),
        }
    }

    /// Get best model by trust score
    pub fn best_model(&self) -> Option<&BkgModel> {
        self.models.values().max_by(|a, b| {
            let score_a =
                a.trust_score * 0.4 + a.stability_index * 0.3 + a.reproducibility_index * 0.3;
            let score_b =
                b.trust_score * 0.4 + b.stability_index * 0.3 + b.reproducibility_index * 0.3;
            score_a.partial_cmp(&score_b).unwrap()
        })
    }
}

/// Defense loop for continuous model monitoring
#[derive(Debug, Clone)]
pub struct DefenseLoop {
    /// Guard engine
    pub guard: GuardEngine,
    /// Quarantined models
    pub quarantined: Vec<String>,
    /// Defense statistics
    pub stats: DefenseStats,
}

/// Defense statistics
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct DefenseStats {
    /// Models verified
    pub verified: u64,
    /// Models quarantined
    pub quarantined: u64,
    /// Violations detected
    pub violations: u64,
}

impl DefenseLoop {
    /// Create a new defense loop
    pub fn new() -> Self {
        Self {
            guard: GuardEngine::new(),
            quarantined: Vec::new(),
            stats: DefenseStats::default(),
        }
    }

    /// Run defense tick
    pub fn tick(&mut self, models: &mut Vec<BkgModel>) {
        models.retain(|m| {
            let result = self.guard.verify_model(m);
            self.stats.verified += 1;

            if !result.accepted {
                self.quarantined.push(m.model_id.clone());
                self.stats.quarantined += 1;
                self.stats.violations += result.violations.len() as u64;
                false
            } else {
                true
            }
        });
    }
}

impl Default for DefenseLoop {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_model() -> BkgModel {
        BkgModel {
            model_id: "model_1".into(),
            weights_hash: "hash1".into(),
            architecture_hash: "hash2".into(),
            trust_score: 0.9,
            stability_index: 0.95,
            reproducibility_index: 0.92,
            parent_models: vec![],
            derived_from_chunks: vec!["chunk_1".into()],
            guard_profile: GuardProfile::default(),
            mesh_signature: Signature::new("sig"),
            created_at: Timestamp::now(),
            metadata: HashMap::new(),
        }
    }

    #[test]
    fn test_model_creation() {
        let model = create_test_model();
        assert_eq!(model.model_id, "model_1");
    }

    #[test]
    fn test_guard_verification() {
        let guard = GuardEngine::new();
        let model = create_test_model();

        let result = guard.verify_model(&model);

        assert!(result.accepted);
        assert!(result.violations.is_empty());
    }

    #[test]
    fn test_poisoning_detection() {
        let guard = GuardEngine::new();
        let mut model = create_test_model();

        model.trust_score = 0.3;
        model.stability_index = 0.4;

        let result = guard.verify_model(&model);

        assert!(!result.accepted);
    }

    #[test]
    fn test_model_sync() {
        let mut sync = ModelSyncEngine::new();
        let model = create_test_model();

        sync.register(model);

        assert!(sync.models.contains_key("model_1"));
    }

    #[test]
    fn test_model_propagation() {
        let mut sync = ModelSyncEngine::new();
        let model = create_test_model();

        let mut packet = sync.create_packet(model, "node_1".into(), 5);

        assert!(sync.propagate(&mut packet));
        assert_eq!(packet.ttl, 4);
    }
}
