// BKG Kernel - Ledger Module (P4)
// Append-only, immutable once written, Motherbrain-only commit authority

use crate::core::NodeId;
use crate::kernel::ExecutionReceipt;
use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug)]
pub struct LedgerEntry {
    pub index: u64,
    pub receipt: ExecutionReceipt,
    pub committed_by: NodeId,
    pub committed_at: u64,
    pub valid: bool,
}

pub struct Ledger {
    entries: Vec<LedgerEntry>,
    index_by_receipt: HashMap<String, u64>, // receipt_id -> entry_index
    valid_count: u64,
}

impl Default for Ledger {
    fn default() -> Self {
        Self::new()
    }
}

impl Ledger {
    pub fn new() -> Self {
        Self {
            entries: vec![],
            index_by_receipt: HashMap::new(),
            valid_count: 0,
        }
    }

    /// Deterministic threshold for considering an execution deterministic
    const DETERMINISTIC_THRESHOLD: f32 = 0.9;

    /// Append a receipt that has been adjudicated by Motherbrain.
    /// Returns the entry index if appended, error if already exists.
    pub fn append(
        &mut self,
        receipt: ExecutionReceipt,
        motherbrain_id: &NodeId,
    ) -> crate::Result<u64> {
        let receipt_id = receipt.receipt_id.clone();
        if self.index_by_receipt.contains_key(&receipt_id) {
            return Err(crate::BkgError::DuplicateReceipt(receipt_id));
        }

        let valid = receipt.success && receipt.deterministic_score >= Self::DETERMINISTIC_THRESHOLD;
        let index = self.entries.len() as u64;

        let entry = LedgerEntry {
            index,
            receipt: receipt.clone(),
            committed_by: motherbrain_id.clone(),
            committed_at: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map_err(|_| crate::BkgError::TimeError)?
                .as_secs(),
            valid,
        };

        self.entries.push(entry);
        self.index_by_receipt.insert(receipt_id, index);
        if valid {
            self.valid_count += 1;
        }

        Ok(index)
    }

    /// Check if a receipt is already committed (by ID)
    pub fn has_receipt(&self, receipt_id: &str) -> bool {
        self.index_by_receipt.contains_key(receipt_id)
    }

    /// Get an entry by index
    pub fn get(&self, index: u64) -> Option<&LedgerEntry> {
        self.entries.get(index as usize)
    }

    /// Get all valid entries
    pub fn valid_entries(&self) -> impl Iterator<Item = &LedgerEntry> {
        self.entries.iter().filter(|e| e.valid)
    }

    /// Total number of entries
    pub fn len(&self) -> u64 {
        self.entries.len() as u64
    }

    /// Whether the ledger is empty
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Number of valid entries
    pub fn valid_count(&self) -> u64 {
        self.valid_count
    }

    /// Validity ratio (0..1)
    pub fn validity_ratio(&self) -> f32 {
        let total = self.entries.len() as f32;
        if total == 0.0 {
            return 0.0;
        }
        self.valid_count as f32 / total
    }

    /// Iterate over all entries (for replay, analysis)
    pub fn iter(&self) -> impl Iterator<Item = &LedgerEntry> {
        self.entries.iter()
    }

    /// Snapshot current state as hash (for consensus, state commitment)
    pub fn state_hash(&self) -> crate::Result<String> {
        use sha2::{Digest, Sha256};

        let mut hasher = Sha256::new();
        for entry in &self.entries {
            let data = format!(
                "{}:{}:{}:{}",
                entry.index, entry.receipt.receipt_id, entry.valid, entry.committed_at
            );
            hasher.update(data.as_bytes());
        }
        Ok(format!("{:x}", hasher.finalize()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::types::Timestamp;
    use crate::kernel::ExecutionReceipt;
    use crate::trust_field_kernel::ExecutionProof;
    use std::collections::HashMap;

    #[test]
    fn test_ledger_append() {
        let mut ledger = Ledger::new();
        let receipt = ExecutionReceipt {
            receipt_id: "test_id".to_string(),
            chunk_id: "chunk1".to_string(),
            node_id: "node1".to_string(),
            output_hash: "out1".to_string(),
            env_hash: "env1".to_string(),
            deterministic_score: 0.98,
            execution_time_ms: 100,
            success: true,
            timestamp: Timestamp(0),
            proof: ExecutionProof {
                input_hash: "".to_string(),
                environment_hash: "".to_string(),
                output_hash: "".to_string(),
                determinism_score: 1.0,
                metadata: HashMap::new(),
            },
        };
        let idx = ledger.append(receipt, &"motherbrain".to_string()).unwrap();
        assert_eq!(idx, 0);
        assert_eq!(ledger.len(), 1);
        assert_eq!(ledger.valid_count(), 1);
    }

    #[test]
    fn test_duplicate_rejection() {
        let mut ledger = Ledger::new();
        let receipt = ExecutionReceipt {
            receipt_id: "dup_test".to_string(),
            chunk_id: "chunk1".to_string(),
            node_id: "node1".to_string(),
            output_hash: "out1".to_string(),
            env_hash: "env1".to_string(),
            deterministic_score: 0.98,
            execution_time_ms: 100,
            success: true,
            timestamp: Timestamp(0),
            proof: ExecutionProof {
                input_hash: "".to_string(),
                environment_hash: "".to_string(),
                output_hash: "".to_string(),
                determinism_score: 1.0,
                metadata: HashMap::new(),
            },
        };
        ledger
            .append(receipt.clone(), &"motherbrain".to_string())
            .unwrap();
        let result = ledger.append(receipt, &"motherbrain".to_string());
        assert!(result.is_err());
        assert!(matches!(result, Err(crate::BkgError::DuplicateReceipt(_))));
    }

    #[test]
    fn test_validity_ratio() {
        let mut ledger = Ledger::new();

        let default_proof = ExecutionProof {
            input_hash: "".to_string(),
            environment_hash: "".to_string(),
            output_hash: "".to_string(),
            determinism_score: 1.0,
            metadata: HashMap::new(),
        };

        let r1 = ExecutionReceipt {
            receipt_id: "r1".to_string(),
            chunk_id: "c1".into(),
            node_id: "n1".into(),
            output_hash: "o1".into(),
            env_hash: "e1".into(),
            deterministic_score: 0.99,
            execution_time_ms: 100,
            success: true,
            timestamp: Timestamp(0),
            proof: default_proof.clone(),
        };
        ledger.append(r1, &"mb".to_string()).unwrap();

        let r2 = ExecutionReceipt {
            receipt_id: "r2".to_string(),
            chunk_id: "c2".into(),
            node_id: "n2".into(),
            output_hash: "o2".into(),
            env_hash: "e2".into(),
            deterministic_score: 0.95,
            execution_time_ms: 100,
            success: false, // will be invalid
            timestamp: Timestamp(0),
            proof: default_proof.clone(),
        };
        ledger.append(r2, &"mb".to_string()).unwrap();

        let r3 = ExecutionReceipt {
            receipt_id: "r3".to_string(),
            chunk_id: "c3".into(),
            node_id: "n3".into(),
            output_hash: "o3".into(),
            env_hash: "e3".into(),
            deterministic_score: 0.80, // below threshold
            execution_time_ms: 100,
            success: true,
            timestamp: Timestamp(0),
            proof: default_proof,
        };
        ledger.append(r3, &"mb".to_string()).unwrap();

        // Only r1 valid
        let ratio = ledger.validity_ratio();
        assert!((ratio - 1.0 / 3.0).abs() < 1e-6);
    }
}
