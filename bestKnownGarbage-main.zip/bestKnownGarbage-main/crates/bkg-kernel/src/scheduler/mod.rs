//! BKG Scheduler Module
//!
//! Distributed validation and task scheduling.

pub mod swarm;

pub use swarm::{
    ConsensusResult, SwarmJob, SwarmJobStatus, SwarmScheduler, SwarmStats, ValidationResult,
    ValidationStrategy,
};
