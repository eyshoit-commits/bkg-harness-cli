//! BKG Swarm Scheduler
//!
//! Distributed validation mesh for distributed truth verification.

use crate::core::*;
use crate::trust::TrustKernel;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Validation strategy for swarm jobs
/// Types of causal relationships between chunks
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum ValidationStrategy {
    /// Full replay validation
    FullReplay,
    /// Sampled validation (probabilistic)
    Sampled { sample_rate: f32 },
    /// Cross-node validation
    CrossNode,
    /// Emergency validation (high priority)
    Emergency,
    /// Counterfactual testing
    Counterfactual,
}

/// Swarm job for distributed validation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SwarmJob {
    /// Job identifier
    pub job_id: String,
    /// Node being validated
    pub node_id: NodeId,
    /// Chunks to validate
    pub chunk_ids: Vec<ChunkId>,
    /// Assigned validators
    pub validators: Vec<NodeId>,
    /// Validation strategy
    pub strategy: ValidationStrategy,
    /// Required consensus threshold
    pub consensus_threshold: f32,
    /// Job creation timestamp
    pub created_at: Timestamp,
    /// Job status
    pub status: SwarmJobStatus,
}

/// Status of a swarm job
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SwarmJobStatus {
    /// Job is pending
    Pending,
    /// Job is running
    Running,
    /// Job completed successfully
    Completed,
    /// Job failed
    Failed,
    /// Job timed out
    Timeout,
}

/// Validation result from a validator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationResult {
    /// Job identifier
    pub job_id: String,
    /// Validator node
    pub validator_id: NodeId,
    /// Chunk validated
    pub chunk_id: ChunkId,
    /// Whether validation passed
    pub passed: bool,
    /// Confidence in result
    pub confidence: f32,
    /// Details
    pub details: String,
    /// Timestamp
    pub timestamp: Timestamp,
}

/// Swarm scheduler managing distributed validation
#[derive(Debug, Clone, Default)]
pub struct SwarmScheduler {
    /// Active jobs
    pub active_jobs: HashMap<String, SwarmJob>,
    /// Completed jobs
    pub completed_jobs: Vec<SwarmJob>,
    /// Validation results
    pub results: HashMap<String, Vec<ValidationResult>>,
    /// Available validators
    pub validators: Vec<NodeId>,
    /// Scheduler statistics
    pub stats: SwarmStats,
}

/// Swarm statistics
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SwarmStats {
    /// Total jobs created
    pub total_jobs: u64,
    /// Successful jobs
    pub successful_jobs: u64,
    /// Failed jobs
    pub failed_jobs: u64,
    /// Total validations
    pub total_validations: u64,
}

impl SwarmScheduler {
    /// Create a new swarm scheduler
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a validator node
    pub fn register_validator(&mut self, node_id: NodeId) {
        if !self.validators.contains(&node_id) {
            self.validators.push(node_id);
        }
    }

    /// Spawn a validation swarm for a node
    pub fn spawn_validation_swarm(
        &mut self,
        node_id: NodeId,
        chunk_ids: Vec<ChunkId>,
        strategy: ValidationStrategy,
    ) -> String {
        let job_id = format!("job_{}_{}", node_id, Timestamp::now().0);

        // Select validators (round-robin)
        let validators: Vec<NodeId> = self
            .validators
            .iter()
            .filter(|v| *v != &node_id)
            .take(3)
            .cloned()
            .collect();

        let job = SwarmJob {
            job_id: job_id.clone(),
            node_id,
            chunk_ids,
            validators,
            strategy,
            consensus_threshold: 0.67,
            created_at: Timestamp::now(),
            status: SwarmJobStatus::Pending,
        };

        self.active_jobs.insert(job_id.clone(), job);
        self.stats.total_jobs += 1;

        job_id
    }

    /// Submit a validation result
    pub fn submit_result(&mut self, result: ValidationResult) {
        self.results
            .entry(result.job_id.clone())
            .or_default()
            .push(result.clone());

        self.stats.total_validations += 1;
    }

    /// Evaluate trust field and spawn jobs if needed
    pub fn evaluate(&mut self, trust: &TrustKernel) -> Vec<String> {
        let mut spawned = Vec::new();

        for node_id in trust.low_trust_nodes() {
            let score = trust.get(node_id);

            let strategy = if score < 0.2 {
                ValidationStrategy::Emergency
            } else if score < 0.4 {
                ValidationStrategy::FullReplay
            } else {
                ValidationStrategy::Sampled { sample_rate: 0.3 }
            };

            let job_id = self.spawn_validation_swarm(
                node_id.clone(),
                vec![format!("chunk_{}", node_id)],
                strategy,
            );

            spawned.push(job_id);
        }

        spawned
    }

    /// Check if a job has reached consensus
    pub fn check_consensus(&self, job_id: &str) -> Option<ConsensusResult> {
        let job = self.active_jobs.get(job_id)?;
        let results = self.results.get(job_id)?;

        if results.len() < job.validators.len() {
            return None;
        }

        let passed: usize = results.iter().filter(|r| r.passed).count();
        let rate = passed as f32 / results.len() as f32;

        Some(ConsensusResult {
            job_id: job_id.to_string(),
            passed: rate >= job.consensus_threshold,
            pass_rate: rate,
            total_validators: results.len(),
            validators_passed: passed,
        })
    }

    /// Complete a job
    pub fn complete_job(&mut self, job_id: &str, success: bool) {
        if let Some(mut job) = self.active_jobs.remove(job_id) {
            job.status = if success {
                SwarmJobStatus::Completed
            } else {
                SwarmJobStatus::Failed
            };

            self.completed_jobs.push(job);

            if success {
                self.stats.successful_jobs += 1;
            } else {
                self.stats.failed_jobs += 1;
            }
        }
    }

    /// Get pending jobs
    pub fn pending_jobs(&self) -> Vec<&SwarmJob> {
        self.active_jobs
            .values()
            .filter(|j| j.status == SwarmJobStatus::Pending)
            .collect()
    }

    /// Get running jobs
    pub fn running_jobs(&self) -> Vec<&SwarmJob> {
        self.active_jobs
            .values()
            .filter(|j| j.status == SwarmJobStatus::Running)
            .collect()
    }
}

/// Consensus result for a swarm job
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsensusResult {
    /// Job identifier
    pub job_id: String,
    /// Whether consensus passed
    pub passed: bool,
    /// Pass rate
    pub pass_rate: f32,
    /// Total validators
    pub total_validators: usize,
    /// Validators that passed
    pub validators_passed: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_swarm_scheduler_creation() {
        let scheduler = SwarmScheduler::new();
        assert_eq!(scheduler.active_jobs.len(), 0);
    }

    #[test]
    fn test_validator_registration() {
        let mut scheduler = SwarmScheduler::new();

        scheduler.register_validator("validator_1".into());
        scheduler.register_validator("validator_2".into());

        assert_eq!(scheduler.validators.len(), 2);
    }

    #[test]
    fn test_spawn_validation_swarm() {
        let mut scheduler = SwarmScheduler::new();

        scheduler.register_validator("validator_1".into());
        scheduler.register_validator("validator_2".into());

        let job_id = scheduler.spawn_validation_swarm(
            "node_1".into(),
            vec!["chunk_1".into()],
            ValidationStrategy::FullReplay,
        );

        assert!(!job_id.is_empty());
        assert!(scheduler.active_jobs.contains_key(&job_id));
    }

    #[test]
    fn test_consensus_check() {
        let mut scheduler = SwarmScheduler::new();

        scheduler.register_validator("v1".into());
        scheduler.register_validator("v2".into());

        let job_id = scheduler.spawn_validation_swarm(
            "node_1".into(),
            vec!["chunk_1".into()],
            ValidationStrategy::FullReplay,
        );

        // Submit results
        scheduler.submit_result(ValidationResult {
            job_id: job_id.clone(),
            validator_id: "v1".into(),
            chunk_id: "chunk_1".into(),
            passed: true,
            confidence: 0.9,
            details: "ok".to_string(),
            timestamp: Timestamp::now(),
        });

        scheduler.submit_result(ValidationResult {
            job_id: job_id.clone(),
            validator_id: "v2".into(),
            chunk_id: "chunk_1".into(),
            passed: true,
            confidence: 0.95,
            details: "ok".to_string(),
            timestamp: Timestamp::now(),
        });

        let consensus = scheduler.check_consensus(&job_id);

        assert!(consensus.is_some());
        assert!(consensus.unwrap().passed);
    }
}
