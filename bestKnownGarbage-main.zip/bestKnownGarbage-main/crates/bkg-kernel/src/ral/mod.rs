//! BKG Reality Anchor Layer (RAL)
//!
//! External truth coupling to prevent epistemic self-hypnosis.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Reality anchor for external truth coupling
#[derive(Debug, Clone)]
pub struct RealityAnchor {
    /// External reality sources
    pub external_sources: Vec<RealitySource>,
    /// Maximum allowed divergence
    pub max_allowed_divergence: f32,
    /// Anchor strength (0.0 to 1.0)
    pub anchor_strength: f32,
    /// Calibration history
    pub calibration_history: Vec<CalibrationPoint>,
}

/// Reality source for external validation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RealitySource {
    /// Source identifier
    pub source_id: String,
    /// Accepts execution feeds
    pub execution_feeds: bool,
    /// Accepts compiler results
    pub compiler_results: bool,
    /// Accepts production metrics
    pub production_metrics: bool,
    /// Accepts cross-node replay
    pub cross_node_replay: bool,
    /// Accepts CVE feeds
    pub cve_feeds: bool,
    /// Trust weight for this source
    pub trust_weight: f32,
    /// Last observation
    pub last_observation: Option<RealityObservation>,
}

/// Reality observation from external source
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RealityObservation {
    /// Observation identifier
    pub observation_id: String,
    /// Source identifier
    pub source_id: String,
    /// Observed value
    pub observed_value: f32,
    /// Confidence
    pub confidence: f32,
    /// Timestamp
    pub timestamp: Timestamp,
    /// Metadata
    pub metadata: HashMap<String, String>,
}

/// Calibration point for anchor adjustment
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationPoint {
    /// Timestamp
    pub timestamp: Timestamp,
    /// Anchor strength before
    pub strength_before: f32,
    /// Anchor strength after
    pub strength_after: f32,
    /// Observed world value
    pub observed_world: f32,
    /// Divergence
    pub divergence: f32,
}

impl RealityAnchor {
    /// Create a new reality anchor
    pub fn new() -> Self {
        Self {
            external_sources: Vec::new(),
            max_allowed_divergence: 0.3,
            anchor_strength: 1.0,
            calibration_history: Vec::new(),
        }
    }

    /// Add a reality source
    pub fn add_source(&mut self, source: RealitySource) {
        self.external_sources.push(source);
    }

    /// Collect observations from all sources
    pub fn collect_observations(&mut self) -> Vec<RealityObservation> {
        self.external_sources
            .iter()
            .filter_map(|s| s.last_observation.clone())
            .collect()
    }

    /// Compute external truth signal
    pub fn compute_external_signal(&self) -> f32 {
        if self.external_sources.is_empty() {
            return 0.5;
        }

        let mut weighted_sum = 0.0;
        let mut total_weight = 0.0;

        for source in &self.external_sources {
            if let Some(ref obs) = source.last_observation {
                weighted_sum += obs.observed_value * source.trust_weight * obs.confidence;
                total_weight += source.trust_weight * obs.confidence;
            }
        }

        if total_weight == 0.0 {
            return 0.5;
        }

        weighted_sum / total_weight
    }
}

impl Default for RealityAnchor {
    fn default() -> Self {
        Self::new()
    }
}

/// Divergence engine for reality checking
pub struct DivergenceEngine;

impl DivergenceEngine {
    /// Compute divergence between prediction and observation
    pub fn compute_divergence(predicted: f32, observed: f32) -> Divergence {
        (predicted - observed).abs()
    }

    /// Check if system is drifting
    pub fn is_drifting(divergence: f32, threshold: f32) -> bool {
        divergence > threshold
    }

    /// Compute trend divergence
    pub fn trend_divergence(history: &[f32]) -> f32 {
        if history.len() < 2 {
            return 0.0;
        }

        let recent = history.iter().rev().take(5).sum::<f32>() / 5.0_f32.min(history.len() as f32);
        let older = history.iter().take(5).sum::<f32>() / 5.0_f32.min(history.len() as f32);

        (recent - older).abs()
    }
}

/// Reality validation result
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum RealityVerdict {
    /// Aligned with reality
    Aligned,
    /// Weak drift detected
    WeakDrift,
    /// Violation of reality constraints
    Violation,
}

/// Reality validator
#[derive(Debug, Clone)]
pub struct RealityValidator {
    /// Violation threshold
    pub violation_threshold: f32,
    /// Weak drift threshold
    pub weak_drift_threshold: f32,
}

impl RealityValidator {
    /// Create a new reality validator
    pub fn new() -> Self {
        Self {
            violation_threshold: 0.3,
            weak_drift_threshold: 0.15,
        }
    }

    /// Validate prediction against observation
    pub fn validate(&self, predicted: f32, observed: f32) -> RealityVerdict {
        let divergence = DivergenceEngine::compute_divergence(predicted, observed);

        if divergence > self.violation_threshold {
            RealityVerdict::Violation
        } else if divergence > self.weak_drift_threshold {
            RealityVerdict::WeakDrift
        } else {
            RealityVerdict::Aligned
        }
    }

    /// Validate with anchor constraints
    pub fn validate_with_anchor(
        &self,
        anchor: &RealityAnchor,
        predicted: f32,
        observed: f32,
    ) -> RealityVerdict {
        let divergence = DivergenceEngine::compute_divergence(predicted, observed);

        if divergence > anchor.max_allowed_divergence {
            RealityVerdict::Violation
        } else if divergence > anchor.max_allowed_divergence * 0.5 {
            RealityVerdict::WeakDrift
        } else {
            RealityVerdict::Aligned
        }
    }
}

impl Default for RealityValidator {
    fn default() -> Self {
        Self::new()
    }
}

/// Reality shock detector
#[derive(Debug, Clone)]
pub struct RealityShockDetector {
    /// Shock threshold
    pub shock_threshold: f32,
    /// History of observations
    pub history: Vec<f32>,
    /// Max history size
    pub max_history: usize,
}

impl RealityShockDetector {
    /// Create a new shock detector
    pub fn new() -> Self {
        Self {
            shock_threshold: 0.4,
            history: Vec::new(),
            max_history: 100,
        }
    }

    /// Add observation
    pub fn observe(&mut self, value: f32) {
        self.history.push(value);
        if self.history.len() > self.max_history {
            self.history.remove(0);
        }
    }

    /// Detect reality shock
    pub fn detect_shock(&self) -> bool {
        if self.history.len() < 5 {
            return false;
        }

        let recent = self.history.last().unwrap();
        let avg = self.history.iter().sum::<f32>() / self.history.len() as f32;
        let deviation = (recent - avg).abs();

        deviation > self.shock_threshold
    }

    /// Detect sudden change
    pub fn detect_sudden_change(&self) -> bool {
        if self.history.len() < 10 {
            return false;
        }

        let recent_avg: f32 = self.history.iter().rev().take(5).sum();
        let older_avg: f32 = self.history.iter().take(5).sum();

        (recent_avg - older_avg).abs() > self.shock_threshold
    }
}

impl Default for RealityShockDetector {
    fn default() -> Self {
        Self::new()
    }
}

/// Truth pressure field
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TruthPressureField {
    /// Current pressure
    pub pressure: f32,
    /// Instability measure
    pub instability: f32,
    /// External pull strength
    pub external_pull: f32,
    /// History
    pub history: Vec<(Timestamp, f32)>,
}

impl TruthPressureField {
    /// Create a new truth pressure field
    pub fn new() -> Self {
        Self {
            pressure: 0.5,
            instability: 0.0,
            external_pull: 1.0,
            history: Vec::new(),
        }
    }

    /// Update pressure based on divergence and external signals
    pub fn update(&mut self, divergence: f32, external_signals: f32) {
        self.external_pull = external_signals;
        self.instability = divergence;

        // Physics-inspired truth model
        self.pressure = external_signals * 0.6 - divergence * 0.4;

        self.history.push((Timestamp::now(), self.pressure));

        if self.history.len() > 100 {
            self.history.remove(0);
        }
    }

    /// Check for collapse risk
    pub fn collapse_risk(&self) -> bool {
        self.pressure < 0.2 && self.instability > 0.7
    }

    /// Get pressure trend
    pub fn trend(&self) -> f32 {
        if self.history.len() < 2 {
            return 0.0;
        }

        let recent: f32 = self
            .history
            .iter()
            .rev()
            .take(5)
            .map(|(_, p)| *p)
            .sum::<f32>()
            / 5.0_f32.min(self.history.len() as f32);
        let older: f32 = self.history.iter().take(5).map(|(_, p)| *p).sum::<f32>()
            / 5.0_f32.min(self.history.len() as f32);

        recent - older
    }
}

impl Default for TruthPressureField {
    fn default() -> Self {
        Self::new()
    }
}

/// Reality calibration system
pub struct RealityCalibration;

impl RealityCalibration {
    /// Recalibrate anchor based on observed world
    pub fn recalibrate(anchor: &mut RealityAnchor, observed_world: f32) {
        let strength_before = anchor.anchor_strength;

        // System slowly re-aligns to external reality
        anchor.anchor_strength = anchor.anchor_strength * 0.9 + observed_world * 0.1;

        anchor.calibration_history.push(CalibrationPoint {
            timestamp: Timestamp::now(),
            strength_before,
            strength_after: anchor.anchor_strength,
            observed_world,
            divergence: (strength_before - observed_world).abs(),
        });
    }

    /// Force hard reset
    pub fn hard_reset(anchor: &mut RealityAnchor, observed_world: f32) {
        let strength_before = anchor.anchor_strength;
        anchor.anchor_strength = observed_world;

        anchor.calibration_history.push(CalibrationPoint {
            timestamp: Timestamp::now(),
            strength_before,
            strength_after: anchor.anchor_strength,
            observed_world,
            divergence: 0.0,
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_reality_anchor_creation() {
        let anchor = RealityAnchor::new();
        assert_eq!(anchor.external_sources.len(), 0);
        assert_eq!(anchor.anchor_strength, 1.0);
    }

    #[test]
    fn test_divergence_computation() {
        let divergence = DivergenceEngine::compute_divergence(0.8, 0.6);
        assert!((divergence - 0.2).abs() < 0.001);
    }

    #[test]
    fn test_drift_detection() {
        assert!(DivergenceEngine::is_drifting(0.4, 0.3));
        assert!(!DivergenceEngine::is_drifting(0.2, 0.3));
    }

    #[test]
    fn test_reality_validation() {
        let validator = RealityValidator::new();

        let aligned = validator.validate(0.8, 0.85);
        assert_eq!(aligned, RealityVerdict::Aligned);

        let violation = validator.validate(0.8, 0.3);
        assert_eq!(violation, RealityVerdict::Violation);
    }

    #[test]
    fn test_shock_detection() {
        let mut detector = RealityShockDetector::new();

        // Add stable observations
        for _ in 0..10 {
            detector.observe(0.5);
        }

        assert!(!detector.detect_shock());

        // Add shock observation
        detector.observe(1.0);

        assert!(detector.detect_shock());
    }

    #[test]
    fn test_truth_pressure() {
        let mut field = TruthPressureField::new();

        field.update(0.2, 0.8);

        assert!(field.pressure > 0.3);
        assert!(!field.collapse_risk());
    }

    #[test]
    fn test_calibration() {
        let mut anchor = RealityAnchor::new();

        RealityCalibration::recalibrate(&mut anchor, 0.9);

        assert!(!anchor.calibration_history.is_empty());
    }
}
