//! BKG Kernel — the epistemic truth engine.
//!
//! This crate contains the core BKG kernel: trust computation, causality graphs,
//! mesh networking, replay verification, evolution rules, reality anchoring,
//! garbage collection, swarm scheduling, and WASM runtime integration.

pub use bkg_core as core;

pub mod causality;
pub mod convergence;
pub mod escalation;
pub mod evolution;
pub mod gc;
pub mod kernel;
pub mod ledger;
pub mod mesh;
pub mod model;
pub mod motherbrain;
pub mod policy;
pub mod ral;
pub mod replay;
pub mod scheduler;
pub mod trust;
pub mod trust_engine;
pub mod trust_field_kernel;
pub mod truth;
pub mod wasm;

pub use policy::PolicyEngine;

// Re-export key trust types at crate root for backward compatibility
pub use trust_field_kernel::{
    CounterfactualResult, CounterfactualTest, EvidenceVector, ExecutionProof, StressProfile,
    TemporalTruth, TrustField, TrustVector, TruthDecision, TruthFunction,
};

/// Error type for bkg-kernel.
pub mod error {
    /// Re-export BkgError from bkg-core.
    pub use bkg_core::BkgError;
    /// Re-export Result from bkg-core.
    pub type Result<T> = std::result::Result<T, BkgError>;
}

/// Re-export of BkgError and Result for convenience.
pub use error::{BkgError, Result};
