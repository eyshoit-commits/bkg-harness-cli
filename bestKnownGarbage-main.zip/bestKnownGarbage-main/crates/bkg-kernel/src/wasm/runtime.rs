//! BKG WASM Runtime
//!
//! Deterministic, sandboxed execution environment for trust derivation.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// WASM module representation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WasmModule {
    /// Module identifier
    pub module_id: String,
    /// Content hash
    pub hash: Hash,
    /// WASM binary bytes (optional; if empty, simulation used)
    #[serde(skip_serializing_if = "Vec::is_empty")]
    #[serde(default)]
    pub wasm_bytes: Vec<u8>,
    /// Memory limit in MB
    pub memory_limit_mb: u64,
    /// Whether module is deterministic
    pub deterministic: bool,
    /// Creation timestamp
    pub created_at: Timestamp,
}

/// WASM runtime managing modules
#[derive(Debug, Clone, Default)]
pub struct WasmRuntime {
    /// Loaded modules
    pub modules: HashMap<String, WasmModule>,
    /// Execution count
    pub execution_count: u64,
    /// Total CPU time in ms
    pub total_cpu_time_ms: u64,
}

/// Execution result from WASM
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    /// Output bytes
    pub output: Vec<u8>,
    /// Output hash
    pub output_hash: Hash,
    /// Peak memory usage in MB
    pub memory_peak_mb: u64,
    /// CPU time in milliseconds
    pub cpu_time_ms: u64,
    /// Whether execution was deterministic
    pub deterministic: bool,
    /// Whether execution succeeded
    pub success: bool,
    /// Error message if failed
    pub error: Option<String>,
}

/// Snapshot for replay
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionSnapshot {
    /// Snapshot identifier
    pub snapshot_id: String,
    /// Module identifier
    pub module_id: String,
    /// Input bytes
    pub input: Vec<u8>,
    /// Input hash
    pub input_hash: Hash,
    /// Expected output hash
    pub output_hash: Hash,
    /// Environment hash
    pub env_hash: Hash,
    /// Timestamp
    pub timestamp: Timestamp,
}

impl WasmRuntime {
    /// Create a new WASM runtime
    pub fn new() -> Self {
        Self::default()
    }

    /// Register a module
    pub fn register_module(&mut self, module: WasmModule) {
        self.modules.insert(module.module_id.clone(), module);
    }

    /// Execute a module with input
    pub fn execute(&mut self, module_id: &str, input: &[u8]) -> ExecutionResult {
        let module = match self.modules.get(module_id) {
            Some(m) => m.clone(),
            None => {
                return ExecutionResult {
                    output: vec![],
                    output_hash: String::new(),
                    memory_peak_mb: 0,
                    cpu_time_ms: 0,
                    deterministic: false,
                    success: false,
                    error: Some(format!("Module not found: {}", module_id)),
                };
            }
        };

        // Check determinism requirement
        if !module.deterministic {
            return ExecutionResult {
                output: vec![],
                output_hash: String::new(),
                memory_peak_mb: 0,
                cpu_time_ms: 0,
                deterministic: false,
                success: false,
                error: Some("Non-deterministic module rejected".to_string()),
            };
        }

        // Simulate deterministic execution
        // (Real WASM execution via wasmtime is planned but not yet integrated)
        let output = self.run_sandbox(&module, input);

        self.execution_count += 1;
        self.total_cpu_time_ms += output.cpu_time_ms;

        output
    }

    /// Run module in sandbox
    fn run_sandbox(&self, module: &WasmModule, input: &[u8]) -> ExecutionResult {
        // Simulated deterministic execution
        // Real implementation would use actual WASM runtime

        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash as StdHash, Hasher};

        // Deterministic output based on input and module hash
        let mut hasher = DefaultHasher::new();
        input.hash(&mut hasher);
        module.hash.hash(&mut hasher);
        let output_hash = format!("{:016x}", hasher.finish());

        // Simulate output (in real implementation, actual WASM execution)
        let output = input.to_vec();

        // Simulate resource usage
        let cpu_time_ms = (input.len() as u64 / 100).max(1);
        let memory_peak_mb = (module.memory_limit_mb / 10).max(1);

        ExecutionResult {
            output,
            output_hash,
            memory_peak_mb,
            cpu_time_ms,
            deterministic: module.deterministic,
            success: true,
            error: None,
        }
    }

    /// Create execution snapshot for replay
    pub fn create_snapshot(
        &self,
        module_id: &str,
        input: &[u8],
        output_hash: Hash,
        env_hash: Hash,
    ) -> ExecutionSnapshot {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash as StdHash, Hasher};

        let mut hasher = DefaultHasher::new();
        input.hash(&mut hasher);
        let input_hash = format!("{:016x}", hasher.finish());

        let snapshot_id = format!("snap_{}_{}", module_id, input_hash);

        ExecutionSnapshot {
            snapshot_id,
            module_id: module_id.to_string(),
            input: input.to_vec(),
            input_hash,
            output_hash,
            env_hash,
            timestamp: Timestamp::now(),
        }
    }

    /// Get statistics
    pub fn stats(&self) -> WasmStats {
        WasmStats {
            modules_loaded: self.modules.len(),
            total_executions: self.execution_count,
            total_cpu_time_ms: self.total_cpu_time_ms,
        }
    }
}

/// WASM runtime statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WasmStats {
    /// Number of loaded modules
    pub modules_loaded: usize,
    /// Total executions
    pub total_executions: u64,
    /// Total CPU time in ms
    pub total_cpu_time_ms: u64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wasm_runtime_creation() {
        let runtime = WasmRuntime::new();
        assert_eq!(runtime.modules.len(), 0);
    }

    #[test]
    fn test_module_registration() {
        let mut runtime = WasmRuntime::new();

        let module = WasmModule {
            module_id: "test_module".to_string(),
            hash: "abc123".to_string(),
            wasm_bytes: Vec::new(),
            memory_limit_mb: 128,
            deterministic: true,
            created_at: Timestamp::now(),
        };

        runtime.register_module(module);

        assert!(runtime.modules.contains_key("test_module"));
    }

    #[test]
    fn test_deterministic_execution() {
        let mut runtime = WasmRuntime::new();

        let module = WasmModule {
            module_id: "test".to_string(),
            hash: "hash".to_string(),
            wasm_bytes: Vec::new(),
            memory_limit_mb: 64,
            deterministic: true,
            created_at: Timestamp::now(),
        };

        runtime.register_module(module);

        let result = runtime.execute("test", &[1, 2, 3]);

        assert!(result.success);
        assert!(result.deterministic);
    }

    #[test]
    fn test_non_deterministic_rejection() {
        let mut runtime = WasmRuntime::new();

        let module = WasmModule {
            module_id: "nondet".to_string(),
            hash: "hash".to_string(),
            wasm_bytes: Vec::new(),
            memory_limit_mb: 64,
            deterministic: false,
            created_at: Timestamp::now(),
        };

        runtime.register_module(module);

        let result = runtime.execute("nondet", &[1, 2, 3]);

        assert!(!result.success);
        assert!(!result.deterministic);
    }
}
