//! BKG WASM Module
//!
//! WebAssembly execution sandbox for deterministic computation.

pub mod runtime;

pub use runtime::{ExecutionResult, ExecutionSnapshot, WasmModule, WasmRuntime, WasmStats};
