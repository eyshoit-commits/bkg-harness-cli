//! BKG Trust Module
//!
//! Mathematical trust field system with adversarial resistance.

pub mod kernel;

pub use kernel::{SafetyThresholds, TemporalSignature, TrustKernel, TruthFunctionKernel};
