//! BKG Trust Kernel
//!
//! Mathematical trust field model with adversarial resistance and
//! counterfactual survival constraints.

use crate::causality::graph::CausalityGraph;
use crate::core::*;
use crate::trust_field_kernel::{
    CounterfactualResult, CounterfactualTest, ExecutionProof, TemporalTruth, TrustVector,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Trust kernel managing node trust scores
#[derive(Debug, Clone)]
pub struct TrustKernel {
    /// Trust scores per node
    pub scores: HashMap<NodeId, TrustScore>,
    /// Trust vectors per node (detailed breakdown)
    pub vectors: HashMap<NodeId, TrustVector>,
    /// Temporal signatures per node
    pub temporal: HashMap<NodeId, TemporalSignature>,
    /// Global entropy of trust field
    pub global_entropy: Entropy,
    /// Safety thresholds
    pub thresholds: SafetyThresholds,
}

/// Temporal signature tracking node stability
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemporalSignature {
    /// Stability over time (lower is better)
    pub stability: f32,
    /// Decay rate of trust
    pub decay_rate: f32,
    /// Volatility measure
    pub volatility: f32,
    /// History of trust scores
    pub history: Vec<(Timestamp, TrustScore)>,
}

impl Default for TemporalSignature {
    fn default() -> Self {
        Self {
            stability: 1.0,
            decay_rate: 0.0,
            volatility: 0.0,
            history: Vec::new(),
        }
    }
}

/// Safety thresholds for trust system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SafetyThresholds {
    /// Maximum entropy allowed
    pub max_entropy: f32,
    /// Maximum drift allowed
    pub max_drift: f32,
    /// Minimum trust for truth claims
    pub min_trust_for_truth: f32,
    /// Minimum counterfactual survival rate
    pub min_counterfactual_survival: f32,
    /// Maximum allowed inconsistency
    pub max_inconsistency: f32,
}

impl Default for SafetyThresholds {
    fn default() -> Self {
        Self {
            max_entropy: 0.8,
            max_drift: 0.1,
            min_trust_for_truth: 0.8,
            min_counterfactual_survival: 0.8,
            max_inconsistency: 0.1,
        }
    }
}

impl TrustKernel {
    /// Create a new trust kernel
    pub fn new() -> Self {
        Self {
            scores: HashMap::new(),
            vectors: HashMap::new(),
            temporal: HashMap::new(),
            global_entropy: 0.0,
            thresholds: SafetyThresholds::default(),
        }
    }

    /// Update trust score for a node (exponential smoothing)
    pub fn update(&mut self, node: NodeId, score: TrustScore) {
        let entry = self.scores.entry(node.clone()).or_insert(0.5);
        *entry = (*entry * 0.9) + (score * 0.1);

        // Update temporal signature
        let temporal = self.temporal.entry(node.clone()).or_default();
        temporal.history.push((Timestamp::now(), *entry));

        // Keep only last 100 entries
        if temporal.history.len() > 100 {
            temporal.history.remove(0);
        }

        self.recompute_temporal_signature(&node);
    }

    /// Update trust vector for a node
    pub fn update_vector(&mut self, node: NodeId, vector: TrustVector) {
        self.vectors.insert(node.clone(), vector.clone());
        self.update(node, vector.calculate_trust_score());
    }

    /// Get trust score for a node
    pub fn get(&self, node: &NodeId) -> TrustScore {
        *self.scores.get(node).unwrap_or(&0.0)
    }

    /// Penalize a node for a failure
    pub fn penalize(&mut self, node: &NodeId, severity: Severity) {
        if let Some(score) = self.scores.get_mut(node) {
            *score = (*score * (1.0 - severity)).max(0.0);
        }
    }

    /// Recompute trust from causality graph
    pub fn recompute(&mut self, graph: &CausalityGraph) {
        for (chunk_id, node) in &graph.nodes {
            let incoming = graph.incoming_edges(chunk_id);

            // Calculate trust from incoming edges
            let score: f32 = incoming.iter().map(|e| e.weight * e.confidence).sum();

            let node_score = if incoming.is_empty() {
                node.trust_at_creation
            } else {
                score / incoming.len() as f32
            };

            self.update(node.node_id.clone(), node_score.clamp(0.0, 1.0));
        }

        self.compute_entropy();
    }

    /// Compute global entropy of trust field
    pub fn compute_entropy(&mut self) -> Entropy {
        if self.scores.is_empty() {
            self.global_entropy = 0.0;
            return self.global_entropy;
        }

        let total_nodes = self.scores.len() as f32;

        // Calculate variance of trust scores
        let mean: f32 = self.scores.values().sum::<f32>() / total_nodes;
        let variance: f32 = self
            .scores
            .values()
            .map(|&s| (s - mean).powi(2))
            .sum::<f32>()
            / total_nodes;

        // High variance = high entropy
        // Low average trust = high entropy
        self.global_entropy = (variance.sqrt() * 0.6 + (1.0 - mean) * 0.4).min(1.0);
        self.global_entropy
    }

    /// Check for anomalies in trust field
    pub fn detect_anomaly(&self) -> bool {
        self.global_entropy > self.thresholds.max_entropy
    }

    /// Recompute temporal signature for a node
    fn recompute_temporal_signature(&mut self, node: &NodeId) {
        if let Some(temporal) = self.temporal.get_mut(node) {
            if temporal.history.len() < 2 {
                return;
            }

            // Calculate volatility
            let mut volatility_sum = 0.0;
            for i in 1..temporal.history.len() {
                let diff = (temporal.history[i].1 - temporal.history[i - 1].1).abs();
                volatility_sum += diff;
            }
            temporal.volatility = volatility_sum / (temporal.history.len() - 1) as f32;

            // Calculate stability (inverse of volatility)
            temporal.stability = 1.0 - temporal.volatility;

            // Calculate decay rate
            if temporal.history.len() >= 10 {
                let recent: f32 = temporal.history[temporal.history.len() - 10..]
                    .iter()
                    .map(|(_, s)| *s)
                    .sum::<f32>()
                    / 10.0;
                let older: f32 = temporal.history[..10].iter().map(|(_, s)| *s).sum::<f32>() / 10.0;
                temporal.decay_rate = (older - recent).max(0.0);
            }
        }
    }

    /// Get nodes with low trust
    pub fn low_trust_nodes(&self) -> Vec<&NodeId> {
        self.scores
            .iter()
            .filter(|(_, score)| **score < self.thresholds.min_trust_for_truth)
            .map(|(id, _)| id)
            .collect()
    }

    /// Get nodes with high volatility
    pub fn unstable_nodes(&self) -> Vec<&NodeId> {
        self.temporal
            .iter()
            .filter(|(_, t)| t.volatility > self.thresholds.max_drift)
            .map(|(id, _)| id)
            .collect()
    }
}

impl Default for TrustKernel {
    fn default() -> Self {
        Self::new()
    }
}

/// Mathematical truth function
pub struct TruthFunctionKernel;

impl TruthFunctionKernel {
    /// Core truth function: Truth(chunk) := survives(all perturbations)
    pub fn is_truthful(
        kernel: &TrustKernel,
        node_id: &NodeId,
        execution_proofs: &[&ExecutionProof],
        counterfactual_tests: &[&CounterfactualTest],
        temporal_truth: &TemporalTruth,
    ) -> bool {
        // Get trust vector
        let vector = match kernel.vectors.get(node_id) {
            Some(v) => v,
            None => return false,
        };

        // 1. Trust score must be sufficient
        let trust_ok = kernel.get(node_id) >= kernel.thresholds.min_trust_for_truth;

        // 2. Counterfactual survival
        let cf_survival = Self::check_counterfactual_survival(counterfactual_tests);

        // 3. Temporal consistency
        let temporal_ok = temporal_truth.is_stable();

        // 4. Vector quality
        let reproducibility_ok = vector.reproducibility >= 0.95;
        let adversarial_ok = vector.adversarial_resistance >= 0.90;
        let cross_env_ok = vector.cross_env_stability >= 0.90;

        // 5. Execution proof quality
        let proofs_ok =
            !execution_proofs.is_empty() && execution_proofs.iter().all(|p| p.is_valid());

        trust_ok
            && cf_survival
            && temporal_ok
            && reproducibility_ok
            && adversarial_ok
            && cross_env_ok
            && proofs_ok
    }

    /// Check counterfactual survival rate
    fn check_counterfactual_survival(tests: &[&CounterfactualTest]) -> bool {
        if tests.is_empty() {
            return true;
        }

        let survived = tests
            .iter()
            .filter(|t| matches!(t.test_result, CounterfactualResult::Survived))
            .count();

        let rate = survived as f32 / tests.len() as f32;
        rate >= 0.8
    }

    /// Calculate truth strength
    pub fn truth_strength(
        kernel: &TrustKernel,
        node_id: &NodeId,
        counterfactual_tests: &[&CounterfactualTest],
        temporal_truth: &TemporalTruth,
    ) -> f32 {
        let vector = match kernel.vectors.get(node_id) {
            Some(v) => v,
            None => return 0.0,
        };

        let cf_score = if Self::check_counterfactual_survival(counterfactual_tests) {
            1.0
        } else {
            0.0
        };

        let temporal_score = if temporal_truth.is_stable() { 1.0 } else { 0.0 };

        cf_score * 0.30
            + temporal_score * 0.30
            + vector.reproducibility * 0.20
            + vector.adversarial_resistance * 0.15
            + vector.cross_env_stability * 0.05
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_trust_kernel_creation() {
        let kernel = TrustKernel::new();
        assert_eq!(kernel.scores.len(), 0);
    }

    #[test]
    fn test_trust_smoothing() {
        let mut kernel = TrustKernel::new();

        kernel.update("node1".into(), 1.0);
        kernel.update("node1".into(), 0.5);

        let score = kernel.get(&"node1".into());
        assert!(score > 0.5);
        assert!(score < 1.0);
    }

    #[test]
    fn test_trust_penalize() {
        let mut kernel = TrustKernel::new();

        kernel.update("node1".into(), 1.0);
        kernel.penalize(&"node1".into(), 0.5);

        let score = kernel.get(&"node1".into());
        assert!(score < 0.5);
    }
}
