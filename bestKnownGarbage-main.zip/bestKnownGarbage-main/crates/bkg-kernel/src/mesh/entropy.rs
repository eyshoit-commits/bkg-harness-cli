use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};

/// A region/subnet in the mesh network with aggregated entropy metrics.
///
/// This is the "weather map" for Garbage Collectors to assess epistemic health.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EntropyRegion {
    /// Identifier of the subnet (could be topic, location, or arbitrary grouping).
    pub subnet_id: String,

    /// Variance of trust scores among nodes in this subnet.
    /// High variance indicates inconsistent verification quality.
    pub trust_variance: f32,

    /// Fraction of replay attempts that failed (0.0 = all succeeded, 1.0 = all failed).
    pub replay_noise: f32,

    /// Rate of change of trust (first derivative). High velocity = rapid drift.
    pub drift_velocity: f32,

    /// Timestamp when this region snapshot was taken (Unix seconds).
    pub timestamp: u64,
}

impl EntropyRegion {
    /// Create a new region snapshot.
    pub fn new(
        subnet_id: String,
        trust_variance: f32,
        replay_noise: f32,
        drift_velocity: f32,
    ) -> Self {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        Self {
            subnet_id,
            trust_variance,
            replay_noise,
            drift_velocity,
            timestamp,
        }
    }

    /// Compute a simple health score: lower variance, noise, drift = better.
    pub fn health_score(&self) -> f32 {
        let normalized_variance = (self.trust_variance / 0.5).min(1.0); // assume 0.5 is max expected
        let normalized_noise = self.replay_noise;
        let normalized_drift = (self.drift_velocity / 0.8).min(1.0); // assume 0.8/s is max expected

        let badness = (normalized_variance + normalized_noise + normalized_drift) / 3.0;
        1.0 - badness
    }
}
