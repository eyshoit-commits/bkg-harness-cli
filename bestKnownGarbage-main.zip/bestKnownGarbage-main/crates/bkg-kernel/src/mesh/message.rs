use super::entropy::EntropyRegion;
use crate::TrustVector;
use crate::core::types::NodeId;
use serde::{Deserialize, Serialize};

/// A cryptographic signature (placeholder; will be ed25519).
pub type Signature = [u8; 64];

/// A hash of some data (receipt, ledger entry, etc.).
pub type Hash = [u8; 32];

/// Messages gossiped between mesh nodes.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum MeshMessage {
    /// Simple heartbeat to detect liveness.
    Heartbeat {
        node_id: NodeId,
        seq: u64, // monotonic sequence number
    },

    /// Trust vector update from a node.
    TrustUpdate { node_id: NodeId, trust: TrustVector },

    /// Entropy map of a subnet – used by GCs for health mapping.
    EntropyMap { regions: Vec<EntropyRegion> },

    /// Minimal ledger synchronization hint.
    LedgerDelta {
        receipt_hash: Hash,
        depth: u64, // block height or ledger index
    },
}

impl MeshMessage {
    /// Returns the node that originated this message (for routing decisions).
    pub fn origin_node(&self) -> Option<NodeId> {
        match self {
            MeshMessage::Heartbeat { node_id, .. } => Some(node_id.clone()),
            MeshMessage::TrustUpdate { node_id, .. } => Some(node_id.clone()),
            MeshMessage::EntropyMap { .. } => None, // aggregated, no single origin
            MeshMessage::LedgerDelta { .. } => None, // global hint
        }
    }
}
