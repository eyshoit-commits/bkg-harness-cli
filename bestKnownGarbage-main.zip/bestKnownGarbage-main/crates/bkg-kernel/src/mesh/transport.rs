use super::message::MeshMessage;
use super::node::MeshNode;
use crate::core::types::NodeId;
use crate::error::Result;
use bincode;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::mpsc;
use tracing;

/// Transport layer handles TCP connections, message framing, and I/O.
///
/// Each MeshNode spawns:
/// - one listener task (accepts incoming connections)
/// - one outgoing connection task per peer
/// - one gossip loop that broadcasts at intervals
pub struct MeshTransport {
    node: Arc<MeshNode>,
    listen_addr: SocketAddr,
    outbound_senders: Vec<mpsc::UnboundedSender<(NodeId, MeshMessage)>>,
}

impl MeshTransport {
    /// Create a new transport bound to the given address.
    pub async fn new(node: Arc<MeshNode>, listen_addr: SocketAddr) -> Result<Self> {
        Ok(Self {
            node,
            listen_addr,
            outbound_senders: Vec::new(),
        })
    }

    /// Start the listener task (incoming connections).
    pub async fn start_listener(&self) -> Result<()> {
        let listener = TcpListener::bind(self.listen_addr).await?;
        let node_clone = self.node.clone();

        tokio::spawn(async move {
            loop {
                match listener.accept().await {
                    Ok((stream, addr)) => {
                        tracing::debug!("Incoming connection from {}", addr);
                        let node = node_clone.clone();
                        tokio::spawn(async move {
                            handle_incoming(stream, node).await;
                        });
                    }
                    Err(e) => {
                        tracing::error!("Listener accept error: {}", e);
                    }
                }
            }
        });

        Ok(())
    }

    /// Connect to a peer (outbound). Returns a sender channel to push messages.
    pub async fn connect_peer(
        &mut self,
        peer_addr: SocketAddr,
    ) -> Result<mpsc::UnboundedSender<(NodeId, MeshMessage)>> {
        let stream = TcpStream::connect(peer_addr).await?;
        let (tx, rx) = mpsc::unbounded_channel();

        let node = self.node.clone();
        tokio::spawn(async move {
            handle_outgoing(stream, rx, node).await;
        });

        Ok(tx)
    }

    /// Register a pre-established outbound channel (called after connect_peer).
    pub fn register_outbound(&mut self, sender: mpsc::UnboundedSender<(NodeId, MeshMessage)>) {
        self.outbound_senders.push(sender);
    }

    /// The gossip loop runs periodically and broadcasts:
    /// - Heartbeat always
    /// - TrustUpdate always (simplified)
    /// - EntropyMap always (for GCs)
    pub fn start_gossip_loop(self: Arc<Self>, interval: Duration) {
        let mut seq = 0u64;

        tokio::spawn(async move {
            loop {
                tokio::time::sleep(interval).await;

                // 1. Heartbeat
                let hb = self.node.build_heartbeat(seq).await;
                seq += 1;
                self.broadcast_message(hb).await;

                // 2. TrustUpdate (always send)
                let tu = self.node.build_trust_update().await;
                self.broadcast_message(tu).await;

                // 3. EntropyMap
                let em = self.node.build_entropy_map().await;
                self.broadcast_message(em).await;
            }
        });
    }

    /// Broadcast a message to all connected peers.
    async fn broadcast_message(&self, msg: MeshMessage) {
        for sender in &self.outbound_senders {
            // We ignore send errors (peer may have disconnected)
            let _ = sender.send((self.node.id.clone(), msg.clone()));
        }
    }
}

/// Handle an incoming TCP connection: read framed messages and feed to node.
async fn handle_incoming(mut stream: TcpStream, node: Arc<MeshNode>) {
    let mut buf = Vec::new();

    loop {
        // Read a 4-byte length prefix (big-endian u32)
        let len_bytes = match stream.read_u32().await {
            Ok(n) => n,
            Err(e) => {
                tracing::warn!("Failed to read message length: {}", e);
                return;
            }
        };
        let len = len_bytes as usize;

        buf.resize(len, 0);
        if let Err(e) = stream.read_exact(&mut buf).await {
            tracing::warn!("Failed to read message body: {}", e);
            return;
        }

        match bincode::deserialize(&buf) {
            Ok(msg) => {
                node.handle_message(msg).await;
            }
            Err(e) => {
                tracing::warn!("Failed to deserialize mesh message: {}", e);
            }
        }
    }
}

/// Handle outgoing connection: receive from channel and write to stream.
async fn handle_outgoing(
    mut stream: TcpStream,
    mut rx: mpsc::UnboundedReceiver<(NodeId, MeshMessage)>,
    _node: Arc<MeshNode>,
) {
    while let Some((_dest, msg)) = rx.recv().await {
        let data = match bincode::serialize(&msg) {
            Ok(d) => d,
            Err(e) => {
                tracing::warn!("Failed to serialize mesh message: {}", e);
                continue;
            }
        };

        // Frame: 4-byte length + payload
        let len = data.len() as u32;
        let mut packet = Vec::with_capacity(4 + data.len());
        packet.extend_from_slice(&len.to_be_bytes());
        packet.extend_from_slice(&data);

        if let Err(e) = stream.write_all(&packet).await {
            tracing::warn!("Outgoing write error: {}", e);
            break;
        }
    }
}

/// Start a full mesh node with listener + gossip.
///
/// Creates a transport, binds the listener, and starts the periodic gossip
/// loop — all I/O runs in tokio background tasks.
///
/// Peers should be added via [`MeshNode::add_peer`] before calling this,
/// or by calling [`MeshTransport::connect_peer`] on the returned transport.
pub async fn start_mesh_listener(
    node: Arc<MeshNode>,
    listen_addr: SocketAddr,
    _peer_addrs: Vec<SocketAddr>,
    gossip_interval: Duration,
) -> Result<Arc<MeshTransport>> {
    let transport = MeshTransport::new(node.clone(), listen_addr).await?;
    transport.start_listener().await?;
    let transport = Arc::new(transport);
    transport.clone().start_gossip_loop(gossip_interval);
    tracing::info!("mesh: full node running on {}", listen_addr);
    Ok(transport)
}
