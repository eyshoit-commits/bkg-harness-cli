use super::entropy::EntropyRegion;
use super::message::MeshMessage;
use crate::TrustVector;
use crate::core::types::NodeId;
use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::RwLock;

/// A mesh node participates in gossip but makes no adjudication decisions.
///
/// Design constraints:
/// - Read-only consumer of GC later (only observes truth, never writes it)
/// - Deterministic event processing (single-threaded handling per node)
/// - Minimal state: peers, local trust, entropy map, last heartbeat
pub struct MeshNode {
    /// Unique identifier for this node.
    pub id: NodeId,

    /// Connected peers (node_id -> remote address). This is a static/semistatic list.
    peers: RwLock<HashMap<NodeId, String>>, // addr -> for transport layer

    /// Latest known trust vector for each node we've heard about.
    trust_map: RwLock<HashMap<NodeId, TrustVector>>,

    /// Aggregated entropy regions (subnet -> health metrics).
    /// Later consumed by GCs.
    entropy_regions: RwLock<HashMap<String, EntropyRegion>>,

    /// Last time we sent a heartbeat.
    #[allow(dead_code)]
    last_heartbeat: RwLock<Instant>,

    /// Local node trust (our own view of ourselves).
    local_trust: RwLock<TrustVector>,
}

impl MeshNode {
    /// Create a new mesh node with given ID.
    pub fn new(id: NodeId, initial_trust: TrustVector) -> Arc<Self> {
        Arc::new(Self {
            id,
            peers: RwLock::new(HashMap::new()),
            trust_map: RwLock::new(HashMap::new()),
            entropy_regions: RwLock::new(HashMap::new()),
            last_heartbeat: RwLock::new(Instant::now()),
            local_trust: RwLock::new(initial_trust),
        })
    }

    /// The node's ID for display
    pub fn display_id(&self) -> &str {
        &self.id
    }
}

impl fmt::Debug for MeshNode {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MeshNode")
            .field("id", &self.id)
            .finish_non_exhaustive()
    }
}

impl MeshNode {
    /// Add a peer to the static peer list.
    pub async fn add_peer(&self, peer_id: NodeId, addr: String) {
        self.peers.write().await.insert(peer_id, addr);
    }

    /// Get current peers (snapshot).
    pub async fn peers_snapshot(&self) -> HashMap<NodeId, String> {
        self.peers.read().await.clone()
    }

    /// Update our local trust (e.g., after internal state changes).
    pub async fn set_local_trust(&self, trust: TrustVector) {
        *self.local_trust.write().await = trust;
    }

    /// Get our local trust snapshot.
    pub async fn local_trust_snapshot(&self) -> TrustVector {
        self.local_trust.read().await.clone()
    }

    /// Handle an incoming gossip message.
    ///
    /// This is the single-threaded, deterministic entry point for all state changes.
    /// Panic safety: no complex logic; just data aggregation.
    pub async fn handle_message(&self, msg: MeshMessage) {
        match msg {
            MeshMessage::Heartbeat { node_id, seq } => {
                tracing::debug!("Heartbeat from {}: seq {}", node_id, seq);
                // Nothing to do; just liveness marker.
            }
            MeshMessage::TrustUpdate { node_id, trust } => {
                tracing::debug!("TrustUpdate from {}: {:?}", node_id, trust);
                self.trust_map.write().await.insert(node_id, trust);
            }
            MeshMessage::EntropyMap { regions } => {
                tracing::debug!("EntropyMap with {} regions", regions.len());
                let mut map = self.entropy_regions.write().await;
                for region in regions {
                    map.insert(region.subnet_id.clone(), region);
                }
            }
            MeshMessage::LedgerDelta {
                receipt_hash,
                depth,
            } => {
                tracing::debug!("LedgerDelta: depth={}, hash={:?}", depth, receipt_hash);
                // No ledger handling here; that's for Ledger module later.
                // Just logging for now.
            }
        }
    }

    /// Gather current entropy map for outgoing gossip.
    pub async fn entropy_snapshot(&self) -> Vec<EntropyRegion> {
        self.entropy_regions
            .read()
            .await
            .values()
            .cloned()
            .collect()
    }

    /// Build a heartbeat message.
    pub async fn build_heartbeat(&self, seq: u64) -> MeshMessage {
        MeshMessage::Heartbeat {
            node_id: self.id.clone(),
            seq,
        }
    }

    /// Build a trust update message (our current local trust).
    pub async fn build_trust_update(&self) -> MeshMessage {
        let trust = self.local_trust_snapshot().await;
        MeshMessage::TrustUpdate {
            node_id: self.id.clone(),
            trust,
        }
    }

    /// Build an entropy map message (our current aggregated regions).
    pub async fn build_entropy_map(&self) -> MeshMessage {
        let regions = self.entropy_snapshot().await;
        MeshMessage::EntropyMap { regions }
    }

    /// Get number of known peers.
    pub async fn peer_count(&self) -> usize {
        self.peers.read().await.len()
    }

    /// Add an entropy region directly (for testing/demo).
    pub async fn add_entropy_region(&self, region: EntropyRegion) {
        let mut map = self.entropy_regions.write().await;
        map.insert(region.subnet_id.clone(), region);
    }

    /// Periodic maintenance tick (e.g., update internal stats). Currently minimal.
    pub async fn tick(&self) {
        // Future: recompute local entropy from trust_map
    }
}
