//! Distributed Mesh Layer – Sensory Nervous System
//!
//! The Mesh is strictly observational:
//! - gossips trust states
//! - propagates entropy maps
//! - forwards ledger hints
//! - never manipulates truth or topology
//!
//! All disruptive actions are reserved for Motherbrain.

use crate::TrustVector;
use crate::core::types::NodeId;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

pub mod entropy;
pub mod message;
pub mod node;
pub mod transport;

pub use entropy::EntropyRegion;
pub use message::MeshMessage;
pub use node::MeshNode;
pub use transport::{MeshTransport, start_mesh_listener};

/// MeshSync manages the sensory mesh layer lifecycle.
///
/// Holds the local MeshNode and spawns the network transport (TCP listener,
/// gossip loop, peer connections) in tokio background tasks.
///
/// The stored node is accessible via [`node()`](MeshSync::node) so that
/// the Garbage Collector can observe entropy regions and topology.
#[derive(Debug)]
pub struct MeshSync {
    /// The local mesh node (set after initialize).
    node: Option<Arc<MeshNode>>,
    /// Address we listen on, if initialized.
    listen_addr: Option<SocketAddr>,
}

impl MeshSync {
    /// Create a new uninitialized MeshSync.
    pub fn new() -> Self {
        Self {
            node: None,
            listen_addr: None,
        }
    }

    /// Initialize the mesh: create a MeshNode, bind a TCP transport, and start
    /// the gossip loop in the background.
    ///
    /// Binds to `127.0.0.1:0` (OS-assigned port). Peers can be added later
    /// via `node().unwrap().add_peer()`.
    pub fn initialize(&mut self, node_id: NodeId) {
        let listen_addr: SocketAddr = "127.0.0.1:0".parse().unwrap();
        let trust = TrustVector::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let node = MeshNode::new(node_id.clone(), trust);
        let node_tx = node.clone();

        tokio::spawn(async move {
            match MeshTransport::new(node_tx.clone(), listen_addr).await {
                Ok(transport) => {
                    if let Err(e) = transport.start_listener().await {
                        tracing::error!("mesh: listener failed: {}", e);
                        return;
                    }
                    let transport = Arc::new(transport);
                    transport.clone().start_gossip_loop(Duration::from_secs(30));
                    tracing::info!("mesh: transport running on {}", listen_addr);
                }
                Err(e) => {
                    tracing::error!("mesh: transport init failed: {}", e);
                }
            }
        });

        self.node = Some(node);
        self.listen_addr = Some(listen_addr);
        tracing::info!("mesh: initialized node {} on {}", node_id, listen_addr);
    }

    /// Return a reference to the local MeshNode, if initialized.
    pub fn node(&self) -> Option<Arc<MeshNode>> {
        self.node.clone()
    }

    /// Return the listen address, if initialized.
    pub fn listen_addr(&self) -> Option<SocketAddr> {
        self.listen_addr
    }
}

impl Default for MeshSync {
    fn default() -> Self {
        Self::new()
    }
}
