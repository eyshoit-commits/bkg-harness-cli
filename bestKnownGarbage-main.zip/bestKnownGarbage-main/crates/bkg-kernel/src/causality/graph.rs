//! BKG Causality Graph Engine
//!
//! Manages causal relationships between chunks, tracking dependencies,
//! failures, and CVE propagation across the knowledge graph.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

/// Types of causal relationships between chunks
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Relation {
    /// Derived from source chunk
    Derived,
    /// Fixes an issue in source chunk
    Fixes,
    /// Breaks the source chunk
    Breaks,
    /// Depends on source chunk
    DependsOn,
    /// CVE trigger relationship
    CVETrigger,
    /// Validates source chunk
    Validates,
    /// Contradicts source chunk
    Contradicts,
}

/// Edge in the causality graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CausalEdge {
    /// Source chunk
    pub from: ChunkId,
    /// Target chunk
    pub to: ChunkId,
    /// Weight of the relationship (0.0 to 1.0)
    pub weight: f32,
    /// Confidence in this relationship (0.0 to 1.0)
    pub confidence: f32,
    /// Type of relationship
    pub relation: Relation,
    /// Timestamp when this edge was created
    pub timestamp: Timestamp,
}

/// Node in the causality graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CausalNode {
    /// Chunk identifier
    pub chunk_id: ChunkId,
    /// Node that produced this chunk
    pub node_id: NodeId,
    /// Trust score at time of creation
    pub trust_at_creation: TrustScore,
    /// Number of incoming edges
    pub fan_in: usize,
    /// Number of outgoing edges
    pub fan_out: usize,
    /// Risk score (CVE exposure, failure rate)
    pub risk_score: f32,
    /// Last update timestamp
    pub last_updated: Timestamp,
}

/// The causality graph structure
#[derive(Debug, Clone, Default)]
pub struct CausalityGraph {
    /// All nodes in the graph
    pub nodes: HashMap<ChunkId, CausalNode>,
    /// All edges in the graph
    pub edges: Vec<CausalEdge>,
    /// Adjacency list for efficient traversal (from -> edges)
    pub adjacency: HashMap<ChunkId, Vec<CausalEdge>>,
    /// Reverse adjacency list (to -> edges)
    pub reverse_adjacency: HashMap<ChunkId, Vec<CausalEdge>>,
    /// Set of high-risk chunks
    pub high_risk_chunks: HashSet<ChunkId>,
    /// Global entropy of the graph
    pub global_entropy: Entropy,
}

impl CausalityGraph {
    /// Create a new empty causality graph
    pub fn new() -> Self {
        Self::default()
    }

    /// Ingest execution receipts into the graph
    pub fn ingest_receipts(&mut self, receipts: &[crate::kernel::ExecutionReceipt]) {
        for receipt in receipts {
            let edge = CausalEdge {
                from: receipt.chunk_id.clone(),
                to: receipt.receipt_id.clone(),
                weight: receipt.deterministic_score,
                confidence: receipt.deterministic_score,
                relation: Relation::Derived,
                timestamp: receipt.timestamp,
            };
            self.add_edge(edge);
        }
    }

    /// Add a node to the graph
    pub fn add_node(&mut self, node: CausalNode) {
        let chunk_id = node.chunk_id.clone();
        self.nodes.insert(chunk_id, node);
    }

    /// Add an edge to the graph
    pub fn add_edge(&mut self, edge: CausalEdge) {
        // Ensure both nodes exist
        if !self.nodes.contains_key(&edge.from) {
            self.add_node(CausalNode {
                chunk_id: edge.from.clone(),
                node_id: "unknown".to_string(),
                trust_at_creation: 0.5,
                fan_in: 0,
                fan_out: 0,
                risk_score: 0.0,
                last_updated: Timestamp::now(),
            });
        }
        if !self.nodes.contains_key(&edge.to) {
            self.add_node(CausalNode {
                chunk_id: edge.to.clone(),
                node_id: "unknown".to_string(),
                trust_at_creation: 0.5,
                fan_in: 0,
                fan_out: 0,
                risk_score: 0.0,
                last_updated: Timestamp::now(),
            });
        }

        // Update fan counts
        if let Some(from_node) = self.nodes.get_mut(&edge.from) {
            from_node.fan_out += 1;
        }
        if let Some(to_node) = self.nodes.get_mut(&edge.to) {
            to_node.fan_in += 1;
        }

        // Add to adjacency lists
        self.adjacency
            .entry(edge.from.clone())
            .or_default()
            .push(edge.clone());
        self.reverse_adjacency
            .entry(edge.to.clone())
            .or_default()
            .push(edge.clone());

        self.edges.push(edge);
    }

    /// Get incoming edges for a chunk
    pub fn incoming_edges(&self, chunk_id: &ChunkId) -> Vec<&CausalEdge> {
        self.reverse_adjacency
            .get(chunk_id)
            .map(|v| v.iter().collect())
            .unwrap_or_default()
    }

    /// Get outgoing edges for a chunk
    pub fn outgoing_edges(&self, chunk_id: &ChunkId) -> Vec<&CausalEdge> {
        self.adjacency
            .get(chunk_id)
            .map(|v| v.iter().collect())
            .unwrap_or_default()
    }

    /// Propagate failure from a source chunk
    pub fn propagate_failure(&self, origin: &ChunkId) -> Vec<ChunkId> {
        let mut affected = Vec::new();
        let mut visited = HashSet::new();
        let mut stack = vec![origin.clone()];

        while let Some(node) = stack.pop() {
            if visited.contains(&node) {
                continue;
            }
            visited.insert(node.clone());

            if let Some(edges) = self.adjacency.get(&node) {
                for edge in edges {
                    // Propagate if weight is significant
                    if edge.weight > 0.5 {
                        affected.push(edge.to.clone());
                        stack.push(edge.to.clone());
                    }
                }
            }
        }

        affected
    }

    /// Detect chunks at risk due to failures
    pub fn detect_failures(&self) -> Vec<FailureEvent> {
        let mut failures = Vec::new();

        for (chunk_id, node) in &self.nodes {
            // Check for high fan-in with low trust
            if node.fan_in > 5 && node.trust_at_creation < 0.4 {
                failures.push(FailureEvent {
                    chunk_id: chunk_id.clone(),
                    node_id: node.node_id.clone(),
                    severity: 0.8,
                    propagation_depth: 0,
                    reason: FailureReason::LowTrustHighFanIn,
                });
            }

            // Check for break relationships
            let incoming = self.incoming_edges(chunk_id);
            for edge in incoming {
                if edge.relation == Relation::Breaks && edge.confidence > 0.7 {
                    failures.push(FailureEvent {
                        chunk_id: chunk_id.clone(),
                        node_id: node.node_id.clone(),
                        severity: edge.weight,
                        propagation_depth: 0,
                        reason: FailureReason::BreaksRelationship,
                    });
                }
            }
        }

        failures
    }

    /// Diffuse risk from a node through the graph
    pub fn diffuse_risk(&mut self, origin: &ChunkId, risk_amount: f32) {
        let affected = self.propagate_failure(origin);

        for chunk_id in affected {
            if let Some(node) = self.nodes.get_mut(&chunk_id) {
                node.risk_score = (node.risk_score + risk_amount * 0.5).min(1.0);
                if node.risk_score > 0.7 {
                    self.high_risk_chunks.insert(chunk_id.clone());
                }
            }
        }
    }

    /// Compute global entropy of the graph
    pub fn compute_entropy(&mut self) -> Entropy {
        if self.nodes.is_empty() {
            self.global_entropy = 0.0;
            return self.global_entropy;
        }

        let _total_edges = self.edges.len() as f32;
        let total_nodes = self.nodes.len() as f32;

        // Entropy based on graph connectivity
        let avg_fan_in = self.nodes.values().map(|n| n.fan_in as f32).sum::<f32>() / total_nodes;
        let avg_fan_out = self.nodes.values().map(|n| n.fan_out as f32).sum::<f32>() / total_nodes;

        // Higher average connectivity = lower entropy (more stable)
        let connectivity_factor = (avg_fan_in + avg_fan_out) / (2.0 * total_nodes.sqrt());

        // Risk factor increases entropy
        let risk_factor = self.high_risk_chunks.len() as f32 / total_nodes;

        self.global_entropy = (1.0 - connectivity_factor.min(1.0)) * 0.6 + risk_factor * 0.4;
        self.global_entropy
    }

    /// Get lineage for a chunk (all ancestors)
    pub fn get_lineage(&self, chunk_id: &ChunkId) -> Vec<ChunkId> {
        let mut lineage = Vec::new();
        let mut visited = HashSet::new();
        let mut stack = vec![chunk_id.clone()];

        while let Some(node) = stack.pop() {
            if visited.contains(&node) {
                continue;
            }
            visited.insert(node.clone());

            for edge in self.incoming_edges(&node) {
                if edge.relation == Relation::DependsOn || edge.relation == Relation::Derived {
                    lineage.push(edge.from.clone());
                    stack.push(edge.from.clone());
                }
            }
        }

        lineage
    }

    /// Get dependents for a chunk (all descendants)
    pub fn get_dependents(&self, chunk_id: &ChunkId) -> Vec<ChunkId> {
        let mut dependents = Vec::new();
        let mut visited = HashSet::new();
        let mut stack = vec![chunk_id.clone()];

        while let Some(node) = stack.pop() {
            if visited.contains(&node) {
                continue;
            }
            visited.insert(node.clone());

            for edge in self.outgoing_edges(&node) {
                if edge.relation == Relation::DependsOn || edge.relation == Relation::Derived {
                    dependents.push(edge.to.clone());
                    stack.push(edge.to.clone());
                }
            }
        }

        dependents
    }
}

/// Failure event in the causality system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FailureEvent {
    /// Chunk that failed
    pub chunk_id: ChunkId,
    /// Node responsible
    pub node_id: NodeId,
    /// Severity of failure (0.0 to 1.0)
    pub severity: Severity,
    /// How deep the failure propagated
    pub propagation_depth: u32,
    /// Reason for the failure
    pub reason: FailureReason,
}

/// Reasons for failures
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum FailureReason {
    /// Low trust score with high fan-in
    LowTrustHighFanIn,
    /// Breaks relationship detected
    BreaksRelationship,
    /// CVE detected
    CVEDetected,
    /// Reproducibility failure
    ReproducibilityFailure,
    /// Temporal inconsistency
    TemporalInconsistency,
    /// Counterfactual failure
    CounterfactualFailure,
    /// Reality divergence
    RealityDivergence,
    /// External validation failure
    ExternalValidationFailure,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_causality_graph_creation() {
        let graph = CausalityGraph::new();
        assert_eq!(graph.nodes.len(), 0);
        assert_eq!(graph.edges.len(), 0);
    }

    #[test]
    fn test_add_edge() {
        let mut graph = CausalityGraph::new();

        let edge = CausalEdge {
            from: "chunk_a".to_string(),
            to: "chunk_b".to_string(),
            weight: 0.9,
            confidence: 0.95,
            relation: Relation::DependsOn,
            timestamp: Timestamp::now(),
        };

        graph.add_edge(edge);

        assert_eq!(graph.nodes.len(), 2);
        assert_eq!(graph.edges.len(), 1);
    }

    #[test]
    fn test_failure_propagation() {
        let mut graph = CausalityGraph::new();

        graph.add_edge(CausalEdge {
            from: "A".into(),
            to: "B".into(),
            weight: 0.9,
            confidence: 1.0,
            relation: Relation::DependsOn,
            timestamp: Timestamp::now(),
        });

        graph.add_edge(CausalEdge {
            from: "B".into(),
            to: "C".into(),
            weight: 0.8,
            confidence: 1.0,
            relation: Relation::DependsOn,
            timestamp: Timestamp::now(),
        });

        let affected = graph.propagate_failure(&"A".into());

        assert!(affected.contains(&"B".to_string()));
        assert!(affected.contains(&"C".to_string()));
    }
}
