//! BKG CVE Diffusion Engine
//!
//! Tracks CVE propagation and risk diffusion through the causality graph.

use crate::causality::graph::CausalityGraph;
use crate::core::*;
use serde::{Deserialize, Serialize};

/// CVE node impact assessment
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CveNodeImpact {
    /// CVE identifier
    pub cve_id: String,
    /// Chunks affected by this CVE
    pub affected_chunks: Vec<ChunkId>,
    /// Severity score (0.0 to 1.0)
    pub severity: f32,
    /// Risk diffusion factor
    pub diffusion_factor: f32,
    /// Timestamp of assessment
    pub assessed_at: Timestamp,
}

/// CVE entry in the database
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CveEntry {
    /// CVE identifier
    pub cve_id: String,
    /// Description
    pub description: String,
    /// Base severity (0.0 to 1.0)
    pub base_severity: f32,
    /// Affected package patterns
    pub affected_patterns: Vec<String>,
    /// Patch available
    pub patch_available: bool,
    /// Exploitation status
    pub exploited_in_wild: bool,
}

/// CVE diffusion engine for risk propagation
#[derive(Debug, Clone)]
pub struct CveDiffusionEngine {
    /// Known CVEs
    pub cve_database: HashMap<String, CveEntry>,
    /// Active CVE impacts
    pub active_impacts: Vec<CveNodeImpact>,
}

impl Default for CveDiffusionEngine {
    fn default() -> Self {
        Self::new()
    }
}

impl CveDiffusionEngine {
    /// Create a new CVE diffusion engine
    pub fn new() -> Self {
        Self {
            cve_database: HashMap::new(),
            active_impacts: Vec::new(),
        }
    }

    /// Register a new CVE
    pub fn register_cve(&mut self, cve: CveEntry) {
        self.cve_database.insert(cve.cve_id.clone(), cve);
    }

    /// Propagate CVE risk through the graph
    pub fn propagate(&mut self, cve_id: &str, graph: &CausalityGraph) -> Option<CveNodeImpact> {
        let cve = self.cve_database.get(cve_id)?;

        // Find affected chunks based on patterns
        let affected_chunks: Vec<ChunkId> = graph
            .nodes
            .keys()
            .filter(|chunk_id| {
                cve.affected_patterns
                    .iter()
                    .any(|pattern| chunk_id.contains(pattern))
            })
            .cloned()
            .collect();

        // Calculate diffusion based on graph structure
        let mut total_risk = 0.0;
        for chunk in &affected_chunks {
            let dependents = graph.get_dependents(chunk);
            total_risk += dependents.len() as f32;
        }

        let diffusion_factor = if !affected_chunks.is_empty() {
            total_risk / affected_chunks.len() as f32
        } else {
            0.0
        };

        let impact = CveNodeImpact {
            cve_id: cve_id.to_string(),
            affected_chunks: affected_chunks.clone(),
            severity: cve.base_severity,
            diffusion_factor: diffusion_factor.min(1.0),
            assessed_at: Timestamp::now(),
        };

        self.active_impacts.push(impact.clone());
        Some(impact)
    }

    /// Get active CVE impacts for a specific chunk
    pub fn get_chunk_impacts(&self, chunk_id: &ChunkId) -> Vec<&CveNodeImpact> {
        self.active_impacts
            .iter()
            .filter(|impact| impact.affected_chunks.contains(chunk_id))
            .collect()
    }

    /// Calculate overall CVE risk for the system
    pub fn compute_system_risk(&self) -> f32 {
        if self.active_impacts.is_empty() {
            return 0.0;
        }

        let total_severity: f32 = self
            .active_impacts
            .iter()
            .map(|i| i.severity * i.diffusion_factor)
            .sum();

        (total_severity / self.active_impacts.len() as f32).min(1.0)
    }

    /// Clear inactive CVE impacts
    pub fn cleanup_inactive(&mut self, max_age_ms: u64) {
        let now = Timestamp::now().0;
        self.active_impacts
            .retain(|impact| now - impact.assessed_at.0 < max_age_ms);
    }
}

use std::collections::HashMap;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cve_engine_creation() {
        let engine = CveDiffusionEngine::new();
        assert_eq!(engine.cve_database.len(), 0);
    }

    #[test]
    fn test_cve_registration() {
        let mut engine = CveDiffusionEngine::new();

        let cve = CveEntry {
            cve_id: "CVE-2024-0001".to_string(),
            description: "Test CVE".to_string(),
            base_severity: 0.8,
            affected_patterns: vec!["unsafe".to_string()],
            patch_available: false,
            exploited_in_wild: false,
        };

        engine.register_cve(cve);

        assert!(engine.cve_database.contains_key("CVE-2024-0001"));
    }
}
