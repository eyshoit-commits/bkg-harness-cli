//! BKG Causality Module
//!
//! Causal relationship tracking and failure propagation.

pub mod cve_map;
pub mod graph;

pub use cve_map::{CveDiffusionEngine, CveEntry, CveNodeImpact};
pub use graph::{CausalEdge, CausalNode, CausalityGraph, FailureEvent, FailureReason, Relation};
