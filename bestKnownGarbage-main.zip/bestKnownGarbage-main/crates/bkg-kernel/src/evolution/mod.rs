//! BKG Evolution Module
//!
//! Self-modifying epistemic governance with bounded causal evolution.

use crate::core::*;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Trust rule for evolution
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TrustRule {
    /// Rule identifier
    pub rule_id: String,
    /// Weight for reproducibility
    pub w_reproducibility: f32,
    /// Weight for causality
    pub w_causality: f32,
    /// Weight for cross-node validation
    pub w_cross_node: f32,
    /// Weight for entropy penalty
    pub w_entropy_penalty: f32,
    /// Epoch when activated
    pub activation_epoch: Epoch,
    /// Parent rule ID
    pub parent_rule: Option<String>,
    /// Rule metadata
    pub metadata: HashMap<String, String>,
}

impl Default for TrustRule {
    fn default() -> Self {
        Self {
            rule_id: "default".to_string(),
            w_reproducibility: 0.4,
            w_causality: 0.3,
            w_cross_node: 0.2,
            w_entropy_penalty: 0.1,
            activation_epoch: 0,
            parent_rule: None,
            metadata: HashMap::new(),
        }
    }
}

/// Rule evolution proposal
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleProposal {
    /// Proposed rule
    pub proposed_rule: TrustRule,
    /// Reason for proposal
    pub reason: String,
    /// Node that submitted
    pub submitted_by: NodeId,
    /// Simulation hash
    pub simulation_hash: Hash,
    /// Replay batch ID
    pub replay_batch_id: String,
    /// Proposal timestamp
    pub timestamp: Timestamp,
}

/// Simulation result for rule evolution
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationResult {
    /// Whether simulation was stable
    pub stable: bool,
    /// Delta from baseline
    pub delta: f32,
    /// Pass rate
    pub pass_rate: f32,
    /// Details
    pub details: String,
}

/// Rule simulator
#[derive(Debug, Clone, Default)]
pub struct RuleSimulator {
    /// Simulation history
    pub history: Vec<(String, SimulationResult)>,
}

impl RuleSimulator {
    /// Create a new rule simulator
    pub fn new() -> Self {
        Self::default()
    }

    /// Simulate a rule change
    pub fn simulate(&mut self, rule: &TrustRule, baseline_scores: &[f32]) -> SimulationResult {
        let mut score_delta = 0.0;
        let _baseline_mean = if !baseline_scores.is_empty() {
            baseline_scores.iter().sum::<f32>() / baseline_scores.len() as f32
        } else {
            0.5
        };

        // Calculate new scores with rule
        for &baseline in baseline_scores {
            let new_score = self.apply_rule(rule, baseline);
            score_delta += (new_score - baseline).abs();
        }

        let stable = score_delta < 0.15 * baseline_scores.len() as f32;
        let pass_rate = if stable { 1.0 } else { 0.5 };

        let result = SimulationResult {
            stable,
            delta: score_delta,
            pass_rate,
            details: if stable {
                "Rule is stable".to_string()
            } else {
                format!("Rule caused delta: {}", score_delta)
            },
        };

        self.history.push((rule.rule_id.clone(), result.clone()));
        result
    }

    /// Apply rule to calculate score
    ///
    /// Each weight contributes proportionally to the simulated score.
    /// A balanced rule (weights sum ≈ 1.0) produces scores close to baseline.
    fn apply_rule(&self, rule: &TrustRule, baseline: f32) -> f32 {
        let reproducibility = rule.w_reproducibility * baseline;
        let causality = rule.w_causality * baseline;
        let cross_node = rule.w_cross_node * baseline;
        let entropy_penalty = rule.w_entropy_penalty * (1.0 - baseline);

        reproducibility + causality + cross_node - entropy_penalty
    }
}

/// Safety invariants for rule evolution
pub struct SafetyInvariants;

impl SafetyInvariants {
    /// Check if a rule satisfies safety invariants
    pub fn check(rule: &TrustRule) -> bool {
        // 1. Must not kill trust completely
        if rule.w_reproducibility < 0.1 {
            return false;
        }

        // 2. Causality must remain dominant
        if rule.w_causality < 0.2 {
            return false;
        }

        // 3. Entropy penalty cannot be ignored
        if rule.w_entropy_penalty < 0.05 {
            return false;
        }

        // 4. Weights must sum to approximately 1.0
        let sum =
            rule.w_reproducibility + rule.w_causality + rule.w_cross_node + rule.w_entropy_penalty;

        if (sum - 1.0).abs() > 0.1 {
            return false;
        }

        true
    }
}

/// Consensus swarm for rule validation
#[derive(Debug, Clone, Default)]
pub struct ConsensusSwarm {
    /// Votes per proposal
    pub votes: HashMap<String, Vec<(NodeId, bool)>>,
}

impl ConsensusSwarm {
    /// Create a new consensus swarm
    pub fn new() -> Self {
        Self::default()
    }

    /// Vote on a proposal
    pub fn vote(&mut self, proposal_hash: &str, node_id: NodeId, approve: bool) {
        self.votes
            .entry(proposal_hash.to_string())
            .or_default()
            .push((node_id, approve));
    }

    /// Validate if consensus reached
    pub fn validate(&self, proposal_hash: &str, nodes: &[NodeId]) -> bool {
        let votes = match self.votes.get(proposal_hash) {
            Some(v) => v,
            None => return false,
        };

        let required = (nodes.len() as f32 * 0.67) as usize;
        let approvals = votes.iter().filter(|(_, approve)| *approve).count();

        approvals >= required && nodes.len() > 3
    }
}

/// Rollback engine for safe evolution
#[derive(Debug, Clone, Default)]
pub struct RollbackEngine {
    /// Rule history
    pub history: Vec<TrustRule>,
    /// Max history size
    pub max_history: usize,
}

impl RollbackEngine {
    /// Create a new rollback engine
    pub fn new() -> Self {
        Self {
            max_history: 100,
            ..Default::default()
        }
    }

    /// Checkpoint current rule
    pub fn checkpoint(&mut self, rule: TrustRule) {
        self.history.push(rule);

        // Enforce max size
        if self.history.len() > self.max_history {
            self.history.remove(0);
        }
    }

    /// Rollback to previous rule
    pub fn rollback(&mut self) -> Option<TrustRule> {
        self.history.pop()
    }

    /// Get current rule
    pub fn current(&self) -> Option<&TrustRule> {
        self.history.last()
    }
}

/// Motherbrain evolution loop
#[derive(Debug, Clone)]
pub struct MotherbrainEvolutionLoop {
    /// Rule simulator
    pub simulator: RuleSimulator,
    /// Consensus swarm
    pub consensus: ConsensusSwarm,
    /// Rollback engine
    pub rollback: RollbackEngine,
    /// Active rule
    pub active_rule: TrustRule,
    /// Evolution epoch
    pub epoch: Epoch,
    /// Pending proposals
    pub pending_proposals: Vec<RuleProposal>,
    /// Rejected proposals
    pub rejected_proposals: Vec<RuleProposal>,
}

impl MotherbrainEvolutionLoop {
    /// Create a new evolution loop
    pub fn new() -> Self {
        Self {
            simulator: RuleSimulator::new(),
            consensus: ConsensusSwarm::new(),
            rollback: RollbackEngine::new(),
            active_rule: TrustRule::default(),
            epoch: 0,
            pending_proposals: Vec::new(),
            rejected_proposals: Vec::new(),
        }
    }

    /// Submit a rule proposal
    pub fn submit_proposal(&mut self, proposal: RuleProposal) {
        self.pending_proposals.push(proposal);
    }

    /// Process a proposal for evolution
    pub fn evolve(
        &mut self,
        proposal: RuleProposal,
        baseline_scores: &[f32],
        nodes: &[NodeId],
    ) -> bool {
        // STEP 1: Safety gate
        if !SafetyInvariants::check(&proposal.proposed_rule) {
            self.rejected_proposals.push(proposal);
            return false;
        }

        // STEP 2: Simulation
        let sim_result = self
            .simulator
            .simulate(&proposal.proposed_rule, baseline_scores);
        if !sim_result.stable {
            self.rejected_proposals.push(proposal);
            return false;
        }

        // STEP 3: Consensus
        let consensus_ok = self.consensus.validate(&proposal.simulation_hash, nodes);
        if !consensus_ok {
            self.rejected_proposals.push(proposal);
            return false;
        }

        // STEP 4: Commit with checkpoint
        self.rollback.checkpoint(self.active_rule.clone());

        // Update active rule
        let mut new_rule = proposal.proposed_rule.clone();
        new_rule.parent_rule = Some(self.active_rule.rule_id.clone());
        new_rule.activation_epoch = self.epoch;

        self.active_rule = new_rule;
        self.epoch += 1;

        true
    }

    /// Force rollback to previous rule
    pub fn force_rollback(&mut self) -> Option<TrustRule> {
        self.rollback.rollback().inspect(|rule| {
            self.active_rule = rule.clone();
            self.epoch += 1;
        })
    }

    /// Get evolution history
    pub fn history(&self) -> &[TrustRule] {
        &self.rollback.history
    }
}

impl Default for MotherbrainEvolutionLoop {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_trust_rule_default() {
        let rule = TrustRule::default();
        assert_eq!(rule.rule_id, "default");
    }

    #[test]
    fn test_safety_invariants() {
        let good_rule = TrustRule::default();
        assert!(SafetyInvariants::check(&good_rule));

        let bad_rule = TrustRule {
            w_reproducibility: 0.0,
            ..Default::default()
        };
        assert!(!SafetyInvariants::check(&bad_rule));
    }

    #[test]
    fn test_rule_simulation() {
        let mut simulator = RuleSimulator::new();
        let rule = TrustRule::default();
        let baseline = vec![0.8, 0.85, 0.9];

        let result = simulator.simulate(&rule, &baseline);

        assert!(result.stable);
    }

    #[test]
    fn test_rollback() {
        let mut engine = RollbackEngine::new();

        let rule1 = TrustRule {
            rule_id: "rule_1".into(),
            ..Default::default()
        };

        let rule2 = TrustRule {
            rule_id: "rule_2".into(),
            ..Default::default()
        };

        engine.checkpoint(rule1);
        engine.checkpoint(rule2);

        let rolled_back = engine.rollback();

        assert!(rolled_back.is_some());
        assert_eq!(rolled_back.unwrap().rule_id, "rule_2");
    }

    #[test]
    fn test_evolution_loop() {
        let mut loop_ = MotherbrainEvolutionLoop::new();

        let proposal = RuleProposal {
            proposed_rule: TrustRule::default(),
            reason: "Initial rule".into(),
            submitted_by: "node_1".into(),
            simulation_hash: "hash".into(),
            replay_batch_id: "batch_1".into(),
            timestamp: Timestamp::now(),
        };

        let nodes = vec![
            "node_1".into(),
            "node_2".into(),
            "node_3".into(),
            "node_4".into(),
        ];
        let baseline = vec![0.8, 0.85];

        // Vote on the proposal
        loop_.consensus.vote("hash", "node_1".into(), true);
        loop_.consensus.vote("hash", "node_2".into(), true);
        loop_.consensus.vote("hash", "node_3".into(), true);

        let result = loop_.evolve(proposal, &baseline, &nodes);

        assert!(result);
    }
}
