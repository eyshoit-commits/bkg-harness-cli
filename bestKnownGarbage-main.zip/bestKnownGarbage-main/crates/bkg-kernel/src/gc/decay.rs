use serde::{Deserialize, Serialize};
///
/// The score is a float between 0.0 (no decay) and 1.0 (fully decayed).
/// GC does NOT modify the ledger; it only computes the score for later use.
#[derive(Debug, Clone)]
pub struct DecayTagger {
    /// Base decay rate per day (applied when no other info)
    base_daily_decay: f32,
}

impl DecayTagger {
    pub fn new(base_daily_decay: f32) -> Self {
        Self { base_daily_decay }
    }

    /// Compute decay score for an entry.
    ///
    /// Parameters:
    /// - age_days: days since last verification
    /// - replay_success_rate: fraction of replays that succeeded (0..1)
    /// - trust_variance: variance of trust among nodes that verified this entry
    pub fn compute_score(
        &self,
        age_days: u64,
        replay_success_rate: f32,
        trust_variance: f32,
    ) -> f32 {
        let age_factor = (age_days as f32) * self.base_daily_decay;
        let replay_penalty = (1.0 - replay_success_rate) * 0.5;
        let variance_penalty = trust_variance * 0.3;
        (age_factor + replay_penalty + variance_penalty).min(1.0)
    }
}

impl Default for DecayTagger {
    fn default() -> Self {
        Self::new(0.01) // 1% decay per day
    }
}

/// A decay score with accompanying metadata.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecayScore {
    pub value: f32,
    pub components: DecayComponents,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DecayComponents {
    pub age_days: u64,
    pub replay_success_rate: f32,
    pub trust_variance: f32,
}

impl DecayScore {
    pub fn new(value: f32, components: DecayComponents) -> Self {
        Self { value, components }
    }

    /// Whether this entry should be considered for archival (high decay).
    pub fn is_archival_candidate(&self, threshold: f32) -> bool {
        self.value >= threshold
    }
}
