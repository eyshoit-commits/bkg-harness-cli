use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// Storage tiers for archival.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Tier {
    Hot,    // recent, frequently accessed
    Warm,   // less recent, occasional access
    Cold,   // long-term storage, rarely accessed
    Frozen, // archival, immutable, never deleted
}

impl Tier {
    pub fn as_str(&self) -> &'static str {
        match self {
            Tier::Hot => "hot",
            Tier::Warm => "warm",
            Tier::Cold => "cold",
            Tier::Frozen => "frozen",
        }
    }
}

/// ArchiveManager handles tiered storage of cold data.
///
/// In this observational phase, GC only writes to cold/frozen tiers.
/// No deletions occur; entries are moved to lower tiers based on policy.
#[derive(Debug, Clone)]
pub struct ArchiveManager {
    base_path: PathBuf,
}

impl ArchiveManager {
    /// Create a new archive manager with the given base directory.
    pub fn new(base_path: PathBuf) -> Self {
        Self { base_path }
    }

    /// Determine which tier an entry belongs to based on age and activity.
    /// This is a simple policy; will become adaptive later.
    pub fn tier_for_entry(&self, age_days: u64, _replay_count: u64) -> Tier {
        if age_days < 7 {
            Tier::Hot
        } else if age_days < 30 {
            Tier::Warm
        } else if age_days < 365 {
            Tier::Cold
        } else {
            Tier::Frozen
        }
    }

    /// Move an entry to its appropriate storage tier.
    ///
    /// Creates the tier subdirectory (if missing) so that the caller can write
    /// the entry data into `tier_path(tier) / <entry_id>`. For cold/frozen
    /// tiers the caller should also apply compression before writing.
    pub async fn ensure_tiered(&self, entry_id: &str, age_days: u64, replay_count: u64) {
        let tier = self.tier_for_entry(age_days, replay_count);
        let tier_dir = self.tier_path(tier);

        if let Err(e) = tokio::fs::create_dir_all(&tier_dir).await {
            tracing::warn!(
                "Failed to create tier directory {:?} for entry {}: {}",
                tier_dir,
                entry_id,
                e,
            );
            return;
        }

        let dest = tier_dir.join(entry_id);
        tracing::info!(
            "Archived entry {} to {:?} tier ({})",
            entry_id,
            tier,
            dest.display()
        );
    }

    /// Get the path for a given tier.
    pub fn tier_path(&self, tier: Tier) -> PathBuf {
        self.base_path.join(tier.as_str())
    }
}

impl Default for ArchiveManager {
    fn default() -> Self {
        Self::new(std::path::PathBuf::from("./archive"))
    }
}
