//! Garbage Collector Foundation (Observational Lymphatic Layer)
//!
//! GCs are strictly observational: they measure, classify, and recommend
//! but never take autonomous action. All disruptive operations require
//! Motherbrain approval.
//!
//! Philosophy:
//! - Read-heavy, write-light (only archival writes)
//! - Entropy mapping and health scoring
//! - Replay dust compression
//! - Decay tagging (mark-only)
//! - Topology observation

pub mod archive;
pub mod collector;
pub mod decay;
pub mod entropy;
pub mod topology;

pub use crate::mesh::EntropyRegion;
pub use archive::{ArchiveManager, Tier};
pub use collector::GarbageCollector;
pub use decay::{DecayScore, DecayTagger};
pub use entropy::EntropyTracker;
pub use topology::TopologyObserver;

/// Action modes for GCs. Initial phase: ObserveOnly.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum GcActionMode {
    /// Only observe and measure; no actions taken.
    #[default]
    ObserveOnly,
    /// Can send recommendations to Motherbrain.
    Suggest,
    /// Can escalate urgent alerts.
    Escalate,
    /// Can take approved autonomous actions (future, highly restricted).
    Autonomous,
}
