use super::decay::{DecayScore, DecayTagger};
use super::{ArchiveManager, EntropyTracker, GcActionMode, TopologyObserver};
use crate::mesh::{MeshMessage, MeshNode};
use std::sync::Arc;
use tokio::sync::RwLock;
use tokio::time::{Duration, interval};

/// The Garbage Collector node (observational).
///
/// It connects to the Mesh and processes incoming messages to update
/// internal state. In this phase, it only measures and tags; it does
/// NOT take autonomous action.
#[derive(Debug)]
pub struct GarbageCollector {
    entropy_tracker: EntropyTracker,
    topology: TopologyObserver,
    decay_tagger: DecayTagger,
    archive: ArchiveManager,
    action_mode: RwLock<GcActionMode>,
}

impl GarbageCollector {
    /// Create a new GC with default components.
    pub fn new(archive_path: Option<std::path::PathBuf>) -> Self {
        let entropy_tracker = EntropyTracker::new();
        let topology = TopologyObserver::new(entropy_tracker.clone());
        let decay_tagger = DecayTagger::default();
        let archive = ArchiveManager::new(
            archive_path.unwrap_or_else(|| std::path::PathBuf::from("./archive")),
        );
        let action_mode = RwLock::new(GcActionMode::ObserveOnly);

        Self {
            entropy_tracker,
            topology,
            decay_tagger,
            archive,
            action_mode,
        }
    }

    /// Process an incoming mesh message (to be called from Mesh message handler).
    pub async fn handle_mesh_message(&self, msg: MeshMessage) {
        match msg {
            MeshMessage::EntropyMap { regions } => {
                self.entropy_tracker.ingest_regions(regions).await;
            }
            _ => {
                // GC only cares about EntropyMap; other messages ignored
            }
        }
    }

    /// Get the current global health score (0..1).
    pub async fn global_health(&self) -> f32 {
        self.entropy_tracker.global_health().await
    }

    /// Get the topology observer.
    pub fn topology(&self) -> &TopologyObserver {
        &self.topology
    }

    /// Get the entropy tracker.
    pub fn entropy_tracker(&self) -> &EntropyTracker {
        &self.entropy_tracker
    }

    /// Get the archive manager.
    pub fn archive(&self) -> &ArchiveManager {
        &self.archive
    }

    /// Compute decay score for a ledger entry (example parameters).
    /// This is read-only; it does not mutate any ledger.
    pub fn compute_decay(
        &self,
        age_days: u64,
        replay_success_rate: f32,
        trust_variance: f32,
    ) -> DecayScore {
        let value = self
            .decay_tagger
            .compute_score(age_days, replay_success_rate, trust_variance);
        DecayScore {
            value,
            components: super::decay::DecayComponents {
                age_days,
                replay_success_rate,
                trust_variance,
            },
        }
    }

    /// Current action mode (e.g., ObserveOnly). Can be upgraded later via Motherbrain.
    pub async fn action_mode(&self) -> GcActionMode {
        *self.action_mode.read().await
    }

    /// Upgrade action mode (typically from Motherbrain command).
    pub async fn set_action_mode(&self, mode: GcActionMode) {
        let mut guard = self.action_mode.write().await;
        *guard = mode;
    }

    /// Start a background task that periodically polls the MeshNode for entropy regions.
    /// This is the primary way GC observes the network in observational phase.
    pub fn start_observing(self: Arc<Self>, mesh_node: Arc<MeshNode>, poll_interval: Duration) {
        tokio::spawn(async move {
            let mut ticker = interval(poll_interval);
            loop {
                ticker.tick().await;
                let regions = mesh_node.entropy_snapshot().await;
                self.entropy_tracker.ingest_regions(regions).await;
            }
        });
    }

    /// Placeholder: suggest archiving an entry based on decay score.
    pub async fn maybe_suggest_archive(&self, entry_id: &str, decay: &DecayScore) {
        if decay.is_archival_candidate(0.5) {
            // In ObserveOnly mode, we just log. Motherbrain could later call archive.ensure_tiered()
            tracing::debug!(
                "GC suggests archival for entry {} (decay={:.3})",
                entry_id,
                decay.value
            );
        }
    }
}

impl Default for GarbageCollector {
    fn default() -> Self {
        Self::new(None)
    }
}
