use super::entropy::EntropyTracker;

/// TopologyObserver consumes entropy maps and peer lists to assess network health.
///
/// It does NOT modify topology; it only computes metrics like:
/// - number of active subnets
/// - average trust variance across the mesh
/// - presence of isolated regions
#[derive(Debug, Clone)]
pub struct TopologyObserver {
    entropy_tracker: EntropyTracker,
}

impl TopologyObserver {
    pub fn new(entropy_tracker: EntropyTracker) -> Self {
        Self { entropy_tracker }
    }

    /// Number of distinct subnets observed.
    pub async fn subnet_count(&self) -> usize {
        self.entropy_tracker.snapshot().await.len()
    }

    /// Global average trust variance (across all regions).
    pub async fn average_trust_variance(&self) -> f32 {
        let snapshot = self.entropy_tracker.snapshot().await;
        if snapshot.is_empty() {
            return 0.0;
        }
        let sum: f32 = snapshot.values().map(|r| r.trust_variance).sum();
        sum / snapshot.len() as f32
    }

    /// Regions with health below threshold may indicate instability.
    pub async fn unstable_regions(&self, health_threshold: f32) -> Vec<String> {
        self.entropy_tracker
            .unhealthy_regions(health_threshold)
            .await
            .into_iter()
            .map(|r| r.subnet_id)
            .collect()
    }

    /// Overall topology health: combination of subnet count and average variance.
    /// Returns 0.0 (unhealthy) to 1.0 (perfect).
    pub async fn health_score(&self) -> f32 {
        let subnet_factor = (self.subnet_count().await as f32 / 10.0).min(1.0); // assume 10 subnets ideal
        let variance = self.average_trust_variance().await;
        let variance_factor = 1.0 - variance; // lower variance = higher factor
        (subnet_factor + variance_factor) / 2.0
    }
}
