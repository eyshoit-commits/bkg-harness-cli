use crate::mesh::EntropyRegion;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

/// Tracks entropy regions across the mesh network.
///
/// GCs consume `MeshMessage::EntropyMap` to build a global view of
/// epistemic health. This is read-only observation; no actions taken.
#[derive(Debug, Clone)]
pub struct EntropyTracker {
    regions: Arc<RwLock<HashMap<String, EntropyRegion>>>,
}

impl EntropyTracker {
    /// Create a new entropy tracker.
    pub fn new() -> Self {
        Self {
            regions: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Ingest a batch of entropy regions (from an EntropyMap message).
    pub async fn ingest_regions(&self, regions: Vec<EntropyRegion>) {
        let mut map = self.regions.write().await;
        for region in regions {
            map.insert(region.subnet_id.clone(), region);
        }
    }

    /// Get a snapshot of all known regions.
    pub async fn snapshot(&self) -> HashMap<String, EntropyRegion> {
        self.regions.read().await.clone()
    }

    /// Compute global average health score across all regions.
    /// Lower score = more entropy/instability.
    pub async fn global_health(&self) -> f32 {
        let map = self.regions.read().await;
        if map.is_empty() {
            return 1.0; // perfect health when no data
        }
        let sum: f32 = map.values().map(|r| r.health_score()).sum();
        sum / map.len() as f32
    }

    /// Find regions with health below threshold.
    pub async fn unhealthy_regions(&self, threshold: f32) -> Vec<EntropyRegion> {
        self.regions
            .read()
            .await
            .values()
            .filter(|r| r.health_score() < threshold)
            .cloned()
            .collect()
    }
}

impl Default for EntropyTracker {
    fn default() -> Self {
        Self::new()
    }
}
