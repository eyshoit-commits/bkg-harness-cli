//! BKG errors — shared crate
