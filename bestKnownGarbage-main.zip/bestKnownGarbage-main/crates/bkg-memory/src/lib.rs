//! Self-Healing Memory — MEMORY.md authority with SQLite FTS5 derivative index.
//!
//! Ported from mythos-router. See `/home/bkg/workspace/mythos-router/src/memory.ts`
//!
//! Authority Chain:
//!   1. MEMORY.md is the Sole Authority (Markdown)
//!   2. SQLite FTS5 is a Derivative Index (fully disposable)
//!   3. SHA-256 manifest hash verifies integrity

use rusqlite::{Connection, params};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs;
use std::path::PathBuf;

// ── Types ────────────────────────────────────────────────────

/// A single memory entry from MEMORY.md
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryEntry {
    pub timestamp: String,
    pub action: String,
    pub result: String,
}

/// Memory file content breakdown.
#[derive(Debug, Clone)]
pub struct MemoryContent {
    pub header: String,
    pub entries: Vec<MemoryEntry>,
    pub raw: String,
}

/// Errors from memory operations.
#[derive(Debug, thiserror::Error)]
pub enum MemoryError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("SQLite error: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("Parse error: {0}")]
    Parse(String),
}

type Result<T> = std::result::Result<T, MemoryError>;

// ── Configuration ─────────────────────────────────────────────

const MEMORY_FILE: &str = "MEMORY.md";
const MEMORY_DB_FILE: &str = "memory.db";
const MEMORY_MAX_ENTRIES: usize = 100;
const MEMORY_ENTRY_MAX_CHARS: usize = 120;

// ── Core API ──────────────────────────────────────────────────

/// The self-healing memory manager.
pub struct MemoryManager {
    working_dir: PathBuf,
    db: Option<Connection>,
}

impl MemoryManager {
    /// Create a new memory manager for the given working directory.
    pub fn new(working_dir: PathBuf) -> Self {
        let mut mgr = Self {
            working_dir,
            db: None,
        };
        let _ = mgr.init_db();
        mgr
    }

    fn memory_path(&self) -> PathBuf {
        self.working_dir.join(MEMORY_FILE)
    }

    fn db_path(&self) -> PathBuf {
        self.working_dir.join(MEMORY_DB_FILE)
    }

    /// Initialize MEMORY.md and SQLite index.
    pub fn init(&mut self) -> Result<()> {
        let path = self.memory_path();
        if !path.exists() {
            let header = format!(
                "# MEMORY.md — Agentic Memory\n\n\
                > Auto-managed by the BKG memory system.\n\
                > When entries exceed {}, a \"Dream\" compresses older context.\n\n\
                ---\n\n\
                | Timestamp | Action | Verified Result |\n\
                |-----------|--------|----------------|\n",
                MEMORY_MAX_ENTRIES
            );
            fs::write(&path, header)?;
        }

        self.init_db()?;
        self.reconcile()?;
        Ok(())
    }

    fn init_db(&mut self) -> Result<()> {
        let path = self.db_path();
        let db = Connection::open(&path)?;

        db.execute_batch(
            "PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS sync_cache (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            CREATE TABLE IF NOT EXISTS memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                action TEXT NOT NULL,
                result TEXT NOT NULL
            );
            CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
                action, result, content='memory', content_rowid='id', tokenize='unicode61'
            );
            CREATE TRIGGER IF NOT EXISTS memory_ai AFTER INSERT ON memory BEGIN
                INSERT INTO memory_fts(rowid, action, result) VALUES (new.id, new.action, new.result);
            END;
            CREATE TRIGGER IF NOT EXISTS memory_ad AFTER DELETE ON memory BEGIN
                DELETE FROM memory_fts WHERE rowid = old.id;
            END;
            CREATE TRIGGER IF NOT EXISTS memory_au AFTER UPDATE ON memory BEGIN
                INSERT INTO memory_fts(rowid, action, result) VALUES (new.id, new.action, new.result);
            END;",
        )?;

        self.db = Some(db);
        Ok(())
    }

    /// Reconcile the derivative index with MEMORY.md authority.
    fn reconcile(&mut self) -> Result<()> {
        let current_hash = self.calculate_memory_hash()?;

        let stored_hash = self.db.as_ref().and_then(|db| {
            db.query_row(
                "SELECT value FROM sync_cache WHERE key = ?1",
                params!["manifest_hash"],
                |row| row.get::<_, String>(0),
            )
            .ok()
        });

        if stored_hash.as_deref() != Some(&current_hash) {
            self.rebuild_index(&current_hash)?;
        }

        Ok(())
    }

    fn calculate_memory_hash(&self) -> Result<String> {
        let path = self.memory_path();
        if !path.exists() {
            return Ok("none".to_string());
        }
        let content = fs::read_to_string(&path)?;
        let hash = Sha256::digest(content.as_bytes());
        Ok(format!("{:x}", hash))
    }

    /// Rebuild the entire SQLite index from MEMORY.md.
    pub fn rebuild_index(&mut self, hash: &str) -> Result<()> {
        let db = self
            .db
            .as_ref()
            .ok_or_else(|| MemoryError::Parse("Database not initialized".to_string()))?;

        let entries = self.parse_memory_file()?;

        db.execute_batch("BEGIN;")?;
        let result = (|| -> Result<()> {
            db.execute("DELETE FROM memory;", [])?;
            db.execute("DELETE FROM memory_fts;", [])?;

            let mut stmt =
                db.prepare("INSERT INTO memory (timestamp, action, result) VALUES (?1, ?2, ?3)")?;

            for entry in &entries {
                stmt.execute(params![entry.timestamp, entry.action, entry.result])?;
            }

            db.execute(
                "INSERT OR REPLACE INTO sync_cache (key, value) VALUES (?1, ?2)",
                params!["manifest_hash", hash],
            )?;

            db.execute_batch("COMMIT;")?;
            Ok(())
        })();

        if result.is_err() {
            let _ = db.execute_batch("ROLLBACK;");
        }

        result
    }

    /// Append an entry to MEMORY.md (authority first) and the index.
    pub fn append_entry(&mut self, action: &str, result: &str) -> Result<()> {
        let path = self.memory_path();
        if !path.exists() {
            self.init()?;
        }

        let ts = chrono::Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();
        let sanitized_action = sanitize(action);
        let sanitized_result = sanitize(result);
        let line = format!("| {} | {} | {} |\n", ts, sanitized_action, sanitized_result);

        // 1. MEMORY.md first (Sole Authority)
        let mut file = fs::OpenOptions::new()
            .append(true)
            .create(true)
            .open(&path)?;
        use std::io::Write;
        writeln!(file, "{}", line.trim())?;

        // 2. Derivative index (best-effort)
        if let Some(ref db) = self.db {
            if let Err(e) = db.execute(
                "INSERT INTO memory (timestamp, action, result) VALUES (?1, ?2, ?3)",
                params![ts, sanitized_action, sanitized_result],
            ) {
                eprintln!("Warning: Failed to update memory index: {}", e);
            } else {
                // Update signpost
                let hash = self.calculate_memory_hash().unwrap_or_default();
                let _ = db.execute(
                    "INSERT OR REPLACE INTO sync_cache (key, value) VALUES (?1, ?2)",
                    params!["manifest_hash", hash],
                );
            }
        }

        Ok(())
    }

    /// Search memory entries using FTS5.
    pub fn search(&self, query: &str) -> Vec<MemoryEntry> {
        let db = match self.db.as_ref() {
            Some(d) => d,
            None => return vec![],
        };

        let mut stmt = match db.prepare(
            "SELECT m.timestamp, m.action, m.result
             FROM memory m
             JOIN memory_fts f ON m.id = f.rowid
             WHERE memory_fts MATCH ?1
             ORDER BY rank
             LIMIT 20",
        ) {
            Ok(s) => s,
            Err(_) => return vec![],
        };

        let rows = stmt.query_map(params![query], |row| {
            Ok(MemoryEntry {
                timestamp: row.get::<_, String>(0)?,
                action: row.get::<_, String>(1)?,
                result: row.get::<_, String>(2)?,
            })
        });

        match rows {
            Ok(r) => r.filter_map(|r| r.ok()).collect(),
            Err(_) => vec![],
        }
    }

    /// Read all entries from MEMORY.md.
    pub fn read_memory(&self) -> MemoryContent {
        let path = self.memory_path();
        if !path.exists() {
            return MemoryContent {
                header: String::new(),
                entries: vec![],
                raw: String::new(),
            };
        }

        let raw = fs::read_to_string(&path).unwrap_or_default();
        let entries = self.parse_memory_file().unwrap_or_default();

        let header = raw
            .lines()
            .take_while(|l| !l.starts_with('|') || l.contains("---") || l.contains("Timestamp"))
            .collect::<Vec<_>>()
            .join("\n");

        MemoryContent {
            header: if header.is_empty() {
                raw.clone()
            } else {
                header
            },
            entries,
            raw,
        }
    }

    /// Parse MEMORY.md table entries.
    fn parse_memory_file(&self) -> Result<Vec<MemoryEntry>> {
        let path = self.memory_path();
        if !path.exists() {
            return Ok(vec![]);
        }

        let raw = fs::read_to_string(&path)?;
        let mut entries = Vec::new();

        for line in raw.lines() {
            if line.starts_with('|') && !line.contains("---") && !line.contains("Timestamp") {
                let cols: Vec<&str> = line
                    .split('|')
                    .map(|s| s.trim())
                    .filter(|s| !s.is_empty())
                    .collect();
                if cols.len() >= 3 {
                    entries.push(MemoryEntry {
                        timestamp: cols[0].to_string(),
                        action: cols[1].to_string(),
                        result: cols[2].to_string(),
                    });
                }
            }
        }

        Ok(entries)
    }

    /// Get entry count.
    pub fn entry_count(&self) -> usize {
        self.read_memory().entries.len()
    }

    /// Check if dream compression is needed.
    pub fn needs_dream(&self) -> bool {
        self.entry_count() > MEMORY_MAX_ENTRIES
    }

    /// Write compressed memory (after a dream).
    pub fn write_compressed(&self, summary: &str, recent_entries: &[MemoryEntry]) -> Result<()> {
        let path = self.memory_path();
        let ts = chrono::Utc::now().format("%Y-%m-%d %H:%M:%S").to_string();

        let mut content = format!(
            "# MEMORY.md — Agentic Memory\n\n\
             > Auto-managed by the BKG memory system.\n\n\
             ---\n\n\
             ## Dream Summary (Compressed {})\n\n{}\n\n\
             ---\n\n\
             ## Recent Entries\n\n\
             | Timestamp | Action | Verified Result |\n\
             |-----------|--------|----------------|\n",
            ts, summary
        );

        for entry in recent_entries {
            content.push_str(&format!(
                "| {} | {} | {} |\n",
                entry.timestamp, entry.action, entry.result
            ));
        }

        fs::write(&path, content)?;
        Ok(())
    }

    /// Get memory context limited to max_chars for system prompt injection.
    pub fn get_context(&self, max_chars: usize) -> String {
        let content = self.read_memory();
        if content.raw.len() <= max_chars {
            return content.raw;
        }
        format!(
            "…[truncated]\n{}",
            &content.raw[content.raw.len() - max_chars..]
        )
    }

    /// Print memory status.
    pub fn print_status(&self) {
        let entries = self.read_memory();
        let count = entries.entries.len();
        let has_dream = entries.raw.contains("## Dream Summary");
        let dream_needed = count > MEMORY_MAX_ENTRIES;

        println!(
            "Memory: {} entries{}{}",
            count,
            if has_dream {
                " (has dream summary)"
            } else {
                ""
            },
            if dream_needed {
                " (dream recommended)"
            } else {
                ""
            },
        );
    }
}

fn sanitize(text: &str) -> String {
    text.replace('|', "∣")
        .replace('\n', " ")
        .chars()
        .take(MEMORY_ENTRY_MAX_CHARS)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_append_and_read() {
        let dir = std::env::temp_dir().join("mem-test");
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();

        let mut mgr = MemoryManager::new(dir.clone());
        mgr.init().unwrap();
        mgr.append_entry("test action", "test result").unwrap();

        let content = mgr.read_memory();
        assert_eq!(content.entries.len(), 1);
        assert_eq!(content.entries[0].action, "test action");

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_search() {
        let dir = std::env::temp_dir().join("mem-search-test");
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();

        let mut mgr = MemoryManager::new(dir.clone());
        mgr.init().unwrap();
        mgr.append_entry("create file foo.txt", "verified").unwrap();
        mgr.append_entry("modify file bar.rs", "verified").unwrap();

        let results = mgr.search("create");
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].action, "create file foo.txt");

        let _ = fs::remove_dir_all(&dir);
    }
}
