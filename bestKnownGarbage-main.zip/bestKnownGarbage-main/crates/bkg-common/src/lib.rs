// bkg-bkg-common — stub. Code migrates from crates/bkg-kernel in Phase 1
