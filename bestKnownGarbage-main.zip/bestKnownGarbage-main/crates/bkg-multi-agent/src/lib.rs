//! # BKG Managed Agent System
//!
//! A structured, role-based multi-agent orchestration layer for BKG.
//!
//! ## Roles
//! - **Manager**: Brain — routes tasks, tracks budget, spawns Executors.
//! - **Executor**: Hands — runs assigned tasks, reports results.
//!
//! ## Budget Policies
//! Three strategies control how the budget is split between Manager ↔ Executors.
//!
//! ## Presets
//! Pre-configured role/budget combos for common scenarios (Anthropic-tiered,
//! Google-tiered, cross-opus, budget, balanced, executor-heavy, manager-heavy,
//! offline-safe).
//!
//! ## Orchestrator
//! System prompt builder + spawn API that enforces depth, budget, and concurrency limits.

use std::collections::BTreeMap;

// Re-export bkg_kernel types that we rely on
pub use bkg_kernel::kernel::WorkerId;

// ──────────────────────────────────────────────
// Errors
// ──────────────────────────────────────────────

/// Error type for managed agent operations.
#[derive(Debug, Clone)]
pub enum ManagedAgentError {
    /// Agent role mismatch.
    RoleMismatch { expected: Role, actual: Role },
    /// Budget exhausted for this cycle/task.
    BudgetExhausted { available: u64, requested: u64 },
    /// Max depth reached.
    MaxDepthReached { depth: u32, max_depth: u32 },
    /// Too many concurrent agents.
    ConcurrencyLimit { current: u32, max_concurrent: u32 },
    /// Unknown preset name.
    UnknownPreset(String),
    /// Agent not found.
    AgentNotFound(WorkerId),
    /// Session not found.
    SessionNotFound(String),
    /// Invalid configuration.
    InvalidConfig(String),
}

impl std::fmt::Display for ManagedAgentError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::RoleMismatch { expected, actual } => {
                write!(f, "role mismatch: expected {expected:?}, got {actual:?}")
            }
            Self::BudgetExhausted {
                available,
                requested,
            } => {
                write!(
                    f,
                    "budget exhausted: {available} available, {requested} requested"
                )
            }
            Self::MaxDepthReached { depth, max_depth } => {
                write!(f, "max depth reached: {depth} >= {max_depth}")
            }
            Self::ConcurrencyLimit {
                current,
                max_concurrent,
            } => {
                write!(
                    f,
                    "concurrency limit: {current} running, max {max_concurrent}"
                )
            }
            Self::UnknownPreset(p) => write!(f, "unknown preset: '{p}'"),
            Self::AgentNotFound(id) => write!(f, "agent not found: '{id}'"),
            Self::SessionNotFound(id) => write!(f, "session not found: '{id}'"),
            Self::InvalidConfig(msg) => write!(f, "invalid config: {msg}"),
        }
    }
}

impl std::error::Error for ManagedAgentError {}

/// Result alias for managed agent operations.
pub type Result<T> = std::result::Result<T, ManagedAgentError>;

// ──────────────────────────────────────────────
// Roles
// ──────────────────────────────────────────────

/// Managed agent role.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Role {
    /// Manager — routes tasks, tracks budget, spawns executors.
    Manager,
    /// Executor — runs assigned tasks, reports results.
    Executor,
}

impl Role {
    #[must_use]
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Manager => "manager",
            Self::Executor => "executor",
        }
    }

    /// Returns true if this role can spawn other agents.
    #[must_use]
    pub fn can_spawn(&self) -> bool {
        matches!(self, Self::Manager)
    }
}

// ──────────────────────────────────────────────
// Budget Allocation
// ──────────────────────────────────────────────

/// How the budget is split between Manager and Executors.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum BudgetPolicy {
    /// 50/50 split — Manager gets half, Executors share half.
    /// Best for balanced scenarios.
    Balanced,
    /// Manager gets minimal budget (10%), Executors share 90%.
    /// Best when the Manager is just a router.
    ExecutorHeavy,
    /// Manager gets most (90%), Executors share 10%.
    /// Best when the Manager does heavy reasoning.
    ManagerHeavy,
    /// Custom split with explicit percentages.
    Custom { manager_pct: u8, executor_pct: u8 },
}

impl BudgetPolicy {
    /// Validate that percentages sum to 100.
    #[must_use]
    pub fn is_valid(&self) -> bool {
        match self {
            Self::Custom {
                manager_pct,
                executor_pct,
            } => {
                let m = *manager_pct;
                let e = *executor_pct;
                m + e == 100
            }
            _ => true,
        }
    }

    /// Get the manager and executor percentages as (manager_pct, executor_pct).
    #[must_use]
    pub fn split(&self) -> (u8, u8) {
        match self {
            Self::Balanced => (50, 50),
            Self::ExecutorHeavy => (10, 90),
            Self::ManagerHeavy => (90, 10),
            Self::Custom {
                manager_pct,
                executor_pct,
            } => (*manager_pct, *executor_pct),
        }
    }
}

impl Default for BudgetPolicy {
    fn default() -> Self {
        Self::Balanced
    }
}

// ──────────────────────────────────────────────
// Budget Tracker
// ──────────────────────────────────────────────

/// Tracks token/step budget for a managed agent session.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ManagedBudgetTracker {
    /// Total budget for this session in tokens.
    total_budget: u64,
    /// Tokens consumed by the Manager.
    manager_consumed: u64,
    /// Tokens consumed by all Executors combined.
    executor_consumed: u64,
    /// The budget split policy.
    policy: BudgetPolicy,
}

impl ManagedBudgetTracker {
    /// Create a new budget tracker.
    #[must_use]
    pub fn new(total_budget: u64, policy: BudgetPolicy) -> Self {
        Self {
            total_budget,
            manager_consumed: 0,
            executor_consumed: 0,
            policy,
        }
    }

    /// Maximum tokens available for the Manager role.
    #[must_use]
    pub fn manager_budget(&self) -> u64 {
        let (manager_pct, _) = self.policy.split();
        (self.total_budget * u64::from(manager_pct)) / 100
    }

    /// Maximum tokens available for Executor roles combined.
    #[must_use]
    pub fn executor_budget(&self) -> u64 {
        let (_, executor_pct) = self.policy.split();
        (self.total_budget * u64::from(executor_pct)) / 100
    }

    /// Remaining budget for the Manager.
    #[must_use]
    pub fn manager_remaining(&self) -> u64 {
        self.manager_budget().saturating_sub(self.manager_consumed)
    }

    /// Remaining budget for all Executors.
    #[must_use]
    pub fn executor_remaining(&self) -> u64 {
        self.executor_budget()
            .saturating_sub(self.executor_consumed)
    }

    /// Total remaining budget.
    #[must_use]
    pub fn total_remaining(&self) -> u64 {
        self.manager_remaining() + self.executor_remaining()
    }

    /// Total consumed budget.
    #[must_use]
    pub fn total_consumed(&self) -> u64 {
        self.manager_consumed + self.executor_consumed
    }

    /// Spend tokens for a given role. Returns error if budget exhausted.
    pub fn spend(&mut self, role: Role, tokens: u64) -> Result<()> {
        match role {
            Role::Manager => {
                if self.manager_remaining() < tokens {
                    return Err(ManagedAgentError::BudgetExhausted {
                        available: self.manager_remaining(),
                        requested: tokens,
                    });
                }
                self.manager_consumed += tokens;
            }
            Role::Executor => {
                if self.executor_remaining() < tokens {
                    return Err(ManagedAgentError::BudgetExhausted {
                        available: self.executor_remaining(),
                        requested: tokens,
                    });
                }
                self.executor_consumed += tokens;
            }
        }
        Ok(())
    }

    /// Check if a role has budget for `tokens` without spending.
    #[must_use]
    pub fn can_spend(&self, role: Role, tokens: u64) -> bool {
        match role {
            Role::Manager => self.manager_remaining() >= tokens,
            Role::Executor => self.executor_remaining() >= tokens,
        }
    }

    /// Usage fraction (0.0 = none used, 1.0 = fully consumed).
    #[must_use]
    pub fn usage_fraction(&self) -> f64 {
        if self.total_budget == 0 {
            return 0.0;
        }
        self.total_consumed() as f64 / self.total_budget as f64
    }

    /// Get the current policy.
    #[must_use]
    pub fn policy(&self) -> BudgetPolicy {
        self.policy
    }

    /// Get total budget.
    #[must_use]
    pub fn total_budget(&self) -> u64 {
        self.total_budget
    }

    /// Reset consumption counters.
    pub fn reset(&mut self) {
        self.manager_consumed = 0;
        self.executor_consumed = 0;
    }
}

// ──────────────────────────────────────────────
// Presets
// ──────────────────────────────────────────────

/// Named preset for agent configuration.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct AgentPreset {
    /// Human-readable name.
    pub name: &'static str,
    /// Description of when to use this preset.
    pub description: &'static str,
    /// Budget split policy.
    pub budget_policy: BudgetPolicy,
    /// Max spawn depth.
    pub max_depth: u32,
    /// Max concurrent executors.
    pub max_concurrent: u32,
    /// Default token budget (0 = no limit).
    pub default_budget: u64,
    /// Whether this preset is safe for offline/air-gapped mode.
    pub offline_safe: bool,
}

/// Pre-configured presets for managed agent scenarios.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PresetName {
    /// Anthropic-style tiered: manager-heavy reasoning, 3 executors.
    AnthropicTiered,
    /// Google-style: manager routes, many lightweight executors.
    GoogleTiered,
    /// Cross-opus collaboration: balanced, deep nesting.
    CrossOpus,
    /// Budget-optimized: minimal token usage, costs-conscious.
    Budget,
    /// Balanced general-purpose: 50/50 split.
    Balanced,
    /// Executor-heavy: manager is just a router.
    ExecutorHeavy,
    /// Manager-heavy: manager does most reasoning.
    ManagerHeavy,
    /// Safe for offline / no-network use.
    OfflineSafe,
}

impl PresetName {
    /// Get the preset configuration.
    #[must_use]
    pub fn preset(self) -> AgentPreset {
        match self {
            Self::AnthropicTiered => AgentPreset {
                name: "anthropic-tiered",
                description: "Manager does heavy reasoning (90%), spawns up to 3 executors for specific subtasks",
                budget_policy: BudgetPolicy::ManagerHeavy,
                max_depth: 3,
                max_concurrent: 3,
                default_budget: 100_000,
                offline_safe: false,
            },
            Self::GoogleTiered => AgentPreset {
                name: "google-tiered",
                description: "Manager routes tasks to 5 lightweight executors, manager keeps minimal budget",
                budget_policy: BudgetPolicy::ExecutorHeavy,
                max_depth: 2,
                max_concurrent: 5,
                default_budget: 200_000,
                offline_safe: false,
            },
            Self::CrossOpus => AgentPreset {
                name: "cross-opus",
                description: "Deep collaboration between agents with balanced budgets, up to 10 concurrent",
                budget_policy: BudgetPolicy::Balanced,
                max_depth: 5,
                max_concurrent: 10,
                default_budget: 500_000,
                offline_safe: false,
            },
            Self::Budget => AgentPreset {
                name: "budget",
                description: "Cost-conscious: small budget, shallow depth, low concurrency",
                budget_policy: BudgetPolicy::ExecutorHeavy,
                max_depth: 2,
                max_concurrent: 2,
                default_budget: 50_000,
                offline_safe: true,
            },
            Self::Balanced => AgentPreset {
                name: "balanced",
                description: "Default balanced mode: 50/50 budget, 3 depth, 5 concurrent",
                budget_policy: BudgetPolicy::Balanced,
                max_depth: 3,
                max_concurrent: 5,
                default_budget: 250_000,
                offline_safe: true,
            },
            Self::ExecutorHeavy => AgentPreset {
                name: "executor-heavy",
                description: "Manager as thin router (10%), up to 8 concurrent executors (90%)",
                budget_policy: BudgetPolicy::ExecutorHeavy,
                max_depth: 2,
                max_concurrent: 8,
                default_budget: 300_000,
                offline_safe: true,
            },
            Self::ManagerHeavy => AgentPreset {
                name: "manager-heavy",
                description: "Manager does all reasoning (90%), limited executors (10%)",
                budget_policy: BudgetPolicy::ManagerHeavy,
                max_depth: 2,
                max_concurrent: 3,
                default_budget: 200_000,
                offline_safe: true,
            },
            Self::OfflineSafe => AgentPreset {
                name: "offline-safe",
                description: "Conservative settings for air-gapped or offline operation",
                budget_policy: BudgetPolicy::Balanced,
                max_depth: 2,
                max_concurrent: 2,
                default_budget: 100_000,
                offline_safe: true,
            },
        }
    }

    /// Build a preset from its name string.
    #[must_use]
    pub fn from_str(name: &str) -> Option<Self> {
        match name {
            "anthropic-tiered" => Some(Self::AnthropicTiered),
            "google-tiered" => Some(Self::GoogleTiered),
            "cross-opus" => Some(Self::CrossOpus),
            "budget" => Some(Self::Budget),
            "balanced" => Some(Self::Balanced),
            "executor-heavy" => Some(Self::ExecutorHeavy),
            "manager-heavy" => Some(Self::ManagerHeavy),
            "offline-safe" => Some(Self::OfflineSafe),
            _ => None,
        }
    }
}

// ──────────────────────────────────────────────
// Managed Agent Config
// ──────────────────────────────────────────────

/// Full configuration for a managed agent system.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ManagedAgentConfig {
    /// Role for this agent instance.
    pub role: Role,
    /// Budget split policy.
    pub budget_policy: BudgetPolicy,
    /// Total token budget.
    pub total_budget: u64,
    /// Maximum spawn depth.
    pub max_depth: u32,
    /// Maximum concurrent executor agents.
    pub max_concurrent: u32,
    /// Human-readable purpose for this session.
    pub purpose: String,
    /// Maximum retries per executor task.
    pub max_retries: u32,
    /// Optional preset name (overrides individual settings if set).
    pub preset: Option<String>,
}

impl ManagedAgentConfig {
    /// Create a new config from a preset name.
    pub fn from_preset(preset_name: &str) -> Result<Self> {
        let preset = PresetName::from_str(preset_name)
            .ok_or_else(|| ManagedAgentError::UnknownPreset(preset_name.to_string()))?;
        let p = preset.preset();
        Ok(Self {
            role: Role::Manager,
            budget_policy: p.budget_policy,
            total_budget: p.default_budget,
            max_depth: p.max_depth,
            max_concurrent: p.max_concurrent,
            purpose: p.description.to_string(),
            max_retries: 2,
            preset: Some(preset_name.to_string()),
        })
    }

    /// Validate the configuration.
    pub fn validate(&self) -> Result<()> {
        if !self.budget_policy.is_valid() {
            return Err(ManagedAgentError::InvalidConfig(
                "budget policy percentages must sum to 100".into(),
            ));
        }
        if self.max_depth == 0 {
            return Err(ManagedAgentError::InvalidConfig(
                "max_depth must be > 0".into(),
            ));
        }
        if self.max_concurrent == 0 {
            return Err(ManagedAgentError::InvalidConfig(
                "max_concurrent must be > 0".into(),
            ));
        }
        Ok(())
    }
}

impl Default for ManagedAgentConfig {
    fn default() -> Self {
        let p = PresetName::Balanced.preset();
        Self {
            role: Role::Manager,
            budget_policy: p.budget_policy,
            total_budget: p.default_budget,
            max_depth: p.max_depth,
            max_concurrent: p.max_concurrent,
            purpose: "Managed agent session".into(),
            max_retries: 2,
            preset: Some("balanced".into()),
        }
    }
}

// ──────────────────────────────────────────────
// Agent Instance
// ──────────────────────────────────────────────

/// A managed agent instance within a session.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct AgentInstance {
    /// Unique worker ID for this agent.
    pub worker_id: WorkerId,
    /// Role assigned to this agent.
    pub role: Role,
    /// Parent agent (None for the root Manager).
    pub parent: Option<WorkerId>,
    /// Spawn depth (0 = root).
    pub depth: u32,
    /// Current status.
    pub status: AgentStatus,
    /// Task assigned to this agent, if any.
    pub assigned_task: Option<String>,
    /// Result of the task, if completed.
    pub result: Option<String>,
    /// Error message if failed.
    pub error: Option<String>,
}

/// Status of an agent instance.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum AgentStatus {
    /// Agent is alive and idle.
    Idle,
    /// Agent is working on a task.
    Working,
    /// Agent completed its task successfully.
    Completed,
    /// Agent failed.
    Failed,
}

// ──────────────────────────────────────────────
// Managed Agent Session
// ──────────────────────────────────────────────

/// A session tracking all managed agents and their state.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct ManagedSession {
    /// Unique session ID.
    pub session_id: String,
    /// Agents in this session, indexed by worker ID.
    pub agents: BTreeMap<WorkerId, AgentInstance>,
    /// Budget tracker for this session.
    pub budget_tracker: ManagedBudgetTracker,
    /// Session configuration.
    pub config: ManagedAgentConfig,
    /// The root manager agent ID.
    pub root_manager: WorkerId,
    /// Whether the session is active.
    pub active: bool,
}

impl ManagedSession {
    /// Create a new session.
    pub fn new(
        session_id: impl Into<String>,
        config: ManagedAgentConfig,
        root_worker_id: impl Into<String>,
    ) -> Self {
        let root_id = root_worker_id.into();
        let budget_tracker = ManagedBudgetTracker::new(config.total_budget, config.budget_policy);

        let mut agents = BTreeMap::new();
        agents.insert(
            root_id.clone(),
            AgentInstance {
                worker_id: root_id.clone(),
                role: Role::Manager,
                parent: None,
                depth: 0,
                status: AgentStatus::Idle,
                assigned_task: None,
                result: None,
                error: None,
            },
        );

        Self {
            session_id: session_id.into(),
            agents,
            budget_tracker,
            config,
            root_manager: root_id,
            active: true,
        }
    }

    /// Spawn an executor agent under a parent manager.
    pub fn spawn_executor(
        &mut self,
        manager_id: &str,
        executor_id: impl Into<String>,
        task: impl Into<String>,
    ) -> Result<WorkerId> {
        // Verify manager exists and is a Manager role
        let parent = self
            .agents
            .get(manager_id)
            .ok_or_else(|| ManagedAgentError::AgentNotFound(manager_id.to_string()))?;
        if parent.role != Role::Manager {
            return Err(ManagedAgentError::RoleMismatch {
                expected: Role::Manager,
                actual: parent.role,
            });
        }

        // Depth check
        let depth = parent.depth + 1;
        if depth > self.config.max_depth {
            return Err(ManagedAgentError::MaxDepthReached {
                depth,
                max_depth: self.config.max_depth,
            });
        }

        // Concurrency limit
        let running_executors = self
            .agents
            .values()
            .filter(|a| a.role == Role::Executor && a.status == AgentStatus::Working)
            .count() as u32;
        if running_executors >= self.config.max_concurrent {
            return Err(ManagedAgentError::ConcurrencyLimit {
                current: running_executors,
                max_concurrent: self.config.max_concurrent,
            });
        }

        let executor_id: WorkerId = executor_id.into();
        let task_str: String = task.into();

        self.agents.insert(
            executor_id.clone(),
            AgentInstance {
                worker_id: executor_id.clone(),
                role: Role::Executor,
                parent: Some(manager_id.to_string()),
                depth,
                status: AgentStatus::Working,
                assigned_task: Some(task_str),
                result: None,
                error: None,
            },
        );

        Ok(executor_id)
    }

    /// Mark an executor as completed with a result.
    pub fn complete_executor(
        &mut self,
        executor_id: &str,
        result: impl Into<String>,
    ) -> Result<()> {
        let agent = self
            .agents
            .get_mut(executor_id)
            .ok_or_else(|| ManagedAgentError::AgentNotFound(executor_id.to_string()))?;
        agent.status = AgentStatus::Completed;
        agent.result = Some(result.into());
        Ok(())
    }

    /// Mark an executor as failed with an error.
    pub fn fail_executor(&mut self, executor_id: &str, error: impl Into<String>) -> Result<()> {
        let agent = self
            .agents
            .get_mut(executor_id)
            .ok_or_else(|| ManagedAgentError::AgentNotFound(executor_id.to_string()))?;
        agent.status = AgentStatus::Failed;
        agent.error = Some(error.into());
        Ok(())
    }

    /// Count agents by status.
    #[must_use]
    pub fn count_by_status(&self, status: AgentStatus) -> usize {
        self.agents.values().filter(|a| a.status == status).count()
    }

    /// Number of active (Idle or Working) agents.
    #[must_use]
    pub fn active_count(&self) -> usize {
        self.agents
            .values()
            .filter(|a| matches!(a.status, AgentStatus::Idle | AgentStatus::Working))
            .count()
    }

    /// All executor agents (non-manager).
    #[must_use]
    pub fn executors(&self) -> impl Iterator<Item = &AgentInstance> {
        self.agents.values().filter(|a| a.role == Role::Executor)
    }

    // ── Budget helpers that delegate to the tracker ──

    /// Spend budget for a role.
    pub fn spend_budget(&mut self, role: Role, tokens: u64) -> Result<()> {
        self.budget_tracker.spend(role, tokens)
    }

    /// Total remaining budget.
    #[must_use]
    pub fn remaining_budget(&self) -> u64 {
        self.budget_tracker.total_remaining()
    }

    /// Budget usage as fraction 0.0..1.0.
    #[must_use]
    pub fn budget_usage(&self) -> f64 {
        self.budget_tracker.usage_fraction()
    }
}

// ──────────────────────────────────────────────
// Managed Orchestrator
// ──────────────────────────────────────────────

/// Builds system prompts and manages the lifecycle of managed agents.
#[derive(Debug, Clone)]
pub struct ManagedOrchestrator {
    /// Configuration for this orchestrator.
    config: ManagedAgentConfig,
}

impl ManagedOrchestrator {
    /// Create a new orchestrator from config.
    #[must_use]
    pub fn new(config: ManagedAgentConfig) -> Self {
        Self { config }
    }

    /// Create an orchestrator from a preset.
    pub fn from_preset(preset_name: &str) -> Result<Self> {
        let config = ManagedAgentConfig::from_preset(preset_name)?;
        Ok(Self::new(config))
    }

    /// Build the system prompt for a Manager agent.
    #[must_use]
    pub fn build_manager_prompt(&self, session_id: &str, task: &str) -> String {
        let (manager_pct, executor_pct) = self.config.budget_policy.split();
        let max_executors = self.config.max_concurrent;
        let max_depth = self.config.max_depth;

        format!(
            r#"You are a MANAGER agent in the BKG Managed Agent system.

SESSION: {session_id}
YOUR ROLE: Manager (you route tasks and manage executors)
TASK: {task}

RULES:
- You spawn Executor agents to do actual work.
- You do NOT do work directly — your job is decomposition and delegation.
- Budget split: Manager gets {manager_pct}%, Executors share {executor_pct}%.
- Max concurrent executors: {max_executors}
- Max spawn depth: {max_depth} (0 = you, 1 = your executors, etc.)

WORKFLOW:
1. Analyze the task and break it into subtasks.
2. For each subtask, spawn an Executor with a clear, self-contained instruction.
3. Monitor executor results.
4. Synthesize results into the final answer.
5. Report back to the user.

OUTPUT FORMAT:
<analysis>Your reasoning about how to decompose the task</analysis>
<plan>List of subtasks to delegate</plan>
<spawn agent="executor-id" task="subtask description" />
<result>Synthesized final output</result>
"#,
        )
    }

    /// Build the system prompt for an Executor agent.
    #[must_use]
    pub fn build_executor_prompt(&self, manager_task: &str) -> String {
        format!(
            r#"You are an EXECUTOR agent in the BKG Managed Agent system.

YOUR ROLE: Executor (you perform work assigned by a Manager)
ASSIGNED TASK: {manager_task}

RULES:
- Focus ONLY on your assigned task — do not deviate.
- Report results clearly. If you cannot complete the task, explain why.
- Do NOT spawn sub-agents (only Managers can spawn).
- Be concise and thorough.

OUTPUT FORMAT:
<execution>Your work and reasoning</execution>
<result>Your final output to return to the Manager</result>
"#,
        )
    }

    /// Create a new session.
    #[must_use]
    pub fn create_session(
        &self,
        session_id: impl Into<String>,
        root_worker_id: impl Into<String>,
    ) -> ManagedSession {
        ManagedSession::new(session_id, self.config.clone(), root_worker_id)
    }

    /// Get the config.
    #[must_use]
    pub fn config(&self) -> &ManagedAgentConfig {
        &self.config
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── Preset tests ──

    #[test]
    fn all_presets_are_valid() {
        for preset in [
            PresetName::AnthropicTiered,
            PresetName::GoogleTiered,
            PresetName::CrossOpus,
            PresetName::Budget,
            PresetName::Balanced,
            PresetName::ExecutorHeavy,
            PresetName::ManagerHeavy,
            PresetName::OfflineSafe,
        ] {
            let p = preset.preset();
            assert!(p.budget_policy.is_valid());
            assert!(p.max_depth > 0);
            assert!(p.max_concurrent > 0);
        }
    }

    #[test]
    fn preset_from_str() {
        assert!(PresetName::from_str("balanced").is_some());
        assert!(PresetName::from_str("anthropic-tiered").is_some());
        assert!(PresetName::from_str("nope").is_none());
    }

    #[test]
    fn config_from_preset() {
        let config = ManagedAgentConfig::from_preset("balanced").unwrap();
        assert_eq!(config.max_depth, 3);
        assert_eq!(config.max_concurrent, 5);
        assert_eq!(config.total_budget, 250_000);
    }

    #[test]
    fn config_from_unknown_preset_fails() {
        assert!(ManagedAgentConfig::from_preset("nonexistent").is_err());
    }

    // ── Budget tracker tests ──

    #[test]
    fn balanced_budget_split() {
        let tracker = ManagedBudgetTracker::new(1000, BudgetPolicy::Balanced);
        assert_eq!(tracker.manager_budget(), 500);
        assert_eq!(tracker.executor_budget(), 500);
    }

    #[test]
    fn executor_heavy_split() {
        let tracker = ManagedBudgetTracker::new(1000, BudgetPolicy::ExecutorHeavy);
        assert_eq!(tracker.manager_budget(), 100);
        assert_eq!(tracker.executor_budget(), 900);
    }

    #[test]
    fn manager_heavy_split() {
        let tracker = ManagedBudgetTracker::new(1000, BudgetPolicy::ManagerHeavy);
        assert_eq!(tracker.manager_budget(), 900);
        assert_eq!(tracker.executor_budget(), 100);
    }

    #[test]
    fn custom_split() {
        let tracker = ManagedBudgetTracker::new(
            1000,
            BudgetPolicy::Custom {
                manager_pct: 30,
                executor_pct: 70,
            },
        );
        assert_eq!(tracker.manager_budget(), 300);
        assert_eq!(tracker.executor_budget(), 700);
    }

    #[test]
    fn spending_tracks_correctly() {
        let mut tracker = ManagedBudgetTracker::new(1000, BudgetPolicy::Balanced);
        tracker.spend(Role::Manager, 200).unwrap();
        tracker.spend(Role::Executor, 100).unwrap();
        assert_eq!(tracker.manager_remaining(), 300);
        assert_eq!(tracker.executor_remaining(), 400);
        assert_eq!(tracker.total_consumed(), 300);
        assert_eq!(tracker.total_remaining(), 700);
    }

    #[test]
    fn spending_over_budget_fails() {
        let mut tracker = ManagedBudgetTracker::new(100, BudgetPolicy::Balanced);
        assert!(tracker.spend(Role::Manager, 60).is_err());
    }

    #[test]
    fn can_spend_checks() {
        let tracker = ManagedBudgetTracker::new(100, BudgetPolicy::ExecutorHeavy);
        assert!(tracker.can_spend(Role::Executor, 50));
        assert!(!tracker.can_spend(Role::Manager, 50)); // manager only gets 10
    }

    #[test]
    fn usage_fraction() {
        let mut tracker = ManagedBudgetTracker::new(100, BudgetPolicy::Balanced);
        assert_eq!(tracker.usage_fraction(), 0.0);
        tracker.spend(Role::Manager, 25).unwrap();
        tracker.spend(Role::Executor, 25).unwrap();
        assert!((tracker.usage_fraction() - 0.5).abs() < 0.001);
    }

    #[test]
    fn reset_clears_consumption() {
        let mut tracker = ManagedBudgetTracker::new(1000, BudgetPolicy::Balanced);
        tracker.spend(Role::Manager, 200).unwrap();
        tracker.spend(Role::Executor, 100).unwrap();
        tracker.reset();
        assert_eq!(tracker.total_consumed(), 0);
    }

    // ── Role tests ──

    #[test]
    fn manager_can_spawn() {
        assert!(Role::Manager.can_spawn());
        assert!(!Role::Executor.can_spawn());
    }

    #[test]
    fn role_as_str() {
        assert_eq!(Role::Manager.as_str(), "manager");
        assert_eq!(Role::Executor.as_str(), "executor");
    }

    // ── Session tests ──

    #[test]
    fn new_session_has_root_manager() {
        let config = ManagedAgentConfig::default();
        let session = ManagedSession::new("test-session", config, "root-1");
        assert_eq!(session.session_id, "test-session");
        assert!(session.active);
        assert_eq!(session.agents.len(), 1);
        assert_eq!(session.agents.get("root-1").unwrap().role, Role::Manager);
    }

    #[test]
    fn spawn_executor_creates_worker() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "manager-1");

        let exec_id = session
            .spawn_executor("manager-1", "exec-1", "do something")
            .unwrap();
        assert_eq!(exec_id, "exec-1");
        assert_eq!(session.agents.len(), 2);

        let exec = session.agents.get("exec-1").unwrap();
        assert_eq!(exec.role, Role::Executor);
        assert_eq!(exec.depth, 1);
        assert_eq!(exec.status, AgentStatus::Working);
        assert_eq!(exec.assigned_task.as_deref(), Some("do something"));
    }

    #[test]
    fn non_manager_cannot_spawn() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "exec-0");
        // Change root to executor to test
        session.agents.get_mut("exec-0").unwrap().role = Role::Executor;

        let result = session.spawn_executor("exec-0", "exec-1", "task");
        assert!(result.is_err());
        assert!(matches!(
            result.unwrap_err(),
            ManagedAgentError::RoleMismatch { .. }
        ));
    }

    #[test]
    fn max_depth_enforced() {
        let mut config = ManagedAgentConfig::default();
        config.max_depth = 1; // Only depth 1 allowed (root=0, can spawn at depth 1)
        let mut session = ManagedSession::new("s1", config, "root");

        // Spawn a Manager at depth 1 (e1 is a manager that can further spawn)
        let e1 = session.spawn_executor("root", "e1", "task1").unwrap();
        // Change e1 to Manager role so it can spawn further
        session.agents.get_mut("e1").unwrap().role = Role::Manager;

        // Now e1 is at depth 1 (Manager). Trying to spawn from e1 → depth 2 > max_depth 1
        let result = session.spawn_executor("e1", "e2", "task2");
        eprintln!("max_depth_enforced error: {:?}", result);
        assert!(result.is_err());
        assert!(
            matches!(&result, Err(ManagedAgentError::MaxDepthReached { .. })),
            "expected MaxDepthReached, got {:?}",
            result
        );
    }

    #[test]
    fn concurrency_limit_enforced() {
        let mut config = ManagedAgentConfig::default();
        config.max_concurrent = 1; // Only 1 concurrent executor
        let mut session = ManagedSession::new("s1", config, "root");

        session.spawn_executor("root", "e1", "task1").unwrap();

        // Second spawn should hit concurrency limit
        let result = session.spawn_executor("root", "e2", "task2");
        assert!(result.is_err());
        assert!(matches!(
            result.unwrap_err(),
            ManagedAgentError::ConcurrencyLimit { .. }
        ));
    }

    #[test]
    fn complete_executor() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "root");
        let exec = session.spawn_executor("root", "e1", "task").unwrap();

        session.complete_executor(&exec, "done!").unwrap();
        assert_eq!(
            session.agents.get(&exec).unwrap().status,
            AgentStatus::Completed
        );
        assert_eq!(
            session.agents.get(&exec).unwrap().result.as_deref(),
            Some("done!")
        );
    }

    #[test]
    fn fail_executor() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "root");
        let exec = session.spawn_executor("root", "e1", "task").unwrap();

        session.fail_executor(&exec, "error!").unwrap();
        assert_eq!(
            session.agents.get(&exec).unwrap().status,
            AgentStatus::Failed
        );
    }

    #[test]
    fn count_by_status() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "root");
        let e1 = session.spawn_executor("root", "e1", "t1").unwrap();
        let e2 = session.spawn_executor("root", "e2", "t2").unwrap();
        session.complete_executor(&e1, "ok").unwrap();

        assert_eq!(session.count_by_status(AgentStatus::Working), 1);
        assert_eq!(session.count_by_status(AgentStatus::Completed), 1);
        assert_eq!(session.count_by_status(AgentStatus::Idle), 1); // root
    }

    // ── Orchestrator tests ──

    #[test]
    fn build_manager_prompt() {
        let config = ManagedAgentConfig::default();
        let orch = ManagedOrchestrator::new(config);
        let prompt = orch.build_manager_prompt("sess-1", "build a thing");

        assert!(prompt.contains("MANAGER"));
        assert!(prompt.contains("sess-1"));
        assert!(prompt.contains("build a thing"));
        assert!(prompt.contains("BKG Managed Agent"));
    }

    #[test]
    fn build_executor_prompt() {
        let config = ManagedAgentConfig::default();
        let orch = ManagedOrchestrator::new(config);
        let prompt = orch.build_executor_prompt("do the thing");

        assert!(prompt.contains("EXECUTOR"));
        assert!(prompt.contains("do the thing"));
    }

    #[test]
    fn orchestrator_from_preset() {
        let orch = ManagedOrchestrator::from_preset("budget").unwrap();
        assert_eq!(orch.config().total_budget, 50_000);
        assert_eq!(orch.config().max_depth, 2);
    }

    #[test]
    fn create_session_via_orchestrator() {
        let config = ManagedAgentConfig::default();
        let orch = ManagedOrchestrator::new(config);
        let session = orch.create_session("s1", "root-1");
        assert_eq!(session.session_id, "s1");
    }

    // ── Config validation tests ──

    #[test]
    fn custom_budget_invalid() {
        let policy = BudgetPolicy::Custom {
            manager_pct: 50,
            executor_pct: 30,
        };
        assert!(!policy.is_valid());
    }

    #[test]
    fn validate_config_rejects_zero_depth() {
        let config = ManagedAgentConfig {
            max_depth: 0,
            ..ManagedAgentConfig::default()
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn validate_config_rejects_zero_concurrent() {
        let config = ManagedAgentConfig {
            max_concurrent: 0,
            ..ManagedAgentConfig::default()
        };
        assert!(config.validate().is_err());
    }

    #[test]
    fn default_config_validates() {
        let config = ManagedAgentConfig::default();
        assert!(config.validate().is_ok());
    }

    #[test]
    fn executors_iterator() {
        let config = ManagedAgentConfig::default();
        let mut session = ManagedSession::new("s1", config, "root");
        session.spawn_executor("root", "e1", "t1").unwrap();
        session.spawn_executor("root", "e2", "t2").unwrap();

        let count: usize = session.executors().count();
        assert_eq!(count, 2);
    }
}
