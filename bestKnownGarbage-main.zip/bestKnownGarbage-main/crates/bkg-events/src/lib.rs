//! BKG Event System — canonical event taxonomy, metadata, reconciliation, and deduplication.
//!
//! This crate provides the foundational event primitives used throughout the BKG system:
//!
//! - **EventName** — taxonomy of all BKG events (observations, trust, decisions, lifecycle, errors)
//! - **EventMetadata** — provenance, environment, emitter identity, confidence, fingerprints
//! - **EventBuilder** — type-safe builder with terminal fingerprint auto-computation
//! - **TerminalEventReconciliation** — deterministic deduplication and ordering
//! - **SessionIdentity** — session/agent identity with incremental enrichment
//! - **NudgeTracking** — acknowledgment cycles for retry/duplicate detection
//! - **RoadmapId / RoadmapLifecycle** — stable ID assignment + lifecycle state machine
//!
//! ## Design Principles
//!
//! 1. **Append-only** — events are immutable once created
//! 2. **Self-describing** — every event carries full provenance and metadata
//! 3. **Deterministic** — same inputs → same fingerprints, same reconciliation
//! 4. **Deduplicatable** — terminal events carry fingerprints for idempotent processing
//! 5. **Recoverable** — no information loss during reconciliation

#![allow(clippy::similar_names, clippy::cast_possible_truncation)]

use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::fmt::Write;

// ──────────────────────────────────────────────
// Event Name Taxonomy
// ──────────────────────────────────────────────

/// Canonical taxonomy of all BKG events.
///
/// Organised by domain prefix:
/// - `observation.*` — Collector/Mesh observations (read-only, per I02/I09)
/// - `trust.*` — Trust score changes, escalation events
/// - `motherbrain.*` — Adjudication decisions from Motherbrain (only writer, per I01)
/// - `replay.*` — Replay verification results
/// - `ledger.*` — Ledger lifecycle events
/// - `gc.*` — Garbage Collector events (observational only, per I03)
/// - `mesh.*` — Network topology and gossip events
/// - `lifecycle.*` — System/session lifecycle
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
pub enum EventName {
    // ── Observations ──
    /// A Collector submitted an observation
    #[serde(rename = "observation.collected")]
    ObservationCollected,
    /// Observation forwarded through mesh gossip
    #[serde(rename = "observation.gossiped")]
    ObservationGossiped,

    // ── Trust ──
    /// Trust score changed for a node
    #[serde(rename = "trust.score_changed")]
    TrustScoreChanged,
    /// Node promoted (e.g., to TrustHero)
    #[serde(rename = "trust.promoted")]
    TrustPromoted,
    /// Node demoted
    #[serde(rename = "trust.demoted")]
    TrustDemoted,
    /// Collusion pattern detected
    #[serde(rename = "trust.collusion_detected")]
    TrustCollusionDetected,
    /// Escalation triggered (follows Talmud stages)
    #[serde(rename = "trust.escalation")]
    TrustEscalation,
    /// Entropy spike detected
    #[serde(rename = "trust.entropy_spike")]
    TrustEntropySpike,

    // ── Motherbrain Adjudication ──
    /// Chunk verified as truthful
    #[serde(rename = "motherbrain.verified")]
    MotherbrainVerified,
    /// Chunk rejected
    #[serde(rename = "motherbrain.rejected")]
    MotherbrainRejected,
    /// Needs revalidation
    #[serde(rename = "motherbrain.needs_revalidation")]
    MotherbrainNeedsRevalidation,
    /// Node quarantined
    #[serde(rename = "motherbrain.quarantined")]
    MotherbrainQuarantined,
    /// Swarm quorum consensus reached
    #[serde(rename = "motherbrain.consensus")]
    MotherbrainConsensus,
    /// Swarm quorum failed
    #[serde(rename = "motherbrain.consensus_failed")]
    MotherbrainConsensusFailed,
    /// Talmud escalation decision
    #[serde(rename = "motherbrain.talmud_decision")]
    MotherbrainTalmudDecision,

    // ── Replay ──
    /// Replay verification started
    #[serde(rename = "replay.started")]
    ReplayStarted,
    /// Replay verification completed (match)
    #[serde(rename = "replay.completed")]
    ReplayCompleted,
    /// Replay verification failed (mismatch)
    #[serde(rename = "replay.failed")]
    ReplayFailed,
    /// Replay class assigned
    #[serde(rename = "replay.class_assigned")]
    ReplayClassAssigned,

    // ── Ledger ──
    /// New entry appended to ledger
    #[serde(rename = "ledger.appended")]
    LedgerAppended,
    /// Ledger state hash computed
    #[serde(rename = "ledger.state_hashed")]
    LedgerStateHashed,
    /// Ledger integrity check passed
    #[serde(rename = "ledger.integrity_ok")]
    LedgerIntegrityOk,
    /// Ledger integrity check failed
    #[serde(rename = "ledger.integrity_failed")]
    LedgerIntegrityFailed,

    // ── Garbage Collector ──
    /// Entropy level changed
    #[serde(rename = "gc.entropy_changed")]
    GcEntropyChanged,
    /// Knowledge decay applied
    #[serde(rename = "gc.decay_applied")]
    GcDecayApplied,
    /// Archive created
    #[serde(rename = "gc.archived")]
    GcArchived,
    /// Archived entry restored
    #[serde(rename = "gc.restored")]
    GcRestored,

    // ── Mesh ──
    /// Peer connected
    #[serde(rename = "mesh.peer_connected")]
    MeshPeerConnected,
    /// Peer disconnected
    #[serde(rename = "mesh.peer_disconnected")]
    MeshPeerDisconnected,
    /// Heartbeat timeout
    #[serde(rename = "mesh.heartbeat_timeout")]
    MeshHeartbeatTimeout,
    /// Topology rewired
    #[serde(rename = "mesh.topology_rewired")]
    MeshTopologyRewired,
    /// Attack hotspot detected
    #[serde(rename = "mesh.attack_hotspot")]
    MeshAttackHotspot,

    // ── Lifecycle ──
    /// System booting
    #[serde(rename = "lifecycle.boot")]
    LifecycleBoot,
    /// System ready
    #[serde(rename = "lifecycle.ready")]
    LifecycleReady,
    /// System mode changed
    #[serde(rename = "lifecycle.mode_changed")]
    LifecycleModeChanged,
    /// System shutting down
    #[serde(rename = "lifecycle.shutdown")]
    LifecycleShutdown,
    /// Task/process started
    #[serde(rename = "lifecycle.task_started")]
    LifecycleTaskStarted,
    /// Task/process completed
    #[serde(rename = "lifecycle.task_completed")]
    LifecycleTaskCompleted,
    /// Task/process failed
    #[serde(rename = "lifecycle.task_failed")]
    LifecycleTaskFailed,
}

// ──────────────────────────────────────────────
// Event Status
// ──────────────────────────────────────────────

/// Primary status of an event.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum EventStatus {
    Running,
    Ready,
    Completed,
    Failed,
    Blocked,
    Superseded,
    Quarantined,
    Pending,
    Skipped,
}

// ──────────────────────────────────────────────
// Failure Classification
// ──────────────────────────────────────────────

/// BKG failure classification taxonomy.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum FailureClass {
    /// Mesh partition or peer loss
    MeshPartition,
    /// Ledger stall or write conflict
    LedgerStall,
    /// Trust gap or threshold breach
    TrustGap,
    /// Replay hash mismatch
    ReplayMismatch,
    /// Attestation verification failed
    AttestationFailure,
    /// Entropy above threshold
    EntropySpike,
    /// Collusion pattern detected
    CollusionDetected,
    /// WASM execution failure
    WasmExecution,
    /// Guard LLM advisory triggered
    GuardAdvisory,
    /// Network transport failure
    TransportFailure,
    /// Configuration/loading error
    ConfigError,
    /// Internal system error
    InternalError,
}

// ──────────────────────────────────────────────
// Event Provenance
// ──────────────────────────────────────────────

/// Provenance labels for event source classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum EventProvenance {
    /// Event from a live, active system
    Live,
    /// Event from a synthetic test
    Test,
    /// Event from a healthcheck probe
    Healthcheck,
    /// Event from a replay/log replay
    Replay,
    /// Event from the transport layer itself
    Transport,
}

// ──────────────────────────────────────────────
// Confidence Level
// ──────────────────────────────────────────────

/// Confidence/trust level for downstream automation decisions.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum ConfidenceLevel {
    /// High confidence — suitable for automated action
    High,
    /// Medium confidence — may require verification
    Medium,
    /// Low confidence — likely requires human review
    Low,
    /// Unknown confidence level
    Unknown,
}

// ──────────────────────────────────────────────
// Event Metadata
// ──────────────────────────────────────────────

/// Full event metadata for provenance, ordering, deduplication, and ownership.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EventMetadata {
    /// Monotonic sequence number for event ordering
    pub seq: u64,
    /// Event provenance source
    pub provenance: EventProvenance,
    /// Session/agent identity
    #[serde(skip_serializing_if = "Option::is_none")]
    pub session_identity: Option<SessionIdentity>,
    /// Nudge/cycle ID for deduplication
    #[serde(skip_serializing_if = "Option::is_none")]
    pub nudge_id: Option<String>,
    /// Event fingerprint for terminal event deduplication
    #[serde(skip_serializing_if = "Option::is_none")]
    pub event_fingerprint: Option<String>,
    /// Timestamp (epoch millis) when event was created
    pub timestamp_ms: u64,
    /// Environment/channel label (e.g., production, staging, replay)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub environment_label: Option<String>,
    /// Emitter identity (e.g., motherbrain, mesh-node-01, guard-llm)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub emitter_identity: Option<String>,
    /// Confidence/trust level for downstream automation
    #[serde(skip_serializing_if = "Option::is_none")]
    pub confidence_level: Option<ConfidenceLevel>,
}

impl EventMetadata {
    /// Create new event metadata with the current timestamp.
    #[must_use]
    pub fn new(seq: u64, provenance: EventProvenance) -> Self {
        Self {
            seq,
            provenance,
            session_identity: None,
            nudge_id: None,
            event_fingerprint: None,
            timestamp_ms: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as u64,
            environment_label: None,
            emitter_identity: None,
            confidence_level: None,
        }
    }

    /// Create event metadata at a specific timestamp (for replay).
    #[must_use]
    pub fn at_timestamp(seq: u64, provenance: EventProvenance, timestamp_ms: u64) -> Self {
        Self {
            seq,
            provenance,
            session_identity: None,
            nudge_id: None,
            event_fingerprint: None,
            timestamp_ms,
            environment_label: None,
            emitter_identity: None,
            confidence_level: None,
        }
    }

    builder_method!(with_session_identity, session_identity, SessionIdentity);
    builder_method!(with_nudge_id, nudge_id, String);
    builder_method!(with_fingerprint, event_fingerprint, String);
    builder_method!(with_environment, environment_label, String);
    builder_method!(with_emitter, emitter_identity, String);
    builder_method!(with_confidence, confidence_level, ConfidenceLevel);
}

// ──────────────────────────────────────────────
// Event Builder
// ──────────────────────────────────────────────

/// Type-safe builder for constructing BKG events with proper metadata.
///
/// Automatically computes terminal event fingerprints. Use `build_terminal()`
/// for events that should be deduplicatable.
#[derive(Debug, Clone)]
pub struct EventBuilder {
    event: EventName,
    status: EventStatus,
    emitted_at: String,
    metadata: EventMetadata,
    detail: Option<String>,
    failure_class: Option<FailureClass>,
    data: Option<Value>,
}

impl EventBuilder {
    /// Start building a new event.
    #[must_use]
    pub fn new(
        event: EventName,
        status: EventStatus,
        emitted_at: impl Into<String>,
        seq: u64,
        provenance: EventProvenance,
    ) -> Self {
        Self {
            event,
            status,
            emitted_at: emitted_at.into(),
            metadata: EventMetadata::new(seq, provenance),
            detail: None,
            failure_class: None,
            data: None,
        }
    }

    /// Add session identity to the event.
    #[must_use]
    pub fn with_session_identity(mut self, identity: SessionIdentity) -> Self {
        self.metadata = self.metadata.with_session_identity(identity);
        self
    }

    /// Add nudge/cycle ID for deduplication.
    #[must_use]
    pub fn with_nudge_id(mut self, nudge_id: impl Into<String>) -> Self {
        self.metadata = self.metadata.with_nudge_id(nudge_id);
        self
    }

    /// Add environment/channel label.
    #[must_use]
    pub fn with_environment(mut self, label: impl Into<String>) -> Self {
        self.metadata = self.metadata.with_environment(label);
        self
    }

    /// Add emitter identity.
    #[must_use]
    pub fn with_emitter(mut self, emitter: impl Into<String>) -> Self {
        self.metadata = self.metadata.with_emitter(emitter);
        self
    }

    /// Add confidence/trust level.
    #[must_use]
    pub fn with_confidence(mut self, level: ConfidenceLevel) -> Self {
        self.metadata = self.metadata.with_confidence(level);
        self
    }

    /// Add a human-readable detail string.
    #[must_use]
    pub fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    /// Add a failure classification.
    #[must_use]
    pub fn with_failure_class(mut self, failure_class: FailureClass) -> Self {
        self.failure_class = Some(failure_class);
        self
    }

    /// Add a structured data payload.
    #[must_use]
    pub fn with_data(mut self, data: Value) -> Self {
        self.data = Some(data);
        self
    }

    /// Compute fingerprint and build as a terminal event (deduplicatable).
    #[must_use]
    pub fn build_terminal(self) -> BkgEvent {
        let fingerprint = compute_event_fingerprint(&self.event, &self.status, self.data.as_ref());
        let mut meta = self.metadata;
        meta.event_fingerprint = Some(fingerprint);
        BkgEvent {
            event: self.event,
            status: self.status,
            emitted_at: self.emitted_at,
            failure_class: self.failure_class,
            detail: self.detail,
            data: self.data,
            metadata: meta,
        }
    }

    /// Build the event (no fingerprint).
    #[must_use]
    pub fn build(self) -> BkgEvent {
        BkgEvent {
            event: self.event,
            status: self.status,
            emitted_at: self.emitted_at,
            failure_class: self.failure_class,
            detail: self.detail,
            data: self.data,
            metadata: self.metadata,
        }
    }
}

// ──────────────────────────────────────────────
// Core Event Types
// ──────────────────────────────────────────────

/// A single BKG event — the atomic unit of system state change.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BkgEvent {
    pub event: EventName,
    pub status: EventStatus,
    pub emitted_at: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub failure_class: Option<FailureClass>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub detail: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub data: Option<Value>,
    pub metadata: EventMetadata,
}

/// Convenience constructors for common event types.
impl BkgEvent {
    /// Create a minimal live event.
    #[must_use]
    pub fn new(event: EventName, status: EventStatus, emitted_at: impl Into<String>) -> Self {
        Self {
            event,
            status,
            emitted_at: emitted_at.into(),
            failure_class: None,
            detail: None,
            data: None,
            metadata: EventMetadata::new(0, EventProvenance::Live),
        }
    }

    /// Create a boot event.
    #[must_use]
    pub fn boot(emitted_at: impl Into<String>, detail: Option<String>) -> Self {
        Self::new(EventName::LifecycleBoot, EventStatus::Running, emitted_at)
            .with_optional_detail(detail)
    }

    /// Create a ready event.
    #[must_use]
    pub fn ready(emitted_at: impl Into<String>) -> Self {
        Self::new(EventName::LifecycleReady, EventStatus::Ready, emitted_at)
    }

    /// Create a task completed event with terminal fingerprint.
    #[must_use]
    pub fn task_completed(
        emitted_at: impl Into<String>,
        detail: Option<String>,
        data: Option<Value>,
    ) -> Self {
        let mut e = Self::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            emitted_at,
        )
        .with_optional_detail(detail);
        if let Some(d) = data {
            e = e.with_data(d);
        }
        e.with_terminal_fingerprint()
    }

    /// Create a task failed event with terminal fingerprint.
    #[must_use]
    pub fn task_failed(
        emitted_at: impl Into<String>,
        failure_class: FailureClass,
        detail: String,
    ) -> Self {
        Self::new(
            EventName::LifecycleTaskFailed,
            EventStatus::Failed,
            emitted_at,
        )
        .with_failure_class(failure_class)
        .with_detail(detail)
        .with_terminal_fingerprint()
    }

    /// Create a ledger append event.
    #[must_use]
    pub fn ledger_appended(emitted_at: impl Into<String>, receipt_id: String, valid: bool) -> Self {
        Self::new(
            EventName::LedgerAppended,
            EventStatus::Completed,
            emitted_at,
        )
        .with_data(serde_json::json!({
            "receipt_id": receipt_id,
            "valid": valid,
        }))
    }

    /// Create a mesh peer connected event.
    #[must_use]
    pub fn mesh_peer_connected(emitted_at: impl Into<String>, peer_id: String) -> Self {
        Self::new(
            EventName::MeshPeerConnected,
            EventStatus::Completed,
            emitted_at,
        )
        .with_data(serde_json::json!({ "peer_id": peer_id }))
    }

    /// Create a trust escalation event.
    #[must_use]
    pub fn trust_escalation(
        emitted_at: impl Into<String>,
        node_id: String,
        stage: u32,
        trust: f32,
    ) -> Self {
        Self::new(EventName::TrustEscalation, EventStatus::Pending, emitted_at).with_data(
            serde_json::json!({
                "node_id": node_id,
                "stage": stage,
                "trust": trust,
            }),
        )
    }

    // ── Internal helpers ──

    #[must_use]
    fn with_optional_detail(mut self, detail: Option<String>) -> Self {
        self.detail = detail;
        self
    }

    #[must_use]
    fn with_detail(mut self, detail: impl Into<String>) -> Self {
        self.detail = Some(detail.into());
        self
    }

    #[must_use]
    fn with_data(mut self, data: Value) -> Self {
        self.data = Some(data);
        if is_terminal_event(self.event) {
            self = self.with_terminal_fingerprint();
        }
        self
    }

    #[must_use]
    fn with_failure_class(mut self, failure_class: FailureClass) -> Self {
        self.failure_class = Some(failure_class);
        self
    }

    #[must_use]
    fn with_terminal_fingerprint(mut self) -> Self {
        if is_terminal_event(self.event) {
            self.metadata.event_fingerprint = Some(compute_event_fingerprint(
                &self.event,
                &self.status,
                self.data.as_ref(),
            ));
        }
        self
    }
}

// ──────────────────────────────────────────────
// Event Classification
// ──────────────────────────────────────────────

/// Check if an event kind is terminal (completed, failed, superseded, etc.).
#[must_use]
pub fn is_terminal_event(event: EventName) -> bool {
    matches!(
        event,
        EventName::LifecycleTaskCompleted
            | EventName::LifecycleTaskFailed
            | EventName::MotherbrainVerified
            | EventName::MotherbrainRejected
            | EventName::MotherbrainQuarantined
            | EventName::MotherbrainConsensus
            | EventName::MotherbrainConsensusFailed
            | EventName::MotherbrainTalmudDecision
            | EventName::ReplayCompleted
            | EventName::ReplayFailed
            | EventName::LedgerIntegrityFailed
            | EventName::MeshAttackHotspot
    )
}

/// Terminality classification for reconciliation decisions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EventTerminality {
    /// Terminal event — represents final outcome
    Terminal,
    /// Advisory event — informational
    Advisory,
    /// Uncertainty — transport/system died, outcome unknown
    Uncertainty,
}

/// Classify an event's terminality.
#[must_use]
pub fn classify_event_terminality(event: EventName) -> EventTerminality {
    if is_terminal_event(event) {
        EventTerminality::Terminal
    } else {
        EventTerminality::Advisory
    }
}

// ──────────────────────────────────────────────
// Fingerprinting
// ──────────────────────────────────────────────

/// Compute a deterministic fingerprint for terminal event deduplication.
#[must_use]
pub fn compute_event_fingerprint(
    event: &EventName,
    status: &EventStatus,
    data: Option<&Value>,
) -> String {
    let payload = serde_json::json!({
        "event": event,
        "status": status,
        "data": data,
    });
    let canonical = serde_json::to_vec(&payload).unwrap_or_default();
    let digest = Sha256::digest(canonical);
    let mut fp = String::with_capacity(16);
    for byte in &digest[..8] {
        write!(&mut fp, "{byte:02x}").expect("fingerprint write should not fail");
    }
    fp
}

// ──────────────────────────────────────────────
// Terminal Event Reconciliation
// ──────────────────────────────────────────────

/// Reconcile a burst of potentially contradictory events into one canonical outcome.
///
/// Handles:
/// - Out-of-order events (sorts by monotonic sequence)
/// - Duplicate terminal events (deduplicates by fingerprint)
/// - Materially different terminal payloads (latest wins)
/// - `completed → idle → error → completed` noise
#[must_use]
pub fn reconcile_terminal_events(events: &[BkgEvent]) -> Option<(BkgEvent, Vec<BkgEvent>)> {
    if events.is_empty() {
        return None;
    }

    let mut sorted = events.to_vec();
    sorted.sort_by_key(|e| e.metadata.seq);

    let mut last_terminal: Option<BkgEvent> = None;
    let mut advisory_events = Vec::new();

    for event in &sorted {
        match classify_event_terminality(event.event) {
            EventTerminality::Terminal => {
                if let Some(ref terminal) = last_terminal {
                    if let (Some(fp1), Some(fp2)) = (
                        &event.metadata.event_fingerprint,
                        &terminal.metadata.event_fingerprint,
                    ) {
                        if fp1 == fp2 {
                            continue; // Same fingerprint — skip duplicate
                        }
                    }
                    // Materially different — update to latest
                    if events_materially_differ(terminal, event) {
                        last_terminal = Some(event.clone());
                    }
                } else {
                    last_terminal = Some(event.clone());
                }
            }
            EventTerminality::Advisory => {
                advisory_events.push(event.clone());
            }
            EventTerminality::Uncertainty => {
                advisory_events.push(event.clone());
            }
        }
    }

    last_terminal.map(|t| (t, advisory_events))
}

/// Check if two terminal events are materially different.
#[must_use]
pub fn events_materially_differ(a: &BkgEvent, b: &BkgEvent) -> bool {
    if a.event != b.event {
        return true;
    }
    if a.status != b.status {
        return true;
    }
    if a.failure_class != b.failure_class {
        return true;
    }
    if a.data != b.data {
        return true;
    }
    false
}

/// Deduplicate terminal events within a reconciliation window.
/// Returns only the first occurrence of each terminal fingerprint.
#[must_use]
pub fn dedupe_terminal_events(events: &[BkgEvent]) -> Vec<BkgEvent> {
    let mut seen = std::collections::HashSet::new();
    let mut result = Vec::new();

    for event in events {
        if is_terminal_event(event.event) {
            if let Some(fp) = &event.metadata.event_fingerprint {
                if !seen.insert(fp.clone()) {
                    continue;
                }
            }
        }
        result.push(event.clone());
    }
    result
}

// ──────────────────────────────────────────────
// Session Identity
// ──────────────────────────────────────────────

/// Session/agent identity with incremental enrichment support.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SessionIdentity {
    /// Stable title for the session/agent
    pub title: String,
    /// Workspace or node path
    pub workspace: String,
    /// Purpose or role description
    pub purpose: String,
    /// Reason for placeholder values (None = complete)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub placeholder_reason: Option<String>,
}

impl SessionIdentity {
    /// Create complete session identity.
    #[must_use]
    pub fn new(
        title: impl Into<String>,
        workspace: impl Into<String>,
        purpose: impl Into<String>,
    ) -> Self {
        Self {
            title: title.into(),
            workspace: workspace.into(),
            purpose: purpose.into(),
            placeholder_reason: None,
        }
    }

    /// Create session identity with placeholder for missing fields.
    #[must_use]
    pub fn with_placeholder(
        title: impl Into<String>,
        workspace: impl Into<String>,
        purpose: impl Into<String>,
        reason: impl Into<String>,
    ) -> Self {
        Self {
            title: title.into(),
            workspace: workspace.into(),
            purpose: purpose.into(),
            placeholder_reason: Some(reason.into()),
        }
    }

    /// Reconcile enriched metadata onto this session identity.
    /// Clears placeholder reason once real values are provided.
    #[must_use]
    pub fn reconcile_enriched(
        self,
        title: Option<String>,
        workspace: Option<String>,
        purpose: Option<String>,
    ) -> Self {
        let has_new = title.is_some() || workspace.is_some() || purpose.is_some();
        Self {
            title: title.unwrap_or(self.title),
            workspace: workspace.unwrap_or(self.workspace),
            purpose: purpose.unwrap_or(self.purpose),
            placeholder_reason: if has_new {
                None
            } else {
                self.placeholder_reason
            },
        }
    }
}

// ──────────────────────────────────────────────
// Nudge Tracking
// ──────────────────────────────────────────────

/// Nudge state tracking for acknowledgment and deduplication.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NudgeTracking {
    pub nudge_id: String,
    pub delivered_at: String,
    pub acknowledged: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub acknowledged_at: Option<String>,
    pub is_retry: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub original_nudge_id: Option<String>,
}

impl NudgeTracking {
    #[must_use]
    pub fn new(nudge_id: impl Into<String>, delivered_at: impl Into<String>) -> Self {
        Self {
            nudge_id: nudge_id.into(),
            delivered_at: delivered_at.into(),
            acknowledged: false,
            acknowledged_at: None,
            is_retry: false,
            original_nudge_id: None,
        }
    }

    #[must_use]
    pub fn retry(
        nudge_id: impl Into<String>,
        delivered_at: impl Into<String>,
        original_nudge_id: impl Into<String>,
    ) -> Self {
        Self {
            nudge_id: nudge_id.into(),
            delivered_at: delivered_at.into(),
            acknowledged: false,
            acknowledged_at: None,
            is_retry: true,
            original_nudge_id: Some(original_nudge_id.into()),
        }
    }

    #[must_use]
    pub fn acknowledge(mut self, at: impl Into<String>) -> Self {
        self.acknowledged = true;
        self.acknowledged_at = Some(at.into());
        self
    }
}

/// Classification of nudge types for deduplication.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NudgeClassification {
    New,
    Retry,
    StaleDuplicate,
}

/// Classify a nudge based on existing tracking records.
#[must_use]
pub fn classify_nudge(
    nudge_id: &str,
    existing: &[NudgeTracking],
    acknowledged_ids: &[String],
) -> NudgeClassification {
    if acknowledged_ids.iter().any(|id| id == nudge_id) {
        return NudgeClassification::StaleDuplicate;
    }
    for tracking in existing {
        if tracking.nudge_id == nudge_id {
            return if tracking.acknowledged {
                NudgeClassification::StaleDuplicate
            } else {
                NudgeClassification::Retry
            };
        }
        if tracking.original_nudge_id.as_ref() == Some(&nudge_id.to_string()) {
            return NudgeClassification::StaleDuplicate;
        }
    }
    NudgeClassification::New
}

// ──────────────────────────────────────────────
// Roadmap ID & Lifecycle
// ──────────────────────────────────────────────

/// Stable roadmap ID assignment for filed system items.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RoadmapId {
    pub id: String,
    pub filed_at: String,
    pub is_new_filing: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub supersedes: Option<String>,
}

impl RoadmapId {
    #[must_use]
    pub fn new_filing(id: impl Into<String>, filed_at: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            filed_at: filed_at.into(),
            is_new_filing: true,
            supersedes: None,
        }
    }

    #[must_use]
    pub fn update(id: impl Into<String>, filed_at: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            filed_at: filed_at.into(),
            is_new_filing: false,
            supersedes: None,
        }
    }

    #[must_use]
    pub fn supersedes(
        id: impl Into<String>,
        filed_at: impl Into<String>,
        previous_id: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            filed_at: filed_at.into(),
            is_new_filing: true,
            supersedes: Some(previous_id.into()),
        }
    }
}

/// Lifecycle state for roadmap/recovery items.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RoadmapLifecycleState {
    Filed,
    Acknowledged,
    InProgress,
    Blocked,
    Done,
    Superseded,
}

/// Roadmap item lifecycle with state machine + lineage tracking.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RoadmapLifecycle {
    pub state: RoadmapLifecycleState,
    pub state_changed_at: String,
    pub filed_at: String,
    #[serde(skip_serializing_if = "Vec::is_empty", default)]
    pub lineage: Vec<String>,
}

impl RoadmapLifecycle {
    #[must_use]
    pub fn new_filed(filed_at: impl Into<String>) -> Self {
        let filed_at = filed_at.into();
        Self {
            state: RoadmapLifecycleState::Filed,
            state_changed_at: filed_at.clone(),
            filed_at,
            lineage: Vec::new(),
        }
    }

    #[must_use]
    pub fn transition(mut self, new_state: RoadmapLifecycleState, at: impl Into<String>) -> Self {
        self.state = new_state;
        self.state_changed_at = at.into();
        self
    }

    #[must_use]
    pub fn superseded_by(mut self, new_item_id: impl Into<String>, at: impl Into<String>) -> Self {
        self.lineage.push(new_item_id.into());
        self.state = RoadmapLifecycleState::Superseded;
        self.state_changed_at = at.into();
        self
    }

    #[must_use]
    pub fn is_terminal(&self) -> bool {
        matches!(
            self.state,
            RoadmapLifecycleState::Done | RoadmapLifecycleState::Superseded
        )
    }

    #[must_use]
    pub fn is_active(&self) -> bool {
        !self.is_terminal()
    }
}

// ──────────────────────────────────────────────
// Startup Classification
// ──────────────────────────────────────────────

/// Classification of startup failures for deterministic boot handling.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum StartupFailureClass {
    /// Config file not found or malformed
    ConfigError,
    /// Mesh listener failed to bind
    MeshBindFailed,
    /// Ledger persistence backend failed to open
    LedgerPersistenceError,
    /// WASM runtime failed to initialize
    WasmInitError,
    /// Trust engine failed to initialize
    TrustEngineError,
    /// Guard LLM model load failed
    GuardModelError,
    /// Database migration failed
    MigrationError,
    /// Timeout during bootstrap
    BootTimeout,
}

/// Evidence bundle collected during a startup failure.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StartupEvidenceBundle {
    pub classification: StartupFailureClass,
    pub exit_code: Option<i32>,
    pub error_log_tail: Option<String>,
    pub last_config_path: Option<String>,
    pub elapsed_ms: u64,
    pub log_count: u32,
    pub crash_count: u32,
    pub recovery_attempted: bool,
}

impl StartupEvidenceBundle {
    #[must_use]
    pub fn new(classification: StartupFailureClass, elapsed_ms: u64) -> Self {
        Self {
            classification,
            exit_code: None,
            error_log_tail: None,
            last_config_path: None,
            elapsed_ms,
            log_count: 0,
            crash_count: 0,
            recovery_attempted: false,
        }
    }

    /// Set the exit code.
    #[must_use]
    pub fn with_exit_code(mut self, code: i32) -> Self {
        self.exit_code = Some(code);
        self
    }

    /// Set the error log tail.
    #[must_use]
    pub fn with_error_log(mut self, log: impl Into<String>) -> Self {
        self.error_log_tail = Some(log.into());
        self
    }

    /// Set the last config path.
    #[must_use]
    pub fn with_config_path(mut self, path: impl Into<String>) -> Self {
        self.last_config_path = Some(path.into());
        self
    }

    /// Set the log count.
    #[must_use]
    pub fn with_log_count(mut self, count: u32) -> Self {
        self.log_count = count;
        self
    }

    /// Set the crash count.
    #[must_use]
    pub fn with_crash_count(mut self, count: u32) -> Self {
        self.crash_count = count;
        self
    }

    /// Mark that recovery was attempted.
    #[must_use]
    pub fn with_recovery(mut self, attempted: bool) -> Self {
        self.recovery_attempted = attempted;
        self
    }
}

/// Classify a startup failure from raw evidence.
#[must_use]
pub fn classify_startup_failure(
    exit_code: Option<i32>,
    log_tail: Option<&str>,
    config_path: Option<&str>,
    elapsed_ms: u64,
    error_count: u32,
) -> StartupEvidenceBundle {
    let classification = match exit_code {
        Some(1) | Some(2) => {
            let log = log_tail.unwrap_or("");
            if log.contains("config") || log.contains("toml") || log.contains("parse") {
                StartupFailureClass::ConfigError
            } else if log.contains("mesh") || log.contains("bind") {
                StartupFailureClass::MeshBindFailed
            } else if log.contains("ledger") || log.contains("sqlite") {
                StartupFailureClass::LedgerPersistenceError
            } else if log.contains("wasm") || log.contains("runtime") {
                StartupFailureClass::WasmInitError
            } else if log.contains("trust") || log.contains("engine") {
                StartupFailureClass::TrustEngineError
            } else if log.contains("guard") || log.contains("model") {
                StartupFailureClass::GuardModelError
            } else if log.contains("migrate") || log.contains("schema") {
                StartupFailureClass::MigrationError
            } else {
                StartupFailureClass::ConfigError
            }
        }
        Some(137) | Some(143) => StartupFailureClass::BootTimeout, // SIGKILL/SIGTERM
        _ => StartupFailureClass::BootTimeout,
    };

    let mut bundle = StartupEvidenceBundle::new(classification, elapsed_ms);

    if let Some(code) = exit_code {
        bundle = bundle.with_exit_code(code);
    }
    if let Some(tail) = log_tail {
        bundle = bundle.with_error_log(tail.to_string());
    }
    if let Some(path) = config_path {
        bundle = bundle.with_config_path(path.to_string());
    }
    bundle = bundle.with_log_count(error_count);

    // If boot took > 30s, it's a timeout regardless of exit code
    if elapsed_ms > 30_000 {
        bundle.classification = StartupFailureClass::BootTimeout;
    }

    bundle
}

// ──────────────────────────────────────────────
// Macro: builder_method
// ──────────────────────────────────────────────

/// Internal macro for generating builder-pattern methods.
macro_rules! builder_method {
    ($name:ident, $target:ident, $type:ty) => {
        #[must_use]
        pub fn $name(mut self, value: impl Into<$type>) -> Self {
            self.$target = Some(value.into());
            self
        }
    };
}

pub(crate) use builder_method;

// ──────────────────────────────────────────────
// Event Filtering
// ──────────────────────────────────────────────

/// Filter events by provenance source.
#[must_use]
pub fn filter_by_provenance(events: &[BkgEvent], provenance: EventProvenance) -> Vec<BkgEvent> {
    events
        .iter()
        .filter(|e| e.metadata.provenance == provenance)
        .cloned()
        .collect()
}

/// Filter events by environment label.
#[must_use]
pub fn filter_by_environment(events: &[BkgEvent], environment: &str) -> Vec<BkgEvent> {
    events
        .iter()
        .filter(|e| {
            e.metadata
                .environment_label
                .as_ref()
                .is_some_and(|label| label == environment)
        })
        .cloned()
        .collect()
}

/// Filter events by minimum confidence level.
#[must_use]
pub fn filter_by_confidence(events: &[BkgEvent], min_confidence: ConfidenceLevel) -> Vec<BkgEvent> {
    let confidence_order = |c: ConfidenceLevel| match c {
        ConfidenceLevel::High => 3,
        ConfidenceLevel::Medium => 2,
        ConfidenceLevel::Low => 1,
        ConfidenceLevel::Unknown => 0,
    };
    let min_level = confidence_order(min_confidence);

    events
        .iter()
        .filter(|e| {
            e.metadata
                .confidence_level
                .is_some_and(|c| confidence_order(c) >= min_level)
        })
        .cloned()
        .collect()
}

/// Check if an event is from a test or synthetic source.
#[must_use]
pub fn is_test_event(event: &BkgEvent) -> bool {
    matches!(
        event.metadata.provenance,
        EventProvenance::Test | EventProvenance::Healthcheck | EventProvenance::Replay
    )
}

/// Check if an event is from a live production system.
#[must_use]
pub fn is_live_event(event: &BkgEvent) -> bool {
    event.metadata.provenance == EventProvenance::Live
}

// ──────────────────────────────────────────────
// Event Queue (in-memory buffer)
// ──────────────────────────────────────────────

/// Thread-safe, append-only event queue for in-process event streaming.
///
/// This is a simple Vec-based buffer. Production usage should replace with
/// a channel-based or persistent queue. Designed for:
/// - Mesh gossip emission
/// - Ledger commit events
/// - Motherbrain adjudication consumption
#[derive(Debug, Clone, Default)]
pub struct EventQueue {
    events: Vec<BkgEvent>,
    next_seq: u64,
}

impl EventQueue {
    /// Create a new empty event queue.
    #[must_use]
    pub fn new() -> Self {
        Self {
            events: Vec::new(),
            next_seq: 0,
        }
    }

    /// Push an event onto the queue.
    /// Assigns the next sequential ID to the event's metadata.
    pub fn push(&mut self, mut event: BkgEvent) {
        event.metadata.seq = self.next_seq;
        self.next_seq += 1;
        self.events.push(event);
    }

    /// Drain all events from the queue.
    #[must_use]
    pub fn drain(&mut self) -> Vec<BkgEvent> {
        std::mem::take(&mut self.events)
    }

    /// Peek at events without draining.
    #[must_use]
    pub fn peek(&self) -> &[BkgEvent] {
        &self.events
    }

    /// Number of events in the queue.
    #[must_use]
    pub fn len(&self) -> usize {
        self.events.len()
    }

    /// Whether the queue is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// Current sequence number (next event will get this seq).
    #[must_use]
    pub fn current_seq(&self) -> u64 {
        self.next_seq
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    // ── Event Name Taxonomy ──

    #[test]
    fn event_names_serialize_to_canonical_wire_values() {
        let cases = [
            (EventName::ObservationCollected, "observation.collected"),
            (EventName::TrustScoreChanged, "trust.score_changed"),
            (EventName::TrustEscalation, "trust.escalation"),
            (EventName::MotherbrainVerified, "motherbrain.verified"),
            (EventName::MotherbrainRejected, "motherbrain.rejected"),
            (EventName::ReplayCompleted, "replay.completed"),
            (EventName::ReplayFailed, "replay.failed"),
            (EventName::LedgerAppended, "ledger.appended"),
            (EventName::LedgerIntegrityOk, "ledger.integrity_ok"),
            (EventName::GcEntropyChanged, "gc.entropy_changed"),
            (EventName::MeshPeerConnected, "mesh.peer_connected"),
            (EventName::MeshAttackHotspot, "mesh.attack_hotspot"),
            (EventName::LifecycleBoot, "lifecycle.boot"),
            (EventName::LifecycleReady, "lifecycle.ready"),
            (EventName::LifecycleTaskFailed, "lifecycle.task_failed"),
        ];
        for (event, expected) in &cases {
            assert_eq!(
                serde_json::to_value(event).expect("serialize"),
                json!(expected)
            );
        }
    }

    // ── Failure Classification ──

    #[test]
    fn failure_classes_serialize_to_snake_case() {
        let cases = [
            (FailureClass::MeshPartition, "mesh_partition"),
            (FailureClass::LedgerStall, "ledger_stall"),
            (FailureClass::TrustGap, "trust_gap"),
            (FailureClass::ReplayMismatch, "replay_mismatch"),
            (FailureClass::CollusionDetected, "collusion_detected"),
            (FailureClass::GuardAdvisory, "guard_advisory"),
        ];
        for (fc, expected) in &cases {
            assert_eq!(
                serde_json::to_value(fc).expect("serialize"),
                json!(expected)
            );
        }
    }

    // ── Terminal Events ──

    #[test]
    fn terminal_events_are_correctly_classified() {
        assert!(is_terminal_event(EventName::LifecycleTaskCompleted));
        assert!(is_terminal_event(EventName::LifecycleTaskFailed));
        assert!(is_terminal_event(EventName::MotherbrainVerified));
        assert!(is_terminal_event(EventName::ReplayFailed));
        assert!(!is_terminal_event(EventName::ObservationCollected));
        assert!(!is_terminal_event(EventName::LifecycleBoot));
        assert!(!is_terminal_event(EventName::LifecycleReady));
    }

    // ── Event Builder ──

    #[test]
    fn event_builder_produces_correct_events() {
        let event = EventBuilder::new(
            EventName::ObservationCollected,
            EventStatus::Completed,
            "2026-05-23T00:00:00Z",
            0,
            EventProvenance::Live,
        )
        .with_detail("node-01 observed chunk-42")
        .with_environment("production")
        .with_data(json!({"chunk_id": "chunk-42", "node_id": "node-01"}))
        .build();

        assert_eq!(event.event, EventName::ObservationCollected);
        assert_eq!(event.metadata.seq, 0);
        assert_eq!(event.metadata.provenance, EventProvenance::Live);
        assert_eq!(
            event.metadata.environment_label.as_deref(),
            Some("production")
        );
        assert!(event.metadata.event_fingerprint.is_none());
    }

    #[test]
    fn terminal_builder_computes_fingerprint() {
        let event = EventBuilder::new(
            EventName::LifecycleTaskFailed,
            EventStatus::Failed,
            "2026-05-23T00:00:00Z",
            1,
            EventProvenance::Live,
        )
        .with_failure_class(FailureClass::LedgerStall)
        .with_detail("ledger write timeout")
        .build_terminal();

        assert!(event.metadata.event_fingerprint.is_some());
    }

    // ── Fingerprinting ──

    #[test]
    fn same_payload_produces_same_fingerprint() {
        let fp1 = compute_event_fingerprint(
            &EventName::LifecycleTaskCompleted,
            &EventStatus::Completed,
            Some(&json!({"result": "ok"})),
        );
        let fp2 = compute_event_fingerprint(
            &EventName::LifecycleTaskCompleted,
            &EventStatus::Completed,
            Some(&json!({"result": "ok"})),
        );
        assert_eq!(fp1, fp2);
    }

    #[test]
    fn different_payload_produces_different_fingerprint() {
        let fp1 = compute_event_fingerprint(
            &EventName::LifecycleTaskCompleted,
            &EventStatus::Completed,
            Some(&json!({"result": "ok"})),
        );
        let fp2 = compute_event_fingerprint(
            &EventName::LifecycleTaskCompleted,
            &EventStatus::Completed,
            Some(&json!({"result": "fail"})),
        );
        assert_ne!(fp1, fp2);
    }

    // ── Reconciliation ──

    #[test]
    fn reconcile_sorts_by_sequence() {
        // Use different data payloads to ensure different fingerprints
        let e1 = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            "2026-05-23T00:00:00Z",
            5,
            EventProvenance::Live,
        )
        .with_data(json!({"id": "final"}))
        .build_terminal();
        let e2 = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            "2026-05-23T00:00:01Z",
            2,
            EventProvenance::Live,
        )
        .with_data(json!({"id": "initial"}))
        .build_terminal();
        let e3 = EventBuilder::new(
            EventName::LifecycleReady,
            EventStatus::Ready,
            "2026-05-23T00:00:02Z",
            0,
            EventProvenance::Live,
        )
        .build();

        let result = reconcile_terminal_events(&[e1, e2, e3]);
        assert!(result.is_some());
        let (terminal, _) = result.unwrap();
        // Should pick the latest-sorted terminal (seq=5) as it is materially different
        assert_eq!(terminal.metadata.seq, 5);
        assert_eq!(
            terminal
                .data
                .as_ref()
                .and_then(|d| d.get("id"))
                .and_then(Value::as_str),
            Some("final")
        );
    }

    #[test]
    fn reconcile_deduplicates_same_fingerprint() {
        let e1 = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            "2026-05-23T00:00:00Z",
            0,
            EventProvenance::Live,
        )
        .with_data(json!({"result": "ok"}))
        .build_terminal();
        let e2 = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            "2026-05-23T00:00:01Z",
            1,
            EventProvenance::Live,
        )
        .with_data(json!({"result": "ok"}))
        .build_terminal();

        let result = reconcile_terminal_events(&[e1, e2]);
        assert!(result.is_some());
        let (_, advisory) = result.unwrap();
        // No advisory — duplicates collapsed
        assert!(advisory.is_empty());
    }

    #[test]
    fn reconcile_returns_none_for_empty() {
        assert!(reconcile_terminal_events(&[]).is_none());
    }

    #[test]
    fn events_materially_differ_detects_real_differences() {
        let a = EventBuilder::new(
            EventName::LifecycleTaskCompleted,
            EventStatus::Completed,
            "2026-05-23T00:00:00Z",
            0,
            EventProvenance::Live,
        )
        .build_terminal();
        let b = EventBuilder::new(
            EventName::LifecycleTaskFailed,
            EventStatus::Failed,
            "2026-05-23T00:00:01Z",
            1,
            EventProvenance::Live,
        )
        .build_terminal();

        assert!(events_materially_differ(&a, &b));
    }

    // ── Terminal Event Dedup ──

    #[test]
    fn dedupe_terminal_events_suppresses_duplicates() {
        let events = vec![
            EventBuilder::new(
                EventName::LifecycleTaskCompleted,
                EventStatus::Completed,
                "t1",
                0,
                EventProvenance::Live,
            )
            .with_data(json!({"id": 1}))
            .build_terminal(),
            EventBuilder::new(
                EventName::LifecycleTaskCompleted,
                EventStatus::Completed,
                "t2",
                1,
                EventProvenance::Live,
            )
            .with_data(json!({"id": 1}))
            .build_terminal(),
            EventBuilder::new(
                EventName::LifecycleBoot,
                EventStatus::Running,
                "t3",
                2,
                EventProvenance::Live,
            )
            .build(),
        ];

        let deduped = dedupe_terminal_events(&events);
        assert_eq!(deduped.len(), 2); // 1 terminal + 1 advisory
    }

    // ── Session Identity ──

    #[test]
    fn session_identity_reconcile_enriched_updates_fields() {
        let id = SessionIdentity::with_placeholder("boot", "", "", "not yet known");
        let id = id.reconcile_enriched(
            None,
            Some("/data/bkg".into()),
            Some("production node".into()),
        );
        assert_eq!(id.workspace, "/data/bkg");
        assert_eq!(id.purpose, "production node");
        assert_eq!(id.title, "boot");
        assert!(id.placeholder_reason.is_none());
    }

    #[test]
    fn session_identity_round_trips_through_json() {
        let id = SessionIdentity::new("node-01", "/data/bkg", "mesh collector");
        let json = serde_json::to_value(&id).unwrap();
        let back: SessionIdentity = serde_json::from_value(json).unwrap();
        assert_eq!(id, back);
    }

    // ── Nudge Tracking ──

    #[test]
    fn nudge_tracking_acknowledge_updates_state() {
        let nudge = NudgeTracking::new("nudge-01", "2026-05-23T00:00:00Z");
        let nudge = nudge.acknowledge("2026-05-23T00:00:05Z");
        assert!(nudge.acknowledged);
        assert_eq!(
            nudge.acknowledged_at.as_deref(),
            Some("2026-05-23T00:00:05Z")
        );
    }

    #[test]
    fn classify_nudge_detects_stale_duplicates() {
        let tracked = vec![NudgeTracking::new("n-1", "t1").acknowledge("t2")];
        assert_eq!(
            classify_nudge("n-1", &tracked, &[]),
            NudgeClassification::StaleDuplicate
        );
    }

    #[test]
    fn classify_nudge_detects_retries() {
        let tracked = vec![NudgeTracking::new("n-1", "t1")];
        assert_eq!(
            classify_nudge("n-1", &tracked, &[]),
            NudgeClassification::Retry
        );
    }

    #[test]
    fn classify_nudge_detects_new_nudges() {
        assert_eq!(classify_nudge("n-1", &[], &[]), NudgeClassification::New);
    }

    // ── Roadmap Lifecycle ──

    #[test]
    fn roadmap_lifecycle_transitions_correctly() {
        let lc = RoadmapLifecycle::new_filed("t0")
            .transition(RoadmapLifecycleState::InProgress, "t1")
            .transition(RoadmapLifecycleState::Done, "t2");
        assert_eq!(lc.state, RoadmapLifecycleState::Done);
        assert!(lc.is_terminal());
        assert!(!lc.is_active());
    }

    #[test]
    fn roadmap_lifecycle_superseded_tracks_lineage() {
        let lc = RoadmapLifecycle::new_filed("t0")
            .transition(RoadmapLifecycleState::InProgress, "t1")
            .superseded_by("item-02", "t2");
        assert_eq!(lc.state, RoadmapLifecycleState::Superseded);
        assert!(lc.is_terminal());
        assert_eq!(lc.lineage, vec!["item-02".to_string()]);
    }

    // ── Startup Classification ──

    #[test]
    fn classify_startup_config_error_from_exit_code_and_log() {
        let bundle = classify_startup_failure(
            Some(1),
            Some("error: failed to parse config.toml"),
            Some("/etc/bkg/config.toml"),
            1500,
            3,
        );
        assert_eq!(bundle.classification, StartupFailureClass::ConfigError);
        assert_eq!(bundle.exit_code, Some(1));
        assert_eq!(
            bundle.last_config_path.as_deref(),
            Some("/etc/bkg/config.toml")
        );
    }

    #[test]
    fn classify_startup_mesh_bind_failure() {
        let bundle = classify_startup_failure(
            Some(2),
            Some("mesh: failed to bind to 0.0.0.0:8765"),
            None,
            5000,
            5,
        );
        assert_eq!(bundle.classification, StartupFailureClass::MeshBindFailed);
    }

    #[test]
    fn classify_startup_timeout_on_long_boot() {
        let bundle = classify_startup_failure(Some(0), Some("boot successful"), None, 35_000, 0);
        assert_eq!(bundle.classification, StartupFailureClass::BootTimeout);
    }

    #[test]
    fn classify_startup_ledger_error() {
        let bundle = classify_startup_failure(
            Some(1),
            Some("ledger: sqlite error: database disk image is malformed"),
            None,
            2000,
            1,
        );
        assert_eq!(
            bundle.classification,
            StartupFailureClass::LedgerPersistenceError
        );
    }

    // ── Event Queue ──

    #[test]
    fn event_queue_assigns_monotonic_sequences() {
        let mut queue = EventQueue::new();
        queue.push(BkgEvent::boot("t1", None));
        queue.push(BkgEvent::ready("t2"));
        queue.push(BkgEvent::task_completed("t3", None, None));

        assert_eq!(queue.len(), 3);
        let drained = queue.drain();
        assert_eq!(drained[0].metadata.seq, 0);
        assert_eq!(drained[1].metadata.seq, 1);
        assert_eq!(drained[2].metadata.seq, 2);
        assert!(queue.is_empty());
    }

    #[test]
    fn event_queue_round_trips_through_serialization() {
        let mut queue = EventQueue::new();
        queue.push(BkgEvent::boot("t1", Some("system boot".into())));
        queue.push(BkgEvent::ready("t2"));

        let json = serde_json::to_string(&queue.drain()).unwrap();
        let events: Vec<BkgEvent> = serde_json::from_str(&json).unwrap();
        assert_eq!(events.len(), 2);
        assert_eq!(events[0].event, EventName::LifecycleBoot);
    }

    // ── Serialization Round-Trips ──

    #[test]
    fn full_event_round_trips_through_json() {
        let event = EventBuilder::new(
            EventName::MotherbrainVerified,
            EventStatus::Completed,
            "2026-05-23T12:00:00Z",
            42,
            EventProvenance::Live,
        )
        .with_environment("production")
        .with_emitter("motherbrain-01")
        .with_confidence(ConfidenceLevel::High)
        .with_detail("chunk-100 verified by 3/5 quorum")
        .with_data(json!({
            "chunk_id": "chunk-100",
            "quorum": "3/5",
            "avg_trust": 0.92,
        }))
        .build_terminal();

        let json = serde_json::to_value(&event).unwrap();
        let back: BkgEvent = serde_json::from_value(json).unwrap();

        assert_eq!(back.event, EventName::MotherbrainVerified);
        assert_eq!(back.metadata.seq, 42);
        assert_eq!(back.metadata.environment_label, Some("production".into()));
        assert_eq!(
            back.metadata.emitter_identity,
            Some("motherbrain-01".into())
        );
        assert_eq!(back.metadata.confidence_level, Some(ConfidenceLevel::High));
        assert!(back.metadata.event_fingerprint.is_some());
    }

    // ── Provenance Filtering ──

    #[test]
    fn filter_by_provenance_selects_correct_events() {
        let live = BkgEvent::new(EventName::LifecycleBoot, EventStatus::Running, "t1");
        let test = EventBuilder::new(
            EventName::ObservationCollected,
            EventStatus::Completed,
            "t2",
            1,
            EventProvenance::Test,
        )
        .build();
        let result = super::filter_by_provenance(&[live, test], EventProvenance::Test);
        assert_eq!(result.len(), 1);
        assert_eq!(result[0].metadata.provenance, EventProvenance::Test);
    }
}
