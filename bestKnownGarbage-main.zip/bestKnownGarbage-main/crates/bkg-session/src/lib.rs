//! Session management — resume, branching, git integration, dry-run.
//!
//! Ported from mythos-router. See `/home/bkg/workspace/mythos-router/src/session.ts`
//! and `/home/bkg/workspace/mythos-router/src/git.ts`

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;
use std::process::Command;

// ── Types ────────────────────────────────────────────────────

/// Session state for resume.
///
/// A Session is the **host** context executing exactly one UCC-4 Capsule.
/// `active_capsule_id` is the hard binding — the session cannot outlive its capsule.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionState {
    /// Unique session ID
    pub id: String,
    /// HARD BIND: every session runs in exactly one UCC-4 Capsule
    #[serde(default)]
    pub active_capsule_id: String,
    /// When the session started
    pub created_at: String,
    /// Last activity timestamp
    pub updated_at: String,
    /// Session conversation summary
    pub summary: String,
    /// Budget state at save
    pub budget_snapshot: Option<String>,
    /// Git state at save
    pub git_branch: Option<String>,
    pub git_commit: Option<String>,
    /// Whether dry-run mode was active
    pub dry_run: bool,
    /// Session metadata
    pub metadata: std::collections::HashMap<String, String>,
}

/// Session configuration.
#[derive(Debug, Clone)]
pub struct SessionConfig {
    /// Working directory
    pub working_dir: PathBuf,
    /// Session storage directory (default: ~/.bkg/sessions)
    pub storage_dir: Option<PathBuf>,
    /// Enable git session branching
    pub git_branching: bool,
    /// Git branch prefix for sessions
    pub branch_prefix: String,
    /// Dry-run mode (preview only)
    pub dry_run: bool,
    /// Verbose tracing
    pub verbose: bool,
}

impl Default for SessionConfig {
    fn default() -> Self {
        Self {
            working_dir: PathBuf::from("."),
            storage_dir: None,
            git_branching: false,
            branch_prefix: "bkg/".to_string(),
            dry_run: false,
            verbose: false,
        }
    }
}

/// Errors from session operations.
#[derive(Debug, thiserror::Error)]
pub enum SessionError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Git error: {0}")]
    Git(String),
    #[error("Session not found: {0}")]
    NotFound(String),
    #[error("Serialization error: {0}")]
    Serialize(String),
}

type Result<T> = std::result::Result<T, SessionError>;

// ── Session Manager ──────────────────────────────────────────

/// Manages session lifecycle, resume, and git branching.
pub struct SessionManager {
    config: SessionConfig,
    state: Option<SessionState>,
}

impl SessionManager {
    pub fn new(config: SessionConfig) -> Self {
        Self {
            config,
            state: None,
        }
    }

    fn storage_dir(&self) -> PathBuf {
        self.config.storage_dir.clone().unwrap_or_else(|| {
            let home = std::env::var("HOME").unwrap_or_else(|_| ".".to_string());
            PathBuf::from(home).join(".bkg").join("sessions")
        })
    }

    /// Start a new session.
    pub fn start(&mut self, summary: &str) -> Result<SessionState> {
        let now = chrono::Utc::now();
        let id = format!("sess_{}", now.format("%Y%m%d_%H%M%S"));

        let git_branch = if self.config.git_branching {
            self.create_session_branch(&id).ok()
        } else {
            None
        };

        let (git_branch_name, git_commit) = self.get_git_state();

        let state = SessionState {
            id,
            active_capsule_id: String::new(),
            created_at: now.to_rfc3339(),
            updated_at: now.to_rfc3339(),
            summary: summary.to_string(),
            budget_snapshot: None,
            git_branch: git_branch_name.or(git_branch),
            git_commit,
            dry_run: self.config.dry_run,
            metadata: std::collections::HashMap::new(),
        };

        self.state = Some(state.clone());
        self.save()?;
        Ok(state)
    }

    /// Save current session state.
    pub fn save(&self) -> Result<()> {
        let state = self
            .state
            .as_ref()
            .ok_or_else(|| SessionError::NotFound("No active session".to_string()))?;

        let dir = self.storage_dir();
        fs::create_dir_all(&dir)?;

        let path = dir.join(format!("{}.json", state.id));
        let content = serde_json::to_string_pretty(state)
            .map_err(|e| SessionError::Serialize(e.to_string()))?;
        fs::write(&path, &content)?;

        // Also save as latest.json for --resume
        let latest_path = dir.join("latest.json");
        fs::write(&latest_path, &content)?;

        Ok(())
    }

    /// Resume the latest session.
    pub fn resume_latest(&mut self) -> Result<SessionState> {
        let dir = self.storage_dir();
        let latest_path = dir.join("latest.json");

        if !latest_path.exists() {
            return Err(SessionError::NotFound(
                "No previous session to resume".to_string(),
            ));
        }

        let content = fs::read_to_string(&latest_path)?;
        let state: SessionState =
            serde_json::from_str(&content).map_err(|e| SessionError::Serialize(e.to_string()))?;

        self.state = Some(state.clone());
        Ok(state)
    }

    /// Resume a specific session by ID.
    pub fn resume(&mut self, session_id: &str) -> Result<SessionState> {
        let dir = self.storage_dir();
        let path = dir.join(format!("{}.json", session_id));

        if !path.exists() {
            return Err(SessionError::NotFound(format!(
                "Session not found: {}",
                session_id
            )));
        }

        let content = fs::read_to_string(&path)?;
        let state: SessionState =
            serde_json::from_str(&content).map_err(|e| SessionError::Serialize(e.to_string()))?;

        self.state = Some(state.clone());
        Ok(state)
    }

    /// Update session state.
    pub fn update(&mut self, f: impl FnOnce(&mut SessionState)) -> Result<()> {
        if let Some(ref mut state) = self.state {
            state.updated_at = chrono::Utc::now().to_rfc3339();
            f(state);
            self.save()?;
        }
        Ok(())
    }

    /// Update budget snapshot in session state.
    pub fn update_budget(&mut self, snapshot: &str) -> Result<()> {
        self.update(|s| s.budget_snapshot = Some(snapshot.to_string()))
    }

    /// Get current session state.
    pub fn state(&self) -> Option<&SessionState> {
        self.state.as_ref()
    }

    /// List all saved sessions.
    pub fn list_sessions(&self) -> Result<Vec<SessionState>> {
        let dir = self.storage_dir();
        if !dir.exists() {
            return Ok(vec![]);
        }

        let mut sessions = Vec::new();
        for entry in fs::read_dir(&dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) == Some("json")
                && path
                    .file_stem()
                    .and_then(|s| s.to_str())
                    .map(|s| s.starts_with("sess_"))
                    .unwrap_or(false)
            {
                if let Ok(content) = fs::read_to_string(&path) {
                    if let Ok(state) = serde_json::from_str::<SessionState>(&content) {
                        sessions.push(state);
                    }
                }
            }
        }

        // Sort by creation time, newest first
        sessions.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        Ok(sessions)
    }

    /// List sessions as formatted string.
    pub fn format_sessions(&self) -> Result<String> {
        let sessions = self.list_sessions()?;
        if sessions.is_empty() {
            return Ok("No saved sessions.".to_string());
        }

        let mut out = format!("=== Saved Sessions ({} total) ===\n\n", sessions.len());
        for (i, session) in sessions.iter().enumerate() {
            let branch_info = session
                .git_branch
                .as_ref()
                .map(|b| format!(" [branch: {}]", b))
                .unwrap_or_default();
            out.push_str(&format!(
                "{}. {} | {} | {}{}\n",
                i + 1,
                &session.id[..20.min(session.id.len())],
                &session.created_at[..19],
                &session.summary[..60.min(session.summary.len())],
                branch_info,
            ));
        }
        Ok(out)
    }

    // ── Git Operations ──────────────────────────────────────

    fn get_git_state(&self) -> (Option<String>, Option<String>) {
        let branch = self.git_command(&["rev-parse", "--abbrev-ref", "HEAD"]);
        let commit = self.git_command(&["rev-parse", "--short", "HEAD"]);
        (branch, commit)
    }

    fn git_command(&self, args: &[&str]) -> Option<String> {
        Command::new("git")
            .args(args)
            .current_dir(&self.config.working_dir)
            .output()
            .ok()
            .and_then(|o| {
                if o.status.success() {
                    String::from_utf8(o.stdout)
                        .ok()
                        .map(|s| s.trim().to_string())
                } else {
                    None
                }
            })
    }

    /// Create a session branch for isolation.
    pub fn create_session_branch(&self, session_id: &str) -> Result<String> {
        let branch_name = format!("{}{}", self.config.branch_prefix, session_id);

        // Check if we're in a git repo
        let root = self.git_command(&["rev-parse", "--show-toplevel"]);
        if root.is_none() {
            return Err(SessionError::Git("Not a git repository".to_string()));
        }

        // Create and switch to branch
        let output = Command::new("git")
            .args(["checkout", "-b", &branch_name])
            .current_dir(&self.config.working_dir)
            .output()
            .map_err(|e| SessionError::Git(e.to_string()))?;

        if !output.status.success() {
            let _stderr = String::from_utf8_lossy(&output.stderr);
            // Branch may already exist, try switching instead
            Command::new("git")
                .args(["checkout", &branch_name])
                .current_dir(&self.config.working_dir)
                .output()
                .map_err(|e| SessionError::Git(e.to_string()))?;
        }

        Ok(branch_name)
    }

    /// Commit session changes to the branch.
    pub fn commit_session(&self, message: &str) -> Result<()> {
        // Stage all changes
        Command::new("git")
            .args(["add", "-A"])
            .current_dir(&self.config.working_dir)
            .output()
            .map_err(|e| SessionError::Git(e.to_string()))?;

        // Commit
        let output = Command::new("git")
            .args(["commit", "-m", message])
            .current_dir(&self.config.working_dir)
            .output()
            .map_err(|e| SessionError::Git(e.to_string()))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            if !stderr.contains("nothing to commit") {
                return Err(SessionError::Git(stderr.to_string()));
            }
        }

        Ok(())
    }

    /// End session — optionally commit and merge back.
    pub fn end(&mut self, commit_message: Option<&str>) -> Result<()> {
        if let Some(ref state) = self.state {
            if self.config.git_branching {
                if let Some(ref _branch) = state.git_branch {
                    // Commit if message provided
                    if let Some(msg) = commit_message {
                        self.commit_session(msg)?;
                    }

                    // Switch back to main branch
                    Command::new("git")
                        .args(["checkout", "main"])
                        .current_dir(&self.config.working_dir)
                        .output()
                        .ok();
                }
            }

            self.update(|s| {
                s.updated_at = chrono::Utc::now().to_rfc3339();
            })?;
        }

        self.state = None;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_session_lifecycle() {
        let dir = std::env::temp_dir().join("sess-test");
        let _ = fs::remove_dir_all(&dir);

        let config = SessionConfig {
            working_dir: dir.clone(),
            storage_dir: Some(dir.join(".bkg").join("sessions")),
            dry_run: true,
            ..Default::default()
        };

        let mut mgr = SessionManager::new(config);
        let state = mgr.start("test session").unwrap();
        assert!(state.id.starts_with("sess_"));
        assert_eq!(state.dry_run, true);

        // Save and resume
        mgr.save().unwrap();
        let mut mgr2 = SessionManager::new(SessionConfig {
            working_dir: dir.clone(),
            storage_dir: Some(dir.join(".bkg").join("sessions")),
            ..Default::default()
        });
        let resumed = mgr2.resume_latest().unwrap();
        assert_eq!(resumed.id, state.id);
        assert_eq!(resumed.summary, "test session");

        let _ = fs::remove_dir_all(&dir);
    }
}
