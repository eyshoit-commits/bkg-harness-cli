//! BKG telemetry — shared crate
