//! BKG serde — shared crate
