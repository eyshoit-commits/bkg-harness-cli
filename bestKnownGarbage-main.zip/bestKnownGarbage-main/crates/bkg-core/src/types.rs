//! BKG Core Types
//!
//! Fundamental types used across the entire BKG kernel system.

use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};

/// Node identifier type
pub type NodeId = String;

/// Chunk identifier type
pub type ChunkId = String;

/// Hash type for content addressing
pub type Hash = String;

/// Timestamp in milliseconds since Unix epoch
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Timestamp(pub u64);

impl Timestamp {
    /// Create a new timestamp at the current time
    pub fn now() -> Self {
        Self(
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_millis() as u64,
        )
    }
}

/// Cryptographic signature
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Signature(pub String);

impl Signature {
    /// Create a new signature from a string
    pub fn new(s: impl Into<String>) -> Self {
        Self(s.into())
    }
}

/// Epoch number for evolutionary tracking
pub type Epoch = u64;

/// Trust score value (0.0 to 1.0)
pub type TrustScore = f32;

/// Stability index (0.0 to 1.0)
pub type StabilityIndex = f32;

/// Reproducibility score (0.0 to 1.0)
pub type ReproducibilityScore = f32;

/// Entropy measure (0.0 to 1.0)
pub type Entropy = f32;

/// Divergence measure (0.0 to 1.0)
pub type Divergence = f32;

/// Severity level for failures (0.0 to 1.0)
pub type Severity = f32;

/// Weight for scoring functions (0.0 to 1.0)
pub type Weight = f32;
