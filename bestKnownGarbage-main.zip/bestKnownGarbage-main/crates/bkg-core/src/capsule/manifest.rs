//! CapsuleGraphManifest — cryptographic summary of a capsule graph.
//!
//! This is distinct from `chain::Manifest` — the chain manifest covers
//! the sequential execution (prompts, outputs, truth). The graph manifest
//! covers the DAG structure (nodes, edges, topology).
//!
//! # Usage
//!
//! The manifest is regenerated after every mutation to the graph.
//! It enables:
//! - Fast diff: compare two manifests instead of loading all nodes
//! - Integrity: recompute hashes and compare
//! - Audit trail: sign and timestamp the graph state

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use super::edge::EdgeId;
use super::node::NodeId;

/// Cryptographic manifest for a capsule graph.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleGraphManifest {
    pub capsule_id: String,
    pub schema_version: u32,
    pub generated_at: DateTime<Utc>,
    pub node_count: usize,
    pub edge_count: usize,
    pub root_hash: String,
    pub node_hashes: Vec<(NodeId, String)>,
    pub edge_hashes: Vec<(EdgeId, String)>,
}

impl CapsuleGraphManifest {
    pub const SCHEMA_VERSION: u32 = 1;

    /// Create a new, empty manifest.
    pub fn new(capsule_id: impl Into<String>) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            schema_version: Self::SCHEMA_VERSION,
            generated_at: Utc::now(),
            node_count: 0,
            edge_count: 0,
            root_hash: String::new(),
            node_hashes: Vec::new(),
            edge_hashes: Vec::new(),
        }
    }

    /// Verify that the manifest's root_hash matches the given hash.
    pub fn verify_root_hash(&self, actual_root_hash: &str) -> bool {
        if self.root_hash.is_empty() {
            return true; // empty manifest is always valid
        }
        self.root_hash == actual_root_hash
    }
}
