//! **Causa** — the persistent causal unit (BKG Reveland).
//!
//! In the Reveland, the capsule is **Causa** (Latin for "cause/reason"):
//! the persistent causal unit that carries provenance through time.
//! Causa provides the graph, timeline, and self-healing capabilities.
//!
//! # UCC-4 Capsule Graph — live DAG over execution artifacts with self-healing.
//!
//! This module is the **soul of the BKG stack** — every application (CLI, web,
//! motherbrain, client) builds on these types. It provides:
//!
//! - **Memory** kernel: `CapsuleGraph` — directed acyclic graph of nodes/edges
//! - **Execution** kernel: `GraphEvent` / `GraphStreamEngine` — event-driven pipeline
//! - **Time** kernel: `TemporalReplayEngine` / `EventTimeline` — state snapshots + replay
//! - **Truth** kernel: `CapsuleRepairEngine` / `diff` — integrity verification + drift detection
//! - **Evolution** kernel: `SelfHealingLoop` / `HealingGuard` — self-healing orchestration
//!
//! # Architecture
//!
//! ```text
//! Execution / Rehydration / Repair / Replay
//!         ↓
//!    GraphEvent / RepairEvent
//!         ↓
//!    GraphStreamEngine → temporal::TemporalReplayEngine
//!         ↓                           ↓
//!    DagUiState (reducer)      EventTimeline (snapshots)
//!         ↓                           ↓
//!    DagRenderer              SelfHealingLoop
//!         ↓                           ↓
//!     TUI display           HealingGuard → HealingPolicy
//! ```
//!
//! # UCC-4 Kernel Mapping
//!
//! | Kernel     | Module          | Key Types                          |
//! |------------|-----------------|------------------------------------|
//! | Memory     | `graph`, `node` | `CapsuleGraph`, `CapsuleNode`      |
//! | Execution  | `event`, `bus`  | `GraphEvent`, `GraphStreamEngine`  |
//! | Time       | `temporal`      | `TemporalReplayEngine`, `Snapshot` |
//! | Truth      | `diff`, `repair`| `CapsuleRepairEngine`, `Drift`     |
//! | Evolution  | `healing`       | `SelfHealingLoop`, `HealingGuard`  |
//!
//! # Production Readiness
//!
//! Every fallible operation returns `CapsuleResult<T>`. No `unwrap()`,
//! no `expect()`, no panics. All public types implement `Send + Sync`.
//! Deterministic hashing ensures identical graphs produce identical hashes.
//!
//! # Event-Driven Design
//!
//! Every source (engine, rehydrator, repairer, replayer) emits events into a
//! `GraphEventBus`. The `GraphStreamEngine` persists events to a timeline.jsonl
//! and forwards them to subscribers. The TUI `DagUiState` reduces events into
//! renderable state — no polling, no file-watching, no duplicated state.

pub mod bus;
pub mod diff;
pub mod edge;
pub mod error;
pub mod event;
pub mod graph;
pub mod guard;
pub mod healing;
pub mod r#loop;
pub mod manifest;
pub mod node;
pub mod policy;
pub mod rehydration;
pub mod repair;
pub mod replay;
pub mod self_heal;
pub mod snapshot;
pub mod storage;
pub mod stream;
pub mod temporal;
pub mod timeline;
pub mod types;

pub use bus::{GraphEventBus, TokioGraphEventBus};
pub use diff::{DriftFinding, GraphDiff, NodeDiff};
pub use edge::{CapsuleEdge, EdgeType};
pub use error::{CapsuleError, CapsuleResult};
pub use event::{GraphEvent, GraphEventKind, GraphSeverity, RepairEvent, RepairEventKind};
pub use graph::CapsuleGraph;
pub use guard::{GuardConfig, GuardResult, HealingGuard};
pub use healing::{HealingCycleResult, HealingEngine, HealingPhase};
pub use r#loop::{
    HealingLoopConfig, HealingLoopState, HealingLoopSummary, SelfHealingLoop, TrackedCapsule,
};
pub use manifest::CapsuleGraphManifest;
pub use node::{CapsuleNode, NodeKind, NodeStatus};
pub use policy::{ApprovalMode, DriftThresholds, EscalationConfig, HealingPolicy, HealingSeverity};
pub use rehydration::CapsuleEngine;
pub use repair::{
    CapsuleRepairEngine, DefaultCapsuleRepairEngine, RepairAction, RepairActionResult,
    RepairRequest, RepairResult,
};
pub use replay::{ReplayEngine, ReplayStats, ReplayVerificationResult};
pub use self_heal::{HealStrategy, heal_capsule, is_healable};
pub use snapshot::{SnapshotId, StateSnapshot};
pub use storage::{FilesystemGraphStorage, GraphStorage};
pub use stream::GraphStreamEngine;
pub use temporal::{PlaybackSpeed, ReplayDirection, ReplayResult, TemporalReplayEngine};
pub use timeline::EventTimeline;
pub use types::{Capsule, CapsuleStatus, TimelineEntry, TimelineId, TimelineSummary};
