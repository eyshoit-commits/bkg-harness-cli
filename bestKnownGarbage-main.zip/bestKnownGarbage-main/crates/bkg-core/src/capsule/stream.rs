//! GraphStreamEngine — event emission with optional persistence.
//!
//! The `GraphStreamEngine` sits between event sources and the event bus.
//! It provides:
//! - **Persistence**: appends every event to `timeline.jsonl` (append-only log)
//! - **Delivery**: publishes to the `GraphEventBus` for subscribers
//! - **Idempotency**: events are written first, then published
//!
//! # Timeline Format
//!
//! The timeline is a JSONL file (one JSON object per line). This format is:
//! - Append-friendly (no seeks, no rewrites)
//! - Grep-friendly (search with `rg` or `grep`)
//! - Streamable (read line by line for replay)
//! - Compressible (gzip compresses JSONL very well)

use chrono::Utc;
use std::path::PathBuf;

use super::bus::GraphEventBus;
use super::event::GraphEvent;

/// Streams events from sources to bus + disk.
///
/// # Usage
///
/// ```rust,ignore
/// let bus = TokioGraphEventBus::new(4096);
/// let engine = GraphStreamEngine::new(bus, "~/.bkg/capsules/cap-1/graph/timeline.jsonl");
/// engine.emit(event).await?;
/// ```
pub struct GraphStreamEngine<B: GraphEventBus> {
    pub bus: B,
    pub timeline_path: PathBuf,
    pub enable_persistence: bool,
}

impl<B: GraphEventBus> GraphStreamEngine<B> {
    /// Create a new stream engine.
    ///
    /// `timeline_path` is the path to the JSONL timeline file.
    pub fn new(bus: B, timeline_path: impl Into<PathBuf>) -> Self {
        Self {
            bus,
            timeline_path: timeline_path.into(),
            enable_persistence: true,
        }
    }

    /// Disable or enable event persistence to disk.
    pub fn with_persistence(mut self, enable: bool) -> Self {
        self.enable_persistence = enable;
        self
    }

    /// Emit an event: persist, then publish.
    ///
    /// Events are written to disk FIRST, then published to the bus.
    /// This ensures at-least-once delivery: if the publish fails,
    /// the event is still on disk for recovery.
    pub async fn emit(&self, mut event: GraphEvent) -> Result<(), String> {
        if event.created_at.timestamp() == 0 {
            event.created_at = Utc::now();
        }

        // Persist first (crash-safe: event on disk even if publish fails)
        if self.enable_persistence {
            self.append_timeline(&event)?;
        }

        // Then publish to bus
        self.bus.publish(event).await
    }

    /// Append a single event to the timeline file.
    fn append_timeline(&self, event: &GraphEvent) -> Result<(), String> {
        use std::fs::OpenOptions;
        use std::io::Write;

        // Ensure parent directory exists
        if let Some(parent) = self.timeline_path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("failed to create timeline directory: {}", e))?;
        }

        let line = serde_json::to_string(event).map_err(|e| e.to_string())?;
        let mut file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(&self.timeline_path)
            .map_err(|e| format!("failed to open timeline: {}", e))?;

        writeln!(file, "{line}").map_err(|e| format!("failed to write timeline: {}", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::bus::TokioGraphEventBus;
    use crate::capsule::event::{GraphEventKind, GraphSeverity};
    use std::env::temp_dir;
    use uuid::Uuid;

    #[tokio::test]
    async fn test_emit_event() {
        let bus = TokioGraphEventBus::new(16);
        let mut rx = bus.subscribe();

        let tmp = temp_dir().join(format!("timeline-{}.jsonl", Uuid::new_v4()));
        let engine = GraphStreamEngine::new(bus, &tmp);

        let event = GraphEvent::new("cap-test", GraphEventKind::NodeAdded, GraphSeverity::Info);
        engine.emit(event).await.unwrap();

        // Verify it arrived at the subscriber
        let received = rx.recv().await.unwrap();
        assert_eq!(received.kind, GraphEventKind::NodeAdded);

        // Verify it was written to disk
        let content = std::fs::read_to_string(&tmp).unwrap();
        assert!(!content.is_empty());
        assert!(content.contains("cap-test"));

        // Cleanup
        let _ = std::fs::remove_file(&tmp);
    }

    #[tokio::test]
    async fn test_persistence_disabled() {
        let bus = TokioGraphEventBus::new(16);
        // Keep a subscriber alive so broadcast send doesn't fail
        let mut _rx = bus.subscribe();
        let tmp = temp_dir().join(format!("timeline-disabled-{}.jsonl", Uuid::new_v4()));
        let engine = GraphStreamEngine::new(bus, &tmp).with_persistence(false);

        let event = GraphEvent::new("cap-test", GraphEventKind::NodeRemoved, GraphSeverity::Warn);
        engine.emit(event).await.unwrap();

        // Verify nothing was written to disk
        assert!(!tmp.exists());
    }
}
