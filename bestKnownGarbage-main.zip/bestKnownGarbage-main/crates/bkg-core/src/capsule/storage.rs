//! GraphStorage — persist capsule graphs to the filesystem.
//!
//! Storage is segmented: each node and edge is a separate JSON file.
//! This enables incremental updates, atomic writes, and partial repair.
//!
//! # Directory Layout
//!
//! ```text
//! ~/.bkg/capsules/
//! └── cap-<id>/
//!     ├── graph/
//!     │   ├── manifest.json    ← CapsuleGraphManifest
//!     │   ├── nodes/
//!     │   │   ├── <node-id>.json
//!     │   │   └── ...
//!     │   ├── edges/
//!     │   │   ├── <edge-id>.json
//!     │   │   └── ...
//!     │   └── timeline.jsonl   ← event log
//!     ├── capsule.json         ← existing TruthCapsule
//!     ├── chain.json           ← existing Chain
//!     └── ...
//! ```

use async_trait::async_trait;
use std::collections::HashMap;
use std::path::{Path, PathBuf};

use super::edge::CapsuleEdge;
use super::graph::CapsuleGraph;
use super::manifest::CapsuleGraphManifest;
use super::node::CapsuleNode;

/// File-based graph storage.
///
/// All operations are async (via `tokio::fs` for non-blocking I/O).
/// The `base_path` is typically `~/.bkg/` or a custom data directory.
#[async_trait]
pub trait GraphStorage: Send + Sync {
    /// Load the full graph (all nodes + edges) for a capsule.
    async fn load_graph(&self, capsule_id: &str) -> Result<CapsuleGraph, String>;

    /// Save the full graph (all nodes + edges) for a capsule.
    async fn save_graph(&self, graph: &CapsuleGraph) -> Result<(), String>;

    /// Load the graph manifest for a capsule.
    async fn load_manifest(&self, capsule_id: &str) -> Result<CapsuleGraphManifest, String>;

    /// Save the graph manifest for a capsule.
    async fn save_manifest(&self, manifest: &CapsuleGraphManifest) -> Result<(), String>;

    /// Save a single node file.
    async fn save_node(&self, capsule_id: &str, node: &CapsuleNode) -> Result<(), String>;

    /// Save a single edge file.
    async fn save_edge(&self, capsule_id: &str, edge: &CapsuleEdge) -> Result<(), String>;

    /// Delete a single node file.
    async fn delete_node(&self, capsule_id: &str, node_id: &str) -> Result<(), String>;

    /// Delete a single edge file.
    async fn delete_edge(&self, capsule_id: &str, edge_id: &str) -> Result<(), String>;

    /// Repair a capsule: rebuild graph from node/edge files, recompute manifest.
    async fn repair_capsule(&self, capsule_id: &str) -> Result<(), String>;
}

/// Filesystem-based implementation of `GraphStorage`.
///
/// Uses `~/.bkg/capsules/<capsule_id>/graph/` as the storage root.
/// Each node and edge is stored as `<id>.json` in `nodes/` or `edges/`.
pub struct FilesystemGraphStorage {
    base_path: PathBuf,
}

impl FilesystemGraphStorage {
    /// Create a new filesystem graph storage at the given base path.
    ///
    /// `base_path` should be the BKG data directory (e.g., `~/.bkg`).
    /// The actual graph data will be stored under `capsules/<id>/graph/`.
    pub fn new(base_path: impl Into<PathBuf>) -> Self {
        Self {
            base_path: base_path.into(),
        }
    }

    fn graph_dir(&self, capsule_id: &str) -> PathBuf {
        self.base_path
            .join("capsules")
            .join(capsule_id)
            .join("graph")
    }

    fn nodes_dir(&self, capsule_id: &str) -> PathBuf {
        self.graph_dir(capsule_id).join("nodes")
    }

    fn edges_dir(&self, capsule_id: &str) -> PathBuf {
        self.graph_dir(capsule_id).join("edges")
    }

    fn manifest_path(&self, capsule_id: &str) -> PathBuf {
        self.graph_dir(capsule_id).join("manifest.json")
    }

    fn ensure_dirs(&self, capsule_id: &str) -> std::io::Result<()> {
        std::fs::create_dir_all(self.nodes_dir(capsule_id))?;
        std::fs::create_dir_all(self.edges_dir(capsule_id))?;
        Ok(())
    }

    /// Read a list of JSON files from a directory, sorted by filename.
    fn read_json_dir<T: serde::de::DeserializeOwned>(
        dir: &Path,
    ) -> Result<Vec<(String, T)>, String> {
        if !dir.exists() {
            return Ok(Vec::new());
        }

        let mut entries: Vec<_> = std::fs::read_dir(dir)
            .map_err(|e| format!("failed to read dir {}: {}", dir.display(), e))?
            .filter_map(|e| e.ok())
            .filter(|e| e.path().extension().map_or(false, |ext| ext == "json"))
            .collect();
        entries.sort_by_key(|e| e.file_name());

        let mut results = Vec::new();
        for entry in entries {
            let path = entry.path();
            let file_stem = entry
                .file_name()
                .into_string()
                .unwrap_or_default()
                .replace(".json", "");
            let content = std::fs::read_to_string(&path)
                .map_err(|e| format!("failed to read {}: {}", path.display(), e))?;
            let value: T = serde_json::from_str(&content)
                .map_err(|e| format!("failed to parse {}: {}", path.display(), e))?;
            results.push((file_stem, value));
        }

        Ok(results)
    }
}

#[async_trait]
impl GraphStorage for FilesystemGraphStorage {
    async fn load_graph(&self, capsule_id: &str) -> Result<CapsuleGraph, String> {
        let nodes_dir = self.nodes_dir(capsule_id);
        let edges_dir = self.edges_dir(capsule_id);

        let mut nodes = HashMap::new();
        let mut edges = HashMap::new();

        // Load all nodes
        let node_data = Self::read_json_dir::<CapsuleNode>(&nodes_dir)?;
        for (_, node) in node_data {
            nodes.insert(node.id.clone(), node);
        }

        // Load all edges
        let edge_data = Self::read_json_dir::<CapsuleEdge>(&edges_dir)?;
        for (_, edge) in edge_data {
            edges.insert(edge.id.clone(), edge);
        }

        // Determine root nodes from parent refs (not file order)
        let root_nodes: Vec<_> = nodes
            .values()
            .filter(|n| n.parents.is_empty())
            .map(|n| n.id.clone())
            .collect();

        Ok(CapsuleGraph {
            capsule_id: capsule_id.to_string(),
            nodes,
            edges,
            root_nodes,
            created_at: chrono::Utc::now(),
            updated_at: chrono::Utc::now(),
        })
    }

    async fn save_graph(&self, graph: &CapsuleGraph) -> Result<(), String> {
        self.ensure_dirs(&graph.capsule_id)
            .map_err(|e| format!("failed to create directories: {}", e))?;

        // Save each node as individual file
        for node in graph.nodes.values() {
            self.save_node(&graph.capsule_id, node).await?;
        }

        // Save each edge as individual file
        for edge in graph.edges.values() {
            self.save_edge(&graph.capsule_id, edge).await?;
        }

        Ok(())
    }

    async fn load_manifest(&self, capsule_id: &str) -> Result<CapsuleGraphManifest, String> {
        let path = self.manifest_path(capsule_id);
        if !path.exists() {
            return Ok(CapsuleGraphManifest::new(capsule_id));
        }
        let content = tokio::fs::read_to_string(&path)
            .await
            .map_err(|e| format!("failed to read manifest: {}", e))?;
        serde_json::from_str(&content).map_err(|e| format!("failed to parse manifest: {}", e))
    }

    async fn save_manifest(&self, manifest: &CapsuleGraphManifest) -> Result<(), String> {
        self.ensure_dirs(&manifest.capsule_id)
            .map_err(|e| format!("failed to create directories: {}", e))?;
        let content = serde_json::to_string_pretty(manifest)
            .map_err(|e| format!("failed to serialize manifest: {}", e))?;
        tokio::fs::write(self.manifest_path(&manifest.capsule_id), content)
            .await
            .map_err(|e| format!("failed to write manifest: {}", e))
    }

    async fn save_node(&self, capsule_id: &str, node: &CapsuleNode) -> Result<(), String> {
        self.ensure_dirs(capsule_id)
            .map_err(|e| format!("failed to create directories: {}", e))?;
        let path = self.nodes_dir(capsule_id).join(format!("{}.json", node.id));
        let content = serde_json::to_string_pretty(node)
            .map_err(|e| format!("failed to serialize node: {}", e))?;
        tokio::fs::write(&path, content)
            .await
            .map_err(|e| format!("failed to write node: {}", e))
    }

    async fn save_edge(&self, capsule_id: &str, edge: &CapsuleEdge) -> Result<(), String> {
        self.ensure_dirs(capsule_id)
            .map_err(|e| format!("failed to create directories: {}", e))?;
        let path = self.edges_dir(capsule_id).join(format!("{}.json", edge.id));
        let content = serde_json::to_string_pretty(edge)
            .map_err(|e| format!("failed to serialize edge: {}", e))?;
        tokio::fs::write(&path, content)
            .await
            .map_err(|e| format!("failed to write edge: {}", e))
    }

    async fn delete_node(&self, capsule_id: &str, node_id: &str) -> Result<(), String> {
        let path = self.nodes_dir(capsule_id).join(format!("{node_id}.json"));
        if path.exists() {
            tokio::fs::remove_file(&path)
                .await
                .map_err(|e| format!("failed to delete node file: {}", e))?;
        }
        Ok(())
    }

    async fn delete_edge(&self, capsule_id: &str, edge_id: &str) -> Result<(), String> {
        let path = self.edges_dir(capsule_id).join(format!("{edge_id}.json"));
        if path.exists() {
            tokio::fs::remove_file(&path)
                .await
                .map_err(|e| format!("failed to delete edge file: {}", e))?;
        }
        Ok(())
    }

    async fn repair_capsule(&self, capsule_id: &str) -> Result<(), String> {
        // Rebuild graph from node/edge files on disk
        let graph = self.load_graph(capsule_id).await?;

        let node_hashes: Vec<_> = graph
            .nodes
            .values()
            .map(|n| (n.id.clone(), n.hash.clone()))
            .collect();
        let edge_hashes: Vec<_> = graph
            .edges
            .values()
            .map(|e| (e.id.clone(), format!("{}:{}", e.source, e.target)))
            .collect();

        let manifest = CapsuleGraphManifest {
            capsule_id: capsule_id.to_string(),
            schema_version: CapsuleGraphManifest::SCHEMA_VERSION,
            generated_at: chrono::Utc::now(),
            node_count: graph.node_count(),
            edge_count: graph.edge_count(),
            root_hash: graph.compute_hash(),
            node_hashes,
            edge_hashes,
        };

        self.save_manifest(&manifest).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::edge::EdgeType;
    use crate::capsule::node::NodeKind;
    use std::env::temp_dir;
    use uuid::Uuid;

    fn make_storage() -> (FilesystemGraphStorage, String) {
        let dir = temp_dir().join(format!("bkg-storage-test-{}", Uuid::new_v4()));
        let _ = std::fs::create_dir_all(&dir);
        let storage = FilesystemGraphStorage::new(&dir);
        (storage, dir.to_string_lossy().to_string())
    }

    #[test]
    fn test_read_json_dir_empty() {
        let dir = temp_dir().join(format!("bkg-empty-{}", Uuid::new_v4()));
        let _ = std::fs::create_dir_all(&dir);
        let result: Vec<(String, CapsuleNode)> =
            FilesystemGraphStorage::read_json_dir(&dir).unwrap();
        assert!(result.is_empty());
    }

    #[tokio::test]
    async fn test_save_and_load_graph() {
        let (storage, _dir) = make_storage();

        let mut graph = CapsuleGraph::new("cap-save-test");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Node 1"));
        graph.add_node(CapsuleNode::new("n2", NodeKind::Execution, "Node 2"));
        graph
            .add_edge(CapsuleEdge::new("e1", "n1", "n2", EdgeType::Produces).with_label("produces"))
            .unwrap();

        storage.save_graph(&graph).await.unwrap();

        let loaded = storage.load_graph("cap-save-test").await.unwrap();
        assert_eq!(loaded.node_count(), 2);
        assert_eq!(loaded.edge_count(), 1);
        assert!(loaded.get_node("n1").is_some());
        assert!(loaded.get_node("n2").is_some());
        assert!(loaded.get_edge("e1").is_some());
    }

    #[tokio::test]
    async fn test_manifest_roundtrip() {
        let (storage, _dir) = make_storage();

        let manifest = CapsuleGraphManifest::new("cap-manifest-test");
        storage.save_manifest(&manifest).await.unwrap();

        let loaded = storage.load_manifest("cap-manifest-test").await.unwrap();
        assert_eq!(loaded.capsule_id, "cap-manifest-test");
        assert!(loaded.root_hash.is_empty());
    }

    #[tokio::test]
    async fn test_repair_capsule() {
        let (storage, _dir) = make_storage();

        let mut graph = CapsuleGraph::new("cap-repair");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Node 1"));
        storage.save_graph(&graph).await.unwrap();

        storage.repair_capsule("cap-repair").await.unwrap();

        let manifest = storage.load_manifest("cap-repair").await.unwrap();
        assert_eq!(manifest.node_count, 1);
        assert_eq!(manifest.edge_count, 0);
        assert!(!manifest.root_hash.is_empty());
    }
}
