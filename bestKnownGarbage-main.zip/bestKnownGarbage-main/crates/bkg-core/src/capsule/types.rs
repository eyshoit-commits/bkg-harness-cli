//! **Causa** types — centralized type definitions for the capsule system.
//!
//! This module pulls together type definitions from across the capsule
//! module tree and adds the higher-level `Capsule` and `CapsuleStatus`
//! types that orchestrate the UCC-4 kernels.
//!
//! # Type Hierarchy
//!
//! ```text
//! CapsuleId         — identifies a capsule (same as graph::CapsuleId)
//!   └── NodeId      — identifies a node in the DAG
//!       └── EdgeId  — identifies an edge in the DAG
//!
//! TimelineId        — identifies a temporal replay timeline
//! Capsule           — the top-level container for all capsule state
//! CapsuleStatus     — lifecycle status of a capsule
//! ```

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

// ──────────────────────────────────────────────
// Re-exports from sibling modules
// ──────────────────────────────────────────────

/// Re-export core graph identifiers so consumers can import from types.
pub use super::edge::EdgeId;
pub use super::event::{CapsuleId, EdgeId as EventEdgeId, EventId, NodeId as EventNodeId};
pub use super::graph::CapsuleId as GraphCapsuleId;
pub use super::node::NodeId;

// ──────────────────────────────────────────────
// Timeline
// ──────────────────────────────────────────────

/// Identifies a temporal replay timeline within a capsule.
///
/// Timelines are append-only sequences of `StateSnapshot` records
/// indexed by snapshot ID. Each timeline corresponds to one replay
/// session or one continuous observation period.
pub type TimelineId = String;

// ──────────────────────────────────────────────
// Capsule Status
// ──────────────────────────────────────────────

/// Top-level lifecycle status of a capsule.
///
/// Mirrors the UCC-4 kernel concepts:
/// - `Bootstrapping` — initial creation, no graph yet
/// - `Live` — active, accepting events
/// - `Divergent` — drift detected, needs repair
/// - `Repairing` — self-healing loop active
/// - `Archived` — frozen, no longer active
/// - `Corrupted` — unrecoverable, needs rehydration
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum CapsuleStatus {
    Bootstrapping,
    Live,
    Divergent,
    Repairing,
    Archived,
    Corrupted,
}

impl std::fmt::Display for CapsuleStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CapsuleStatus::Bootstrapping => write!(f, "bootstrapping"),
            CapsuleStatus::Live => write!(f, "live"),
            CapsuleStatus::Divergent => write!(f, "divergent"),
            CapsuleStatus::Repairing => write!(f, "repairing"),
            CapsuleStatus::Archived => write!(f, "archived"),
            CapsuleStatus::Corrupted => write!(f, "corrupted"),
        }
    }
}

// ──────────────────────────────────────────────
// Capsule — top-level container
// ──────────────────────────────────────────────

/// A capsule is the top-level container for all graph + event + repair state.
///
/// Every capsule has:
/// - A `CapsuleGraph` (the DAG of nodes and edges)
/// - A `CapsuleStatus` (top-level lifecycle)
/// - A collection of `TimelineId`s (temporal replay sessions)
/// - Optional replay state
///
/// This struct is the fusion point for the UCC-4 kernels: memory (graph),
/// execution (events), time (timelines), truth (repair), and evolution (status).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Capsule {
    /// Unique capsule identifier
    pub id: CapsuleId,
    /// Top-level lifecycle status
    pub status: CapsuleStatus,
    /// Human-readable label
    pub label: String,
    /// Timelines attached to this capsule
    pub timelines: Vec<TimelineId>,
    /// Active timeline (if any)
    pub active_timeline: Option<TimelineId>,
    /// Number of repair cycles performed
    pub repair_cycle_count: u64,
    /// Number of replay sessions performed
    pub replay_count: u64,
    /// Creation timestamp
    pub created_at: DateTime<Utc>,
    /// Last modification timestamp
    pub updated_at: DateTime<Utc>,
}

impl Capsule {
    /// Create a new capsule in `Bootstrapping` status.
    pub fn new(id: impl Into<String>, label: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            status: CapsuleStatus::Bootstrapping,
            label: label.into(),
            timelines: Vec::new(),
            active_timeline: None,
            repair_cycle_count: 0,
            replay_count: 0,
            created_at: Utc::now(),
            updated_at: Utc::now(),
        }
    }

    /// Transition to a new status.
    pub fn transition_to(&mut self, status: CapsuleStatus) {
        self.status = status;
        self.updated_at = Utc::now();
    }

    /// Attach a timeline to this capsule.
    pub fn attach_timeline(&mut self, timeline_id: impl Into<String>) {
        let tid = timeline_id.into();
        if !self.timelines.contains(&tid) {
            self.timelines.push(tid);
            self.updated_at = Utc::now();
        }
    }

    /// Set the active timeline.
    pub fn set_active_timeline(&mut self, timeline_id: impl Into<String>) {
        self.active_timeline = Some(timeline_id.into());
        self.updated_at = Utc::now();
    }

    /// Increment repair cycle counter.
    pub fn increment_repair_cycle(&mut self) {
        self.repair_cycle_count += 1;
        self.updated_at = Utc::now();
    }

    /// Increment replay counter.
    pub fn increment_replay(&mut self) {
        self.replay_count += 1;
        self.updated_at = Utc::now();
    }

    /// Check if this capsule is in a terminal state.
    pub fn is_terminal(&self) -> bool {
        matches!(
            self.status,
            CapsuleStatus::Archived | CapsuleStatus::Corrupted
        )
    }

    /// Check if this capsule is active.
    pub fn is_active(&self) -> bool {
        matches!(
            self.status,
            CapsuleStatus::Live | CapsuleStatus::Divergent | CapsuleStatus::Repairing
        )
    }
}

// ──────────────────────────────────────────────
// Type aliases for timeline events
// ──────────────────────────────────────────────

/// A single entry in a temporal replay timeline.
///
/// Each entry pairs a `StateSnapshot` with the event that triggered it,
/// enabling forward/backward stepping through capsule history.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineEntry {
    /// Unique entry ID within this timeline
    pub entry_id: String,
    /// Sequence number (monotonic within timeline)
    pub seq: u64,
    /// Wall-clock timestamp
    pub timestamp: DateTime<Utc>,
    /// The event that triggered this entry
    pub event: super::event::GraphEvent,
    /// Snapshot of capsule state at this point
    pub snapshot: super::snapshot::StateSnapshot,
}

/// Summary of a timeline — used for listing without loading all entries.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineSummary {
    pub timeline_id: TimelineId,
    pub capsule_id: CapsuleId,
    pub entry_count: u64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub first_event_time: Option<DateTime<Utc>>,
    pub last_event_time: Option<DateTime<Utc>>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_capsule_creation() {
        let cap = Capsule::new("cap-test", "Test Capsule");
        assert_eq!(cap.id, "cap-test");
        assert_eq!(cap.status, CapsuleStatus::Bootstrapping);
        assert!(!cap.is_terminal());
        assert!(!cap.is_active());
    }

    #[test]
    fn test_capsule_lifecycle() {
        let mut cap = Capsule::new("cap-live", "Live Test");
        cap.transition_to(CapsuleStatus::Live);
        assert_eq!(cap.status, CapsuleStatus::Live);
        assert!(cap.is_active());
        assert!(!cap.is_terminal());

        cap.transition_to(CapsuleStatus::Archived);
        assert!(cap.is_terminal());
        assert!(!cap.is_active());
    }

    #[test]
    fn test_timeline_attachment() {
        let mut cap = Capsule::new("cap-tl", "Timeline Test");
        cap.attach_timeline("tl-1");
        cap.attach_timeline("tl-2");
        assert_eq!(cap.timelines.len(), 2);

        // No duplicates
        cap.attach_timeline("tl-1");
        assert_eq!(cap.timelines.len(), 2);

        cap.set_active_timeline("tl-1");
        assert_eq!(cap.active_timeline, Some("tl-1".to_string()));
    }

    #[test]
    fn test_counters() {
        let mut cap = Capsule::new("cap-cnt", "Counter Test");
        cap.increment_repair_cycle();
        cap.increment_repair_cycle();
        cap.increment_replay();
        assert_eq!(cap.repair_cycle_count, 2);
        assert_eq!(cap.replay_count, 1);
    }
}
