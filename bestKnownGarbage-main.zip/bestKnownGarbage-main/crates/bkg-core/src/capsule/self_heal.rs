//! **SelfHeal** — self-healing strategies for capsule repair.
//!
//! Each strategy targets a specific failure mode detected during
//! CapsuleEngine scanning. The healing is attempted at boot time
//! during Bootstrap Phase 2 (CapsuleRehydration).
//!
//! # Algorithm
//!
//! ```text
//! if index missing     → rebuild from MEMORY.md
//! if snapshot missing  → restore from receipt + diff chain
//! if receipt invalid   → re-verify from filesystem state
//! if capsule corrupted → mark degraded + rebuild partial state
//! ```

use std::path::Path;

/// The healing strategy to apply for a given failure mode.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealStrategy {
    /// SQLite index is missing — rebuild from MEMORY.md
    RebuildIndex,
    /// State snapshot is missing — restore from receipt + diff
    RestoreSnapshot,
    /// Execution receipt hash doesn't match — re-verify from filesystem
    ReverifyReceipt,
    /// Capsule is partially corrupted — rebuild what we can
    RebuildPartial,
}

impl HealStrategy {
    /// Human-readable label for the strategy.
    pub fn label(&self) -> &'static str {
        match self {
            HealStrategy::RebuildIndex => "RebuildIndex",
            HealStrategy::RestoreSnapshot => "RestoreSnapshot",
            HealStrategy::ReverifyReceipt => "ReverifyReceipt",
            HealStrategy::RebuildPartial => "RebuildPartial",
        }
    }
}

/// Attempt to heal a capsule using the given strategy.
///
/// Returns `Ok(())` if the healing was attempted (even if partial),
/// or `Err(reason)` if the capsule is unhealable.
pub fn heal_capsule(capsule_path: &Path, strategy: HealStrategy) -> Result<(), String> {
    match strategy {
        HealStrategy::RebuildIndex => {
            let memory = capsule_path.join("MEMORY.md");
            if !memory.exists() {
                return Err("Cannot rebuild index: MEMORY.md missing".into());
            }
            // TODO: actual SQLite index rebuild from MEMORY.md content
            Ok(())
        }

        HealStrategy::RestoreSnapshot => {
            let receipts = capsule_path.join("receipts");
            if !receipts.exists() {
                return Err("Cannot restore snapshot: no receipts directory".into());
            }
            // TODO: find the latest receipt, apply diff chain to reconstruct snapshot
            Ok(())
        }

        HealStrategy::ReverifyReceipt => {
            let receipts = capsule_path.join("receipts");
            if !receipts.exists() {
                return Err("Cannot re-verify: no receipts directory".into());
            }
            // TODO: re-hash each receipt against current filesystem state
            Ok(())
        }

        HealStrategy::RebuildPartial => {
            // Rebuild as much state as possible from available artifacts.
            // If MEMORY.md exists, we can at least rebuild the index.
            let memory = capsule_path.join("MEMORY.md");
            if memory.exists() {
                let _ = heal_capsule(capsule_path, HealStrategy::RebuildIndex);
            }
            Ok(())
        }
    }
}

/// Check whether a capsule is healable (at minimum MEMORY.md must exist).
pub fn is_healable(capsule_path: &Path) -> bool {
    capsule_path.join("MEMORY.md").exists()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_heal_strategy_labels() {
        assert_eq!(HealStrategy::RebuildIndex.label(), "RebuildIndex");
        assert_eq!(HealStrategy::RestoreSnapshot.label(), "RestoreSnapshot");
        assert_eq!(HealStrategy::ReverifyReceipt.label(), "ReverifyReceipt");
        assert_eq!(HealStrategy::RebuildPartial.label(), "RebuildPartial");
    }

    #[test]
    fn test_heal_missing_memory() {
        let dir = std::env::temp_dir().join("bkg_self_heal_test");
        let result = heal_capsule(&dir, HealStrategy::RebuildIndex);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("MEMORY.md"));
    }

    #[test]
    fn test_is_healable_without_memory() {
        let dir = std::env::temp_dir().join("bkg_healable_test");
        assert!(!is_healable(&dir));
    }

    #[test]
    fn test_is_healable_with_memory() {
        let dir = std::env::temp_dir().join("bkg_healable_test_ok");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("MEMORY.md"), "# test").unwrap();
        assert!(is_healable(&dir));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_heal_partial_without_memory() {
        let dir = std::env::temp_dir().join("bkg_partial_test");
        // No MEMORY.md — rebuild partial should still not error
        assert!(heal_capsule(&dir, HealStrategy::RebuildPartial).is_ok());
    }

    #[test]
    fn test_heal_snapshot_no_receipts() {
        let dir = std::env::temp_dir().join("bkg_snap_test");
        std::fs::create_dir_all(&dir).unwrap();
        let result = heal_capsule(&dir, HealStrategy::RestoreSnapshot);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("receipts"));
        let _ = std::fs::remove_dir_all(&dir);
    }
}
