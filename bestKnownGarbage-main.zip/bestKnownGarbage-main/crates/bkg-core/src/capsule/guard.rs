//! **Causa** HealingGuard — safety envelope for the self-healing loop.
//!
//! The healing guard prevents the self-healing loop from causing damage
//! through excessive or inappropriate repair. It enforces:
//!
//! - **Rate limiting**: maximum repairs per time window
//! - **Cooldown**: minimum time between repairs on the same node
//! - **Max retries**: hard cap on retries per capsule
//! - **Invariant checks**: safety rules that must hold before/during repair
//!
//! The guard is the "safety rail" — it never initiates repair, only
//! constrains it. If the guard blocks a repair, the reason is recorded
//! for diagnostic purposes.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use super::error::{CapsuleError, CapsuleResult};

/// Outcome of a guard check.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum GuardResult {
    /// Repair is allowed to proceed
    Allowed,
    /// Repair is blocked for a specific reason
    Blocked { reason: String },
    /// Requires escalation to manual approval
    RequiresEscalation { reason: String },
}

/// Record of a single repair attempt (for rate limiting and diagnostics).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepairAttempt {
    /// Capsule that was repaired
    pub capsule_id: String,
    /// Target node (if node-level repair)
    pub target_id: Option<String>,
    /// Wall-clock timestamp
    pub timestamp: DateTime<Utc>,
    /// Whether the repair succeeded
    pub success: bool,
    /// Reason/description of the repair
    pub reason: String,
}

/// Configuration for the healing guard.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GuardConfig {
    /// Maximum repair attempts per capsule in the time window
    pub max_repairs_per_window: u32,
    /// Time window for rate limiting in seconds
    pub rate_limit_window_secs: u64,
    /// Minimum seconds between repairs on the same node
    pub node_cooldown_secs: u64,
    /// Minimum seconds between repairs on the same capsule
    pub capsule_cooldown_secs: u64,
    /// Absolute maximum retries per capsule (hard cap)
    pub max_retries_per_capsule: u32,
    /// Absolute maximum retries per node (hard cap)
    pub max_retries_per_node: u32,
    /// Whether to block repair on capsules in terminal state
    pub block_terminal_repair: bool,
}

impl Default for GuardConfig {
    fn default() -> Self {
        Self {
            max_repairs_per_window: 10,
            rate_limit_window_secs: 300, // 5 minutes
            node_cooldown_secs: 60,      // 1 minute
            capsule_cooldown_secs: 10,   // 10 seconds
            max_retries_per_capsule: 20,
            max_retries_per_node: 5,
            block_terminal_repair: true,
        }
    }
}

/// The healing guard — safety envelope for self-healing operations.
///
/// The guard is not a repair engine — it only checks whether repair
/// should be allowed. The actual repair logic is in `HealingEngine`
/// and `SelfHealingLoop`.
#[derive(Debug, Clone)]
pub struct HealingGuard {
    /// Guard configuration
    pub config: GuardConfig,
    /// Repair attempt history (for rate limiting)
    history: Vec<RepairAttempt>,
    /// Per-capsule retry count
    capsule_retries: HashMap<String, u32>,
    /// Per-node retry count
    node_retries: HashMap<String, u32>,
    /// Last repair time per capsule
    last_capsule_repair: HashMap<String, DateTime<Utc>>,
    /// Last repair time per node
    last_node_repair: HashMap<String, DateTime<Utc>>,
}

impl HealingGuard {
    /// Create a new healing guard with default configuration.
    pub fn new() -> Self {
        Self::with_config(GuardConfig::default())
    }

    /// Create a new healing guard with custom configuration.
    pub fn with_config(config: GuardConfig) -> Self {
        Self {
            config,
            history: Vec::new(),
            capsule_retries: HashMap::new(),
            node_retries: HashMap::new(),
            last_capsule_repair: HashMap::new(),
            last_node_repair: HashMap::new(),
        }
    }

    /// Check whether a repair operation is allowed.
    ///
    /// Returns `GuardResult::Allowed` if the repair should proceed,
    /// or `GuardResult::Blocked` with a reason if it should not.
    pub fn check(
        &mut self,
        capsule_id: &str,
        target_id: Option<&str>,
        is_terminal: bool,
    ) -> GuardResult {
        let now = Utc::now();

        // 1. Check terminal state
        if is_terminal && self.config.block_terminal_repair {
            return GuardResult::Blocked {
                reason: format!("capsule {capsule_id} is in terminal state"),
            };
        }

        // 2. Check capsule retry limit
        let capsule_retries = self.capsule_retries.get(capsule_id).copied().unwrap_or(0);
        if capsule_retries >= self.config.max_retries_per_capsule {
            return GuardResult::RequiresEscalation {
                reason: format!(
                    "capsule {capsule_id} has exceeded max retries ({})",
                    self.config.max_retries_per_capsule
                ),
            };
        }

        // 3. Check node retry limit (if targeting a specific node)
        if let Some(node_id) = target_id {
            let node_retries = self.node_retries.get(node_id).copied().unwrap_or(0);
            if node_retries >= self.config.max_retries_per_node {
                return GuardResult::RequiresEscalation {
                    reason: format!(
                        "node {node_id} has exceeded max retries ({})",
                        self.config.max_retries_per_node
                    ),
                };
            }
        }

        // 4. Check capsule cooldown
        if let Some(last_time) = self.last_capsule_repair.get(capsule_id) {
            let elapsed = (now - *last_time).num_seconds() as u64;
            if elapsed < self.config.capsule_cooldown_secs {
                return GuardResult::Blocked {
                    reason: format!(
                        "capsule {capsule_id} is in cooldown ({elapsed}s < {}s)",
                        self.config.capsule_cooldown_secs
                    ),
                };
            }
        }

        // 5. Check node cooldown
        if let Some(node_id) = target_id {
            if let Some(last_time) = self.last_node_repair.get(node_id) {
                let elapsed = (now - *last_time).num_seconds() as u64;
                if elapsed < self.config.node_cooldown_secs {
                    return GuardResult::Blocked {
                        reason: format!(
                            "node {node_id} is in cooldown ({elapsed}s < {}s)",
                            self.config.node_cooldown_secs
                        ),
                    };
                }
            }
        }

        // 6. Rate limit check (repairs in time window)
        let window_start =
            now - chrono::Duration::seconds(self.config.rate_limit_window_secs as i64);
        let recent_count = self
            .history
            .iter()
            .filter(|a| a.capsule_id == capsule_id && a.timestamp > window_start)
            .count() as u32;

        if recent_count >= self.config.max_repairs_per_window {
            return GuardResult::Blocked {
                reason: format!(
                    "rate limit exceeded: {recent_count} repairs in last {}s (max {})",
                    self.config.rate_limit_window_secs, self.config.max_repairs_per_window
                ),
            };
        }

        GuardResult::Allowed
    }

    /// Record a completed repair attempt.
    ///
    /// Updates retry counters and cooldown timestamps.
    pub fn record_attempt(
        &mut self,
        capsule_id: &str,
        target_id: Option<&str>,
        success: bool,
        reason: &str,
    ) {
        let now = Utc::now();

        self.history.push(RepairAttempt {
            capsule_id: capsule_id.to_string(),
            target_id: target_id.map(|s| s.to_string()),
            timestamp: now,
            success,
            reason: reason.to_string(),
        });

        // Update capsule retry count
        *self
            .capsule_retries
            .entry(capsule_id.to_string())
            .or_insert(0) += 1;
        self.last_capsule_repair.insert(capsule_id.to_string(), now);

        // Update node retry count
        if let Some(node_id) = target_id {
            *self.node_retries.entry(node_id.to_string()).or_insert(0) += 1;
            self.last_node_repair.insert(node_id.to_string(), now);
        }
    }

    /// Check invariants that must hold before/during repair.
    ///
    /// Returns an error if an invariant is violated.
    pub fn check_invariants(
        &self,
        capsule_id: &str,
        is_active: bool,
        has_graph: bool,
    ) -> CapsuleResult<()> {
        // Invariant 1: Cannot repair a non-existent capsule
        if !has_graph {
            return Err(CapsuleError::invalid_operation(
                capsule_id,
                "cannot repair capsule with no graph data",
            ));
        }

        // Invariant 2: Cannot repair an inactive capsule (unless terminal is allowed)
        if !is_active && self.config.block_terminal_repair {
            return Err(CapsuleError::invalid_operation(
                capsule_id,
                "cannot repair inactive capsule",
            ));
        }

        Ok(())
    }

    /// Get the current retry count for a capsule.
    pub fn capsule_retry_count(&self, capsule_id: &str) -> u32 {
        self.capsule_retries.get(capsule_id).copied().unwrap_or(0)
    }

    /// Get the current retry count for a node.
    pub fn node_retry_count(&self, node_id: &str) -> u32 {
        self.node_retries.get(node_id).copied().unwrap_or(0)
    }

    /// Get recent repair history.
    pub fn recent_history(&self, capsule_id: &str, limit: usize) -> Vec<&RepairAttempt> {
        self.history
            .iter()
            .filter(|a| a.capsule_id == capsule_id)
            .rev()
            .take(limit)
            .collect()
    }

    /// Reset retry counters for a capsule.
    pub fn reset_capsule(&mut self, capsule_id: &str) {
        self.capsule_retries.remove(capsule_id);
        self.last_capsule_repair.remove(capsule_id);
        self.history.retain(|a| a.capsule_id != capsule_id);
    }
}

impl Default for HealingGuard {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_guard_allows_initial_repair() {
        let mut guard = HealingGuard::new();
        let result = guard.check("cap-1", None, false);
        assert_eq!(result, GuardResult::Allowed);
    }

    #[test]
    fn test_guard_blocks_terminal() {
        let mut guard = HealingGuard::new();
        let result = guard.check("cap-terminal", None, true);
        assert_eq!(
            result,
            GuardResult::Blocked {
                reason: "capsule cap-terminal is in terminal state".into()
            }
        );
    }

    #[test]
    fn test_guard_rate_limiting() {
        let mut guard = HealingGuard::new();

        // Disable capsule cooldown for rate-limiting test
        guard.config.capsule_cooldown_secs = 0;

        // Max repairs per window is 10 by default
        for i in 0..10 {
            let result = guard.check("cap-rate", None, false);
            assert_eq!(
                result,
                GuardResult::Allowed,
                "attempt {i} should be allowed"
            );
            guard.record_attempt("cap-rate", None, true, "test");
        }

        // 11th should be blocked
        let result = guard.check("cap-rate", None, false);
        assert!(matches!(result, GuardResult::Blocked { .. }));
    }

    #[test]
    fn test_guard_capsule_retries() {
        let mut guard = HealingGuard::new();

        // Max retries per capsule is 20
        for i in 0..20 {
            guard.record_attempt("cap-retry", None, true, "test");
        }
        assert_eq!(guard.capsule_retry_count("cap-retry"), 20);

        let result = guard.check("cap-retry", None, false);
        assert!(matches!(result, GuardResult::RequiresEscalation { .. }));
    }

    #[test]
    fn test_guard_node_cooldown() {
        let mut guard = HealingGuard::new();
        guard.config.node_cooldown_secs = 3600; // 1 hour

        // First repair is allowed
        let result = guard.check("cap-1", Some("node-1"), false);
        assert_eq!(result, GuardResult::Allowed);
        guard.record_attempt("cap-1", Some("node-1"), true, "test");

        // Second repair within cooldown should be blocked
        let result = guard.check("cap-1", Some("node-1"), false);
        assert!(matches!(result, GuardResult::Blocked { .. }));
    }

    #[test]
    fn test_guard_invariants() {
        let guard = HealingGuard::new();

        // No graph → error
        let result = guard.check_invariants("cap-missing", true, false);
        assert!(result.is_err());

        // Inactive capsule → error
        let result = guard.check_invariants("cap-inactive", false, true);
        assert!(result.is_err());

        // Healthy → ok
        let result = guard.check_invariants("cap-healthy", true, true);
        assert!(result.is_ok());
    }

    #[test]
    fn test_reset_capsule() {
        let mut guard = HealingGuard::new();
        guard.record_attempt("cap-reset", None, true, "test");
        assert_eq!(guard.capsule_retry_count("cap-reset"), 1);

        guard.reset_capsule("cap-reset");
        assert_eq!(guard.capsule_retry_count("cap-reset"), 0);
    }

    #[test]
    fn test_recent_history() {
        let mut guard = HealingGuard::new();
        guard.record_attempt("cap-hist", None, true, "first");
        guard.record_attempt("cap-hist", None, false, "second");

        let history = guard.recent_history("cap-hist", 10);
        assert_eq!(history.len(), 2);
        assert!(!history[0].success); // most recent first
    }
}
