//! **Causa** ReplayEngine trait — deterministic temporal replay.
//!
//! This module provides the `ReplayEngine` trait, which abstracts over
//! different replay strategies (temporal, WASM-based, deterministic
//! re-execution). The default implementation uses the temporal engine
//! for time-travel replay and the kernel's replay engine for
//! deterministic re-execution.
//!
//! # Replay Strategies
//!
//! - **Temporal**: rewind/fast-forward through state snapshots
//! - **Deterministic**: re-execute WASM modules with same inputs
//! - **Hybrid**: re-execute where possible, fall back to temporal

use async_trait::async_trait;
use chrono::{DateTime, Utc};

use super::error::CapsuleResult;
use super::graph::CapsuleGraph;
use super::temporal::{PlaybackSpeed, ReplayResult};
use super::timeline::EventTimeline;

/// Statistics collected across replay operations.
#[derive(Debug, Clone, Default)]
pub struct ReplayStats {
    /// Total replay operations
    pub total_replays: u64,
    /// Successful replays
    pub successful_replays: u64,
    /// Failed replays (divergence detected)
    pub failed_replays: u64,
    /// Total time spent replaying in ms
    pub total_time_ms: u64,
}

impl ReplayStats {
    /// Record a successful replay.
    pub fn record_success(&mut self, duration_ms: u64) {
        self.total_replays += 1;
        self.successful_replays += 1;
        self.total_time_ms += duration_ms;
    }

    /// Record a failed replay.
    pub fn record_failure(&mut self, duration_ms: u64) {
        self.total_replays += 1;
        self.failed_replays += 1;
        self.total_time_ms += duration_ms;
    }

    /// Success rate as a float (0.0 – 1.0).
    pub fn success_rate(&self) -> f32 {
        if self.total_replays == 0 {
            1.0
        } else {
            self.successful_replays as f32 / self.total_replays as f32
        }
    }
}

/// Result of a full replay verification.
#[derive(Debug, Clone)]
pub struct ReplayVerificationResult {
    /// Verified state graph
    pub graph: CapsuleGraph,
    /// Number of events replayed
    pub events_replayed: u64,
    /// Number of divergences detected
    pub divergences: u64,
    /// Whether all replayed events matched expected state
    pub all_match: bool,
    /// Verification timestamp
    pub verified_at: DateTime<Utc>,
}

/// Trait for capsule replay engines.
///
/// Implementations provide different replay strategies:
/// - `TemporalReplayEngine<B, S>` — time-travel via snapshots
/// - `WasmReplayEngine` — deterministic WASM re-execution
#[async_trait]
pub trait ReplayEngine: Send + Sync {
    /// Rewind capsule state to a specific snapshot.
    async fn rewind_to(&self, capsule_id: &str, snapshot_id: &str) -> CapsuleResult<ReplayResult>;

    /// Fast-forward a capsule from a snapshot to the latest state.
    async fn fast_forward(
        &self,
        timeline: &EventTimeline,
        from_snapshot: &str,
    ) -> CapsuleResult<ReplayResult>;

    /// Playback a timeline at the given speed.
    async fn playback(
        &self,
        timeline: &mut EventTimeline,
        speed: PlaybackSpeed,
    ) -> CapsuleResult<ReplayResult>;

    /// Step forward one event in a timeline.
    async fn step_forward(
        &self,
        timeline: &mut EventTimeline,
    ) -> CapsuleResult<Option<ReplayResult>>;

    /// Step backward one event in a timeline.
    async fn step_backward(
        &self,
        timeline: &mut EventTimeline,
    ) -> CapsuleResult<Option<ReplayResult>>;

    /// Verify capsule integrity by replaying and checking hashes.
    async fn verify_replay(&self, capsule_id: &str) -> CapsuleResult<ReplayVerificationResult>;

    /// Get replay statistics.
    fn stats(&self) -> &ReplayStats;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_replay_stats_default() {
        let stats = ReplayStats::default();
        assert_eq!(stats.total_replays, 0);
        assert_eq!(stats.success_rate(), 1.0); // No replays = perfect rate
    }

    #[test]
    fn test_replay_stats_recording() {
        let mut stats = ReplayStats::default();
        stats.record_success(100);
        stats.record_success(50);
        stats.record_failure(200);

        assert_eq!(stats.total_replays, 3);
        assert_eq!(stats.successful_replays, 2);
        assert_eq!(stats.failed_replays, 1);
        assert_eq!(stats.total_time_ms, 350);
        assert!((stats.success_rate() - 2.0 / 3.0).abs() < 0.001);
    }

    #[test]
    fn test_verification_result() {
        use crate::capsule::graph::CapsuleGraph;
        let graph = CapsuleGraph::new("cap-verify");
        let result = ReplayVerificationResult {
            graph,
            events_replayed: 10,
            divergences: 0,
            all_match: true,
            verified_at: Utc::now(),
        };
        assert!(result.all_match);
        assert_eq!(result.divergences, 0);
    }
}
