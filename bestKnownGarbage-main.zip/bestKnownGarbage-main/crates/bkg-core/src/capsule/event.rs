//! Graph events — the universal message format for the capsule graph.
//!
//! Every state change in the graph is represented as a `GraphEvent`.
//! Events flow from sources (engine, rehydrator, repairer, replayer)
//! through the `GraphEventBus` to consumers (persistence, UI, audit).
//!
//! # Event Lifecycle
//!
//! 1. Source creates `GraphEvent` with kind, severity, and payload
//! 2. `GraphStreamEngine.emit()` persists to timeline.jsonl + publishes to bus
//! 3. `DagUiState.reduce()` transforms event into renderable state
//! 4. `DagRenderer` renders the state to the terminal
//!
//! `RepairEvent` is a separate, simpler event type for the repair pipeline.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Unique identifiers used throughout the capsule graph.
pub type CapsuleId = String;
pub type NodeId = String;
pub type EdgeId = String;
pub type EventId = String;

/// All possible graph event kinds, grouped by domain.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum GraphEventKind {
    // ── Capsule lifecycle ──
    CapsuleLoaded,
    CapsuleRehydrated,
    CapsuleRepaired,
    CapsuleArchived,

    // ── Node lifecycle ──
    NodeAdded,
    NodeUpdated,
    NodeRemoved,
    NodeVerified,
    NodeStale,
    NodeDivergent,
    NodeRepaired,

    // ── Edge lifecycle ──
    EdgeAdded,
    EdgeUpdated,
    EdgeRemoved,

    // ── Replay ──
    ReplayStarted,
    ReplayStep,
    ReplayFinished,

    // ── Drift ──
    DriftDetected,
    DriftResolved,

    // ── UI / Projection ──
    LayoutUpdated,
    ProjectionChanged,

    // ── Attachments ──
    SnapshotAttached,
    ReceiptAttached,
}

/// Event severity — used by UI to color-code events and by repair to prioritize.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum GraphSeverity {
    Info,
    Warn,
    Error,
    Critical,
}

/// A single graph event — the universal delta message.
///
/// Every event carries enough context for consumers to act independently:
/// - `event_id` enables dedup (consumers can track processed IDs)
/// - `capsule_id` scopes the event to a specific capsule
/// - `node_id` / `edge_id` identify the affected element
/// - `kind` + `severity` enable routing and display decisions
/// - `payload` carries arbitrary structured data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphEvent {
    pub event_id: EventId,
    pub capsule_id: CapsuleId,
    pub node_id: Option<NodeId>,
    pub edge_id: Option<EdgeId>,
    pub kind: GraphEventKind,
    pub created_at: DateTime<Utc>,
    pub severity: GraphSeverity,
    pub payload: serde_json::Value,
}

impl GraphEvent {
    /// Create a new event with minimal fields.
    pub fn new(
        capsule_id: impl Into<String>,
        kind: GraphEventKind,
        severity: GraphSeverity,
    ) -> Self {
        Self {
            event_id: uuid::Uuid::new_v4().to_string(),
            capsule_id: capsule_id.into(),
            node_id: None,
            edge_id: None,
            kind,
            created_at: Utc::now(),
            severity,
            payload: serde_json::Value::Null,
        }
    }

    /// Attach a node reference.
    pub fn with_node(mut self, node_id: impl Into<String>) -> Self {
        self.node_id = Some(node_id.into());
        self
    }

    /// Attach an edge reference.
    pub fn with_edge(mut self, edge_id: impl Into<String>) -> Self {
        self.edge_id = Some(edge_id.into());
        self
    }

    /// Attach a JSON payload.
    pub fn with_payload(mut self, payload: serde_json::Value) -> Self {
        self.payload = payload;
        self
    }
}

/// Repair-specific event kind — simpler than full GraphEvent, used within
/// the repair pipeline for granular progress reporting.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum RepairEventKind {
    RepairStarted,
    DriftFound,
    ActionApplied,
    ActionFailed,
    RepairCompleted,
}

/// A repair event — emitted by `CapsuleRepairEngine` during repair operations.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RepairEvent {
    pub capsule_id: CapsuleId,
    pub target_id: Option<NodeId>,
    pub kind: RepairEventKind,
    pub created_at: DateTime<Utc>,
    pub message: String,
}

impl RepairEvent {
    pub fn new(
        capsule_id: impl Into<String>,
        kind: RepairEventKind,
        message: impl Into<String>,
    ) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            target_id: None,
            kind,
            created_at: Utc::now(),
            message: message.into(),
        }
    }

    pub fn with_target(mut self, target_id: impl Into<String>) -> Self {
        self.target_id = Some(target_id.into());
        self
    }
}

/// Helper: construct a GraphEvent from a node status change.
/// Used by engines, rehydrators, and repairers to emit consistent events.
pub fn graph_event_from_node_status(
    capsule_id: String,
    node_id: String,
    kind: NodeKind,
    status: &super::node::NodeStatus,
) -> GraphEvent {
    let (event_kind, severity) = match status {
        super::node::NodeStatus::Verified => (GraphEventKind::NodeVerified, GraphSeverity::Info),
        super::node::NodeStatus::Stale => (GraphEventKind::NodeStale, GraphSeverity::Warn),
        super::node::NodeStatus::Divergent { .. } => {
            (GraphEventKind::NodeDivergent, GraphSeverity::Error)
        }
        super::node::NodeStatus::Repaired => (GraphEventKind::NodeRepaired, GraphSeverity::Info),
        super::node::NodeStatus::Failed(_) => (GraphEventKind::NodeUpdated, GraphSeverity::Error),
        super::node::NodeStatus::Running => (GraphEventKind::NodeUpdated, GraphSeverity::Info),
        super::node::NodeStatus::Pending => (GraphEventKind::NodeUpdated, GraphSeverity::Info),
        super::node::NodeStatus::Archived => (GraphEventKind::CapsuleArchived, GraphSeverity::Info),
    };

    GraphEvent::new(capsule_id, event_kind, severity)
        .with_node(node_id)
        .with_payload(serde_json::json!({
            "kind": format!("{:?}", kind),
            "status": format!("{:?}", status),
        }))
}

use super::node::NodeKind;
