//! **Causa** error types — unified, production-grade error taxonomy.
//!
//! Every fallible operation in the capsule module returns `CapsuleResult<T>`
//! using these error types. No `unwrap()`. No `expect()`. No panics.
//!
//! # Error Categories
//!
//! - **Storage**: filesystem or persistence failures
//! - **Corruption**: data integrity violations (hash mismatch, missing fields)
//! - **MissingNode / MissingEdge**: graph structural errors
//! - **InvalidOperation**: semantic violations (cycle, wrong status)
//! - **EventError**: event bus or stream failures
//! - **ReplayError**: temporal replay failures
//! - **HealingError**: self-healing loop failures
//!
//! Every variant carries enough context for diagnostics, logging, and
//! user-facing error messages.

use std::fmt;

// ──────────────────────────────────────────────
// CapsuleError
// ──────────────────────────────────────────────

/// Unified error type for all capsule operations.
#[derive(Debug, Clone)]
pub enum CapsuleError {
    // ── Storage (I/O) ──
    /// Generic storage read/write failure.
    Storage { capsule_id: String, detail: String },
    /// Manifest not found or unreadable.
    /// This is distinct from Storage because it implies capsule-level recovery.
    ManifestMissing { capsule_id: String },

    // ── Corruption (integrity) ──
    /// Data integrity check failed — hash mismatch.
    Corruption {
        capsule_id: String,
        target_id: String,
        expected_hash: String,
        actual_hash: String,
    },
    /// Schema version mismatch — cannot deserialize.
    SchemaMismatch {
        capsule_id: String,
        expected: u32,
        actual: u32,
    },

    // ── Graph structure ──
    /// Referenced node does not exist in the graph.
    MissingNode { capsule_id: String, node_id: String },
    /// Referenced edge does not exist in the graph.
    MissingEdge { capsule_id: String, edge_id: String },
    /// Adding this edge would create a cycle.
    CycleDetected { source: String, target: String },

    // ── Invalid operations ──
    /// Operation is not valid for the current state.
    InvalidOperation { capsule_id: String, reason: String },
    /// Operation attempted on a capsule in a terminal state.
    TerminalCapsule { capsule_id: String, status: String },

    // ── Events ──
    /// Event bus publish/consume failure.
    EventError { detail: String },
    /// Event stream persistence failure.
    EventStreamError { detail: String },

    // ── Replay ──
    /// Temporal replay operation failed.
    ReplayError { timeline_id: String, detail: String },
    /// Snapshot not found during replay.
    SnapshotMissing { snapshot_id: String },

    // ── Healing ──
    /// Self-healing loop operation failed.
    HealingError { capsule_id: String, detail: String },
    /// Healing policy violation.
    HealingPolicyViolation { capsule_id: String, rule: String },

    // ── Generic ──
    /// Catch-all for errors that don't fit other categories.
    Internal { detail: String },
}

impl CapsuleError {
    // ── Storage ──
    pub fn storage(capsule_id: impl Into<String>, detail: impl Into<String>) -> Self {
        Self::Storage {
            capsule_id: capsule_id.into(),
            detail: detail.into(),
        }
    }

    pub fn manifest_missing(capsule_id: impl Into<String>) -> Self {
        Self::ManifestMissing {
            capsule_id: capsule_id.into(),
        }
    }

    // ── Corruption ──
    pub fn corruption(
        capsule_id: impl Into<String>,
        target_id: impl Into<String>,
        expected_hash: impl Into<String>,
        actual_hash: impl Into<String>,
    ) -> Self {
        Self::Corruption {
            capsule_id: capsule_id.into(),
            target_id: target_id.into(),
            expected_hash: expected_hash.into(),
            actual_hash: actual_hash.into(),
        }
    }

    pub fn schema_mismatch(capsule_id: impl Into<String>, expected: u32, actual: u32) -> Self {
        Self::SchemaMismatch {
            capsule_id: capsule_id.into(),
            expected,
            actual,
        }
    }

    // ── Missing graph elements ──
    pub fn missing_node(capsule_id: impl Into<String>, node_id: impl Into<String>) -> Self {
        Self::MissingNode {
            capsule_id: capsule_id.into(),
            node_id: node_id.into(),
        }
    }

    pub fn missing_edge(capsule_id: impl Into<String>, edge_id: impl Into<String>) -> Self {
        Self::MissingEdge {
            capsule_id: capsule_id.into(),
            edge_id: edge_id.into(),
        }
    }

    pub fn cycle_detected(source: impl Into<String>, target: impl Into<String>) -> Self {
        Self::CycleDetected {
            source: source.into(),
            target: target.into(),
        }
    }

    // ── Invalid operation ──
    pub fn invalid_operation(capsule_id: impl Into<String>, reason: impl Into<String>) -> Self {
        Self::InvalidOperation {
            capsule_id: capsule_id.into(),
            reason: reason.into(),
        }
    }

    pub fn terminal_capsule(capsule_id: impl Into<String>, status: impl Into<String>) -> Self {
        Self::TerminalCapsule {
            capsule_id: capsule_id.into(),
            status: status.into(),
        }
    }

    // ── Events ──
    pub fn event_error(detail: impl Into<String>) -> Self {
        Self::EventError {
            detail: detail.into(),
        }
    }

    pub fn event_stream_error(detail: impl Into<String>) -> Self {
        Self::EventStreamError {
            detail: detail.into(),
        }
    }

    // ── Replay ──
    pub fn replay_error(timeline_id: impl Into<String>, detail: impl Into<String>) -> Self {
        Self::ReplayError {
            timeline_id: timeline_id.into(),
            detail: detail.into(),
        }
    }

    pub fn snapshot_missing(snapshot_id: impl Into<String>) -> Self {
        Self::SnapshotMissing {
            snapshot_id: snapshot_id.into(),
        }
    }

    // ── Healing ──
    pub fn healing_error(capsule_id: impl Into<String>, detail: impl Into<String>) -> Self {
        Self::HealingError {
            capsule_id: capsule_id.into(),
            detail: detail.into(),
        }
    }

    pub fn healing_policy_violation(
        capsule_id: impl Into<String>,
        rule: impl Into<String>,
    ) -> Self {
        Self::HealingPolicyViolation {
            capsule_id: capsule_id.into(),
            rule: rule.into(),
        }
    }

    // ── Internal ──
    pub fn internal(detail: impl Into<String>) -> Self {
        Self::Internal {
            detail: detail.into(),
        }
    }
}

impl fmt::Display for CapsuleError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Storage { capsule_id, detail } => {
                write!(f, "[capsule:{capsule_id}] storage error: {detail}")
            }
            Self::ManifestMissing { capsule_id } => {
                write!(f, "[capsule:{capsule_id}] manifest missing or unreadable")
            }
            Self::Corruption {
                capsule_id,
                target_id,
                expected_hash,
                actual_hash,
            } => {
                write!(
                    f,
                    "[capsule:{capsule_id}] corruption in {target_id}: \
                     expected hash {expected_hash}, got {actual_hash}"
                )
            }
            Self::SchemaMismatch {
                capsule_id,
                expected,
                actual,
            } => {
                write!(
                    f,
                    "[capsule:{capsule_id}] schema version mismatch: \
                     expected v{expected}, got v{actual}"
                )
            }
            Self::MissingNode {
                capsule_id,
                node_id,
            } => {
                write!(f, "[capsule:{capsule_id}] node not found: {node_id}")
            }
            Self::MissingEdge {
                capsule_id,
                edge_id,
            } => {
                write!(f, "[capsule:{capsule_id}] edge not found: {edge_id}")
            }
            Self::CycleDetected { source, target } => {
                write!(
                    f,
                    "cycle detected: edge {source} → {target} would create a cycle"
                )
            }
            Self::InvalidOperation { capsule_id, reason } => {
                write!(f, "[capsule:{capsule_id}] invalid operation: {reason}")
            }
            Self::TerminalCapsule { capsule_id, status } => {
                write!(
                    f,
                    "[capsule:{capsule_id}] cannot operate on terminal capsule (status: {status})"
                )
            }
            Self::EventError { detail } => {
                write!(f, "event error: {detail}")
            }
            Self::EventStreamError { detail } => {
                write!(f, "event stream error: {detail}")
            }
            Self::ReplayError {
                timeline_id,
                detail,
            } => {
                write!(f, "[timeline:{timeline_id}] replay error: {detail}")
            }
            Self::SnapshotMissing { snapshot_id } => {
                write!(f, "snapshot not found: {snapshot_id}")
            }
            Self::HealingError { capsule_id, detail } => {
                write!(f, "[capsule:{capsule_id}] healing error: {detail}")
            }
            Self::HealingPolicyViolation { capsule_id, rule } => {
                write!(f, "[capsule:{capsule_id}] healing policy violation: {rule}")
            }
            Self::Internal { detail } => {
                write!(f, "internal error: {detail}")
            }
        }
    }
}

impl std::error::Error for CapsuleError {}

/// Convenience alias for capsule operations.
pub type CapsuleResult<T> = Result<T, CapsuleError>;

// ──────────────────────────────────────────────
// Conversions from other error types
// ──────────────────────────────────────────────

impl From<std::io::Error> for CapsuleError {
    fn from(err: std::io::Error) -> Self {
        Self::Internal {
            detail: format!("IO error: {err}"),
        }
    }
}

impl From<serde_json::Error> for CapsuleError {
    fn from(err: serde_json::Error) -> Self {
        Self::Internal {
            detail: format!("serialization error: {err}"),
        }
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display_storage() {
        let err = CapsuleError::storage("cap-1", "disk full");
        let msg = err.to_string();
        assert!(msg.contains("cap-1"));
        assert!(msg.contains("disk full"));
    }

    #[test]
    fn test_error_display_corruption() {
        let err = CapsuleError::corruption("cap-1", "node-1", "abc", "def");
        let msg = err.to_string();
        assert!(msg.contains("abc"));
        assert!(msg.contains("def"));
    }

    #[test]
    fn test_error_display_cycle() {
        let err = CapsuleError::cycle_detected("a", "b");
        let msg = err.to_string();
        assert!(msg.contains("a → b"));
    }

    #[test]
    fn test_error_implements_std_error() {
        fn is_std_error<T: std::error::Error>() {}
        is_std_error::<CapsuleError>();
    }

    #[test]
    fn test_error_from_io() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let capsule_err: CapsuleError = io_err.into();
        assert!(capsule_err.to_string().contains("file not found"));
    }

    #[test]
    fn test_error_from_serde() {
        let serde_err = serde_json::from_str::<String>("invalid").unwrap_err();
        let capsule_err: CapsuleError = serde_err.into();
        assert!(capsule_err.to_string().contains("serialization error"));
    }

    #[test]
    fn test_all_error_constructors() {
        let _ = CapsuleError::storage("c", "d");
        let _ = CapsuleError::manifest_missing("c");
        let _ = CapsuleError::corruption("c", "t", "e", "a");
        let _ = CapsuleError::schema_mismatch("c", 1, 2);
        let _ = CapsuleError::missing_node("c", "n");
        let _ = CapsuleError::missing_edge("c", "e");
        let _ = CapsuleError::cycle_detected("s", "t");
        let _ = CapsuleError::invalid_operation("c", "reason");
        let _ = CapsuleError::terminal_capsule("c", "archived");
        let _ = CapsuleError::event_error("bus full");
        let _ = CapsuleError::event_stream_error("write failed");
        let _ = CapsuleError::replay_error("tl-1", "snapshot not found");
        let _ = CapsuleError::snapshot_missing("snap-1");
        let _ = CapsuleError::healing_error("c", "loop timeout");
        let _ = CapsuleError::healing_policy_violation("c", "max retries exceeded");
        let _ = CapsuleError::internal("unknown");
    }
}
