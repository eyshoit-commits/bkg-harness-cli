//! CapsuleEdge — a directed edge in the capsule DAG.
//!
//! Edges connect `CapsuleNode` instances to form a directed acyclic graph.
//! Each edge has a type that describes the relationship semantics:
//! - `DependsOn`: execution dependency (source must complete before target)
//! - `Contains`: parent-child containment
//! - `References`: cross-reference (e.g., receipt references a chain)
//! - `Produces`: source node produced target node
//! - `Replay`: source was replayed to create target
//! - `Repair`: source was repaired as target
//! - `Verification`: source passed verification to become target

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

pub type EdgeId = String;
pub type NodeId = String;

/// Semantic type of a capsule graph edge.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum EdgeType {
    DependsOn,
    Contains,
    References,
    Produces,
    Replay,
    Repair,
    Verification,
}

impl std::fmt::Display for EdgeType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EdgeType::DependsOn => write!(f, "depends-on"),
            EdgeType::Contains => write!(f, "contains"),
            EdgeType::References => write!(f, "references"),
            EdgeType::Produces => write!(f, "produces"),
            EdgeType::Replay => write!(f, "replay"),
            EdgeType::Repair => write!(f, "repair"),
            EdgeType::Verification => write!(f, "verification"),
        }
    }
}

/// A directed edge between two capsule nodes.
///
/// Edges are directional: source → target. A DAG invariant is maintained:
/// there must be no cycles. The `weight` field supports ranked/prioritized
/// traversal (e.g., shortest-path analysis for dependency resolution).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleEdge {
    pub id: EdgeId,
    pub source: NodeId,
    pub target: NodeId,
    pub edge_type: EdgeType,
    pub label: String,
    pub weight: f64,
    pub created_at: DateTime<Utc>,
    pub metadata: serde_json::Value,
}

impl CapsuleEdge {
    /// Create a new directed edge.
    pub fn new(
        id: impl Into<String>,
        source: impl Into<String>,
        target: impl Into<String>,
        edge_type: EdgeType,
    ) -> Self {
        Self {
            id: id.into(),
            source: source.into(),
            target: target.into(),
            edge_type,
            label: String::new(),
            weight: 1.0,
            created_at: Utc::now(),
            metadata: serde_json::json!({}),
        }
    }

    /// Set a human-readable label.
    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = label.into();
        self
    }

    /// Set the traversal weight (default: 1.0).
    pub fn with_weight(mut self, weight: f64) -> Self {
        self.weight = weight;
        self
    }

    /// Attach metadata.
    pub fn with_metadata(mut self, metadata: serde_json::Value) -> Self {
        self.metadata = metadata;
        self
    }
}
