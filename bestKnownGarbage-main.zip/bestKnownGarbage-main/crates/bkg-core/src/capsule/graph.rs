//! CapsuleGraph — the DAG container for capsule nodes and edges.
//!
//! A `CapsuleGraph` holds all nodes and edges for a single capsule,
//! maintains DAG invariants, and provides topological analysis.
//!
//! # DAG Invariants
//!
//! - No cycles: enforced by `add_edge` (refuses edges that create cycles)
//! - Root nodes: tracked in `root_nodes` (nodes with no parents)
//! - Parent/child references: kept in sync with edge operations
//!
//! # Usage
//!
//! ```rust,ignore
//! let mut graph = CapsuleGraph::new("cap-7f91");
//! graph.add_node(CapsuleNode::new("task-1", NodeKind::Task, "Build feature"));
//! graph.add_node(CapsuleNode::new("exec-1", NodeKind::Execution, "Execute"));
//! graph.add_edge(CapsuleEdge::new("e1", "task-1", "exec-1", EdgeType::Produces));
//! let levels = graph.topological_levels();
//! ```

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use super::edge::{CapsuleEdge, EdgeId};
use super::node::{CapsuleNode, NodeId};
use crate::chain::hashes::hash_bytes;

pub type CapsuleId = String;

/// The complete DAG for one capsule.
///
/// Nodes and edges are stored in `HashMap`s for O(1) lookup.
/// `root_nodes` is maintained as an optimization for topological traversal.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleGraph {
    pub capsule_id: CapsuleId,
    pub nodes: HashMap<NodeId, CapsuleNode>,
    pub edges: HashMap<EdgeId, CapsuleEdge>,
    pub root_nodes: Vec<NodeId>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl CapsuleGraph {
    /// Create an empty graph for the given capsule.
    pub fn new(capsule_id: impl Into<String>) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            nodes: HashMap::new(),
            edges: HashMap::new(),
            root_nodes: Vec::new(),
            created_at: Utc::now(),
            updated_at: Utc::now(),
        }
    }

    /// Add a node to the graph.
    ///
    /// If the node has no parents, it's added to `root_nodes`.
    /// Nodes with duplicate IDs are silently ignored (no-op).
    pub fn add_node(&mut self, node: CapsuleNode) {
        let id = node.id.clone();
        if self.nodes.contains_key(&id) {
            return;
        }
        if node.parents.is_empty() {
            self.root_nodes.push(id.clone());
        }
        self.nodes.insert(id, node);
        self.updated_at = Utc::now();
    }

    /// Add a directed edge to the graph.
    ///
    /// Updates parent/child references on the affected nodes.
    /// If the target node was a root (no parents), it's removed from
    /// `root_nodes`. Returns an error if the edge would create a cycle.
    pub fn add_edge(&mut self, edge: CapsuleEdge) -> Result<(), String> {
        // Validate both endpoints exist
        if !self.nodes.contains_key(&edge.source) {
            return Err(format!("source node '{}' not found", edge.source));
        }
        if !self.nodes.contains_key(&edge.target) {
            return Err(format!("target node '{}' not found", edge.target));
        }

        // Check for cycles before adding
        if self.would_create_cycle(&edge.source, &edge.target) {
            return Err(format!(
                "edge {} → {} would create a cycle",
                edge.source, edge.target
            ));
        }

        // Update source children
        if let Some(source) = self.nodes.get_mut(&edge.source) {
            if !source.children.contains(&edge.target) {
                source.children.push(edge.target.clone());
            }
        }

        // Update target parents
        if let Some(target) = self.nodes.get_mut(&edge.target) {
            if !target.parents.contains(&edge.source) {
                target.parents.push(edge.source.clone());
            }
            // Target is no longer a root
            self.root_nodes.retain(|r| r != &edge.target);
        }

        let edge_id = edge.id.clone();
        self.edges.insert(edge_id, edge);
        self.updated_at = Utc::now();
        Ok(())
    }

    /// Check if adding an edge source → target would create a cycle.
    ///
    /// Uses DFS from target: if we can reach source, adding the edge
    /// would create a cycle (source → target → ... → source).
    fn would_create_cycle(&self, source: &str, target: &str) -> bool {
        // If source == target, it's trivially a cycle
        if source == target {
            return true;
        }
        // DFS from target — can we reach source?
        let mut visited = std::collections::HashSet::new();
        let mut stack = vec![target.to_string()];
        while let Some(current) = stack.pop() {
            if current == source {
                return true;
            }
            if visited.contains(&current) {
                continue;
            }
            visited.insert(current.clone());
            if let Some(node) = self.nodes.get(&current) {
                for child in &node.children {
                    if !visited.contains(child) {
                        stack.push(child.clone());
                    }
                }
            }
        }
        false
    }

    /// Get a node by ID.
    pub fn get_node(&self, id: &str) -> Option<&CapsuleNode> {
        self.nodes.get(id)
    }

    /// Get a mutable reference to a node.
    pub fn get_node_mut(&mut self, id: &str) -> Option<&mut CapsuleNode> {
        self.nodes.get_mut(id)
    }

    /// Get an edge by ID.
    pub fn get_edge(&self, id: &str) -> Option<&CapsuleEdge> {
        self.edges.get(id)
    }

    /// Remove a node and all edges connected to it.
    pub fn remove_node(&mut self, id: &str) -> Option<CapsuleNode> {
        // Remove all edges connected to this node
        self.edges.retain(|_, e| e.source != id && e.target != id);
        // Remove from root_nodes
        self.root_nodes.retain(|r| r != id);
        // Remove from parent/child references
        for node in self.nodes.values_mut() {
            node.parents.retain(|p| p != id);
            node.children.retain(|c| c != id);
        }
        let node = self.nodes.remove(id);
        self.updated_at = Utc::now();
        node
    }

    /// Remove an edge and clean up parent/child references.
    pub fn remove_edge(&mut self, id: &str) -> Option<CapsuleEdge> {
        let edge = self.edges.remove(id)?;
        // Clean up source children
        if let Some(source) = self.nodes.get_mut(&edge.source) {
            source.children.retain(|c| c != &edge.target);
        }
        // Clean up target parents
        if let Some(target) = self.nodes.get_mut(&edge.target) {
            target.parents.retain(|p| p != &edge.source);
            // If target now has no parents, restore it as a root
            if target.parents.is_empty() {
                self.root_nodes.push(edge.target.clone());
            }
        }
        self.updated_at = Utc::now();
        Some(edge)
    }

    /// Number of nodes in the graph.
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    /// Number of edges in the graph.
    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }

    /// Compute a cryptographic hash of the entire graph.
    ///
    /// Used for integrity verification and drift detection.
    /// Uses canonical serialization (sorted keys, sorted entries) to ensure
    /// identical graphs always produce identical hashes.
    /// Excludes temporal fields (`created_at`, `updated_at`) from the hash
    /// to ensure determinism across runs.
    pub fn compute_hash(&self) -> String {
        let mut sorted_nodes: Vec<(&super::node::NodeId, &super::node::CapsuleNode)> =
            self.nodes.iter().collect();
        sorted_nodes.sort_by(|a, b| a.0.cmp(b.0));

        let mut sorted_edges: Vec<(&super::edge::EdgeId, &super::edge::CapsuleEdge)> =
            self.edges.iter().collect();
        sorted_edges.sort_by(|a, b| a.0.cmp(b.0));

        /// Canonical node — excludes temporal fields.
        #[derive(Serialize)]
        struct CanonicalNode<'a> {
            id: &'a super::node::NodeId,
            kind: &'a super::node::NodeKind,
            label: &'a str,
            description: &'a str,
            status: &'a super::node::NodeStatus,
            hash: &'a str,
            parents: &'a [super::node::NodeId],
            children: &'a [super::node::NodeId],
            depth: usize,
        }

        /// Canonical edge — excludes temporal fields.
        #[derive(Serialize)]
        struct CanonicalEdge<'a> {
            id: &'a super::edge::EdgeId,
            source: &'a super::edge::NodeId,
            target: &'a super::edge::NodeId,
            edge_type: &'a super::edge::EdgeType,
            label: &'a str,
            weight: f64,
        }

        let canonical_nodes: Vec<CanonicalNode> = sorted_nodes
            .iter()
            .map(|(_id, n)| CanonicalNode {
                id: &n.id,
                kind: &n.kind,
                label: &n.label,
                description: &n.description,
                status: &n.status,
                hash: &n.hash,
                parents: &n.parents,
                children: &n.children,
                depth: n.depth,
            })
            .collect();

        let canonical_edges: Vec<CanonicalEdge> = sorted_edges
            .iter()
            .map(|(_id, e)| CanonicalEdge {
                id: &e.id,
                source: &e.source,
                target: &e.target,
                edge_type: &e.edge_type,
                label: &e.label,
                weight: e.weight,
            })
            .collect();

        #[derive(Serialize)]
        struct CanonicalGraph<'a> {
            capsule_id: &'a str,
            nodes: &'a [CanonicalNode<'a>],
            edges: &'a [CanonicalEdge<'a>],
            root_nodes: &'a [super::node::NodeId],
        }

        let canonical = CanonicalGraph {
            capsule_id: &self.capsule_id,
            nodes: &canonical_nodes,
            edges: &canonical_edges,
            root_nodes: &self.root_nodes,
        };

        let json = serde_json::to_string(&canonical).unwrap_or_default();
        hash_bytes(json.as_bytes())
    }

    /// Compute topological levels using Kahn's algorithm.
    ///
    /// Returns levels as `Vec<Vec<NodeId>>` where each inner vec contains
    /// all nodes at that level (same topological depth). Level 0 = roots.
    pub fn topological_levels(&self) -> Vec<Vec<NodeId>> {
        // Compute in-degree for each node
        let mut in_degree: HashMap<&NodeId, usize> = HashMap::new();
        for node_id in self.nodes.keys() {
            in_degree.entry(node_id).or_insert(0);
        }
        for edge in self.edges.values() {
            *in_degree.entry(&edge.target).or_insert(0) += 1;
        }

        let mut levels: Vec<Vec<NodeId>> = Vec::new();
        let mut queue: Vec<NodeId> = self.root_nodes.clone();
        let mut visited = std::collections::HashSet::<NodeId>::new();

        while !queue.is_empty() {
            let level_nodes: Vec<NodeId> = queue.drain(..).collect();
            let mut next_queue = Vec::new();
            for node_id in &level_nodes {
                if visited.contains(node_id) {
                    continue;
                }
                visited.insert(node_id.clone());
                if let Some(node) = self.nodes.get(node_id) {
                    for child_id in &node.children {
                        if let Some(deg) = in_degree.get_mut(child_id) {
                            *deg = deg.saturating_sub(1);
                            if *deg == 0 {
                                next_queue.push(child_id.clone());
                            }
                        }
                    }
                }
            }
            if !level_nodes.is_empty() {
                levels.push(level_nodes);
            }
            queue = next_queue;
        }

        levels
    }

    /// Find all descendants of a node (BFS).
    pub fn descendants(&self, node_id: &str) -> Vec<NodeId> {
        let mut result = Vec::new();
        let mut visited = std::collections::HashSet::new();
        let mut stack = vec![node_id.to_string()];

        while let Some(current) = stack.pop() {
            if visited.contains(&current) {
                continue;
            }
            visited.insert(current.clone());
            if current != node_id {
                result.push(current.clone());
            }
            if let Some(node) = self.nodes.get(&current) {
                for child in &node.children {
                    stack.push(child.clone());
                }
            }
        }
        result
    }

    /// Find all ancestors of a node (BFS).
    pub fn ancestors(&self, node_id: &str) -> Vec<NodeId> {
        let mut result = Vec::new();
        let mut visited = std::collections::HashSet::new();
        let mut stack = vec![node_id.to_string()];

        while let Some(current) = stack.pop() {
            if visited.contains(&current) {
                continue;
            }
            visited.insert(current.clone());
            if current != node_id {
                result.push(current.clone());
            }
            if let Some(node) = self.nodes.get(&current) {
                for parent in &node.parents {
                    stack.push(parent.clone());
                }
            }
        }
        result
    }

    /// Filter nodes by kind.
    pub fn nodes_by_kind(&self, kind: &super::node::NodeKind) -> Vec<&CapsuleNode> {
        self.nodes.values().filter(|n| n.kind == *kind).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::edge::EdgeType;
    use crate::capsule::node::NodeKind;

    #[test]
    fn test_empty_graph() {
        let g = CapsuleGraph::new("cap-test");
        assert_eq!(g.node_count(), 0);
        assert_eq!(g.edge_count(), 0);
        assert!(g.root_nodes.is_empty());
    }

    #[test]
    fn test_add_node() {
        let mut g = CapsuleGraph::new("cap-test");
        let node = CapsuleNode::new("task-1", NodeKind::Task, "Test task");
        g.add_node(node);
        assert_eq!(g.node_count(), 1);
        assert_eq!(g.root_nodes, vec!["task-1".to_string()]);
    }

    #[test]
    fn test_add_node_with_parent() {
        let mut g = CapsuleGraph::new("cap-test");
        let parent = CapsuleNode::new("parent", NodeKind::Task, "Parent");
        let child = CapsuleNode::new("child", NodeKind::Execution, "Child").with_parent("parent");
        g.add_node(parent);
        g.add_node(child);
        assert_eq!(g.node_count(), 2);
        // Child has a parent, so only parent is root
        assert_eq!(g.root_nodes, vec!["parent".to_string()]);
    }

    #[test]
    fn test_add_edge_updates_refs() {
        let mut g = CapsuleGraph::new("cap-test");
        g.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        g.add_node(CapsuleNode::new("b", NodeKind::Execution, "B"));
        assert!(g.root_nodes.contains(&"a".into()));
        assert!(g.root_nodes.contains(&"b".into()));
        assert_eq!(g.root_nodes.len(), 2);

        g.add_edge(CapsuleEdge::new("e1", "a", "b", EdgeType::Produces))
            .unwrap();

        // Root nodes should now only contain "a" (b has a parent)
        assert_eq!(g.root_nodes, vec!["a".to_string()]);
        assert!(g.get_node("a").unwrap().children.contains(&"b".into()));
        assert!(g.get_node("b").unwrap().parents.contains(&"a".into()));
    }

    #[test]
    fn test_cycle_detection() {
        let mut g = CapsuleGraph::new("cap-test");
        g.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        g.add_node(CapsuleNode::new("b", NodeKind::Execution, "B"));
        g.add_node(CapsuleNode::new("c", NodeKind::Task, "C"));

        g.add_edge(CapsuleEdge::new("e1", "a", "b", EdgeType::Produces))
            .unwrap();
        g.add_edge(CapsuleEdge::new("e2", "b", "c", EdgeType::Produces))
            .unwrap();

        // Adding c → a would create a cycle
        let result = g.add_edge(CapsuleEdge::new("e3", "c", "a", EdgeType::DependsOn));
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("cycle"));
    }

    #[test]
    fn test_topological_levels() {
        let mut g = CapsuleGraph::new("cap-test");
        g.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        g.add_node(CapsuleNode::new("b", NodeKind::Execution, "B"));
        g.add_node(CapsuleNode::new("c", NodeKind::Receipt, "C"));

        g.add_edge(CapsuleEdge::new("e1", "a", "b", EdgeType::Produces))
            .unwrap();
        g.add_edge(CapsuleEdge::new("e2", "b", "c", EdgeType::Produces))
            .unwrap();

        let levels = g.topological_levels();
        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0], vec!["a"]);
        assert_eq!(levels[1], vec!["b"]);
        assert_eq!(levels[2], vec!["c"]);
    }

    #[test]
    fn test_remove_node() {
        let mut g = CapsuleGraph::new("cap-test");
        g.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        g.add_node(CapsuleNode::new("b", NodeKind::Execution, "B"));
        g.add_edge(CapsuleEdge::new("e1", "a", "b", EdgeType::Produces))
            .unwrap();

        assert_eq!(g.node_count(), 2);
        assert_eq!(g.edge_count(), 1);

        let removed = g.remove_node("a");
        assert!(removed.is_some());
        assert_eq!(g.node_count(), 1);
        assert_eq!(g.edge_count(), 0); // edge removed too
    }

    #[test]
    fn test_descendants_and_ancestors() {
        let mut g = CapsuleGraph::new("cap-test");
        g.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        g.add_node(CapsuleNode::new("b", NodeKind::Execution, "B"));
        g.add_node(CapsuleNode::new("c", NodeKind::Receipt, "C"));
        g.add_edge(CapsuleEdge::new("e1", "a", "b", EdgeType::Produces))
            .unwrap();
        g.add_edge(CapsuleEdge::new("e2", "b", "c", EdgeType::Produces))
            .unwrap();

        let desc = g.descendants("a");
        assert!(desc.contains(&"b".to_string()));
        assert!(desc.contains(&"c".to_string()));

        let anc = g.ancestors("c");
        assert!(anc.contains(&"a".to_string()));
        assert!(anc.contains(&"b".to_string()));
    }

    #[test]
    fn test_hash_deterministic() {
        let mut g1 = CapsuleGraph::new("cap-test");
        g1.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));
        let mut g2 = CapsuleGraph::new("cap-test");
        g2.add_node(CapsuleNode::new("a", NodeKind::Task, "A"));

        assert_eq!(g1.compute_hash(), g2.compute_hash());
    }
}
