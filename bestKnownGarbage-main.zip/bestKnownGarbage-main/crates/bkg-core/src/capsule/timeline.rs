//! **Causa** EventTimeline — index of events for temporal replay.
//!
//! An `EventTimeline` is an ordered index of `TimelineEntry` records.
//! Each entry pairs a `GraphEvent` with the `StateSnapshot` that resulted
//! from processing that event, enabling forward/backward stepping through
//! capsule history.
//!
//! # Usage
//!
//! The timeline is appended to by the `TemporalReplayEngine` as events are
//! processed. Consumers can:
//! - Scan forward/backward through event history
//! - Query a time range for analytics
//! - Replay at configurable speed (step-by-step or fast-forward)
//!
//! # Storage
//!
//! Timelines are backed by the same persistence layer as capsule state —
//! segmenting to `capsules/<id>/timelines/<timeline_id>/` on disk.
//! The `TimelineStorage` trait abstracts this.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use super::error::{CapsuleError, CapsuleResult};
use super::event::GraphEvent;
use super::snapshot::SnapshotId;
use super::types::{CapsuleId, TimelineEntry, TimelineId, TimelineSummary};

/// Maximum number of entries in an in-memory timeline before truncation.
/// Keeps memory bounded — old entries are evicted from hot cache but
/// remain on disk.
pub const MAX_IN_MEMORY_ENTRIES: u64 = 10_000;

/// An ordered index of timeline entries for temporal replay.
///
/// The timeline is append-only. Entries are added monotonically by sequence
/// number. Lookups are O(1) by seq or by snapshot_id via the index map.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventTimeline {
    /// Timeline identifier
    pub timeline_id: TimelineId,
    /// Capsule this timeline belongs to
    pub capsule_id: CapsuleId,
    /// All entries, ordered by seq
    pub entries: Vec<TimelineEntry>,
    /// Index: snapshot_id → seq (O(1) snapshot lookup)
    #[serde(skip_serializing, default)]
    snapshot_index: std::collections::HashMap<SnapshotId, u64>,
    /// Index: event_id → seq (O(1) event lookup)
    #[serde(skip_serializing, default)]
    event_index: std::collections::HashMap<String, u64>,
    /// Current position for replay (index into entries, not seq)
    #[serde(skip)]
    pub cursor: usize,
    /// Creation timestamp
    pub created_at: DateTime<Utc>,
    /// Last append timestamp
    pub updated_at: DateTime<Utc>,
}

impl EventTimeline {
    /// Create a new empty timeline.
    pub fn new(timeline_id: impl Into<String>, capsule_id: impl Into<String>) -> Self {
        Self {
            timeline_id: timeline_id.into(),
            capsule_id: capsule_id.into(),
            entries: Vec::new(),
            snapshot_index: std::collections::HashMap::new(),
            event_index: std::collections::HashMap::new(),
            cursor: 0,
            created_at: Utc::now(),
            updated_at: Utc::now(),
        }
    }

    /// Append an entry to the timeline.
    ///
    /// Returns an error if the seq would be out of order (past entries must
    /// have increasing seq numbers) or if the snapshot_id/event_id would
    /// duplicate an existing entry.
    pub fn append(&mut self, entry: TimelineEntry) -> CapsuleResult<()> {
        // Validate seq monotonicity
        if let Some(last) = self.entries.last() {
            if entry.seq <= last.seq {
                return Err(CapsuleError::invalid_operation(
                    &self.capsule_id,
                    format!(
                        "out-of-order timeline append: last seq={}, new seq={}",
                        last.seq, entry.seq
                    ),
                ));
            }
        }

        // Check for duplicate snapshot_id
        if self
            .snapshot_index
            .contains_key(&entry.snapshot.snapshot_id)
        {
            return Err(CapsuleError::invalid_operation(
                &self.capsule_id,
                format!(
                    "duplicate snapshot_id in timeline: {}",
                    entry.snapshot.snapshot_id
                ),
            ));
        }

        // Check for duplicate event_id
        if self.event_index.contains_key(&entry.event.event_id) {
            return Err(CapsuleError::invalid_operation(
                &self.capsule_id,
                format!("duplicate event_id in timeline: {}", entry.event.event_id),
            ));
        }

        // Update indices
        self.snapshot_index
            .insert(entry.snapshot.snapshot_id.clone(), entry.seq);
        self.event_index
            .insert(entry.event.event_id.clone(), entry.seq);

        self.entries.push(entry);
        self.updated_at = Utc::now();

        // Enforce memory limit — evict oldest if over threshold
        if self.entries.len() as u64 > MAX_IN_MEMORY_ENTRIES {
            let evicted = self.entries.remove(0);
            self.snapshot_index.remove(&evicted.snapshot.snapshot_id);
            self.event_index.remove(&evicted.event.event_id);
            if self.cursor > 0 {
                self.cursor -= 1;
            }
        }

        Ok(())
    }

    /// Get an entry by sequence number.
    pub fn get_by_seq(&self, seq: u64) -> Option<&TimelineEntry> {
        // Binary search since entries are sorted by seq
        self.entries
            .binary_search_by(|e| e.seq.cmp(&seq))
            .ok()
            .map(|i| &self.entries[i])
    }

    /// Get an entry by snapshot_id.
    pub fn get_by_snapshot(&self, snapshot_id: &str) -> Option<&TimelineEntry> {
        self.snapshot_index
            .get(snapshot_id)
            .and_then(|seq| self.get_by_seq(*seq))
    }

    /// Get an entry by event_id.
    pub fn get_by_event(&self, event_id: &str) -> Option<&TimelineEntry> {
        self.event_index
            .get(event_id)
            .and_then(|seq| self.get_by_seq(*seq))
    }

    /// Get the entry at the current cursor position.
    pub fn current(&self) -> Option<&TimelineEntry> {
        self.entries.get(self.cursor)
    }

    /// Move cursor forward one step. Returns the new current entry, or None
    /// if already at the end.
    pub fn step_forward(&mut self) -> Option<&TimelineEntry> {
        if self.cursor + 1 < self.entries.len() {
            self.cursor += 1;
            self.entries.get(self.cursor)
        } else {
            None
        }
    }

    /// Move cursor backward one step. Returns the new current entry, or None
    /// if already at the beginning.
    pub fn step_backward(&mut self) -> Option<&TimelineEntry> {
        if self.cursor > 0 {
            self.cursor -= 1;
            self.entries.get(self.cursor)
        } else {
            None
        }
    }

    /// Jump to a specific sequence number.
    pub fn jump_to_seq(&mut self, seq: u64) -> CapsuleResult<Option<&TimelineEntry>> {
        let pos = self.entries.binary_search_by(|e| e.seq.cmp(&seq));
        match pos {
            Ok(i) => {
                self.cursor = i;
                Ok(Some(&self.entries[i]))
            }
            Err(_) => Ok(None),
        }
    }

    /// Query entries within a time range.
    pub fn range(&self, from: DateTime<Utc>, to: DateTime<Utc>) -> Vec<&TimelineEntry> {
        self.entries
            .iter()
            .filter(|e| e.timestamp >= from && e.timestamp <= to)
            .collect()
    }

    /// Query entries matching a predicate on the event kind.
    pub fn filter_events(&self, predicate: fn(&GraphEvent) -> bool) -> Vec<&TimelineEntry> {
        self.entries
            .iter()
            .filter(|e| predicate(&e.event))
            .collect()
    }

    /// Get entries from the current cursor position to the end.
    pub fn entries_from_cursor(&self) -> &[TimelineEntry] {
        let start = self.cursor.min(self.entries.len());
        &self.entries[start..]
    }

    /// Number of entries in the timeline.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the timeline is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Build a summary of this timeline.
    pub fn summary(&self) -> TimelineSummary {
        TimelineSummary {
            timeline_id: self.timeline_id.clone(),
            capsule_id: self.capsule_id.clone(),
            entry_count: self.entries.len() as u64,
            created_at: self.created_at,
            updated_at: self.updated_at,
            first_event_time: self.entries.first().map(|e| e.timestamp),
            last_event_time: self.entries.last().map(|e| e.timestamp),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::event::{GraphEvent, GraphEventKind, GraphSeverity};
    use crate::capsule::graph::CapsuleGraph;
    use crate::capsule::node::{CapsuleNode, NodeKind};
    use crate::capsule::snapshot::StateSnapshot;

    fn make_event(capsule: &str, kind: GraphEventKind) -> GraphEvent {
        GraphEvent::new(capsule, kind, GraphSeverity::Info)
    }

    fn make_snapshot(capsule: &str, seq: u64) -> StateSnapshot {
        let mut graph = CapsuleGraph::new(capsule);
        graph.add_node(CapsuleNode::new(
            format!("n{seq}"),
            NodeKind::Task,
            format!("Node {seq}"),
        ));
        StateSnapshot::new(format!("snap-{seq}"), capsule, seq, graph, "test")
    }

    fn make_entry(timeline: &str, capsule: &str, seq: u64, kind: GraphEventKind) -> TimelineEntry {
        TimelineEntry {
            entry_id: format!("entry-{seq}"),
            seq,
            timestamp: Utc::now(),
            event: make_event(capsule, kind),
            snapshot: make_snapshot(capsule, seq),
        }
    }

    #[test]
    fn test_empty_timeline() {
        let tl = EventTimeline::new("tl-1", "cap-1");
        assert!(tl.is_empty());
        assert_eq!(tl.len(), 0);
        assert!(tl.current().is_none());
    }

    #[test]
    fn test_append_entry() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        let entry = make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded);
        tl.append(entry).unwrap();
        assert_eq!(tl.len(), 1);
    }

    #[test]
    fn test_rejects_out_of_order_seq() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 2, GraphEventKind::NodeAdded))
            .unwrap();
        let result = tl.append(make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded));
        assert!(result.is_err());
    }

    #[test]
    fn test_rejects_duplicate_snapshot() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded))
            .unwrap();
        // Same snapshot_id "snap-1" would trigger duplicate check
        let dup = TimelineEntry {
            entry_id: "entry-2".to_string(),
            seq: 2,
            timestamp: Utc::now(),
            event: make_event("cap-1", GraphEventKind::NodeAdded),
            snapshot: make_snapshot("cap-1", 1), // seq=1 → snapshot_id="snap-1"
        };
        let result = tl.append(dup);
        assert!(result.is_err());
    }

    #[test]
    fn test_step_forward_and_backward() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded))
            .unwrap();
        tl.append(make_entry("tl-1", "cap-1", 2, GraphEventKind::NodeUpdated))
            .unwrap();
        tl.append(make_entry("tl-1", "cap-1", 3, GraphEventKind::NodeVerified))
            .unwrap();

        // Start at beginning
        assert_eq!(tl.current().unwrap().seq, 1);

        // Step forward
        assert_eq!(tl.step_forward().unwrap().seq, 2);
        assert_eq!(tl.step_forward().unwrap().seq, 3);
        assert!(tl.step_forward().is_none()); // End

        // Step backward
        assert_eq!(tl.step_backward().unwrap().seq, 2);
        assert_eq!(tl.step_backward().unwrap().seq, 1);
        assert!(tl.step_backward().is_none()); // Beginning
    }

    #[test]
    fn test_jump_to_seq() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 10, GraphEventKind::NodeAdded))
            .unwrap();
        tl.append(make_entry("tl-1", "cap-1", 20, GraphEventKind::NodeUpdated))
            .unwrap();

        let entry = tl.jump_to_seq(10).unwrap();
        assert!(entry.is_some());
        assert_eq!(entry.unwrap().seq, 10);

        let entry = tl.jump_to_seq(20).unwrap();
        assert!(entry.is_some());
        assert_eq!(entry.unwrap().seq, 20);
    }

    #[test]
    fn test_lookup_by_snapshot_and_event() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded))
            .unwrap();

        // Lookup by snapshot_id
        let entry = tl.get_by_snapshot("snap-1");
        assert!(entry.is_some());

        // Lookup by event_id (we need the actual event_id from the first entry)
        let first = tl.entries.first().unwrap();
        let entry = tl.get_by_event(&first.event.event_id);
        assert!(entry.is_some());
    }

    #[test]
    fn test_time_range_query() {
        let mut tl = EventTimeline::new("tl-1", "cap-1");
        tl.append(make_entry("tl-1", "cap-1", 1, GraphEventKind::NodeAdded))
            .unwrap();
        tl.append(make_entry("tl-1", "cap-1", 2, GraphEventKind::NodeUpdated))
            .unwrap();

        // Range covering all entries
        let from = DateTime::parse_from_rfc3339("2020-01-01T00:00:00Z")
            .unwrap()
            .with_timezone(&Utc);
        let to = Utc::now() + chrono::Duration::hours(1);
        let range = tl.range(from, to);
        assert_eq!(range.len(), 2);
    }

    #[test]
    fn test_summary() {
        let tl = EventTimeline::new("tl-1", "cap-1");
        let summary = tl.summary();
        assert_eq!(summary.timeline_id, "tl-1");
        assert_eq!(summary.entry_count, 0);
    }
}
