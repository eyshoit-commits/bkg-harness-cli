//! GraphEventBus — the event transport layer.
//!
//! The `GraphEventBus` trait decouples event sources (engines, rehydrators,
//! repairers) from consumers (persistence, UI, audit). The default
//! implementation uses `tokio::sync::broadcast` for fan-out delivery.
//!
//! # Pattern
//!
//! ```rust,ignore
//! let bus = TokioGraphEventBus::new(4096);
//! let mut rx = bus.subscribe();
//!
//! // Publisher
//! bus.publish(event).await.unwrap();
//!
//! // Consumer
//! while let Ok(event) = rx.recv().await {
//!     handle_event(&event);
//! }
//! ```

use async_trait::async_trait;
use tokio::sync::broadcast;

use super::event::GraphEvent;

/// Event bus for graph events.
///
/// Any number of publishers can emit events. Any number of subscribers can
/// receive them. The bus is a fan-out channel — every subscriber receives
/// every event.
#[async_trait]
pub trait GraphEventBus: Send + Sync {
    /// Publish an event to all subscribers.
    async fn publish(&self, event: GraphEvent) -> Result<(), String>;

    /// Subscribe to all future events.
    fn subscribe(&self) -> broadcast::Receiver<GraphEvent>;

    /// Maximum number of events the bus can buffer.
    fn capacity(&self) -> usize;
}

/// Concrete implementation using `tokio::sync::broadcast`.
///
/// Default capacity is 4096 events. If the buffer is full, the oldest events
/// are dropped (lagging subscribers miss them). This is acceptable for the
/// TUI — the `DagUiState` is a snapshot reducer that doesn't need every event.
pub struct TokioGraphEventBus {
    tx: broadcast::Sender<GraphEvent>,
    capacity: usize,
}

impl TokioGraphEventBus {
    /// Create a new event bus with the given capacity.
    ///
    /// `capacity` controls how many events are buffered for slow subscribers.
    /// A value of 4096 covers ~30 seconds of high-throughput operation.
    pub fn new(capacity: usize) -> Self {
        let (tx, _) = broadcast::channel(capacity);
        Self { tx, capacity }
    }
}

impl Default for TokioGraphEventBus {
    fn default() -> Self {
        Self::new(4096)
    }
}

#[async_trait]
impl GraphEventBus for TokioGraphEventBus {
    async fn publish(&self, event: GraphEvent) -> Result<(), String> {
        self.tx
            .send(event)
            .map(|_| ())
            .map_err(|e| format!("bus publish failed: {}", e))
    }

    fn subscribe(&self) -> broadcast::Receiver<GraphEvent> {
        self.tx.subscribe()
    }

    fn capacity(&self) -> usize {
        self.capacity
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::event::{GraphEventKind, GraphSeverity};

    #[tokio::test]
    async fn test_publish_subscribe() {
        let bus = TokioGraphEventBus::new(16);
        let mut rx = bus.subscribe();

        let event = GraphEvent::new("cap-test", GraphEventKind::NodeAdded, GraphSeverity::Info);
        bus.publish(event.clone()).await.unwrap();

        let received = rx.recv().await.unwrap();
        assert_eq!(received.event_id, event.event_id);
        assert_eq!(received.kind, GraphEventKind::NodeAdded);
    }

    #[tokio::test]
    async fn test_multiple_subscribers() {
        let bus = TokioGraphEventBus::new(16);
        let mut rx1 = bus.subscribe();
        let mut rx2 = bus.subscribe();

        let event = GraphEvent::new("cap-test", GraphEventKind::EdgeAdded, GraphSeverity::Info);
        bus.publish(event).await.unwrap();

        let e1 = rx1.recv().await.unwrap();
        let e2 = rx2.recv().await.unwrap();
        assert_eq!(e1.event_id, e2.event_id);
    }

    #[test]
    fn test_capacity() {
        let bus = TokioGraphEventBus::new(128);
        assert_eq!(bus.capacity(), 128);
    }
}
