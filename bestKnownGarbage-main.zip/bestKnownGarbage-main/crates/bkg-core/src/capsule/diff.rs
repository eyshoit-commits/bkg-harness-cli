//! Drift detection and graph diff utilities.
//!
//! This module provides the low-level comparison functions used by the
//! `CapsuleRepairEngine` to detect drift between expected and actual
//! graph state. It also provides `GraphDiff` for general before/after
//! comparison of graph snapshots.

use super::event::GraphSeverity;
use super::graph::CapsuleGraph;
use super::node::{CapsuleNode, NodeId};

/// A single drift finding — one discrepancy between expected and actual state.
///
/// Collected by `CapsuleRepairEngine::detect_drift()` and used to drive
/// repair actions. The `severity` field determines repair priority.
#[derive(Debug, Clone)]
pub struct DriftFinding {
    pub target_id: String,
    pub target_kind: String,
    pub expected_hash: String,
    pub actual_hash: String,
    pub severity: GraphSeverity,
    pub reason: String,
}

impl DriftFinding {
    pub fn new(
        target_id: impl Into<String>,
        target_kind: impl Into<String>,
        expected_hash: impl Into<String>,
        actual_hash: impl Into<String>,
        severity: GraphSeverity,
        reason: impl Into<String>,
    ) -> Self {
        Self {
            target_id: target_id.into(),
            target_kind: target_kind.into(),
            expected_hash: expected_hash.into(),
            actual_hash: actual_hash.into(),
            severity,
            reason: reason.into(),
        }
    }
}

/// The result of comparing two graph snapshots.
#[derive(Debug, Clone)]
pub struct GraphDiff {
    pub added: Vec<CapsuleNode>,
    pub removed: Vec<String>,
    pub modified: Vec<NodeDiff>,
}

/// A single field-level difference between two versions of the same node.
#[derive(Debug, Clone)]
pub struct NodeDiff {
    pub node_id: NodeId,
    pub field: String,
    pub old_value: String,
    pub new_value: String,
}

/// Compare two graph snapshots and return the differences.
///
/// Useful for before/after analysis after repair or replay operations.
pub fn diff_graphs(before: &CapsuleGraph, after: &CapsuleGraph) -> GraphDiff {
    let mut added = Vec::new();
    let mut removed = Vec::new();
    let mut modified = Vec::new();

    for (id, node) in &after.nodes {
        match before.nodes.get(id) {
            None => added.push(node.clone()),
            Some(old) => {
                if old.hash != node.hash {
                    modified.push(NodeDiff {
                        node_id: id.clone(),
                        field: "hash".to_string(),
                        old_value: old.hash.clone(),
                        new_value: node.hash.clone(),
                    });
                }
                if old.status != node.status {
                    modified.push(NodeDiff {
                        node_id: id.clone(),
                        field: "status".to_string(),
                        old_value: format!("{:?}", old.status),
                        new_value: format!("{:?}", node.status),
                    });
                }
            }
        }
    }

    for id in before.nodes.keys() {
        if !after.nodes.contains_key(id) {
            removed.push(id.clone());
        }
    }

    GraphDiff {
        added,
        removed,
        modified,
    }
}

/// Check a single node for drift against its expected hash.
///
/// Returns `Some(DriftFinding)` if the node's hash doesn't match the expected
/// value, or `None` if the node is consistent.
pub fn check_node_drift(node: &CapsuleNode, expected_hash: &str) -> Option<DriftFinding> {
    if node.hash == expected_hash {
        return None;
    }
    Some(DriftFinding::new(
        &node.id,
        format!("{:?}", node.kind),
        expected_hash,
        &node.hash,
        GraphSeverity::Warn,
        "node hash mismatch — content may have changed",
    ))
}

/// Check a graph's node/edge counts against expected values.
///
/// Returns `Some(DriftFinding)` with `Critical` severity if counts don't match.
pub fn check_count_drift(
    capsule_id: &str,
    expected_nodes: usize,
    actual_nodes: usize,
    expected_edges: usize,
    actual_edges: usize,
    root_hash: &str,
    computed_hash: &str,
) -> Option<DriftFinding> {
    if expected_nodes == actual_nodes && expected_edges == actual_edges {
        return None;
    }
    Some(DriftFinding::new(
        capsule_id,
        "CapsuleManifest",
        root_hash,
        computed_hash,
        GraphSeverity::Critical,
        format!(
            "node count mismatch: expected {expected_nodes}, got {actual_nodes}; \
             edge count mismatch: expected {expected_edges}, got {actual_edges}"
        ),
    ))
}
