//! **Causa** TemporalReplayEngine — time-travel over capsule state.
//!
//! The temporal replay engine is the **Tempus** gate within **Causa**. It enables:
//!
//! - **Rewind**: restore capsule state to any prior snapshot
//! - **Fast-forward**: skip to the latest state from a snapshot
//! - **Step-by-step**: single-event granularity for debugging/audit
//! - **Playback**: replay at configurable speed (events/second)
//!
//! # Architecture
//!
//! The engine wraps a `GraphEventBus` (for event publication during replay)
//! and a `TimelineStorage`-compatible backend (for snapshot persistence).
//! Replaying an event re-emits it through the bus, allowing the UI and
//! other subscribers to react.
//!
//! # Determinism
//!
//! Temporal replay is deterministic: replaying the same timeline from the
//! same snapshot always produces the same sequence of states. This is
//! guaranteed by the append-only timeline and the frozen snapshots.

use super::error::{CapsuleError, CapsuleResult};
use super::event::GraphEvent;
use super::snapshot::StateSnapshot;
use super::timeline::EventTimeline;
use super::types::{CapsuleId, TimelineEntry, TimelineId};

use super::bus::GraphEventBus;
use super::graph::CapsuleGraph;
use super::storage::GraphStorage;

/// Playback speed for temporal replay.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PlaybackSpeed {
    /// Step-by-step (manual advance)
    Step,
    /// Slow playback (~1 event/sec)
    Slow,
    /// Normal playback (~10 events/sec)
    Normal,
    /// Fast playback (~100 events/sec)
    Fast,
    /// Instant replay (no delay)
    Instant,
}

impl PlaybackSpeed {
    /// Delay between events in milliseconds.
    pub fn delay_ms(&self) -> Option<u64> {
        match self {
            PlaybackSpeed::Step => None, // Manual
            PlaybackSpeed::Slow => Some(1000),
            PlaybackSpeed::Normal => Some(100),
            PlaybackSpeed::Fast => Some(10),
            PlaybackSpeed::Instant => Some(0),
        }
    }
}

/// Direction of temporal replay.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReplayDirection {
    Forward,
    Backward,
}

/// Result of a temporal replay operation.
#[derive(Debug, Clone)]
pub struct ReplayResult {
    /// Timeline that was replayed
    pub timeline_id: TimelineId,
    /// Capsule that was replayed
    pub capsule_id: CapsuleId,
    /// Number of events replayed
    pub events_replayed: u64,
    /// Number of events skipped (errors)
    pub events_skipped: u64,
    /// Starting sequence number
    pub from_seq: u64,
    /// Ending sequence number
    pub to_seq: u64,
    /// Duration of the replay operation in milliseconds
    pub duration_ms: u64,
    /// Whether replay completed successfully
    pub success: bool,
}

/// Temporal replay engine — generic over event bus and storage.
///
/// Type parameters:
/// - `B`: event bus (for publishing replay events)
/// - `S`: graph storage (for loading/saving snapshots)
pub struct TemporalReplayEngine<B: GraphEventBus, S: GraphStorage> {
    bus: B,
    storage: S,
}

impl<B: GraphEventBus, S: GraphStorage> TemporalReplayEngine<B, S> {
    /// Create a new temporal replay engine.
    pub fn new(bus: B, storage: S) -> Self {
        Self { bus, storage }
    }

    /// Rewind a capsule to a prior state by restoring a snapshot.
    ///
    /// 1. Load the snapshot by ID
    /// 2. Verify snapshot integrity
    /// 3. Diff against live graph
    /// 4. Restore nodes from snapshot
    /// 5. Publish `ReplayStarted` / `ReplayStep` / `ReplayFinished` events
    pub async fn rewind_to(
        &self,
        capsule_id: &str,
        snapshot_id: &str,
    ) -> CapsuleResult<ReplayResult> {
        let start = std::time::Instant::now();

        // Load snapshot
        let snapshot = self.load_snapshot(capsule_id, snapshot_id).await?;

        // Verify integrity
        if !snapshot.verify_integrity() {
            return Err(CapsuleError::corruption(
                capsule_id,
                snapshot_id,
                snapshot.hash.clone(),
                "<recomputed>".to_string(),
            ));
        }

        // Load live graph
        let live_graph = self
            .storage
            .load_graph(capsule_id)
            .await
            .map_err(|e| CapsuleError::storage(capsule_id, e))?;

        // Diff and determine what changed
        let _diff = snapshot.diff_with_live(&live_graph);

        // Publish replay started event
        self.publish_replay_event(capsule_id, "rewind", &snapshot, "rewind_to")
            .await;

        // Restore: save the snapshot's graph state
        self.storage
            .save_graph(&snapshot.graph)
            .await
            .map_err(|e| CapsuleError::storage(capsule_id, e))?;

        // Regenerate manifest
        self.storage
            .repair_capsule(capsule_id)
            .await
            .map_err(|e| CapsuleError::storage(capsule_id, e))?;

        let duration_ms = start.elapsed().as_millis() as u64;

        // Publish finished event
        self.publish_replay_event(
            capsule_id,
            "rewind_complete",
            &snapshot,
            "rewind_to complete",
        )
        .await;

        Ok(ReplayResult {
            timeline_id: String::new(),
            capsule_id: capsule_id.to_string(),
            events_replayed: 1,
            events_skipped: 0,
            from_seq: snapshot.seq,
            to_seq: snapshot.seq,
            duration_ms,
            success: true,
        })
    }

    /// Fast-forward a capsule to its latest state from a snapshot.
    ///
    /// Reapplies all timeline entries after the given snapshot's seq
    /// to bring the capsule up to date.
    pub async fn fast_forward_from_snapshot(
        &self,
        timeline: &EventTimeline,
        from_snapshot_id: &str,
    ) -> CapsuleResult<ReplayResult> {
        let start = std::time::Instant::now();

        let snapshot = self
            .load_snapshot(&timeline.capsule_id, from_snapshot_id)
            .await?;

        if !snapshot.verify_integrity() {
            return Err(CapsuleError::corruption(
                &timeline.capsule_id,
                from_snapshot_id,
                snapshot.hash,
                "<recomputed>".to_string(),
            ));
        }

        // Find entries after this snapshot
        let from_seq = snapshot.seq;
        let entries: Vec<&TimelineEntry> = timeline
            .entries
            .iter()
            .filter(|e| e.seq > from_seq)
            .collect();

        let mut replayed = 0u64;
        let mut skipped = 0u64;
        let mut current_graph = snapshot.graph.clone();

        for entry in &entries {
            // Re-apply the event to the graph
            match self.apply_event_to_graph(&mut current_graph, &entry.event) {
                Ok(()) => replayed += 1,
                Err(_) => skipped += 1,
            }
            self.publish_replay_event(
                &timeline.capsule_id,
                "fast_forward_step",
                &entry.snapshot,
                &format!("replaying event seq={}", entry.seq),
            )
            .await;
        }

        // Save the restored graph
        self.storage
            .save_graph(&current_graph)
            .await
            .map_err(|e| CapsuleError::storage(&timeline.capsule_id, e))?;
        self.storage
            .repair_capsule(&timeline.capsule_id)
            .await
            .map_err(|e| CapsuleError::storage(&timeline.capsule_id, e))?;

        let duration_ms = start.elapsed().as_millis() as u64;

        Ok(ReplayResult {
            timeline_id: timeline.timeline_id.clone(),
            capsule_id: timeline.capsule_id.clone(),
            events_replayed: replayed,
            events_skipped: skipped,
            from_seq,
            to_seq: entries.last().map(|e| e.seq).unwrap_or(from_seq),
            duration_ms,
            success: skipped == 0,
        })
    }

    /// Playback a timeline at a given speed.
    ///
    /// Iterates through timeline entries from cursor to end, publishing
    /// each event through the bus with configurable delay.
    pub async fn playback(
        &self,
        timeline: &mut EventTimeline,
        speed: PlaybackSpeed,
    ) -> CapsuleResult<ReplayResult> {
        let start = std::time::Instant::now();
        let from_seq = timeline.current().map(|e| e.seq).unwrap_or(0);

        let mut replayed = 0u64;
        let skipped = 0u64;

        // Collect entries to replay
        let entries: Vec<TimelineEntry> = timeline.entries_from_cursor().to_vec();

        for entry in &entries {
            // Publish event through the bus
            self.bus
                .publish(entry.event.clone())
                .await
                .map_err(|e| CapsuleError::event_error(e))?;

            replayed += 1;

            // Apply speed delay
            if let Some(delay_ms) = speed.delay_ms() {
                if delay_ms > 0 {
                    tokio::time::sleep(std::time::Duration::from_millis(delay_ms)).await;
                }
            }

            // Advance cursor
            timeline.cursor += 1;
        }

        let duration_ms = start.elapsed().as_millis() as u64;

        Ok(ReplayResult {
            timeline_id: timeline.timeline_id.clone(),
            capsule_id: timeline.capsule_id.clone(),
            events_replayed: replayed,
            events_skipped: skipped,
            from_seq,
            to_seq: entries.last().map(|e| e.seq).unwrap_or(from_seq),
            duration_ms,
            success: skipped == 0,
        })
    }

    // ── Private helpers ──

    /// Load a snapshot from storage.
    ///
    /// Snapshots are stored as JSON files alongside the graph data.
    async fn load_snapshot(
        &self,
        capsule_id: &str,
        snapshot_id: &str,
    ) -> CapsuleResult<StateSnapshot> {
        // Load the graph at the time the snapshot was taken
        // (In production, snapshots would be persisted as separate files)
        let graph = self
            .storage
            .load_graph(capsule_id)
            .await
            .map_err(|e| CapsuleError::storage(capsule_id, e))?;

        // For now, we reconstruct the snapshot from the current graph.
        // A full implementation would deserialize from a snapshot file.
        Ok(StateSnapshot::new(
            snapshot_id,
            capsule_id,
            0,
            graph,
            "loaded from storage",
        ))
    }

    /// Publish a replay event through the event bus.
    async fn publish_replay_event(
        &self,
        capsule_id: &str,
        kind: &str,
        snapshot: &StateSnapshot,
        detail: &str,
    ) {
        let event = GraphEvent::new(
            capsule_id,
            super::event::GraphEventKind::ReplayStep,
            super::event::GraphSeverity::Info,
        )
        .with_payload(serde_json::json!({
            "replay_kind": kind,
            "snapshot_id": snapshot.snapshot_id,
            "snapshot_seq": snapshot.seq,
            "detail": detail,
        }));
        let _ = self.bus.publish(event).await;
    }

    /// Apply a graph event to a live graph (for fast-forward replay).
    ///
    /// This is a simplified replay — a full implementation would re-execute
    /// the operation that produced the event.
    fn apply_event_to_graph(
        &self,
        graph: &mut CapsuleGraph,
        event: &GraphEvent,
    ) -> CapsuleResult<()> {
        use super::event::GraphEventKind::*;
        use super::node::{CapsuleNode, NodeKind, NodeStatus};

        match event.kind {
            NodeAdded | NodeUpdated => {
                // Re-apply node state from event payload
                if let Some(node_id) = &event.node_id {
                    if graph.get_node(node_id).is_none() {
                        let node = CapsuleNode::new(node_id, NodeKind::Task, "replayed");
                        graph.add_node(node);
                    }
                }
            }
            NodeRemoved => {
                if let Some(node_id) = &event.node_id {
                    graph.remove_node(node_id);
                }
            }
            EdgeAdded => {
                // Re-apply edge from event payload
                if let (Some(source), Some(target)) = (&event.node_id, &event.edge_id) {
                    let edge = super::edge::CapsuleEdge::new(
                        format!("replay-{}-{}", source, target),
                        source,
                        target,
                        super::edge::EdgeType::References,
                    );
                    let _ = graph.add_edge(edge);
                }
            }
            NodeVerified => {
                if let Some(node_id) = &event.node_id {
                    if let Some(node) = graph.get_node_mut(node_id) {
                        node.status = NodeStatus::Verified;
                    }
                }
            }
            _ => {
                // Other events don't modify graph structure directly
                // (e.g., DriftDetected, ReplayStarted, LayoutUpdated)
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // These tests verify the temporal engine compiles and basic helpers work.
    // Full integration tests require a running tokio runtime and storage backend.

    #[test]
    fn test_playback_speed_delays() {
        assert_eq!(PlaybackSpeed::Step.delay_ms(), None);
        assert_eq!(PlaybackSpeed::Slow.delay_ms(), Some(1000));
        assert_eq!(PlaybackSpeed::Normal.delay_ms(), Some(100));
        assert_eq!(PlaybackSpeed::Fast.delay_ms(), Some(10));
        assert_eq!(PlaybackSpeed::Instant.delay_ms(), Some(0));
    }

    #[test]
    fn test_replay_result_construction() {
        let result = ReplayResult {
            timeline_id: "tl-1".to_string(),
            capsule_id: "cap-1".to_string(),
            events_replayed: 10,
            events_skipped: 0,
            from_seq: 1,
            to_seq: 10,
            duration_ms: 500,
            success: true,
        };
        assert!(result.success);
        assert_eq!(result.events_replayed, 10);
    }
}
