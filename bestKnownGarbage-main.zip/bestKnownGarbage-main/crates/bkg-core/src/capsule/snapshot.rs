//! **Causa** StateSnapshot — frozen copy of capsule state for temporal replay.
//!
//! A `StateSnapshot` captures the complete state of a `CapsuleGraph` at a
//! point in time. Snapshots are the atomic units of temporal replay — the
//! replay engine moves between snapshots to rewind, fast-forward, and step
//! through capsule history.
//!
//! # Design
//!
//! - Each snapshot is a full copy (not a delta) — this is the simplest and
//!   most reliable model for a deterministic replay system.
//! - Snapshots carry their own hash computed from the serialized graph state.
//! - A snapshot can be diffed against the live graph to detect divergence
//!   between replayed and current state.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use super::graph::CapsuleGraph;

/// Unique snapshot identifier.
pub type SnapshotId = String;

/// A frozen copy of capsule graph state at a specific point in time.
///
/// # Integrity
///
/// Every snapshot carries a `hash` computed from the serialized graph + metadata.
/// This enables verification that no tampering occurred between capture and replay.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateSnapshot {
    /// Unique snapshot identifier
    pub snapshot_id: SnapshotId,
    /// The capsule this snapshot belongs to
    pub capsule_id: String,
    /// Sequence number (monotonic within a timeline)
    pub seq: u64,
    /// Wall-clock time when the snapshot was taken
    pub captured_at: DateTime<Utc>,
    /// The frozen graph state
    pub graph: CapsuleGraph,
    /// Cryptographic hash of this snapshot (for integrity verification)
    pub hash: String,
    /// Reason this snapshot was taken (e.g., "node_added", "repair", "replay_step")
    pub reason: String,
}

impl StateSnapshot {
    /// Create a new snapshot from a capsule graph.
    ///
    /// Automatically computes the integrity hash.
    pub fn new(
        snapshot_id: impl Into<String>,
        capsule_id: impl Into<String>,
        seq: u64,
        graph: CapsuleGraph,
        reason: impl Into<String>,
    ) -> Self {
        let mut snap = Self {
            snapshot_id: snapshot_id.into(),
            capsule_id: capsule_id.into(),
            seq,
            captured_at: Utc::now(),
            graph,
            hash: String::new(),
            reason: reason.into(),
        };
        snap.hash = snap.compute_hash();
        snap
    }

    /// Compute the cryptographic hash of this snapshot.
    ///
    /// The hash covers the graph hash (which itself excludes temporal fields
    /// like `created_at`/`updated_at`), plus capsule_id, seq, and reason.
    /// This guarantees determinism: identical states → identical hashes.
    ///
    /// ## Determinism
    ///
    /// Two snapshots with the same graph, capsule_id, seq, and reason will
    /// ALWAYS produce the same hash, regardless of when they were created.
    fn compute_hash(&self) -> String {
        let mut hasher = Sha256::new();

        // Use CapsuleGraph::compute_hash() — it does canonical serialization
        // and excludes temporal fields that would break determinism.
        hasher.update(self.graph.compute_hash().as_bytes());

        // Hash metadata — no timestamps (breaks determinism)
        hasher.update(self.capsule_id.as_bytes());
        hasher.update(self.seq.to_le_bytes());
        hasher.update(self.reason.as_bytes());

        format!("{:x}", hasher.finalize())
    }

    /// Verify this snapshot's integrity by recomputing its hash.
    ///
    /// Returns `true` if the recomputed hash matches the stored hash.
    pub fn verify_integrity(&self) -> bool {
        let recomputed = self.compute_hash();
        self.hash == recomputed
    }

    /// Diff this snapshot's graph against a live graph.
    ///
    /// Returns the set of differences between the frozen snapshot state
    /// and the current (live) graph state.
    pub fn diff_with_live(&self, live_graph: &CapsuleGraph) -> super::diff::GraphDiff {
        super::diff::diff_graphs(&self.graph, live_graph)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::graph::CapsuleGraph;
    use crate::capsule::node::{CapsuleNode, NodeKind};

    fn make_graph() -> CapsuleGraph {
        let mut g = CapsuleGraph::new("cap-snap-test");
        g.add_node(CapsuleNode::new("n1", NodeKind::Task, "Node 1"));
        g.add_node(CapsuleNode::new("n2", NodeKind::Execution, "Node 2"));
        g
    }

    #[test]
    fn test_snapshot_creation() {
        let graph = make_graph();
        let snap = StateSnapshot::new("snap-1", "cap-snap-test", 0, graph, "initial");

        assert_eq!(snap.snapshot_id, "snap-1");
        assert_eq!(snap.seq, 0);
        assert_eq!(snap.graph.node_count(), 2);
        assert!(!snap.hash.is_empty());
    }

    #[test]
    fn test_snapshot_integrity() {
        let graph = make_graph();
        let snap = StateSnapshot::new("snap-2", "cap-snap-test", 1, graph, "test");

        assert!(snap.verify_integrity());
    }

    #[test]
    fn test_snapshot_detects_tampering() {
        let graph = make_graph();
        let mut snap = StateSnapshot::new("snap-3", "cap-snap-test", 2, graph, "initial");

        // Tamper with the snapshot
        snap.reason = "tampered".to_string();
        assert!(!snap.verify_integrity());
    }

    #[test]
    fn test_snapshot_diff_no_changes() {
        let graph = make_graph();
        let snap = StateSnapshot::new("snap-diff", "cap-snap-test", 0, graph.clone(), "initial");

        let diff = snap.diff_with_live(&graph);
        assert!(diff.added.is_empty());
        assert!(diff.removed.is_empty());
    }

    #[test]
    fn test_snapshot_diff_detects_changes() {
        let graph = make_graph();
        let snap = StateSnapshot::new("snap-diff2", "cap-snap-test", 0, graph, "initial");

        let mut live = make_graph();
        live.add_node(CapsuleNode::new("n3", NodeKind::Receipt, "Node 3"));

        let diff = snap.diff_with_live(&live);
        assert_eq!(diff.added.len(), 1);
        assert_eq!(diff.added[0].id, "n3");
    }

    #[test]
    fn test_same_input_produces_same_hash() {
        let g1 = make_graph();
        let g2 = make_graph();

        let snap1 = StateSnapshot::new("s1", "c", 0, g1, "reason");
        let snap2 = StateSnapshot::new("s1", "c", 0, g2, "reason");

        assert_eq!(snap1.hash, snap2.hash, "same inputs must produce same hash");
    }
}
