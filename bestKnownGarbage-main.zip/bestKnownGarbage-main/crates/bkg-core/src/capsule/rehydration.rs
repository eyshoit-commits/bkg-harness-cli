//! **CapsuleEngine** — boot-time capsule rehydration and integrity scanning.
//!
//! This is the rehydration entry point called during Bootstrap Phase 2.
//! It scans capsule directories, verifies manifests, checks MEMORY.md and
//! receipts, and returns the aggregate capsule state.
//!
//! Self-healing strategies are in the sibling `self_heal` module.

use std::path::{Path, PathBuf};

use crate::bootstrap::CapsuleState;

/// Engine for scanning and rehydrating capsules at boot time.
pub struct CapsuleEngine {
    pub capsules_dir: PathBuf,
}

impl CapsuleEngine {
    /// Create a new CapsuleEngine pointing at `~/.bkg/capsules/`.
    pub fn new() -> Self {
        let capsules_dir = dirs::home_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join(".bkg")
            .join("capsules");
        Self { capsules_dir }
    }

    /// Create a CapsuleEngine with an explicit capsules directory.
    pub fn with_dir(path: PathBuf) -> Self {
        Self { capsules_dir: path }
    }

    /// Scan all capsule directories and determine overall capsule state.
    ///
    /// Returns:
    /// - `CapsuleState::Missing` — no capsule directory or empty
    /// - `CapsuleState::Healthy` — all capsules pass integrity checks
    /// - `CapsuleState::Degraded` — some capsules have issues
    pub async fn scan_and_rehydrate(&self) -> CapsuleState {
        if !self.capsules_dir.exists() {
            return CapsuleState::Missing;
        }

        let mut issues: Vec<String> = Vec::new();
        let mut read_dir = match tokio::fs::read_dir(&self.capsules_dir).await {
            Ok(d) => d,
            Err(_) => return CapsuleState::Missing,
        };

        let mut found_any = false;
        loop {
            let entry = match read_dir.next_entry().await {
                Ok(Some(e)) => e,
                Ok(None) => break,
                Err(_) => continue,
            };

            let ft = match entry.file_type().await {
                Ok(t) => t,
                Err(_) => continue,
            };

            if !ft.is_dir() {
                continue;
            }

            found_any = true;
            let cap_path = entry.path();

            // Verify manifest.json
            match Self::verify_manifest(&cap_path) {
                Ok(true) => { /* healthy */ }
                Ok(false) => issues.push(format!("Invalid manifest: {}", cap_path.display())),
                Err(e) => issues.push(format!("Manifest error ({}): {}", cap_path.display(), e)),
            }

            // Check MEMORY.md
            let memory = cap_path.join("MEMORY.md");
            if !memory.exists() {
                issues.push(format!("Missing MEMORY.md: {}", cap_path.display()));
            }

            // Check receipts/
            let receipts = cap_path.join("receipts");
            if !receipts.exists() {
                issues.push(format!("Missing receipts/: {}", cap_path.display()));
            }
        }

        if !found_any {
            return CapsuleState::Missing;
        }

        if issues.is_empty() {
            CapsuleState::Healthy
        } else {
            CapsuleState::Degraded { issues }
        }
    }

    /// Verify that a capsule has a valid `manifest.json`.
    ///
    /// Returns `Ok(true)` if the manifest exists and is valid JSON,
    /// `Ok(false)` if it is missing or malformed, `Err` on I/O errors.
    pub fn verify_manifest(path: &Path) -> Result<bool, String> {
        let manifest = path.join("manifest.json");
        if !manifest.exists() {
            return Ok(false);
        }
        let content = std::fs::read_to_string(&manifest).map_err(|e| format!("read error: {e}"))?;
        match serde_json::from_str::<serde_json::Value>(&content) {
            Ok(v) => Ok(v.is_object()),
            Err(_) => Ok(false),
        }
    }

    /// Rebuild the SQLite index from `MEMORY.md` (stub for now).
    pub fn rebuild_index(memory_path: &Path) -> Result<(), String> {
        if !memory_path.exists() {
            return Err("MEMORY.md not found".to_string());
        }
        // TODO: full SQLite index rebuild when we add SQLite support
        Ok(())
    }

    /// Repair a missing snapshot from a receipt + diff chain (stub).
    pub fn repair_snapshot(receipt_path: &Path) -> Result<(), String> {
        if !receipt_path.exists() {
            return Err("Receipt not found".to_string());
        }
        // TODO: full repair from receipt + diff chain
        Ok(())
    }
}

impl Default for CapsuleEngine {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    fn tmp_capsule_dir() -> PathBuf {
        let dir = std::env::temp_dir()
            .join("bkg_test_capsule_")
            .join(uuid::Uuid::new_v4().to_string());
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[tokio::test]
    async fn test_missing_dir_returns_missing() {
        let engine = CapsuleEngine::with_dir(PathBuf::from("/nonexistent/bkg/capsules"));
        assert_eq!(engine.scan_and_rehydrate().await, CapsuleState::Missing);
    }

    #[tokio::test]
    async fn test_empty_dir_returns_missing() {
        let dir = tmp_capsule_dir();
        let engine = CapsuleEngine::with_dir(dir.clone());
        assert_eq!(engine.scan_and_rehydrate().await, CapsuleState::Missing);
        let _ = fs::remove_dir_all(&dir);
    }

    #[tokio::test]
    async fn test_healthy_capsule() {
        let dir = tmp_capsule_dir();
        let capsule = dir.join("default");
        fs::create_dir_all(capsule.join("receipts")).unwrap();

        // Valid manifest
        let manifest = capsule.join("manifest.json");
        fs::write(&manifest, r#"{"version":1,"name":"default"}"#).unwrap();

        // MEMORY.md
        fs::write(capsule.join("MEMORY.md"), "# Memory").unwrap();

        let engine = CapsuleEngine::with_dir(dir.clone());
        assert_eq!(engine.scan_and_rehydrate().await, CapsuleState::Healthy);

        let _ = fs::remove_dir_all(&dir);
    }

    #[tokio::test]
    async fn test_degraded_capsule() {
        let dir = tmp_capsule_dir();
        let capsule = dir.join("default");
        fs::create_dir_all(&capsule).unwrap();

        // Corrupt manifest
        fs::write(capsule.join("manifest.json"), "not-json").unwrap();

        // No MEMORY.md, no receipts
        let engine = CapsuleEngine::with_dir(dir.clone());
        let state = engine.scan_and_rehydrate().await;
        assert!(matches!(state, CapsuleState::Degraded { .. }));

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_verify_manifest_valid() {
        let dir = tmp_capsule_dir();
        let manifest = dir.join("manifest.json");
        fs::write(&manifest, r#"{"key":"value"}"#).unwrap();

        assert_eq!(CapsuleEngine::verify_manifest(&dir).unwrap(), true);
        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_verify_manifest_missing() {
        let dir = tmp_capsule_dir();
        assert_eq!(CapsuleEngine::verify_manifest(&dir).unwrap(), false);
    }

    #[test]
    fn test_verify_manifest_corrupt() {
        let dir = tmp_capsule_dir();
        fs::write(dir.join("manifest.json"), "{{{broken").unwrap();
        assert_eq!(CapsuleEngine::verify_manifest(&dir).unwrap(), false);
        let _ = fs::remove_dir_all(&dir);
    }
}
