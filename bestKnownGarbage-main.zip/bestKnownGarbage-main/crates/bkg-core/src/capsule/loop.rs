//! **Causa** SelfHealingLoop — continuous self-healing orchestration.
//!
//! The self-healing loop is the "Evolution" kernel's runtime. It runs
//! continuous healing cycles on a set of tracked capsules, managing:
//!
//! - **Tick rate**: how often to scan for drift
//! - **Training mode**: learn normal behavior before healing
//! - **Trigger conditions**: what initiates a healing cycle
//! - **Heal execution**: delegate to `HealingEngine`
//! - **State transitions**: update capsule status through lifecycle
//!
//! # States
//!
//! ```text
//! Idle → Training → Monitoring → Healing → Verifying → Idle
//!                                      ↓
//!                                   Escalated (manual review)
//! ```

use chrono::{DateTime, Utc};
use std::collections::HashMap;

use super::healing::{HealingCycleResult, HealingEngine};
use super::repair::CapsuleRepairEngine;
use super::storage::GraphStorage;
use super::types::{CapsuleId, CapsuleStatus};

/// State of the self-healing loop.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealingLoopState {
    /// Loop is idle (not monitoring any capsules)
    Idle,
    /// Loop is training (learning baseline behavior)
    Training,
    /// Loop is monitoring for drift
    Monitoring,
    /// Loop is actively healing a capsule
    Healing,
    /// Loop is verifying a completed repair
    Verifying,
    /// Loop has escalated to manual review
    Escalated,
}

impl std::fmt::Display for HealingLoopState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            HealingLoopState::Idle => write!(f, "idle"),
            HealingLoopState::Training => write!(f, "training"),
            HealingLoopState::Monitoring => write!(f, "monitoring"),
            HealingLoopState::Healing => write!(f, "healing"),
            HealingLoopState::Verifying => write!(f, "verifying"),
            HealingLoopState::Escalated => write!(f, "escalated"),
        }
    }
}

/// Tracked capsule — a capsule being monitored by the self-healing loop.
#[derive(Debug, Clone)]
pub struct TrackedCapsule {
    /// Capsule identifier
    pub capsule_id: CapsuleId,
    /// Current status
    pub status: CapsuleStatus,
    /// Last healing cycle result
    pub last_heal_result: Option<HealingCycleResult>,
    /// Number of consecutive failed healing cycles
    pub consecutive_failures: u32,
    /// Whether this capsule is being monitored
    pub monitoring: bool,
    /// Last scan timestamp
    pub last_scan: Option<DateTime<Utc>>,
}

/// Configuration for the self-healing loop.
#[derive(Debug, Clone)]
pub struct HealingLoopConfig {
    /// Interval between drift scans in seconds
    pub scan_interval_secs: u64,
    /// Maximum number of capsules to scan per tick
    pub max_scan_per_tick: usize,
    /// Training duration in seconds
    pub training_duration_secs: u64,
    /// Number of consecutive failures before escalation
    pub max_consecutive_failures: u32,
    /// Whether to publish events during loop operations
    pub publish_events: bool,
}

impl Default for HealingLoopConfig {
    fn default() -> Self {
        Self {
            scan_interval_secs: 30,
            max_scan_per_tick: 5,
            training_duration_secs: 60,
            max_consecutive_failures: 3,
            publish_events: true,
        }
    }
}

/// The self-healing loop — continuous healing orchestration.
///
/// Generic over:
/// - `S`: graph storage backend
/// - `E`: repair engine
pub struct SelfHealingLoop<S: GraphStorage, E: CapsuleRepairEngine> {
    /// The healing engine (detect → plan → execute → converge)
    pub engine: HealingEngine<S, E>,
    /// Loop configuration
    pub config: HealingLoopConfig,
    /// Current loop state
    pub state: HealingLoopState,
    /// Tracked capsules
    pub tracked: HashMap<CapsuleId, TrackedCapsule>,
    /// Capsules currently being healed
    pub healing_queue: Vec<CapsuleId>,
    /// Total ticks executed
    pub ticks: u64,
    /// Total healing cycles completed
    pub cycles_completed: u64,
    /// Total healing cycles that failed
    pub cycles_failed: u64,
    /// When training started (if in training state)
    pub training_started: Option<DateTime<Utc>>,
    /// Last tick timestamp
    pub last_tick: Option<DateTime<Utc>>,
}

impl<S: GraphStorage, E: CapsuleRepairEngine> SelfHealingLoop<S, E> {
    /// Create a new self-healing loop.
    pub fn new(engine: HealingEngine<S, E>, config: HealingLoopConfig) -> Self {
        Self {
            engine,
            config,
            state: HealingLoopState::Idle,
            tracked: HashMap::new(),
            healing_queue: Vec::new(),
            ticks: 0,
            cycles_completed: 0,
            cycles_failed: 0,
            training_started: None,
            last_tick: None,
        }
    }

    /// Start monitoring a capsule.
    pub fn track_capsule(&mut self, capsule_id: &str, status: CapsuleStatus) {
        self.tracked.insert(
            capsule_id.to_string(),
            TrackedCapsule {
                capsule_id: capsule_id.to_string(),
                status,
                last_heal_result: None,
                consecutive_failures: 0,
                monitoring: true,
                last_scan: None,
            },
        );
    }

    /// Stop monitoring a capsule.
    pub fn untrack_capsule(&mut self, capsule_id: &str) {
        self.tracked.remove(capsule_id);
        self.healing_queue.retain(|id| id != capsule_id);
    }

    /// Start the training phase.
    pub fn start_training(&mut self) {
        self.state = HealingLoopState::Training;
        self.training_started = Some(Utc::now());
    }

    /// Transition to monitoring state.
    pub fn start_monitoring(&mut self) {
        self.state = HealingLoopState::Monitoring;
        self.training_started = None;
    }

    /// Execute a single tick of the self-healing loop.
    ///
    /// Returns a list of healing cycle results for this tick.
    pub async fn tick(&mut self) -> Vec<HealingCycleResult> {
        self.ticks += 1;
        self.last_tick = Some(Utc::now());

        let mut results = Vec::new();

        match self.state {
            HealingLoopState::Training => {
                // Check if training period is over
                if let Some(started) = self.training_started {
                    let elapsed = (Utc::now() - started).num_seconds() as u64;
                    if elapsed >= self.config.training_duration_secs {
                        self.state = HealingLoopState::Monitoring;
                        self.emit_loop_event("training_complete", "training period ended")
                            .await;
                    }
                }
            }

            HealingLoopState::Monitoring => {
                // Process healing queue first
                while let Some(capsule_id) = self.healing_queue.first().cloned() {
                    self.state = HealingLoopState::Healing;
                    let result = self.engine.heal(&capsule_id).await;
                    self.state = HealingLoopState::Monitoring;

                    self.update_tracked_capsule(&capsule_id, &result);
                    results.push(result);
                    self.healing_queue.remove(0);
                }

                // Scan tracked capsules for drift
                let to_scan: Vec<CapsuleId> = self
                    .tracked
                    .values()
                    .filter(|t| t.monitoring)
                    .take(self.config.max_scan_per_tick)
                    .map(|t| t.capsule_id.clone())
                    .collect();

                for capsule_id in to_scan {
                    // Quick scan: check if drift exists (dry-run)
                    if let Ok(findings) =
                        self.engine
                            .guard()
                            .check_invariants(&capsule_id, true, true)
                    {
                        let _ = findings;
                        // Check if guard allows repair
                        let result = self.engine.heal(&capsule_id).await;
                        if !result.converged && result.drift_count > 0 {
                            self.healing_queue.push(capsule_id.clone());
                        }
                        self.update_tracked_capsule(&capsule_id, &result);
                        results.push(result);
                    }
                }
            }

            HealingLoopState::Healing => {
                // Process healing queue
                while let Some(capsule_id) = self.healing_queue.first().cloned() {
                    let result = self.engine.heal(&capsule_id).await;
                    self.update_tracked_capsule(&capsule_id, &result);
                    results.push(result);
                    self.healing_queue.remove(0);
                }
                self.state = HealingLoopState::Verifying;
            }

            HealingLoopState::Verifying => {
                // Check results of last healing cycle
                let mut all_ok = true;
                for tracked in self.tracked.values() {
                    if let Some(ref result) = tracked.last_heal_result {
                        if !result.converged {
                            all_ok = false;
                        }
                    }
                }

                if all_ok {
                    self.state = HealingLoopState::Monitoring;
                } else {
                    // Check if we need to escalate
                    let needs_escalation = self
                        .tracked
                        .values()
                        .any(|t| t.consecutive_failures >= self.config.max_consecutive_failures);

                    if needs_escalation {
                        self.state = HealingLoopState::Escalated;
                        self.emit_loop_event("escalated", "max consecutive failures reached")
                            .await;
                    } else {
                        // Re-queue for another healing attempt
                        for tracked in self.tracked.values() {
                            if let Some(ref result) = tracked.last_heal_result {
                                if !result.converged {
                                    self.healing_queue.push(tracked.capsule_id.clone());
                                }
                            }
                        }
                        self.state = HealingLoopState::Monitoring;
                    }
                }
            }

            HealingLoopState::Idle | HealingLoopState::Escalated => {
                // No-op in idle or escalated states
            }
        }

        results
    }

    /// Manually trigger a healing cycle for a specific capsule.
    pub async fn trigger_heal(&mut self, capsule_id: &str) -> HealingCycleResult {
        let result = self.engine.heal(capsule_id).await;
        self.update_tracked_capsule(capsule_id, &result);
        result
    }

    /// Get the status of a tracked capsule.
    pub fn capsule_status(&self, capsule_id: &str) -> Option<&TrackedCapsule> {
        self.tracked.get(capsule_id)
    }

    /// Get all tracked capsules with issues.
    pub fn unhealthy_capsules(&self) -> Vec<&TrackedCapsule> {
        self.tracked
            .values()
            .filter(|t| t.last_heal_result.as_ref().is_some_and(|r| !r.converged))
            .collect()
    }

    /// Get summary stats for the loop.
    pub fn summary(&self) -> HealingLoopSummary {
        HealingLoopSummary {
            state: self.state,
            tracked_count: self.tracked.len() as u64,
            queue_length: self.healing_queue.len() as u64,
            ticks: self.ticks,
            cycles_completed: self.cycles_completed,
            cycles_failed: self.cycles_failed,
            healing_active: !self.healing_queue.is_empty(),
        }
    }

    // ── Private helpers ──

    fn update_tracked_capsule(&mut self, capsule_id: &str, result: &HealingCycleResult) {
        if let Some(tracked) = self.tracked.get_mut(capsule_id) {
            tracked.last_heal_result = Some(result.clone());
            tracked.last_scan = Some(Utc::now());

            if result.converged {
                tracked.status = CapsuleStatus::Live;
                tracked.consecutive_failures = 0;
                self.cycles_completed += 1;
            } else {
                tracked.consecutive_failures += 1;
                tracked.status = CapsuleStatus::Divergent;
                self.cycles_failed += 1;
            }
        }
    }

    async fn emit_loop_event(&self, kind: &str, detail: &str) {
        if !self.config.publish_events {
            return;
        }
        let _ = kind;
        let _ = detail;
        // In production, this would publish to the event bus
    }
}

/// Summary of the self-healing loop state.
#[derive(Debug, Clone)]
pub struct HealingLoopSummary {
    pub state: HealingLoopState,
    pub tracked_count: u64,
    pub queue_length: u64,
    pub ticks: u64,
    pub cycles_completed: u64,
    pub cycles_failed: u64,
    pub healing_active: bool,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::graph::CapsuleGraph;
    use crate::capsule::guard::HealingGuard;
    use crate::capsule::healing::HealingEngine;
    use crate::capsule::node::{CapsuleNode, NodeKind};
    use crate::capsule::policy::HealingPolicy;
    use crate::capsule::repair::DefaultCapsuleRepairEngine;
    use crate::capsule::storage::FilesystemGraphStorage;
    use std::env::temp_dir;
    use uuid::Uuid;

    fn tmp_dir() -> String {
        let dir = temp_dir().join(format!("bkg-loop-test-{}", Uuid::new_v4()));
        let _ = std::fs::create_dir_all(&dir);
        dir.to_string_lossy().to_string()
    }

    fn make_loop(
        dir: &str,
    ) -> SelfHealingLoop<FilesystemGraphStorage, DefaultCapsuleRepairEngine<FilesystemGraphStorage>>
    {
        let storage = FilesystemGraphStorage::new(dir);
        let repair = DefaultCapsuleRepairEngine::new(FilesystemGraphStorage::new(dir), dir);
        let guard = HealingGuard::new();
        let policy = HealingPolicy::default();
        let engine = HealingEngine::new(storage, repair, guard, policy);
        let config = HealingLoopConfig::default();
        SelfHealingLoop::new(engine, config)
    }

    #[tokio::test]
    async fn test_loop_initial_state() {
        let dir = tmp_dir();
        let loop_ = make_loop(&dir);
        assert_eq!(loop_.state, HealingLoopState::Idle);
        assert_eq!(loop_.ticks, 0);
    }

    #[tokio::test]
    async fn test_track_and_untrack() {
        let dir = tmp_dir();
        let mut loop_ = make_loop(&dir);
        loop_.track_capsule("cap-1", CapsuleStatus::Live);
        assert!(loop_.tracked.contains_key("cap-1"));

        loop_.untrack_capsule("cap-1");
        assert!(!loop_.tracked.contains_key("cap-1"));
    }

    #[tokio::test]
    async fn test_training_phase() {
        let dir = tmp_dir();
        let mut loop_ = make_loop(&dir);
        loop_.start_training();
        assert_eq!(loop_.state, HealingLoopState::Training);
    }

    #[tokio::test]
    async fn test_loop_state_display() {
        assert_eq!(HealingLoopState::Idle.to_string(), "idle");
        assert_eq!(HealingLoopState::Training.to_string(), "training");
        assert_eq!(HealingLoopState::Monitoring.to_string(), "monitoring");
        assert_eq!(HealingLoopState::Healing.to_string(), "healing");
        assert_eq!(HealingLoopState::Verifying.to_string(), "verifying");
        assert_eq!(HealingLoopState::Escalated.to_string(), "escalated");
    }

    #[tokio::test]
    async fn test_summary() {
        let dir = tmp_dir();
        let loop_ = make_loop(&dir);
        let summary = loop_.summary();
        assert_eq!(summary.state, HealingLoopState::Idle);
        assert!(!summary.healing_active);
    }
}
