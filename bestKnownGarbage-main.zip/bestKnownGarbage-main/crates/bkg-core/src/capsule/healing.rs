//! **Causa** HealingEngine — detect, plan, execute, and converge capsule repair.
//!
//! The healing engine is the "hands" of the self-healing system. It:
//!
//! 1. **Detect**: scans for drift using the repair engine's drift detection
//! 2. **Plan**: maps findings to repair actions, filtered by policy
//! 3. **Execute**: applies repair actions through the guard
//! 4. **Converge**: verifies repair succeeded and updates capsule status
//!
//! The healing engine is driven by the `SelfHealingLoop`. It does not
//! manage its own scheduling — that's the loop's responsibility.

use chrono::{DateTime, Utc};

use super::diff::DriftFinding;
use super::event::{GraphEvent, GraphEventKind, GraphSeverity};
use super::guard::{GuardResult, HealingGuard};
use super::policy::{HealingPolicy, HealingSeverity};
use super::repair::{CapsuleRepairEngine, RepairRequest};
use super::storage::GraphStorage;
use super::types::CapsuleId;

/// Phase of the healing cycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealingPhase {
    /// Scanning for drift
    Detect,
    /// Planning repair actions
    Plan,
    /// Applying repair actions
    Execute,
    /// Verifying repair succeeded
    Converge,
}

impl std::fmt::Display for HealingPhase {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            HealingPhase::Detect => write!(f, "detect"),
            HealingPhase::Plan => write!(f, "plan"),
            HealingPhase::Execute => write!(f, "execute"),
            HealingPhase::Converge => write!(f, "converge"),
        }
    }
}

/// Result of a single healing cycle.
#[derive(Debug, Clone)]
pub struct HealingCycleResult {
    /// Capsule that was healed
    pub capsule_id: CapsuleId,
    /// Phase at which the cycle stopped
    pub phase: HealingPhase,
    /// Number of drift findings discovered
    pub drift_count: usize,
    /// Number of repair actions planned
    pub planned_actions: usize,
    /// Number of repair actions successfully executed
    pub executed_actions: usize,
    /// Number of repair actions that failed
    pub failed_actions: usize,
    /// Whether the capsule converged to a healthy state
    pub converged: bool,
    /// Whether the cycle was interrupted or blocked
    pub interrupted: bool,
    /// Detailed failure reason (if any)
    pub failure_reason: Option<String>,
    /// Cycle duration in milliseconds
    pub duration_ms: u64,
    /// Timestamp
    pub completed_at: DateTime<Utc>,
}

/// The healing engine — orchestrates a full detect-plan-execute-converge cycle.
///
/// Generic over:
/// - `S`: graph storage backend
/// - `E`: repair engine
#[allow(dead_code)]
pub struct HealingEngine<S: GraphStorage, E: CapsuleRepairEngine> {
    storage: S,
    repair_engine: E,
    guard: HealingGuard,
    policy: HealingPolicy,
}

impl<S: GraphStorage, E: CapsuleRepairEngine> HealingEngine<S, E> {
    /// Create a new healing engine.
    pub fn new(storage: S, repair_engine: E, guard: HealingGuard, policy: HealingPolicy) -> Self {
        Self {
            storage,
            repair_engine,
            guard,
            policy,
        }
    }

    /// Run a single healing cycle: detect → plan → execute → converge.
    ///
    /// Returns a `HealingCycleResult` with the outcome at each phase.
    pub async fn heal(&mut self, capsule_id: &str) -> HealingCycleResult {
        let start = std::time::Instant::now();

        // Check guard invariants first
        if let Err(e) = self.guard.check_invariants(capsule_id, true, true) {
            return HealingCycleResult {
                capsule_id: capsule_id.to_string(),
                phase: HealingPhase::Detect,
                drift_count: 0,
                planned_actions: 0,
                executed_actions: 0,
                failed_actions: 0,
                converged: false,
                interrupted: true,
                failure_reason: Some(e.to_string()),
                duration_ms: start.elapsed().as_millis() as u64,
                completed_at: Utc::now(),
            };
        }

        // ── PHASE 1: Detect ──
        let findings = match self.repair_engine.detect_drift(capsule_id).await {
            Ok(f) => f,
            Err(e) => {
                return HealingCycleResult {
                    capsule_id: capsule_id.to_string(),
                    phase: HealingPhase::Detect,
                    drift_count: 0,
                    planned_actions: 0,
                    executed_actions: 0,
                    failed_actions: 0,
                    converged: false,
                    interrupted: true,
                    failure_reason: Some(format!("drift detection failed: {e}")),
                    duration_ms: start.elapsed().as_millis() as u64,
                    completed_at: Utc::now(),
                };
            }
        };

        let drift_count = findings.len();
        if drift_count == 0 {
            return HealingCycleResult {
                capsule_id: capsule_id.to_string(),
                phase: HealingPhase::Detect,
                drift_count: 0,
                planned_actions: 0,
                executed_actions: 0,
                failed_actions: 0,
                converged: true,
                interrupted: false,
                failure_reason: None,
                duration_ms: start.elapsed().as_millis() as u64,
                completed_at: Utc::now(),
            };
        }

        // ── PHASE 2: Plan ──
        let guard_check = self.guard.check(capsule_id, None, false);
        match guard_check {
            GuardResult::Blocked { reason } => {
                return HealingCycleResult {
                    capsule_id: capsule_id.to_string(),
                    phase: HealingPhase::Plan,
                    drift_count,
                    planned_actions: 0,
                    executed_actions: 0,
                    failed_actions: 0,
                    converged: false,
                    interrupted: true,
                    failure_reason: Some(reason),
                    duration_ms: start.elapsed().as_millis() as u64,
                    completed_at: Utc::now(),
                };
            }
            GuardResult::RequiresEscalation { reason } => {
                self.emit_healing_event(capsule_id, "escalation_required", &reason)
                    .await;
                return HealingCycleResult {
                    capsule_id: capsule_id.to_string(),
                    phase: HealingPhase::Plan,
                    drift_count,
                    planned_actions: 0,
                    executed_actions: 0,
                    failed_actions: 0,
                    converged: false,
                    interrupted: true,
                    failure_reason: Some(format!("escalation required: {reason}")),
                    duration_ms: start.elapsed().as_millis() as u64,
                    completed_at: Utc::now(),
                };
            }
            GuardResult::Allowed => {}
        }

        // Filter findings by policy severity
        let actionable: Vec<&DriftFinding> = findings
            .iter()
            .filter(|f| {
                let sev = match f.severity {
                    crate::capsule::event::GraphSeverity::Info => HealingSeverity::Info,
                    crate::capsule::event::GraphSeverity::Warn => HealingSeverity::Warning,
                    crate::capsule::event::GraphSeverity::Error => HealingSeverity::Error,
                    crate::capsule::event::GraphSeverity::Critical => HealingSeverity::Critical,
                };
                self.policy.should_auto_repair(sev)
            })
            .collect();

        if actionable.is_empty() {
            return HealingCycleResult {
                capsule_id: capsule_id.to_string(),
                phase: HealingPhase::Plan,
                drift_count,
                planned_actions: 0,
                executed_actions: 0,
                failed_actions: 0,
                converged: false,
                interrupted: false,
                failure_reason: Some("all findings below auto-repair threshold".to_string()),
                duration_ms: start.elapsed().as_millis() as u64,
                completed_at: Utc::now(),
            };
        }

        // ── PHASE 3: Execute ──
        self.emit_healing_event(
            capsule_id,
            "repair_started",
            &format!("{} drift items to repair", actionable.len()),
        )
        .await;

        let request = RepairRequest::new(capsule_id)
            .with_dry_run(false)
            .with_restore(true)
            .with_replay_repair(true);

        let repair_result = match self.repair_engine.repair(request).await {
            Ok(r) => r,
            Err(e) => {
                return HealingCycleResult {
                    capsule_id: capsule_id.to_string(),
                    phase: HealingPhase::Execute,
                    drift_count,
                    planned_actions: actionable.len(),
                    executed_actions: 0,
                    failed_actions: 0,
                    converged: false,
                    interrupted: true,
                    failure_reason: Some(format!("repair execution failed: {e}")),
                    duration_ms: start.elapsed().as_millis() as u64,
                    completed_at: Utc::now(),
                };
            }
        };

        // Record the repair attempt in the guard
        self.guard.record_attempt(
            capsule_id,
            None,
            repair_result.failed == 0,
            &format!(
                "repaired {} items ({} failed)",
                repair_result.repaired, repair_result.failed
            ),
        );

        // ── PHASE 4: Converge ──
        let repaired_ok = repair_result.failed == 0;
        if repaired_ok {
            self.emit_healing_event(
                capsule_id,
                "repair_completed",
                "all items repaired successfully",
            )
            .await;
        } else {
            self.emit_healing_event(
                capsule_id,
                "repair_partial",
                &format!("{} items failed to repair", repair_result.failed),
            )
            .await;
        }

        HealingCycleResult {
            capsule_id: capsule_id.to_string(),
            phase: if repaired_ok {
                HealingPhase::Converge
            } else {
                HealingPhase::Execute
            },
            drift_count,
            planned_actions: actionable.len(),
            executed_actions: repair_result.repaired,
            failed_actions: repair_result.failed,
            converged: repaired_ok,
            interrupted: !repaired_ok,
            failure_reason: if repaired_ok {
                None
            } else {
                Some("some repair actions failed".to_string())
            },
            duration_ms: start.elapsed().as_millis() as u64,
            completed_at: Utc::now(),
        }
    }

    /// Get a reference to the guard (for status queries).
    pub fn guard(&self) -> &HealingGuard {
        &self.guard
    }

    /// Get a mutable reference to the guard.
    pub fn guard_mut(&mut self) -> &mut HealingGuard {
        &mut self.guard
    }

    /// Get the policy.
    pub fn policy(&self) -> &HealingPolicy {
        &self.policy
    }

    /// Update the policy.
    pub fn set_policy(&mut self, policy: HealingPolicy) {
        self.policy = policy;
    }

    /// Emit a healing event (best-effort, no-op if not configured).
    async fn emit_healing_event(&self, capsule_id: &str, kind: &str, detail: &str) {
        if !self.policy.publish_events {
            return;
        }
        let event = GraphEvent::new(
            capsule_id,
            GraphEventKind::CapsuleRepaired,
            GraphSeverity::Info,
        )
        .with_payload(serde_json::json!({
            "healing_kind": kind,
            "detail": detail,
        }));
        // Best-effort — we don't have direct bus access here
        // The SelfHealingLoop handles bus publishing
        let _ = event;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::event::GraphSeverity;
    use crate::capsule::graph::CapsuleGraph;
    use crate::capsule::node::{CapsuleNode, NodeKind};
    use crate::capsule::repair::DefaultCapsuleRepairEngine;
    use crate::capsule::storage::FilesystemGraphStorage;
    use std::env::temp_dir;
    use uuid::Uuid;

    fn tmp_dir() -> String {
        let dir = temp_dir().join(format!("bkg-heal-test-{}", Uuid::new_v4()));
        let _ = std::fs::create_dir_all(&dir);
        dir.to_string_lossy().to_string()
    }

    fn make_engine(
        dir: &str,
    ) -> HealingEngine<FilesystemGraphStorage, DefaultCapsuleRepairEngine<FilesystemGraphStorage>>
    {
        let storage = FilesystemGraphStorage::new(dir);
        let repair = DefaultCapsuleRepairEngine::new(FilesystemGraphStorage::new(dir), dir);
        let guard = HealingGuard::new();
        let policy = HealingPolicy::default();
        HealingEngine::new(storage, repair, guard, policy)
    }

    #[tokio::test]
    async fn test_heal_healthy_capsule() {
        let dir = tmp_dir();
        let mut engine = make_engine(&dir);

        // Create a healthy capsule
        let store = FilesystemGraphStorage::new(&dir);
        let mut graph = CapsuleGraph::new("cap-healthy");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Task 1"));
        store.save_graph(&graph).await.unwrap();
        store.repair_capsule("cap-healthy").await.unwrap();

        let result = engine.heal("cap-healthy").await;
        assert!(
            result.converged,
            "healthy capsule should converge: {:?}",
            result.failure_reason
        );
        assert_eq!(result.drift_count, 0);
        assert_eq!(result.phase, HealingPhase::Detect);
    }

    #[tokio::test]
    async fn test_heal_detect_drift() {
        let dir = tmp_dir();
        let store = FilesystemGraphStorage::new(&dir);

        // Create a graph
        let mut graph = CapsuleGraph::new("cap-drift");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Task 1"));
        store.save_graph(&graph).await.unwrap();
        store.repair_capsule("cap-drift").await.unwrap();

        // Add a second node without updating manifest
        let mut graph2 = store.load_graph("cap-drift").await.unwrap();
        graph2.add_node(CapsuleNode::new("n2", NodeKind::Execution, "Exec 2"));
        store.save_graph(&graph2).await.unwrap();

        let mut engine = make_engine(&dir);
        let result = engine.heal("cap-drift").await;
        // Should detect drift and attempt repair
        assert!(result.drift_count > 0 || !result.converged);
    }

    #[test]
    fn test_healing_cycle_result_construction() {
        let result = HealingCycleResult {
            capsule_id: "cap-test".to_string(),
            phase: HealingPhase::Converge,
            drift_count: 5,
            planned_actions: 3,
            executed_actions: 3,
            failed_actions: 0,
            converged: true,
            interrupted: false,
            failure_reason: None,
            duration_ms: 150,
            completed_at: Utc::now(),
        };
        assert!(result.converged);
        assert_eq!(result.executed_actions, 3);
    }

    #[test]
    fn test_healing_phase_display() {
        assert_eq!(HealingPhase::Detect.to_string(), "detect");
        assert_eq!(HealingPhase::Plan.to_string(), "plan");
        assert_eq!(HealingPhase::Execute.to_string(), "execute");
        assert_eq!(HealingPhase::Converge.to_string(), "converge");
    }
}
