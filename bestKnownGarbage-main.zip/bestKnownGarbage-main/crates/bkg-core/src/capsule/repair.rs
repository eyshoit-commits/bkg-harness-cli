//! CapsuleRepairEngine — detect and fix graph drift.
//!
//! The repair engine is the "self-healing" part of the capsule system.
//! It detects discrepancies between expected and actual state (drift)
//! and applies targeted repair actions.
//!
//! # Repair Pipeline
//!
//! 1. **Detect drift**: scan nodes + manifest for hash mismatches
//! 2. **Resolve action**: map each finding to a `RepairAction`
//! 3. **Apply action**: execute the repair (or dry-run)
//! 4. **Report**: return `RepairResult` with per-action outcomes
//!
//! # Drift Severity
//!
//! - `Warn`: single node hash mismatch (content may have changed)
//! - `Critical`: manifest count mismatch (nodes/edges missing or extra)
//!
//! # Dry Run
//!
//! Set `RepairRequest.dry_run = true` to see what would be repaired
//! without making any changes.

use async_trait::async_trait;
use std::path::PathBuf;

use super::diff::DriftFinding;
use super::event::GraphSeverity;
use super::graph::CapsuleGraph;
use super::storage::GraphStorage;

/// Request to repair a capsule.
#[derive(Debug, Clone)]
pub struct RepairRequest {
    pub capsule_id: String,
    pub dry_run: bool,
    pub allow_restore: bool,
    pub allow_replay_repair: bool,
}

impl RepairRequest {
    /// Create a new repair request for the given capsule.
    pub fn new(capsule_id: impl Into<String>) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            dry_run: false,
            allow_restore: false,
            allow_replay_repair: false,
        }
    }

    /// Set dry-run mode (discover issues without fixing them).
    pub fn with_dry_run(mut self, dry_run: bool) -> Self {
        self.dry_run = dry_run;
        self
    }

    /// Allow restoring missing nodes/edges from backup.
    pub fn with_restore(mut self, allow: bool) -> Self {
        self.allow_restore = allow;
        self
    }

    /// Allow replay-based repair (re-execute subgraphs).
    pub fn with_replay_repair(mut self, allow: bool) -> Self {
        self.allow_replay_repair = allow;
        self
    }
}

/// Result of a repair operation.
#[derive(Debug, Clone)]
pub struct RepairResult {
    pub capsule_id: String,
    pub repaired: usize,
    pub skipped: usize,
    pub failed: usize,
    pub drift_detected: bool,
    pub actions: Vec<RepairActionResult>,
}

/// Outcome of a single repair action.
#[derive(Debug, Clone)]
pub struct RepairActionResult {
    pub target_id: String,
    pub action: RepairAction,
    pub success: bool,
    pub message: String,
}

/// A specific repair action to take.
#[derive(Debug, Clone)]
pub enum RepairAction {
    /// Rebuild the index from node/edge files
    RebuildIndex,
    /// Regenerate the graph manifest
    RecreateManifest,
    /// Restore a missing node from backup
    RestoreMissingNode,
    /// Restore a missing edge from backup
    RestoreMissingEdge,
    /// Recompute and update a node's hash
    RehashNode,
    /// Recompute and update an edge's hash
    RehashEdge,
    /// Reattach a receipt to a node
    ReattachReceipt,
    /// Reattach a snapshot to a node
    ReattachSnapshot,
    /// Recompute the truth score for a node
    RecomputeTruth,
    /// Mark a node as stale (for manual review)
    MarkStale,
    /// Mark a node as divergent (hash mismatch confirmed)
    MarkDivergent,
    /// Re-execute a subgraph to fix drift
    ReplaySubgraph,
}

/// Trait for capsule repair engines.
///
/// Implementations detect drift and apply repairs. The default
/// implementation (`DefaultCapsuleRepairEngine`) works with any
/// `GraphStorage` backend.
#[async_trait]
pub trait CapsuleRepairEngine: Send + Sync {
    /// Detect drift and apply repairs.
    async fn repair(&self, request: RepairRequest) -> Result<RepairResult, String>;

    /// Scan a capsule for drift without making any changes.
    async fn detect_drift(&self, capsule_id: &str) -> Result<Vec<DriftFinding>, String>;

    /// Preview what repairs would be made.
    async fn dry_run(&self, capsule_id: &str) -> Result<RepairResult, String>;
}

/// Default implementation of `CapsuleRepairEngine`.
///
/// Works with any `GraphStorage` backend. Detects drift by comparing
/// node hashes against recomputed hashes and verifying manifest counts.
pub struct DefaultCapsuleRepairEngine<S: GraphStorage> {
    pub storage: S,
    pub capsule_root: PathBuf,
}

impl<S: GraphStorage> DefaultCapsuleRepairEngine<S> {
    /// Create a new repair engine.
    pub fn new(storage: S, capsule_root: impl Into<PathBuf>) -> Self {
        Self {
            storage,
            capsule_root: capsule_root.into(),
        }
    }

    /// Compute the expected hash for a node by serializing it.
    fn compute_node_hash(&self, node: &super::node::CapsuleNode) -> String {
        let json = serde_json::to_string(node).unwrap_or_default();
        crate::chain::hashes::hash_bytes(json.as_bytes())
    }

    /// Compute the expected hash for the entire graph.
    fn compute_graph_hash(&self, graph: &CapsuleGraph) -> String {
        graph.compute_hash()
    }

    /// Map a drift finding to the most appropriate repair action.
    fn resolve_action(&self, finding: &DriftFinding) -> RepairAction {
        match finding.target_kind.as_str() {
            "CapsuleManifest" => RepairAction::RecreateManifest,
            "Task" | "Execution" | "Receipt" | "TruthCheck" => RepairAction::RehashNode,
            "Snapshot" => RepairAction::ReattachSnapshot,
            _ => RepairAction::MarkDivergent,
        }
    }

    /// Apply a single repair action.
    async fn apply_action(
        &self,
        request: &RepairRequest,
        finding: &DriftFinding,
        action: RepairAction,
    ) -> Result<RepairActionResult, String> {
        if request.dry_run {
            return Ok(RepairActionResult {
                target_id: finding.target_id.clone(),
                action,
                success: true,
                message: "dry run — no changes applied".to_string(),
            });
        }

        let message = match &action {
            RepairAction::RecreateManifest => {
                self.storage.repair_capsule(&request.capsule_id).await?;
                "manifest recreated from current state"
            }
            RepairAction::RehashNode => {
                let mut graph = self.storage.load_graph(&request.capsule_id).await?;
                if let Some(node) = graph.get_node_mut(&finding.target_id) {
                    node.hash = self.compute_node_hash(node);
                    self.storage.save_node(&request.capsule_id, node).await?;
                }
                "node rehashed"
            }
            RepairAction::RehashEdge => {
                let mut graph = self.storage.load_graph(&request.capsule_id).await?;
                if let Some(edge) = graph.get_edge_mut(&finding.target_id) {
                    self.storage.save_edge(&request.capsule_id, edge).await?;
                }
                "edge rehashed"
            }
            RepairAction::MarkStale => {
                let mut graph = self.storage.load_graph(&request.capsule_id).await?;
                if let Some(node) = graph.get_node_mut(&finding.target_id) {
                    node.status = super::node::NodeStatus::Stale;
                    self.storage.save_node(&request.capsule_id, node).await?;
                }
                "marked as stale — manual review required"
            }
            RepairAction::MarkDivergent => {
                let mut graph = self.storage.load_graph(&request.capsule_id).await?;
                if let Some(node) = graph.get_node_mut(&finding.target_id) {
                    node.status = super::node::NodeStatus::Divergent {
                        expected: finding.expected_hash.clone(),
                        actual: finding.actual_hash.clone(),
                    };
                    self.storage.save_node(&request.capsule_id, node).await?;
                }
                "marked as divergent"
            }
            _ => {
                let s = format!("{action:?} — not yet implemented in default engine");
                return Ok(RepairActionResult {
                    target_id: finding.target_id.clone(),
                    action,
                    success: false,
                    message: s,
                });
            }
        };

        Ok(RepairActionResult {
            target_id: finding.target_id.clone(),
            action,
            success: true,
            message: message.to_string(),
        })
    }
}

#[async_trait]
impl<S: GraphStorage + Send + Sync> CapsuleRepairEngine for DefaultCapsuleRepairEngine<S> {
    /// Full repair pipeline: detect drift → resolve → apply → report.
    async fn repair(&self, request: RepairRequest) -> Result<RepairResult, String> {
        let findings = self.detect_drift(&request.capsule_id).await?;

        let mut result = RepairResult {
            capsule_id: request.capsule_id.clone(),
            repaired: 0,
            skipped: 0,
            failed: 0,
            drift_detected: !findings.is_empty(),
            actions: vec![],
        };

        for finding in &findings {
            let action = self.resolve_action(finding);
            let action_result = self.apply_action(&request, finding, action).await?;
            if action_result.success {
                result.repaired += 1;
            } else if finding.severity == GraphSeverity::Critical {
                result.failed += 1;
            } else {
                result.skipped += 1;
            }
            result.actions.push(action_result);
        }

        Ok(result)
    }

    /// Scan a capsule for drift.
    ///
    /// Compares each node's hash against a freshly computed hash,
    /// and verifies manifest node/edge counts match the actual graph.
    async fn detect_drift(&self, capsule_id: &str) -> Result<Vec<DriftFinding>, String> {
        let graph = self.storage.load_graph(capsule_id).await?;
        let manifest = self.storage.load_manifest(capsule_id).await?;

        let mut findings = vec![];

        // Check each node's hash
        for node in graph.nodes.values() {
            if node.hash.is_empty() {
                continue; // unhashed nodes are not drift
            }
            let expected_hash = self.compute_node_hash(node);
            if node.hash != expected_hash {
                findings.push(DriftFinding::new(
                    &node.id,
                    format!("{:?}", node.kind),
                    expected_hash,
                    &node.hash,
                    GraphSeverity::Warn,
                    "node hash mismatch — content may have changed",
                ));
            }
        }

        // Check manifest counts
        if manifest.node_count != graph.nodes.len() || manifest.edge_count != graph.edges.len() {
            let computed_hash = self.compute_graph_hash(&graph);
            findings.push(DriftFinding::new(
                capsule_id,
                "CapsuleManifest",
                manifest.root_hash.clone(),
                computed_hash,
                GraphSeverity::Critical,
                format!(
                    "manifest count mismatch: manifest says {} nodes/{} edges, \
                     graph has {} nodes/{} edges",
                    manifest.node_count,
                    manifest.edge_count,
                    graph.nodes.len(),
                    graph.edges.len()
                ),
            ));
        }

        Ok(findings)
    }

    /// Preview repairs without making changes.
    async fn dry_run(&self, capsule_id: &str) -> Result<RepairResult, String> {
        let findings = self.detect_drift(capsule_id).await?;
        Ok(RepairResult {
            capsule_id: capsule_id.to_string(),
            repaired: 0,
            skipped: findings.len(),
            failed: 0,
            drift_detected: !findings.is_empty(),
            actions: findings
                .into_iter()
                .map(|f| RepairActionResult {
                    target_id: f.target_id,
                    action: RepairAction::MarkStale,
                    success: true,
                    message: format!("would repair: {} (severity: {:?})", f.reason, f.severity),
                })
                .collect(),
        })
    }
}

// Helper: CapsuleGraph needs get_edge_mut for the repair engine
// This is provided via the `get_node_mut` pattern — we need it for edges too.
// Add this method via a small extension.
impl CapsuleGraph {
    /// Get a mutable reference to an edge.
    pub fn get_edge_mut(&mut self, id: &str) -> Option<&mut super::edge::CapsuleEdge> {
        self.edges.get_mut(id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::capsule::graph::CapsuleGraph;
    use crate::capsule::node::{CapsuleNode, NodeKind};
    use crate::capsule::storage::FilesystemGraphStorage;
    use std::env::temp_dir;
    use uuid::Uuid;

    /// Create a temp dir for test data.
    fn tmp_dir() -> String {
        let dir = temp_dir().join(format!("bkg-repair-test-{}", Uuid::new_v4()));
        let _ = std::fs::create_dir_all(&dir);
        dir.to_string_lossy().to_string()
    }

    #[tokio::test]
    async fn test_dry_run_detects_no_drift_for_healthy_capsule() {
        let dir = tmp_dir();
        let storage = FilesystemGraphStorage::new(&dir);
        let engine = DefaultCapsuleRepairEngine::new(storage, &dir);

        // Create a healthy graph
        let storage2 = FilesystemGraphStorage::new(&dir);
        let mut graph = CapsuleGraph::new("cap-healthy");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Task 1"));
        storage2.save_graph(&graph).await.unwrap();
        storage2.repair_capsule("cap-healthy").await.unwrap();

        let result = engine.dry_run("cap-healthy").await.unwrap();
        assert!(
            !result.drift_detected,
            "healthy capsule should have no drift"
        );
    }

    #[tokio::test]
    async fn test_dry_run_detects_manifest_drift() {
        let dir = tmp_dir();
        let storage = FilesystemGraphStorage::new(&dir);
        let engine = DefaultCapsuleRepairEngine::new(storage, &dir);

        // Create graph with 1 node, save, and generate manifest
        let store = FilesystemGraphStorage::new(&dir);
        let mut graph = CapsuleGraph::new("cap-drift");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Task 1"));
        store.save_graph(&graph).await.unwrap();
        store.repair_capsule("cap-drift").await.unwrap();

        // Now add a second node but DON'T update manifest
        let mut graph2 = store.load_graph("cap-drift").await.unwrap();
        graph2.add_node(CapsuleNode::new("n2", NodeKind::Execution, "Exec 2"));
        store.save_graph(&graph2).await.unwrap();

        let result = engine.dry_run("cap-drift").await.unwrap();
        assert!(
            result.drift_detected,
            "should detect drift from manifest mismatch"
        );
    }

    #[tokio::test]
    async fn test_repair_recreates_manifest() {
        let dir = tmp_dir();
        let storage = FilesystemGraphStorage::new(&dir);
        let engine = DefaultCapsuleRepairEngine::new(storage, &dir);

        // Create a graph
        let store = FilesystemGraphStorage::new(&dir);
        let mut graph = CapsuleGraph::new("cap-repair-test");
        graph.add_node(CapsuleNode::new("n1", NodeKind::Task, "Task 1"));
        store.save_graph(&graph).await.unwrap();

        // Repair
        let request = RepairRequest::new("cap-repair-test");
        let result = engine.repair(request).await.unwrap();
        assert!(result.repaired > 0 || !result.drift_detected);
    }
}
