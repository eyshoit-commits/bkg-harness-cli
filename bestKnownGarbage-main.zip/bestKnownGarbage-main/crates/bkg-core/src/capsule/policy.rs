//! **Causa** HealingPolicy — governance rules for the self-healing loop.
//!
//! The healing policy determines HOW the self-healing loop repairs
//! capsules. It's the "rule book" that bounds repair behavior:
//!
//! - What severity of drift triggers automatic vs. manual repair
//! - How many retries before escalation
//! - Whether repair is automatic, manual, or advisory-only
//! - Thresholds for when to escalate to human review

use serde::{Deserialize, Serialize};

/// Severity level for healing policy rules.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Serialize, Deserialize)]
pub enum HealingSeverity {
    /// Informational — no action required
    Info,
    /// Warning — may need attention
    Warning,
    /// Error — automatic repair attempted
    Error,
    /// Critical — immediate escalation required
    Critical,
}

impl HealingSeverity {
    /// Higher severity = higher numerical value.
    pub fn as_u8(self) -> u8 {
        match self {
            HealingSeverity::Info => 0,
            HealingSeverity::Warning => 1,
            HealingSeverity::Error => 2,
            HealingSeverity::Critical => 3,
        }
    }
}

/// Whether a healing action requires human approval.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ApprovalMode {
    /// Automatic — no human needed
    Automatic,
    /// Manual — human must approve
    Manual,
    /// Advisory — recommend but don't enforce
    Advisory,
}

/// Configuration for automatic repair escalation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EscalationConfig {
    /// Number of failed repair attempts before escalating
    pub max_retries: u32,
    /// Cooldown between retries in seconds
    pub retry_cooldown_secs: u64,
    /// Whether to escalate to guardian when retries exhausted
    pub escalate_on_exhaustion: bool,
    /// Maximum consecutive repair cycles before forcing manual review
    pub max_consecutive_cycles: u32,
}

impl Default for EscalationConfig {
    fn default() -> Self {
        Self {
            max_retries: 3,
            retry_cooldown_secs: 60,
            escalate_on_exhaustion: true,
            max_consecutive_cycles: 10,
        }
    }
}

/// Drift thresholds that trigger different healing responses.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DriftThresholds {
    /// Hash divergence below this level is "noise" (no action)
    pub noise_threshold: f32,
    /// Hash divergence above this level triggers warning
    pub warning_threshold: f32,
    /// Hash divergence above this level triggers automatic repair
    pub auto_repair_threshold: f32,
    /// Hash divergence above this level triggers critical escalation
    pub critical_threshold: f32,
}

impl Default for DriftThresholds {
    fn default() -> Self {
        Self {
            noise_threshold: 0.05,
            warning_threshold: 0.15,
            auto_repair_threshold: 0.30,
            critical_threshold: 0.70,
        }
    }
}

/// Complete healing policy for a capsule.
///
/// The policy governs all aspects of the self-healing loop:
/// - What triggers repair (drift thresholds)
/// - How repair proceeds (escalation config)
/// - What requires human approval (approval mode)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HealingPolicy {
    /// Capsule this policy applies to (empty = default for all)
    pub capsule_id: Option<String>,
    /// Approval mode for automatic vs. manual repair
    pub approval_mode: ApprovalMode,
    /// Drift thresholds
    pub drift_thresholds: DriftThresholds,
    /// Escalation configuration
    pub escalation_config: EscalationConfig,
    /// Whether to publish events during healing
    pub publish_events: bool,
}

impl Default for HealingPolicy {
    fn default() -> Self {
        Self {
            capsule_id: None,
            approval_mode: ApprovalMode::Automatic,
            drift_thresholds: DriftThresholds::default(),
            escalation_config: EscalationConfig::default(),
            publish_events: true,
        }
    }
}

impl HealingPolicy {
    /// Create a new policy with default settings.
    pub fn new() -> Self {
        Self::default()
    }

    /// Create a policy that requires manual approval for all repairs.
    pub fn manual() -> Self {
        Self {
            approval_mode: ApprovalMode::Manual,
            ..Self::default()
        }
    }

    /// Create a strict policy with aggressive thresholds.
    pub fn strict() -> Self {
        Self {
            drift_thresholds: DriftThresholds {
                noise_threshold: 0.02,
                warning_threshold: 0.05,
                auto_repair_threshold: 0.10,
                critical_threshold: 0.30,
            },
            escalation_config: EscalationConfig {
                max_retries: 5,
                ..EscalationConfig::default()
            },
            ..Self::default()
        }
    }

    /// Classify drift severity based on the configured thresholds.
    pub fn classify_drift(&self, divergence: f32) -> HealingSeverity {
        if divergence >= self.drift_thresholds.critical_threshold {
            HealingSeverity::Critical
        } else if divergence >= self.drift_thresholds.auto_repair_threshold {
            HealingSeverity::Error
        } else if divergence >= self.drift_thresholds.warning_threshold {
            HealingSeverity::Warning
        } else {
            HealingSeverity::Info
        }
    }

    /// Determine whether repair should proceed automatically.
    pub fn should_auto_repair(&self, severity: HealingSeverity) -> bool {
        match self.approval_mode {
            ApprovalMode::Automatic => severity >= HealingSeverity::Warning,
            ApprovalMode::Advisory => severity >= HealingSeverity::Critical,
            ApprovalMode::Manual => false,
        }
    }

    /// Determine whether this severity requires escalation.
    pub fn requires_escalation(&self, severity: HealingSeverity) -> bool {
        severity == HealingSeverity::Critical
    }

    /// Check if retries are exhausted.
    pub fn retries_exhausted(&self, attempts: u32) -> bool {
        attempts >= self.escalation_config.max_retries
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_policy() {
        let policy = HealingPolicy::default();
        assert_eq!(policy.approval_mode, ApprovalMode::Automatic);
        assert!(policy.publish_events);
    }

    #[test]
    fn test_manual_policy() {
        let policy = HealingPolicy::manual();
        assert_eq!(policy.approval_mode, ApprovalMode::Manual);
    }

    #[test]
    fn test_strict_thresholds() {
        let policy = HealingPolicy::strict();
        assert!(policy.drift_thresholds.noise_threshold < 0.05);
    }

    #[test]
    fn test_drift_classification() {
        let policy = HealingPolicy::default();

        assert_eq!(policy.classify_drift(0.01), HealingSeverity::Info);
        assert_eq!(policy.classify_drift(0.20), HealingSeverity::Warning);
        assert_eq!(policy.classify_drift(0.40), HealingSeverity::Error);
        assert_eq!(policy.classify_drift(0.80), HealingSeverity::Critical);
    }

    #[test]
    fn test_auto_repair_decisions() {
        let auto = HealingPolicy::default();
        let manual = HealingPolicy::manual();

        assert!(auto.should_auto_repair(HealingSeverity::Warning));
        assert!(!auto.should_auto_repair(HealingSeverity::Info));
        assert!(!manual.should_auto_repair(HealingSeverity::Critical));
    }

    #[test]
    fn test_escalation() {
        let policy = HealingPolicy::default();
        assert!(policy.requires_escalation(HealingSeverity::Critical));
        assert!(!policy.requires_escalation(HealingSeverity::Warning));

        assert!(!policy.retries_exhausted(2));
        assert!(policy.retries_exhausted(3));
    }

    #[test]
    fn test_severity_ordering() {
        assert!(HealingSeverity::Critical.as_u8() > HealingSeverity::Error.as_u8());
        assert!(HealingSeverity::Error.as_u8() > HealingSeverity::Warning.as_u8());
        assert!(HealingSeverity::Warning.as_u8() > HealingSeverity::Info.as_u8());
    }
}
