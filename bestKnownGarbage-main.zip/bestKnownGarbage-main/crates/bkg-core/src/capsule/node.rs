//! CapsuleNode — a single node in the capsule DAG.
//!
//! Each node represents one artifact or state in the execution graph:
//! a task, an execution, a receipt, a truth check, a snapshot, a memory
//! entry, or a repair action.
//!
//! Nodes are connected by `CapsuleEdge` instances to form the full DAG.
//! Every node has a cryptographic hash for integrity verification.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

pub type NodeId = String;

/// The kind of work or artifact this node represents.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum NodeKind {
    Task,
    Execution,
    Receipt,
    TruthCheck,
    Snapshot,
    Memory,
    Repair,
}

/// Lifecycle status of a node in the graph.
///
/// The status determines UI rendering (color, icon) and repair behavior.
/// - `Verified`: passed integrity check
/// - `Stale`: hash mismatch but not yet confirmed divergent
/// - `Divergent`: confirmed hash mismatch with expected/actual
/// - `Repaired`: was divergent, now fixed
/// - `Failed`: execution failed
/// - `Archived`: moved to cold storage
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum NodeStatus {
    Pending,
    Running,
    Verified,
    Stale,
    Divergent { expected: String, actual: String },
    Repaired,
    Failed(String),
    Archived,
}

/// A node in the capsule execution graph.
///
/// Nodes are the atomic units of the DAG. They carry:
/// - Identity (`id`, `kind`, `label`)
/// - Status (`status`, `hash`)
/// - Topology (`parents`, `children`, `depth`)
/// - Position (`position`: optional UI layout hint)
/// - Metadata (`metadata`: flexible JSON for any domain-specific data)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleNode {
    pub id: NodeId,
    pub kind: NodeKind,
    pub label: String,
    pub description: String,
    pub status: NodeStatus,
    pub hash: String,
    pub parents: Vec<NodeId>,
    pub children: Vec<NodeId>,
    pub depth: usize,
    pub position: Option<(f64, f64)>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub metadata: serde_json::Value,
}

impl CapsuleNode {
    /// Create a new node with the minimal required fields.
    pub fn new(id: impl Into<String>, kind: NodeKind, label: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            kind,
            label: label.into(),
            description: String::new(),
            status: NodeStatus::Pending,
            hash: String::new(),
            parents: Vec::new(),
            children: Vec::new(),
            depth: 0,
            position: None,
            created_at: Utc::now(),
            updated_at: Utc::now(),
            metadata: serde_json::json!({}),
        }
    }

    /// Set the node status.
    pub fn with_status(mut self, status: NodeStatus) -> Self {
        self.status = status;
        self
    }

    /// Set the cryptographic hash.
    pub fn with_hash(mut self, hash: impl Into<String>) -> Self {
        self.hash = hash.into();
        self
    }

    /// Add a parent node reference.
    pub fn with_parent(mut self, parent: impl Into<String>) -> Self {
        self.parents.push(parent.into());
        self
    }

    /// Add a child node reference.
    pub fn with_child(mut self, child: impl Into<String>) -> Self {
        self.children.push(child.into());
        self
    }

    /// Set the depth in the DAG.
    pub fn with_depth(mut self, depth: usize) -> Self {
        self.depth = depth;
        self
    }

    /// Set a human-readable description.
    pub fn with_description(mut self, desc: impl Into<String>) -> Self {
        self.description = desc.into();
        self
    }

    /// Set a metadata payload.
    pub fn with_metadata(mut self, metadata: serde_json::Value) -> Self {
        self.metadata = metadata;
        self
    }

    /// Set a UI position hint.
    pub fn with_position(mut self, x: f64, y: f64) -> Self {
        self.position = Some((x, y));
        self
    }
}
