//! BKG Core — foundational types for the BKG system.
//!
//! This crate provides the basic building blocks used by all other
//! BKG crates: error types, configuration, message types, session management,
//! and core type aliases.
//!
//! # The BKG Reveland — A Naming Architecture
//!
//! The system is no longer a "framework" — it is a **Causal State Machine Runtime
//! with Verifiable Time**. Each layer has a Reveland identity:
//!
//! | Layer | Rust Module | Reveland Name | Meaning |
//! |-------|-------------|---------------|---------|
//! | Session | `session` | **Aevum** | Ephemeral runtime fire — one execution age |
//! | Capsule | `capsule` | **Causa** | Persistent causal unit — provenance through time |
//! | Execution | `capsule::graph` | **Telum** | Deterministic DAG forge |
//! | Truth | `kernel::truth` | **Speculum** | Mirror gate — reflection reveals divergence |
//! | Evolution | `kernel::evolution` | **Evolutio** | Living codex — policy evolves across generations |
//! | Timeline | `kernel::time` | **Tempus** | Append-only causal stream — time itself |
//! | CAS Store | (future) | **Mensa** | Memory lattice — content-addressable facts |

pub mod bootstrap;
pub mod capsule;
pub mod chain;
pub mod config;
pub mod error;
pub mod kernel;
pub mod message;
pub mod model;
pub mod provider;
pub mod result;
pub mod reveland;
pub mod session;
pub mod types;

/// Default data directory for BKG state.
pub const DATA_DIR: &str = ".bkg";

pub use error::{BkgError, Result as CoreResult};
pub use reveland::{
    CausalError, CausalInvariantChecker, CausalProof, DefaultCausalInvariantChecker,
};
pub use session::{SessionBudget, SessionId};
pub use types::*;
