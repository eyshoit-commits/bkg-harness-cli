//! BKG Core Error Types
//!
//! Unified error handling for the entire BKG kernel system.

use thiserror::Error;

/// Main error type for BKG operations
#[derive(Error, Debug)]
pub enum BkgError {
    #[error("Trust kernel failure: {0}")]
    Trust(String),

    #[error("Causality graph error: {0}")]
    Causality(String),

    #[error("Replay divergence detected: original={original}, replayed={replayed}")]
    ReplayMismatch { original: String, replayed: String },

    #[error("Consensus not reachable: {0}")]
    ConsensusFailure(String),

    #[error("Sandbox violation: {0}")]
    SandboxViolation(String),

    #[error("Provider error: {0}")]
    Provider(String),

    #[error("Node unavailable: {0}")]
    NodeDown(String),

    #[error("Reality anchor divergence exceeded: {0}")]
    RealityDivergence(f32),

    #[error("Evolution rejected: {0}")]
    EvolutionRejected(String),

    #[error("Guard system violation: {0}")]
    GuardViolation(String),

    #[error("Invalid state transition: {0}")]
    InvalidState(String),

    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Mesh sync error: {0}")]
    MeshSync(String),

    #[error("Safety invariant violation: {0}")]
    SafetyInvariant(String),

    #[error("duplicate receipt: {0}")]
    DuplicateReceipt(String),

    #[error("time error")]
    TimeError,

    #[error("operation cancelled")]
    Cancelled,
}

/// Result type alias for BKG operations
pub type Result<T> = std::result::Result<T, BkgError>;
