//! Configuration types for BKG.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Main configuration.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct Config {
    /// LSP configurations.
    #[serde(default)]
    pub lsp: HashMap<String, LspConfig>,
    /// MCP server configurations.
    #[serde(default)]
    pub mcp: HashMap<String, McpConfig>,
    /// Provider configurations.
    #[serde(default)]
    pub providers: HashMap<String, ProviderConfig>,
    /// Selected large model.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub large_model: Option<SelectedModel>,
    /// Selected small model.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub small_model: Option<SelectedModel>,
    /// Configuration options.
    #[serde(default)]
    pub options: ConfigOptions,
    /// Hooks.
    #[serde(default)]
    pub hooks: Vec<HookConfig>,
    /// Agent definitions.
    #[serde(default)]
    pub agents: HashMap<String, AgentConfig>,
    /// Permissions.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub permissions: Option<PermissionsConfig>,
}

/// LSP configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LspConfig {
    /// Command to run.
    pub command: String,
    /// Command arguments.
    #[serde(default)]
    pub args: Vec<String>,
    /// Environment variables.
    #[serde(default)]
    pub env: HashMap<String, String>,
    /// File types this LSP handles.
    #[serde(default)]
    pub file_types: Vec<String>,
    /// Root markers.
    #[serde(default)]
    pub root_markers: Vec<String>,
    /// Initialization options.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub init_options: Option<serde_json::Value>,
    /// LSP options.
    #[serde(default)]
    pub options: serde_json::Value,
    /// Whether this LSP is disabled.
    #[serde(default)]
    pub disabled: bool,
}

/// MCP server configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct McpConfig {
    /// Command to run.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub command: Option<String>,
    /// Command arguments.
    #[serde(default)]
    pub args: Vec<String>,
    /// Environment variables.
    #[serde(default)]
    pub env: HashMap<String, String>,
    /// URL for HTTP-based MCP.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub url: Option<String>,
    /// Whether this MCP is disabled.
    #[serde(default)]
    pub disabled: bool,
}

/// Provider configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProviderConfig {
    /// Provider ID.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub id: Option<String>,
    /// Provider name.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// Base URL.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub base_url: Option<String>,
    /// Provider type.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub provider_type: Option<String>,
    /// API key.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub api_key: Option<String>,
    /// Available models.
    #[serde(default)]
    pub models: Vec<ModelConfig>,
    /// Whether this provider is disabled.
    #[serde(default)]
    pub disabled: bool,
}

/// Model configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelConfig {
    /// Model ID.
    pub id: String,
    /// Model name.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    /// Context window.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub context_window: Option<i64>,
    /// Max output tokens.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_output: Option<i64>,
    /// Cost per 1M input tokens.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cost_input: Option<f64>,
    /// Cost per 1M output tokens.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cost_output: Option<f64>,
}

/// Selected model configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SelectedModel {
    /// Model ID.
    pub model: String,
    /// Provider name.
    pub provider: String,
    /// Reasoning effort (for OpenAI).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub reasoning_effort: Option<String>,
    /// Enable thinking (for Anthropic).
    #[serde(default)]
    pub think: bool,
    /// Max tokens override.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub max_tokens: Option<i64>,
    /// Temperature override.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub temperature: Option<f64>,
}

/// Configuration options.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfigOptions {
    /// Data directory.
    #[serde(default = "default_data_dir")]
    pub data_directory: String,
    /// Debug mode.
    #[serde(default)]
    pub debug: bool,
    /// Disable telemetry.
    #[serde(default)]
    pub disable_telemetry: bool,
    /// Theme.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub theme: Option<String>,
}

fn default_data_dir() -> String {
    crate::DATA_DIR.to_string()
}

impl Default for ConfigOptions {
    fn default() -> Self {
        Self {
            data_directory: default_data_dir(),
            debug: false,
            disable_telemetry: false,
            theme: None,
        }
    }
}

/// Hook configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HookConfig {
    /// Hook event type.
    pub event: String,
    /// Hook name.
    pub name: String,
    /// Command to run.
    pub command: String,
    /// Matcher pattern.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub matcher: Option<String>,
    /// Timeout in seconds.
    #[serde(default = "default_hook_timeout")]
    pub timeout: u64,
}

fn default_hook_timeout() -> u64 {
    60
}

/// Agent configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentConfig {
    /// Agent name.
    pub name: String,
    /// System prompt template.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub system_prompt: Option<String>,
    /// Model to use.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model: Option<SelectedModel>,
}

/// Permissions configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PermissionsConfig {
    /// Allowed tools.
    #[serde(default)]
    pub allowed_tools: Vec<String>,
    /// Denied tools.
    #[serde(default)]
    pub denied_tools: Vec<String>,
}
