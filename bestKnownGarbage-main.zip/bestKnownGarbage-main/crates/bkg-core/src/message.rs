//! Message types for BKG.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Message role.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MessageRole {
    /// Assistant message.
    Assistant,
    /// User message.
    User,
    /// System message.
    System,
    /// Tool result message.
    Tool,
}

impl std::fmt::Display for MessageRole {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Assistant => write!(f, "assistant"),
            Self::User => write!(f, "user"),
            Self::System => write!(f, "system"),
            Self::Tool => write!(f, "tool"),
        }
    }
}

/// Finish reason for a message.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FinishReason {
    /// Normal end of turn.
    EndTurn,
    /// Max tokens reached.
    MaxTokens,
    /// Tool use requested.
    ToolUse,
    /// Cancelled by user.
    Canceled,
    /// Error occurred.
    Error,
    /// Unknown reason.
    Unknown,
}

/// Content part in a message.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ContentPart {
    /// Text content.
    Text {
        /// The text content.
        text: String,
    },
    /// Image content.
    Image {
        /// Image URL or base64 data.
        source: ImageSource,
    },
    /// Tool use request.
    ToolUse {
        /// Tool call ID.
        id: String,
        /// Tool name.
        name: String,
        /// Tool input as JSON.
        input: serde_json::Value,
    },
    /// Tool result.
    ToolResult {
        /// Tool use ID this is responding to.
        tool_use_id: String,
        /// Content of the result.
        content: String,
        /// Whether the tool call errored.
        is_error: bool,
    },
    /// Reasoning/thinking content.
    Reasoning {
        /// The thinking content.
        thinking: String,
        /// Signature for extended thinking.
        #[serde(skip_serializing_if = "Option::is_none")]
        signature: Option<String>,
    },
}

impl ContentPart {
    /// Create a new text content part.
    pub fn text(text: impl Into<String>) -> Self {
        Self::Text { text: text.into() }
    }

    /// Create a new tool use content part.
    pub fn tool_use(
        id: impl Into<String>,
        name: impl Into<String>,
        input: serde_json::Value,
    ) -> Self {
        Self::ToolUse {
            id: id.into(),
            name: name.into(),
            input,
        }
    }

    /// Create a new tool result content part.
    pub fn tool_result(
        tool_use_id: impl Into<String>,
        content: impl Into<String>,
        is_error: bool,
    ) -> Self {
        Self::ToolResult {
            tool_use_id: tool_use_id.into(),
            content: content.into(),
            is_error,
        }
    }
}

impl std::fmt::Display for ContentPart {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Text { text } => write!(f, "{}", text),
            Self::Image { source } => write!(f, "[Image: {}]", source),
            Self::ToolUse { name, .. } => write!(f, "[Tool: {}]", name),
            Self::ToolResult {
                content, is_error, ..
            } => {
                if *is_error {
                    write!(f, "[Error: {}]", content)
                } else {
                    write!(f, "{}", content)
                }
            }
            Self::Reasoning { thinking, .. } => write!(f, "{}", thinking),
        }
    }
}

/// Image source.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImageSource {
    /// Source type.
    #[serde(rename = "type")]
    pub source_type: String,
    /// Media type.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub media_type: Option<String>,
    /// Data (URL or base64).
    pub data: String,
}

impl std::fmt::Display for ImageSource {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.source_type)
    }
}

/// Message in a conversation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    /// Unique message ID.
    pub id: String,
    /// Session ID this message belongs to.
    pub session_id: String,
    /// Message role.
    pub role: MessageRole,
    /// Content parts.
    pub parts: Vec<ContentPart>,
    /// Model used (for assistant messages).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub model: Option<String>,
    /// Provider used.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub provider: Option<String>,
    /// Finish reason.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub finish_reason: Option<FinishReason>,
    /// Creation timestamp.
    pub created_at: DateTime<Utc>,
    /// Update timestamp.
    pub updated_at: DateTime<Utc>,
    /// Finish timestamp.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub finished_at: Option<DateTime<Utc>>,
    /// Prompt tokens used.
    #[serde(default)]
    pub prompt_tokens: i64,
    /// Completion tokens used.
    #[serde(default)]
    pub completion_tokens: i64,
    /// Whether this is a summary message.
    #[serde(default)]
    pub is_summary: bool,
}

impl Message {
    /// Create a new message.
    pub fn new(session_id: impl Into<String>, role: MessageRole, parts: Vec<ContentPart>) -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4().to_string(),
            session_id: session_id.into(),
            role,
            parts,
            model: None,
            provider: None,
            finish_reason: None,
            created_at: now,
            updated_at: now,
            finished_at: None,
            prompt_tokens: 0,
            completion_tokens: 0,
            is_summary: false,
        }
    }

    /// Create a new user message.
    pub fn user(session_id: impl Into<String>, text: impl Into<String>) -> Self {
        Self::new(session_id, MessageRole::User, vec![ContentPart::text(text)])
    }

    /// Create a new assistant message.
    pub fn assistant(session_id: impl Into<String>, text: impl Into<String>) -> Self {
        Self::new(
            session_id,
            MessageRole::Assistant,
            vec![ContentPart::text(text)],
        )
    }

    /// Create a new system message.
    pub fn system(text: impl Into<String>) -> Self {
        Self::new("", MessageRole::System, vec![ContentPart::text(text)])
    }

    /// Get the text content of this message.
    pub fn text(&self) -> String {
        self.parts
            .iter()
            .filter_map(|p| match p {
                ContentPart::Text { text } => Some(text.clone()),
                _ => None,
            })
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// Check if this message has tool uses.
    pub fn has_tool_uses(&self) -> bool {
        self.parts
            .iter()
            .any(|p| matches!(p, ContentPart::ToolUse { .. }))
    }

    /// Get tool uses from this message.
    pub fn tool_uses(&self) -> Vec<(&str, &str, &serde_json::Value)> {
        self.parts
            .iter()
            .filter_map(|p| match p {
                ContentPart::ToolUse { id, name, input } => {
                    Some((id.as_str(), name.as_str(), input))
                }
                _ => None,
            })
            .collect()
    }

    /// Mark this message as finished.
    pub fn finish(&mut self, reason: FinishReason) {
        self.finish_reason = Some(reason);
        self.finished_at = Some(Utc::now());
        self.updated_at = Utc::now();
    }

    /// Get total tokens used.
    pub fn total_tokens(&self) -> i64 {
        self.prompt_tokens + self.completion_tokens
    }
}
