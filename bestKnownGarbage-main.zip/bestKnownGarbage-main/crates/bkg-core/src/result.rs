//! Error types for BKG core library.

use thiserror::Error;

/// Result type alias for BKG operations.
pub type Result<T> = std::result::Result<T, Error>;

/// Main error type for BKG operations.
#[derive(Error, Debug)]
pub enum Error {
    /// Configuration error.
    #[error("configuration error: {0}")]
    Config(String),

    /// IO error.
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    /// JSON error.
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    /// YAML error.
    #[error("YAML error: {0}")]
    Yaml(#[from] serde_yaml::Error),

    /// HTTP error.
    #[error("HTTP error: {0}")]
    Http(String),

    /// Provider error.
    #[error("provider error: {0}")]
    Provider(String),

    /// Tool error.
    #[error("tool error: {0}")]
    Tool(String),

    /// Session error.
    #[error("session error: {0}")]
    Session(String),

    /// Message error.
    #[error("message error: {0}")]
    Message(String),

    /// Permission denied.
    #[error("permission denied: {0}")]
    PermissionDenied(String),

    /// Not found.
    #[error("not found: {0}")]
    NotFound(String),

    /// Invalid input.
    #[error("invalid input: {0}")]
    InvalidInput(String),

    /// Cancelled.
    #[error("operation cancelled")]
    Cancelled,

    /// Timeout.
    #[error("operation timed out")]
    Timeout,

    /// Ledger error (duplicate, integrity, etc.)
    #[error("ledger error: {0}")]
    Ledger(String),

    /// Duplicate receipt or entry
    #[error("duplicate receipt: {0}")]
    DuplicateReceipt(String),

    /// System time error
    #[error("time error")]
    TimeError,

    /// Role escalation error
    #[error("escalation error: {0}")]
    Escalation(String),

    /// Convergence error
    #[error("convergence error: {0}")]
    Convergence(String),

    /// Other error.
    #[error("{0}")]
    Other(String),
}

impl Error {
    /// Create a new config error.
    pub fn config(msg: impl Into<String>) -> Self {
        Self::Config(msg.into())
    }

    /// Create a new provider error.
    pub fn provider(msg: impl Into<String>) -> Self {
        Self::Provider(msg.into())
    }

    /// Create a new tool error.
    pub fn tool(msg: impl Into<String>) -> Self {
        Self::Tool(msg.into())
    }

    /// Create a new ledger error.
    pub fn ledger(msg: impl Into<String>) -> Self {
        Self::Ledger(msg.into())
    }

    /// Create a duplicate receipt error.
    pub fn duplicate_receipt(id: impl Into<String>) -> Self {
        Self::DuplicateReceipt(id.into())
    }

    /// Create a time error.
    pub fn time_error() -> Self {
        Self::TimeError
    }

    /// Create an escalation error.
    pub fn escalation(msg: impl Into<String>) -> Self {
        Self::Escalation(msg.into())
    }

    /// Create a convergence error.
    pub fn convergence(msg: impl Into<String>) -> Self {
        Self::Convergence(msg.into())
    }

    /// Check if this is a permission denied error.
    pub fn is_permission_denied(&self) -> bool {
        matches!(self, Self::PermissionDenied(_))
    }

    /// Check if this is a cancelled error.
    pub fn is_cancelled(&self) -> bool {
        matches!(self, Self::Cancelled)
    }

    /// Check if this is a timeout error.
    pub fn is_timeout(&self) -> bool {
        matches!(self, Self::Timeout)
    }
}
