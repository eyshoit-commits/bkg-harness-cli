//! **Model** — boot-time model catalog (BKG Catalogus).
//!
//! At bootstrap time we maintain a static model table per provider.
//! This lets Bootstrap Phase 4 (ModelDiscovery) report available models
//! without needing an active API call to each provider.
//!
//! The provider's actual `list_models()` API is called at runtime by the
//! `bkg-provider` crate — this module is for *discovery*, not enumeration.

use crate::provider::ProviderKind;
use std::collections::HashMap;

/// A single model entry in the bootstrap catalog.
#[derive(Debug, Clone)]
pub struct ModelEntry {
    /// Model identifier (e.g. "gpt-4o", "meta/llama-3.3-70b-instruct").
    pub id: String,
    /// Human-readable name.
    pub name: String,
    /// Maximum context length in tokens.
    pub context_length: u32,
    /// Provider that serves this model.
    pub provider: ProviderKind,
    /// Whether this is the recommended default for its provider.
    pub is_default: bool,
}

/// Bootstrap-time model catalog.
///
/// Populated by static model tables. CLI layer may override at runtime
/// by calling the provider's `list_models()` API.
#[derive(Debug, Clone)]
pub struct ModelCatalog {
    models: HashMap<String, Vec<ModelEntry>>,
}

impl ModelCatalog {
    /// Build the catalog from static tables, filtered by available providers.
    pub fn discover(available_providers: &[ProviderKind]) -> Self {
        let mut models: HashMap<String, Vec<ModelEntry>> = HashMap::new();

        for provider in available_providers {
            let entries = get_models_for_provider(provider);
            models.insert(provider.label().to_string(), entries);
        }

        Self { models }
    }

    /// Get all models for a given provider label.
    pub fn for_provider(&self, provider_label: &str) -> Vec<&ModelEntry> {
        self.models
            .get(provider_label)
            .map(|v| v.iter().collect())
            .unwrap_or_default()
    }

    /// Get the catalog as a flat list.
    pub fn all_models(&self) -> Vec<&ModelEntry> {
        self.models.values().flat_map(|v| v.iter()).collect()
    }

    /// Number of providers in the catalog.
    pub fn provider_count(&self) -> usize {
        self.models.len()
    }

    /// Total number of model entries.
    pub fn total_count(&self) -> usize {
        self.models.values().map(|v| v.len()).sum()
    }

    /// Find the default model for the first available provider.
    pub fn get_default(&self) -> Option<&ModelEntry> {
        self.models
            .values()
            .flat_map(|v| v.iter())
            .find(|e| e.is_default)
    }
}

// ── Static model tables ──────────────────────────────────────────────

fn get_models_for_provider(provider: &ProviderKind) -> Vec<ModelEntry> {
    match provider {
        ProviderKind::Nvidia => vec![
            ModelEntry {
                id: "meta/llama-3.3-70b-instruct".into(),
                name: "Llama 3.3 70B Instruct".into(),
                context_length: 131_072,
                provider: ProviderKind::Nvidia,
                is_default: true,
            },
            ModelEntry {
                id: "meta/llama-3.1-405b-instruct".into(),
                name: "Llama 3.1 405B Instruct".into(),
                context_length: 131_072,
                provider: ProviderKind::Nvidia,
                is_default: false,
            },
            ModelEntry {
                id: "mistralai/mistral-large-2411".into(),
                name: "Mistral Large 2411".into(),
                context_length: 131_072,
                provider: ProviderKind::Nvidia,
                is_default: false,
            },
        ],
        ProviderKind::OpenAI => vec![
            ModelEntry {
                id: "gpt-4o".into(),
                name: "GPT-4o".into(),
                context_length: 128_000,
                provider: ProviderKind::OpenAI,
                is_default: true,
            },
            ModelEntry {
                id: "gpt-4o-mini".into(),
                name: "GPT-4o Mini".into(),
                context_length: 128_000,
                provider: ProviderKind::OpenAI,
                is_default: false,
            },
            ModelEntry {
                id: "o1-mini".into(),
                name: "o1 Mini".into(),
                context_length: 128_000,
                provider: ProviderKind::OpenAI,
                is_default: false,
            },
        ],
        ProviderKind::Anthropic => vec![
            ModelEntry {
                id: "claude-3-5-sonnet-20241022".into(),
                name: "Claude 3.5 Sonnet".into(),
                context_length: 200_000,
                provider: ProviderKind::Anthropic,
                is_default: true,
            },
            ModelEntry {
                id: "claude-3-5-haiku-20241022".into(),
                name: "Claude 3.5 Haiku".into(),
                context_length: 200_000,
                provider: ProviderKind::Anthropic,
                is_default: false,
            },
        ],
        ProviderKind::Groq => vec![
            ModelEntry {
                id: "llama-3.3-70b-versatile".into(),
                name: "Llama 3.3 70B Versatile".into(),
                context_length: 131_072,
                provider: ProviderKind::Groq,
                is_default: true,
            },
            ModelEntry {
                id: "llama-3.1-8b-instant".into(),
                name: "Llama 3.1 8B Instant".into(),
                context_length: 131_072,
                provider: ProviderKind::Groq,
                is_default: false,
            },
            ModelEntry {
                id: "mixtral-8x7b-32768".into(),
                name: "Mixtral 8x7B".into(),
                context_length: 32_768,
                provider: ProviderKind::Groq,
                is_default: false,
            },
        ],
        ProviderKind::Gemini => vec![
            ModelEntry {
                id: "gemini-2.0-flash".into(),
                name: "Gemini 2.0 Flash".into(),
                context_length: 1_000_000,
                provider: ProviderKind::Gemini,
                is_default: true,
            },
            ModelEntry {
                id: "gemini-1.5-pro".into(),
                name: "Gemini 1.5 Pro".into(),
                context_length: 2_000_000,
                provider: ProviderKind::Gemini,
                is_default: false,
            },
        ],
        ProviderKind::OpenRouter => vec![
            ModelEntry {
                id: "openai/gpt-4o".into(),
                name: "GPT-4o (OpenRouter)".into(),
                context_length: 128_000,
                provider: ProviderKind::OpenRouter,
                is_default: true,
            },
            ModelEntry {
                id: "anthropic/claude-3.5-sonnet".into(),
                name: "Claude 3.5 Sonnet (OpenRouter)".into(),
                context_length: 200_000,
                provider: ProviderKind::OpenRouter,
                is_default: false,
            },
        ],
        ProviderKind::Ollama => vec![
            ModelEntry {
                id: "qwen2:1.5b-coder".into(),
                name: "Qwen 2 1.5B Coder".into(),
                context_length: 32_768,
                provider: ProviderKind::Ollama,
                is_default: true,
            },
            ModelEntry {
                id: "mistral-7b".into(),
                name: "Mistral 7B".into(),
                context_length: 32_768,
                provider: ProviderKind::Ollama,
                is_default: false,
            },
            ModelEntry {
                id: "llama3.2:3b".into(),
                name: "Llama 3.2 3B".into(),
                context_length: 32_768,
                provider: ProviderKind::Ollama,
                is_default: false,
            },
            ModelEntry {
                id: "deepseek-coder-v2".into(),
                name: "DeepSeek Coder V2".into(),
                context_length: 128_000,
                provider: ProviderKind::Ollama,
                is_default: false,
            },
        ],
        ProviderKind::DeepSeek => vec![
            ModelEntry {
                id: "deepseek-chat".into(),
                name: "DeepSeek Chat".into(),
                context_length: 128_000,
                provider: ProviderKind::DeepSeek,
                is_default: true,
            },
            ModelEntry {
                id: "deepseek-coder".into(),
                name: "DeepSeek Coder".into(),
                context_length: 128_000,
                provider: ProviderKind::DeepSeek,
                is_default: false,
            },
        ],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_discover_empty() {
        let catalog = ModelCatalog::discover(&[]);
        assert_eq!(catalog.provider_count(), 0);
        assert_eq!(catalog.total_count(), 0);
    }

    #[test]
    fn test_discover_single_provider() {
        let catalog = ModelCatalog::discover(&[ProviderKind::Ollama]);
        assert_eq!(catalog.provider_count(), 1);
        assert!(catalog.total_count() > 0);
        assert!(catalog.get_default().is_some());
    }

    #[test]
    fn test_for_provider() {
        let catalog = ModelCatalog::discover(&[ProviderKind::OpenAI]);
        let models = catalog.for_provider("openai");
        assert!(!models.is_empty());
        assert!(models.iter().any(|m| m.id == "gpt-4o"));
    }

    #[test]
    fn test_default_model_selection() {
        let catalog = ModelCatalog::discover(&[ProviderKind::Nvidia, ProviderKind::OpenAI]);
        let default = catalog.get_default().expect("should have default");
        assert!(default.is_default);
        // At least one of the two providers should have its default model selected
        assert!(
            default.provider == ProviderKind::Nvidia || default.provider == ProviderKind::OpenAI,
            "default model provider should be Nvidia or OpenAI, got {:?}",
            default.provider
        );
    }

    #[test]
    fn test_all_models_flat() {
        let catalog = ModelCatalog::discover(&[ProviderKind::Nvidia, ProviderKind::Ollama]);
        let all = catalog.all_models();
        assert_eq!(all.len(), 3 + 4); // Nvidia 3 + Ollama 4
    }

    #[test]
    fn test_nvidia_models() {
        let models = get_models_for_provider(&ProviderKind::Nvidia);
        assert_eq!(models.len(), 3);
        assert!(models.iter().any(|m| m.is_default));
    }
}
