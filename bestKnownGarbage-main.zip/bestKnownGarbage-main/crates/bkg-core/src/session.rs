//! **Aevum** — the ephemeral runtime fire (BKG Reveland).
//!
//! In the Reveland, the session is **Aevum** (Latin for "age/spirit of the age"):
//! the ephemeral runtime context that exists for one execution age then dissipates.
//!
//! **UCC-4 v1.1 binding:** A session is an ephemeral runtime host context
//! bound to exactly one persistent Capsule (Causa). Sessions die; Capsules persist.
//!
//! Types defined here (`SessionId`, `SessionBudget`) are shared across all BKG layers.
//! The kernel-level `Session` (with `workspace_snapshot`, budget, lifecycle state)
//! lives in `bkg-session` — this module provides the CLI conversation model.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Newtype wrapper for a session identifier.
///
/// Contract invariant: Every session has exactly one ID that is unique within
/// the BKG host. Session IDs are human-readable (not opaque UUIDs in display).
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SessionId(pub String);

impl SessionId {
    /// Generate a new unique session ID.
    pub fn new() -> Self {
        Self(format!("sess_{}", Uuid::new_v4().to_string()))
    }
}

impl Default for SessionId {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for SessionId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl From<String> for SessionId {
    fn from(s: String) -> Self {
        Self(s)
    }
}

impl From<&str> for SessionId {
    fn from(s: &str) -> Self {
        Self(s.to_string())
    }
}

/// Budget tracking for a session.
///
/// Tracks both token and USD cost limits/consumption.
/// Limits of 0 mean "no limit" (unbounded).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionBudget {
    /// Maximum tokens allowed (0 = unlimited).
    pub token_limit: u64,
    /// Tokens consumed so far.
    pub tokens_consumed: u64,
    /// Maximum USD cost allowed (0 = unlimited).
    pub cost_limit_usd: f64,
    /// USD cost consumed so far.
    pub cost_consumed_usd: f64,
}

impl SessionBudget {
    /// Create a new budget with the given limits.
    pub fn new(token_limit: u64, cost_limit_usd: f64) -> Self {
        Self {
            token_limit,
            tokens_consumed: 0,
            cost_limit_usd,
            cost_consumed_usd: 0.0,
        }
    }

    /// Check if the budget is exhausted (over token or cost limit).
    pub fn is_exhausted(&self) -> bool {
        (self.token_limit > 0 && self.tokens_consumed >= self.token_limit)
            || (self.cost_limit_usd > 0.0 && self.cost_consumed_usd >= self.cost_limit_usd)
    }
}

impl Default for SessionBudget {
    fn default() -> Self {
        Self::new(0, 0.0)
    }
}

/// Todo status.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TodoStatus {
    /// Todo is pending.
    Pending,
    /// Todo is in progress.
    InProgress,
    /// Todo is completed.
    Completed,
}

impl std::fmt::Display for TodoStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Pending => write!(f, "pending"),
            Self::InProgress => write!(f, "in_progress"),
            Self::Completed => write!(f, "completed"),
        }
    }
}

/// Todo item in a session.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Todo {
    /// Todo content.
    pub content: String,
    /// Todo status.
    pub status: TodoStatus,
    /// Active form of the todo.
    pub active_form: String,
}

impl Todo {
    /// Create a new todo.
    pub fn new(
        content: impl Into<String>,
        status: TodoStatus,
        active_form: impl Into<String>,
    ) -> Self {
        Self {
            content: content.into(),
            status,
            active_form: active_form.into(),
        }
    }
}

/// Session in a conversation.
///
/// A Session is the **host** context that executes one or more UCC-4 Capsules.
/// `active_capsule_id` binds a session to exactly one UCC-4 Capsule.
/// A session is ephemeral — it can die. A Capsule persists.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Session {
    /// Unique session ID.
    pub id: String,
    /// Parent session ID (for sub-sessions).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parent_session_id: Option<String>,
    /// HARD BIND: Every session runs in exactly one UCC-4 Capsule.
    /// Session ≠ Capsule. A session dies; the Capsule persists.
    #[serde(default)]
    pub active_capsule_id: String,
    /// Session title.
    pub title: String,
    /// Number of messages.
    #[serde(default)]
    pub message_count: i64,
    /// Prompt tokens used.
    #[serde(default)]
    pub prompt_tokens: i64,
    /// Completion tokens used.
    #[serde(default)]
    pub completion_tokens: i64,
    /// Whether token counts are estimated.
    #[serde(default)]
    pub estimated_usage: bool,
    /// Summary message ID.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub summary_message_id: Option<String>,
    /// Cost of the session.
    #[serde(default)]
    pub cost: f64,
    /// Todo items.
    #[serde(default)]
    pub todos: Vec<Todo>,
    /// Creation timestamp.
    pub created_at: DateTime<Utc>,
    /// Update timestamp.
    pub updated_at: DateTime<Utc>,
}

impl Session {
    /// Default session name.
    pub const DEFAULT_NAME: &'static str = "Untitled Session";

    /// Create a new session.
    pub fn new() -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4().to_string(),
            parent_session_id: None,
            active_capsule_id: String::new(),
            title: Self::DEFAULT_NAME.to_string(),
            message_count: 0,
            prompt_tokens: 0,
            completion_tokens: 0,
            estimated_usage: false,
            summary_message_id: None,
            cost: 0.0,
            todos: Vec::new(),
            created_at: now,
            updated_at: now,
        }
    }

    /// Create a new session with a title.
    pub fn with_title(title: impl Into<String>) -> Self {
        let mut session = Self::new();
        session.title = title.into();
        session
    }

    /// Get total tokens used.
    pub fn total_tokens(&self) -> i64 {
        self.prompt_tokens + self.completion_tokens
    }

    /// Check if there are incomplete todos.
    pub fn has_incomplete_todos(&self) -> bool {
        self.todos.iter().any(|t| t.status != TodoStatus::Completed)
    }

    /// Hash ID for display.
    pub fn hash_id(&self) -> String {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        self.id.hash(&mut hasher);
        format!("{:x}", hasher.finish())
    }
}

impl Default for Session {
    fn default() -> Self {
        Self::new()
    }
}
