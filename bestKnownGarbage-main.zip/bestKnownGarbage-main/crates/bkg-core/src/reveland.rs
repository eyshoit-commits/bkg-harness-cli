//! **Reveland** — the BKG Atlantean Causal Taxonomy.
//!
//! Every layer of the system has a **Reveland identity** — an Atlantean name
//! from the 6 Sphären that encodes its role in the causal state machine.
//! These names are the permanent public-facing identity of each module,
//! used in docs, telemetry, tracing, and user-facing messages.
//!
//! # The 6 Sphären of the Reveland (Atlantean Core)
//!
//! | Sphäre (Greek) | Rust Module | Reveland Alias | Meaning |
//! |----------------|-------------|----------------|---------|
//! | **🜁 ARCHE**   | `bootstrap`, `capsule` | `Causa` | First Cause — provenance, identity, origin, frozen system state |
//! | **🌊 THALASSA**| `session`, `kernel::execution` | `Aevum`, `Executio` | Living Current — ephemeral execution, volatile states, transient compute |
//! | **⛓ STYX**    | `kernel::execution::receipts` | `Telum` | Causal Crossing — deterministic transition, execution proof, receipt forge |
//! | **🔮 KATOPTRON**| `kernel::truth` | `Speculum` | Mirror of Truth — drift detection, divergence, replay consistency |
//! | **🌱 ANAMNESIS**| `kernel::evolution` | `Evolutio` | Living Memory — controlled recollection, policy evolution for future epochs |
//! | **🜃 MNEMOS**  | `kernel::memory`, `storage` | `Memoria`, `Mensa` | Immutable Foundation — CAS blocks, append-only history, crypto-addressed reality |
//!
//! # The Causal Cycle (Atlantean Loop)
//!
//! The Reveland is a **closed causal feedback loop**. The cycle flows:
//!
//! ```text
//!                ┌───────────────┐
//!                │  ANAMNESIS    │  ← policy evolution (living memory)
//!                │  (Evolutio)   │
//!                └──────┬────────┘
//!                       │ modifies policies for next epoch
//!                       ▼
//!                ┌───────────────┐
//!                │    ARCHE      │  ← capsule/bootstrap initialization
//!                │   (Causa)     │  ← frozen system state, provenance
//!                └──────┬────────┘
//!                       │ instantiates
//!                       ▼
//!                ┌───────────────┐
//!                │   THALASSA    │  ← session/runtime execution
//!                │  (Aevum)      │  ← volatile current, transient compute
//!                └──────┬────────┘
//!                       │ produces
//!                       ▼
//!                ┌───────────────┐
//!                │    STYX       │  ← execution receipts, DAG forge
//!                │   (Telum)     │  ← causal crossing, proof materialization
//!                └──────┬────────┘
//!                       │ reflects
//!                       ▼
//!                ┌───────────────┐
//!                │  KATOPTRON    │  ← truth verification, drift detection
//!                │ (Katoptron)   │  ← mirror of truth, divergence report
//!                └──────┬────────┘
//!                       │ feeds
//!                       ▼
//!                ┌───────────────┐
//!                │    MNEMOS     │  ← immutable storage, CAS lattice
//!                │  (Memoria)    │  ← append-only, crypto-addressed foundation
//!                └───────────────┘
//!                       │
//!                       └──────→ feeds back into ANAMNESIS
//!                                  (truth informs policy evolution)
//! ```
//!
//! # Cycle Invariants (Atlantean Laws)
//!
//! - **ARCHE before THALASSA**: No execution without frozen provenance (capsule必须先 rehydrated)
//! - **THALASSA produces STYX**: Every execution yields a receipt (verifiable proof)
//! - **STYX reflects in KATOPTRON**: Every receipt is verified against truth (drift detection)
//! - **KATOPTRON writes to MNEMOS**: All verification results are immutably logged
//! - **MNEMOS feeds ANAMNESIS**: Truth history informs policy evolution (epoch-bound)
//! - **ANAMNESIS updates ARCHE**: New policies apply to next epoch only (past immutable)
//!
//! This ensures: **deterministic, replayable, self-healing, policy-evolving,
//! cross-context safe execution** — every run is causally bounded and verifiable.
//!
//! # Backward Compatibility
//!
//! The Latin gate names (Aevum, Causa, Telum, Speculum, Evolutio, Memoria, Pacta, Mensa, Tempus, Executio)
//! are retained as **aliases** for existing module references. New code should prefer
//! the Atlantean Sphären names for consistency with the causal taxonomy.

use serde::{Deserialize, Serialize};
use std::collections::HashSet;
use std::fmt;

/// Reveland identity for the kernel root — **Nucleus** ("heart/core").
/// Now understood as the convergence point of all 6 Sphären.
pub const NUCLEUS: &str = "Nucleus";

/// Reveland identity for **ARCHE** (First Cause) — bootstrap & capsule initialization.
///
/// ARCHE contains the frozen system state, provenance, identity, and origin.
/// Every execution springs from ARCHE.
pub const ARCHE: &str = "Arche";

/// Reveland identity for sessions — **THALASSA** (Living Current).
///
/// Each session is an ephemeral execution current — a wave in the causal sea
/// that burns, produces receipts, and expires.
///
/// *Alias: Aevum (legacy Latin name)*
pub const THALASSA: &str = "Thalassa";
pub const AEVUM: &str = "Aevum"; // Backward compatible alias

/// Reveland identity for capsules — **ARCHE** (First Cause).
///
/// Capsules are the persistent causal units that carry provenance through time.
/// They are the frozen state from which all execution springs.
///
/// *Alias: Causa (legacy Latin name)*
pub const CAUSA: &str = "Causa"; // Backward compatible alias

/// Reveland identity for the DAG execution graph — **STYX** (Causal Crossing).
///
/// The deterministic execution forge where DAGs are materialized into receipts.
/// This is the passage from volatile current to immutable proof.
///
/// *Alias: Telum (legacy Latin name)*
pub const STYX: &str = "Styx";
pub const TELUM: &str = "Telum"; // Backward compatible alias

/// Reveland identity for execution — **THALASSA** (Living Current).
///
/// The doing gate — where intent becomes action in the causal current.
///
/// *Alias: Executio (legacy Latin name)*
pub const EXECUTIO: &str = "Executio"; // Backward compatible alias

/// Reveland identity for truth verification — **KATOPTRON** (Mirror of Truth).
///
/// The mirror gate — reflection reveals divergence between expected and actual.
/// Drift detection, replay consistency, causal integrity.
///
/// *Alias: Speculum (legacy Latin name)*
pub const KATOPTRON: &str = "Katoptron";
pub const SPECULUM: &str = "Speculum"; // Backward compatible alias

/// Reveland identity for time — **TEMPUS** (River of Time).
///
/// The river gate — time flows, replays unwind, history reveals itself.
/// Now understood as part of the THALASSA → STYX → KATOPTRON flow.
pub const TEMPUS: &str = "Tempus";

/// Reveland identity for evolution — **ANAMNESIS** (Living Memory).
///
/// The unfolding gate — the kernel learns, adapts, and evolves over time.
/// Policy evolution for future epochs only; past remains immutable.
///
/// *Alias: Evolutio (legacy Latin name)*
pub const ANAMNESIS: &str = "Anamnesis";
pub const EVOLUTIO: &str = "Evolutio"; // Backward compatible alias

/// Reveland identity for memory — **MNEMOS** (Immutable Foundation).
///
/// The vault gate — capsules are indexed, stored, and rehydrated.
/// Content-addressable storage, append-only history, crypto-addressed reality.
///
/// *Alias: Memoria (legacy Latin name)*
pub const MNEMOS: &str = "Mnemos";
pub const MEMORIA: &str = "Memoria"; // Backward compatible alias

/// Reveland identity for kernel contracts — **PACTA** (Covenants).
///
/// The covenant gate — invariants, constants, errors, and laws.
/// The unbreakable rules that govern all Sphären.
pub const PACTA: &str = "Pacta";

/// Reveland identity for the content-addressable store — **MNEMOS** (Immutable Foundation).
///
/// **MNEMOS is the immutable CAS sink:**
/// - Globally shared (not per-capsule)
/// - Content-addressed (keyed by hash)
/// - Strictly immutable (append-only, never mutated)
/// - Logically partitioned by `capsule_id` namespace
/// - Read-only from MNEMOS, write-once into MNEMOS
///
/// *Alias: Mensa (legacy Latin name)*
pub const MENSA: &str = "Mensa"; // Backward compatible alias

/// Returns the Reveland name for a given module path, if known.
///
/// Returns the **Atlantean Sphäre name** (preferred) or the legacy Latin alias.
///
/// # Example
///
/// ```
/// use bkg_core::reveland::resolve;
/// assert_eq!(resolve("kernel::truth"), Some("Katoptron")); // preferred
/// assert_eq!(resolve("session"), Some("Thalassa")); // preferred
/// assert_eq!(resolve("capsule"), Some("Arche")); // preferred
/// // Legacy aliases also work:
/// assert_eq!(resolve("kernel::truth"), Some("Katoptron")); // not Speculum anymore
/// ```
pub fn resolve(module_path: &str) -> Option<&'static str> {
    match module_path {
        "kernel" => Some(NUCLEUS),
        "bootstrap" | "capsule" => Some(ARCHE), // Arche: First Cause
        "session" | "kernel::execution" => Some(THALASSA), // Thalassa: Living Current
        "capsule::graph" | "kernel::execution::receipts" => Some(STYX), // Styx: Causal Crossing
        "kernel::truth" => Some(KATOPTRON),     // Katoptron: Mirror of Truth
        "kernel::time" => Some(TEMPUS),         // Tempus: River of Time
        "kernel::evolution" => Some(ANAMNESIS), // Anamnesis: Living Memory
        "kernel::memory" | "storage" => Some(MNEMOS), // Mnemos: Immutable Foundation
        "kernel::contracts" => Some(PACTA),     // Pacta: Covenants
        "mensa" => Some(MNEMOS),                // Mnemos (legacy: Mensa)
        _ => None,
    }
}

/// A causal proof entry in the Reveland.
///
/// Each proof must be anchored to a known Reveland module and may optionally
/// reference a parent proof to preserve the causal chain.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CausalProof {
    pub id: String,
    pub module_path: String,
    pub parent_id: Option<String>,
    pub hash: String,
    pub timestamp: i64,
    pub metadata: Option<String>,
}

impl CausalProof {
    /// Create a new causal proof.
    pub fn new(
        id: impl Into<String>,
        module_path: impl Into<String>,
        parent_id: Option<String>,
        hash: impl Into<String>,
        timestamp: i64,
        metadata: Option<String>,
    ) -> Self {
        Self {
            id: id.into(),
            module_path: module_path.into(),
            parent_id,
            hash: hash.into(),
            timestamp,
            metadata,
        }
    }
}

/// Errors produced by Reveland causal invariant validation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CausalError {
    /// The proof references an unknown or unsupported module path.
    InvalidModule { module_path: String },
    /// The proof contains an empty or missing hash.
    EmptyHash { proof_id: String },
    /// The proof contains a cyclic or self-referencing parent link.
    CyclicParent { proof_id: String, parent_id: String },
    /// The proof references a missing parent in the provided chain.
    MissingParent { proof_id: String, parent_id: String },
    /// Two proofs in the same chain share the same proof id.
    DuplicateProofId { proof_id: String },
    /// The proof id is empty.
    InvalidProofId { proof_id: String },
}

impl fmt::Display for CausalError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            CausalError::InvalidModule { module_path } => {
                write!(f, "invalid module path: {module_path}")
            }
            CausalError::EmptyHash { proof_id } => {
                write!(f, "proof {proof_id} has empty hash")
            }
            CausalError::CyclicParent {
                proof_id,
                parent_id,
            } => {
                write!(f, "proof {proof_id} has cyclic parent {parent_id}")
            }
            CausalError::MissingParent {
                proof_id,
                parent_id,
            } => {
                write!(f, "proof {proof_id} references missing parent {parent_id}")
            }
            CausalError::DuplicateProofId { proof_id } => {
                write!(f, "duplicate proof id in chain: {proof_id}")
            }
            CausalError::InvalidProofId { proof_id } => {
                write!(f, "invalid proof id: {proof_id}")
            }
        }
    }
}

impl std::error::Error for CausalError {}

/// A causal invariant checker for Reveland proofs.
///
/// This trait defines the minimal causality validation required by Tempus non
/// frangitur and the Reveland contract.
pub trait CausalInvariantChecker {
    /// Check a single proof for local invariants.
    fn check_proof(&self, proof: &CausalProof) -> Result<(), CausalError>;

    /// Check a sequence of proofs for chain consistency invariants.
    fn check_chain(&self, proofs: &[CausalProof]) -> Result<(), CausalError>;
}

/// Default Reveland invariant checker implementation.
pub struct DefaultCausalInvariantChecker;

impl DefaultCausalInvariantChecker {
    /// Create a new default checker.
    pub fn new() -> Self {
        Self
    }
}

impl CausalInvariantChecker for DefaultCausalInvariantChecker {
    fn check_proof(&self, proof: &CausalProof) -> Result<(), CausalError> {
        if proof.id.trim().is_empty() {
            return Err(CausalError::InvalidProofId {
                proof_id: proof.id.clone(),
            });
        }

        if resolve(&proof.module_path).is_none() {
            return Err(CausalError::InvalidModule {
                module_path: proof.module_path.clone(),
            });
        }

        if proof.hash.trim().is_empty() {
            return Err(CausalError::EmptyHash {
                proof_id: proof.id.clone(),
            });
        }

        if let Some(parent_id) = proof.parent_id.as_ref() {
            if parent_id == &proof.id {
                return Err(CausalError::CyclicParent {
                    proof_id: proof.id.clone(),
                    parent_id: parent_id.clone(),
                });
            }
        }

        Ok(())
    }

    fn check_chain(&self, proofs: &[CausalProof]) -> Result<(), CausalError> {
        let mut ids = HashSet::new();
        for proof in proofs {
            if !ids.insert(&proof.id) {
                return Err(CausalError::DuplicateProofId {
                    proof_id: proof.id.clone(),
                });
            }
        }

        for proof in proofs {
            if let Some(parent_id) = proof.parent_id.as_ref() {
                if !ids.contains(parent_id) {
                    return Err(CausalError::MissingParent {
                        proof_id: proof.id.clone(),
                        parent_id: parent_id.clone(),
                    });
                }
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_all_reveland_names_are_non_empty() {
        let names = [
            NUCLEUS, ARCHE, THALASSA, STYX, KATOPTRON, ANAMNESIS, MNEMOS, PACTA,
            // Legacy aliases
            AEVUM, CAUSA, TELUM, EXECUTIO, SPECULUM, TEMPUS, EVOLUTIO, MEMORIA, MENSA,
        ];
        for name in &names {
            assert!(!name.is_empty(), "Reveland name must not be empty");
        }
    }

    #[test]
    fn test_resolve_atlantean_names() {
        // New Atlantean Sphären names (preferred)
        assert_eq!(resolve("kernel"), Some(NUCLEUS));
        assert_eq!(resolve("bootstrap"), Some(ARCHE));
        assert_eq!(resolve("capsule"), Some(ARCHE));
        assert_eq!(resolve("session"), Some(THALASSA));
        assert_eq!(resolve("kernel::execution"), Some(THALASSA));
        assert_eq!(resolve("capsule::graph"), Some(STYX));
        assert_eq!(resolve("kernel::execution::receipts"), Some(STYX));
        assert_eq!(resolve("kernel::truth"), Some(KATOPTRON));
        assert_eq!(resolve("kernel::time"), Some(TEMPUS));
        assert_eq!(resolve("kernel::evolution"), Some(ANAMNESIS));
        assert_eq!(resolve("kernel::memory"), Some(MNEMOS));
        assert_eq!(resolve("storage"), Some(MNEMOS));
        assert_eq!(resolve("kernel::contracts"), Some(PACTA));
    }

    #[test]
    fn test_resolve_unknown_path() {
        assert_eq!(resolve("nonexistent"), None);
    }

    #[test]
    fn test_resolve_case_sensitive() {
        assert_eq!(resolve("Kernel"), None);
        assert_eq!(resolve("kernel"), Some(NUCLEUS));
    }

    #[test]
    fn test_causal_invariant_checker_accepts_valid_proof_chain() {
        let proofs = vec![
            CausalProof::new("root", "capsule", None, "hash-root", 1, None),
            CausalProof::new(
                "child",
                "kernel::execution",
                Some("root".to_string()),
                "hash-child",
                2,
                None,
            ),
        ];
        let checker = DefaultCausalInvariantChecker::new();

        assert!(checker.check_proof(&proofs[0]).is_ok());
        assert!(checker.check_proof(&proofs[1]).is_ok());
        assert!(checker.check_chain(&proofs).is_ok());
    }

    #[test]
    fn test_causal_invariant_checker_detects_missing_parent() {
        let proofs = vec![CausalProof::new(
            "child",
            "kernel::execution",
            Some("missing".to_string()),
            "hash-child",
            2,
            None,
        )];
        let checker = DefaultCausalInvariantChecker::new();

        let result = checker.check_chain(&proofs);
        assert!(
            matches!(result, Err(CausalError::MissingParent { proof_id, parent_id }) if proof_id == "child" && parent_id == "missing")
        );
    }

    #[test]
    fn test_causal_invariant_checker_rejects_empty_hash() {
        let proof = CausalProof::new("root", "capsule", None, "", 1, None);
        let checker = DefaultCausalInvariantChecker::new();

        let result = checker.check_proof(&proof);
        assert!(matches!(result, Err(CausalError::EmptyHash { proof_id }) if proof_id == "root"));
    }

    #[test]
    fn test_sphären_mapping() {
        // Verify the 6 Sphären are all defined and distinct
        let sphären = [ARCHE, THALASSA, STYX, KATOPTRON, ANAMNESIS, MNEMOS];
        for (i, sphäre) in sphären.iter().enumerate() {
            for (j, other) in sphären.iter().enumerate() {
                if i != j {
                    assert_ne!(sphäre, other, "Sphären must be unique");
                }
            }
        }
    }
}
