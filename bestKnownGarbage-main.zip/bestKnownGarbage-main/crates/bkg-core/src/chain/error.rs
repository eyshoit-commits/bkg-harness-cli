//! Chain error types.

use crate::BkgError;

/// Errors that can occur during chain execution.
#[derive(Debug, thiserror::Error)]
pub enum ChainError {
    /// A link failed the truth gate
    #[error("Link '{link_id}' failed truth: {reason}")]
    TruthFailed { link_id: String, reason: String },

    /// Budget exhausted during execution
    #[error("Budget exhausted for chain '{chain_id}': {message}")]
    BudgetExhausted { chain_id: String, message: String },

    /// No provider available for the assigned model
    #[error("No provider available for model '{model}' on link '{link_id}'")]
    NoProvider { link_id: String, model: String },

    /// Context size exceeded
    #[error("Context overflow in chain '{chain_id}': {current} > {max} tokens")]
    ContextOverflow {
        chain_id: String,
        current: u64,
        max: u64,
    },

    /// A required skill was not found
    #[error("Skill '{skill}' required for link '{link_id}' but not loaded")]
    MissingSkill { link_id: String, skill: String },

    /// Underlying BKG error
    #[error(transparent)]
    Bkg(#[from] BkgError),
}
