//! ExecutionReceipt — signed ledger entry for a completed chain.
//!
//! A receipt is the single source of truth for what happened during a chain
//! execution. It is created AFTER the chain completes (or fails) and contains
//! summary metrics, cost, truth score, and references to all artifacts.
//!
//! Receipts are immutable once written. They serve as:
//! - Audit trail ("what happened and when")
//! - Dataset filter ("only chains with truth_score > 0.9")
//! - Cost tracking ("how many tokens did this week's chains use?")
//! - Replay source ("re-run chain X with current models")

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Summary metadata about a stored chain (used for listing without deserializing).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ChainMeta {
    /// Chain identifier
    pub id: String,
    /// Original prompt
    pub prompt: String,
    /// Chain status as string ("completed", "failed", etc.)
    pub status: String,
    /// Number of links in the chain
    pub link_count: usize,
    /// Number of links that passed truth
    pub passed_links: usize,
    /// Number of links that failed truth
    pub failed_links: usize,
    /// ISO 8601 creation timestamp
    pub created_at: String,
    /// Total duration in seconds (0 if not completed)
    pub duration_secs: f64,
}

/// Execution receipt — the immutable record of a chain execution.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecutionReceipt {
    /// Unique receipt identifier (matches chain id by convention)
    pub receipt_id: String,
    /// The chain this receipt covers
    pub chain_id: String,
    /// If this is a replay, the original chain id
    pub replay_of: Option<String>,

    /// When the receipt was created
    pub created_at: DateTime<Utc>,
    /// When the chain completed (or failed)
    pub completed_at: Option<DateTime<Utc>>,

    /// Provider used (e.g., "nvidia", "ollama")
    pub provider: String,
    /// Models used per role/link (in order)
    pub model_matrix: Vec<String>,

    /// Total tokens consumed across all links
    pub total_tokens: u64,
    /// Estimated total cost in USD
    pub total_cost: f64,

    /// Truth score (0.0 – 1.0): fraction of links that passed
    pub truth_score: f64,

    /// Files touched by the chain (via SWD snapshots)
    pub touched_files: Vec<String>,
    /// SHA256 of the entire chain JSON output
    pub output_hash: String,
    /// SHA256 of the manifest
    pub manifest_hash: String,

    /// Did the entire chain pass verification?
    pub verification_passed: bool,

    /// File path reference to the full truth report
    pub truth_report_ref: String,
    /// File path references to per-link snapshots
    pub snapshot_refs: Vec<String>,
}

impl ExecutionReceipt {
    /// Create a new execution receipt.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        chain_id: String,
        provider: String,
        model_matrix: Vec<String>,
        total_tokens: u64,
        total_cost: f64,
        truth_score: f64,
        verification_passed: bool,
    ) -> Self {
        Self {
            receipt_id: chain_id.clone(),
            chain_id,
            replay_of: None,
            created_at: Utc::now(),
            completed_at: None,
            provider,
            model_matrix,
            total_tokens,
            total_cost,
            truth_score,
            touched_files: Vec::new(),
            output_hash: String::new(),
            manifest_hash: String::new(),
            verification_passed,
            truth_report_ref: String::new(),
            snapshot_refs: Vec::new(),
        }
    }

    /// Mark this receipt as a replay of another chain.
    pub fn with_replay_of(mut self, original_id: String) -> Self {
        self.replay_of = Some(original_id);
        self
    }

    /// Set the completion timestamp.
    pub fn mark_completed(&mut self) {
        self.completed_at = Some(Utc::now());
    }

    /// Add a touched file.
    pub fn add_touched_file(&mut self, path: String) {
        self.touched_files.push(path);
    }
}
