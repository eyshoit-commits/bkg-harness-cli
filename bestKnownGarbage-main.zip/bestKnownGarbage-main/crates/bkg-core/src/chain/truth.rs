//! Truth Gate — the final authority on whether work is real.
//!
//! Every link in a chain passes through the Truth Gate before the chain
//! may proceed. The gate checks: was the work verified? Was it snapshotted?
//! Did it stay within budget? Is there no file drift?
//!
//! If truth fails, the link is re-executed. No exceptions.
//!
//! # Versioning
//!
//! TruthReport carries a `schema_version` field for forward compatibility.
//! Current version: 1.
//! Bump this when adding/removing fields to existing persisted reports.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::time::Duration;

/// Current schema version for TruthReport.
pub const TRUTH_SCHEMA_VERSION: u32 = 1;

/// What the Truth Gate actually checked.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum TruthCheck {
    /// bkg-verify confirmed the work is correct
    VerifyPassed,
    /// SWD snapshot was taken before any write
    SWDSnapshotTaken,
    /// Token budget was respected
    BudgetRespected,
    /// Context from previous link was preserved (no topic drift)
    ContextPreserved,
    /// No files changed outside the intended scope
    NoFileDrift,
    /// All tool calls completed without error
    ToolCallSuccess,
    /// The output matches the expected format
    OutputValid,
}

impl std::fmt::Display for TruthCheck {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TruthCheck::VerifyPassed => write!(f, "verify passed"),
            TruthCheck::SWDSnapshotTaken => write!(f, "swd snapshot"),
            TruthCheck::BudgetRespected => write!(f, "budget ok"),
            TruthCheck::ContextPreserved => write!(f, "context intact"),
            TruthCheck::NoFileDrift => write!(f, "no file drift"),
            TruthCheck::ToolCallSuccess => write!(f, "tools ok"),
            TruthCheck::OutputValid => write!(f, "output valid"),
        }
    }
}

/// The verdict of the Truth Gate for one link.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TruthVerdict {
    /// Did ALL checks pass?
    pub passed: bool,
    /// Which checks were performed and their results
    pub checks: Vec<(TruthCheck, bool)>,
    /// When the verdict was issued
    pub timestamp: DateTime<Utc>,
    /// Human-readable explanation if failed
    pub failure_reason: Option<String>,
}

impl TruthVerdict {
    /// Create a passing verdict (all checks passed).
    pub fn pass(checks: Vec<TruthCheck>) -> Self {
        let check_results: Vec<_> = checks.into_iter().map(|c| (c, true)).collect();
        Self {
            passed: true,
            checks: check_results,
            timestamp: Utc::now(),
            failure_reason: None,
        }
    }

    /// Create a failing verdict.
    pub fn fail(reason: impl Into<String>) -> Self {
        Self {
            passed: false,
            checks: Vec::new(),
            timestamp: Utc::now(),
            failure_reason: Some(reason.into()),
        }
    }

    /// Add a failed check to the verdict.
    pub fn with_failed_check(mut self, check: TruthCheck, reason: impl Into<String>) -> Self {
        self.checks.push((check, false));
        self.passed = false;
        self.failure_reason = Some(reason.into());
        self
    }

    /// Add a passed check to the verdict.
    pub fn with_passed_check(mut self, check: TruthCheck) -> Self {
        self.checks.push((check, true));
        self
    }
}

/// Full truth report for an entire chain.
///
/// Schema versioning ensures forward compatibility when loading
/// previously persisted reports.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TruthReport {
    /// Schema version for forward compatibility
    pub schema_version: u32,
    /// Verifier implementation version
    pub verifier_version: String,
    /// Chain identifier
    pub chain_id: String,
    /// Verdicts per link (in order)
    pub link_verdicts: Vec<TruthVerdict>,
    /// Did the entire chain pass truth?
    pub chain_passed: bool,
    /// When the report was generated
    pub generated_at: DateTime<Utc>,
    /// Total duration in seconds (serialization-friendly)
    pub total_duration_secs: f64,
}

impl TruthReport {
    /// Create a new truth report for the given chain.
    pub fn new(chain_id: String) -> Self {
        Self {
            schema_version: TRUTH_SCHEMA_VERSION,
            verifier_version: env!("CARGO_PKG_VERSION").to_string(),
            chain_id,
            link_verdicts: Vec::new(),
            chain_passed: true,
            generated_at: Utc::now(),
            total_duration_secs: 0.0,
        }
    }

    /// Add a link's verdict.
    pub fn add_verdict(&mut self, verdict: TruthVerdict) {
        if !verdict.passed {
            self.chain_passed = false;
        }
        self.link_verdicts.push(verdict);
    }

    /// Mark chain duration from a std Duration.
    pub fn set_duration(&mut self, duration: Duration) {
        self.total_duration_secs = duration.as_secs_f64();
    }

    /// Get the duration as std Duration.
    pub fn duration(&self) -> Duration {
        Duration::from_secs_f64(self.total_duration_secs)
    }

    /// Number of passed links.
    pub fn passed_links(&self) -> usize {
        self.link_verdicts.iter().filter(|v| v.passed).count()
    }

    /// Number of failed links.
    pub fn failed_links(&self) -> usize {
        self.link_verdicts.iter().filter(|v| !v.passed).count()
    }

    /// Truth score as a fraction (0.0 – 1.0).
    pub fn score(&self) -> f64 {
        let total = self.link_verdicts.len();
        if total == 0 {
            return 1.0;
        }
        self.passed_links() as f64 / total as f64
    }
}

impl std::fmt::Display for TruthReport {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        writeln!(
            f,
            "═══ TRUTH REPORT [{}] (v{}) ═══",
            self.chain_id, self.schema_version
        )?;
        for (i, verdict) in self.link_verdicts.iter().enumerate() {
            let status = if verdict.passed {
                "✓ PASS"
            } else {
                "✗ FAIL"
            };
            writeln!(f, "  Link {}: {status}", i + 1)?;
            for (check, ok) in &verdict.checks {
                let icon = if *ok { "  ✓" } else { "  ✗" };
                writeln!(f, "    {icon} {check}")?;
            }
            if let Some(reason) = &verdict.failure_reason {
                writeln!(f, "    Reason: {reason}")?;
            }
        }
        let overall = if self.chain_passed {
            "✓ ALL PASS"
        } else {
            "✗ FAILED"
        };
        writeln!(
            f,
            "═══ {overall} (score: {:.2}, {:.1}s) ═══",
            self.score(),
            self.total_duration_secs
        )
    }
}
