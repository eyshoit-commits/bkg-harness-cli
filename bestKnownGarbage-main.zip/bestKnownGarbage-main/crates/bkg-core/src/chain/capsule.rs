//! TruthCapsule — self-healing, immutable, replayable execution capsule.
//!
//! A TruthCapsule wraps a Chain + Receipt + Truth + Memory + Snapshots
//! into one cohesive artifact that can verify itself, heal itself, and
//! be replayed deterministically.
//!
//! # Capsule Layout
//!
//! ```text
//! ~/.bkg/capsules/
//! └── cap-<id>/
//!     ├── capsule.json     ← TruthCapsule metadata + integrity checks
//!     ├── chain.json       ← The frozen Chain (with hashes per link)
//!     ├── receipt.json     ← ExecutionReceipt (cost, truth score, provider)
//!     ├── truth.json       ← TruthReport (schema-versioned)
//!     ├── manifest.sha256  ← Cryptographic manifest of all files
//!     ├── memory/
//!     │   └── MEMORY.md    ← SOLE AUTHORITY (NOT sqlite!)
//!     ├── snapshots/       ← Per-link SWD snapshots
//!     │   ├── link-1.json
//!     │   └── ...
//!     ├── tools/           ← Tool call logs
//!     ├── providers/       ← Provider config snapshot
//!     ├── replay/          ← Cached replay results
//!     ├── datasets/        ← Export-ready truth data
//!     └── audit/           ← Audit trail entries
//! ```
//!
//! # MEMORY.md is Sole Authority
//!
//! SQLite indexes are DERIVATIVE — they can be rebuilt. MEMORY.md is the
//! canonical truth because it's:
//! - Human-readable
//! - Git-friendly (diffable, mergable)
//! - Portable (no binary format)
//! - Recoverable (grep through markdown)

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Current capsule schema version.
pub const CAPSULE_SCHEMA_VERSION: u32 = 1;

/// The state of a TruthCapsule.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum CapsuleState {
    /// Chain is currently executing
    Active,
    /// All links passed truth, chain is frozen
    Completed,
    /// A link failed truth and couldn't be recovered
    Failed,
    /// Integrity check found corruption
    Corrupted,
    /// Capsule was repaired after corruption
    Repaired,
    /// Archived for long-term storage
    Archived,
    /// This capsule is a replay of another chain
    Replay,
}

/// A self-healing, immutable execution capsule.
///
/// This is the top-level container for all chain execution artifacts.
/// Once `immutable` is set, no structural changes are allowed.
/// `self_healing` controls whether auto-repair is attempted on load.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TruthCapsule {
    /// Unique capsule identifier (e.g., "cap-7f91")
    pub capsule_id: String,
    /// Current lifecycle state
    pub state: CapsuleState,
    /// Schema version
    pub schema_version: u32,

    // ── References ──
    /// Chain ID reference
    pub chain_ref: String,
    /// Receipt file reference
    pub receipt_ref: String,
    /// Truth report file reference
    pub truth_ref: String,
    /// Memory file reference (MEMORY.md path)
    pub memory_ref: String,

    // ── Integrity ──
    /// SHA256 of the canonical manifest
    pub manifest_hash: String,
    /// Timestamp of last integrity verification
    pub last_verified_at: Option<DateTime<Utc>>,

    // ── Capabilities ──
    /// Can this capsule be deterministically replayed?
    pub replayable: bool,
    /// Is this capsule frozen against mutation?
    pub immutable: bool,
    /// Should auto-healing be attempted on load?
    pub self_healing: bool,

    // ── Provenance ──
    /// When the capsule was created
    pub created_at: DateTime<Utc>,
    /// When the capsule was last modified
    pub updated_at: DateTime<Utc>,
    /// Original chain ID if this is a replay
    pub replay_of: Option<String>,
}

impl TruthCapsule {
    /// Create a new active capsule.
    pub fn new(capsule_id: String, chain_id: String) -> Self {
        Self {
            capsule_id,
            schema_version: CAPSULE_SCHEMA_VERSION,
            state: CapsuleState::Active,
            chain_ref: chain_id.clone(),
            receipt_ref: format!("{}/receipt.json", chain_id),
            truth_ref: format!("{}/truth.json", chain_id),
            memory_ref: format!("{}/memory/MEMORY.md", chain_id),
            manifest_hash: String::new(),
            last_verified_at: None,
            replayable: true,
            immutable: false,
            self_healing: true,
            created_at: Utc::now(),
            updated_at: Utc::now(),
            replay_of: None,
        }
    }

    /// Mark this capsule as a replay of another.
    pub fn with_replay(mut self, original_id: String) -> Self {
        self.replay_of = Some(original_id);
        self.state = CapsuleState::Replay;
        self
    }

    /// Freeze the capsule (makes it immutable).
    pub fn freeze(&mut self) {
        self.immutable = true;
        self.updated_at = Utc::now();
    }

    /// Mark as completed.
    pub fn mark_completed(&mut self, manifest_hash: String) {
        self.state = CapsuleState::Completed;
        self.manifest_hash = manifest_hash;
        self.immutable = true;
        self.updated_at = Utc::now();
    }

    /// Mark as failed.
    pub fn mark_failed(&mut self) {
        self.state = CapsuleState::Failed;
        self.updated_at = Utc::now();
    }

    /// Record that integrity verification was done.
    pub fn mark_verified(&mut self) {
        self.last_verified_at = Some(Utc::now());
    }

    /// Mark as repaired after corruption.
    pub fn mark_repaired(&mut self) {
        self.state = CapsuleState::Repaired;
        self.updated_at = Utc::now();
    }

    /// Mark as archived.
    pub fn mark_archived(&mut self) {
        self.state = CapsuleState::Archived;
        self.updated_at = Utc::now();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_capsule_creation() {
        let c = TruthCapsule::new("cap-1".into(), "ch-1".into());
        assert_eq!(c.state, CapsuleState::Active);
        assert!(c.self_healing);
        assert!(!c.immutable);
    }

    #[test]
    fn test_capsule_freeze() {
        let mut c = TruthCapsule::new("cap-2".into(), "ch-2".into());
        c.freeze();
        assert!(c.immutable);
    }

    #[test]
    fn test_capsule_completed() {
        let mut c = TruthCapsule::new("cap-3".into(), "ch-3".into());
        c.mark_completed("abc123".into());
        assert_eq!(c.state, CapsuleState::Completed);
        assert!(c.immutable);
        assert_eq!(c.manifest_hash, "abc123");
    }

    #[test]
    fn test_capsule_replay() {
        let c = TruthCapsule::new("cap-replay".into(), "ch-4".into())
            .with_replay("cap-original".into());
        assert_eq!(c.state, CapsuleState::Replay);
        assert_eq!(c.replay_of, Some("cap-original".into()));
    }

    #[test]
    fn test_capsule_state_serialization() {
        let states = vec![
            CapsuleState::Active,
            CapsuleState::Completed,
            CapsuleState::Failed,
            CapsuleState::Corrupted,
            CapsuleState::Repaired,
            CapsuleState::Archived,
            CapsuleState::Replay,
        ];
        for s in &states {
            let json = serde_json::to_string(s).unwrap();
            let back: CapsuleState = serde_json::from_str(&json).unwrap();
            assert_eq!(*s, back);
        }
    }
}
