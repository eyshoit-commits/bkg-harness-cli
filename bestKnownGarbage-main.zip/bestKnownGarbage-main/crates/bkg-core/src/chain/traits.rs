//! Traits for chain execution and truth verification.
//!
//! `LinkExecutor` — knows how to run a single link through all 9 stages.
//! `TruthVerifier` — checks that a completed link is actually true.
//!
//! These traits live in bkg-core so the data model is self-contained.
//! Concrete implementations live in bkg-cli where all subsystems are available.

use super::{Link, LinkResult, TruthVerdict};
use crate::BkgError;

/// Execute ONE link in the chain.
///
/// The implementor is responsible for orchestrating:
///   1. session.start    6. tools.execute
///   2. budget.alloc     7. swd.snapshot
///   3. skills.inject    8. memory.store
///   4. agent.route      9. verify.check
///   5. provider.chat
///
/// Each execution is sequential and receives the accumulated context
/// from all previous links, preventing topic drift.
#[async_trait::async_trait]
pub trait LinkExecutor: Send + Sync {
    /// Run one link and return the result + truth verdict.
    async fn execute(
        &self,
        link: &Link,
        chain_id: &str,
    ) -> std::result::Result<(LinkResult, TruthVerdict), BkgError>;
}

/// Verify that a completed link is actually true.
///
/// Runs after every link execution. If truth fails, the link must be
/// re-executed before the chain can proceed.
#[async_trait::async_trait]
pub trait TruthVerifier: Send + Sync {
    /// Check whether the link's output is truthful.
    async fn verify(&self, link: &Link, result: &LinkResult) -> TruthVerdict;
}
