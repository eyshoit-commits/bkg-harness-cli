//! Manifest — cryptographic summary of a chain's execution.
//!
//! A manifest contains SHA256 hashes of all critical chain data:
//! - Original prompt
//! - Per-link hashes (prompt, output, truth)
//! - Final truth report
//! - Execution receipt
//!
//! This enables:
//! - Tamper detection (any change breaks the manifest hash)
//! - Chain verification (recompute manifest from stored data)
//! - Dataset deduplication (identical manifest = duplicate execution)
//! - Audit trails (prove nothing was altered post-execution)

use crate::chain::hashes::HashOutput;
use serde::{Deserialize, Serialize};

/// A single entry in the manifest.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ManifestEntry {
    /// Label describing what was hashed
    pub label: String,
    /// SHA256 hash of the content
    pub hash: HashOutput,
    /// When this entry was added to the manifest
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

/// Complete manifest for a chain execution.
///
/// The manifest is computed AFTER the chain completes (or fails) and
/// represents the immutable fingerprint of that execution.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Manifest {
    /// Schema version for forward compatibility
    pub schema_version: u32,
    /// When the manifest was generated
    pub generated_at: chrono::DateTime<chrono::Utc>,
    /// All entries in the manifest
    pub entries: Vec<ManifestEntry>,
    /// SHA256 of the canonical JSON serialization of all entries
    pub manifest_hash: HashOutput,
}

impl Manifest {
    /// Current schema version
    pub const SCHEMA_VERSION: u32 = 1;

    /// Create a new manifest builder.
    pub fn builder() -> ManifestBuilder {
        ManifestBuilder::new()
    }

    /// Verify that the manifest_hash matches the entries.
    pub fn verify(&self) -> bool {
        let computed = Self::compute_hash(&self.entries);
        computed == self.manifest_hash
    }

    /// Compute the manifest hash from entries.
    fn compute_hash(entries: &[ManifestEntry]) -> HashOutput {
        // Canonical JSON: sort by label, no whitespace
        let mut sorted_entries = entries.to_vec();
        sorted_entries.sort_by(|a, b| a.label.cmp(&b.label));

        let json =
            serde_json::to_string(&sorted_entries).expect("Manifest entries must be serializable");
        crate::chain::hashes::hash_bytes(json.as_bytes())
    }
}

/// Builder for constructing a manifest.
#[derive(Debug, Default)]
pub struct ManifestBuilder {
    entries: Vec<ManifestEntry>,
}

impl ManifestBuilder {
    /// Create a new empty builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Add an entry to the manifest.
    pub fn add_entry(mut self, label: impl Into<String>, hash: impl Into<String>) -> Self {
        self.entries.push(ManifestEntry {
            label: label.into(),
            hash: hash.into(),
            timestamp: chrono::Utc::now(),
        });
        self
    }

    /// Build the manifest.
    pub fn build(self) -> Manifest {
        let manifest_hash = Manifest::compute_hash(&self.entries);
        Manifest {
            schema_version: Manifest::SCHEMA_VERSION,
            generated_at: chrono::Utc::now(),
            entries: self.entries,
            manifest_hash,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_manifest_builder() {
        let manifest = Manifest::builder()
            .add_entry("prompt", "abc123")
            .add_entry("output", "def456")
            .build();

        assert_eq!(manifest.schema_version, Manifest::SCHEMA_VERSION);
        assert_eq!(manifest.entries.len(), 2);
        assert!(manifest.verify());
    }

    #[test]
    fn test_manifest_tamper_detection() {
        let mut manifest = Manifest::builder()
            .add_entry("prompt", "abc123")
            .add_entry("output", "def456")
            .build();

        assert!(manifest.verify());

        // Tamper with an entry
        manifest.entries[0].hash = "tampered".to_string();
        assert!(!manifest.verify());
    }
}
