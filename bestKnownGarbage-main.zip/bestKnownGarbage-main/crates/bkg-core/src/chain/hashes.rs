//! LinkHashes — cryptographic fingerprints for reproducibility.
//!
//! Every Link carries SHA256 hashes of its prompt, output, and truth
//! verdict. This enables:
//!
//! - Deterministic replay detection (output_changed = hash mismatch)
//! - Truth regression tracking (truth_hash changed across replays)
//! - Dataset deduplication (identical prompt_hash = duplicate entry)
//! - Cryptographic chain verification (manifest SHA256 over all hashes)

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// 64-character hex SHA256 hash.
pub type HashOutput = String;

/// Cryptographic hashes for a single link.
///
/// All hashes are SHA256 of the canonical JSON serialization of the
/// respective data. Empty strings mean the data was not yet produced
/// (pre-execution).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LinkHashes {
    /// SHA256 of the prompt/input sent to the LLM
    pub prompt_hash: HashOutput,
    /// SHA256 of the output received from the LLM
    pub output_hash: HashOutput,
    /// SHA256 of the truth verdict + all checks
    pub truth_hash: HashOutput,
}

impl LinkHashes {
    /// Create empty hashes (pre-execution state).
    pub const fn empty() -> Self {
        Self {
            prompt_hash: String::new(),
            output_hash: String::new(),
            truth_hash: String::new(),
        }
    }

    /// Returns true if all hashes are populated (post-execution).
    pub fn is_complete(&self) -> bool {
        !self.prompt_hash.is_empty() && !self.output_hash.is_empty() && !self.truth_hash.is_empty()
    }
}

impl Default for LinkHashes {
    fn default() -> Self {
        Self::empty()
    }
}

/// Compute SHA256 hex hash of a string.
pub fn hash_string(data: &str) -> HashOutput {
    let mut hasher = Sha256::new();
    hasher.update(data.as_bytes());
    hex::encode(hasher.finalize())
}

/// Compute SHA256 hex hash of canonical JSON bytes.
pub fn hash_bytes(data: &[u8]) -> HashOutput {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hash_string_deterministic() {
        let a = hash_string("hello");
        let b = hash_string("hello");
        assert_eq!(a, b, "SHA256 must be deterministic");
        assert_eq!(a.len(), 64, "SHA256 hex must be 64 chars");
    }

    #[test]
    fn test_hash_string_different() {
        let a = hash_string("hello");
        let b = hash_string("world");
        assert_ne!(a, b, "Different inputs must produce different hashes");
    }

    #[test]
    fn test_link_hashes_empty() {
        let h = LinkHashes::empty();
        assert!(!h.is_complete());
    }

    #[test]
    fn test_link_hashes_complete() {
        let h = LinkHashes {
            prompt_hash: hash_string("prompt"),
            output_hash: hash_string("output"),
            truth_hash: hash_string("truth"),
        };
        assert!(h.is_complete());
    }
}
