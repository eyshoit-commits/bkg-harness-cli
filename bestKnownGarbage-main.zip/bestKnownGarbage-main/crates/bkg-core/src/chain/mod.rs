//! Chain — sequential, verified work units.
//!
//! A Chain is a sequence of Links. Each Link executes one unit of work
//! through a 9-stage lifecycle (session → budget → skills → agent →
//! provider → tools → swd → memory → verify). After each Link, a Truth
//! Gate checks that the work is real — verified, snapshotted, in-budget,
//! drift-free. If truth fails, the Link is re-executed.
//!
//! Chains prevent topic drift because each Link receives the accumulated
//! context + previous output. The LLM cannot pivot to unrelated work
//! without failing the Truth Gate.
//!
//! # Persistence
//!
//! All types in this module implement `Serialize` + `Deserialize` so chains
//! can be saved to disk as canonical JSON. Timestamps use `chrono::DateTime<Utc>`
//! for deterministic serialization. Use `chain.freeze()` before serializing
//! to guarantee immutability.

pub mod capsule;
pub mod error;
pub mod hashes;
pub mod manifest;
pub mod receipts;
pub mod traits;
pub mod truth;

pub use capsule::{CapsuleState, TruthCapsule};
use chrono::{DateTime, Utc};
pub use error::*;
pub use hashes::{HashOutput, LinkHashes, hash_bytes, hash_string};
pub use manifest::{Manifest, ManifestBuilder, ManifestEntry};
pub use receipts::{ChainMeta, ExecutionReceipt};
use serde::{Deserialize, Serialize};
pub use traits::*;
pub use truth::*;

/// Overall status of a Chain.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum ChainStatus {
    /// Chain was created but not yet started
    Created,
    /// At least one link is running
    Running,
    /// All links passed truth
    Completed,
    /// A link failed truth and couldn't be recovered
    Failed(String),
    /// Chain was cancelled
    Cancelled,
}

/// Status of a single Link.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum LinkStatus {
    /// Waiting to be executed
    Pending,
    /// Currently executing the 9-stage lifecycle
    Running,
    /// Passed the Truth Gate
    Passed,
    /// Failed truth — needs re-execution
    Failed(String),
    /// Skipped due to earlier link failure
    Skipped,
}

/// Context passed from link to link, preventing drift.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LinkContext {
    /// The full accumulated conversation history (prevents drift)
    pub accumulated_context: String,
    /// Output from the previous link (empty for first link)
    pub previous_output: String,
    /// Agent role assigned to this link
    pub agent_role: String,
    /// Model to use
    pub model: String,
    /// Skills to inject into the system prompt
    pub skills: Vec<String>,
    /// Budget allocation for this link in tokens
    pub budget_tokens: u64,
}

impl LinkContext {
    /// Create a new context for the first link in a chain.
    pub fn first(agent_role: &str, model: &str) -> Self {
        Self {
            accumulated_context: String::new(),
            previous_output: String::new(),
            agent_role: agent_role.to_string(),
            model: model.to_string(),
            skills: Vec::new(),
            budget_tokens: 0,
        }
    }

    /// Create context for a subsequent link, carrying forward previous output.
    pub fn next(prev: &LinkContext, prev_output: &str, agent_role: &str, model: &str) -> Self {
        let mut acc = prev.accumulated_context.clone();
        if !prev_output.is_empty() {
            acc.push_str("\n--- previous output ---\n");
            acc.push_str(prev_output);
        }
        Self {
            accumulated_context: acc,
            previous_output: prev_output.to_string(),
            agent_role: agent_role.to_string(),
            model: model.to_string(),
            skills: Vec::new(),
            budget_tokens: 0,
        }
    }

    /// Add skills to this context.
    pub fn with_skills(mut self, skills: Vec<String>) -> Self {
        self.skills = skills;
        self
    }

    /// Set budget for this context.
    pub fn with_budget(mut self, tokens: u64) -> Self {
        self.budget_tokens = tokens;
        self
    }
}

/// Result of executing one link.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct LinkResult {
    /// The text output from the agent
    pub output: String,
    /// SWD snapshot reference (if snapshot was taken)
    pub snapshot_id: Option<String>,
    /// Token usage
    pub tokens_used: u64,
    /// Files that were changed
    pub files_changed: Vec<String>,
    /// The truth verdict for this link
    pub truth: TruthVerdict,
}

impl LinkResult {
    pub fn new(output: String) -> Self {
        Self {
            output,
            snapshot_id: None,
            tokens_used: 0,
            files_changed: Vec::new(),
            truth: TruthVerdict::pass(vec![]),
        }
    }
}

/// A single unit of work in a Chain.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Link {
    /// Unique identifier (e.g. "link-1")
    pub id: String,
    /// Human-readable description
    pub description: String,
    /// The context (accumulated, previous output, role, model)
    pub context: LinkContext,
    /// Current status
    pub status: LinkStatus,
    /// Result (set when completed)
    pub result: Option<LinkResult>,
    /// Cryptographic hashes for reproducibility
    pub hashes: LinkHashes,
    /// When execution started
    pub started_at: Option<DateTime<Utc>>,
    /// When execution completed
    pub completed_at: Option<DateTime<Utc>>,
}

impl Link {
    pub fn new(id: String, description: String, context: LinkContext) -> Self {
        Self {
            id,
            description,
            context,
            status: LinkStatus::Pending,
            result: None,
            hashes: LinkHashes::default(),
            started_at: None,
            completed_at: None,
        }
    }
}

/// A Chain — sequential verified work.
///
/// # Immutability
///
/// Once `freeze()` is called, the chain is immutable. All mutation methods
/// (add_link, etc.) will panic. Serialization should only happen after freeze.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Chain {
    /// Unique identifier
    pub id: String,
    /// The links in order
    pub links: Vec<Link>,
    /// Overall status
    pub status: ChainStatus,
    /// The original prompt that created this chain
    pub original_prompt: String,
    /// When the chain was created
    pub created_at: DateTime<Utc>,
    /// When the chain completed
    pub completed_at: Option<DateTime<Utc>>,
    /// The truth report (set when complete)
    pub truth_report: Option<TruthReport>,
    /// If true, the chain is immutable (no further mutations allowed)
    pub frozen: bool,
}

impl Chain {
    /// Create a new chain with the given id and prompt.
    pub fn new(id: String, prompt: String) -> Self {
        Self {
            id,
            links: Vec::new(),
            status: ChainStatus::Created,
            original_prompt: prompt,
            created_at: Utc::now(),
            completed_at: None,
            truth_report: None,
            frozen: false,
        }
    }

    /// Freeze this chain, making it immutable.
    ///
    /// After calling `freeze()`, any attempt to mutate the chain (add_link, etc.)
    /// will panic. Always freeze before serialization.
    pub fn freeze(&mut self) {
        self.frozen = true;
    }

    /// Returns true if the chain is frozen (immutable).
    pub fn is_frozen(&self) -> bool {
        self.frozen
    }

    /// Add a link to the chain.
    ///
    /// # Panics
    /// Panics if the chain is frozen.
    pub fn add_link(&mut self, link: Link) {
        assert!(!self.frozen, "Cannot modify a frozen chain");
        self.links.push(link);
    }

    /// Get the current active link (the first running or pending one).
    pub fn current_link(&self) -> Option<&Link> {
        self.links
            .iter()
            .find(|l| matches!(l.status, LinkStatus::Pending | LinkStatus::Running))
    }

    /// Get the last completed link.
    pub fn last_completed(&self) -> Option<&Link> {
        self.links
            .iter()
            .rev()
            .find(|l| l.status == LinkStatus::Passed)
    }

    /// Check if all links are done.
    pub fn is_complete(&self) -> bool {
        self.links
            .iter()
            .all(|l| l.status == LinkStatus::Passed || l.status == LinkStatus::Skipped)
    }

    /// Count links by status.
    pub fn counts(&self) -> (usize, usize, usize, usize) {
        let mut pending = 0usize;
        let mut running = 0usize;
        let mut passed = 0usize;
        let mut failed = 0usize;
        for link in &self.links {
            match link.status {
                LinkStatus::Pending => pending += 1,
                LinkStatus::Running => running += 1,
                LinkStatus::Passed => passed += 1,
                LinkStatus::Failed(_) | LinkStatus::Skipped => failed += 1,
            }
        }
        (pending, running, passed, failed)
    }

    /// Format a chain summary for display.
    pub fn summary(&self) -> String {
        let (pending, running, passed, failed) = self.counts();
        format!(
            "Chain {}: {} pending, {} running, {} passed, {} failed | \"{}\"{}",
            self.id,
            pending,
            running,
            passed,
            failed,
            self.original_prompt,
            if self.frozen { " [FROZEN]" } else { "" },
        )
    }
}
