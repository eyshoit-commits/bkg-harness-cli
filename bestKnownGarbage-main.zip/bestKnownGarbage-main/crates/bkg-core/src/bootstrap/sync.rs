//! TaskTruthSync — Pure Reconciliation + Drift Detection Layer.
//!
//! Kein Executor. Kein Planner. Kein Bootstrap-Owner.
//! Nur: Hash Reconciliation, Capsule Diff, Drift Detection.
//!
//! Jeder Task hat einen Truth-Anker (receipt_hash + capsule_hash).
//! Beim Sync wird geprüft: Stimmt die aktuelle Capsule-Truth noch mit dem Task-Anker überein?
//! Wenn nicht → Divergent. Wenn ja → Verified.

use std::collections::HashMap;
use std::path::PathBuf;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

/// Status eines Tasks im Verhältnis zur Capsule-Truth.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum TaskStatus {
    Planned,
    InProgress,
    Verified,
    Divergent {
        expected_hash: String,
        actual_hash: String,
    },
    Stale,
}

/// Wahrheits-Anker: Verbindet einen Task mit einer Capsule-Version.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskTruthAnchor {
    pub task_id: String,
    pub capsule_id: String,
    pub phase: String,
    pub receipt_hash: String,
    pub capsule_hash: String,
    pub status: TaskStatus,
    pub truth_path: PathBuf,
    pub last_verified: Option<DateTime<Utc>>,
}

/// Ergebnis eines einzelnen Sync-Durchlaufs für einen Task.
#[derive(Debug, Clone)]
pub struct SyncResult {
    pub task_id: String,
    pub status_before: TaskStatus,
    pub status_after: TaskStatus,
    pub drift_detected: bool,
    pub reason: String,
}

/// Detaillierter Drift-Report bei Abweichung.
#[derive(Debug, Clone)]
pub struct DriftReport {
    pub task_id: String,
    pub capsule_id: String,
    pub receipt_hash_old: String,
    pub receipt_hash_new: String,
    pub diff_summary: Vec<String>,
    pub severity: DriftSeverity,
}

#[derive(Debug, Clone)]
pub enum DriftSeverity {
    None,
    Minor,
    Major,
    Critical,
}

/// Diff zwischen zwei Capsule-Zuständen.
#[derive(Debug)]
pub struct CapsuleDiff {
    pub capsule_id: String,
    pub changed_fields: Vec<String>,
    pub hash_changed: bool,
    pub structural_drift: bool,
}

// ── Hash System ──

/// Kanonischer SHA256-Hash eines Strings.
pub fn hash_content(input: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(input.as_bytes());
    format!("{:x}", hasher.finalize())
}

/// Hash eines ExecutionReceipt (über kanonisches JSON).
pub fn receipt_hash(receipt: &str) -> String {
    hash_content(receipt)
}

/// Hash einer Capsule (über kanonisches JSON).
pub fn capsule_hash(capsule_json: &str) -> String {
    hash_content(capsule_json)
}

// ── Capsule Diff Engine ──

/// Vergleicht zwei Capsule-Zustände und identifiziert Drift.
pub fn diff_capsules(old: &str, new: &str, capsule_id: &str) -> CapsuleDiff {
    let old_h = hash_content(old);
    let new_h = hash_content(new);
    let changed = old_h != new_h;

    CapsuleDiff {
        capsule_id: capsule_id.to_string(),
        changed_fields: if changed {
            vec!["capsule_root".to_string()]
        } else {
            vec![]
        },
        hash_changed: changed,
        structural_drift: changed,
    }
}

// ── Drift Detection Engine ──

/// Erkennt Drift zwischen einem Task-Anker und dem aktuellen Capsule-Zustand.
pub fn detect_drift(
    anchor: &TaskTruthAnchor,
    latest_receipt: &str,
    latest_capsule_hash: &str,
) -> Option<DriftReport> {
    let current_hash = receipt_hash(latest_receipt);

    if current_hash == anchor.receipt_hash && latest_capsule_hash == anchor.capsule_hash {
        return None;
    }

    let severity = match (
        current_hash == anchor.receipt_hash,
        latest_capsule_hash == anchor.capsule_hash,
    ) {
        (false, false) => DriftSeverity::Critical,
        (false, true) => DriftSeverity::Major,
        (true, false) => DriftSeverity::Minor,
        _ => DriftSeverity::None,
    };

    Some(DriftReport {
        task_id: anchor.task_id.clone(),
        capsule_id: anchor.capsule_id.clone(),
        receipt_hash_old: anchor.receipt_hash.clone(),
        receipt_hash_new: current_hash,
        diff_summary: vec!["Receipt or Capsule mismatch detected".to_string()],
        severity,
    })
}

// ── TaskTruthSync Engine ──

/// Pure Reconciliation + Drift Detection.
/// Kein Executor, kein Planner — nur Sync.
pub struct TaskTruthSync {
    pub task_index: HashMap<String, TaskTruthAnchor>,
    pub capsule_dir: PathBuf,
}

impl TaskTruthSync {
    pub fn new(capsule_dir: PathBuf) -> Self {
        Self {
            task_index: HashMap::new(),
            capsule_dir,
        }
    }

    /// Full Sync Pipeline: lädt Capsules, vergleicht Receipts, markiert Drift.
    pub async fn sync(&mut self) -> Vec<SyncResult> {
        let mut results = vec![];

        // TODO: echte Capsule-Scanner-Integration
        // Für jetzt: scan ~/.bkg/capsules/ und parse receipts
        if !self.capsule_dir.exists() {
            return results;
        }

        let entries = match std::fs::read_dir(&self.capsule_dir) {
            Ok(e) => e,
            Err(_) => return results,
        };

        for entry in entries.flatten() {
            let capsule_path = entry.path();
            if !capsule_path.is_dir() {
                continue;
            }

            let capsule_id = capsule_path
                .file_name()
                .and_then(|n| n.to_str())
                .unwrap_or("unknown")
                .to_string();

            // Lese receipt.json falls vorhanden
            let receipt_path = capsule_path.join("receipt.json");
            let capsule_manifest_path = capsule_path.join("capsule.json");

            let receipt_content = match std::fs::read_to_string(&receipt_path) {
                Ok(c) => c,
                Err(_) => continue,
            };

            let capsule_content = match std::fs::read_to_string(&capsule_manifest_path) {
                Ok(c) => c,
                Err(_) => continue,
            };

            let task_id = capsule_id.clone();
            let new_receipt_hash = receipt_hash(&receipt_content);
            let new_capsule_hash = capsule_hash(&capsule_content);

            match self.task_index.get(&task_id) {
                Some(existing) => {
                    let drift = detect_drift(existing, &receipt_content, &new_capsule_hash);

                    let status_after = if let Some(_d) = &drift {
                        TaskStatus::Divergent {
                            expected_hash: existing.receipt_hash.clone(),
                            actual_hash: new_receipt_hash.clone(),
                        }
                    } else {
                        TaskStatus::Verified
                    };

                    results.push(SyncResult {
                        task_id: task_id.clone(),
                        status_before: existing.status.clone(),
                        status_after,
                        drift_detected: drift.is_some(),
                        reason: "Capsule reconciliation".to_string(),
                    });
                }
                None => {
                    // Neuer Task aus Capsule entdeckt
                    self.task_index.insert(
                        task_id.clone(),
                        TaskTruthAnchor {
                            task_id: task_id.clone(),
                            capsule_id,
                            phase: "rehydrated".to_string(),
                            receipt_hash: new_receipt_hash,
                            capsule_hash: new_capsule_hash,
                            status: TaskStatus::Planned,
                            truth_path: capsule_path,
                            last_verified: None,
                        },
                    );
                }
            }
        }

        results
    }

    /// Task als "Verified" markieren + Receipt-Hash updaten.
    pub fn verify_task(
        &mut self,
        task_id: &str,
        receipt_content: &str,
        capsule_content: &str,
    ) -> Result<(), String> {
        let r_hash = receipt_hash(receipt_content);
        let c_hash = capsule_hash(capsule_content);

        if let Some(anchor) = self.task_index.get_mut(task_id) {
            anchor.receipt_hash = r_hash;
            anchor.capsule_hash = c_hash;
            anchor.status = TaskStatus::Verified;
            anchor.last_verified = Some(Utc::now());
            Ok(())
        } else {
            Err(format!("Task '{}' not found in index", task_id))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hash_content_deterministic() {
        let a = hash_content("hello world");
        let b = hash_content("hello world");
        assert_eq!(a, b);
        assert_eq!(a.len(), 64); // SHA256 hex
    }

    #[test]
    fn test_hash_content_changes() {
        let a = hash_content("hello world");
        let b = hash_content("hello world!");
        assert_ne!(a, b);
    }

    #[test]
    fn test_diff_capsules_no_change() {
        let content = r#"{"version":1}"#;
        let diff = diff_capsules(content, content, "test");
        assert!(!diff.hash_changed);
        assert!(!diff.structural_drift);
    }

    #[test]
    fn test_diff_capsules_change() {
        let old = r#"{"version":1}"#;
        let new = r#"{"version":2}"#;
        let diff = diff_capsules(old, new, "test");
        assert!(diff.hash_changed);
        assert!(diff.structural_drift);
    }

    #[test]
    fn test_detect_drift_no_drift() {
        let anchor = TaskTruthAnchor {
            task_id: "t1".into(),
            capsule_id: "c1".into(),
            phase: "test".into(),
            receipt_hash: hash_content("receipt1"),
            capsule_hash: hash_content("capsule1"),
            status: TaskStatus::Verified,
            truth_path: PathBuf::from("/tmp"),
            last_verified: None,
        };
        let result = detect_drift(&anchor, "receipt1", &hash_content("capsule1"));
        assert!(result.is_none());
    }

    #[test]
    fn test_detect_drift_critical() {
        let anchor = TaskTruthAnchor {
            task_id: "t1".into(),
            capsule_id: "c1".into(),
            phase: "test".into(),
            receipt_hash: hash_content("old_receipt"),
            capsule_hash: hash_content("old_capsule"),
            status: TaskStatus::Verified,
            truth_path: PathBuf::from("/tmp"),
            last_verified: None,
        };
        let result = detect_drift(&anchor, "new_receipt", &hash_content("new_capsule"));
        assert!(result.is_some());
        assert!(matches!(result.unwrap().severity, DriftSeverity::Critical));
    }

    #[test]
    fn test_task_truth_sync_new_capsule() {
        // Create temp capsule dir
        let tmp = std::env::temp_dir().join("bkg-sync-test");
        std::fs::create_dir_all(&tmp.join("cap-1")).unwrap();
        std::fs::write(tmp.join("cap-1/receipt.json"), r#"{"id":"r1"}"#).unwrap();
        std::fs::write(tmp.join("cap-1/capsule.json"), r#"{"id":"cap-1"}"#).unwrap();

        let mut sync = TaskTruthSync::new(tmp.clone());
        let rt = tokio::runtime::Runtime::new().unwrap();
        let _results = rt.block_on(sync.sync());

        assert_eq!(sync.task_index.len(), 1);
        assert!(sync.task_index.contains_key("cap-1"));

        // Cleanup
        std::fs::remove_dir_all(&tmp).ok();
    }
}
