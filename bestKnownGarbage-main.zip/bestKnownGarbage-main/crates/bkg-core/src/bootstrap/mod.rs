//! Bootstrap — System Genesis Layer.
//!
//! Deterministischer Startup mit Phasen-Validierung.
//! Architektur: Bootstrap → Capsule → Runtime → Coordinator (lazy)
//!
//! Bootstrap resolved nur System-State (Config, Provider, Models, Capsules).
//! Der Coordinator wird erst von Runtime aus dem CoordinatorSpec created.

pub mod sync;

use std::path::PathBuf;
use std::time::{Duration, Instant};

/// Phase des Bootstrap-Prozesses.
#[derive(Debug, Clone, PartialEq)]
pub enum BootstrapPhase {
    ConfigLoad,
    CapsuleRehydration,
    ProviderDetection,
    ModelDiscovery,
    CoordinatorResolution,
    SetupWizard,
    Ready,
}

impl BootstrapPhase {
    pub fn label(&self) -> &'static str {
        match self {
            BootstrapPhase::ConfigLoad => "ConfigLoad",
            BootstrapPhase::CapsuleRehydration => "CapsuleRehydration",
            BootstrapPhase::ProviderDetection => "ProviderDetection",
            BootstrapPhase::ModelDiscovery => "ModelDiscovery",
            BootstrapPhase::CoordinatorResolution => "CoordinatorResolution",
            BootstrapPhase::SetupWizard => "SetupWizard",
            BootstrapPhase::Ready => "Ready",
        }
    }
}

/// Status einer einzelnen Bootstrap-Phase.
#[derive(Debug, Clone)]
pub enum PhaseStatus {
    Passed,
    Failed { errors: Vec<String> },
    Warned { warnings: Vec<String> },
}

impl PhaseStatus {
    pub fn is_healthy(&self) -> bool {
        matches!(self, PhaseStatus::Passed | PhaseStatus::Warned { .. })
    }
}

/// Ergebnis einer einzelnen Phase.
#[derive(Debug, Clone)]
pub struct PhaseResult {
    pub phase: BootstrapPhase,
    pub status: PhaseStatus,
    pub duration: Duration,
}

impl PhaseResult {
    pub fn new(phase: BootstrapPhase, status: PhaseStatus, duration: Duration) -> Self {
        Self {
            phase,
            status,
            duration,
        }
    }
}

/// State einer Truth Capsule beim Startup.
#[derive(Debug, Clone, PartialEq)]
pub enum CapsuleState {
    Healthy,
    Degraded { issues: Vec<String> },
    Missing,
}

/// Spezifikation für den Coordinator (wird von Runtime instanziiert).
#[derive(Debug, Clone)]
pub struct CoordinatorSpec {
    pub model: String,
    pub provider_kind: String,
    pub system_prompt: String,
    pub max_tokens: u32,
    pub temperature: f32,
}

impl Default for CoordinatorSpec {
    fn default() -> Self {
        Self {
            model: "ollama/qwen2:1.5b-coder".to_string(),
            provider_kind: "ollama".to_string(),
            system_prompt: String::new(),
            max_tokens: 4096,
            temperature: 0.7,
        }
    }
}

/// Gesamter Bootstrap-Report nach allen Phasen.
#[derive(Debug, Clone)]
pub struct BootstrapReport {
    pub phases: Vec<PhaseResult>,
    pub coordinator_spec: CoordinatorSpec,
    pub capsule_state: CapsuleState,
    pub available_providers: Vec<crate::provider::ProviderKind>,
    pub needs_setup: bool,
}

impl BootstrapReport {
    pub fn new() -> Self {
        Self {
            phases: Vec::new(),
            coordinator_spec: CoordinatorSpec::default(),
            capsule_state: CapsuleState::Missing,
            available_providers: Vec::new(),
            needs_setup: false,
        }
    }

    /// Alle Phasen bestanden?
    pub fn is_healthy(&self) -> bool {
        self.phases.iter().all(|p| p.status.is_healthy())
    }

    /// Farbige Zusammenfassung ausgeben.
    pub fn print_summary(&self) {
        #[cfg(feature = "colored")]
        {
            use colored::*;
            println!(
                "\n{}",
                "╔═══════════════════════╤════════╤══════════════╗".green()
            );
            println!(
                "{}",
                "║ Phase                 │ Status │ Duration      ║".green()
            );
            println!(
                "{}",
                "╠═══════════════════════╪════════╪══════════════╣".green()
            );
            for pr in &self.phases {
                let (symbol, color) = match &pr.status {
                    PhaseStatus::Passed => ("✓", "green"),
                    PhaseStatus::Failed { .. } => ("✗", "red"),
                    PhaseStatus::Warned { .. } => ("⚠", "yellow"),
                };
                let label = pr.phase.label();
                let ms = pr.duration.as_millis();
                let colored_sym = match color {
                    "green" => symbol.green(),
                    "red" => symbol.red(),
                    _ => symbol.yellow(),
                };
                println!(
                    "║ {:<21} │ {:>2}    │ {:>4}ms       ║",
                    label, colored_sym, ms
                );
            }
            println!(
                "{}",
                "╚═══════════════════════╧════════╧══════════════╝".green()
            );
        }
        #[cfg(not(feature = "colored"))]
        {
            println!("\n╔═══════════════════════╤════════╤══════════════╗");
            println!("║ Phase                 │ Status │ Duration      ║");
            println!("╠═══════════════════════╪════════╪══════════════╣");
            for pr in &self.phases {
                let symbol = match &pr.status {
                    PhaseStatus::Passed => "✓",
                    PhaseStatus::Failed { .. } => "✗",
                    PhaseStatus::Warned { .. } => "⚠",
                };
                let label = pr.phase.label();
                let ms = pr.duration.as_millis();
                println!("║ {:<21} │ {:>2}    │ {:>4}ms       ║", label, symbol, ms);
            }
            println!("╚═══════════════════════╧════════╧══════════════╝");
        }
    }
}

/// Der Bootstrap-Orchestrator.
///
/// Führt alle Phasen sequentiell aus und sammelt Ergebnisse.
pub struct BkgBootstrap {
    pub report: BootstrapReport,
    pub config_path: PathBuf,
}

impl BkgBootstrap {
    pub fn new() -> Self {
        let config_path = dirs::home_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join(".bkg");
        Self {
            report: BootstrapReport::new(),
            config_path,
        }
    }

    /// Vollständigen Bootstrap-Durchlauf starten.
    pub async fn run(&mut self) -> BootstrapReport {
        // Phase 1: ConfigLoad
        self.phase_config_load().await;

        // Phase 2: CapsuleRehydration
        self.phase_capsule_rehydration().await;

        // Phase 3: ProviderDetection
        self.phase_provider_detection().await;

        // Phase 4: ModelDiscovery
        self.phase_model_discovery().await;

        // Phase 5: CoordinatorResolution
        self.phase_coordinator_resolution().await;

        // Phase 6: Ready
        self.run_phase(BootstrapPhase::Ready, || async {
            Ok(PhaseResult::new(
                BootstrapPhase::Ready,
                PhaseStatus::Passed,
                Duration::ZERO,
            ))
        })
        .await;

        self.report.clone()
    }

    /// Phase 1: ConfigLoad — check if config exists, determine first-run.
    async fn phase_config_load(&mut self) {
        let start = Instant::now();

        let config_file = self.config_path.join("config.toml");
        let env_file = self.config_path.join(".env");

        let status = if config_file.exists() {
            PhaseStatus::Passed
        } else if env_file.exists() {
            PhaseStatus::Warned {
                warnings: vec!["config.toml not found, but .env exists".into()],
            }
        } else {
            self.report.needs_setup = true;
            PhaseStatus::Warned {
                warnings: vec!["No config found — first run detected".into()],
            }
        };

        self.report.phases.push(PhaseResult::new(
            BootstrapPhase::ConfigLoad,
            status,
            start.elapsed(),
        ));
    }

    /// Phase 2: CapsuleRehydration — scan and verify capsules.
    async fn phase_capsule_rehydration(&mut self) {
        let start = Instant::now();

        let engine = crate::capsule::CapsuleEngine::with_dir(self.config_path.join("capsules"));
        let capsule_state = engine.scan_and_rehydrate().await;

        self.report.capsule_state = capsule_state.clone();

        let status = match &capsule_state {
            CapsuleState::Healthy => PhaseStatus::Passed,
            CapsuleState::Degraded { issues } => PhaseStatus::Warned {
                warnings: issues.clone(),
            },
            CapsuleState::Missing => {
                self.report.needs_setup = true;
                PhaseStatus::Warned {
                    warnings: vec!["No capsules found — initial setup needed".into()],
                }
            }
        };

        self.report.phases.push(PhaseResult::new(
            BootstrapPhase::CapsuleRehydration,
            status,
            start.elapsed(),
        ));
    }

    /// Phase 3: ProviderDetection — scan env vars for available providers.
    async fn phase_provider_detection(&mut self) {
        let start = Instant::now();

        let probes = crate::provider::probe_all_providers();
        let available: Vec<crate::provider::ProviderKind> = probes
            .iter()
            .filter(|p| p.available)
            .map(|p| p.kind.clone())
            .collect();

        self.report.available_providers = available.clone();

        let status = if available.is_empty() {
            self.report.needs_setup = true;
            PhaseStatus::Warned {
                warnings: vec![
                    "No providers detected. Set an API key or run Ollama locally.".into(),
                ],
            }
        } else {
            PhaseStatus::Passed
        };

        self.report.phases.push(PhaseResult::new(
            BootstrapPhase::ProviderDetection,
            status,
            start.elapsed(),
        ));
    }

    /// Phase 4: ModelDiscovery — build model catalog from available providers.
    async fn phase_model_discovery(&mut self) {
        let start = Instant::now();

        let catalog = crate::model::ModelCatalog::discover(&self.report.available_providers);
        let default = catalog.get_default();

        if let Some(model) = default {
            self.report.coordinator_spec.model = model.id.clone();
            self.report.coordinator_spec.provider_kind = model.provider.label().to_string();
        }

        let count = catalog.total_count();
        let status = if count > 0 {
            PhaseStatus::Passed
        } else {
            PhaseStatus::Warned {
                warnings: vec!["No models discovered — using hardcoded defaults".into()],
            }
        };

        self.report.phases.push(PhaseResult::new(
            BootstrapPhase::ModelDiscovery,
            status,
            start.elapsed(),
        ));
    }

    /// Phase 5: CoordinatorResolution — finalize CoordinatorSpec and validate.
    async fn phase_coordinator_resolution(&mut self) {
        let start = Instant::now();

        let spec = &self.report.coordinator_spec;
        let has_model = !spec.model.is_empty();
        let has_provider = !spec.provider_kind.is_empty();

        let status = if has_model && has_provider {
            PhaseStatus::Passed
        } else if has_model {
            PhaseStatus::Warned {
                warnings: vec![format!(
                    "Model '{}' resolved but no provider — using Ollama fallback",
                    spec.model
                )],
            }
        } else {
            self.report.needs_setup = true;
            PhaseStatus::Warned {
                warnings: vec!["No coordinator spec resolved — needs setup".into()],
            }
        };

        self.report.phases.push(PhaseResult::new(
            BootstrapPhase::CoordinatorResolution,
            status,
            start.elapsed(),
        ));
    }

    async fn run_phase<F, Fut>(&mut self, phase: BootstrapPhase, f: F)
    where
        F: FnOnce() -> Fut,
        Fut: std::future::Future<Output = Result<PhaseResult, String>>,
    {
        let start = Instant::now();
        let result = f().await;
        let duration = start.elapsed();

        let phase_result = match result {
            Ok(mut pr) => {
                pr.duration = duration;
                pr
            }
            Err(errors) => PhaseResult::new(
                phase,
                PhaseStatus::Failed {
                    errors: vec![errors],
                },
                duration,
            ),
        };

        self.report.phases.push(phase_result);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bootstrap_phase_labels() {
        assert_eq!(BootstrapPhase::ConfigLoad.label(), "ConfigLoad");
        assert_eq!(
            BootstrapPhase::CapsuleRehydration.label(),
            "CapsuleRehydration"
        );
        assert_eq!(
            BootstrapPhase::CoordinatorResolution.label(),
            "CoordinatorResolution"
        );
    }

    #[test]
    fn test_phase_status_healthy() {
        assert!(PhaseStatus::Passed.is_healthy());
        assert!(
            !PhaseStatus::Failed {
                errors: vec!["err".into()]
            }
            .is_healthy()
        );
        assert!(
            PhaseStatus::Warned {
                warnings: vec!["warn".into()]
            }
            .is_healthy()
        );
    }

    #[test]
    fn test_report_healthy() {
        let mut report = BootstrapReport::new();
        report.phases.push(PhaseResult::new(
            BootstrapPhase::ConfigLoad,
            PhaseStatus::Passed,
            Duration::from_millis(5),
        ));
        assert!(report.is_healthy());
    }

    #[test]
    fn test_report_unhealthy() {
        let mut report = BootstrapReport::new();
        report.phases.push(PhaseResult::new(
            BootstrapPhase::ProviderDetection,
            PhaseStatus::Failed {
                errors: vec!["no provider".into()],
            },
            Duration::from_millis(10),
        ));
        assert!(!report.is_healthy());
    }

    #[test]
    fn test_coordinator_spec_default() {
        let spec = CoordinatorSpec::default();
        assert_eq!(spec.model, "ollama/qwen2:1.5b-coder");
        assert_eq!(spec.provider_kind, "ollama");
        assert_eq!(spec.max_tokens, 4096);
    }

    #[tokio::test]
    async fn test_bootstrap_run() {
        let mut boot = BkgBootstrap::new();
        let report = boot.run().await;
        assert_eq!(report.phases.len(), 6);
        assert!(report.is_healthy());
    }
}
