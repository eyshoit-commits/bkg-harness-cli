//! **Provider** — boot-time provider detection (BKG Prospecto).
//!
//! At bootstrap time we cannot depend on `bkg-provider` (circular crate dep).
//! Instead, this module scans environment variables to determine which
//! AI providers are available. The CLI layer uses these probe results to
//! initialize the real `ProviderRegistry`.
//!
//! Probed env vars:
//! - `NVIDIA_API_KEY` / `NVIDIA_BASE_URL`   → Nvidia
//! - `OPENAI_API_KEY` / `OPENAI_BASE_URL`   → OpenAI
//! - `ANTHROPIC_API_KEY`                     → Anthropic
//! - `GROQ_API_KEY`                          → Groq
//! - `GEMINI_API_KEY`                        → Gemini
//! - `OPENROUTER_API_KEY`                    → OpenRouter
//! - `OLLAMA_BASE_URL` / `OLLAMA_URL`        → Ollama (no key needed)
//! - `DEEPSEEK_API_KEY`                      → DeepSeek

/// Known provider kinds detected at bootstrap.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum ProviderKind {
    Nvidia,
    OpenAI,
    Anthropic,
    Groq,
    Gemini,
    OpenRouter,
    Ollama,
    DeepSeek,
}

impl ProviderKind {
    /// Human-readable label.
    pub fn label(&self) -> &'static str {
        match self {
            Self::Nvidia => "nvidia",
            Self::OpenAI => "openai",
            Self::Anthropic => "anthropic",
            Self::Groq => "groq",
            Self::Gemini => "gemini",
            Self::OpenRouter => "openrouter",
            Self::Ollama => "ollama",
            Self::DeepSeek => "deepseek",
        }
    }

    /// Env var to check for API key (None if key-free, like Ollama).
    pub fn api_key_env(&self) -> Option<&'static str> {
        match self {
            Self::Nvidia => Some("NVIDIA_API_KEY"),
            Self::OpenAI => Some("OPENAI_API_KEY"),
            Self::Anthropic => Some("ANTHROPIC_API_KEY"),
            Self::Groq => Some("GROQ_API_KEY"),
            Self::Gemini => Some("GEMINI_API_KEY"),
            Self::OpenRouter => Some("OPENROUTER_API_KEY"),
            Self::Ollama => None,
            Self::DeepSeek => Some("DEEPSEEK_API_KEY"),
        }
    }

    /// Default model ID for this provider.
    pub fn default_model(&self) -> &'static str {
        match self {
            Self::Nvidia => "meta/llama-3.3-70b-instruct",
            Self::OpenAI => "gpt-4o",
            Self::Anthropic => "claude-3-5-sonnet-20241022",
            Self::Groq => "llama-3.3-70b-versatile",
            Self::Gemini => "gemini-2.0-flash",
            Self::OpenRouter => "openai/gpt-4o",
            Self::Ollama => "qwen2:1.5b-coder",
            Self::DeepSeek => "deepseek-chat",
        }
    }

    /// Default context length (tokens) for the default model.
    pub fn default_context(&self) -> u32 {
        match self {
            Self::Nvidia => 131_072,
            Self::OpenAI => 128_000,
            Self::Anthropic => 200_000,
            Self::Groq => 131_072,
            Self::Gemini => 1_000_000,
            Self::OpenRouter => 128_000,
            Self::Ollama => 32_768,
            Self::DeepSeek => 128_000,
        }
    }

    /// Whether this provider supports function/tool calling.
    pub fn supports_tools(&self) -> bool {
        match self {
            Self::OpenAI | Self::Anthropic | Self::Groq | Self::Nvidia | Self::Gemini => true,
            Self::Ollama | Self::OpenRouter | Self::DeepSeek => false,
        }
    }
}

/// Result of probing a single provider.
#[derive(Debug, Clone)]
pub struct ProviderProbe {
    pub kind: ProviderKind,
    pub available: bool,
    pub has_key: bool,
    pub base_url: Option<String>,
}

/// Probe all known providers by scanning environment variables.
pub fn probe_all_providers() -> Vec<ProviderProbe> {
    let mut results = Vec::new();

    for kind in &ALL_PROVIDERS {
        let has_key = match kind.api_key_env() {
            Some(var) => std::env::var(var).is_ok(),
            None => true, // Ollama, etc. don't need keys
        };

        let base_url = match kind {
            ProviderKind::Nvidia => std::env::var("NVIDIA_BASE_URL").ok(),
            ProviderKind::OpenAI => std::env::var("OPENAI_BASE_URL").ok(),
            ProviderKind::Ollama => std::env::var("OLLAMA_BASE_URL")
                .or_else(|_| std::env::var("OLLAMA_URL"))
                .ok(),
            _ => None,
        };

        let available = has_key || kind == &ProviderKind::Ollama;

        results.push(ProviderProbe {
            kind: kind.clone(),
            available,
            has_key,
            base_url,
        });
    }

    results
}

/// Get the first available provider kind (fallback: Ollama).
pub fn resolve_default_provider(probes: &[ProviderProbe]) -> ProviderKind {
    // Priority order: Nvidia > OpenAI > Anthropic > Groq > Gemini > Ollama
    for kind in &[
        ProviderKind::Nvidia,
        ProviderKind::OpenAI,
        ProviderKind::Anthropic,
        ProviderKind::Groq,
        ProviderKind::Gemini,
        ProviderKind::OpenRouter,
        ProviderKind::DeepSeek,
        ProviderKind::Ollama,
    ] {
        if let Some(p) = probes.iter().find(|p| p.kind == *kind && p.available) {
            return p.kind.clone();
        }
    }
    ProviderKind::Ollama
}

/// All known providers in probe order.
pub const ALL_PROVIDERS: [ProviderKind; 8] = [
    ProviderKind::Nvidia,
    ProviderKind::OpenAI,
    ProviderKind::Anthropic,
    ProviderKind::Groq,
    ProviderKind::Gemini,
    ProviderKind::OpenRouter,
    ProviderKind::DeepSeek,
    ProviderKind::Ollama,
];

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_provider_labels() {
        assert_eq!(ProviderKind::Nvidia.label(), "nvidia");
        assert_eq!(ProviderKind::Ollama.label(), "ollama");
        assert_eq!(ProviderKind::DeepSeek.label(), "deepseek");
    }

    #[test]
    fn test_api_key_env_vars() {
        assert_eq!(ProviderKind::Nvidia.api_key_env(), Some("NVIDIA_API_KEY"));
        assert_eq!(ProviderKind::Ollama.api_key_env(), None);
        assert_eq!(ProviderKind::Groq.api_key_env(), Some("GROQ_API_KEY"));
    }

    #[test]
    fn test_default_models() {
        assert_eq!(
            ProviderKind::Nvidia.default_model(),
            "meta/llama-3.3-70b-instruct"
        );
        assert_eq!(ProviderKind::OpenAI.default_model(), "gpt-4o");
        assert_eq!(ProviderKind::Ollama.default_model(), "qwen2:1.5b-coder");
    }

    #[test]
    fn test_default_context() {
        assert!(ProviderKind::Gemini.default_context() > 100_000);
        assert_eq!(ProviderKind::Ollama.default_context(), 32_768);
    }

    #[test]
    fn test_supports_tools() {
        assert!(ProviderKind::OpenAI.supports_tools());
        assert!(ProviderKind::Nvidia.supports_tools());
        assert!(!ProviderKind::Ollama.supports_tools());
    }

    #[test]
    fn test_probe_all_providers_has_all() {
        let probes = probe_all_providers();
        assert_eq!(probes.len(), 8);

        let ollama = probes
            .iter()
            .find(|p| p.kind == ProviderKind::Ollama)
            .unwrap();
        assert!(ollama.available); // Ollama is always available (key-free)
    }

    #[test]
    fn test_resolve_default_with_explicit_probes() {
        // Explicit probe list with only Ollama available
        let probes = vec![
            ProviderProbe {
                kind: ProviderKind::Nvidia,
                available: false,
                has_key: false,
                base_url: None,
            },
            ProviderProbe {
                kind: ProviderKind::OpenAI,
                available: false,
                has_key: false,
                base_url: None,
            },
            ProviderProbe {
                kind: ProviderKind::Ollama,
                available: true,
                has_key: true,
                base_url: None,
            },
        ];
        let default = resolve_default_provider(&probes);
        assert_eq!(default, ProviderKind::Ollama);
    }

    #[test]
    fn test_resolve_default_prioritizes_available() {
        // Even though Nvidia is higher priority, OpenAI is the only available one
        let probes = vec![
            ProviderProbe {
                kind: ProviderKind::Nvidia,
                available: false,
                has_key: false,
                base_url: None,
            },
            ProviderProbe {
                kind: ProviderKind::OpenAI,
                available: true,
                has_key: true,
                base_url: None,
            },
            ProviderProbe {
                kind: ProviderKind::Ollama,
                available: true,
                has_key: true,
                base_url: None,
            },
        ];
        let default = resolve_default_provider(&probes);
        assert_eq!(default, ProviderKind::OpenAI); // OpenAI is first available
    }

    #[test]
    fn test_all_providers_list() {
        assert_eq!(ALL_PROVIDERS.len(), 8);
        assert!(ALL_PROVIDERS.contains(&ProviderKind::Nvidia));
        assert!(ALL_PROVIDERS.contains(&ProviderKind::Ollama));
    }
}
