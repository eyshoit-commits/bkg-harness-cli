//! **Nucleus** — the heart gate (BKG Reveland).
//!
//! In the Reveland, the kernel is **Nucleus** (Latin for "kernel/core"):
//! the heart where all gates converge and the system's determinism is governed.
//!
//! # UCC-4 Self-Evolving Kernel — the deterministic, self-healing execution core.
//!
//! The kernel is divided into five sub-systems:
//!
//! | Module       | Responsibility |
//! |--------------|---------------|
//! | `execution`  | DAG construction, parallel execution, receipt generation |
//! | `truth`      | Verification, drift detection, repair loop |
//! | `time`       | Replay, diffing, event timeline |
//! | `memory`     | Capsule index, filesystem persistence |
//! | `evolution`  | Policy learning, async event queue |
//!
//! # Hot Path
//!
//! The main hot path is [`Ucc4Kernel::run()`]:
//!
//! 1. Load capsule from memory
//! 2. Build execution DAG
//! 3. Execute DAG (parallel safe, deterministic)
//! 4. Generate ExecutionReceipt (immutable)
//! 5. Persist receipt
//! 6. Verify against truth
//! 7. If divergent → repair loop (max 3, convergent)
//! 8. Persist capsule update
//! 9. Finalize TruthReport
//! 10. Queue evolution event (async)
//! 11. Return output

pub mod contracts;
pub mod evolution;
pub mod epistemic;
pub mod execution;
pub mod memory;
pub mod time;
pub mod truth;
pub mod ucc4;

// Re-export key types at the kernel level.
pub use contracts::{KernelError, KernelResult, ReplayMode, Verdict};
pub use ucc4::Ucc4Kernel;

/// Pre-constructed test kernel for use in tests across the crate.
#[cfg(test)]
pub fn test_kernel() -> impl Ucc4Kernel {
    use crate::kernel::execution::receipts::{
        CapsuleSnapshot, ExecutionReceipt, KernelOutput, PolicySnapshot,
    };

    struct TestKernel;

    #[async_trait::async_trait]
    impl Ucc4Kernel for TestKernel {
        async fn run(&mut self, _id: &str, _input: &str) -> KernelResult<KernelOutput> {
            let receipt = ExecutionReceipt::new(
                "test-rec",
                _id,
                "in-hash",
                "out-hash",
                42,
                PolicySnapshot::new("v1.0"),
                CapsuleSnapshot::new(_id, "graph-hash"),
            );
            Ok(KernelOutput {
                receipt,
                verdict: Verdict::Pass,
                capsule_status: "Active".into(),
                output_hash: "out-hash".into(),
            })
        }

        async fn replay(
            &self,
            _rid: &str,
            _mode: ReplayMode,
        ) -> KernelResult<crate::kernel::time::replay::ReplayResult> {
            Err(KernelError::internal("not implemented"))
        }

        async fn rehydrate(&mut self, _id: &str) -> KernelResult<String> {
            Ok("Active".into())
        }

        async fn capsule_status(&self, _id: &str) -> KernelResult<String> {
            Ok("Active".into())
        }

        async fn list_receipts(&self, _id: &str) -> KernelResult<Vec<String>> {
            Ok(vec![])
        }

        async fn load_receipt(&self, _rid: &str) -> KernelResult<ExecutionReceipt> {
            Err(KernelError::internal("not implemented"))
        }
    }

    TestKernel
}
