//! **Evolutio** — the unfolding gate (BKG Reveland).
//!
//! In the Reveland, evolution is **Evolutio** (Latin for "unfolding"):
//! the gate where the kernel learns, adapts, and unfolds over time.
//!
//! The evolution kernel enables the kernel to improve over time:
//! - Records learning observations from truth verification results
//! - Analyzes patterns (divergence rates, repair frequency)
//! - Produces policy recommendations
//! - Queues evolution events for async processing
//!
//! # Async Design
//!
//! Evolution NEVER blocks execution. Events are queued and consumed
//! asynchronously between execution runs. This ensures:
//! - Zero latency added to the hot path
//! - No coupling between execution and learning
//! - Graceful degradation if the learner is unavailable

pub mod learner;
pub mod policy;
pub mod queue;

// Re-export key types.
pub use learner::{EvolutionLearner, LearningObservation, PolicyRecommendation};
pub use policy::{PolicyLineage, PolicyRecord};
pub use queue::{EvolutionEvent, EvolutionEventType, EvolutionQueue};
