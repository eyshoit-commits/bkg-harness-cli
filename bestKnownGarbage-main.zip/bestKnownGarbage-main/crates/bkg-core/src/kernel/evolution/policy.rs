//! Policy evolution — tracking policy changes over time.
//!
//! Policy snapshots are created at execution time and frozen in receipts.
//! The PolicyRecord tracks the lineage of policy changes over time.
//! Evolution is always async — policies change between runs, never during.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

// Re-export PolicySnapshot from execution module for convenience.
pub use crate::kernel::execution::receipts::PolicySnapshot;

/// Record of a policy version change in the evolution lineage.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicyRecord {
    /// Version identifier (hash-based).
    pub policy_version: String,
    /// When this policy version was applied.
    pub applied_at: DateTime<Utc>,
    /// Previous version (None for the initial policy).
    pub previous_version: Option<String>,
    /// Human-readable description of changes.
    pub changes: Vec<String>,
}

impl PolicyRecord {
    /// Create a new policy record.
    pub fn new(version: impl Into<String>) -> Self {
        Self {
            policy_version: version.into(),
            applied_at: Utc::now(),
            previous_version: None,
            changes: Vec::new(),
        }
    }

    /// Set the previous version.
    pub fn with_previous(mut self, prev: impl Into<String>) -> Self {
        self.previous_version = Some(prev.into());
        self
    }

    /// Add a change description.
    pub fn with_change(mut self, change: impl Into<String>) -> Self {
        self.changes.push(change.into());
        self
    }
}

/// Immutable lineage of all policy versions.
#[derive(Debug, Clone)]
pub struct PolicyLineage {
    records: Vec<PolicyRecord>,
}

impl PolicyLineage {
    /// Create an empty policy lineage.
    pub fn new() -> Self {
        Self {
            records: Vec::new(),
        }
    }

    /// Append a new policy record.
    pub fn push(&mut self, record: PolicyRecord) {
        self.records.push(record);
    }

    /// Get all records in order.
    pub fn all(&self) -> &[PolicyRecord] {
        &self.records
    }

    /// Get the latest policy version.
    pub fn latest_version(&self) -> Option<&str> {
        self.records.last().map(|r| r.policy_version.as_str())
    }

    /// Number of policy changes recorded.
    pub fn len(&self) -> usize {
        self.records.len()
    }

    /// Whether the lineage is empty.
    pub fn is_empty(&self) -> bool {
        self.records.is_empty()
    }
}

impl Default for PolicyLineage {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_policy_record_creation() {
        let rec = PolicyRecord::new("v1.0");
        assert_eq!(rec.policy_version, "v1.0");
        assert!(rec.previous_version.is_none());
        assert!(rec.changes.is_empty());
    }

    #[test]
    fn test_policy_record_with_history() {
        let rec = PolicyRecord::new("v2.0")
            .with_previous("v1.0")
            .with_change("increased retry limit to 5")
            .with_change("lowered repair threshold to 0.05");
        assert_eq!(rec.previous_version, Some("v1.0".into()));
        assert_eq!(rec.changes.len(), 2);
    }

    #[test]
    fn test_policy_lineage() {
        let mut lineage = PolicyLineage::new();
        lineage.push(PolicyRecord::new("v1.0"));
        lineage.push(PolicyRecord::new("v2.0").with_previous("v1.0"));
        assert_eq!(lineage.len(), 2);
        assert_eq!(lineage.latest_version(), Some("v2.0"));
    }

    #[test]
    fn test_empty_lineage() {
        let lineage = PolicyLineage::new();
        assert!(lineage.is_empty());
        assert!(lineage.latest_version().is_none());
    }

    #[test]
    fn test_policy_record_serialization() {
        let rec = PolicyRecord::new("v1.0").with_change("initial policy");
        let json = serde_json::to_string(&rec).unwrap();
        let back: PolicyRecord = serde_json::from_str(&json).unwrap();
        assert_eq!(back.policy_version, "v1.0");
    }
}
