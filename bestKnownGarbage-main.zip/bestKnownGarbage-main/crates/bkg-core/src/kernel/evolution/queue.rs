//! Evolution Queue — async processing of evolution events.
//!
//! Evolution is always asynchronous: policy changes are queued and
//! consumed between execution runs. They NEVER synchronously affect
//! an active execution.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// An event queued for the evolution system.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionEvent {
    /// Unique event ID.
    pub id: String,
    /// Capsule this event relates to.
    pub capsule_id: String,
    /// Type of evolution event.
    pub event_type: EvolutionEventType,
    /// Arbitrary payload data.
    pub payload: serde_json::Value,
    /// When this event was created.
    pub created_at: DateTime<Utc>,
}

/// Types of evolution events.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum EvolutionEventType {
    /// A new truth report is available for learning.
    TruthReportAvailable,
    /// Repair loop completed — analyze results.
    RepairCompleted,
    /// Replay detected divergence — adjust policy.
    ReplayDivergenceDetected,
    /// Manual policy update requested.
    PolicyUpdateRequested,
}

impl EvolutionEvent {
    /// Create a new evolution event.
    pub fn new(
        id: impl Into<String>,
        capsule_id: impl Into<String>,
        event_type: EvolutionEventType,
    ) -> Self {
        Self {
            id: id.into(),
            capsule_id: capsule_id.into(),
            event_type,
            payload: serde_json::json!({}),
            created_at: Utc::now(),
        }
    }

    /// Attach a payload.
    pub fn with_payload(mut self, payload: serde_json::Value) -> Self {
        self.payload = payload;
        self
    }
}

/// Async evolution event queue.
///
/// Events are produced by the execution pipeline and consumed
/// asynchronously by the evolution learner. The queue never blocks
/// execution — it grows unbounded (in production, bounded by a
/// configurable limit).
#[derive(Debug, Clone)]
pub struct EvolutionQueue {
    /// Pending evolution events.
    events: Vec<EvolutionEvent>,
    /// Maximum queue size (0 = unlimited).
    max_size: usize,
}

impl EvolutionQueue {
    /// Create a new evolution queue.
    pub fn new() -> Self {
        Self {
            events: Vec::new(),
            max_size: 1000,
        }
    }

    /// Create a queue with a maximum size.
    pub fn with_max_size(max_size: usize) -> Self {
        Self {
            events: Vec::new(),
            max_size,
        }
    }

    /// Enqueue an evolution event.
    ///
    /// Returns Ok(true) if queued, Ok(false) if queue is full (event dropped).
    /// Never blocks — evolution is always async.
    pub fn enqueue(&mut self, event: EvolutionEvent) -> bool {
        if self.max_size > 0 && self.events.len() >= self.max_size {
            return false; // Queue full — event dropped
        }
        self.events.push(event);
        true
    }

    /// Dequeue the next event for processing.
    pub fn dequeue(&mut self) -> Option<EvolutionEvent> {
        if self.events.is_empty() {
            None
        } else {
            Some(self.events.remove(0))
        }
    }

    /// Peek at the next event without removing it.
    pub fn peek(&self) -> Option<&EvolutionEvent> {
        self.events.first()
    }

    /// Number of pending events.
    pub fn len(&self) -> usize {
        self.events.len()
    }

    /// Whether the queue is empty.
    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// Drain all pending events.
    pub fn drain(&mut self) -> Vec<EvolutionEvent> {
        std::mem::take(&mut self.events)
    }

    /// Get the max queue size.
    pub fn max_size(&self) -> usize {
        self.max_size
    }
}

impl Default for EvolutionQueue {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_queue() {
        let queue = EvolutionQueue::new();
        assert!(queue.is_empty());
        assert_eq!(queue.len(), 0);
    }

    #[test]
    fn test_enqueue_dequeue() {
        let mut queue = EvolutionQueue::new();
        let event = EvolutionEvent::new("e1", "cap-1", EvolutionEventType::TruthReportAvailable);
        assert!(queue.enqueue(event));
        assert_eq!(queue.len(), 1);

        let popped = queue.dequeue().unwrap();
        assert_eq!(popped.id, "e1");
        assert!(queue.is_empty());
    }

    #[test]
    fn test_queue_order() {
        let mut queue = EvolutionQueue::new();
        queue.enqueue(EvolutionEvent::new(
            "e1",
            "c1",
            EvolutionEventType::TruthReportAvailable,
        ));
        queue.enqueue(EvolutionEvent::new(
            "e2",
            "c1",
            EvolutionEventType::RepairCompleted,
        ));

        assert_eq!(queue.dequeue().unwrap().id, "e1");
        assert_eq!(queue.dequeue().unwrap().id, "e2");
    }

    #[test]
    fn test_queue_max_size() {
        let mut queue = EvolutionQueue::with_max_size(2);
        assert!(queue.enqueue(EvolutionEvent::new(
            "e1",
            "c1",
            EvolutionEventType::TruthReportAvailable
        )));
        assert!(queue.enqueue(EvolutionEvent::new(
            "e2",
            "c1",
            EvolutionEventType::TruthReportAvailable
        )));
        assert!(!queue.enqueue(EvolutionEvent::new(
            "e3",
            "c1",
            EvolutionEventType::TruthReportAvailable
        )));
    }

    #[test]
    fn test_drain() {
        let mut queue = EvolutionQueue::new();
        queue.enqueue(EvolutionEvent::new(
            "e1",
            "c1",
            EvolutionEventType::TruthReportAvailable,
        ));
        queue.enqueue(EvolutionEvent::new(
            "e2",
            "c1",
            EvolutionEventType::RepairCompleted,
        ));

        let drained = queue.drain();
        assert_eq!(drained.len(), 2);
        assert!(queue.is_empty());
    }

    #[test]
    fn test_peek() {
        let mut queue = EvolutionQueue::new();
        queue.enqueue(EvolutionEvent::new(
            "e1",
            "c1",
            EvolutionEventType::TruthReportAvailable,
        ));
        let peeked = queue.peek().unwrap();
        assert_eq!(peeked.id, "e1");
        assert_eq!(queue.len(), 1); // peek doesn't remove
    }
}
