//! Evolution Learner — history-only learning from truth results.
//!
//! The learner consumes verified TruthReports and produces policy
//! recommendations for future executions. It NEVER touches past
//! receipts or truth files — evolution is forward-only.

use serde::{Deserialize, Serialize};

use crate::kernel::contracts::Verdict;

/// A learning observation derived from one truth verification.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LearningObservation {
    /// Receipt ID that was verified.
    pub receipt_id: String,
    /// Verdict from the truth check.
    pub verdict: Verdict,
    /// Drift score at verification time.
    pub drift_score: f64,
    /// Whether repair was needed.
    pub repair_needed: bool,
    /// Number of repair attempts (if any).
    pub repair_attempts: u8,
}

/// A policy recommendation produced by the learner.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicyRecommendation {
    /// Suggested new policy version.
    pub suggested_version: String,
    /// Changes recommended.
    pub changes: Vec<String>,
    /// Confidence in this recommendation [0.0, 1.0].
    pub confidence: f64,
}

/// The evolution learner — analyzes truth results for policy improvements.
#[derive(Debug, Clone)]
pub struct EvolutionLearner {
    /// Observations collected so far.
    observations: Vec<LearningObservation>,
    /// Current policy version being learned from.
    current_policy_version: String,
}

impl EvolutionLearner {
    /// Create a new evolution learner.
    pub fn new(policy_version: impl Into<String>) -> Self {
        Self {
            observations: Vec::new(),
            current_policy_version: policy_version.into(),
        }
    }

    /// Record a learning observation from a truth verification.
    ///
    /// # Hard Rule
    ///
    /// This only records the observation. It NEVER modifies past data.
    pub fn observe(&mut self, observation: LearningObservation) {
        self.observations.push(observation);
    }

    /// Analyze observations and produce policy recommendations.
    ///
    /// Returns recommendations if the learner detects patterns that
    /// suggest policy improvements.
    pub fn analyze(&self) -> Vec<PolicyRecommendation> {
        let mut recommendations = Vec::new();

        if self.observations.is_empty() {
            return recommendations;
        }

        // Count divergent vs pass
        let total = self.observations.len();
        let divergent_count = self
            .observations
            .iter()
            .filter(|o| o.verdict == Verdict::Divergent)
            .count();

        let divergence_rate = divergent_count as f64 / total as f64;

        // If divergence rate is high, suggest threshold adjustment
        if divergence_rate > 0.5 && total >= 5 {
            recommendations.push(PolicyRecommendation {
                suggested_version: format!("{}-adjusted", self.current_policy_version),
                changes: vec![format!(
                    "lowered repair threshold (divergence rate: {:.2})",
                    divergence_rate
                )],
                confidence: 0.6,
            });
        }

        // If many repairs needed, suggest retry limit change
        let repair_count = self.observations.iter().filter(|o| o.repair_needed).count();
        if repair_count as f64 / total as f64 > 0.3 {
            recommendations.push(PolicyRecommendation {
                suggested_version: format!("{}-retry-adjust", self.current_policy_version),
                changes: vec!["increased retry limit due to frequent repairs".to_string()],
                confidence: 0.4,
            });
        }

        recommendations
    }

    /// Get all observations.
    pub fn observations(&self) -> &[LearningObservation] {
        &self.observations
    }

    /// Number of observations collected.
    pub fn observation_count(&self) -> usize {
        self.observations.len()
    }

    /// Clear observations (e.g., after applying recommendations).
    pub fn clear(&mut self) {
        self.observations.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_learner() {
        let learner = EvolutionLearner::new("v1.0");
        assert!(learner.observations().is_empty());
        assert!(learner.analyze().is_empty());
    }

    #[test]
    fn test_record_observation() {
        let mut learner = EvolutionLearner::new("v1.0");
        learner.observe(LearningObservation {
            receipt_id: "rec-1".into(),
            verdict: Verdict::Pass,
            drift_score: 0.0,
            repair_needed: false,
            repair_attempts: 0,
        });
        assert_eq!(learner.observation_count(), 1);
    }

    #[test]
    fn test_high_divergence_rate_triggers_recommendation() {
        let mut learner = EvolutionLearner::new("v1.0");
        for i in 0..6 {
            learner.observe(LearningObservation {
                receipt_id: format!("rec-{i}"),
                verdict: if i < 4 {
                    Verdict::Divergent
                } else {
                    Verdict::Pass
                },
                drift_score: if i < 4 { 0.8 } else { 0.0 },
                repair_needed: i < 4,
                repair_attempts: if i < 4 { 2 } else { 0 },
            });
        }
        let recommendations = learner.analyze();
        assert!(!recommendations.is_empty());
    }

    #[test]
    fn test_clear_observations() {
        let mut learner = EvolutionLearner::new("v1.0");
        learner.observe(LearningObservation {
            receipt_id: "rec-1".into(),
            verdict: Verdict::Pass,
            drift_score: 0.0,
            repair_needed: false,
            repair_attempts: 0,
        });
        learner.clear();
        assert_eq!(learner.observation_count(), 0);
    }
}
