//! ExecutionReceipt — immutable record of one deterministic execution.
//!
//! # Invariants
//!
//! - receipts/*.json are NEVER overwritten after creation
//! - Every receipt freezes the policy environment via PolicySnapshot
//! - Every receipt pins the capsule graph via CapsuleSnapshot
//! - execution_seed guarantees bit-identical replay

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use crate::kernel::contracts::ExecutionSeed;

// ──────────────────────────────────────────────
// PolicySnapshot
// ──────────────────────────────────────────────

/// Frozen policy environment at execution time.
///
/// Replay MUST use this snapshot, NEVER the current system policy.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolicySnapshot {
    /// Hash of the policy definition at freeze time.
    pub policy_version: String,
    /// Routing weights for model/provider selection.
    pub routing_weights: HashMap<String, f32>,
    /// Maximum retry count for tool/LLM calls.
    pub retry_limit: u8,
    /// Threshold above which divergence is flagged.
    pub repair_threshold: f32,
}

impl PolicySnapshot {
    /// Create a new policy snapshot with the given version.
    pub fn new(version: impl Into<String>) -> Self {
        Self {
            policy_version: version.into(),
            routing_weights: HashMap::new(),
            retry_limit: 3,
            repair_threshold: 0.1,
        }
    }

    /// Set routing weights.
    pub fn with_routing_weights(mut self, weights: HashMap<String, f32>) -> Self {
        self.routing_weights = weights;
        self
    }

    /// Set retry limit.
    pub fn with_retry_limit(mut self, limit: u8) -> Self {
        self.retry_limit = limit;
        self
    }

    /// Set repair threshold.
    pub fn with_repair_threshold(mut self, threshold: f32) -> Self {
        self.repair_threshold = threshold;
        self
    }
}

// ──────────────────────────────────────────────
// CapsuleSnapshot
// ──────────────────────────────────────────────

/// Pinned capsule graph state at execution time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapsuleSnapshot {
    /// Capsule identifier.
    pub capsule_id: String,
    /// Deterministic hash of the full DAG.
    pub graph_hash: String,
    /// Per-node hashes: (node_id, hash).
    pub node_hashes: Vec<(String, String)>,
    /// Per-edge hashes: (edge_id, hash).
    pub edge_hashes: Vec<(String, String)>,
}

impl CapsuleSnapshot {
    /// Create a new capsule snapshot.
    pub fn new(capsule_id: impl Into<String>, graph_hash: impl Into<String>) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            graph_hash: graph_hash.into(),
            node_hashes: Vec::new(),
            edge_hashes: Vec::new(),
        }
    }

    /// Attach node hashes.
    pub fn with_node_hashes(mut self, hashes: Vec<(String, String)>) -> Self {
        self.node_hashes = hashes;
        self
    }

    /// Attach edge hashes.
    pub fn with_edge_hashes(mut self, hashes: Vec<(String, String)>) -> Self {
        self.edge_hashes = hashes;
        self
    }
}

// ──────────────────────────────────────────────
// ToolCallRecord
// ──────────────────────────────────────────────

/// Record of one tool or LLM call during execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolCallRecord {
    /// Node ID that made the call.
    pub node_id: String,
    /// Tool or model name.
    pub tool: String,
    /// Input hash.
    pub input_hash: String,
    /// Output hash.
    pub output_hash: String,
    /// Duration in milliseconds.
    pub duration_ms: u64,
}

impl ToolCallRecord {
    /// Create a new tool call record.
    pub fn new(
        node_id: impl Into<String>,
        tool: impl Into<String>,
        input_hash: impl Into<String>,
        output_hash: impl Into<String>,
        duration_ms: u64,
    ) -> Self {
        Self {
            node_id: node_id.into(),
            tool: tool.into(),
            input_hash: input_hash.into(),
            output_hash: output_hash.into(),
            duration_ms,
        }
    }
}

// ──────────────────────────────────────────────
// ExecutionReceipt (IMMUTABLE)
// ──────────────────────────────────────────────

/// Immutable record of one deterministic DAG execution.
///
/// # Hard Rules
///
/// - NEVER modified after creation
/// - Filed under receipts/<uuid>.json
/// - Replay MUST use this receipt's policy_snapshot + execution_seed
/// - Same (input, execution_seed, policy_snapshot, capsule_snapshot) → same output
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionReceipt {
    /// Unique receipt identifier (UUID).
    pub id: String,
    /// Capsule that was executed.
    pub capsule_id: String,
    /// Hash of the input passed to execution.
    pub input_hash: String,
    /// Hash of the output produced by execution.
    pub output_hash: String,
    /// Determinism anchor — makes replay bit-identical.
    pub execution_seed: ExecutionSeed,
    /// Policy environment frozen at execution time.
    pub policy_snapshot: PolicySnapshot,
    /// Capsule graph pinned at execution time.
    pub capsule_snapshot: CapsuleSnapshot,
    /// All tool/LLM calls made during execution.
    pub tool_calls: Vec<ToolCallRecord>,
    /// Wall-clock timestamp.
    pub timestamp: DateTime<Utc>,
}

impl ExecutionReceipt {
    /// Create a new execution receipt.
    pub fn new(
        id: impl Into<String>,
        capsule_id: impl Into<String>,
        input_hash: impl Into<String>,
        output_hash: impl Into<String>,
        execution_seed: ExecutionSeed,
        policy_snapshot: PolicySnapshot,
        capsule_snapshot: CapsuleSnapshot,
    ) -> Self {
        Self {
            id: id.into(),
            capsule_id: capsule_id.into(),
            input_hash: input_hash.into(),
            output_hash: output_hash.into(),
            execution_seed,
            policy_snapshot,
            capsule_snapshot,
            tool_calls: Vec::new(),
            timestamp: Utc::now(),
        }
    }

    /// Add a tool call record.
    pub fn with_tool_call(mut self, record: ToolCallRecord) -> Self {
        self.tool_calls.push(record);
        self
    }
}

// ──────────────────────────────────────────────
// KernelOutput
// ──────────────────────────────────────────────

/// Result of a kernel execution run.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KernelOutput {
    /// The execution receipt created by this run.
    pub receipt: ExecutionReceipt,
    /// The truth verdict for this execution.
    pub verdict: crate::kernel::contracts::Verdict,
    /// Capsule status after execution.
    pub capsule_status: String,
    /// Output hash (matches receipt.output_hash).
    pub output_hash: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_policy_snapshot_defaults() {
        let snap = PolicySnapshot::new("v1.0");
        assert_eq!(snap.policy_version, "v1.0");
        assert_eq!(snap.retry_limit, 3);
        assert!((snap.repair_threshold - 0.1).abs() < f32::EPSILON);
    }

    #[test]
    fn test_execution_receipt_creation() {
        let policy = PolicySnapshot::new("v1.0");
        let capsule_snap = CapsuleSnapshot::new("cap-1", "abc123");
        let receipt = ExecutionReceipt::new(
            "rec-1",
            "cap-1",
            "in-hash",
            "out-hash",
            42,
            policy,
            capsule_snap,
        );
        assert_eq!(receipt.id, "rec-1");
        assert_eq!(receipt.execution_seed, 42);
        assert!(receipt.tool_calls.is_empty());
    }

    #[test]
    fn test_receipt_immutability_round_trip() {
        let policy = PolicySnapshot::new("v1.0");
        let capsule_snap = CapsuleSnapshot::new("cap-1", "abc");
        let receipt =
            ExecutionReceipt::new("rec-rt", "cap-1", "in", "out", 99, policy, capsule_snap);
        let json = serde_json::to_string(&receipt).unwrap();
        let deserialized: ExecutionReceipt = serde_json::from_str(&json).unwrap();
        assert_eq!(deserialized.id, "rec-rt");
        assert_eq!(deserialized.execution_seed, 99);
    }

    #[test]
    fn test_tool_call_record() {
        let record = ToolCallRecord::new("node-1", "llm", "in-hash", "out-hash", 1500);
        assert_eq!(record.node_id, "node-1");
        assert_eq!(record.duration_ms, 1500);
    }

    #[test]
    fn test_kernel_output() {
        use crate::kernel::contracts::Verdict;
        let policy = PolicySnapshot::new("v1.0");
        let cs = CapsuleSnapshot::new("cap-1", "gh");
        let receipt = ExecutionReceipt::new("r", "c", "i", "o", 0, policy, cs);
        let output = KernelOutput {
            receipt,
            verdict: Verdict::Pass,
            capsule_status: "Active".into(),
            output_hash: "o".into(),
        };
        assert_eq!(output.capsule_status, "Active");
    }
}
