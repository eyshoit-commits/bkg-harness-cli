//! Execution DAG — minimal node/edge definitions for the execution kernel.
//!
//! These types are used by the executor to build and traverse the execution
//! graph. They are distinct from capsule's `CapsuleNode`/`CapsuleEdge`:
//! the execution DAG is a lightweight projection focused on tool calls
//! and their dependency ordering.

use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet, VecDeque};

// ──────────────────────────────────────────────
// Node
// ──────────────────────────────────────────────

/// A single operation in the execution DAG.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Node {
    /// Unique node identifier (references capsule node ID).
    pub id: String,
    /// Tool or model name to invoke.
    pub tool: String,
    /// Reference to the input data for this node.
    pub input_ref: String,
    /// Dependencies (node IDs that must execute first).
    pub dependencies: Vec<String>,
}

impl Node {
    /// Create a new execution node.
    pub fn new(
        id: impl Into<String>,
        tool: impl Into<String>,
        input_ref: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            tool: tool.into(),
            input_ref: input_ref.into(),
            dependencies: Vec::new(),
        }
    }

    /// Set dependencies for this node.
    pub fn with_dependencies(mut self, deps: Vec<String>) -> Self {
        self.dependencies = deps;
        self
    }
}

// ──────────────────────────────────────────────
// Edge
// ──────────────────────────────────────────────

/// A directed dependency edge in the execution DAG.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Edge {
    /// Source node ID.
    pub from: String,
    /// Target node ID.
    pub to: String,
}

impl Edge {
    /// Create a new edge.
    pub fn new(from: impl Into<String>, to: impl Into<String>) -> Self {
        Self {
            from: from.into(),
            to: to.into(),
        }
    }
}

// ──────────────────────────────────────────────
// ExecutionGraph
// ──────────────────────────────────────────────

/// A lightweight DAG for execution ordering.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionGraph {
    /// Nodes in the graph.
    pub nodes: HashMap<String, Node>,
    /// Edges in the graph.
    pub edges: Vec<Edge>,
}

impl ExecutionGraph {
    /// Create an empty execution graph.
    pub fn new() -> Self {
        Self {
            nodes: HashMap::new(),
            edges: Vec::new(),
        }
    }

    /// Add a node to the graph.
    pub fn add_node(&mut self, node: Node) {
        self.nodes.insert(node.id.clone(), node);
    }

    /// Add an edge. Returns error if it would create a cycle.
    pub fn add_edge(&mut self, edge: Edge) -> Result<(), String> {
        // Check for cycle before adding
        if self.would_create_cycle(&edge) {
            return Err(format!(
                "edge {} -> {} would create a cycle",
                edge.from, edge.to
            ));
        }
        self.edges.push(edge);
        Ok(())
    }

    /// Check if adding this edge would create a cycle.
    fn would_create_cycle(&self, edge: &Edge) -> bool {
        // BFS from edge.to to see if we reach edge.from
        let mut visited = HashSet::new();
        let mut queue = VecDeque::new();
        queue.push_back(edge.to.clone());

        while let Some(current) = queue.pop_front() {
            if current == edge.from {
                return true;
            }
            if !visited.insert(current.clone()) {
                continue;
            }
            for e in &self.edges {
                if e.from == current {
                    queue.push_back(e.to.clone());
                }
            }
        }
        false
    }

    /// Perform topological sort. Returns nodes in execution order (grouped by level).
    pub fn topological_levels(&self) -> Vec<Vec<String>> {
        let mut in_degree: HashMap<String, usize> = HashMap::new();
        for node_id in self.nodes.keys() {
            in_degree.entry(node_id.clone()).or_insert(0);
        }
        for edge in &self.edges {
            *in_degree.entry(edge.to.clone()).or_insert(0) += 1;
        }

        let mut levels = Vec::new();
        let mut current_level: Vec<String> = in_degree
            .iter()
            .filter(|&(_, deg)| *deg == 0)
            .map(|(id, _)| id.clone())
            .collect();

        let mut assigned = HashSet::new();

        while !current_level.is_empty() {
            levels.push(current_level.clone());
            let mut next_level = Vec::new();

            for node_id in &current_level {
                assigned.insert(node_id.clone());
                // Find all edges from this node
                let targets: Vec<String> = self
                    .edges
                    .iter()
                    .filter(|e| e.from == *node_id)
                    .map(|e| e.to.clone())
                    .collect();
                for target in targets {
                    let entry = in_degree.entry(target.clone()).or_insert(0);
                    *entry = entry.saturating_sub(1);
                    if *entry == 0 && !assigned.contains(&target) {
                        next_level.push(target);
                    }
                }
            }
            current_level = next_level;
        }

        levels
    }

    /// Get root nodes (no incoming edges).
    pub fn root_nodes(&self) -> Vec<String> {
        let mut has_incoming = HashSet::new();
        for edge in &self.edges {
            has_incoming.insert(edge.to.clone());
        }
        self.nodes
            .keys()
            .filter(|id| !has_incoming.contains(*id))
            .cloned()
            .collect()
    }

    /// Number of nodes in the graph.
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }
}

impl Default for ExecutionGraph {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_empty_graph() {
        let g = ExecutionGraph::new();
        assert_eq!(g.node_count(), 0);
        assert!(g.topological_levels().is_empty());
    }

    #[test]
    fn test_single_node() {
        let mut g = ExecutionGraph::new();
        g.add_node(Node::new("n1", "tool", "ref"));
        let levels = g.topological_levels();
        assert_eq!(levels.len(), 1);
        assert_eq!(levels[0], vec!["n1"]);
    }

    #[test]
    fn test_linear_chain() {
        let mut g = ExecutionGraph::new();
        g.add_node(Node::new("n1", "tool1", "ref1"));
        g.add_node(Node::new("n2", "tool2", "ref2"));
        g.add_edge(Edge::new("n1", "n2")).unwrap();
        let levels = g.topological_levels();
        assert_eq!(levels.len(), 2);
        assert_eq!(levels[0], vec!["n1"]);
        assert_eq!(levels[1], vec!["n2"]);
    }

    #[test]
    fn test_cycle_detection() {
        let mut g = ExecutionGraph::new();
        g.add_node(Node::new("n1", "t", "r"));
        g.add_node(Node::new("n2", "t", "r"));
        g.add_edge(Edge::new("n1", "n2")).unwrap();
        let result = g.add_edge(Edge::new("n2", "n1"));
        assert!(result.is_err());
    }

    #[test]
    fn test_diamond_graph() {
        let mut g = ExecutionGraph::new();
        g.add_node(Node::new("root", "t", "r"));
        g.add_node(Node::new("a", "t", "r"));
        g.add_node(Node::new("b", "t", "r"));
        g.add_node(Node::new("c", "t", "r"));
        g.add_edge(Edge::new("root", "a")).unwrap();
        g.add_edge(Edge::new("root", "b")).unwrap();
        g.add_edge(Edge::new("a", "c")).unwrap();
        g.add_edge(Edge::new("b", "c")).unwrap();
        let levels = g.topological_levels();
        // root -> [a,b] -> c
        assert_eq!(levels.len(), 3);
        assert_eq!(levels[0], vec!["root"]);
        assert_eq!(levels[2], vec!["c"]);
    }

    #[test]
    fn test_root_nodes() {
        let mut g = ExecutionGraph::new();
        g.add_node(Node::new("n1", "t", "r"));
        g.add_node(Node::new("n2", "t", "r"));
        g.add_edge(Edge::new("n1", "n2")).unwrap();
        let roots = g.root_nodes();
        assert_eq!(roots, vec!["n1"]);
    }
}
