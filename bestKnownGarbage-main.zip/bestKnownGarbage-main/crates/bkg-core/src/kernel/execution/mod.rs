//! **Executio** — the doing gate (BKG Reveland).
//!
//! In the Reveland, execution is **Executio** (Latin for "carrying out"):
//! the gate where intent becomes action, DAGs are built, and work gets done.
//!
//! The execution kernel is responsible for:
//! - Building execution DAGs from capsule graphs
//! - Executing nodes in topological order (parallel-safe)
//! - Generating immutable ExecutionReceipts
//!
//! # Determinism
//!
//! Every execution is seeded deterministically:
//! ```text
//! node_seed = hash(execution_seed || node_id)
//! ```
//! This ensures reproducible execution across runs.

pub mod dag;
pub mod executor;
pub mod receipts;

// Re-export key types.
pub use dag::{Edge, ExecutionGraph, Node};
pub use executor::{ExecutionResult, NodeExecutionResult, compute_node_seed, execute_graph};
pub use receipts::{
    CapsuleSnapshot, ExecutionReceipt, KernelOutput, PolicySnapshot, ToolCallRecord,
};
