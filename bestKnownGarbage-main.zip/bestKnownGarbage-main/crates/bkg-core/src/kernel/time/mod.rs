//! **Tempus** — the river gate (BKG Reveland).
//!
//! In the Reveland, time is **Tempus** (Latin for "time"):
//! the gate where events flow, replays unwind, and history reveals itself.
//!
//! The time kernel provides:
//! - Deterministic replay from ExecutionReceipts
//! - Diffing between expected and actual execution
//! - Event timeline for capsule history
//!
//! # Replay Modes
//!
//! | Mode | Behavior |
//! |------|----------|
//! | `Deterministic` | Bit-identical replay from receipt |
//! | `Verify` | Replay + diff against expected |
//! | `Annotate` | Replay with repair annotations |

pub mod diff;
pub mod replay;
pub mod timeline;

// Re-export key types.
pub use diff::{NodeDiff, ReplayDiff};
pub use replay::{ReplayContext, ReplayEngine, ReplayResult, ReplayStats};
pub use timeline::{EventTimeline, TimelineEvent, TypedEventPayload};
