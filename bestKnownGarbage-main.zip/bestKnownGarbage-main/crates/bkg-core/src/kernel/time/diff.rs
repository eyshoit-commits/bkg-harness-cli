//! ReplayDiff — output of comparing replayed execution against original.

use serde::{Deserialize, Serialize};

/// Result of comparing replayed execution to the original execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayDiff {
    /// Receipt ID that was replayed.
    pub receipt_id: String,
    /// Whether the replay output matches the original.
    pub matches: bool,
    /// Hash of the replayed output.
    pub replayed_output_hash: String,
    /// Hash of the original output (from receipt).
    pub original_output_hash: String,
    /// Per-node diffs, if any.
    pub node_diffs: Vec<NodeDiff>,
    /// Duration of replay in milliseconds.
    pub duration_ms: u64,
}

/// Diff for a single node between original and replay.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeDiff {
    /// Node ID that was compared.
    pub node_id: String,
    /// Whether this node's output matches.
    pub matches: bool,
    /// Original output hash.
    pub original_hash: String,
    /// Replayed output hash.
    pub replayed_hash: String,
}

impl ReplayDiff {
    /// Create a new replay diff.
    pub fn new(
        receipt_id: impl Into<String>,
        replayed_output_hash: impl Into<String>,
        original_output_hash: impl Into<String>,
        duration_ms: u64,
    ) -> Self {
        let replayed = replayed_output_hash.into();
        let original = original_output_hash.into();
        Self {
            receipt_id: receipt_id.into(),
            matches: replayed == original,
            replayed_output_hash: replayed,
            original_output_hash: original,
            node_diffs: Vec::new(),
            duration_ms,
        }
    }

    /// Add a node-level diff.
    pub fn with_node_diff(mut self, diff: NodeDiff) -> Self {
        if !diff.matches {
            self.matches = false;
        }
        self.node_diffs.push(diff);
        self
    }
}

impl NodeDiff {
    /// Create a new node diff.
    pub fn new(
        node_id: impl Into<String>,
        original_hash: impl Into<String>,
        replayed_hash: impl Into<String>,
    ) -> Self {
        let orig = original_hash.into();
        let rep = replayed_hash.into();
        Self {
            node_id: node_id.into(),
            matches: orig == rep,
            original_hash: orig,
            replayed_hash: rep,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_matching_replay() {
        let diff = ReplayDiff::new("rec-1", "abc123", "abc123", 100);
        assert!(diff.matches);
    }

    #[test]
    fn test_mismatching_replay() {
        let diff = ReplayDiff::new("rec-1", "abc123", "def456", 100);
        assert!(!diff.matches);
    }

    #[test]
    fn test_node_diff() {
        let nd = NodeDiff::new("node-1", "abc", "def");
        assert!(!nd.matches);
        assert_eq!(nd.node_id, "node-1");
    }

    #[test]
    fn test_node_diff_matching() {
        let nd = NodeDiff::new("node-1", "abc", "abc");
        assert!(nd.matches);
    }

    #[test]
    fn test_diff_serialization() {
        let mut diff = ReplayDiff::new("rec-1", "abc", "def", 200);
        diff = diff.with_node_diff(NodeDiff::new("n1", "abc", "def"));
        let json = serde_json::to_string(&diff).unwrap();
        let back: ReplayDiff = serde_json::from_str(&json).unwrap();
        assert_eq!(back.receipt_id, "rec-1");
        assert!(!back.matches);
        assert_eq!(back.node_diffs.len(), 1);
    }

    #[test]
    fn test_node_diff_overrides_match() {
        let mut diff = ReplayDiff::new("rec-1", "abc", "abc", 50);
        diff = diff.with_node_diff(NodeDiff::new("n1", "abc", "def"));
        assert!(!diff.matches); // node diff overrides the overall match
    }
}
