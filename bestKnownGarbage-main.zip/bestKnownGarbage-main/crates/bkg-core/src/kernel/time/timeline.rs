//! **Tempus** — the causal stream (BKG Reveland).
//!
//! In the Reveland, the timeline is **Tempus** (Latin for "time"):
//! the append-only causal stream that encodes the DAG of execution history.
//!
//! # Causal Timeline — append-only event stream with parent_event linking.
//!
//! Unlike a flat log, every event carries an optional `parent_event` that
//! encodes the causal DAG structure: executions fork into repair events,
//! repair re-verifies, replay branches off an existing receipt, etc.
//!
//! # Invariants
//!
//! - timeline.jsonl is append-only (never modified in place)
//! - Every event has a unique event_id
//! - parent_event links to a previous event (or None for root events)

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::fmt;

// ──────────────────────────────────────────────
// TypedEventPayload
// ──────────────────────────────────────────────

/// Typed payload for timeline events — replaces the old `EventType` + `serde_json::Value` pattern.
///
/// Every variant carries typed data relevant to that event type, eliminating JSON schema
/// drift during replay. Consumers MUST match on all variants — the compiler enforces this.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TypedEventPayload {
    /// Execution started (no additional data yet).
    ExecutionStarted,
    /// Execution finished (no additional data yet).
    ExecutionFinished,
    /// A receipt was stored with a given ID.
    ReceiptStored { receipt_id: String },
    /// Truth verification produced a report hash.
    TruthVerified { report_hash: String },
    /// Repair was triggered for a given reason.
    RepairTriggered { reason: String },
    /// A replay was executed (no additional data yet).
    ReplayExecuted,
    /// A policy snapshot was taken with a given hash.
    PolicyUpdated { policy_hash: String },
    /// SWD bridge: a `FileSnapshot` was committed.
    /// The `snapshot_hash` enables lookup in the SWD system.
    FileCommitted { snapshot_hash: String },
}

// ──────────────────────────────────────────────
// TimelineEvent
// ──────────────────────────────────────────────

/// A single event in the causal timeline.
///
/// Each event carries a `TypedEventPayload` that determines both the category
/// and the associated data — no untyped JSON payloads.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineEvent {
    /// Unique event identifier.
    pub event_id: String,
    /// Capsule this event belongs to.
    pub capsule_id: String,
    /// Optional link to the causal parent event.
    pub parent_event: Option<String>,
    /// Typed event payload (category + data combined).
    pub event_type: TypedEventPayload,
    /// Wall-clock timestamp.
    pub timestamp: DateTime<Utc>,
}

impl TimelineEvent {
    /// Create a new timeline event with a typed payload.
    pub fn new(
        event_id: impl Into<String>,
        capsule_id: impl Into<String>,
        event_type: TypedEventPayload,
    ) -> Self {
        Self {
            event_id: event_id.into(),
            capsule_id: capsule_id.into(),
            parent_event: None,
            event_type,
            timestamp: Utc::now(),
        }
    }

    /// Set the causal parent event.
    pub fn with_parent(mut self, parent: impl Into<String>) -> Self {
        self.parent_event = Some(parent.into());
        self
    }
}

// ──────────────────────────────────────────────
// TimelineError
// ──────────────────────────────────────────────

/// Errors produced while appending events to a timeline.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TimelineError {
    /// Event IDs must be unique within a timeline.
    DuplicateEventId { event_id: String },
    /// Parent events must already exist in the timeline.
    MissingParentEvent {
        event_id: String,
        parent_event: String,
    },
    /// Events must belong to the same capsule as the timeline.
    CapsuleMismatch {
        timeline_capsule_id: String,
        event_capsule_id: String,
    },
}

impl fmt::Display for TimelineError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DuplicateEventId { event_id } => {
                write!(f, "duplicate event_id in timeline: {event_id}")
            }
            Self::MissingParentEvent {
                event_id,
                parent_event,
            } => {
                write!(
                    f,
                    "timeline event {event_id} references missing parent event {parent_event}"
                )
            }
            Self::CapsuleMismatch {
                timeline_capsule_id,
                event_capsule_id,
            } => {
                write!(
                    f,
                    "event capsule id {event_capsule_id} does not match timeline capsule id {timeline_capsule_id}"
                )
            }
        }
    }
}

impl std::error::Error for TimelineError {}

// ──────────────────────────────────────────────
// EventTimeline
// ──────────────────────────────────────────────

/// Append-only collection of causal timeline events.
#[derive(Debug, Clone)]
pub struct EventTimeline {
    /// Capsule this timeline belongs to.
    capsule_id: String,
    /// Events in order (monotonically appended).
    events: Vec<TimelineEvent>,
    /// Quick lookup by event_id.
    indices: std::collections::HashMap<String, usize>,
}

impl EventTimeline {
    /// Create a new empty timeline.
    pub fn new(capsule_id: impl Into<String>) -> Self {
        Self {
            capsule_id: capsule_id.into(),
            events: Vec::new(),
            indices: std::collections::HashMap::new(),
        }
    }

    /// Append an event. Events are append-only — never modified.
    ///
    /// Returns an error if the event is invalid for this timeline.
    pub fn push(&mut self, event: TimelineEvent) -> Result<(), TimelineError> {
        if event.capsule_id != self.capsule_id {
            return Err(TimelineError::CapsuleMismatch {
                timeline_capsule_id: self.capsule_id.clone(),
                event_capsule_id: event.capsule_id.clone(),
            });
        }

        if let Some(ref parent) = event.parent_event {
            if !self.indices.contains_key(parent) {
                return Err(TimelineError::MissingParentEvent {
                    event_id: event.event_id.clone(),
                    parent_event: parent.clone(),
                });
            }
        }

        if self.indices.contains_key(&event.event_id) {
            return Err(TimelineError::DuplicateEventId {
                event_id: event.event_id.clone(),
            });
        }

        let idx = self.events.len();
        self.indices.insert(event.event_id.clone(), idx);
        self.events.push(event);
        Ok(())
    }

    /// Get an event by ID.
    pub fn get(&self, event_id: &str) -> Option<&TimelineEvent> {
        self.indices.get(event_id).map(|&idx| &self.events[idx])
    }

    /// Get all events in order.
    pub fn all(&self) -> &[TimelineEvent] {
        &self.events
    }

    /// Number of events.
    pub fn len(&self) -> usize {
        self.events.len()
    }

    /// Whether the timeline is empty.
    pub fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// Get events for a specific time range.
    pub fn time_range(&self, start: &DateTime<Utc>, end: &DateTime<Utc>) -> Vec<&TimelineEvent> {
        self.events
            .iter()
            .filter(|e| e.timestamp >= *start && e.timestamp <= *end)
            .collect()
    }

    /// Filter events by a predicate on their typed payload.
    ///
    /// Replaces the old `by_type` + untyped JSON approach.
    /// Use with `matches!` for type-safe filtering:
    ///
    /// ```ignore
    /// let file_events = tl.filter_by(|p| matches!(p, TypedEventPayload::FileCommitted { .. }));
    /// ```
    pub fn filter_by(&self, predicate: impl Fn(&TypedEventPayload) -> bool) -> Vec<&TimelineEvent> {
        self.events
            .iter()
            .filter(|e| predicate(&e.event_type))
            .collect()
    }

    /// Get children of a given event (events that point to it as parent).
    pub fn children_of(&self, event_id: &str) -> Vec<&TimelineEvent> {
        self.events
            .iter()
            .filter(|e| e.parent_event.as_deref() == Some(event_id))
            .collect()
    }

    /// Capsule ID this timeline belongs to.
    pub fn capsule_id(&self) -> &str {
        &self.capsule_id
    }

    /// Clear all events (for testing only).
    #[cfg(test)]
    pub fn clear(&mut self) {
        self.events.clear();
        self.indices.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_event(id: &str, payload: TypedEventPayload) -> TimelineEvent {
        TimelineEvent::new(id, "cap-1", payload)
    }

    #[test]
    fn test_empty_timeline() {
        let tl = EventTimeline::new("cap-1");
        assert!(tl.is_empty());
        assert_eq!(tl.len(), 0);
    }

    #[test]
    fn test_append_events() {
        let mut tl = EventTimeline::new("cap-1");
        tl.push(make_event("e1", TypedEventPayload::ExecutionStarted))
            .unwrap();
        tl.push(make_event("e2", TypedEventPayload::ExecutionFinished))
            .unwrap();
        assert_eq!(tl.len(), 2);
    }

    #[test]
    fn test_get_by_id() {
        let mut tl = EventTimeline::new("cap-1");
        tl.push(make_event("e1", TypedEventPayload::ExecutionStarted))
            .unwrap();
        let event = tl.get("e1").unwrap();
        assert!(matches!(
            event.event_type,
            TypedEventPayload::ExecutionStarted
        ));
    }

    #[test]
    fn test_parent_linking() {
        let mut tl = EventTimeline::new("cap-1");
        let e1 = make_event("e1", TypedEventPayload::ExecutionStarted);
        let e2 = TimelineEvent::new(
            "e2",
            "cap-1",
            TypedEventPayload::RepairTriggered {
                reason: "drift detected".into(),
            },
        )
        .with_parent("e1");
        tl.push(e1).unwrap();
        tl.push(e2).unwrap();
        let children = tl.children_of("e1");
        assert_eq!(children.len(), 1);
        assert_eq!(children[0].event_id, "e2");
    }

    #[test]
    fn test_filter_by() {
        let mut tl = EventTimeline::new("cap-1");
        tl.push(make_event("e1", TypedEventPayload::ExecutionStarted))
            .unwrap();
        tl.push(make_event("e2", TypedEventPayload::ExecutionFinished))
            .unwrap();
        tl.push(make_event("e3", TypedEventPayload::ExecutionStarted))
            .unwrap();
        let started = tl.filter_by(|p| matches!(p, TypedEventPayload::ExecutionStarted));
        assert_eq!(started.len(), 2);
    }

    #[test]
    fn test_event_serialization_with_data() {
        let e = TimelineEvent::new(
            "e1",
            "cap-1",
            TypedEventPayload::ReceiptStored {
                receipt_id: "rec-1".into(),
            },
        );
        let json = serde_json::to_string(&e).unwrap();
        let back: TimelineEvent = serde_json::from_str(&json).unwrap();
        assert_eq!(back.event_id, "e1");
        assert!(
            matches!(back.event_type, TypedEventPayload::ReceiptStored { receipt_id } if receipt_id == "rec-1")
        );
    }

    #[test]
    fn test_rejects_duplicate_event_id() {
        let mut tl = EventTimeline::new("cap-1");
        tl.push(make_event("e1", TypedEventPayload::ExecutionStarted))
            .unwrap();
        let result = tl.push(make_event("e1", TypedEventPayload::ExecutionFinished));
        assert_eq!(
            result.unwrap_err(),
            TimelineError::DuplicateEventId {
                event_id: "e1".to_string()
            }
        );
    }

    #[test]
    fn test_rejects_missing_parent_event() {
        let mut tl = EventTimeline::new("cap-1");
        let event = TimelineEvent::new(
            "e2",
            "cap-1",
            TypedEventPayload::RepairTriggered {
                reason: "drift detected".into(),
            },
        )
        .with_parent("missing-parent");

        let result = tl.push(event);
        assert_eq!(
            result.unwrap_err(),
            TimelineError::MissingParentEvent {
                event_id: "e2".to_string(),
                parent_event: "missing-parent".to_string()
            }
        );
    }

    #[test]
    fn test_rejects_capsule_id_mismatch() {
        let mut tl = EventTimeline::new("cap-1");
        let event = TimelineEvent::new("e2", "cap-2", TypedEventPayload::ExecutionStarted);

        let result = tl.push(event);
        assert_eq!(
            result.unwrap_err(),
            TimelineError::CapsuleMismatch {
                timeline_capsule_id: "cap-1".to_string(),
                event_capsule_id: "cap-2".to_string()
            }
        );
    }

    #[test]
    fn test_all_payload_variants_serialize() {
        let variants: Vec<TypedEventPayload> = vec![
            TypedEventPayload::ExecutionStarted,
            TypedEventPayload::ExecutionFinished,
            TypedEventPayload::ReceiptStored {
                receipt_id: "r1".into(),
            },
            TypedEventPayload::TruthVerified {
                report_hash: "h1".into(),
            },
            TypedEventPayload::RepairTriggered {
                reason: "test".into(),
            },
            TypedEventPayload::ReplayExecuted,
            TypedEventPayload::PolicyUpdated {
                policy_hash: "h2".into(),
            },
            TypedEventPayload::FileCommitted {
                snapshot_hash: "h3".into(),
            },
        ];
        for variant in &variants {
            let json = serde_json::to_string(variant).unwrap();
            let back: TypedEventPayload = serde_json::from_str(&json).unwrap();
            // Verify discriminant equality via debug formatting
            assert_eq!(
                format!("{:?}", variant),
                format!("{:?}", back),
                "round-trip failed for {:?}",
                variant
            );
        }
    }

    #[test]
    fn test_file_committed_carries_hash() {
        let e = TimelineEvent::new(
            "e1",
            "cap-1",
            TypedEventPayload::FileCommitted {
                snapshot_hash: "sha256:abc123".into(),
            },
        );
        assert!(matches!(
            e.event_type,
            TypedEventPayload::FileCommitted { ref snapshot_hash }
            if snapshot_hash == "sha256:abc123"
        ));
    }
}
