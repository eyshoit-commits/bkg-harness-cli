//! Replay Engine — deterministic re-execution with full context pinning.
//!
//! # Replay Contract
//!
//! Replay is a pure function:
//! ```text
//! f(input, execution_seed, policy_snapshot, capsule_snapshot)
//! → identical DAG + bit-identical hashes
//! ```
//!
//! Replay MUST use the receipt's policy_snapshot, NEVER the current policy.
//! Replay MUST use the receipt's execution_seed for deterministic routing.
//!
//! # Replay Modes
//!
//! - **Deterministic**: full pinning (policy + seed + capsule snapshot)
//! - **Live**: current provider/model, same DAG structure
//! - **Hybrid**: deterministic DAG + live LLM/tool calls
//! - **AnomalyOnly**: only re-execute nodes marked divergent

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::kernel::contracts::{ExecutionSeed, ReplayMode};
use crate::kernel::execution::receipts::ExecutionReceipt;
use crate::kernel::time::diff::ReplayDiff;

/// Full replay context with all pinned state.
///
/// # Hard Rule
///
/// Deterministic replay MUST use this context exclusively.
/// No runtime mutation, no current-policy leakage.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayContext {
    /// The original execution receipt (contains pinned policy + seed + snapshot).
    pub receipt: ExecutionReceipt,
}

impl ReplayContext {
    /// Create a new replay context from a receipt.
    pub fn new(receipt: ExecutionReceipt) -> Self {
        Self { receipt }
    }

    /// Get the execution seed for deterministic routing.
    pub fn execution_seed(&self) -> ExecutionSeed {
        self.receipt.execution_seed
    }

    /// Get the pinning key: (execution_seed, policy_version, capsule_graph_hash).
    pub fn pinning_key(&self) -> (ExecutionSeed, String, String) {
        (
            self.receipt.execution_seed,
            self.receipt.policy_snapshot.policy_version.clone(),
            self.receipt.capsule_snapshot.graph_hash.clone(),
        )
    }
}

/// Statistics from a replay run.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayStats {
    /// Duration of replay in milliseconds.
    pub duration_ms: u64,
    /// Number of nodes replayed.
    pub nodes_replayed: usize,
    /// Number of tool/LLM calls made.
    pub tool_calls: usize,
    /// Wall-clock time when replay started.
    pub started_at: DateTime<Utc>,
    /// Wall-clock time when replay finished.
    pub finished_at: DateTime<Utc>,
}

/// Full result of a replay operation.
#[derive(Debug, Clone)]
pub struct ReplayResult {
    /// The diff between original and replayed output.
    pub diff: ReplayDiff,
    /// Statistics about the replay run.
    pub stats: ReplayStats,
    /// Mode used for this replay.
    pub mode: ReplayMode,
}

/// Replay Engine — executes deterministic replay of a previous execution.
#[derive(Debug, Clone)]
pub struct ReplayEngine {
    /// The replay context with pinned state.
    context: ReplayContext,
    /// Current replay mode.
    mode: ReplayMode,
}

impl ReplayEngine {
    /// Create a new replay engine from a context.
    pub fn new(context: ReplayContext) -> Self {
        Self {
            context,
            mode: ReplayMode::Deterministic,
        }
    }

    /// Set the replay mode.
    pub fn with_mode(mut self, mode: ReplayMode) -> Self {
        self.mode = mode;
        self
    }

    /// Get the current replay context.
    pub fn context(&self) -> &ReplayContext {
        &self.context
    }

    /// Get the current replay mode.
    pub fn mode(&self) -> &ReplayMode {
        &self.mode
    }

    /// Execute a replay (simulated — compares hashes).
    ///
    /// In production, this would re-execute the DAG with the pinned context.
    /// For now, it compares the receipt's output hash against a provided
    /// replayed output hash.
    pub fn replay(
        &self,
        replayed_output_hash: &str,
        duration_ms: u64,
        nodes_replayed: usize,
    ) -> ReplayResult {
        let started_at = Utc::now();

        let diff = if self.mode == ReplayMode::Deterministic {
            // Deterministic: compare against receipt's original
            ReplayDiff::new(
                &self.context.receipt.id,
                replayed_output_hash,
                &self.context.receipt.output_hash,
                duration_ms,
            )
        } else {
            // Non-deterministic modes: always mark as matching (live comparison)
            ReplayDiff::new(
                &self.context.receipt.id,
                replayed_output_hash,
                replayed_output_hash,
                duration_ms,
            )
        };

        let stats = ReplayStats {
            duration_ms,
            nodes_replayed,
            tool_calls: self.context.receipt.tool_calls.len(),
            started_at,
            finished_at: Utc::now(),
        };

        ReplayResult {
            diff,
            stats,
            mode: self.mode.clone(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::execution::receipts::{CapsuleSnapshot, PolicySnapshot};

    fn make_receipt(output_hash: &str, seed: ExecutionSeed) -> ExecutionReceipt {
        ExecutionReceipt::new(
            "rec-1",
            "cap-1",
            "in-hash",
            output_hash,
            seed,
            PolicySnapshot::new("v1.0"),
            CapsuleSnapshot::new("cap-1", "graph-hash"),
        )
    }

    #[test]
    fn test_replay_context_creation() {
        let receipt = make_receipt("out", 42);
        let ctx = ReplayContext::new(receipt);
        assert_eq!(ctx.execution_seed(), 42);
    }

    #[test]
    fn test_pinning_key() {
        let receipt = make_receipt("out", 42);
        let ctx = ReplayContext::new(receipt);
        let (seed, policy, graph) = ctx.pinning_key();
        assert_eq!(seed, 42);
        assert_eq!(policy, "v1.0");
        assert_eq!(graph, "graph-hash");
    }

    #[test]
    fn test_deterministic_replay_match() {
        let receipt = make_receipt("abc123", 42);
        let ctx = ReplayContext::new(receipt);
        let engine = ReplayEngine::new(ctx);
        let result = engine.replay("abc123", 100, 5);
        assert!(result.diff.matches);
    }

    #[test]
    fn test_deterministic_replay_mismatch() {
        let receipt = make_receipt("abc123", 42);
        let ctx = ReplayContext::new(receipt);
        let engine = ReplayEngine::new(ctx);
        let result = engine.replay("def456", 100, 5);
        assert!(!result.diff.matches);
    }

    #[test]
    fn test_live_mode_always_matches() {
        let receipt = make_receipt("abc123", 42);
        let ctx = ReplayContext::new(receipt);
        let engine = ReplayEngine::new(ctx).with_mode(ReplayMode::Live);
        let result = engine.replay("different_output", 100, 5);
        // Live mode doesn't compare — same DAG structure is sufficient
        assert!(result.diff.matches);
    }

    #[test]
    fn test_replay_stats() {
        let receipt = make_receipt("abc", 42);
        let ctx = ReplayContext::new(receipt);
        let engine = ReplayEngine::new(ctx);
        let result = engine.replay("abc", 200, 10);
        assert_eq!(result.stats.duration_ms, 200);
        assert_eq!(result.stats.nodes_replayed, 10);
    }

    #[test]
    fn test_replay_mode_preservation() {
        let receipt = make_receipt("abc", 42);
        let ctx = ReplayContext::new(receipt);
        let engine = ReplayEngine::new(ctx).with_mode(ReplayMode::AnomalyOnly);
        assert_eq!(*engine.mode(), ReplayMode::AnomalyOnly);
    }
}
