//! **Pacta** — the covenant gate (BKG Reveland).
//!
//! In the Reveland, contracts are **Pacta** (Latin for "covenants"):
//! the gate where invariants are sworn, errors are named, and laws are written.
//!
//! # UCC-4 Kernel Contracts — constants, invariants, and kernel-level error types.
//!
//! # Hard Invariants
//!
//! - MAX_REPAIR_ATTEMPTS = 3 — repair loop halts after this
//! - receipts/* and truth/* are NEVER overwritten
//! - Repair only in VERIFY → REPAIR → VERIFY flow
//! - Replay MUST use receipt's policy_snapshot, never current policy
//! - Same inputs + same execution_seed → same outputs

use serde::{Deserialize, Serialize};
use std::fmt;

// ──────────────────────────────────────────────
// Constants
// ──────────────────────────────────────────────

/// Maximum number of repair cycles before a capsule is locked.
pub const MAX_REPAIR_ATTEMPTS: u8 = 3;

/// Current kernel version.
pub const KERNEL_VERSION: &str = "0.1.0";

// ──────────────────────────────────────────────
// KernelError
// ──────────────────────────────────────────────

/// Unified error type for all kernel operations.
#[derive(Debug, Clone)]
pub enum KernelError {
    /// Capsule not found in storage.
    CapsuleNotFound { capsule_id: String },
    /// Receipt not found.
    ReceiptNotFound { receipt_id: String },
    /// Data integrity violation (hash mismatch, corrupt file).
    CorruptData {
        capsule_id: String,
        target_id: String,
        expected_hash: String,
        actual_hash: String,
    },
    /// Execution determinism violation — replay produced different output.
    DeterminismViolation {
        receipt_id: String,
        expected_hash: String,
        actual_hash: String,
    },
    /// Capsule in terminal state (Locked/Broken) — execution blocked.
    CapsuleLocked { capsule_id: String, status: String },
    /// Repair loop exhausted without convergence.
    RepairExhausted {
        capsule_id: String,
        attempts: u8,
        last_score: f64,
    },
    /// IO or storage error.
    Storage { detail: String },
    /// Operation not supported in current state.
    InvalidOperation { detail: String },
    /// Generic internal error.
    Internal { detail: String },
}

impl KernelError {
    pub fn capsule_not_found(capsule_id: impl Into<String>) -> Self {
        Self::CapsuleNotFound {
            capsule_id: capsule_id.into(),
        }
    }

    pub fn receipt_not_found(receipt_id: impl Into<String>) -> Self {
        Self::ReceiptNotFound {
            receipt_id: receipt_id.into(),
        }
    }

    pub fn corrupt_data(
        capsule_id: impl Into<String>,
        target_id: impl Into<String>,
        expected_hash: impl Into<String>,
        actual_hash: impl Into<String>,
    ) -> Self {
        Self::CorruptData {
            capsule_id: capsule_id.into(),
            target_id: target_id.into(),
            expected_hash: expected_hash.into(),
            actual_hash: actual_hash.into(),
        }
    }

    pub fn determinism_violation(
        receipt_id: impl Into<String>,
        expected_hash: impl Into<String>,
        actual_hash: impl Into<String>,
    ) -> Self {
        Self::DeterminismViolation {
            receipt_id: receipt_id.into(),
            expected_hash: expected_hash.into(),
            actual_hash: actual_hash.into(),
        }
    }

    pub fn capsule_locked(capsule_id: impl Into<String>, status: impl Into<String>) -> Self {
        Self::CapsuleLocked {
            capsule_id: capsule_id.into(),
            status: status.into(),
        }
    }

    pub fn repair_exhausted(capsule_id: impl Into<String>, attempts: u8, last_score: f64) -> Self {
        Self::RepairExhausted {
            capsule_id: capsule_id.into(),
            attempts,
            last_score,
        }
    }

    pub fn storage(detail: impl Into<String>) -> Self {
        Self::Storage {
            detail: detail.into(),
        }
    }

    pub fn invalid_operation(detail: impl Into<String>) -> Self {
        Self::InvalidOperation {
            detail: detail.into(),
        }
    }

    pub fn internal(detail: impl Into<String>) -> Self {
        Self::Internal {
            detail: detail.into(),
        }
    }
}

impl fmt::Display for KernelError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::CapsuleNotFound { capsule_id } => {
                write!(f, "[kernel] capsule not found: {capsule_id}")
            }
            Self::ReceiptNotFound { receipt_id } => {
                write!(f, "[kernel] receipt not found: {receipt_id}")
            }
            Self::CorruptData {
                capsule_id,
                target_id,
                expected_hash,
                actual_hash,
            } => {
                write!(
                    f,
                    "[kernel] corruption in {capsule_id}/{target_id}: \
                     expected hash {expected_hash}, got {actual_hash}"
                )
            }
            Self::DeterminismViolation {
                receipt_id,
                expected_hash,
                actual_hash,
            } => {
                write!(
                    f,
                    "[kernel] determinism violation in {receipt_id}: \
                     expected {expected_hash}, got {actual_hash}"
                )
            }
            Self::CapsuleLocked { capsule_id, status } => {
                write!(
                    f,
                    "[kernel] capsule {capsule_id} is locked (status: {status})"
                )
            }
            Self::RepairExhausted {
                capsule_id,
                attempts,
                last_score,
            } => {
                write!(
                    f,
                    "[kernel] repair exhausted for {capsule_id}: \
                     {attempts} attempts, last score {last_score}"
                )
            }
            Self::Storage { detail } => write!(f, "[kernel] storage error: {detail}"),
            Self::InvalidOperation { detail } => write!(f, "[kernel] invalid operation: {detail}"),
            Self::Internal { detail } => write!(f, "[kernel] internal error: {detail}"),
        }
    }
}

impl std::error::Error for KernelError {}

/// Convenience alias for kernel operations.
pub type KernelResult<T> = Result<T, KernelError>;

impl From<std::io::Error> for KernelError {
    fn from(err: std::io::Error) -> Self {
        Self::Storage {
            detail: format!("IO error: {err}"),
        }
    }
}

impl From<serde_json::Error> for KernelError {
    fn from(err: serde_json::Error) -> Self {
        Self::Internal {
            detail: format!("serialization error: {err}"),
        }
    }
}

// ──────────────────────────────────────────────
// ReplayMode
// ──────────────────────────────────────────────

/// Controls how replay executes.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum ReplayMode {
    /// Deterministic: uses receipt's policy_snapshot + execution_seed only.
    Deterministic,
    /// Live: current provider/model, same DAG structure.
    Live,
    /// Hybrid: deterministic DAG + live LLM/tool calls.
    Hybrid,
    /// AnomalyOnly: only re-executes nodes marked divergent.
    AnomalyOnly,
}

// ──────────────────────────────────────────────
// Verdict
// ──────────────────────────────────────────────

/// Result of a truth verification.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum Verdict {
    /// Execution matches expected state exactly.
    Pass,
    /// Minor deviation within tolerance.
    Warn,
    /// Significant deviation — repair required.
    Divergent,
}

// ──────────────────────────────────────────────
// ExecutionSeed
// ──────────────────────────────────────────────

/// Determinism anchor for one execution run.
///
/// Every tool/LLM call within this execution MUST hash
/// `(execution_seed, policy_snapshot.policy_version, node_id)`
/// into its random/routing/retry decisions to guarantee bit-identical replay.
pub type ExecutionSeed = u64;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = KernelError::capsule_not_found("cap-1");
        assert!(err.to_string().contains("cap-1"));
    }

    #[test]
    fn test_error_from_io() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "file not found");
        let kernel_err: KernelError = io_err.into();
        assert!(kernel_err.to_string().contains("file not found"));
    }

    #[test]
    fn test_all_error_constructors() {
        let _ = KernelError::capsule_not_found("c");
        let _ = KernelError::receipt_not_found("r");
        let _ = KernelError::corrupt_data("c", "t", "e", "a");
        let _ = KernelError::determinism_violation("r", "e", "a");
        let _ = KernelError::capsule_locked("c", "Locked");
        let _ = KernelError::repair_exhausted("c", 3, 0.5);
        let _ = KernelError::storage("disk full");
        let _ = KernelError::invalid_operation("bad op");
        let _ = KernelError::internal("unknown");
    }

    #[test]
    fn test_replay_mode_serialization() {
        let modes = vec![
            ReplayMode::Deterministic,
            ReplayMode::Live,
            ReplayMode::Hybrid,
            ReplayMode::AnomalyOnly,
        ];
        for mode in &modes {
            let json = serde_json::to_string(mode).unwrap();
            let back: ReplayMode = serde_json::from_str(&json).unwrap();
            assert_eq!(*mode, back);
        }
    }

    #[test]
    fn test_verdict_serialization() {
        for verdict in &[Verdict::Pass, Verdict::Warn, Verdict::Divergent] {
            let json = serde_json::to_string(verdict).unwrap();
            let back: Verdict = serde_json::from_str(&json).unwrap();
            assert_eq!(*verdict, back);
        }
    }
}
