//! TruthGate — verifies execution receipts against expected state.
//!
//! The verifier is the core of the Truth Kernel. It takes an execution
//! receipt and determines whether the execution PASSED, WARNed, or
//! DIVERGED from the expected truth.

use crate::kernel::contracts::{MAX_REPAIR_ATTEMPTS, Verdict};
use crate::kernel::execution::receipts::ExecutionReceipt;
use crate::kernel::truth::drift::{DriftResult, DriftType, compute_drift_result};

/// Result of a truth verification.
#[derive(Debug, Clone)]
pub struct VerificationResult {
    /// The verdict (Pass/Warn/Divergent).
    pub verdict: Verdict,
    /// Detailed drift information.
    pub drift: DriftResult,
    /// Receipt that was verified.
    pub receipt_id: String,
}

/// Verify an execution receipt against expected outputs.
///
/// # Arguments
///
/// * `receipt` - The execution receipt to verify.
/// * `expected_output_hash` - The expected output hash.
/// * `acceptable_threshold` - Drift threshold for Warn vs Pass.
/// * `divergent_threshold` - Drift threshold for Divergent vs Warn.
pub fn verify_receipt(
    receipt: &ExecutionReceipt,
    expected_output_hash: &str,
    acceptable_threshold: f64,
    divergent_threshold: f64,
) -> VerificationResult {
    let drift = compute_drift_result(
        expected_output_hash,
        &receipt.output_hash,
        acceptable_threshold,
        divergent_threshold,
    );

    let verdict = match drift.drift_type {
        DriftType::None | DriftType::Acceptable => Verdict::Pass,
        DriftType::Configuration => Verdict::Warn,
        DriftType::Structural | DriftType::Semantic | DriftType::HashMismatch => Verdict::Divergent,
    };

    VerificationResult {
        verdict,
        drift,
        receipt_id: receipt.id.clone(),
    }
}

/// Check if repair is allowed based on attempt count.
pub fn repair_allowed(attempts: u8) -> bool {
    attempts < MAX_REPAIR_ATTEMPTS
}

/// Determine if a capsule should be locked based on divergence trend.
pub fn should_lock(divergence_score: f64, previous_score: f64) -> bool {
    divergence_score >= previous_score
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::execution::receipts::{CapsuleSnapshot, PolicySnapshot};

    fn make_receipt(output_hash: &str) -> ExecutionReceipt {
        ExecutionReceipt::new(
            "rec-1",
            "cap-1",
            "in-hash",
            output_hash,
            42,
            PolicySnapshot::new("v1.0"),
            CapsuleSnapshot::new("cap-1", "graph-hash"),
        )
    }

    #[test]
    fn test_pass_on_match() {
        let receipt = make_receipt("abc123");
        let result = verify_receipt(&receipt, "abc123", 0.1, 0.5);
        assert_eq!(result.verdict, Verdict::Pass);
    }

    #[test]
    fn test_divergent_on_mismatch_with_high_threshold() {
        // Hash mismatch is binary (0 or 1.0), so even with high thresholds
        // the result is still Semantic/Divergent since 1.0 > 0.9.
        let receipt = make_receipt("different_hash");
        let result = verify_receipt(&receipt, "expected_hash", 0.5, 0.9);
        assert_eq!(result.verdict, Verdict::Divergent);
    }

    #[test]
    fn test_divergent_on_mismatch() {
        let receipt = make_receipt("def456");
        let result = verify_receipt(&receipt, "abc123", 0.1, 0.5);
        assert_eq!(result.verdict, Verdict::Divergent);
    }

    #[test]
    fn test_repair_allowed() {
        assert!(repair_allowed(0));
        assert!(repair_allowed(1));
        assert!(repair_allowed(2));
        assert!(!repair_allowed(3));
        assert!(!repair_allowed(4));
    }

    #[test]
    fn test_should_lock() {
        assert!(should_lock(0.5, 0.3)); // got worse
        assert!(should_lock(0.5, 0.5)); // didn't improve
        assert!(!should_lock(0.3, 0.5)); // improved
    }

    #[test]
    fn test_verification_result_contains_receipt_id() {
        let receipt = make_receipt("abc");
        let result = verify_receipt(&receipt, "abc", 0.1, 0.5);
        assert_eq!(result.receipt_id, "rec-1");
    }
}
