//! Drift detection — divergence measurement for truth verification.
//!
//! Drift measures the semantic distance between expected and actual
//! execution output. The score is a value in [0.0, 1.0]:
//!
//! - 0.0 = identical (no drift)
//! - 0.0–0.1 = acceptable tolerance
//! - 0.1–0.5 = warning (WARN)
//! - 0.5+ = divergent (DIVERGENT)
//!
//! Drift classification determines whether repair is triggered.

use serde::{Deserialize, Serialize};

/// Classification of detected drift.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum DriftType {
    /// No drift detected.
    None,
    /// Acceptable deviation within tolerance.
    Acceptable,
    /// Configuration-level drift (routing weights, thresholds).
    Configuration,
    /// Structural drift (graph topology changed).
    Structural,
    /// Semantic drift (output content differs).
    Semantic,
    /// Hash mismatch (cryptographic integrity violation).
    HashMismatch,
}

/// Result of a drift calculation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DriftResult {
    /// Calculated drift score [0.0, 1.0].
    pub score: f64,
    /// Classification of the drift.
    pub drift_type: DriftType,
    /// Human-readable explanation.
    pub explanation: String,
}

/// Calculate drift score between two hashes.
///
/// Simple comparison: hashes match → score 0.0, hashes differ → score 1.0.
/// More sophisticated semantic drift can override this for specific node types.
pub fn calculate_drift(expected_hash: &str, actual_hash: &str) -> f64 {
    if expected_hash == actual_hash {
        0.0
    } else {
        1.0
    }
}

/// Classify a drift score against thresholds.
pub fn classify_drift(
    score: f64,
    acceptable_threshold: f64,
    divergent_threshold: f64,
) -> (DriftType, &'static str) {
    if score == 0.0 {
        (DriftType::None, "no drift detected")
    } else if score <= acceptable_threshold {
        (DriftType::Acceptable, "minor deviation within tolerance")
    } else if score <= divergent_threshold {
        (
            DriftType::Configuration,
            "configuration-level drift detected",
        )
    } else {
        (
            DriftType::Semantic,
            "semantic drift detected — repair required",
        )
    }
}

/// Compute a combined drift result from expected and actual hashes.
pub fn compute_drift_result(
    expected_hash: &str,
    actual_hash: &str,
    acceptable_threshold: f64,
    divergent_threshold: f64,
) -> DriftResult {
    let score = calculate_drift(expected_hash, actual_hash);
    let (drift_type, explanation) =
        classify_drift(score, acceptable_threshold, divergent_threshold);
    DriftResult {
        score,
        drift_type,
        explanation: explanation.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_drift_on_match() {
        assert!((calculate_drift("abc", "abc") - 0.0).abs() < f64::EPSILON);
    }

    #[test]
    fn test_full_drift_on_mismatch() {
        assert!((calculate_drift("abc", "def") - 1.0).abs() < f64::EPSILON);
    }

    #[test]
    fn test_classify_none() {
        let (t, _) = classify_drift(0.0, 0.1, 0.5);
        assert_eq!(t, DriftType::None);
    }

    #[test]
    fn test_classify_acceptable() {
        let (t, _) = classify_drift(0.05, 0.1, 0.5);
        assert_eq!(t, DriftType::Acceptable);
    }

    #[test]
    fn test_classify_configuration() {
        let (t, _) = classify_drift(0.3, 0.1, 0.5);
        assert_eq!(t, DriftType::Configuration);
    }

    #[test]
    fn test_classify_semantic() {
        let (t, _) = classify_drift(0.7, 0.1, 0.5);
        assert_eq!(t, DriftType::Semantic);
    }

    #[test]
    fn test_compute_drift_result() {
        let r = compute_drift_result("abc", "def", 0.1, 0.5);
        assert!((r.score - 1.0).abs() < f64::EPSILON);
        assert_eq!(r.drift_type, DriftType::Semantic);
        assert!(!r.explanation.is_empty());
    }

    #[test]
    fn test_drift_type_serialization() {
        let types = vec![
            DriftType::None,
            DriftType::Acceptable,
            DriftType::Configuration,
            DriftType::Structural,
            DriftType::Semantic,
            DriftType::HashMismatch,
        ];
        for dt in &types {
            let json = serde_json::to_string(dt).unwrap();
            let back: DriftType = serde_json::from_str(&json).unwrap();
            assert_eq!(*dt, back);
        }
    }
}
