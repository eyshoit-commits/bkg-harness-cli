//! **Speculum** — the mirror gate (BKG Reveland).
//!
//! In the Reveland, truth verification is **Speculum** (Latin for "mirror"):
//! the gate where execution reflects against truth and reveals divergence.
//!
//! # Truth Kernel — verification, drift detection, and repair.
//!
//! The truth kernel verifies execution receipts against expected hashes
//! and runs the repair loop when divergence is detected.
//!
//! # Repair Loop
//!
//! When a receipt is divergent:
//! 1. Run repair cycle (max 3 attempts)
//! 2. Re-execute
//! 3. Verify again
//! 4. If still divergent → lock capsule for human review
//!
//! Repairs are convergent — each attempt should reduce divergence.

pub mod drift;
pub mod repair;
pub mod verifier;

// Re-export key types.
pub use drift::{DriftResult, DriftType, calculate_drift, classify_drift, compute_drift_result};
pub use repair::{RepairContext, RepairResult, run_repair_cycle};
pub use verifier::{VerificationResult, repair_allowed, should_lock, verify_receipt};
