//! Repair Engine — self-healing with bounded retry and monotonic convergence.
//!
//! # Hard Rules
//!
//! - MAX_REPAIR_ATTEMPTS = 3: after 3 attempts, capsule is LOCKED
//! - Monotonic convergence: if divergence_score doesn't decrease → LOCK
//! - Repair only runs in VERIFY → REPAIR → VERIFY flow
//! - On lock: only replay is allowed (no execution, no repair)

use crate::kernel::contracts::{KernelError, MAX_REPAIR_ATTEMPTS};

/// Tracks repair state for one capsule.
#[derive(Debug, Clone)]
pub struct RepairContext {
    /// Number of repair attempts performed.
    pub attempts: u8,
    /// Last error message (if any).
    pub last_error: String,
    /// Current divergence score (must monotonically decrease).
    pub divergence_score: f64,
}

impl RepairContext {
    /// Create a new repair context.
    pub fn new(initial_score: f64) -> Self {
        Self {
            attempts: 0,
            last_error: String::new(),
            divergence_score: initial_score,
        }
    }

    /// Attempt a repair cycle.
    ///
    /// Returns Ok(()) if repair is allowed, Err if the capsule should be locked.
    pub fn attempt(&mut self, new_score: f64, error: impl Into<String>) -> Result<(), KernelError> {
        self.attempts += 1;
        self.last_error = error.into();

        // Check monotonic convergence: score must decrease
        if new_score >= self.divergence_score {
            return Err(KernelError::repair_exhausted(
                "unknown",
                self.attempts,
                new_score,
            ));
        }

        self.divergence_score = new_score;

        // Check max attempts
        if self.attempts >= MAX_REPAIR_ATTEMPTS {
            return Err(KernelError::repair_exhausted(
                "unknown",
                self.attempts,
                new_score,
            ));
        }

        Ok(())
    }

    /// Reset the repair context (e.g., after successful verification).
    pub fn reset(&mut self) {
        self.attempts = 0;
        self.last_error = String::new();
        self.divergence_score = 0.0;
    }

    /// Whether repair is allowed (attempts < MAX_REPAIR_ATTEMPTS).
    pub fn is_allowed(&self) -> bool {
        self.attempts < MAX_REPAIR_ATTEMPTS
    }
}

/// Summary of a repair cycle result.
#[derive(Debug, Clone)]
pub struct RepairResult {
    /// Whether repair was successful.
    pub success: bool,
    /// Number of attempts made.
    pub attempts: u8,
    /// Final divergence score.
    pub final_score: f64,
    /// Whether the capsule is now locked.
    pub locked: bool,
}

/// Run a repair cycle with monotonic convergence checking.
///
/// Returns a RepairResult indicating whether repair succeeded,
/// how many attempts were used, and whether the capsule is locked.
pub fn run_repair_cycle(
    context: &mut RepairContext,
    attempt_fn: impl FnOnce(&mut RepairContext) -> Result<f64, String>,
) -> RepairResult {
    if !context.is_allowed() {
        return RepairResult {
            success: false,
            attempts: context.attempts,
            final_score: context.divergence_score,
            locked: true,
        };
    }

    match attempt_fn(context) {
        Ok(new_score) => {
            // Check monotonic convergence
            if new_score >= context.divergence_score {
                return RepairResult {
                    success: false,
                    attempts: context.attempts,
                    final_score: new_score,
                    locked: true,
                };
            }

            context.divergence_score = new_score;
            context.attempts += 1;

            RepairResult {
                success: context.is_allowed(),
                attempts: context.attempts,
                final_score: new_score,
                locked: !context.is_allowed(),
            }
        }
        Err(err) => {
            context.last_error = err;
            context.attempts += 1;

            RepairResult {
                success: false,
                attempts: context.attempts,
                final_score: context.divergence_score,
                locked: !context.is_allowed(),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_repair_context_initial() {
        let ctx = RepairContext::new(0.8);
        assert_eq!(ctx.attempts, 0);
        assert!((ctx.divergence_score - 0.8).abs() < f64::EPSILON);
        assert!(ctx.is_allowed());
    }

    #[test]
    fn test_successful_repair() {
        let mut ctx = RepairContext::new(0.8);
        let result = ctx.attempt(0.3, "repaired node hash mismatch");
        assert!(result.is_ok());
        assert_eq!(ctx.attempts, 1);
    }

    #[test]
    fn test_non_convergent_repair_locks() {
        let mut ctx = RepairContext::new(0.5);
        let result = ctx.attempt(0.7, "divergence increased");
        assert!(result.is_err()); // score got worse → lock
    }

    #[test]
    fn test_equal_score_locks() {
        let mut ctx = RepairContext::new(0.5);
        let result = ctx.attempt(0.5, "no improvement");
        assert!(result.is_err()); // score didn't improve → lock
    }

    #[test]
    fn test_max_attempts_locks() {
        let mut ctx = RepairContext::new(0.9);
        // First two succeed
        assert!(ctx.attempt(0.6, "ok").is_ok());
        assert!(ctx.attempt(0.3, "ok").is_ok());
        // Third attempt should exhaust
        let result = ctx.attempt(0.1, "ok");
        assert!(result.is_err());
        assert!(!ctx.is_allowed());
    }

    #[test]
    fn test_run_repair_cycle_success() {
        let mut ctx = RepairContext::new(0.8);
        let result = run_repair_cycle(&mut ctx, |c| {
            Ok(c.divergence_score * 0.5) // improve
        });
        assert!(result.success);
        assert_eq!(result.attempts, 1);
        assert!(!result.locked);
    }

    #[test]
    fn test_run_repair_cycle_failure_locks() {
        let mut ctx = RepairContext::new(0.5);
        let result = run_repair_cycle(&mut ctx, |_| Err("repair failed".to_string()));
        assert!(!result.success);
        assert!(!result.locked); // first failure doesn't lock
    }

    #[test]
    fn test_reset_context() {
        let mut ctx = RepairContext::new(0.8);
        let _ = ctx.attempt(0.3, "ok");
        ctx.reset();
        assert_eq!(ctx.attempts, 0);
        assert!((ctx.divergence_score - 0.0).abs() < f64::EPSILON);
    }
}
