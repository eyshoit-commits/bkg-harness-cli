//! Ucc4Kernel trait — the public API for the self-evolving execution kernel.
//!
//! # Hot Path (Ucc4Kernel::run())
//!
//! 1. load capsule
//! 2. build DAG
//! 3. execute DAG (parallel safe, deterministic seed)
//! 4. generate ExecutionReceipt
//! 5. persist receipt (immutable)
//! 6. Truth verify
//! 7. IF divergent → repair loop (max 3, convergent)
//! 8. persist capsule update
//! 9. finalize TruthReport
//! 10. queue Evolution event (async)
//! 11. return output

use crate::kernel::contracts::{KernelResult, ReplayMode};
use crate::kernel::execution::receipts::{ExecutionReceipt, KernelOutput};
use crate::kernel::time::replay::ReplayResult;

/// The UCC-4 Self-Evolving Kernel trait.
///
/// Implementors provide the execution, truth, memory, time, and evolution
/// kernels that together form a deterministic, self-healing execution system.
#[async_trait::async_trait]
pub trait Ucc4Kernel: Send + Sync {
    /// Execute a capsule with the given input.
    ///
    /// This is the main hot path (11 steps):
    /// 1. Locate and load capsule
    /// 2. Build execution DAG from capsule graph
    /// 3. Execute DAG (topological order, parallel safe)
    /// 4. Package result into ExecutionReceipt
    /// 5. Persist receipt (IMMUTABLE — never overwritten)
    /// 6. Verify receipt against expected truth
    /// 7. If DIVERGENT: repair loop (max 3, convergent)
    /// 8. Persist capsule state update
    /// 9. Finalize TruthReport
    /// 10. Queue evolution event (async)
    /// 11. Return output
    async fn run(&mut self, capsule_id: &str, input: &str) -> KernelResult<KernelOutput>;

    /// Replay a previous execution from its receipt.
    ///
    /// # Determinism Guarantee
    ///
    /// With ReplayMode::Deterministic:
    /// ```text
    /// f(input, receipt.execution_seed, receipt.policy_snapshot, receipt.capsule_snapshot)
    /// → identical DAG + bit-identical hashes
    /// ```
    async fn replay(&self, receipt_id: &str, mode: ReplayMode) -> KernelResult<ReplayResult>;

    /// Rehydrate a capsule from persistent storage.
    ///
    /// Reconstructs capsule state from manifest, receipts, and truth files.
    /// Used for error recovery after crashes or corruption.
    async fn rehydrate(&mut self, capsule_id: &str) -> KernelResult<String>;

    /// Get the current status of a capsule.
    async fn capsule_status(&self, capsule_id: &str) -> KernelResult<String>;

    /// List all execution receipts for a capsule.
    async fn list_receipts(&self, capsule_id: &str) -> KernelResult<Vec<String>>;

    /// Load a specific execution receipt.
    async fn load_receipt(&self, receipt_id: &str) -> KernelResult<ExecutionReceipt>;
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::contracts::Verdict;
    use crate::kernel::execution::receipts::{CapsuleSnapshot, PolicySnapshot};
    use crate::kernel::time::replay::ReplayContext;

    /// Minimal test implementation of Ucc4Kernel.
    struct TestKernel;

    #[async_trait::async_trait]
    impl Ucc4Kernel for TestKernel {
        async fn run(&mut self, _capsule_id: &str, _input: &str) -> KernelResult<KernelOutput> {
            let receipt = ExecutionReceipt::new(
                "test-rec",
                _capsule_id,
                "in-hash",
                "out-hash",
                42,
                PolicySnapshot::new("v1.0"),
                CapsuleSnapshot::new(_capsule_id, "graph-hash"),
            );
            Ok(KernelOutput {
                receipt,
                verdict: Verdict::Pass,
                capsule_status: "Active".into(),
                output_hash: "out-hash".into(),
            })
        }

        async fn replay(&self, _receipt_id: &str, _mode: ReplayMode) -> KernelResult<ReplayResult> {
            Err(crate::kernel::contracts::KernelError::internal(
                "not implemented",
            ))
        }

        async fn rehydrate(&mut self, _capsule_id: &str) -> KernelResult<String> {
            Ok("Active".to_string())
        }

        async fn capsule_status(&self, _capsule_id: &str) -> KernelResult<String> {
            Ok("Active".to_string())
        }

        async fn list_receipts(&self, _capsule_id: &str) -> KernelResult<Vec<String>> {
            Ok(vec![])
        }

        async fn load_receipt(&self, _receipt_id: &str) -> KernelResult<ExecutionReceipt> {
            Err(crate::kernel::contracts::KernelError::internal(
                "not implemented",
            ))
        }
    }

    #[tokio::test]
    async fn test_trait_run() {
        let mut kernel = TestKernel;
        let result = kernel.run("cap-1", "test input").await.unwrap();
        assert_eq!(result.capsule_status, "Active");
        assert_eq!(result.verdict, Verdict::Pass);
    }

    #[tokio::test]
    async fn test_trait_rehydrate() {
        let mut kernel = TestKernel;
        let status = kernel.rehydrate("cap-1").await.unwrap();
        assert_eq!(status, "Active");
    }

    #[tokio::test]
    async fn test_trait_capsule_status() {
        let kernel = TestKernel;
        let status = kernel.capsule_status("cap-1").await.unwrap();
        assert_eq!(status, "Active");
    }

    #[tokio::test]
    async fn test_trait_list_receipts() {
        let kernel = TestKernel;
        let receipts = kernel.list_receipts("cap-1").await.unwrap();
        assert!(receipts.is_empty());
    }
}
