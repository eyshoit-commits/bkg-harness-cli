//! Capsule Index — registry of known capsules and their metadata.

use std::collections::HashMap;

use crate::kernel::contracts::{KernelError, KernelResult};

/// Metadata for a known capsule.
#[derive(Debug, Clone)]
pub struct CapsuleEntry {
    /// Capsule identifier.
    pub capsule_id: String,
    /// Current status string.
    pub status: String,
    /// Path to the capsule directory.
    pub path: String,
    /// Number of execution receipts.
    pub receipt_count: u64,
}

/// Registry/index of all known capsules.
#[derive(Debug, Clone)]
pub struct CapsuleIndex {
    capsules: HashMap<String, CapsuleEntry>,
}

impl CapsuleIndex {
    /// Create an empty capsule index.
    pub fn new() -> Self {
        Self {
            capsules: HashMap::new(),
        }
    }

    /// Register or update a capsule in the index.
    pub fn register(&mut self, entry: CapsuleEntry) {
        self.capsules.insert(entry.capsule_id.clone(), entry);
    }

    /// Look up a capsule by ID.
    pub fn lookup(&self, capsule_id: &str) -> KernelResult<&CapsuleEntry> {
        self.capsules
            .get(capsule_id)
            .ok_or_else(|| KernelError::capsule_not_found(capsule_id))
    }

    /// List all registered capsule IDs.
    pub fn list(&self) -> Vec<&CapsuleEntry> {
        self.capsules.values().collect()
    }

    /// Number of registered capsules.
    pub fn len(&self) -> usize {
        self.capsules.len()
    }

    /// Whether the index is empty.
    pub fn is_empty(&self) -> bool {
        self.capsules.is_empty()
    }

    /// Remove a capsule from the index.
    pub fn remove(&mut self, capsule_id: &str) {
        self.capsules.remove(capsule_id);
    }

    /// Update the status of a capsule.
    pub fn update_status(
        &mut self,
        capsule_id: &str,
        status: impl Into<String>,
    ) -> KernelResult<()> {
        if let Some(entry) = self.capsules.get_mut(capsule_id) {
            entry.status = status.into();
            Ok(())
        } else {
            Err(KernelError::capsule_not_found(capsule_id))
        }
    }
}

impl Default for CapsuleIndex {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_entry(id: &str) -> CapsuleEntry {
        CapsuleEntry {
            capsule_id: id.to_string(),
            status: "Active".to_string(),
            path: format!("/capsules/{id}"),
            receipt_count: 0,
        }
    }

    #[test]
    fn test_empty_index() {
        let idx = CapsuleIndex::new();
        assert!(idx.is_empty());
        assert_eq!(idx.len(), 0);
    }

    #[test]
    fn test_register_and_lookup() {
        let mut idx = CapsuleIndex::new();
        idx.register(make_entry("cap-1"));
        let entry = idx.lookup("cap-1").unwrap();
        assert_eq!(entry.capsule_id, "cap-1");
        assert_eq!(entry.status, "Active");
    }

    #[test]
    fn test_lookup_nonexistent() {
        let idx = CapsuleIndex::new();
        let result = idx.lookup("nonexistent");
        assert!(result.is_err());
    }

    #[test]
    fn test_list() {
        let mut idx = CapsuleIndex::new();
        idx.register(make_entry("cap-1"));
        idx.register(make_entry("cap-2"));
        assert_eq!(idx.list().len(), 2);
    }

    #[test]
    fn test_update_status() {
        let mut idx = CapsuleIndex::new();
        idx.register(make_entry("cap-1"));
        idx.update_status("cap-1", "Locked").unwrap();
        let entry = idx.lookup("cap-1").unwrap();
        assert_eq!(entry.status, "Locked");
    }

    #[test]
    fn test_remove() {
        let mut idx = CapsuleIndex::new();
        idx.register(make_entry("cap-1"));
        idx.remove("cap-1");
        assert!(idx.is_empty());
    }
}
