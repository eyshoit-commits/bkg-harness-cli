//! **Memoria** — the vault gate (BKG Reveland).
//!
//! In the Reveland, memory is **Memoria** (Latin for "memory"):
//! the gate where capsules are kept, indexed, and rehydrated.
//!
//! The memory kernel handles:
//! - Capsule index (in-memory registry of active capsules)
//! - Filesystem storage (persistent read/write)
//! - Capsule rehydration from persistent state
//!
//! # Storage Abstraction
//!
//! The [`KernelStorage`] trait abstracts persistence:
//! - `InMemoryStorage` for testing
//! - `FilesystemStorage` for production

pub mod filesystem;
pub mod index;

// Re-export key types.
pub use filesystem::{FilesystemStorage, InMemoryStorage, KernelStorage};
pub use index::{CapsuleEntry, CapsuleIndex};
