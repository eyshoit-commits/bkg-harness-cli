//! Filesystem storage for immutable receipts and truth reports.
//!
//! # Storage Contract
//!
//! ```text
//! ~/.bkg/capsules/<id>/
//! ├── capsule.json
//! ├── receipts/<uuid>.json      (IMMUTABLE — never overwritten)
//! ├── truth/<uuid>.json         (IMMUTABLE — never overwritten)
//! ├── timeline.jsonl            (APPEND-ONLY causal log)
//! └── ... (other capsule files)
//! ```

use std::collections::HashMap;
use std::path::PathBuf;

use crate::kernel::contracts::{KernelError, KernelResult};
use crate::kernel::execution::receipts::ExecutionReceipt;

/// Trait for storage backends.
pub trait KernelStorage: Send + Sync {
    /// Store an execution receipt (immutable).
    fn store_receipt(&mut self, receipt: &ExecutionReceipt) -> KernelResult<()>;

    /// Load an execution receipt by ID.
    fn load_receipt(&self, receipt_id: &str) -> KernelResult<ExecutionReceipt>;

    /// List all receipt IDs for a capsule.
    fn list_receipts(&self, capsule_id: &str) -> KernelResult<Vec<String>>;
}

/// In-memory storage implementation (for testing).
#[derive(Debug, Clone)]
pub struct InMemoryStorage {
    receipts: HashMap<String, ExecutionReceipt>,
    capsule_receipts: HashMap<String, Vec<String>>,
}

impl InMemoryStorage {
    /// Create a new in-memory storage.
    pub fn new() -> Self {
        Self {
            receipts: HashMap::new(),
            capsule_receipts: HashMap::new(),
        }
    }
}

impl Default for InMemoryStorage {
    fn default() -> Self {
        Self::new()
    }
}

impl KernelStorage for InMemoryStorage {
    fn store_receipt(&mut self, receipt: &ExecutionReceipt) -> KernelResult<()> {
        let id = receipt.id.clone();
        let capsule_id = receipt.capsule_id.clone();

        // Enforce immutability: refuse to overwrite
        if self.receipts.contains_key(&id) {
            return Err(KernelError::invalid_operation(format!(
                "receipt {id} already exists — immutable"
            )));
        }

        self.receipts.insert(id.clone(), receipt.clone());
        self.capsule_receipts
            .entry(capsule_id)
            .or_default()
            .push(id);
        Ok(())
    }

    fn load_receipt(&self, receipt_id: &str) -> KernelResult<ExecutionReceipt> {
        self.receipts
            .get(receipt_id)
            .cloned()
            .ok_or_else(|| KernelError::receipt_not_found(receipt_id))
    }

    fn list_receipts(&self, capsule_id: &str) -> KernelResult<Vec<String>> {
        Ok(self
            .capsule_receipts
            .get(capsule_id)
            .cloned()
            .unwrap_or_default())
    }
}

/// Filesystem-based storage for receipts and truth reports.
#[derive(Debug, Clone)]
pub struct FilesystemStorage {
    base_path: PathBuf,
}

impl FilesystemStorage {
    /// Create a new filesystem storage at the given base path.
    pub fn new(base_path: impl Into<PathBuf>) -> Self {
        Self {
            base_path: base_path.into(),
        }
    }

    /// Get the receipts directory for a capsule.
    fn receipts_dir(&self, capsule_id: &str) -> PathBuf {
        self.base_path
            .join("capsules")
            .join(capsule_id)
            .join("receipts")
    }

    /// Get the truth directory for a capsule.
    fn truth_dir(&self, capsule_id: &str) -> PathBuf {
        self.base_path
            .join("capsules")
            .join(capsule_id)
            .join("truth")
    }

    /// Get the receipt file path.
    fn receipt_path(&self, capsule_id: &str, receipt_id: &str) -> PathBuf {
        self.receipts_dir(capsule_id)
            .join(format!("{receipt_id}.json"))
    }
}

impl KernelStorage for FilesystemStorage {
    fn store_receipt(&mut self, receipt: &ExecutionReceipt) -> KernelResult<()> {
        let dir = self.receipts_dir(&receipt.capsule_id);
        std::fs::create_dir_all(&dir)?;

        let path = dir.join(format!("{}.json", receipt.id));

        // Enforce immutability
        if path.exists() {
            return Err(KernelError::invalid_operation(format!(
                "receipt {} already exists at {:?} — immutable",
                receipt.id, path
            )));
        }

        let json = serde_json::to_string_pretty(receipt)?;
        std::fs::write(&path, json)?;
        Ok(())
    }

    fn load_receipt(&self, receipt_id: &str) -> KernelResult<ExecutionReceipt> {
        // Search across all capsule directories
        let capsules_dir = self.base_path.join("capsules");
        if !capsules_dir.exists() {
            return Err(KernelError::receipt_not_found(receipt_id));
        }

        for entry in std::fs::read_dir(&capsules_dir)? {
            let entry = entry?;
            let receipt_path = entry
                .path()
                .join("receipts")
                .join(format!("{receipt_id}.json"));
            if receipt_path.exists() {
                let json = std::fs::read_to_string(&receipt_path)?;
                return Ok(serde_json::from_str(&json)?);
            }
        }

        Err(KernelError::receipt_not_found(receipt_id))
    }

    fn list_receipts(&self, capsule_id: &str) -> KernelResult<Vec<String>> {
        let dir = self.receipts_dir(capsule_id);
        if !dir.exists() {
            return Ok(Vec::new());
        }

        let mut receipts = Vec::new();
        for entry in std::fs::read_dir(&dir)? {
            let entry = entry?;
            if let Some(name) = entry.file_name().to_str() {
                if name.ends_with(".json") {
                    receipts.push(name.trim_end_matches(".json").to_string());
                }
            }
        }
        receipts.sort();
        Ok(receipts)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::execution::receipts::{CapsuleSnapshot, PolicySnapshot};

    fn make_receipt(id: &str, capsule_id: &str) -> ExecutionReceipt {
        ExecutionReceipt::new(
            id,
            capsule_id,
            "in-hash",
            "out-hash",
            42,
            PolicySnapshot::new("v1.0"),
            CapsuleSnapshot::new(capsule_id, "graph-hash"),
        )
    }

    #[test]
    fn test_in_memory_store_and_load() {
        let mut storage = InMemoryStorage::new();
        let receipt = make_receipt("rec-1", "cap-1");
        storage.store_receipt(&receipt).unwrap();
        let loaded = storage.load_receipt("rec-1").unwrap();
        assert_eq!(loaded.id, "rec-1");
    }

    #[test]
    fn test_in_memory_immutability() {
        let mut storage = InMemoryStorage::new();
        let receipt = make_receipt("rec-1", "cap-1");
        storage.store_receipt(&receipt).unwrap();
        let result = storage.store_receipt(&receipt);
        assert!(result.is_err());
    }

    #[test]
    fn test_in_memory_list_receipts() {
        let mut storage = InMemoryStorage::new();
        storage.store_receipt(&make_receipt("r1", "cap-1")).unwrap();
        storage.store_receipt(&make_receipt("r2", "cap-1")).unwrap();
        let receipts = storage.list_receipts("cap-1").unwrap();
        assert_eq!(receipts.len(), 2);
    }

    #[test]
    fn test_in_memory_not_found() {
        let storage = InMemoryStorage::new();
        let result = storage.load_receipt("nonexistent");
        assert!(result.is_err());
    }

    #[test]
    fn test_filesystem_store_and_load() {
        let tmp = std::env::temp_dir().join(format!("bkg_test_store_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&tmp);

        let mut storage = FilesystemStorage::new(&tmp);
        let receipt = make_receipt("rec-fs-1", "cap-fs-1");
        storage.store_receipt(&receipt).unwrap();
        let loaded = storage.load_receipt("rec-fs-1").unwrap();
        assert_eq!(loaded.id, "rec-fs-1");

        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn test_filesystem_immutability() {
        let tmp = std::env::temp_dir().join(format!("bkg_test_immut_{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&tmp);

        let mut storage = FilesystemStorage::new(&tmp);
        let receipt = make_receipt("rec-fs-2", "cap-fs-2");
        storage.store_receipt(&receipt).unwrap();
        let result = storage.store_receipt(&receipt);
        assert!(result.is_err());

        let _ = std::fs::remove_dir_all(&tmp);
    }
}
