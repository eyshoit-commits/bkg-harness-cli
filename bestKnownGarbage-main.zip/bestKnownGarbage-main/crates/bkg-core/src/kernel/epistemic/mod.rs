//! **Epistemic Kernel** — the truth-seeking core (BKG Reveland).
//!
//! In the Reveland, truth is not assumed; it is verified.
//! This module provides the primitives for tracking both **Causal Integrity**
//! (the unbroken chain of events) and **Epistemic Integrity** (the truthfulness of the origin).

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

use crate::kernel::contracts::{ExecutionSeed, Verdict};
use crate::kernel::execution::receipts::{CapsuleSnapshot, PolicySnapshot};
use crate::types::Hash;

// ──────────────────────────────────────────────
// TruthState
// ──────────────────────────────────────────────

/// The epistemic status of an event or state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TruthState {
    /// The event is causally valid and its origin is verified as true.
    CausallyValid,
    /// The event is causally valid, but its origin is unverified or potentially false.
    EpistemicallyValid,
    /// The event represents a divergence from a known truth.
    Divergent,
    /// The event is part of a tainted lineage.
    Tainted,
    /// The event has been nullified by a higher-order truth correction.
    Nullified,
}

// ──────────────────────────────────────────────
// GenesisAnchor
// ──────────────────────────────────────────────

/// The anchor for the system's origin.
///
/// Every timeline must be traceable back to a GenesisAnchor.
/// If the anchor is found to be epistemically invalid, the entire
/// lineage may be marked as `Tainted` or `Nullified`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GenesisAnchor {
    /// Hash of the original genesis event.
    pub genesis_hash: Hash,
    /// The initial confidence in the truth of the genesis event.
    pub epistemic_confidence: f32,
    /// Sources that verified the genesis event.
    pub verification_sources: Vec<Hash>,
    /// Hashes of events that caused a divergence from the original timeline.
    pub divergence_events: Vec<Hash>,
    /// The hash of the anchor that superseded this one (if any).
    pub superseded_by: Option<Hash>,
}

// ──────────────────────────────────────────────
// CausalReceipt
// ──────────────────────────────────────────────

/// A comprehensive, immutable record of a causally-bound execution.
///
/// Unlike a standard `ExecutionReceipt`, a `CausalReceipt` binds
/// the execution to the trust state, the SWD state, and the timeline.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CausalReceipt {
    /// Unique identifier for this receipt.
    pub receipt_id: String,
    /// The capsule that was executed.
    pub capsule_id: String,

    /// The trust state at the time of execution.
    pub trust_snapshot: Hash,
    /// The policy environment frozen at execution time.
    pub policy_snapshot: PolicySnapshot,

    /// The SWD state before the operation.
    pub swd_snapshot_before: Hash,
    /// The SWD state after the operation.
    pub swd_snapshot_after: Hash,

    /// Hash of the tool/LLM execution itself.
    pub tool_execution_hash: Hash,
    /// The parent event in the timeline.
    pub timeline_parent: Hash,

    /// The model used for this execution.
    pub model_used: String,
    /// The routing decision made by the kernel.
    pub routing_decision: Hash,

    /// The final truth verdict for this execution.
    pub verification_result: Verdict,

    /// Wall-clock timestamp.
    pub created_at: DateTime<Utc>,
}

impl CausalReceipt {
    /// Create a new causal receipt.
    pub fn new(
        receipt_id: impl Into<String>,
        capsule_id: impl Into<String>,
        trust_snapshot: Hash,
        policy_snapshot: PolicySnapshot,
        swd_snapshot_before: Hash,
        swd_snapshot_after: Hash,
        tool_execution_hash: Hash,
        timeline_parent: Hash,
        model_used: impl Into<String>,
        routing_decision: Hash,
        verification_result: Verdict,
    ) -> Self {
        Self {
            receipt_id: receipt_id.into(),
            capsule_id: capsule_id.into(),
            trust_snapshot,
            policy_snapshot,
            swd_snapshot_before,
            swd_snapshot_after,
            tool_execution_hash,
            timeline_parent,
            model_used: model_used.into(),
            routing_decision,
            verification_result,
            created_at: Utc::now(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::contracts::Verdict;

    #[test]
    fn test_truth_state_serialization() {
        let state = TruthState::CausallyValid;
        let json = serde_json::to_string(&state).unwrap();
        let back: TruthState = serde_json::from_str(&json).unwrap();
        assert_eq!(state, back);
    }

    #[test]
    fn test_causal_receipt_creation() {
        let policy = PolicySnapshot::new("v1.0");
        let receipt = CausalReceipt::new(
            "rec-1",
            "cap-1",
            "trust-hash".into(),
            policy,
            "swd-before".into(),
            "swd-after".into(),
            "tool-hash".into(),
            "parent-hash".into(),
            "gpt-4",
            "route-hash".into(),
            Verdict::Pass,
        );
        assert_eq!(receipt.receipt_id, "rec-1");
        assert_eq!(receipt.model_used, "gpt-4");
        assert_eq!(receipt.verification_result, Verdict::Pass);
    }
}
