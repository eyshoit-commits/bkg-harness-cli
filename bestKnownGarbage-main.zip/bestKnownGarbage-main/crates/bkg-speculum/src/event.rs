//! ASTP Event Types — the atomic unit of the speculum cryptotree.
//!
//! Defines `Event`, `EventNode`, and `IntegrityState` for the
//! Anti-Speculum-Tamper-Protokoll (ASTP v1).
//!
//! **Design invariant:** Events are immutable after insertion. No silent rewrites.
//! See docs/superpowers/plans/2026-05-24-anti-speculum-tamper-protocol.md

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::HashMap;

// ──────────────────────────────────────────────
// Type Aliases
// ──────────────────────────────────────────────

/// Canonical hash type for the speculum tree (SHA-256 hex).
pub type SpeculumHash = String;

// ──────────────────────────────────────────────
// Event — the atomic unit in the tree
// ──────────────────────────────────────────────

/// A single event in the speculum cryptotree.
///
/// Every event carries:
/// - `id` — human-readable identifier
/// - `parent_hash` — cryptographic link to its causal predecessor (`None` means genesis)
/// - `payload` — the event's content/data
/// - `timestamp` — monotonic timestamp (epoch seconds)
/// - `signature` — external signature for provenance verification
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Event {
    pub id: String,
    pub parent_hash: Option<SpeculumHash>,
    pub payload: String,
    pub timestamp: u64,
    pub signature: SpeculumHash,
}

impl Event {
    /// Create a new genesis event (no parent).
    pub fn genesis(id: impl Into<String>, payload: impl Into<String>, signature: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            parent_hash: None,
            payload: payload.into(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            signature: signature.into(),
        }
    }

    /// Create a new child event with a parent hash.
    pub fn child(
        id: impl Into<String>,
        parent_hash: SpeculumHash,
        payload: impl Into<String>,
        signature: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            parent_hash: Some(parent_hash),
            payload: payload.into(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs(),
            signature: signature.into(),
        }
    }

    /// Create an event at a specific timestamp (for deterministic testing/replay).
    pub fn at_timestamp(
        id: impl Into<String>,
        parent_hash: Option<SpeculumHash>,
        payload: impl Into<String>,
        timestamp: u64,
        signature: impl Into<String>,
    ) -> Self {
        Self {
            id: id.into(),
            parent_hash,
            payload: payload.into(),
            timestamp,
            signature: signature.into(),
        }
    }
}

// ──────────────────────────────────────────────
// Integrity State
// ──────────────────────────────────────────────

/// Integrity state of a speculum tree node.
///
/// Transitions:
/// - `Clean` → `Suspect` (on integrity check warning)
/// - `Clean` → `TamperDetected` (on hash mismatch)
/// - `Clean` → `ForkDetected` (on conflicting genesis)
/// - `Suspect` → `TamperDetected` (on confirmed corruption)
/// - `*` → `CorruptedGenesis` (genesis itself is compromised)
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum IntegrityState {
    /// Node is cryptographically sound and part of the active timeline
    Clean,
    /// Node integrity is questionable (requires deeper investigation)
    Suspect,
    /// The genesis event itself has been invalidated → entire tree is suspect
    CorruptedGenesis,
    /// A fork was detected — multiple valid roots exist
    ForkDetected,
    /// Tamper was confirmed — hash mismatch or lineage break
    TamperDetected,
}

impl IntegrityState {
    /// Whether this state means the node is still usable.
    pub fn is_active(&self) -> bool {
        matches!(self, IntegrityState::Clean)
    }

    /// Whether this state means the node is permanently invalid.
    pub fn is_corrupt(&self) -> bool {
        matches!(self, IntegrityState::TamperDetected | IntegrityState::CorruptedGenesis)
    }
}

// ──────────────────────────────────────────────
// EventNode — event + computed state in the tree
// ──────────────────────────────────────────────

/// A node in the speculum tree: the `Event` plus its computed cryptographic state.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EventNode {
    /// The original event data
    pub event: Event,
    /// Pre-computed SHA-256 hash of the event (immutable after insertion)
    pub computed_hash: SpeculumHash,
    /// Child hashes for subtree traversal
    pub children: Vec<SpeculumHash>,
    /// Depth from genesis (genesis = 0)
    pub depth: u64,
    /// Current integrity state
    pub integrity_state: IntegrityState,
}

impl EventNode {
    /// Create a new clean event node with its computed hash.
    pub fn new(event: Event, depth: u64) -> Self {
        let computed_hash = compute_hash(&event);
        Self {
            event,
            computed_hash,
            children: Vec::new(),
            depth,
            integrity_state: IntegrityState::Clean,
        }
    }
}

// ──────────────────────────────────────────────
// Hash Computation (non-negotiable)
// ──────────────────────────────────────────────

/// Compute the cryptographic hash of an event using SHA-256.
///
/// Hash includes (in order):
/// 1. `event.id` (bytes)
/// 2. `event.payload` (bytes)
/// 3. `event.timestamp` (little-endian bytes)
/// 4. `event.parent_hash` (bytes, if present)
/// 5. `event.signature` (bytes)
///
/// **This algorithm is frozen.** Changing it breaks all existing lineage chains.
#[must_use]
pub fn compute_hash(event: &Event) -> SpeculumHash {
    let mut hasher = Sha256::new();

    hasher.update(event.id.as_bytes());
    hasher.update(event.payload.as_bytes());
    hasher.update(event.timestamp.to_le_bytes());

    if let Some(parent) = &event.parent_hash {
        hasher.update(parent.as_bytes());
    }

    hasher.update(event.signature.as_bytes());

    format!("{:x}", hasher.finalize())
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn same_event_produces_same_hash() {
        let event = Event::at_timestamp("test", None, "hello", 1000, "sig");
        let h1 = compute_hash(&event);
        let h2 = compute_hash(&event);
        assert_eq!(h1, h2, "identical events must produce identical hashes");
    }

    #[test]
    fn different_payload_produces_different_hash() {
        let e1 = Event::at_timestamp("test", None, "hello", 1000, "sig");
        let e2 = Event::at_timestamp("test", None, "world", 1000, "sig");
        assert_ne!(
            compute_hash(&e1),
            compute_hash(&e2),
            "different payloads must produce different hashes"
        );
    }

    #[test]
    fn different_parent_hash_produces_different_hash() {
        let parent_a = "hash_a".to_string();
        let parent_b = "hash_b".to_string();
        let e1 = Event::at_timestamp("test", Some(parent_a), "payload", 1000, "sig");
        let e2 = Event::at_timestamp("test", Some(parent_b), "payload", 1000, "sig");
        assert_ne!(
            compute_hash(&e1),
            compute_hash(&e2),
            "different parent hashes must produce different event hashes"
        );
    }

    #[test]
    fn genesis_event_has_no_parent() {
        let event = Event::genesis("genesis-1", "Initial event", "root_sig");
        assert!(event.parent_hash.is_none(), "genesis events must have no parent");
    }

    #[test]
    fn child_event_has_parent() {
        let parent = Event::genesis("parent", "parent payload", "sig");
        let parent_hash = compute_hash(&parent);
        let child = Event::child("child-1", parent_hash, "child payload", "child_sig");
        assert!(child.parent_hash.is_some(), "child events must have a parent hash");
    }

    #[test]
    fn child_chain_hashes_are_deterministic() {
        let genesis = Event::at_timestamp("g", None, "genesis", 100, "gsig");
        let gh = compute_hash(&genesis);
        let child = Event::at_timestamp("c1", Some(gh.clone()), "child1", 200, "csig");
        let ch = compute_hash(&child);

        // Recompute — must match
        let gh2 = compute_hash(&genesis);
        let ch2 = compute_hash(&child);

        assert_eq!(gh, gh2);
        assert_eq!(ch, ch2);
    }

    #[test]
    fn event_node_new_sets_correct_fields() {
        let event = Event::genesis("g1", "payload", "sig");
        let node = EventNode::new(event.clone(), 0);

        assert_eq!(node.depth, 0);
        assert_eq!(node.integrity_state, IntegrityState::Clean);
        assert!(node.children.is_empty());
        assert_eq!(node.computed_hash, compute_hash(&event));
    }

    #[test]
    fn integrity_state_transitions() {
        assert!(IntegrityState::Clean.is_active());
        assert!(!IntegrityState::TamperDetected.is_active());
        assert!(!IntegrityState::CorruptedGenesis.is_active());
        assert!(IntegrityState::TamperDetected.is_corrupt());
        assert!(IntegrityState::CorruptedGenesis.is_corrupt());
        assert!(!IntegrityState::Clean.is_corrupt());
        assert!(!IntegrityState::ForkDetected.is_corrupt());
    }
}