//! BKG Speculum — Cryptographic Event Tree with Anti-Tamper Enforcement (ASTP v1).
//!
//! The Speculum crate implements the **Anti-Speculum-Tamper-Protokoll (ASTP)**:
//! a cryptographically enforced time-reality grid with anti-manipulation physics.
//!
//! ## Core Concepts
//!
//! - **SpeculumTree** — a SHA-256 hash-chained tree of events
//! - **Genesis Immunity** — the root event cannot be edited; if compromised, the entire tree is isolated
//! - **No Silent Rewrites** — every mutation produces a new hash, never an overwrite
//! - **Isolation over Repair** — corruption is cut out and isolated, never healed
//! - **Fork Awareness** — multiple valid roots = detected forks with split timelines
//! - **Live Integrity Watcher** — continuous background tamper detection
//!
//! ## Integration
//!
//! - `bkg-events` — speculum events emitted into the standard event taxonomy
//! - `bkg-kernel::causality` — speculum tree syncs with causality graph for lineage tracking
//! - `bkg-kernel::trust_engine` — corruption events feed into trust scoring
//!
//! ## Hard Rules (from the protocol)
//!
//! 1. **Immutable Causality** — no event exists without a parent hash (except genesis)
//! 2. **Genesis Immunity Rule** — genesis is not editable; if wrong → system invalid
//! 3. **No Silent Rewrite Rule** — every change produces a new hash
//! 4. **Isolation statt Repair** — corruption is cut, isolated, logged, never healed
//! 5. **Fork Awareness** — two valid genesis = fork detected, no merge without consensus
//!
//! See `docs/superpowers/plans/2026-05-24-anti-speculum-tamper-protocol.md` for the full spec.

pub mod event;
pub mod tree;
pub mod antispeculum;
pub mod isolation;
pub mod watcher;

pub use event::*;
pub use tree::SpeculumTree;
pub use antispeculum::AntiSpeculumLayer;
pub use isolation::IsolationLayer;
pub use watcher::IntegrityWatcher;