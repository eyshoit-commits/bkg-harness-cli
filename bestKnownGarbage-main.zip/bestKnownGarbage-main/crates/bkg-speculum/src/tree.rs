//! SpeculumTree — the cryptographic hash-chained event tree engine.
//!
//! Provides:
//! - Event insertion with parent lineage validation
//! - Genesis guard (immunity rule)
//! - Tamper detection by hash recomputation
//! - Subtree cutting (recursive isolation of corrupt branches)
//! - Fork detection (multiple valid roots)
//! - Tip management (current leaf hashes)

use crate::event::{
    compute_hash, Event, EventNode, IntegrityState, SpeculumHash,
};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// The cryptographic event tree.
///
/// Every event is stored as an `EventNode` keyed by its SHA-256 hash.
/// The tree enforces:
/// - No event insertion without valid parent lineage (except genesis)
/// - No silent rewrites (immutable computed_hash)
/// - Subtree isolation on corruption detection
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SpeculumTree {
    /// All nodes in the tree, keyed by computed hash
    pub nodes: HashMap<SpeculumHash, EventNode>,
    /// The root hash of the tree (set on first genesis insert)
    pub genesis_hash: Option<SpeculumHash>,
    /// Current leaf hashes (events with no children yet)
    pub tip_hashes: Vec<SpeculumHash>,
    /// Hashes of nodes moved to isolation (corrupt or forked)
    pub isolation_layer: Vec<SpeculumHash>,
}

impl Default for SpeculumTree {
    fn default() -> Self {
        Self::new()
    }
}

impl SpeculumTree {
    /// Create a new empty speculum tree.
    #[must_use]
    pub fn new() -> Self {
        Self {
            nodes: HashMap::new(),
            genesis_hash: None,
            tip_hashes: Vec::new(),
            isolation_layer: Vec::new(),
        }
    }

    /// Compute the depth of an event given its optional parent hash.
    fn depth_of(&self, parent_hash: &Option<SpeculumHash>) -> u64 {
        parent_hash
            .as_ref()
            .and_then(|ph| self.nodes.get(ph))
            .map(|parent| parent.depth + 1)
            .unwrap_or(0)
    }

    /// Insert an event into the tree.
    ///
    /// Returns the computed hash on success, or an error if:
    /// - The parent hash references a non-existent node (broken lineage)
    /// - The parent node is in the isolation layer (cannot attach to corrupt)
    ///
    /// Sets `genesis_hash` on the first insertion (event with no parent).
    pub fn insert_event(&mut self, event: Event) -> Result<SpeculumHash, String> {
        let hash = compute_hash(&event);

        // Validate parent lineage if this is not a genesis event
        if let Some(parent) = &event.parent_hash {
            if self.isolation_layer.contains(parent) {
                return Err(format!(
                    "Cannot attach to isolated parent: {}",
                    parent
                ));
            }
            if !self.nodes.contains_key(parent) {
                return Err(format!(
                    "Broken lineage: parent hash {} not found in tree",
                    parent
                ));
            }
        }

        // Validate no duplicate insertion (No Silent Rewrite Rule)
        if self.nodes.contains_key(&hash) {
            return Err(format!(
                "Duplicate event hash: {} — event already exists in tree",
                hash
            ));
        }

        let depth = self.depth_of(&event.parent_hash);

        // Create and insert the node
        let mut node = EventNode::new(event, depth);

        // Link parent-child relationship
        if let Some(parent) = &node.event.parent_hash {
            if let Some(parent_node) = self.nodes.get_mut(parent) {
                parent_node.children.push(hash.clone());
            }
        }

        // Update tip tracking
        self.tip_hashes.push(hash.clone());
        if let Some(parent) = &node.event.parent_hash {
            self.tip_hashes.retain(|t| t != parent);
        }

        // Set genesis hash on first root insertion
        if node.event.parent_hash.is_none() {
            if self.genesis_hash.is_some() {
                // Multiple genesis detected — mark as fork
                node.integrity_state = IntegrityState::ForkDetected;
            } else {
                self.genesis_hash = Some(hash.clone());
            }
        }

        self.nodes.insert(hash.clone(), node);
        Ok(hash)
    }

    // ──────────────────────────────────────────
    // Genesis Guard
    // ──────────────────────────────────────────

    /// Validate genesis integrity.
    ///
    /// If genesis is missing, the system panics (structural invariant).
    /// If genesis hash doesn't match its computed hash, the entire tree
    /// is marked corrupt via `mark_corruption`.
    ///
    /// **Genesis Immunity Rule:** Genesis is not editable. If it's wrong,
    /// the system becomes invalid — it is not corrected.
    pub fn validate_genesis(&mut self) {
        let genesis_hash = match self.genesis_hash.clone() {
            Some(h) => h,
            None => return, // Tree is empty, nothing to validate
        };

        let genesis = match self.nodes.get(&genesis_hash) {
            Some(n) => n.clone(),
            None => {
                // This should never happen if tree invariants hold
                tracing::error!("GENESIS MISSING — SYSTEM INVALID");
                return;
            }
        };

        let recomputed = compute_hash(&genesis.event);

        if recomputed != genesis_hash {
            tracing::error!(
                "GENESIS CORRUPT: stored={}, recomputed={}",
                genesis_hash,
                recomputed
            );
            self.mark_corruption(&genesis_hash, IntegrityState::CorruptedGenesis);
        }
    }

    // ──────────────────────────────────────────
    // Tamper Detection
    // ──────────────────────────────────────────

    /// Detect tamper for a single node by recomputing its hash.
    ///
    /// If the recomputed hash does not match the stored `computed_hash`,
    /// the node is marked as `TamperDetected` and moved to isolation.
    pub fn detect_tamper(&mut self, hash: &SpeculumHash) -> IntegrityState {
        let node = match self.nodes.get(hash) {
            Some(n) => n.clone(),
            None => return IntegrityState::Clean,
        };

        let recomputed = compute_hash(&node.event);

        if recomputed != node.computed_hash {
            tracing::warn!(
                "TAMPER DETECTED at hash={}: stored={}, recomputed={}",
                hash,
                node.computed_hash,
                recomputed
            );
            self.mark_corruption(hash, IntegrityState::TamperDetected);
            IntegrityState::TamperDetected
        } else {
            IntegrityState::Clean
        }
    }

    /// Run tamper detection on all nodes in the tree.
    /// Returns the count of tampered nodes found.
    pub fn scan_all(&mut self) -> usize {
        let hashes: Vec<SpeculumHash> = self.nodes.keys().cloned().collect();
        let mut count = 0;
        for hash in &hashes {
            if self.detect_tamper(hash) != IntegrityState::Clean {
                count += 1;
            }
        }
        count
    }

    // ──────────────────────────────────────────
    // Corruption Handling
    // ──────────────────────────────────────────

    /// Mark a node as corrupt and isolate its entire subtree.
    ///
    /// **Isolation statt Repair:** Corruption is not healed. It is cut out
    /// and moved to the isolation layer. The subtree (all descendants) is
    /// recursively cut as well.
    pub fn mark_corruption(&mut self, hash: &SpeculumHash, state: IntegrityState) {
        if let Some(node) = self.nodes.get_mut(hash) {
            node.integrity_state = state;
        }

        // Move to isolation layer
        if !self.isolation_layer.contains(hash) {
            self.isolation_layer.push(hash.clone());
        }

        // Remove from tip hashes if present
        self.tip_hashes.retain(|t| t != hash);

        // Recursively cut the subtree
        self.cut_subtree(hash);
    }

    /// Recursively cut a subtree, isolating all descendants.
    fn cut_subtree(&mut self, root: &SpeculumHash) {
        let children: Vec<SpeculumHash> = self
            .nodes
            .get(root)
            .map(|n| n.children.clone())
            .unwrap_or_default();

        for child in children {
            if let Some(node) = self.nodes.get_mut(&child) {
                node.integrity_state = IntegrityState::TamperDetected;
            }
            if !self.isolation_layer.contains(&child) {
                self.isolation_layer.push(child.clone());
            }
            self.tip_hashes.retain(|t| t != &child);
            self.cut_subtree(&child);
        }
    }

    // ──────────────────────────────────────────
    // Fork Detection
    // ──────────────────────────────────────────

    /// Detect forks in the tree.
    ///
    /// A fork occurs when multiple valid root events exist (events with no parent
    /// that are not in the isolation layer and have clean integrity state).
    ///
    /// Returns a vector of branches, where each branch is a vector of hashes
    /// from root to leaves.
    pub fn detect_forks(&self) -> Vec<Vec<SpeculumHash>> {
        let roots: Vec<&EventNode> = self
            .nodes
            .values()
            .filter(|n| {
                n.event.parent_hash.is_none()
                    && !self.isolation_layer.contains(&n.computed_hash)
                    && n.integrity_state == IntegrityState::Clean
            })
            .collect();

        if roots.len() <= 1 {
            return Vec::new(); // No fork (single root is normal)
        }

        roots.iter().map(|root| self.collect_branch(&root.computed_hash)).collect()
    }

    /// Collect all hashes in a branch starting from a root.
    fn collect_branch(&self, root: &SpeculumHash) -> Vec<SpeculumHash> {
        let mut branch = Vec::new();
        let mut stack = vec![root.clone()];

        while let Some(hash) = stack.pop() {
            if !self.isolation_layer.contains(&hash) {
                branch.push(hash.clone());
                if let Some(node) = self.nodes.get(&hash) {
                    for child in &node.children {
                        stack.push(child.clone());
                    }
                }
            }
        }

        branch
    }

    // ──────────────────────────────────────────
    // Queries
    // ──────────────────────────────────────────

    /// Get the lineage (ancestor chain) for a given hash, from root to node.
    #[must_use]
    pub fn lineage(&self, hash: &SpeculumHash) -> Vec<SpeculumHash> {
        let mut chain = Vec::new();
        let mut current = hash.clone();

        loop {
            chain.push(current.clone());
            let node = match self.nodes.get(&current) {
                Some(n) => n,
                None => break,
            };
            match &node.event.parent_hash {
                Some(parent) => current = parent.clone(),
                None => break,
            }
        }

        chain.reverse();
        chain
    }

    /// Check if a specific hash is isolated.
    #[must_use]
    pub fn is_isolated(&self, hash: &SpeculumHash) -> bool {
        self.isolation_layer.contains(hash)
    }

    /// Number of active (non-isolated) nodes in the tree.
    #[must_use]
    pub fn active_count(&self) -> usize {
        self.nodes.len() - self.isolation_layer.len()
    }

    /// Total number of nodes in the tree (including isolated).
    #[must_use]
    pub fn total_count(&self) -> usize {
        self.nodes.len()
    }

    /// Depth of the tree (max depth of any active node).
    #[must_use]
    pub fn max_depth(&self) -> u64 {
        self.nodes
            .values()
            .filter(|n| !self.isolation_layer.contains(&n.computed_hash))
            .map(|n| n.depth)
            .max()
            .unwrap_or(0)
    }
}

// ──────────────────────────────────────────────
// Tests
// ──────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn insert_genesis_event() {
        let mut tree = SpeculumTree::new();
        let event = Event::genesis("g1", "first event", "root_sig");
        let hash = tree.insert_event(event).unwrap();

        assert!(tree.genesis_hash.is_some());
        assert_eq!(tree.genesis_hash.unwrap(), hash);
        assert_eq!(tree.nodes.len(), 1);
        assert_eq!(tree.tip_hashes.len(), 1);
        assert_eq!(tree.nodes[&hash].depth, 0);
    }

    #[test]
    fn insert_child_event() {
        let mut tree = SpeculumTree::new();
        let genesis = Event::genesis("g1", "genesis", "sig");
        let gh = tree.insert_event(genesis).unwrap();

        let child = Event::child("c1", gh.clone(), "child payload", "c_sig");
        let ch = tree.insert_event(child).unwrap();

        assert_eq!(tree.nodes.len(), 2);
        assert_eq!(tree.nodes[&ch].depth, 1);
        assert!(tree.nodes[&gh].children.contains(&ch));
        assert!(tree.tip_hashes.contains(&ch));
        assert!(!tree.tip_hashes.contains(&gh));
    }

    #[test]
    fn broken_lineage_rejected() {
        let mut tree = SpeculumTree::new();
        let orphan = Event::child("orphan", "nonexistent_hash".into(), "payload", "sig");
        let result = tree.insert_event(orphan);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Broken lineage"));
    }

    #[test]
    fn duplicate_event_rejected() {
        let mut tree = SpeculumTree::new();
        let event = Event::at_timestamp("dup", None, "payload", 1000, "sig");
        tree.insert_event(event.clone()).unwrap();
        let result = tree.insert_event(event);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("Duplicate event hash"));
    }

    #[test]
    fn cant_attach_to_isolated_parent() {
        let mut tree = SpeculumTree::new();
        let genesis = Event::genesis("g1", "genesis", "sig");
        let gh = tree.insert_event(genesis).unwrap();

        // Corrupt the genesis
        tree.mark_corruption(&gh, IntegrityState::CorruptedGenesis);

        // Try to attach to isolated genesis
        let child = Event::child("c1", gh, "child", "csig");
        let result = tree.insert_event(child);
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("isolated parent"));
    }

    #[test]
    fn tamper_detection_catches_hash_mismatch() {
        let mut tree = SpeculumTree::new();
        let event = Event::at_timestamp("t1", None, "original", 1000, "sig");
        let hash = tree.insert_event(event).unwrap();

        // Manually corrupt the node's computed hash in the map
        if let Some(node) = tree.nodes.get_mut(&hash) {
            node.computed_hash = "corrupted_fake_hash".to_string();
        }

        let result = tree.detect_tamper(&hash);
        assert_eq!(result, IntegrityState::TamperDetected);
        assert!(tree.isolation_layer.contains(&hash));
    }

    #[test]
    fn clean_node_passes_tamper_detection() {
        let mut tree = SpeculumTree::new();
        let event = Event::genesis("g1", "clean", "sig");
        let hash = tree.insert_event(event).unwrap();

        let result = tree.detect_tamper(&hash);
        assert_eq!(result, IntegrityState::Clean);
        assert!(!tree.isolation_layer.contains(&hash));
    }

    #[test]
    fn subtree_is_fully_cut_on_corruption() {
        let mut tree = SpeculumTree::new();
        let g = Event::genesis("g1", "root", "sig");
        let gh = tree.insert_event(g).unwrap();

        let c1 = Event::child("c1", gh.clone(), "child1", "csig");
        let c1h = tree.insert_event(c1).unwrap();

        let c2 = Event::child("c2", c1h.clone(), "child2", "csig2");
        let c2h = tree.insert_event(c2).unwrap();

        // Corrupt the middle node
        tree.mark_corruption(&c1h, IntegrityState::TamperDetected);

        // Both c1 and c2 should be in isolation
        assert!(tree.isolation_layer.contains(&c1h));
        assert!(tree.isolation_layer.contains(&c2h));
        // Genesis should NOT be in isolation
        assert!(!tree.isolation_layer.contains(&gh));
        // Tips should not contain isolated nodes
        assert!(!tree.tip_hashes.contains(&c2h));
    }

    #[test]
    fn fork_detection_with_two_genesis_roots() {
        let mut tree = SpeculumTree::new();

        let g1 = Event::genesis("g1", "first genesis", "sig1");
        let g1h = tree.insert_event(g1).unwrap();

        let g2 = Event::genesis("g2", "second genesis", "sig2");
        let _g2h = tree.insert_event(g2).unwrap();

        let forks = tree.detect_forks();
        assert_eq!(forks.len(), 1, "should detect exactly one fork pair");

        // First genesis should still be the official genesis_hash
        assert_eq!(tree.genesis_hash.unwrap(), g1h);
    }

    #[test]
    fn lineage_is_correct() {
        let mut tree = SpeculumTree::new();
        let g = Event::genesis("g1", "root", "sig");
        let gh = tree.insert_event(g).unwrap();
        let c1 = Event::child("c1", gh.clone(), "child1", "csig");
        let c1h = tree.insert_event(c1).unwrap();
        let c2 = Event::child("c2", c1h.clone(), "child2", "csig2");
        let c2h = tree.insert_event(c2).unwrap();

        let lineage = tree.lineage(&c2h);
        assert_eq!(lineage.len(), 3);
        assert_eq!(lineage[0], gh);
        assert_eq!(lineage[1], c1h);
        assert_eq!(lineage[2], c2h);
    }

    #[test]
    fn genesis_guard_panics_on_missing_genesis() {
        let mut tree = SpeculumTree::new();
        // Empty tree should not panic
        tree.validate_genesis();
        assert!(tree.genesis_hash.is_none());
    }

    #[test]
    fn max_depth_is_accurate() {
        let mut tree = SpeculumTree::new();
        let g = Event::genesis("g1", "root", "sig");
        let gh = tree.insert_event(g).unwrap();
        let c1 = Event::child("c1", gh.clone(), "child1", "csig");
        let c1h = tree.insert_event(c1).unwrap();
        let _c2 = Event::child("c2", c1h, "child2", "csig2");

        assert_eq!(tree.max_depth(), 2);
    }

    #[test]
    fn scan_all_detects_all_tampered_nodes() {
        let mut tree = SpeculumTree::new();
        let g = Event::genesis("g1", "root", "sig");
        let gh = tree.insert_event(g).unwrap();
        let c1 = Event::child("c1", gh.clone(), "child1", "csig");
        let c1h = tree.insert_event(c1).unwrap();
        let _c2 = Event::child("c2", c1h, "child2", "csig2");

        // Corrupt a node
        tree.mark_corruption(&gh, IntegrityState::TamperDetected);

        // The other nodes should also be in isolation due to subtree cut
        let isolated = tree.isolation_layer.len();
        assert!(isolated > 1);
    }
}