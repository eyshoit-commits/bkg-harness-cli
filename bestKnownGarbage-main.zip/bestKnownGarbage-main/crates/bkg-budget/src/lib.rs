//! Token/Budget Limiter with graceful save, analytics, and pricing.
//!
//! Ported from mythos-router. See `/home/bkg/workspace/mythos-router/src/budget.ts`
//! and `/home/bkg/workspace/mythos-router/src/metrics.ts`

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

// ── Configuration ─────────────────────────────────────────────

/// Default budget settings.
pub const DEFAULT_MAX_TOKENS: u64 = 500_000;
pub const DEFAULT_MAX_TURNS: u32 = 25;
pub const WARNING_THRESHOLD: f64 = 0.80;

/// Pricing per 1M tokens (Opus 4.7 rates).
pub const PRICING_INPUT_PER_1M: f64 = 5.00;
pub const PRICING_OUTPUT_PER_1M: f64 = 25.00;

// ── Types ────────────────────────────────────────────────────

/// Budget configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BudgetConfig {
    /// Maximum tokens per session
    pub max_tokens: u64,
    /// Maximum turns per session
    pub max_turns: u32,
    /// Whether budgeting is enabled
    pub enabled: bool,
}

impl Default for BudgetConfig {
    fn default() -> Self {
        Self {
            max_tokens: DEFAULT_MAX_TOKENS,
            max_turns: DEFAULT_MAX_TURNS,
            enabled: true,
        }
    }
}

/// Token usage for a single operation.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct TokenUsage {
    pub input_tokens: u64,
    pub output_tokens: u64,
}

impl TokenUsage {
    pub fn total(&self) -> u64 {
        self.input_tokens + self.output_tokens
    }

    pub fn estimated_cost(&self) -> f64 {
        let input_cost = (self.input_tokens as f64 / 1_000_000.0) * PRICING_INPUT_PER_1M;
        let output_cost = (self.output_tokens as f64 / 1_000_000.0) * PRICING_OUTPUT_PER_1M;
        input_cost + output_cost
    }
}

/// Session budget state.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionBudget {
    /// Total input tokens used
    pub total_input: u64,
    /// Total output tokens used
    pub total_output: u64,
    /// Total turns used
    pub turns_used: u32,
    /// Maximum tokens allowed
    pub max_tokens: u64,
    /// Maximum turns allowed
    pub max_turns: u32,
    /// Whether budget is enabled
    pub enabled: bool,
}

impl SessionBudget {
    pub fn new(config: BudgetConfig) -> Self {
        Self {
            total_input: 0,
            total_output: 0,
            turns_used: 0,
            max_tokens: config.max_tokens,
            max_turns: config.max_turns,
            enabled: config.enabled,
        }
    }

    /// Record token usage for one turn.
    pub fn record(&mut self, usage: TokenUsage) {
        self.total_input += usage.input_tokens;
        self.total_output += usage.output_tokens;
        self.turns_used += 1;
    }

    /// Total tokens consumed.
    pub fn total_tokens(&self) -> u64 {
        self.total_input + self.total_output
    }

    /// Estimated cost in USD.
    pub fn estimated_cost(&self) -> f64 {
        let input_cost = (self.total_input as f64 / 1_000_000.0) * PRICING_INPUT_PER_1M;
        let output_cost = (self.total_output as f64 / 1_000_000.0) * PRICING_OUTPUT_PER_1M;
        input_cost + output_cost
    }

    /// Token consumption ratio (0.0 - 1.0).
    pub fn token_ratio(&self) -> f64 {
        if !self.enabled || self.max_tokens == 0 {
            return 0.0;
        }
        (self.total_tokens() as f64 / self.max_tokens as f64).min(1.0)
    }

    /// Turn consumption ratio.
    pub fn turn_ratio(&self) -> f64 {
        if !self.enabled || self.max_turns == 0 {
            return 0.0;
        }
        (self.turns_used as f64 / self.max_turns as f64).min(1.0)
    }

    /// Check if warning threshold is reached.
    pub fn is_warning(&self) -> bool {
        self.enabled
            && (self.token_ratio() >= WARNING_THRESHOLD || self.turn_ratio() >= WARNING_THRESHOLD)
    }

    /// Check if budget is exhausted.
    pub fn is_exhausted(&self) -> bool {
        if !self.enabled {
            return false;
        }
        self.total_tokens() >= self.max_tokens || self.turns_used >= self.max_turns
    }

    /// Check if a turn would exceed budget.
    pub fn would_exceed(&self, estimated_tokens: u64) -> bool {
        if !self.enabled {
            return false;
        }
        self.total_tokens() + estimated_tokens > self.max_tokens
            || self.turns_used >= self.max_turns
    }

    /// Format a budget bar for display.
    pub fn format_bar(&self) -> String {
        let bar_width = 20;
        let token_fill = (self.token_ratio() * bar_width as f64).round() as usize;
        let turn_fill = (self.turn_ratio() * bar_width as f64).round() as usize;

        let token_bar = format!(
            "[{}{}]",
            "█".repeat(token_fill.min(bar_width)),
            "░".repeat(bar_width.saturating_sub(token_fill))
        );
        let turn_bar = format!(
            "[{}{}]",
            "█".repeat(turn_fill.min(bar_width)),
            "░".repeat(bar_width.saturating_sub(turn_fill))
        );

        format!(
            "budget: {} {}/{} tokens · {} {}/{} turns · ~${:.4}",
            token_bar,
            self.total_tokens(),
            self.max_tokens,
            turn_bar,
            self.turns_used,
            self.max_turns,
            self.estimated_cost(),
        )
    }
}

// ── Metrics / Analytics ──────────────────────────────────────

/// A single metrics record.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricsRecord {
    pub timestamp: String,
    pub command: String,
    pub project: String,
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub turns: u32,
    pub cost: f64,
}

/// Persistent metrics store.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricsStore {
    records: Vec<MetricsRecord>,
}

impl MetricsStore {
    pub fn new() -> Self {
        Self { records: vec![] }
    }

    /// Load metrics from file.
    pub fn load(path: &PathBuf) -> Self {
        if path.exists() {
            if let Ok(content) = fs::read_to_string(path) {
                if let Ok(store) = serde_json::from_str::<MetricsStore>(&content) {
                    return store;
                }
            }
        }
        Self::new()
    }

    /// Save metrics to file.
    pub fn save(&self, path: &PathBuf) {
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        if let Ok(content) = serde_json::to_string_pretty(self) {
            let _ = fs::write(path, content);
        }
    }

    /// Record a new metrics entry.
    pub fn record(&mut self, record: MetricsRecord) {
        self.records.push(record);
    }

    /// Get total tokens across all records.
    pub fn total_tokens(&self) -> (u64, u64) {
        let input = self.records.iter().map(|r| r.input_tokens).sum();
        let output = self.records.iter().map(|r| r.output_tokens).sum();
        (input, output)
    }

    /// Get total cost.
    pub fn total_cost(&self) -> f64 {
        self.records.iter().map(|r| r.cost).sum()
    }

    /// Get records filtered by command.
    pub fn by_command(&self, command: &str) -> Vec<&MetricsRecord> {
        self.records
            .iter()
            .filter(|r| r.command == command)
            .collect()
    }

    /// Get records filtered by project.
    pub fn by_project(&self, project: &str) -> Vec<&MetricsRecord> {
        self.records
            .iter()
            .filter(|r| r.project == project)
            .collect()
    }

    /// Get records within N days.
    pub fn recent(&self, days: i64) -> Vec<&MetricsRecord> {
        let cutoff = chrono::Utc::now() - chrono::Duration::days(days);
        self.records
            .iter()
            .filter(|r| {
                chrono::DateTime::parse_from_rfc3339(&r.timestamp)
                    .map(|dt| dt > cutoff)
                    .unwrap_or(true)
            })
            .collect()
    }

    /// Summary string.
    pub fn summary(&self, days: Option<i64>) -> String {
        let records: Vec<&MetricsRecord> = match days {
            Some(d) => self.recent(d),
            None => self.records.iter().collect(),
        };

        let total_input: u64 = records.iter().map(|r| r.input_tokens).sum();
        let total_output: u64 = records.iter().map(|r| r.output_tokens).sum();
        let total_cost: f64 = records.iter().map(|r| r.cost).sum();
        let total_turns: u32 = records.iter().map(|r| r.turns).sum();

        format!(
            "📊 Budget Analytics ({} records)\n\
             Total tokens: {} in / {} out\n\
             Total turns: {}\n\
             Total cost: ${:.4}\n\
             Sessions: {}",
            records.len(),
            total_input,
            total_output,
            total_turns,
            total_cost,
            records.len(),
        )
    }
}

impl Default for MetricsStore {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_budget_tracking() {
        let config = BudgetConfig::default();
        let mut budget = SessionBudget::new(config);

        assert!(!budget.is_exhausted());
        assert!(!budget.is_warning());

        budget.record(TokenUsage {
            input_tokens: 100000,
            output_tokens: 50000,
        });

        assert!(budget.total_tokens() > 0);
        assert!(budget.estimated_cost() > 0.0);
    }

    #[test]
    fn test_budget_exhaustion() {
        let config = BudgetConfig {
            max_tokens: 1000,
            max_turns: 1,
            enabled: true,
        };
        let mut budget = SessionBudget::new(config);

        budget.record(TokenUsage {
            input_tokens: 600,
            output_tokens: 500,
        });

        assert!(budget.is_exhausted());
    }

    #[test]
    fn test_metrics_store() {
        let mut store = MetricsStore::new();
        store.record(MetricsRecord {
            timestamp: chrono::Utc::now().to_rfc3339(),
            command: "chat".to_string(),
            project: "test".to_string(),
            input_tokens: 1000,
            output_tokens: 500,
            turns: 5,
            cost: 0.02,
        });

        assert_eq!(store.total_tokens(), (1000, 500));
        assert!(store.total_cost() > 0.0);
    }
}
