//! CI Verification + Integrity Gate — read-only PR/diff risk review.
//!
//! Ported from mythos-router. See `/home/bkg/workspace/mythos-router/src/ci/verify.ts`

use serde::{Deserialize, Serialize};
use std::fs;
use std::path::{Path, PathBuf};

// ── Types ────────────────────────────────────────────────────

/// Severity of a finding.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum FindingSeverity {
    High,
    Medium,
    Low,
    Info,
}

/// A single verification finding.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Finding {
    pub severity: FindingSeverity,
    pub category: String,
    pub message: String,
    pub file: Option<String>,
    pub line: Option<usize>,
}

/// CI verification result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerifyReport {
    pub passed: bool,
    pub findings: Vec<Finding>,
    pub summary: String,
    /// Whether findings exceeded thresholds
    pub strict_fail: bool,
}

impl VerifyReport {
    pub fn new() -> Self {
        Self {
            passed: true,
            findings: vec![],
            summary: String::new(),
            strict_fail: false,
        }
    }

    pub fn add_finding(&mut self, finding: Finding) {
        if finding.severity == FindingSeverity::High {
            self.passed = false;
        }
        self.findings.push(finding);
    }

    pub fn count_by_severity(&self, severity: FindingSeverity) -> usize {
        self.findings
            .iter()
            .filter(|f| f.severity == severity)
            .count()
    }

    pub fn format(&self, json_output: bool) -> String {
        if json_output {
            return serde_json::to_string_pretty(self).unwrap_or_default();
        }

        let mut out = String::new();
        out.push_str(&format!("=== CI Verification Report ===\n\n"));

        if self.passed {
            out.push_str("✅ PASSED — No high-severity findings\n");
        } else {
            out.push_str("❌ FAILED — High-severity findings detected\n");
        }

        if self.strict_fail {
            out.push_str("⚠️  Strict mode: warnings treated as failures\n");
        }

        out.push_str(&format!(
            "\nFindings: {} high, {} medium, {} low, {} info\n\n",
            self.count_by_severity(FindingSeverity::High),
            self.count_by_severity(FindingSeverity::Medium),
            self.count_by_severity(FindingSeverity::Low),
            self.count_by_severity(FindingSeverity::Info),
        ));

        for finding in &self.findings {
            let sev = match finding.severity {
                FindingSeverity::High => "🔴 HIGH",
                FindingSeverity::Medium => "🟡 MEDIUM",
                FindingSeverity::Low => "🟢 LOW",
                FindingSeverity::Info => "ℹ️ INFO",
            };
            out.push_str(&format!(
                "  {} [{}] {}\n",
                sev, finding.category, finding.message
            ));
            if let Some(ref file) = finding.file {
                if let Some(line) = finding.line {
                    out.push_str(&format!("     → {}:{}\n", file, line));
                } else {
                    out.push_str(&format!("     → {}\n", file));
                }
            }
            out.push('\n');
        }

        if !self.summary.is_empty() {
            out.push_str(&format!("Summary: {}\n", self.summary));
        }

        out
    }
}

impl Default for VerifyReport {
    fn default() -> Self {
        Self::new()
    }
}

// ── CI Rules Engine ──────────────────────────────────────────

/// High-risk file patterns to scan.
const HIGH_RISK_PATTERNS: &[(&str, &str, FindingSeverity)] = &[
    ("package.json", "npm scripts", FindingSeverity::High),
    ("scripts/*", "shell scripts", FindingSeverity::High),
    (
        ".github/workflows/*",
        "CI/CD workflows",
        FindingSeverity::High,
    ),
    ("deploy/*", "deployment config", FindingSeverity::High),
    ("Dockerfile*", "container config", FindingSeverity::High),
    ("Makefile", "build config", FindingSeverity::High),
    (".env*", "environment config", FindingSeverity::Medium),
    (".npmrc", "npm config", FindingSeverity::Medium),
    ("compose.*", "docker compose", FindingSeverity::Medium),
    ("*.pem", "private key file", FindingSeverity::High),
    ("id_rsa*", "SSH key", FindingSeverity::High),
];

/// Sensitive content patterns (regex-like strings).
const SECRET_PATTERNS: &[&str] = &[
    "sk-ant-",
    "sk-proj-",
    "ghp_",
    "github_pat_",
    "AKIA",
    "-----BEGIN",
];

/// The CI verification engine.
pub struct VerifyEngine {
    working_dir: PathBuf,
    /// .mythosignore patterns
    ignore_patterns: Vec<String>,
}

impl VerifyEngine {
    pub fn new(working_dir: PathBuf) -> Self {
        let ignore_patterns = Self::load_ignore(&working_dir.join(".mythosignore"));
        Self {
            working_dir,
            ignore_patterns,
        }
    }

    fn load_ignore(path: &Path) -> Vec<String> {
        if !path.exists() {
            return vec![];
        }
        let content = fs::read_to_string(path).unwrap_or_default();
        content
            .lines()
            .map(|l| l.trim().to_string())
            .filter(|l| !l.is_empty() && !l.starts_with('#'))
            .collect()
    }

    fn is_ignored(&self, file_path: &str) -> bool {
        self.ignore_patterns.iter().any(|p| {
            if p.ends_with('/') {
                file_path.starts_with(p)
            } else {
                file_path.contains(p.as_str())
            }
        })
    }

    /// Run CI verification on the current workspace.
    pub fn verify(&self, strict: bool, _json: bool) -> VerifyReport {
        let mut report = VerifyReport::new();
        report.strict_fail = strict;

        self.check_high_risk_files(&mut report);
        self.check_secrets(&mut report);
        self.check_receipt_integrity(&mut report);

        if report.passed {
            report.summary = "All CI checks passed.".to_string();
        } else {
            report.summary = format!(
                "Found {} high, {} medium severity issues.",
                report.count_by_severity(FindingSeverity::High),
                report.count_by_severity(FindingSeverity::Medium),
            );
        }

        if strict
            && report
                .findings
                .iter()
                .any(|f| f.severity != FindingSeverity::Info)
        {
            report.passed = false;
            report.strict_fail = true;
        }

        report
    }

    /// Check for modifications to high-risk files.
    fn check_high_risk_files(&self, report: &mut VerifyReport) {
        // Walk the working directory looking for high-risk patterns
        if let Ok(entries) = fs::read_dir(&self.working_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                let rel_path = path
                    .strip_prefix(&self.working_dir)
                    .unwrap_or(&path)
                    .to_string_lossy()
                    .to_string();

                if self.is_ignored(&rel_path) {
                    continue;
                }

                for (pattern, category, severity) in HIGH_RISK_PATTERNS {
                    if glob_match(pattern, &rel_path) {
                        let is_dir = path.is_dir();
                        if !is_dir {
                            report.add_finding(Finding {
                                severity: severity.clone(),
                                category: category.to_string(),
                                message: format!("Modified high-risk file: {}", rel_path),
                                file: Some(rel_path.clone()),
                                line: None,
                            });
                        }
                    }
                }
            }
        }
    }

    /// Check for potential secrets in staged/changed files.
    fn check_secrets(&self, report: &mut VerifyReport) {
        if let Ok(entries) = fs::read_dir(&self.working_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if !path.is_file() {
                    continue;
                }

                let rel_path = path
                    .strip_prefix(&self.working_dir)
                    .unwrap_or(&path)
                    .to_string_lossy()
                    .to_string();

                if self.is_ignored(&rel_path) {
                    continue;
                }

                // Skip binary files
                let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
                if matches!(
                    ext,
                    "png" | "jpg" | "jpeg" | "gif" | "ico" | "woff" | "woff2" | "ttf"
                ) {
                    continue;
                }

                if let Ok(content) = fs::read_to_string(&path) {
                    for (i, line) in content.lines().enumerate() {
                        for pattern in SECRET_PATTERNS {
                            if line.contains(pattern) {
                                report.add_finding(Finding {
                                    severity: FindingSeverity::High,
                                    category: "secret".to_string(),
                                    message: format!(
                                        "Potential secret found matching pattern '{}'",
                                        pattern
                                    ),
                                    file: Some(rel_path.clone()),
                                    line: Some(i + 1),
                                });
                            }
                        }
                    }
                }
            }
        }
    }

    /// Check receipt integrity.
    fn check_receipt_integrity(&self, report: &mut VerifyReport) {
        let receipts_dir = self.working_dir.join(".mythos").join("receipts");
        if !receipts_dir.exists() {
            report.add_finding(Finding {
                severity: FindingSeverity::Info,
                category: "receipts".to_string(),
                message: "No SWD receipts directory found. Run with SWD enabled to generate trust receipts.".to_string(),
                file: None,
                line: None,
            });
            return;
        }

        if let Ok(entries) = fs::read_dir(&receipts_dir) {
            let count = entries.flatten().count();
            if count == 0 {
                report.add_finding(Finding {
                    severity: FindingSeverity::Info,
                    category: "receipts".to_string(),
                    message: "Receipts directory is empty.".to_string(),
                    file: None,
                    line: None,
                });
            } else {
                report.add_finding(Finding {
                    severity: FindingSeverity::Low,
                    category: "receipts".to_string(),
                    message: format!("{} SWD receipt(s) found. Verify with `bkg verify`", count),
                    file: None,
                    line: None,
                });
            }
        }
    }
}

/// Simple glob pattern matching.
fn glob_match(pattern: &str, path: &str) -> bool {
    if pattern.contains('*') {
        let prefix = pattern.trim_end_matches('*');
        let suffix = pattern.trim_start_matches('*');
        if pattern.starts_with('*') && pattern.ends_with('*') {
            path.contains(suffix)
        } else if pattern.ends_with('*') {
            path.starts_with(prefix)
        } else if pattern.starts_with('*') {
            path.ends_with(suffix)
        } else {
            path == pattern
        }
    } else if pattern.ends_with('/') {
        path.starts_with(pattern)
    } else {
        path == pattern || path.ends_with(&format!("/{}", pattern))
    }
}

/// Memory integrity check.
pub struct IntegrityGate {
    working_dir: PathBuf,
}

impl IntegrityGate {
    pub fn new(working_dir: PathBuf) -> Self {
        Self { working_dir }
    }

    /// Verify that all files referenced in MEMORY.md still exist.
    pub fn check_memory_files(&self) -> Vec<Finding> {
        let mut findings = vec![];
        let memory_path = self.working_dir.join("MEMORY.md");

        if !memory_path.exists() {
            findings.push(Finding {
                severity: FindingSeverity::Info,
                category: "integrity".to_string(),
                message: "MEMORY.md not found. No memory integrity check needed.".to_string(),
                file: None,
                line: None,
            });
            return findings;
        }

        let content = fs::read_to_string(&memory_path).unwrap_or_default();

        for (i, line) in content.lines().enumerate() {
            // Look for file metadata blocks like: path=src/main.rs
            if line.starts_with("path=") {
                let file_path = line[5..].trim();
                let abs_path = self.working_dir.join(file_path);
                if !abs_path.exists() {
                    findings.push(Finding {
                        severity: FindingSeverity::Medium,
                        category: "integrity".to_string(),
                        message: format!("MEMORY.md references missing file: {}", file_path),
                        file: Some("MEMORY.md".to_string()),
                        line: Some(i + 1),
                    });
                }
            }
        }

        findings
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_glob_match() {
        assert!(glob_match("*.rs", "src/main.rs"));
        assert!(glob_match("Dockerfile*", "Dockerfile.prod"));
        assert!(glob_match(".env*", ".env.local"));
        assert!(!glob_match("*.rs", "main.ts"));
    }

    #[test]
    fn test_verify_report() {
        let mut report = VerifyReport::new();
        assert!(report.passed);

        report.add_finding(Finding {
            severity: FindingSeverity::High,
            category: "secrets".to_string(),
            message: "Potential secret found".to_string(),
            file: Some(".env".to_string()),
            line: Some(1),
        });

        assert!(!report.passed);
    }
}
