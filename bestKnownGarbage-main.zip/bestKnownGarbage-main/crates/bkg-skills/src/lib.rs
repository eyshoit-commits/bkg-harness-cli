//! Skills Protocol — YAML frontmatter plugin injection and expert skills.
//!
//! Ported from mythos-router. See `/home/bkg/workspace/mythos-router/src/skills.ts`

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};

// ── Types ────────────────────────────────────────────────────

/// A skill definition loaded from YAML frontmatter.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Skill {
    /// Skill name (e.g., "react", "mcp", "rust")
    pub name: String,
    /// Human-readable description
    pub description: String,
    /// Skill version
    #[serde(default = "default_version")]
    pub version: String,
    /// System prompt fragment to inject
    #[serde(default)]
    pub prompt: String,
    /// Provider preference (e.g., "anthropic", "openai")
    #[serde(default)]
    pub preferred_provider: Option<String>,
    /// Model preference
    #[serde(default)]
    pub preferred_model: Option<String>,
    /// Tags for categorization
    #[serde(default)]
    pub tags: Vec<String>,
    /// Additional metadata
    #[serde(default)]
    pub metadata: HashMap<String, String>,
}

fn default_version() -> String {
    "1.0.0".to_string()
}

/// A skill set — collection of skills for a session.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SkillSet {
    pub skills: Vec<Skill>,
}

impl SkillSet {
    pub fn new() -> Self {
        Self { skills: vec![] }
    }

    /// Add a skill.
    pub fn add(&mut self, skill: Skill) {
        // Deduplicate by name
        if let Some(pos) = self.skills.iter().position(|s| s.name == skill.name) {
            self.skills[pos] = skill;
        } else {
            self.skills.push(skill);
        }
    }

    /// Get a skill by name.
    pub fn get(&self, name: &str) -> Option<&Skill> {
        self.skills.iter().find(|s| s.name == name)
    }

    /// Get all skill names.
    pub fn names(&self) -> Vec<&str> {
        self.skills.iter().map(|s| s.name.as_str()).collect()
    }

    /// Build combined system prompt from all loaded skills.
    pub fn build_prompt(&self) -> String {
        if self.skills.is_empty() {
            return String::new();
        }

        let mut prompt = String::from("\n\n## Loaded Skills\n\n");
        for skill in &self.skills {
            prompt.push_str(&format!("### {}\n", skill.name));
            prompt.push_str(&format!("> {}\n\n", skill.description));
            if !skill.prompt.is_empty() {
                prompt.push_str(&skill.prompt);
                prompt.push('\n');
            }
        }
        prompt
    }
}

/// Errors from skill operations.
#[derive(Debug, thiserror::Error)]
pub enum SkillError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Parse error: {0}")]
    Parse(String),
    #[error("Skill not found: {0}")]
    NotFound(String),
}

type Result<T> = std::result::Result<T, SkillError>;

// ── Built-in Skills ──────────────────────────────────────────

/// Built-in skills bundled with the system.
pub fn builtin_skills() -> Vec<Skill> {
    vec![
        Skill {
            name: "rust".to_string(),
            description: "Expert Rust programming with best practices".to_string(),
            version: "1.0.0".to_string(),
            prompt: "You are an expert Rust developer. Follow Rust idioms: use Result/Option for error handling, prefer iterators over loops, leverage the type system, and write idiomatic unsafe code only when necessary.".to_string(),
            preferred_provider: None,
            preferred_model: None,
            tags: vec!["programming".to_string(), "rust".to_string()],
            metadata: HashMap::new(),
        },
        Skill {
            name: "security".to_string(),
            description: "Security audit and vulnerability analysis".to_string(),
            version: "1.0.0".to_string(),
            prompt: "You are a security expert. Analyze code for vulnerabilities following OWASP Top 10. Check for injection, broken auth, sensitive data exposure, XXE, broken access control, misconfiguration, XSS, deserialization, and logging/monitoring gaps.".to_string(),
            preferred_provider: None,
            preferred_model: None,
            tags: vec!["security".to_string(), "audit".to_string()],
            metadata: HashMap::new(),
        },
        Skill {
            name: "testing".to_string(),
            description: "Test-driven development and testing best practices".to_string(),
            version: "1.0.0".to_string(),
            prompt: "You practice test-driven development. Write tests before implementation. Cover unit tests, integration tests, and edge cases. Use property-based testing where appropriate. Ensure >80% code coverage.".to_string(),
            preferred_provider: None,
            preferred_model: None,
            tags: vec!["testing".to_string(), "quality".to_string()],
            metadata: HashMap::new(),
        },
        Skill {
            name: "docs".to_string(),
            description: "Technical documentation and API reference writing".to_string(),
            version: "1.0.0".to_string(),
            prompt: "You write clear, comprehensive documentation. Follow the principle of least astonishment. Include examples, edge cases, and reasoning. Document both public APIs and internal architecture.".to_string(),
            preferred_provider: None,
            preferred_model: None,
            tags: vec!["documentation".to_string(), "writing".to_string()],
            metadata: HashMap::new(),
        },
    ]
}

// ── Skills Manager ───────────────────────────────────────────

/// Manages skill discovery, loading, and runtime.
pub struct SkillsManager {
    /// Built-in skills
    builtins: Vec<Skill>,
    /// User-installed skill directories
    skill_dirs: Vec<PathBuf>,
    /// Cache of loaded skills
    loaded: SkillSet,
}

impl SkillsManager {
    pub fn new() -> Self {
        Self {
            builtins: builtin_skills(),
            skill_dirs: vec![],
            loaded: SkillSet::new(),
        }
    }

    /// Add a directory to search for user skills.
    pub fn add_skill_dir(&mut self, dir: PathBuf) {
        self.skill_dirs.push(dir);
    }

    /// Load a skill by name (from builtins or user dirs).
    pub fn load_skill(&mut self, name: &str) -> Result<Skill> {
        // Check builtins first
        if let Some(skill) = self.builtins.iter().find(|s| s.name == name) {
            self.loaded.add(skill.clone());
            return Ok(skill.clone());
        }

        // Search user directories for .skill.yaml files
        for dir in &self.skill_dirs {
            if dir.exists() {
                if let Ok(entries) = fs::read_dir(dir) {
                    for entry in entries.flatten() {
                        let path = entry.path();
                        if path.extension().and_then(|e| e.to_str()) == Some("yaml")
                            || path.extension().and_then(|e| e.to_str()) == Some("yml")
                        {
                            if let Ok(skill) = load_skill_from_file(&path) {
                                if skill.name == name {
                                    self.loaded.add(skill.clone());
                                    return Ok(skill);
                                }
                            }
                        }
                    }
                }
            }
        }

        Err(SkillError::NotFound(name.to_string()))
    }

    /// Load multiple skills by name.
    pub fn load_skills(&mut self, names: &[&str]) -> Vec<Result<Skill>> {
        names.iter().map(|n| self.load_skill(n)).collect()
    }

    /// Get the currently loaded skill set.
    pub fn loaded(&self) -> &SkillSet {
        &self.loaded
    }

    /// Build combined system prompt from all loaded skills.
    pub fn build_prompt(&self) -> String {
        self.loaded.build_prompt()
    }

    /// List all available skills (builtins + discovered).
    pub fn list_available(&self) -> Vec<Skill> {
        let mut all = self.builtins.clone();

        for dir in &self.skill_dirs {
            if dir.exists() {
                if let Ok(entries) = fs::read_dir(dir) {
                    for entry in entries.flatten() {
                        let path = entry.path();
                        if path.extension().and_then(|e| e.to_str()) == Some("yaml")
                            || path.extension().and_then(|e| e.to_str()) == Some("yml")
                        {
                            if let Ok(skill) = load_skill_from_file(&path) {
                                if !all.iter().any(|s| s.name == skill.name) {
                                    all.push(skill);
                                }
                            }
                        }
                    }
                }
            }
        }

        all
    }
}

impl Default for SkillsManager {
    fn default() -> Self {
        Self::new()
    }
}

/// Load a skill definition from a YAML file.
pub fn load_skill_from_file(path: &Path) -> Result<Skill> {
    let content = fs::read_to_string(path)?;
    parse_skill_yaml(&content, path)
}

/// Parse skill from YAML content.
/// Handles YAML frontmatter (between `---` markers) or raw YAML.
pub fn parse_skill_yaml(content: &str, source: &Path) -> Result<Skill> {
    let yaml_content = if content.starts_with("---") {
        // Extract frontmatter
        let end = content[3..]
            .find("---")
            .map(|i| i + 3)
            .unwrap_or(content.len());
        &content[3..end]
    } else {
        content
    };

    serde_yaml::from_str::<Skill>(yaml_content)
        .map_err(|e| SkillError::Parse(format!("Failed to parse skill from {:?}: {}", source, e)))
}

/// Install a skill from a path.
pub fn install_skill(source: &Path, target_dir: &Path) -> Result<PathBuf> {
    fs::create_dir_all(target_dir)?;

    let skill = load_skill_from_file(source)?;
    let target_path = target_dir.join(format!("{}.skill.yaml", skill.name));

    // Copy the file
    fs::copy(source, &target_path)?;

    Ok(target_path)
}

pub use serde_yaml;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_builtin_skills() {
        let skills = builtin_skills();
        assert!(skills.iter().any(|s| s.name == "rust"));
        assert!(skills.iter().any(|s| s.name == "security"));
    }

    #[test]
    fn test_skill_set() {
        let mut set = SkillSet::new();
        let skill = Skill {
            name: "test-skill".to_string(),
            description: "A test".to_string(),
            version: "1.0.0".to_string(),
            prompt: "You are a test.".to_string(),
            preferred_provider: None,
            preferred_model: None,
            tags: vec![],
            metadata: HashMap::new(),
        };
        set.add(skill);
        assert!(set.get("test-skill").is_some());
        assert!(set.build_prompt().contains("test-skill"));
    }

    #[test]
    fn test_skills_manager() {
        let mut mgr = SkillsManager::new();
        let result = mgr.load_skill("rust");
        assert!(result.is_ok());
        assert_eq!(result.unwrap().name, "rust");

        let result = mgr.load_skill("nonexistent");
        assert!(result.is_err());
    }
}
