//! CLI Bootstrap — thin wrapper over bkg_core::bootstrap.
//!
//! The core bootstrap logic lives in bkg-core/src/bootstrap/.
//! This module provides CLI-specific extensions:
//! - Ollama availability probe
//! - Setup wizard integration (see setup.rs)

pub use bkg_core::bootstrap::*;

/// Run the full bootstrap pipeline and print a summary.
pub async fn run_bootstrap() -> BootstrapReport {
    let mut boot = BkgBootstrap::new();
    let report = boot.run().await;
    report.print_summary();
    report
}

/// Check if the report indicates that first-time setup is needed.
pub fn requires_setup(report: &BootstrapReport) -> bool {
    report.needs_setup
        || report
            .phases
            .iter()
            .any(|p| matches!(&p.status, PhaseStatus::Failed { .. }))
}

/// Probe whether Ollama is running (simple TCP port check).
pub async fn probe_ollama() -> bool {
    tokio::net::TcpStream::connect("127.0.0.1:11434")
        .await
        .is_ok()
}

/// Quick check: is the system already configured?
pub fn is_initialized() -> bool {
    let config_path = dirs::home_dir()
        .unwrap_or_else(|| std::path::PathBuf::from("."))
        .join(".bkg")
        .join("config.toml");
    config_path.exists()
}

#[cfg(test)]
mod tests {
    use super::*;
    use bkg_core::bootstrap::{BootstrapPhase, PhaseResult, PhaseStatus};
    use std::time::Duration;

    #[test]
    fn test_requires_setup_with_failed_phase() {
        let mut report = BootstrapReport::new();
        report.phases.push(PhaseResult::new(
            BootstrapPhase::ProviderDetection,
            PhaseStatus::Failed {
                errors: vec!["no provider".into()],
            },
            Duration::ZERO,
        ));
        assert!(requires_setup(&report));
    }

    #[test]
    fn test_requires_setup_healthy() {
        let mut report = BootstrapReport::new();
        report.phases.push(PhaseResult::new(
            BootstrapPhase::ConfigLoad,
            PhaseStatus::Passed,
            Duration::ZERO,
        ));
        assert!(!requires_setup(&report));
    }
}
