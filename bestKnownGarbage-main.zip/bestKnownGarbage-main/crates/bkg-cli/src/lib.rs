//! BKG CLI — AI coding assistant with tool-using agent loop.
//!
//! This crate provides the CLI binary and agent runtime for interacting
//! with LLM providers (OpenAI, Anthropic, NVIDIA NIM, Ollama, etc.).

pub mod agent;
pub mod bootstrap;
pub mod budget;
pub mod capsule;
pub mod chain;
pub mod managed;
pub mod memory;
pub mod model_router;
pub mod router;
pub mod session;
pub mod setup;
pub mod skills;
pub mod snapshot;
pub mod tui;
pub mod verify;
pub mod work;

/// Re-export CLI-specific public API.
pub use agent::Coordinator;

/// Budget system via bkg-budget.
pub use bkg_budget as budget_sys;
/// Core types via bkg-core.
pub use bkg_core as core;
/// Event system via bkg-events.
pub use bkg_events as events;
/// Kernel types via bkg-kernel.
pub use bkg_kernel as kernel;
/// Memory system via bkg-memory.
pub use bkg_memory as memory_sys;
/// Provider integration via bkg-provider.
pub use bkg_provider as provider;
/// Session system via bkg-session.
pub use bkg_session as session_sys;
/// Skills system via bkg-skills.
pub use bkg_skills as skills_sys;
/// SWD system via bkg-swd.
pub use bkg_swd as swd;
/// Tool system via bkg-tools.
pub use bkg_tools as tools;
/// Verify system via bkg-verify.
pub use bkg_verify as verify_sys;

/// Error type alias.
pub type BkgError = bkg_core::BkgError;

/// Result type alias.
pub type Result<T> = std::result::Result<T, BkgError>;

/// Convenience types used by the agent.
pub use bkg_core::config::Config;
pub use bkg_core::message::Message;
pub use bkg_core::session::Session;

/// The application name.
pub const APP_NAME: &str = "bkg";

/// Current version.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
