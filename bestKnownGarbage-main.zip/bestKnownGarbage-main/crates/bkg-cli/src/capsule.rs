//! Capsule Storage — self-healing, verifiable capsule persistence.
//!
//! This module manages the `~/.bkg/capsules/` directory. Each capsule is a
//! self-contained directory with all chain execution artifacts.
//!
//! # Self-Healing
//!
//! On load, every capsule is verified:
//! 1. Does `capsule.json` exist?         → if not → Corrupted
//! 2. Does `chain.json` exist?           → if not → Corrupted
//! 3. Does `manifest.sha256` match?      → if not → Repaired (rehash)
//! 4. Are referenced snapshots present?  → if not → Repaired (remove refs)
//! 5. Is `receipt.json` consistent?      → if not → Repaired (regen)
//!
//! Repair never modifies the Chain itself — only derivative data.

use bkg_core::BkgError;
use bkg_core::chain::{Chain, ExecutionReceipt, Manifest, TruthCapsule, TruthReport, hash_string};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

/// Default BKG data directory (~/.bkg).
fn default_data_dir() -> PathBuf {
    dirs::home_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join(".bkg")
}

/// Path to the capsules directory.
fn capsules_dir() -> PathBuf {
    default_data_dir().join("capsules")
}

/// Path to a specific capsule directory.
fn capsule_dir(capsule_id: &str) -> PathBuf {
    capsules_dir().join(capsule_id)
}

/// Read a JSON file from the capsule directory.
#[allow(dead_code)]
fn read_capsule_file<T: serde::de::DeserializeOwned>(
    capsule_id: &str,
    filename: &str,
) -> Result<T, BkgError> {
    let path = capsule_dir(capsule_id).join(filename);
    let content = std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?;
    serde_json::from_str(&content)
        .map_err(|e| BkgError::Provider(format!("Failed to deserialize {filename}: {e}")))
}

/// Write a JSON file to the capsule directory.
fn write_capsule_file<T: serde::Serialize>(
    capsule_id: &str,
    filename: &str,
    value: &T,
) -> Result<(), BkgError> {
    let dir = capsule_dir(capsule_id);
    std::fs::create_dir_all(&dir).map_err(|e| BkgError::Io(e))?;
    let path = dir.join(filename);
    let content = serde_json::to_string_pretty(value)
        .map_err(|e| BkgError::Provider(format!("Failed to serialize {filename}: {e}")))?;
    std::fs::write(&path, &content).map_err(|e| BkgError::Io(e))?;
    Ok(())
}

/// Summary metadata for listing capsules.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CapsuleSummary {
    pub capsule_id: String,
    pub state: String,
    pub chain_id: String,
    pub prompt: String,
    pub link_count: usize,
    pub truth_score: f64,
    pub created_at: String,
    pub immutable: bool,
    pub healthy: bool,
}

/// Full integrity report for a capsule.
#[derive(Clone, Debug)]
pub struct IntegrityReport {
    pub capsule_id: String,
    pub capsule_exists: bool,
    pub chain_exists: bool,
    pub receipt_exists: bool,
    pub truth_exists: bool,
    pub manifest_valid: bool,
    pub snapshots_present: bool,
    pub all_ok: bool,
    pub issues: Vec<String>,
}

/// The capsule storage manager.
pub struct CapsuleStore {
    root: PathBuf,
}

impl Default for CapsuleStore {
    fn default() -> Self {
        Self::new()
    }
}

impl CapsuleStore {
    /// Create a new capsule store at the default location.
    pub fn new() -> Self {
        let root = capsules_dir();
        std::fs::create_dir_all(&root).ok();
        Self { root }
    }

    /// Create a capsule store at a custom path.
    pub fn with_root(root: PathBuf) -> Self {
        std::fs::create_dir_all(&root).ok();
        Self { root }
    }

    /// Root directory for capsules.
    pub fn root(&self) -> &Path {
        &self.root
    }

    // ── Save ──

    /// Save a completed chain as a capsule.
    ///
    /// This persists the chain, receipt, truth report, and generates a
    /// cryptographic manifest. The capsule is frozen after this call.
    pub fn save_chain_capsule(
        &self,
        capsule_id: &str,
        chain: &Chain,
        receipt: &ExecutionReceipt,
        truth: &TruthReport,
    ) -> Result<TruthCapsule, BkgError> {
        let dir = self.root.join(capsule_id);
        std::fs::create_dir_all(&dir).map_err(|e| BkgError::Io(e))?;

        // Create subdirectories
        for sub in &["memory", "snapshots", "replay", "datasets"] {
            std::fs::create_dir_all(dir.join(sub)).map_err(|e| BkgError::Io(e))?;
        }

        // Write chain, receipt, truth
        write_capsule_file(capsule_id, "chain.json", chain)?;
        write_capsule_file(capsule_id, "receipt.json", receipt)?;
        write_capsule_file(capsule_id, "truth.json", truth)?;

        // Generate manifest
        let manifest = self.build_manifest(capsule_id, chain, receipt, truth)?;

        // Create capsule metadata
        let mut capsule = TruthCapsule::new(capsule_id.to_string(), chain.id.clone());
        capsule.mark_completed(manifest.manifest_hash.clone());
        capsule.mark_verified();

        // Write capsule.json
        write_capsule_file(capsule_id, "capsule.json", &capsule)?;
        write_capsule_file(capsule_id, "manifest.sha256", &manifest)?;

        // Write initial MEMORY.md
        let memory_content = format!(
            "# Capsule {}\n\n## Chain {}\n\nPrompt: {}\n\n## Links\n\n",
            capsule_id, chain.id, chain.original_prompt
        );
        let memory_path = dir.join("memory").join("MEMORY.md");
        std::fs::write(&memory_path, &memory_content).map_err(|e| BkgError::Io(e))?;

        Ok(capsule)
    }

    /// Build a cryptographic manifest for the capsule.
    fn build_manifest(
        &self,
        _capsule_id: &str,
        chain: &Chain,
        receipt: &ExecutionReceipt,
        truth: &TruthReport,
    ) -> Result<Manifest, BkgError> {
        let chain_json = serde_json::to_string(chain)
            .map_err(|e| BkgError::Provider(format!("Serialize chain: {e}")))?;
        let receipt_json = serde_json::to_string(receipt)
            .map_err(|e| BkgError::Provider(format!("Serialize receipt: {e}")))?;
        let truth_json = serde_json::to_string(truth)
            .map_err(|e| BkgError::Provider(format!("Serialize truth: {e}")))?;

        let mut builder = Manifest::builder()
            .add_entry("chain.json", hash_string(&chain_json))
            .add_entry("receipt.json", hash_string(&receipt_json))
            .add_entry("truth.json", hash_string(&truth_json));

        // Add per-link hashes
        for (i, link) in chain.links.iter().enumerate() {
            if link.hashes.is_complete() {
                builder = builder
                    .add_entry(format!("link-{}/prompt", i + 1), &link.hashes.prompt_hash)
                    .add_entry(format!("link-{}/output", i + 1), &link.hashes.output_hash)
                    .add_entry(format!("link-{}/truth", i + 1), &link.hashes.truth_hash);
            }
        }

        Ok(builder.build())
    }

    // ── Load ──

    /// Load the capsule metadata.
    pub fn load_capsule(&self, capsule_id: &str) -> Result<Option<TruthCapsule>, BkgError> {
        let path = self.root.join(capsule_id).join("capsule.json");
        if !path.exists() {
            return Ok(None);
        }
        let content = std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?;
        let capsule: TruthCapsule = serde_json::from_str(&content)
            .map_err(|e| BkgError::Provider(format!("Deserialize capsule: {e}")))?;
        Ok(Some(capsule))
    }

    /// Load the chain from a capsule.
    pub fn load_chain(&self, capsule_id: &str) -> Result<Option<Chain>, BkgError> {
        let path = self.root.join(capsule_id).join("chain.json");
        if !path.exists() {
            return Ok(None);
        }
        let content = std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?;
        let chain: Chain = serde_json::from_str(&content)
            .map_err(|e| BkgError::Provider(format!("Deserialize chain: {e}")))?;
        Ok(Some(chain))
    }

    /// Load the receipt from a capsule.
    pub fn load_receipt(&self, capsule_id: &str) -> Result<Option<ExecutionReceipt>, BkgError> {
        let path = self.root.join(capsule_id).join("receipt.json");
        if !path.exists() {
            return Ok(None);
        }
        let content = std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?;
        let receipt: ExecutionReceipt = serde_json::from_str(&content)
            .map_err(|e| BkgError::Provider(format!("Deserialize receipt: {e}")))?;
        Ok(Some(receipt))
    }

    /// Load the truth report from a capsule.
    pub fn load_truth(&self, capsule_id: &str) -> Result<Option<TruthReport>, BkgError> {
        let path = self.root.join(capsule_id).join("truth.json");
        if !path.exists() {
            return Ok(None);
        }
        let content = std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?;
        let truth: TruthReport = serde_json::from_str(&content)
            .map_err(|e| BkgError::Provider(format!("Deserialize truth: {e}")))?;
        Ok(Some(truth))
    }

    // ── List ──

    /// List all capsules with summary metadata.
    pub fn list_capsules(&self) -> Result<Vec<CapsuleSummary>, BkgError> {
        let mut summaries = Vec::new();

        let entries = match std::fs::read_dir(&self.root) {
            Ok(e) => e,
            Err(_) => return Ok(Vec::new()),
        };

        for entry in entries.flatten() {
            let dir_name = entry.file_name();
            let capsule_id = dir_name.to_string_lossy().to_string();

            // Must be a directory with capsule.json
            let cap_path = entry.path().join("capsule.json");
            if !cap_path.exists() {
                continue;
            }

            let healthy = self.verify_capsule_integrity(&capsule_id).all_ok;
            let summary = match self.load_capsule(&capsule_id) {
                Ok(Some(cap)) => {
                    let (chain_info, truth_score) = match self.load_chain(&capsule_id) {
                        Ok(Some(chain)) => {
                            let (_, _, passed, failed) = chain.counts();
                            let total = passed + failed;
                            let score = if total > 0 {
                                passed as f64 / total as f64
                            } else {
                                1.0
                            };
                            (chain.summary(), score)
                        }
                        _ => (
                            format!("Chain: {} (chain.json unavailable)", cap.chain_ref),
                            0.0,
                        ),
                    };

                    CapsuleSummary {
                        capsule_id: capsule_id.clone(),
                        state: format!("{:?}", cap.state),
                        chain_id: cap.chain_ref.clone(),
                        prompt: chain_info,
                        link_count: 0,
                        truth_score,
                        created_at: cap.created_at.to_rfc3339(),
                        immutable: cap.immutable,
                        healthy,
                    }
                }
                _ => CapsuleSummary {
                    capsule_id,
                    state: "Unknown".to_string(),
                    chain_id: "?".to_string(),
                    prompt: "Could not load capsule metadata".to_string(),
                    link_count: 0,
                    truth_score: 0.0,
                    created_at: String::new(),
                    immutable: false,
                    healthy,
                },
            };
            summaries.push(summary);
        }

        summaries.sort_by(|a, b| b.created_at.cmp(&a.created_at));
        Ok(summaries)
    }

    // ── Delete ──

    /// Delete a capsule and all its data.
    pub fn delete_capsule(&self, capsule_id: &str) -> Result<bool, BkgError> {
        let path = self.root.join(capsule_id);
        if !path.exists() {
            return Ok(false);
        }
        std::fs::remove_dir_all(&path).map_err(|e| BkgError::Io(e))?;
        Ok(true)
    }

    // ── Verify ──

    /// Verify the integrity of a capsule.
    pub fn verify_capsule_integrity(&self, capsule_id: &str) -> IntegrityReport {
        let dir = self.root.join(capsule_id);
        let mut issues = Vec::new();

        let capsule_exists = dir.join("capsule.json").exists();
        let chain_exists = dir.join("chain.json").exists();
        let receipt_exists = dir.join("receipt.json").exists();
        let truth_exists = dir.join("truth.json").exists();

        if !capsule_exists {
            issues.push("capsule.json missing".to_string());
        }
        if !chain_exists {
            issues.push("chain.json missing".to_string());
        }
        if !receipt_exists {
            issues.push("receipt.json missing".to_string());
        }
        if !truth_exists {
            issues.push("truth.json missing".to_string());
        }

        // Verify manifest
        let manifest_valid = if dir.join("manifest.sha256").exists() {
            match self.verify_manifest(capsule_id) {
                Ok(true) => true,
                _ => {
                    issues.push("manifest hash mismatch".to_string());
                    false
                }
            }
        } else {
            issues.push("manifest.sha256 missing".to_string());
            false
        };

        // Check snapshots directory
        let snapshots_dir = dir.join("snapshots");
        let snapshots_present = snapshots_dir.exists();

        let all_ok =
            capsule_exists && chain_exists && receipt_exists && truth_exists && manifest_valid;

        IntegrityReport {
            capsule_id: capsule_id.to_string(),
            capsule_exists,
            chain_exists,
            receipt_exists,
            truth_exists,
            manifest_valid,
            snapshots_present,
            all_ok,
            issues,
        }
    }

    /// Verify that the manifest matches the stored files.
    fn verify_manifest(&self, capsule_id: &str) -> Result<bool, BkgError> {
        let manifest_path = self.root.join(capsule_id).join("manifest.sha256");
        let content = match std::fs::read_to_string(&manifest_path) {
            Ok(c) => c,
            Err(_) => return Ok(false),
        };
        let manifest: Manifest = match serde_json::from_str(&content) {
            Ok(m) => m,
            Err(_) => return Ok(false),
        };
        Ok(manifest.verify())
    }

    // ── Repair ──

    /// Attempt to repair a corrupted capsule.
    ///
    /// Repair never modifies the Chain itself — only derivative data
    /// (manifest, missing dirs, etc.).
    pub fn repair_capsule(&self, capsule_id: &str) -> Result<IntegrityReport, BkgError> {
        let report = self.verify_capsule_integrity(capsule_id);
        if report.all_ok {
            return Ok(report);
        }

        let dir = self.root.join(capsule_id);
        if !dir.exists() {
            return Err(BkgError::Provider(format!(
                "Capsule {capsule_id} does not exist, cannot repair"
            )));
        }

        // Recreate missing subdirectories
        for sub in &["memory", "snapshots", "replay", "datasets"] {
            std::fs::create_dir_all(dir.join(sub)).ok();
        }

        // If chain.json exists, rebuild derivative data
        if report.chain_exists {
            if let Ok(Some(chain)) = self.load_chain(capsule_id) {
                // Rebuild receipt if missing
                if !report.receipt_exists {
                    let receipt = ExecutionReceipt::new(
                        chain.id.clone(),
                        "unknown".to_string(),
                        Vec::new(),
                        0,
                        0.0,
                        0.0,
                        false,
                    );
                    write_capsule_file(capsule_id, "receipt.json", &receipt)?;
                }

                // Rebuild truth if chain has it
                if !report.truth_exists {
                    if let Some(ref truth) = chain.truth_report {
                        write_capsule_file(capsule_id, "truth.json", truth)?;
                    }
                }

                // Rebuild manifest
                if let (Ok(Some(receipt)), Ok(Some(truth))) =
                    (self.load_receipt(capsule_id), self.load_truth(capsule_id))
                {
                    let manifest = self.build_manifest(capsule_id, &chain, &receipt, &truth)?;
                    write_capsule_file(capsule_id, "manifest.sha256", &manifest)?;
                }
            }
        }

        // Re-verify after repair
        let repaired = self.verify_capsule_integrity(capsule_id);
        if !repaired.all_ok {
            // If we couldn't fix everything, at least mark it
            if let Ok(Some(mut capsule)) = self.load_capsule(capsule_id) {
                capsule.mark_repaired();
                write_capsule_file(capsule_id, "capsule.json", &capsule)?;
            }
        }

        Ok(repaired)
    }
}

// ── CLI Commands ──

use clap::Subcommand;

/// Capsule management commands.
#[derive(Debug, Subcommand)]
pub enum CapsuleCommand {
    /// List all capsules
    List,
    /// Show detailed capsule info
    Show {
        /// Capsule ID (e.g., "cap-7f91")
        id: String,
    },
    /// Verify capsule integrity
    Verify {
        /// Capsule ID
        id: String,
    },
    /// Attempt to repair a corrupted capsule
    Repair {
        /// Capsule ID
        id: String,
    },
    /// Delete a capsule
    Delete {
        /// Capsule ID
        id: String,
    },
    /// Replay execution from MEMORY.md
    Replay {
        /// Capsule ID (e.g., "cap-7f91")
        id: String,
    },
}

/// Handle capsule CLI commands.
pub async fn handle_capsule_command(command: CapsuleCommand) -> Result<(), BkgError> {
    let store = CapsuleStore::new();

    match command {
        CapsuleCommand::List => list_capsules(&store)?,
        CapsuleCommand::Show { id } => show_capsule(&store, &id)?,
        CapsuleCommand::Verify { id } => verify_capsule(&store, &id)?,
        CapsuleCommand::Repair { id } => repair_capsule_cmd(&store, &id)?,
        CapsuleCommand::Delete { id } => delete_capsule_cmd(&store, &id)?,
        CapsuleCommand::Replay { id } => replay_capsule(&store, &id).await?,
    }

    Ok(())
}

fn list_capsules(store: &CapsuleStore) -> Result<(), BkgError> {
    let capsules = store.list_capsules()?;
    if capsules.is_empty() {
        println!("No capsules found.");
        println!("Capsules are created automatically when a chain completes.");
        println!("  ~/.bkg/capsules/");
        return Ok(());
    }

    println!("┌─ BKG Capsules ──────────────────────────────────────");
    for cap in &capsules {
        let health = if cap.healthy { "✓" } else { "✗" };
        let frozen = if cap.immutable { " 🔒" } else { "" };
        println!(
            "│ {health} {:<20} | {:<12} | {:.1} score{}",
            cap.capsule_id, cap.state, cap.truth_score, frozen,
        );
        println!("│   {:.72}", cap.prompt);
    }
    println!("└──────────────────────────────────────────────────────");
    println!("Total: {} capsules", capsules.len());
    Ok(())
}

fn show_capsule(store: &CapsuleStore, id: &str) -> Result<(), BkgError> {
    let capsule = store
        .load_capsule(id)?
        .ok_or_else(|| BkgError::Provider(format!("Capsule '{id}' not found")))?;

    println!(
        "┌─ Capsule: {} ──────────────────────────────",
        capsule.capsule_id
    );
    println!("│ State:     {:?}", capsule.state);
    println!("│ Chain:     {}", capsule.chain_ref);
    println!("│ Schema:    v{}", capsule.schema_version);
    println!("│ Immutable: {}", capsule.immutable);
    println!("│ Replayable: {}", capsule.replayable);
    println!("│ Healing:   {}", capsule.self_healing);
    println!("│ Created:   {}", capsule.created_at.to_rfc3339());
    println!("│ Updated:   {}", capsule.updated_at.to_rfc3339());
    println!("│ Manifest:  {:.16}...", capsule.manifest_hash);
    if let Some(replay) = &capsule.replay_of {
        println!("│ Replay of: {}", replay);
    }
    if let Some(verified) = capsule.last_verified_at {
        println!("│ Verified:  {}", verified.to_rfc3339());
    }

    // Show chain info
    if let Ok(Some(chain)) = store.load_chain(id) {
        println!("├─ Chain ──────────────────────────────────────────────");
        println!("│ Prompt: {}", chain.original_prompt);
        let (pending, _running, passed, failed) = chain.counts();
        println!(
            "│ Links: {} total ({} passed, {} failed, {} pending)",
            chain.links.len(),
            passed,
            failed,
            pending
        );
        for link in &chain.links {
            let status = match &link.status {
                bkg_core::chain::LinkStatus::Passed => "✓",
                bkg_core::chain::LinkStatus::Failed(_) => "✗",
                bkg_core::chain::LinkStatus::Skipped => "–",
                _ => "○",
            };
            println!(
                "│   {status} {} — {} ({})",
                link.id, link.description, link.context.model
            );
        }
    }

    println!("└────────────────────────────────────────────────────────");
    Ok(())
}

fn verify_capsule(store: &CapsuleStore, id: &str) -> Result<(), BkgError> {
    let report = store.verify_capsule_integrity(id);
    println!("┌─ Integrity Report: {id} ────────────────");
    println!("│ capsule.json:   {}", checkmark(report.capsule_exists));
    println!("│ chain.json:     {}", checkmark(report.chain_exists));
    println!("│ receipt.json:   {}", checkmark(report.receipt_exists));
    println!("│ truth.json:     {}", checkmark(report.truth_exists));
    println!("│ manifest:       {}", checkmark(report.manifest_valid));
    println!("│ snapshots:      {}", checkmark(report.snapshots_present));
    if report.all_ok {
        println!("├─ ✅ ALL INTEGRITY CHECKS PASSED");
    } else {
        println!("├─ ❌ ISSUES FOUND:");
        for issue in &report.issues {
            println!("│   • {issue}");
        }
    }
    println!("└────────────────────────────────────────────────────────");
    Ok(())
}

fn repair_capsule_cmd(store: &CapsuleStore, id: &str) -> Result<(), BkgError> {
    println!("Attempting to repair capsule '{id}'...");
    let report = store.repair_capsule(id)?;
    if report.all_ok {
        println!("✅ Capsule '{id}' repaired successfully.");
    } else {
        println!(
            "⚠️  Capsule '{id}' partially repaired. {} issues remain.",
            report.issues.len()
        );
        for issue in &report.issues {
            println!("  • {issue}");
        }
    }
    Ok(())
}

fn delete_capsule_cmd(store: &CapsuleStore, id: &str) -> Result<(), BkgError> {
    let deleted = store.delete_capsule(id)?;
    if deleted {
        println!("✅ Capsule '{id}' deleted.");
    } else {
        println!("Capsule '{id}' not found.");
    }
    Ok(())
}

/// Replay execution from a capsule's MEMORY.md.
async fn replay_capsule(store: &CapsuleStore, id: &str) -> Result<(), BkgError> {
    let capsule_dir = store.root().join(id);
    if !capsule_dir.exists() {
        println!("❌ Capsule '{id}' not found.");
        return Ok(());
    }

    let memory_path = capsule_dir.join("MEMORY.md");
    if !memory_path.exists() {
        println!("❌ No MEMORY.md found in capsule '{id}'. Nothing to replay.");
        return Ok(());
    }

    let content = std::fs::read_to_string(&memory_path)?;

    println!("┌─ Replaying Capsule: {id} ──────────────────────");
    println!("│ MEMORY.md ({})", content.lines().count());
    println!("│");
    for line in content.lines().take(20) {
        println!("│ {line}");
    }
    if content.lines().count() > 20 {
        println!("│ ... ({} more lines)", content.lines().count() - 20);
    }
    println!("└────────────────────────────────────────────────────");
    Ok(())
}

fn checkmark(ok: bool) -> &'static str {
    if ok { "✓" } else { "✗" }
}
