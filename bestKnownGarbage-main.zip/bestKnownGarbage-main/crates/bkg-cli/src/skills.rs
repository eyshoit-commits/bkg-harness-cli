use crate::Result;
use bkg_skills::SkillsManager;
use clap::{Args, Subcommand};
use std::path::PathBuf;

/// Skills management commands
#[derive(Debug, Subcommand)]
pub enum SkillsCommand {
    /// List available skills
    List(ListArgs),
    /// Load a skill by name
    Load(LoadArgs),
    /// Install a skill from a file or directory
    Install(InstallArgs),
    /// Show skill details
    Show(ShowArgs),
    /// Build prompt from loaded skills
    Prompt,
}

#[derive(Debug, Args)]
pub struct ListArgs {
    /// Show only loaded skills
    #[arg(long)]
    loaded: bool,
}

#[derive(Debug, Args)]
pub struct LoadArgs {
    /// Name of the skill to load
    name: String,
}

#[derive(Debug, Args)]
pub struct InstallArgs {
    /// Path to skill file or directory
    path: PathBuf,
    /// Target directory (default: skills/)
    #[arg(long, default_value = "skills")]
    target: PathBuf,
}

#[derive(Debug, Args)]
pub struct ShowArgs {
    /// Name of the skill to show
    name: String,
}

pub async fn handle_skills(command: SkillsCommand) -> Result<()> {
    match command {
        SkillsCommand::List(args) => list_skills(args).await?,
        SkillsCommand::Load(args) => load_skill(args).await?,
        SkillsCommand::Install(args) => install_skill(args).await?,
        SkillsCommand::Show(args) => show_skill(args).await?,
        SkillsCommand::Prompt => show_prompt().await?,
    }
    Ok(())
}

async fn list_skills(args: ListArgs) -> Result<()> {
    let manager = SkillsManager::new();

    if args.loaded {
        let skills = manager.loaded();
        if skills.skills.is_empty() {
            println!("No skills loaded");
        } else {
            println!("Loaded skills:");
            for skill in skills.skills.iter() {
                println!("  - {}", skill.name);
            }
        }
    } else {
        let available = manager.list_available();
        if available.is_empty() {
            println!("No skills available");
        } else {
            println!("Available skills:");
            for skill in available.iter() {
                println!("  - {}", skill.name);
            }
        }
    }

    Ok(())
}

async fn load_skill(args: LoadArgs) -> Result<()> {
    let mut manager = SkillsManager::new();
    match manager.load_skill(&args.name) {
        Ok(skill) => {
            println!("Loaded skill: {}", skill.name);
            if !skill.description.is_empty() {
                println!("Description: {}", skill.description);
            }
        }
        Err(e) => {
            eprintln!("Failed to load skill '{}': {}", args.name, e);
            std::process::exit(1);
        }
    }
    Ok(())
}

async fn install_skill(args: InstallArgs) -> Result<()> {
    // Ensure target directory exists
    if !args.target.exists() {
        std::fs::create_dir_all(&args.target)?;
        println!("Created skills directory: {}", args.target.display());
    }

    match bkg_skills::install_skill(&args.path, &args.target) {
        Ok(installed_path) => {
            println!("Installed skill to: {}", installed_path.display());
        }
        Err(e) => {
            eprintln!("Failed to install skill: {}", e);
            std::process::exit(1);
        }
    }

    Ok(())
}

async fn show_skill(args: ShowArgs) -> Result<()> {
    let mut manager = SkillsManager::new();
    match manager.load_skill(&args.name) {
        Ok(skill) => {
            println!("Skill: {}", skill.name);
            if !skill.description.is_empty() {
                println!("\nDescription:\n{}", skill.description);
            }
            if !skill.prompt.is_empty() {
                println!("\nPrompt:\n{}", skill.prompt);
            }
            if let Some(provider) = &skill.preferred_provider {
                println!("\nPreferred provider: {}", provider);
            }
            if !skill.tags.is_empty() {
                println!("\nTags: {}", skill.tags.join(", "));
            }
        }
        Err(e) => {
            eprintln!("Failed to load skill '{}': {}", args.name, e);
            std::process::exit(1);
        }
    }
    Ok(())
}

async fn show_prompt() -> Result<()> {
    let manager = SkillsManager::new();
    let prompt = manager.build_prompt();
    if prompt.is_empty() {
        println!("No skills loaded");
    } else {
        println!("{}", prompt);
    }
    Ok(())
}

/// Load skills for a chain link (stage 3/9).
/// Returns the skills context string to inject into the system prompt.
pub async fn load_skills_for_chain(skill_names: &[String]) -> String {
    if skill_names.is_empty() {
        return String::new();
    }
    let mut mgr = SkillsManager::new();
    let names: Vec<&str> = skill_names.iter().map(|s| s.as_str()).collect();
    let results = mgr.load_skills(&names);
    let loaded = results.iter().filter(|r| r.is_ok()).count();
    if loaded > 0 {
        mgr.build_prompt()
    } else {
        String::new()
    }
}
