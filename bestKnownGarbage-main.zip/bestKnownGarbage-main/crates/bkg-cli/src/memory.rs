use crate::Result;
use bkg_memory::MemoryManager;
use clap::{Args, Subcommand};

/// Memory management commands
#[derive(Debug, Subcommand)]
pub enum MemoryCommand {
    /// Read the current MEMORY.md
    Read,
    /// Search memory for a query
    Search(SearchArgs),
    /// Append an entry to memory
    Append(AppendArgs),
    /// Show memory statistics
    Status,
    /// Initialize memory if not present
    Init,
}

#[derive(Debug, Args)]
pub struct SearchArgs {
    /// Search query
    query: String,
}

#[derive(Debug, Args)]
pub struct AppendArgs {
    /// Action description
    action: String,
    /// Result of the action
    result: String,
}

pub async fn handle_memory(command: MemoryCommand) -> Result<()> {
    let working_dir = std::env::current_dir()?;
    let mut manager = MemoryManager::new(working_dir);

    match command {
        MemoryCommand::Read => read_memory(&manager).await?,
        MemoryCommand::Search(args) => search_memory(&manager, args).await?,
        MemoryCommand::Append(args) => append_to_memory(&mut manager, args).await?,
        MemoryCommand::Status => show_status(&manager).await?,
        MemoryCommand::Init => init_memory(&mut manager).await?,
    }

    Ok(())
}

async fn read_memory(manager: &MemoryManager) -> Result<()> {
    let content = manager.read_memory();
    if content.raw.trim().is_empty() {
        println!("MEMORY.md is empty");
    } else {
        print!("{}", content.raw);
    }
    Ok(())
}

async fn search_memory(manager: &MemoryManager, args: SearchArgs) -> Result<()> {
    let results = manager.search(&args.query);
    if results.is_empty() {
        println!("No matches found for: {}", args.query);
    } else {
        println!("Found {} matches for: {}", results.len(), args.query);
        println!();
        for (i, entry) in results.iter().enumerate() {
            println!(
                "{}. [{}] {} -> {}",
                i + 1,
                entry.timestamp,
                entry.action,
                entry.result
            );
            println!();
        }
    }
    Ok(())
}

async fn append_to_memory(manager: &mut MemoryManager, args: AppendArgs) -> Result<()> {
    manager
        .append_entry(&args.action, &args.result)
        .map_err(|e| crate::BkgError::Provider(format!("Memory error: {e}")))?;
    println!("Appended to memory");
    println!("  Action: {}", args.action);
    println!("  Result: {}", args.result);
    Ok(())
}

async fn show_status(manager: &MemoryManager) -> Result<()> {
    let content = manager.read_memory();
    let entry_count = manager.entry_count();
    let needs_dream = manager.needs_dream();
    let context = manager.get_context(200);

    println!("Memory Status:");
    println!("  Entries: {}", entry_count);
    println!("  Raw size: {} bytes", content.raw.len());
    println!("  Needs compression: {}", needs_dream);
    println!();
    println!("Recent context:");
    println!("{}", context);
    Ok(())
}

/// Store a chain link result in memory (stage 8/9).
pub async fn store_link_result(
    chain_id: &str,
    link_id: &str,
    description: &str,
    output: &str,
    files_changed: &[String],
) -> Result<()> {
    let working_dir = std::env::current_dir()
        .map_err(|e| crate::BkgError::Provider(format!("Failed to get working dir: {e}")))?;
    let mut manager = MemoryManager::new(working_dir);

    let action = format!("chain:{chain_id}/{link_id} — {description}");
    let files = if files_changed.is_empty() {
        "no files changed".to_string()
    } else {
        format!("files: {}", files_changed.join(", "))
    };
    let result = format!("{output}\n\n{files}");

    manager
        .append_entry(&action, &result)
        .map_err(|e| crate::BkgError::Provider(format!("Memory store error: {e}")))?;

    Ok(())
}

async fn init_memory(manager: &mut MemoryManager) -> Result<()> {
    manager
        .init()
        .map_err(|e| crate::BkgError::Provider(format!("Memory init error: {e}")))?;
    println!("Memory initialized");
    println!("  Created: MEMORY.md");
    println!("  Created: memory.db (FTS5 index)");
    Ok(())
}
