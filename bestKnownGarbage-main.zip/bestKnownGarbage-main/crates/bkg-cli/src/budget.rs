use crate::{BkgError, Result};
use bkg_budget::{BudgetConfig, MetricsRecord, MetricsStore};
use clap::{Args, Subcommand};
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

/// Budget tracking commands
#[derive(Debug, Subcommand)]
pub enum BudgetCommand {
    /// Show current budget status
    Status,
    /// Show budget history
    History(HistoryArgs),
    /// Record token usage manually
    Record(RecordArgs),
    /// Reset budget counters
    Reset,
    /// Export budget data
    Export(ExportArgs),
}

#[derive(Debug, Args)]
pub struct HistoryArgs {
    /// Number of days to look back (default: 30)
    #[arg(long, default_value_t = 30i64)]
    days: i64,
    /// Filter by project name
    #[arg(long)]
    project: Option<String>,
    /// Filter by command name
    #[arg(long)]
    command: Option<String>,
}

#[derive(Debug, Args)]
pub struct RecordArgs {
    /// Input tokens used
    input_tokens: u64,
    /// Output tokens used
    output_tokens: u64,
    /// Number of turns
    #[arg(long, default_value_t = 1u32)]
    turns: u32,
    /// Estimated cost in USD
    #[arg(long)]
    cost: Option<f64>,
    /// Project name
    #[arg(long)]
    project: Option<String>,
    /// Command name
    #[arg(long)]
    command: Option<String>,
}

#[derive(Debug, Args)]
pub struct ExportArgs {
    /// Output file path
    path: PathBuf,
    /// Number of days to export (default: all)
    #[arg(long)]
    days: Option<i64>,
}

pub async fn handle_budget(command: BudgetCommand) -> Result<()> {
    match command {
        BudgetCommand::Status => show_status().await?,
        BudgetCommand::History(args) => show_history(args).await?,
        BudgetCommand::Record(args) => record_usage(args).await?,
        BudgetCommand::Reset => reset_budget().await?,
        BudgetCommand::Export(args) => export_budget(args).await?,
    }
    Ok(())
}

async fn show_status() -> Result<()> {
    let store = MetricsStore::load(&get_budget_path());
    let (input_tokens, output_tokens) = store.total_tokens();
    let total_cost = store.total_cost();
    let summary = store.summary(None);

    println!("Budget Status:");
    println!("  Input tokens:  {}", input_tokens);
    println!("  Output tokens: {}", output_tokens);
    println!("  Total tokens:  {}", input_tokens + output_tokens);
    println!("  Total cost:    ${:.4}", total_cost);
    println!();
    println!("{}", summary);

    Ok(())
}

fn flatten_records(v: Vec<&MetricsRecord>) -> Vec<MetricsRecord> {
    v.into_iter().cloned().collect()
}

async fn show_history(args: HistoryArgs) -> Result<()> {
    let store = MetricsStore::load(&get_budget_path());
    let records = flatten_records(store.recent(args.days));

    // Apply filters
    let mut filtered = records;
    if let Some(project) = &args.project {
        filtered.retain(|r| r.project == *project);
    }
    if let Some(command) = &args.command {
        filtered.retain(|r| r.command == *command);
    }

    if filtered.is_empty() {
        println!("No budget records found");
    } else {
        println!("Budget History (last {} days):", args.days);
        for record in filtered.iter() {
            println!(
                "  {} | {:>6}+{:<6} tokens | ${:<8.4} | {}",
                record.timestamp,
                record.input_tokens,
                record.output_tokens,
                record.cost,
                record.command
            );
        }

        let total_in: u64 = filtered.iter().map(|r| r.input_tokens).sum();
        let total_out: u64 = filtered.iter().map(|r| r.output_tokens).sum();
        let total_cost: f64 = filtered.iter().map(|r| r.cost).sum();
        println!(
            "\nTotals: {} in + {} out = {} tokens, ${:.4}",
            total_in,
            total_out,
            total_in + total_out,
            total_cost
        );
    }

    Ok(())
}

async fn record_usage(args: RecordArgs) -> Result<()> {
    let mut store = MetricsStore::load(&get_budget_path());

    let record = MetricsRecord {
        timestamp: chrono_now(),
        command: args.command.unwrap_or_else(|| "manual".to_string()),
        project: args.project.unwrap_or_else(|| "default".to_string()),
        input_tokens: args.input_tokens,
        output_tokens: args.output_tokens,
        turns: args.turns,
        cost: args.cost.unwrap_or(0.0),
    };

    store.record(record);
    store.save(&get_budget_path());

    println!(
        "Recorded {} input + {} output tokens",
        args.input_tokens, args.output_tokens
    );
    if let Some(cost) = args.cost {
        println!("Cost: ${:.4}", cost);
    }

    Ok(())
}

async fn reset_budget() -> Result<()> {
    let store = MetricsStore::new();
    store.save(&get_budget_path());
    println!("Budget reset");
    Ok(())
}

async fn export_budget(args: ExportArgs) -> Result<()> {
    let store = MetricsStore::load(&get_budget_path());
    let records = flatten_records(store.recent(args.days.unwrap_or(i64::MAX)));

    let json = serde_json::to_string_pretty(&records)?;
    std::fs::write(&args.path, json)?;

    println!(
        "Exported {} records to {}",
        records.len(),
        args.path.display()
    );
    Ok(())
}

fn chrono_now() -> String {
    // Simple ISO timestamp
    use std::time::{SystemTime, UNIX_EPOCH};
    let dur = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    let secs = dur.as_secs();
    let days = secs / 86400;
    let time_secs = secs % 86400;
    let hours = time_secs / 3600;
    let minutes = (time_secs % 3600) / 60;
    let seconds = time_secs % 60;
    format!(
        "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
        1970 + (days / 365),
        (days % 365) / 30 + 1,
        (days % 30) + 1,
        hours,
        minutes,
        seconds
    )
}

fn get_budget_path() -> PathBuf {
    let config_dir = dirs::config_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("bkg");
    // Ensure directory exists
    std::fs::create_dir_all(&config_dir).ok();
    config_dir.join("budget.json")
}

/// Allocate budget for a chain link (stage 2/9).
/// Returns Ok if allocation succeeded, Err if budget is exhausted.
pub async fn allocate_budget(session_id: &str, tokens: u64) -> Result<()> {
    // Check if we'd exceed the budget
    let config = BudgetConfig::default();
    let store = MetricsStore::new();
    let (total_in, total_out) = store.total_tokens();
    let total_used = total_in + total_out;

    if config.enabled && total_used + tokens > config.max_tokens {
        return Err(BkgError::Provider(format!(
            "Budget insufficient for {session_id}: {} used + {tokens} requested > {} limit",
            total_used, config.max_tokens
        )));
    }

    // Record the allocation
    let now_secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    let mut store = MetricsStore::load(&get_budget_path());
    let record = MetricsRecord {
        timestamp: format!("{}", now_secs),
        command: "chain-alloc".to_string(),
        project: session_id.to_string(),
        input_tokens: tokens / 2,
        output_tokens: tokens / 2,
        turns: 1,
        cost: (tokens as f64) * 0.000_005,
    };
    store.record(record);
    store.save(&get_budget_path());
    Ok(())
}
