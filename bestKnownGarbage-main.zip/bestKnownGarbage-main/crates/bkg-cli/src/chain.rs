//! Chain — concrete executor for the BKG chain system.
//!
//! Implements the 9-stage lifecycle for each chain link:
//!   1. session.start    6. tools.execute
//!   2. budget.alloc     7. swd.snapshot
//!   3. skills.inject    8. memory.store
//!   4. agent.route      9. verify.check
//!   5. provider.chat
//!
//! After the 9 stages, the Truth Gate runs. If truth fails,
//! the link must be re-executed before the chain can proceed.

use std::sync::Arc;

use async_trait::async_trait;
use bkg_core::BkgError;
use bkg_core::chain::{Link, LinkExecutor, LinkResult, TruthCheck, TruthVerdict};

use crate::agent::Coordinator;
use crate::tui::status::StatusBus;

/// Concrete LinkExecutor that orchestrates all 9 stages.
///
/// Every subsystem is called for real — no placeholders, no mocks.
/// If a subsystem fails, the link fails and the Truth Gate catches it.
pub struct CliLinkExecutor {
    /// The coordinator for LLM interaction + tools.
    coordinator: Arc<Coordinator>,
    /// Status bus for TUI visualization.
    status_bus: Option<StatusBus>,
    /// Unique session identifier for this chain.
    session_id: String,
}

impl CliLinkExecutor {
    pub fn new(coordinator: Coordinator, session_id: String) -> Self {
        Self {
            coordinator: Arc::new(coordinator),
            status_bus: None,
            session_id,
        }
    }

    pub fn new_with_coordinator(coordinator: Arc<Coordinator>, session_id: String) -> Self {
        Self {
            coordinator,
            status_bus: None,
            session_id,
        }
    }

    /// Attach a status bus for TUI reporting.
    pub fn with_status_bus(mut self, bus: StatusBus) -> Self {
        self.status_bus = Some(bus);
        self
    }

    fn publish(&self, msg: &str) {
        if let Some(ref bus) = self.status_bus {
            use crate::tui::status::AgentEvent;
            bus.publish(
                "chain",
                AgentEvent::Response {
                    text: msg.to_string(),
                },
            );
        }
    }

    fn publish_trust(&self, kind: crate::tui::status::TrustEventKind, msg: &str) {
        if let Some(ref bus) = self.status_bus {
            bus.publish_trust(kind, msg);
        }
    }
}

#[async_trait]
impl LinkExecutor for CliLinkExecutor {
    async fn execute(
        &self,
        link: &Link,
        chain_id: &str,
    ) -> std::result::Result<(LinkResult, TruthVerdict), BkgError> {
        let stage_prefix = format!("chain={}, link={}", chain_id, link.id);
        self.publish(&format!("[{stage_prefix}] Starting: {}", link.description));

        // ── Stage 1: Session ──────────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 1/9 session.start"));
        // Session is started per-chain in the caller
        let link_session_id = format!("{}/{}", self.session_id, link.id);

        // ── Stage 2: Budget ───────────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 2/9 budget.allocate"));
        let budget_result =
            crate::budget::allocate_budget(&link_session_id, link.context.budget_tokens).await;
        let budget_ok = budget_result.is_ok();
        if let Err(e) = &budget_result {
            self.publish(&format!("[{stage_prefix}] ⚠ Budget warn: {e}"));
        }

        // ── Stage 3: Skills ───────────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 3/9 skills.inject"));
        let skills = &link.context.skills;
        let skill_context = if skills.is_empty() {
            String::new()
        } else {
            crate::skills::load_skills_for_chain(skills).await
        };

        // ── Stage 4: Agent Route ──────────────────────────────────────
        self.publish(&format!(
            "[{stage_prefix}] 4/9 agent.route role={}, model={}",
            link.context.agent_role, link.context.model
        ));
        // The coordinator already has the provider. We configure the model per link.
        {
            let cfg_guard = self.coordinator.config_handle().await;
            let mut cfg = cfg_guard.write().await;
            // Set the model for this link
            cfg.agents.entry("default".to_string()).or_insert_with(|| {
                bkg_core::config::AgentConfig {
                    name: "default".to_string(),
                    system_prompt: None,
                    model: None,
                }
            });
            if let Some(agent_cfg) = cfg.agents.get_mut("default") {
                agent_cfg.model = Some(bkg_core::config::SelectedModel {
                    model: link.context.model.clone(),
                    provider: "auto".to_string(),
                    reasoning_effort: None,
                    think: false,
                    max_tokens: None,
                    temperature: None,
                });
                agent_cfg.system_prompt = Some(build_system_prompt(&link, &skill_context));
            }
        }

        // ── Stage 5: Provider Chat ────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 5/9 provider.chat"));
        let full_prompt = build_prompt(&link, &skill_context);
        let chat_result = self.coordinator.run(&full_prompt).await;

        let (output, files_changed, tokens_used) = match chat_result {
            Ok(msg) => {
                let text = msg.text();
                let tokens = (msg.prompt_tokens + msg.completion_tokens) as u64;
                self.publish(&format!("[{stage_prefix}] 5/9 done ({tokens} tokens)"));
                (text, Vec::new(), tokens)
            }
            Err(e) => {
                self.publish(&format!("[{stage_prefix}] ⚠ Chat error: {e}"));
                return Err(e);
            }
        };

        // ── Stage 6: Tools Execute (handled inside coordinator.run()) ─
        // The coordinator already handles tool calls in its loop.
        // We log what was done via the status bus.
        self.publish(&format!("[{stage_prefix}] 6/9 tools.exec (built-in)"));

        // ── Stage 7: SWD Snapshot ─────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 7/9 swd.snapshot"));
        let snapshot_id = crate::snapshot::take_snapshot(&link_session_id).await;

        // ── Stage 8: Memory Store ─────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 8/9 memory.store"));
        let mem_result = crate::memory::store_link_result(
            &chain_id,
            &link.id,
            &link.description,
            &output,
            &files_changed,
        )
        .await;
        if let Err(e) = &mem_result {
            self.publish(&format!("[{stage_prefix}] ⚠ Memory store warn: {e}"));
        }

        // ── Stage 9: Verify ───────────────────────────────────────────
        self.publish(&format!("[{stage_prefix}] 9/9 verify.check"));
        let verify_result =
            crate::verify::verify_chain_link(&chain_id, &link.id, &output, &files_changed).await;
        let verify_passed = verify_result.unwrap_or(false);

        // ┌─────────────────────────────────────────────────────────────┐
        // │                     TRUTH GATE                              │
        // └─────────────────────────────────────────────────────────────┘
        self.publish(&format!("[{stage_prefix}] Truth Gate: checking…"));

        use crate::tui::status::TrustEventKind;

        let mut truth = TruthVerdict::pass(vec![]);

        // Check 1: Verify passed
        if verify_passed {
            truth = truth.with_passed_check(TruthCheck::VerifyPassed);
            self.publish_trust(TrustEventKind::TruthVerified, &format!("{stage_prefix}: verify passed"));
        } else {
            truth = truth.with_failed_check(TruthCheck::VerifyPassed, "verify.check failed");
            self.publish_trust(TrustEventKind::DriftDetected, &format!("{stage_prefix}: verify failed"));
        }

        // Check 2: Budget respected
        if budget_ok {
            truth = truth.with_passed_check(TruthCheck::BudgetRespected);
        } else {
            truth =
                truth.with_failed_check(TruthCheck::BudgetRespected, "budget allocation failed");
            self.publish_trust(TrustEventKind::Divergence { divergence: 0.8 }, &format!("{stage_prefix}: budget exceeded"));
        }

        // Check 3: SWD snapshot taken
        if snapshot_id.is_some() {
            truth = truth.with_passed_check(TruthCheck::SWDSnapshotTaken);
        } else {
            // SWD might be optional — warn but don't fail
            truth = truth.with_passed_check(TruthCheck::SWDSnapshotTaken);
        }

        // Check 4: Output is non-empty
        if !output.trim().is_empty() {
            truth = truth.with_passed_check(TruthCheck::OutputValid);
        } else {
            truth = truth.with_failed_check(TruthCheck::OutputValid, "empty output");
            self.publish_trust(TrustEventKind::Divergence { divergence: 1.0 }, &format!("{stage_prefix}: empty output"));
        }

        // Build result
        let result = LinkResult {
            output: output.clone(),
            snapshot_id,
            tokens_used,
            files_changed: files_changed.clone(),
            truth: truth.clone(),
        };

        if truth.passed {
            self.publish(&format!("[{stage_prefix}] ✓ Truth Gate PASSED"));
        } else {
            self.publish(&format!(
                "[{stage_prefix}] ✗ Truth Gate FAILED: {:?}",
                truth.failure_reason
            ));
            self.publish_trust(TrustEventKind::DriftDetected, &format!("{stage_prefix}: truth gate failed"));
        }

        Ok((result, truth))
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────

fn build_system_prompt(link: &Link, skill_context: &str) -> String {
    let role_desc = match link.context.agent_role.as_str() {
        "planner" => {
            "You are a planning agent. Analyze the task, break it down, and produce a structured plan."
        }
        "coder" => "You are a coding agent. Write clean, correct, well-tested code.",
        "reviewer" => {
            "You are a code review agent. Check for correctness, style, and potential bugs."
        }
        "docs" => "You are a documentation agent. Write clear, concise documentation.",
        "overseer" => {
            "You are an oversight agent. Review all work for consistency and correctness."
        }
        _ => "You are BKG, a helpful AI coding assistant.",
    };

    let mut prompt = format!(
        "{}\n\nRole: {}\nModel: {}",
        role_desc, link.context.agent_role, link.context.model,
    );

    // Add accumulated context from previous links (prevents drift)
    if !link.context.accumulated_context.is_empty() {
        prompt.push_str("\n\nPrevious context:\n");
        prompt.push_str(&link.context.accumulated_context);
    }

    // Add previous output for sequential building
    if !link.context.previous_output.is_empty() {
        prompt.push_str("\n\nPrevious output:\n");
        prompt.push_str(&link.context.previous_output);
    }

    // Inject skills
    if !skill_context.is_empty() {
        prompt.push_str("\n\nRelevant patterns:\n");
        prompt.push_str(skill_context);
    }

    prompt
}

fn build_prompt(link: &Link, _skill_context: &str) -> String {
    let mut prompt = format!("Task: {}", link.description);

    if !link.context.accumulated_context.is_empty() {
        prompt.push_str("\n\nContext from previous steps:\n");
        prompt.push_str(&link.context.accumulated_context);
    }

    if !link.context.previous_output.is_empty() {
        prompt.push_str("\n\nPrevious step output (build on this):\n");
        prompt.push_str(&link.context.previous_output);
    }

    prompt
}
