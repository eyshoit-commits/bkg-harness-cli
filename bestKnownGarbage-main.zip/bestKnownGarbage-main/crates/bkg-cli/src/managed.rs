//! Managed Agent CLI — commands for the BKG Managed Agent system.
//!
//! Integrates `bkg-multi-agent` into the CLI with commands for status,
//! preset management, budget tracking, and running managed sessions.

use bkg_multi_agent::{ManagedAgentConfig, ManagedBudgetTracker, ManagedOrchestrator, PresetName};

/// Show available presets.
pub fn list_presets() {
    println!("=== BKG Managed Agent Presets ===\n");

    for preset in [
        PresetName::AnthropicTiered,
        PresetName::GoogleTiered,
        PresetName::CrossOpus,
        PresetName::Budget,
        PresetName::Balanced,
        PresetName::ExecutorHeavy,
        PresetName::ManagerHeavy,
        PresetName::OfflineSafe,
    ] {
        let p = preset.preset();
        let (mgr_pct, exec_pct) = p.budget_policy.split();
        println!("  {} — {}", p.name, p.description);
        println!("    Budget: {mgr_pct}% manager / {exec_pct}% executor");
        println!(
            "    Depth: {}, Concurrent: {}, Budget: {} tokens",
            p.max_depth,
            p.max_concurrent,
            if p.default_budget == 0 {
                "unlimited".to_string()
            } else {
                p.default_budget.to_string()
            }
        );
        if p.offline_safe {
            println!("    ✓ Offline safe");
        }
        println!();
    }
}

/// Show info about a specific preset.
pub fn show_preset(name: &str) {
    let preset = match PresetName::from_str(name) {
        Some(p) => p.preset(),
        None => {
            eprintln!("Unknown preset: '{name}'");
            eprintln!(
                "Available presets: anthropic-tiered, google-tiered, cross-opus, budget, balanced, executor-heavy, manager-heavy, offline-safe"
            );
            return;
        }
    };

    let (mgr_pct, exec_pct) = preset.budget_policy.split();
    println!("Preset: {} — {}", preset.name, preset.description);
    println!("  Budget split: {mgr_pct}% manager / {exec_pct}% executor");
    println!("  Max spawn depth: {}", preset.max_depth);
    println!("  Max concurrent executors: {}", preset.max_concurrent);
    println!("  Default token budget: {}", preset.default_budget);
    println!("  Offline safe: {}", preset.offline_safe);
}

/// Show managed agent system status.
pub fn show_status() {
    let config = ManagedAgentConfig::default();
    let tracker = ManagedBudgetTracker::new(config.total_budget, config.budget_policy);

    println!("=== BKG Managed Agent Status ===\n");
    println!("  Default preset: balanced");
    println!("  Budget policy: {:?}", config.budget_policy);
    println!("  Budget allocation: Manager (50%), Executors (50%)");
    println!("  Default budget: {} tokens", config.total_budget);
    println!("  Max spawn depth: {}", config.max_depth);
    println!("  Max concurrent executors: {}", config.max_concurrent);

    println!("\n  Budget breakdown:");
    println!(
        "    Manager budget:    {:>10} tokens",
        tracker.manager_budget()
    );
    println!(
        "    Executor budget:   {:>10} tokens",
        tracker.executor_budget()
    );
    println!(
        "    Total:             {:>10} tokens",
        tracker.total_budget()
    );
    println!(
        "    Used:              {:>10} tokens",
        tracker.total_consumed()
    );
    println!(
        "    Remaining:         {:>10} tokens",
        tracker.total_remaining()
    );
}

/// Run a managed agent session with a given preset and task.
pub async fn run_session(preset_name: &str, task: &str) -> Result<(), String> {
    let session_id = "managed-session-1".to_string();

    let orch = ManagedOrchestrator::from_preset(preset_name)
        .map_err(|e| format!("Failed to load preset '{preset_name}': {e}"))?;

    let config = orch.config();
    println!("=== BKG Managed Agent Run ===\n");
    println!("  Session:     {session_id}");
    println!("  Preset:      {preset_name}");
    println!("  Budget:      {} tokens", config.total_budget);
    println!("  Max depth:   {}", config.max_depth);
    println!("  Max concur:  {}", config.max_concurrent);
    println!("  Task:        {task}");
    println!();

    // Build the system prompt
    let manager_prompt = orch.build_manager_prompt(&session_id, task);
    println!("── Manager System Prompt ──\n{manager_prompt}\n");

    // Create and show session
    let session = orch.create_session(&session_id, "manager-1");
    println!("── Session Created ──");
    println!("  Agents: {}", session.agents.len());
    println!("  Active: {}", session.active);

    // Show executor prompt as well
    let executor_prompt = orch.build_executor_prompt("example subtask");
    println!("\n── Executor System Prompt ──\n{executor_prompt}\n");

    Ok(())
}

/// Try all presets as a validation/check.
pub fn validate_presets() {
    println!("Validating all presets...");
    let mut ok = 0u32;
    let mut fail = 0u32;

    for name in [
        "anthropic-tiered",
        "google-tiered",
        "cross-opus",
        "budget",
        "balanced",
        "executor-heavy",
        "manager-heavy",
        "offline-safe",
    ] {
        match ManagedAgentConfig::from_preset(name) {
            Ok(config) => {
                if config.validate().is_ok() {
                    println!("  ✓ {name}");
                    ok += 1;
                } else {
                    println!("  ✗ {name} (validation failed)");
                    fail += 1;
                }
            }
            Err(e) => {
                println!("  ✗ {name} ({e})");
                fail += 1;
            }
        }
    }

    println!("\nResult: {ok} passed, {fail} failed");
}
