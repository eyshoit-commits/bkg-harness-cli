//! BKG Atlantean UI — Reveland Design System
//!
//! The complete Atlantean visual identity system for BKG.
//! Based on the 6 Sphären and Reveland taxonomy.
//!
//! # Color Philosophy
//!
//! Each Sphäre has a signature color that represents its essence:
//!
//! | Sphäre | Color    | Hex       | Meaning                        |
//! |--------|----------|-----------|--------------------------------|
//! | ARCHE  | Gold     | #FFD700   | First Cause, divine origin     |
//! | THALASSA | Cyan   | #00CED1   | Living waters, ephemeral flow  |
//! | STYX   | Purple   | #9370DB   | Causal crossing, transition    |
//! | KATOPTRON | Silver | #C0C0C0 | Mirror of truth, reflection    |
//! | ANAMNESIS | Green  | #32CD32   | Living memory, growth          |
//! | MNEMOS | Blue     | #4169E1   | Immutable foundation, depth    |
//!
//! # UI Components
//!
//! All UI components follow Atlantean naming:
//! - Nucleus (center/core)
//! - Pillar (vertical panels)
//! - Lintel (horizontal bars)
//! - Portal (input/output areas)
//! - Oracle (AI response displays)
//! - Chronos (time/event displays)

use ratatui::style::{Color, Modifier, Style};

/// Atlantean color palette
pub mod colors {
    use super::*;

    /// ARCHE - First Cause (Gold)
    pub const ARCHE: Color = Color::Rgb(255, 215, 0);

    /// THALASSA - Living Current (Cyan)
    pub const THALASSA: Color = Color::Rgb(0, 206, 209);

    /// STYX - Causal Crossing (Purple)
    pub const STYX: Color = Color::Rgb(147, 112, 219);

    /// KATOPTRON - Mirror of Truth (Silver)
    pub const KATOPTRON: Color = Color::Rgb(192, 192, 192);

    /// ANAMNESIS - Living Memory (Green)
    pub const ANAMNESIS: Color = Color::Rgb(50, 205, 50);

    /// MNEMOS - Immutable Foundation (Blue)
    pub const MNEMOS: Color = Color::Rgb(65, 105, 225);

    /// Nucleus - Heart/Core (White)
    pub const NUCLEUS: Color = Color::Rgb(255, 255, 255);

    /// Void - Empty Space (Dark Gray)
    pub const VOID: Color = Color::Rgb(30, 30, 30);

    /// Error - Divergence (Red)
    pub const DIVERGENCE: Color = Color::Rgb(220, 20, 60);

    /// Success - Verified (Bright Green)
    pub const VERIFIED: Color = Color::Rgb(0, 255, 127);
}

/// Atlantean UI styles
pub mod styles {
    use super::*;

    /// Title style for all Atlantean headers
    pub fn title() -> Style {
        Style::default()
            .fg(colors::ARCHE)
            .add_modifier(Modifier::BOLD)
    }

    /// Header style for panel headers
    pub fn header() -> Style {
        Style::default()
            .fg(colors::NUCLEUS)
            .bg(colors::VOID)
            .add_modifier(Modifier::BOLD)
    }

    /// Accent style for highlights
    pub fn accent() -> Style {
        Style::default()
            .fg(colors::THALASSA)
            .add_modifier(Modifier::BOLD)
    }

    /// Success style for verified operations
    pub fn verified() -> Style {
        Style::default()
            .fg(colors::VERIFIED)
            .add_modifier(Modifier::BOLD)
    }

    /// Error style for divergences
    pub fn divergence() -> Style {
        Style::default()
            .fg(colors::DIVERGENCE)
            .add_modifier(Modifier::BOLD)
    }

    /// Muted style for secondary text
    pub fn muted() -> Style {
        Style::default().fg(colors::KATOPTRON)
    }

    /// Accent style for the active element
    pub fn active() -> Style {
        Style::default()
            .fg(colors::ARCHE)
            .bg(colors::VOID)
            .add_modifier(Modifier::BOLD)
    }

    /// Inactive style
    pub fn inactive() -> Style {
        Style::default().fg(colors::KATOPTRON)
    }

    /// Streaming indicator style
    pub fn streaming() -> Style {
        Style::default()
            .fg(colors::THALASSA)
            .add_modifier(Modifier::SLOW_BLINK)
    }
}

/// Atlantean symbols and icons
pub mod symbols {
    /// ARCHE symbol (origin/source)
    pub const ARCHE: &str = "α";

    /// THALASSA symbol (wave)
    pub const THALASSA: &str = "θ";

    /// STYX symbol (crossing)
    pub const STYX: &str = "σ";

    /// KATOPTRON symbol (mirror)
    pub const KATOPTRON: &str = "κ";

    /// ANAMNESIS symbol (memory)
    pub const ANAMNESIS: &str = "η";

    /// MNEMOS symbol (foundation)
    pub const MNEMOS: &str = "μ";

    /// Nucleus symbol (core)
    pub const NUCLEUS: &str = "Ω";

    /// Success/verified symbol
    pub const VERIFIED: &str = "✓";

    /// Divergence/error symbol
    pub const DIVERGENCE: &str = "✗";

    /// Running/pending symbol
    pub const RUNNING: &str = "▶";

    /// Stopped/paused symbol
    pub const STOPPED: &str = "■";

    /// Streaming symbol
    pub const STREAMING: &str = "⟳";

    /// Arrow symbols
    pub const ARROW_RIGHT: &str = "→";
    pub const ARROW_DOWN: &str = "↓";
    pub const ARROW_UP: &str = "↑";
}

/// Atlantean UI borders and boxes
pub mod borders {
    /// Double-line border for primary panels
    pub const DOUBLE_TOP_LEFT: &str = "╔";
    pub const DOUBLE_TOP_RIGHT: &str = "╗";
    pub const DOUBLE_BOTTOM_LEFT: &str = "╚";
    pub const DOUBLE_BOTTOM_RIGHT: &str = "╝";
    pub const DOUBLE_HORIZONTAL: &str = "═";
    pub const DOUBLE_VERTICAL: &str = "║";

    /// Single-line border for secondary panels
    pub const SINGLE_TOP_LEFT: &str = "┌";
    pub const SINGLE_TOP_RIGHT: &str = "┐";
    pub const SINGLE_BOTTOM_LEFT: &str = "└";
    pub const SINGLE_BOTTOM_RIGHT: &str = "┘";
    pub const SINGLE_HORIZONTAL: &str = "─";
    pub const SINGLE_VERTICAL: &str = "│";

    /// Rounded border for tertiary panels
    pub const ROUNDED_TOP_LEFT: &str = "╭";
    pub const ROUNDED_TOP_RIGHT: &str = "╮";
    pub const ROUNDED_BOTTOM_LEFT: &str = "╰";
    pub const ROUNDED_BOTTOM_RIGHT: &str = "╯";
}

/// Atlantean component names
pub mod components {
    /// Main application header
    pub const HEADER: &str = "PILLAR_OF_ORIGIN";

    /// Chat input area
    pub const INPUT: &str = "ORACLE_PORTAL";

    /// Chat output area
    pub const OUTPUT: &str = "ORACLE_RESPONSE";

    /// Status bar
    pub const STATUS: &str = "CHRONOS_STRIP";

    /// Side panel
    pub const PANEL: &str = "PILLAR";

    /// Event log
    pub const LOG: &str = "SCROLL_OF_AGES";

    /// DAG visualization
    pub const DAG: &str = "TAPESTRY_OF_CAUSALITY";

    /// Config editor
    pub const CONFIG: &str = "CODEX_OF_LAWS";
}

/// Helper function to create Atlantean-styled box title
pub fn atlantean_title(sphäre: &str, text: &str) -> String {
    let symbol = match sphäre {
        "arche" => symbols::ARCHE,
        "thalassa" => symbols::THALASSA,
        "styx" => symbols::STYX,
        "katoptron" => symbols::KATOPTRON,
        "anamnesis" => symbols::ANAMNESIS,
        "mnemos" => symbols::MNEMOS,
        "nucleus" => symbols::NUCLEUS,
        _ => "●",
    };
    format!(" {} {} ", symbol, text)
}

/// Helper function to create a progress indicator
pub fn progress_indicator(current: usize, total: usize) -> String {
    let percentage = if total > 0 {
        (current * 100) / total
    } else {
        0
    };

    let filled = percentage / 10;
    let empty = 10 - filled;

    let bar: String = std::iter::repeat('█')
        .take(filled)
        .chain(std::iter::repeat('░').take(empty))
        .collect();

    format!("[{}] {}%", bar, percentage)
}

/// Helper function to create a causal chain indicator
pub fn causal_chain_indicator(steps: &[&str], current: usize) -> String {
    steps
        .iter()
        .enumerate()
        .map(|(i, step)| {
            if i < current {
                format!("{}{}", symbols::VERIFIED, step)
            } else if i == current {
                format!("{}{}", symbols::RUNNING, step)
            } else {
                format!("○{}", step)
            }
        })
        .collect::<Vec<_>>()
        .join(&format!(" {} ", symbols::ARROW_RIGHT))
}
