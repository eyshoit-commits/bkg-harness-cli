//! Status bus — broadcast channel for agent → UI events.
//!
//! Every AgentWorker publishes its activity here. The TUI subscribes
//! and renders real-time status in the Agents tab.
//!
//! New: SystemEvent variant for CapsuleState, TrustLayer, SWD, Healing.

use serde_json::Value;
use tokio::sync::broadcast;

/// Everything an agent or system can report while working.
#[derive(Clone, Debug)]
pub enum AgentEvent {
    /// Agent is thinking / waiting for LLM
    Thinking,
    /// Agent is calling a tool
    ToolCall { tool: String, arguments: Value },
    /// Tool returned a result
    ToolResult { tool: String, summary: String },
    /// Partial or final text response from the LLM
    Response { text: String },
    /// An error occurred
    Error { message: String },
    /// Agent finished successfully
    Done { summary: String },
    // ── System Events ──
    /// Capsule system state update
    CapsuleEvent { state: CapsuleEventKind, message: String },
    /// Trust layer / drift detection event
    TrustEvent { kind: TrustEventKind, message: String },
    /// SWD (Strict Write Discipline) event
    SwdEvent { kind: SwdEventKind, path: String, message: String },
    /// Self-healing event
    HealEvent { strategy: String, result: String },
    /// Model routing event
    RouteEvent { role: String, model: String, provider: String },
}

/// Sub-types for capsule events
#[derive(Clone, Debug)]
pub enum CapsuleEventKind {
    Healthy,
    Degraded,
    Missing,
    Repaired,
    Rehydrated,
}

/// Sub-types for trust layer events
#[derive(Clone, Debug)]
pub enum TrustEventKind {
    DriftDetected,
    DriftResolved,
    TruthVerified,
    Divergence { divergence: f64 },
}

/// Sub-types for SWD events
#[derive(Clone, Debug)]
pub enum SwdEventKind {
    WriteBlocked,
    WriteAllowed,
    IntegrityCheck,
    SnapshotCreated,
}

impl std::fmt::Display for AgentEvent {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AgentEvent::Thinking => write!(f, "🧠 thinking…"),
            AgentEvent::ToolCall { tool, .. } => write!(f, "🔧 {tool}(…)"),
            AgentEvent::ToolResult { tool, summary } => {
                let s = if summary.len() > 60 {
                    format!("{}…", &summary[..57])
                } else {
                    summary.clone()
                };
                write!(f, "🔧 {tool} → {s}")
            }
            AgentEvent::Response { text } => {
                let s = if text.len() > 80 {
                    format!("{}…", &text[..77])
                } else {
                    text.clone()
                };
                write!(f, "💬 {s}")
            }
            AgentEvent::Error { message } => write!(f, "⚠️  {message}"),
            AgentEvent::Done { summary } => write!(f, "✅ {summary}"),
            AgentEvent::CapsuleEvent { state, message } => {
                let icon = match state {
                    CapsuleEventKind::Healthy => "✅",
                    CapsuleEventKind::Degraded => "⚠️",
                    CapsuleEventKind::Missing => "❌",
                    CapsuleEventKind::Repaired => "🔧",
                    CapsuleEventKind::Rehydrated => "💧",
                };
                write!(f, "{} Capsule: {}", icon, message)
            }
            AgentEvent::TrustEvent { kind, message } => {
                let icon = match kind {
                    TrustEventKind::TruthVerified => "🔮",
                    TrustEventKind::DriftDetected => "🚨",
                    TrustEventKind::DriftResolved => "✅",
                    TrustEventKind::Divergence { .. } => "⚠️",
                };
                write!(f, "{} Trust: {}", icon, message)
            }
            AgentEvent::SwdEvent { kind, path, message } => {
                let icon = match kind {
                    SwdEventKind::WriteBlocked => "🔒",
                    SwdEventKind::WriteAllowed => "🔓",
                    SwdEventKind::IntegrityCheck => "🔍",
                    SwdEventKind::SnapshotCreated => "📸",
                };
                write!(f, "{} SWD [{}]: {} {}", icon, path, message, path)
            }
            AgentEvent::HealEvent { strategy, result } => {
                write!(f, "🩺 Heal({}): {}", strategy, result)
            }
            AgentEvent::RouteEvent { role, model, provider } => {
                write!(f, "🔄 Route: {} → {}@{}", role, model, provider)
            }
        }
    }
}

/// Channel capacity — keeps the last 4096 events so the TUI never misses one.
const BUS_CAPACITY: usize = 4096;

/// Broadcast bus: workers publish, TUI subscribes.
#[derive(Clone)]
pub struct StatusBus {
    tx: broadcast::Sender<(String, AgentEvent)>,
}

impl StatusBus {
    pub fn new() -> Self {
        let (tx, _) = broadcast::channel(BUS_CAPACITY);
        Self { tx }
    }

    /// Publish an event from an agent.
    pub fn publish(&self, agent_id: &str, event: AgentEvent) {
        let _ = self.tx.send((agent_id.to_string(), event));
    }

    /// Subscribe to all agent events.
    pub fn subscribe(&self) -> broadcast::Receiver<(String, AgentEvent)> {
        self.tx.subscribe()
    }

    /// Publish a capsule system event.
    pub fn publish_capsule(&self, state: CapsuleEventKind, message: &str) {
        self.publish("system", AgentEvent::CapsuleEvent {
            state,
            message: message.to_string(),
        });
    }

    /// Publish a trust layer event.
    pub fn publish_trust(&self, kind: TrustEventKind, message: &str) {
        self.publish("system", AgentEvent::TrustEvent {
            kind,
            message: message.to_string(),
        });
    }

    /// Publish an SWD event.
    pub fn publish_swd(&self, kind: SwdEventKind, path: &str, message: &str) {
        self.publish("system", AgentEvent::SwdEvent {
            kind,
            path: path.to_string(),
            message: message.to_string(),
        });
    }

    /// Publish a healing event.
    pub fn publish_heal(&self, strategy: &str, result: &str) {
        self.publish("system", AgentEvent::HealEvent {
            strategy: strategy.to_string(),
            result: result.to_string(),
        });
    }

    /// Publish a routing event.
    pub fn publish_route(&self, role: &str, model: &str, provider: &str) {
        self.publish("system", AgentEvent::RouteEvent {
            role: role.to_string(),
            model: model.to_string(),
            provider: provider.to_string(),
        });
    }
}

impl Default for StatusBus {
    fn default() -> Self {
        Self::new()
    }
}