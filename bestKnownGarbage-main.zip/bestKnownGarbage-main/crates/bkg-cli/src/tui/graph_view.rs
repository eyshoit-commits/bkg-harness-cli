//! Graph view — layout engine for the DAG canvas.
//!
//! Computes screen-space positions for graph nodes using a level-based
//! layout algorithm (Sugiyama-style simplified):
//!
//! 1. Topological sort to determine levels
//! 2. Assign Y = level_index * vertical_spacing
//! 3. Assign X = node_index_within_level * horizontal_spacing
//! 4. Center each level horizontally
//!
//! The result is stored in `GraphLayout` and used by `DagRenderer` to
//! draw nodes and edges on the canvas.

use std::collections::HashMap;

use bkg_core::capsule::{graph::CapsuleGraph, node::NodeId};
use ratatui::layout::Rect;

/// Computed screen positions for all nodes in a graph.
#[derive(Clone, Debug)]
pub struct GraphLayout {
    /// Topological levels: level 0 = roots
    pub levels: Vec<Vec<NodeId>>,
    /// Screen-space (x, y) positions for each node
    pub positions: HashMap<NodeId, (u16, u16)>,
    /// Bounding box of all positioned nodes
    pub bounds: (u16, u16, u16, u16), // min_x, min_y, max_x, max_y
    /// Total width and height of the layout
    pub width: u16,
    pub height: u16,
}

impl GraphLayout {
    /// Compute a new layout for the given graph within the given screen area.
    ///
    /// The layout algorithm:
    /// 1. Gets topological levels from the graph
    /// 2. Assigns Y positions based on level index
    /// 3. Distributes nodes horizontally within each level
    /// 4. Centers the entire layout in the available area
    pub fn compute(graph: &CapsuleGraph, area: Rect) -> Self {
        let levels = graph.topological_levels();
        if levels.is_empty() {
            return Self {
                levels: Vec::new(),
                positions: HashMap::new(),
                bounds: (0, 0, 0, 0),
                width: 0,
                height: 0,
            };
        }

        let area_w = area.width.max(40) as usize;
        let area_h = area.height.max(20) as usize;

        // Compute spacing
        let max_nodes_per_level = levels.iter().map(|l| l.len()).max().unwrap_or(1);
        let v_spacing = (area_h as f64 / (levels.len() as f64 + 1.0)).max(3.0) as u16;
        let h_spacing = (area_w as f64 / (max_nodes_per_level as f64 + 1.0)).max(6.0) as u16;

        // Node width/height for box drawing
        let node_w: u16 = 16;
        let node_h: u16 = 3;

        let mut positions = HashMap::new();
        let mut min_x = u16::MAX;
        let mut min_y = u16::MAX;
        let mut max_x = u16::MIN;
        let mut max_y = u16::MIN;

        for (level_idx, level_nodes) in levels.iter().enumerate() {
            let y = (level_idx as u16 + 1) * v_spacing;
            let level_width = level_nodes.len() as u16 * h_spacing;
            let start_x = (area_w as u16).saturating_sub(level_width) / 2;

            for (node_idx, node_id) in level_nodes.iter().enumerate() {
                let x = start_x + node_idx as u16 * h_spacing;
                positions.insert(node_id.clone(), (x, y));

                min_x = min_x.min(x);
                min_y = min_y.min(y);
                max_x = max_x.max(x + node_w);
                max_y = max_y.max(y + node_h);
            }
        }

        let width = max_x.saturating_sub(min_x) + node_w;
        let height = max_y.saturating_sub(min_y) + node_h;

        Self {
            levels,
            positions,
            bounds: (min_x, min_y, max_x, max_y),
            width,
            height,
        }
    }

    /// Get the position of a node, if it has one.
    pub fn position_of(&self, node_id: &str) -> Option<(u16, u16)> {
        self.positions.get(node_id).copied()
    }

    /// Find the node closest to a given screen position.
    ///
    /// Used for mouse/touch interaction.
    pub fn node_at(&self, x: u16, y: u16) -> Option<&NodeId> {
        let threshold: u16 = 8; // max distance to consider a hit
        self.positions
            .iter()
            .filter(|(_, (nx, ny))| nx.abs_diff(x) <= threshold && ny.abs_diff(y) <= threshold)
            .min_by_key(|(_, (nx, ny))| nx.abs_diff(x) + ny.abs_diff(y))
            .map(|(id, _)| id)
    }

    /// Get the next node in the same level (for keyboard navigation).
    pub fn next_sibling(&self, node_id: &str) -> Option<&NodeId> {
        for level in &self.levels {
            if let Some(pos) = level.iter().position(|id| id == node_id) {
                return level.get(pos + 1);
            }
        }
        None
    }

    /// Get the previous node in the same level.
    pub fn prev_sibling(&self, node_id: &str) -> Option<&NodeId> {
        for level in &self.levels {
            if let Some(pos) = level.iter().position(|id| id == node_id) {
                if pos > 0 {
                    return level.get(pos - 1);
                }
            }
        }
        None
    }

    /// Get the first child of a node.
    pub fn first_child<'a>(&self, node_id: &str, graph: &'a CapsuleGraph) -> Option<&'a NodeId> {
        graph.get_node(node_id)?.children.first()
    }

    /// Get the parent of a node.
    pub fn parent_of<'a>(&self, node_id: &str, graph: &'a CapsuleGraph) -> Option<&'a NodeId> {
        graph.get_node(node_id)?.parents.first()
    }
}
