//! DagUiState — pure UI state for the DAG renderer.
//!
//! This is a reducer: it takes `GraphEvent` values and produces
//! renderable state. No I/O, no side effects — just transformations.
//!
//! # Event → State Flow
//!
//! ```text
//! GraphEvent → DagUiState::reduce() → updated DagUiState → DagRenderer::render()
//! ```

use bkg_core::capsule::{CapsuleGraph, GraphEvent, GraphEventKind};
use std::collections::HashSet;

/// All UI-relevant state for the DAG tab.
///
/// The renderer (DagRenderer) reads this struct and produces the terminal output.
/// Every field has a clear default — the renderer never panics on missing data.
#[derive(Clone)]
pub struct DagUiState {
    // ── Session ──
    pub capsule_id: Option<String>,
    pub graph: Option<CapsuleGraph>,

    // ── Selection ──
    pub active_node: Option<String>,
    pub selected_path: Vec<String>,
    pub focus_panel: PanelFocus,

    // ── Visibility ──
    pub visible_nodes: HashSet<String>,
    pub visible_edges: HashSet<String>,

    // ── Status sets (for color coding) ──
    pub verified_nodes: HashSet<String>,
    pub stale_nodes: HashSet<String>,
    pub divergent_nodes: HashSet<String>,
    pub repaired_nodes: HashSet<String>,

    // ── Timeline ──
    pub event_log: Vec<GraphEvent>,
    pub timeline_scroll: usize,
    pub last_event_at: Option<String>,

    // ── Interaction ──
    pub node_tree_scroll: usize,
    pub inspector_scroll: usize,
}

/// Which of the four panels has keyboard focus.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum PanelFocus {
    NodeTree,
    GraphCanvas,
    Inspector,
    Timeline,
}

impl DagUiState {
    pub fn new() -> Self {
        Self {
            capsule_id: None,
            graph: None,
            active_node: None,
            selected_path: Vec::new(),
            focus_panel: PanelFocus::GraphCanvas,
            visible_nodes: HashSet::new(),
            visible_edges: HashSet::new(),
            verified_nodes: HashSet::new(),
            stale_nodes: HashSet::new(),
            divergent_nodes: HashSet::new(),
            repaired_nodes: HashSet::new(),
            event_log: Vec::new(),
            timeline_scroll: 0,
            last_event_at: None,
            node_tree_scroll: 0,
            inspector_scroll: 0,
        }
    }

    /// Reduce an event into state.
    ///
    /// Call this for every `GraphEvent` received from the bus.
    /// The reducer is idempotent — calling it with the same event
    /// twice produces the same state.
    pub fn reduce(&mut self, event: &GraphEvent) {
        self.last_event_at = Some(event.created_at.to_rfc3339());
        self.event_log.push(event.clone());

        // Keep only last 500 events in memory
        if self.event_log.len() > 500 {
            self.event_log.remove(0);
        }

        // Set capsule ID on first event
        if self.capsule_id.is_none() {
            self.capsule_id = Some(event.capsule_id.clone());
        }

        match event.kind {
            GraphEventKind::CapsuleLoaded | GraphEventKind::CapsuleRehydrated => {
                if let Some(ref node_id) = event.node_id {
                    self.visible_nodes.insert(node_id.clone());
                }
            }
            GraphEventKind::NodeAdded => {
                if let Some(ref node_id) = event.node_id {
                    self.visible_nodes.insert(node_id.clone());
                }
            }
            GraphEventKind::NodeRemoved => {
                if let Some(ref node_id) = event.node_id {
                    self.visible_nodes.remove(node_id);
                    self.verified_nodes.remove(node_id);
                    self.stale_nodes.remove(node_id);
                    self.divergent_nodes.remove(node_id);
                    self.repaired_nodes.remove(node_id);
                }
            }
            GraphEventKind::NodeVerified => {
                if let Some(ref node_id) = event.node_id {
                    self.verified_nodes.insert(node_id.clone());
                    self.stale_nodes.remove(node_id);
                    self.divergent_nodes.remove(node_id);
                    self.repaired_nodes.remove(node_id);
                }
            }
            GraphEventKind::NodeStale => {
                if let Some(ref node_id) = event.node_id {
                    self.stale_nodes.insert(node_id.clone());
                    self.verified_nodes.remove(node_id);
                }
            }
            GraphEventKind::NodeDivergent | GraphEventKind::DriftDetected => {
                if let Some(ref node_id) = event.node_id {
                    self.divergent_nodes.insert(node_id.clone());
                    self.verified_nodes.remove(node_id);
                }
            }
            GraphEventKind::NodeRepaired | GraphEventKind::DriftResolved => {
                if let Some(ref node_id) = event.node_id {
                    self.repaired_nodes.insert(node_id.clone());
                    self.divergent_nodes.remove(node_id);
                    self.stale_nodes.remove(node_id);
                }
            }
            GraphEventKind::EdgeAdded => {
                if let Some(ref edge_id) = event.edge_id {
                    self.visible_edges.insert(edge_id.clone());
                }
            }
            GraphEventKind::EdgeRemoved => {
                if let Some(ref edge_id) = event.edge_id {
                    self.visible_edges.remove(edge_id);
                }
            }
            _ => {}
        }
    }

    /// Select a node by ID.
    pub fn select_node(&mut self, node_id: &str) {
        self.active_node = Some(node_id.to_string());
        self.selected_path.push(node_id.to_string());
    }

    /// Clear the current node selection.
    pub fn clear_selection(&mut self) {
        self.active_node = None;
    }

    /// Move focus to the next panel.
    pub fn focus_next(&mut self) {
        self.focus_panel = match self.focus_panel {
            PanelFocus::NodeTree => PanelFocus::GraphCanvas,
            PanelFocus::GraphCanvas => PanelFocus::Inspector,
            PanelFocus::Inspector => PanelFocus::Timeline,
            PanelFocus::Timeline => PanelFocus::NodeTree,
        };
    }

    /// Move focus to the previous panel.
    pub fn focus_prev(&mut self) {
        self.focus_panel = match self.focus_panel {
            PanelFocus::NodeTree => PanelFocus::Timeline,
            PanelFocus::GraphCanvas => PanelFocus::NodeTree,
            PanelFocus::Inspector => PanelFocus::GraphCanvas,
            PanelFocus::Timeline => PanelFocus::Inspector,
        };
    }

    /// Set the graph data.
    pub fn set_graph(&mut self, graph: CapsuleGraph) {
        self.capsule_id = Some(graph.capsule_id.clone());
        for node_id in graph.nodes.keys() {
            self.visible_nodes.insert(node_id.clone());
        }
        for edge_id in graph.edges.keys() {
            self.visible_edges.insert(edge_id.clone());
        }
        self.graph = Some(graph);
    }
}

impl Default for DagUiState {
    fn default() -> Self {
        Self::new()
    }
}
