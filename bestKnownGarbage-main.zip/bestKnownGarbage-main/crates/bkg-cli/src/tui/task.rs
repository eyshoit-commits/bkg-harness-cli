//! Task system — decomposes multi-part work and tracks each sub-task.
//!
//! A single prompt like "implement auth + add tests + update docs" gets
//! split into separate Task items. Each is dispatched to an AgentWorker.

use std::time::Instant;

/// Current status of a single task.
#[derive(Clone, Debug, PartialEq)]
pub enum TaskStatus {
    /// Waiting for a worker slot
    Queued,
    /// Assigned to an agent, work in progress
    Running,
    /// Completed successfully
    Done,
    /// Failed with an error message
    Failed(String),
}

/// A unit of work — one slice of a multi-part prompt.
#[derive(Clone, Debug)]
pub struct Task {
    /// Unique id (e.g. "task-1")
    pub id: String,
    /// Human-readable description
    pub description: String,
    /// Current status
    pub status: TaskStatus,
    /// Which model this task should use (user-assigned)
    pub model: String,
    /// Which agent is working on it (set when dispatched)
    pub agent_id: Option<String>,
    /// When the task was created
    pub created_at: Instant,
    /// Duration if finished
    pub duration: Option<std::time::Duration>,
    /// Result text if done
    pub result: Option<String>,
}

impl Task {
    fn new(id: String, description: String, model: String) -> Self {
        Self {
            id,
            description,
            status: TaskStatus::Queued,
            model,
            agent_id: None,
            created_at: Instant::now(),
            duration: None,
            result: None,
        }
    }
}

/// Manages the task queue — creation, dispatch, status updates.
#[derive(Clone, Debug)]
pub struct TaskManager {
    tasks: Vec<Task>,
    next_id: usize,
}

impl TaskManager {
    pub fn new() -> Self {
        Self {
            tasks: Vec::new(),
            next_id: 1,
        }
    }

    /// Split a multi-part prompt into individual tasks.
    ///
    /// The prompt is split on `+`, `,`, newlines, or numbered items.
    /// Each part becomes a separate Task with the given model.
    ///
    /// Returns the ids of the newly created tasks.
    pub fn decompose(&mut self, prompt: &str, model: &str) -> Vec<String> {
        let parts = self.split_prompt(prompt);
        let mut ids = Vec::new();

        for part in parts {
            let id = format!("task-{}", self.next_id);
            self.next_id += 1;
            self.tasks
                .push(Task::new(id.clone(), part, model.to_string()));
            ids.push(id);
        }

        ids
    }

    /// Add a single task manually.
    pub fn add(&mut self, description: &str, model: &str) -> String {
        let id = format!("task-{}", self.next_id);
        self.next_id += 1;
        self.tasks.push(Task::new(
            id.clone(),
            description.to_string(),
            model.to_string(),
        ));
        id
    }

    /// Mark a task as running (assigned to an agent).
    pub fn start(&mut self, task_id: &str, agent_id: &str) {
        if let Some(task) = self.tasks.iter_mut().find(|t| t.id == task_id) {
            task.status = TaskStatus::Running;
            task.agent_id = Some(agent_id.to_string());
        }
    }

    /// Mark a task as done.
    pub fn complete(&mut self, task_id: &str, result: &str) {
        if let Some(task) = self.tasks.iter_mut().find(|t| t.id == task_id) {
            task.status = TaskStatus::Done;
            task.result = Some(result.to_string());
            task.duration = Some(task.created_at.elapsed());
        }
    }

    /// Mark a task as failed.
    pub fn fail(&mut self, task_id: &str, error: &str) {
        if let Some(task) = self.tasks.iter_mut().find(|t| t.id == task_id) {
            task.status = TaskStatus::Failed(error.to_string());
            task.duration = Some(task.created_at.elapsed());
        }
    }

    /// Get all tasks.
    pub fn all(&self) -> &[Task] {
        &self.tasks
    }

    /// Get queued (not yet running) tasks.
    pub fn queued(&self) -> Vec<&Task> {
        self.tasks
            .iter()
            .filter(|t| t.status == TaskStatus::Queued)
            .collect()
    }

    /// Get running tasks.
    pub fn running(&self) -> Vec<&Task> {
        self.tasks
            .iter()
            .filter(|t| t.status == TaskStatus::Running)
            .collect()
    }

    /// Count of tasks in each status.
    pub fn counts(&self) -> (usize, usize, usize, usize) {
        let mut q = 0usize;
        let mut r = 0usize;
        let mut d = 0usize;
        let mut f = 0usize;
        for t in &self.tasks {
            match t.status {
                TaskStatus::Queued => q += 1,
                TaskStatus::Running => r += 1,
                TaskStatus::Done => d += 1,
                TaskStatus::Failed(_) => f += 1,
            }
        }
        (q, r, d, f)
    }

    // Split a prompt into sub-tasks.
    fn split_prompt(&self, prompt: &str) -> Vec<String> {
        let prompt = prompt.trim();
        if prompt.is_empty() {
            return vec![];
        }

        // Try splitting on common multi-part delimiters
        let parts: Vec<&str> = prompt
            .split(|c: char| c == '+' || c == ',')
            .flat_map(|s| s.split('\n'))
            .map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect();

        if parts.len() > 1 {
            return parts.into_iter().map(|s| s.to_string()).collect();
        }

        // Try numbered list: "1. do X 2. do Y 3. do Z"
        let _numbered: Vec<&str> = prompt
            .split(char::is_uppercase) // heuristic: each item starts uppercase
            .collect();

        // Fall back: single task
        vec![prompt.to_string()]
    }
}

impl Default for TaskManager {
    fn default() -> Self {
        Self::new()
    }
}
