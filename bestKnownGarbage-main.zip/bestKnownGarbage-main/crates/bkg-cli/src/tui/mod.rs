//! TUI — Terminal UI for the Chain system.
//!
//! Provides interactive visualization of chain execution:
//! - Chat tab: prompt input + response
//! - Chain tab: chain progress with link status + truth gates
//! - Config tab: model routing per agent role
//!
//! # Atlantean Design System
//!
//! The TUI follows the Atlantean visual identity based on the 6 Sphären.
//! Each component has a Reveland identity and mystical aesthetic.

pub mod app;
pub mod atlantean;
pub mod dag;
pub mod graph_events;
pub mod graph_state;
pub mod graph_view;
pub mod status;
pub mod task;

// Re-exports
pub use app::run_tui;
pub use atlantean::{colors, styles, symbols};
pub use dag::DagRenderer;
pub use graph_state::DagUiState;
pub use graph_view::GraphLayout;
pub use status::{AgentEvent, StatusBus};
pub use task::TaskManager;
