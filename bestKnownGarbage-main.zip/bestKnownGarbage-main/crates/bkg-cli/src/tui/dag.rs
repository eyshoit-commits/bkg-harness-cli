//! DagRenderer — 4-panel DAG visualization for the TUI.
//!
//! Renders the capsule execution graph as a live, interactive terminal UI.
//! Layout:
//!
//! ```text
//! ┌────────────────────────────────────────────────────┐
//! │ [Graph] Title Bar                                  │
//! ├──────────┬─────────────────────────┬───────────────┤
//! │  Node    │   Graph Canvas          │   Inspector   │
//! │  Tree    │   (DAG layout)          │   (details)   │
//! │          │                         │               │
//! ├──────────┴─────────────────────────┴───────────────┤
//! │ Timeline / Event Log                                │
//! └────────────────────────────────────────────────────┘
//! ```
//!
//! Usage:
//! ```rust,ignore
//! let renderer = DagRenderer::new(&dag_state, &layout);
//! frame.render_widget(renderer, area);
//! ```

use ratatui::{
    Frame,
    layout::{Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    text::{Line, Span, Text},
    widgets::{Block, Borders, List, ListItem, Paragraph, Wrap},
};

use super::graph_events::{
    format_event_line, node_status_color, node_status_icon, severity_color,
};
use super::graph_state::{DagUiState, PanelFocus};
use super::graph_view::GraphLayout;

/// The DAG renderer — renders a full 4-panel graph view.
///
/// Owns no state. Takes references to `DagUiState` and `GraphLayout`.
pub struct DagRenderer<'a> {
    state: &'a DagUiState,
    layout: &'a GraphLayout,
}

impl<'a> DagRenderer<'a> {
    /// Create a new renderer for the given state and layout.
    pub fn new(state: &'a DagUiState, layout: &'a GraphLayout) -> Self {
        Self { state, layout }
    }

    /// Render the full DAG view into the given frame area.
    pub fn render(&self, frame: &mut Frame, area: Rect) {
        // ── Title bar ──
        let main_chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Length(1), Constraint::Min(0)])
            .split(area);

        self.render_title_bar(frame, main_chunks[0]);

        // ── 3-column body + bottom timeline ──
        let body_chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Min(0), Constraint::Length(10)])
            .split(main_chunks[1]);

        let column_chunks = Layout::default()
            .direction(Direction::Horizontal)
            .constraints([
                Constraint::Percentage(25),
                Constraint::Percentage(45),
                Constraint::Percentage(30),
            ])
            .split(body_chunks[0]);

        self.render_node_tree(frame, column_chunks[0]);
        self.render_graph_canvas(frame, column_chunks[1]);
        self.render_inspector(frame, column_chunks[2]);
        self.render_timeline(frame, body_chunks[1]);
    }

    // ── Title bar ──

    fn render_title_bar(&self, frame: &mut Frame, area: Rect) {
        let capsule = self.state.capsule_id.as_deref().unwrap_or("(no capsule)");
        let node_count = self
            .state
            .graph
            .as_ref()
            .map(|g| g.node_count())
            .unwrap_or(0);
        let edge_count = self
            .state
            .graph
            .as_ref()
            .map(|g| g.edge_count())
            .unwrap_or(0);
        let title = format!(
            " DAG — {capsule} | {node_count} nodes, {edge_count} edges | \
             Tab:Switch  ↑↓:Navigate  Enter:Select  Q:Quit"
        );
        let title_style = Style::default()
            .fg(Color::White)
            .bg(Color::Blue)
            .add_modifier(Modifier::BOLD);
        let para = Paragraph::new(Text::from(title)).style(title_style);
        frame.render_widget(para, area);
    }

    // ── Node tree (left panel) ──

    fn render_node_tree(&self, frame: &mut Frame, area: Rect) {
        let has_focus = self.state.focus_panel == PanelFocus::NodeTree;
        let border_style = if has_focus {
            Style::default().fg(Color::Cyan)
        } else {
            Style::default()
        };

        let mut items: Vec<ListItem> = Vec::new();

        if let Some(ref graph) = self.state.graph {
            for (node_id, node) in &graph.nodes {
                let icon = node_status_icon(&node.status);
                let color = node_status_color(&node.status);
                let indent = "  ".repeat(node.depth);
                let is_selected = self.state.active_node.as_deref() == Some(node_id);
                let marker = if is_selected { "▸" } else { " " };

                let label_short = if node.label.len() > 20 {
                    format!("{}…", &node.label[..18])
                } else {
                    node.label.clone()
                };

                let style = if is_selected {
                    Style::default()
                        .fg(color)
                        .bg(Color::DarkGray)
                        .add_modifier(Modifier::BOLD)
                } else {
                    Style::default().fg(color)
                };

                let line = format!(" {marker}{indent}{icon} {label_short}");
                items.push(ListItem::new(line).style(style));
            }
        }

        if items.is_empty() {
            items.push(ListItem::new(" (no nodes)").style(Style::default().fg(Color::DarkGray)));
        }

        let list = List::new(items)
            .block(
                Block::default()
                    .borders(Borders::ALL)
                    .border_style(border_style)
                    .title(" Nodes "),
            )
            .highlight_style(Style::default().add_modifier(Modifier::BOLD));

        let mut list_state = ratatui::widgets::ListState::default();
        if let Some(ref active) = self.state.active_node {
            if let Some(idx) = self
                .state
                .graph
                .as_ref()
                .and_then(|g| g.nodes.keys().position(|id| id == active))
            {
                list_state.select(Some(idx));
            }
        }

        frame.render_stateful_widget(list, area, &mut list_state);
    }

    // ── Graph canvas (center panel) ──

    fn render_graph_canvas(&self, frame: &mut Frame, area: Rect) {
        let has_focus = self.state.focus_panel == PanelFocus::GraphCanvas;
        let border_style = if has_focus {
            Style::default().fg(Color::Cyan)
        } else {
            Style::default()
        };

        let mut lines: Vec<Line> = Vec::new();
        let graph_width = area.width as usize;

        if let Some(ref graph) = self.state.graph {
            if self.layout.levels.is_empty() {
                lines.push(Line::from(Span::styled(
                    " (empty graph)",
                    Style::default().fg(Color::DarkGray),
                )));
            } else {
                // Render edges as connection lines between nodes
                for (edge_id, edge) in &graph.edges {
                    if let (Some(from), Some(to)) = (
                        self.layout.position_of(&edge.source),
                        self.layout.position_of(&edge.target),
                    ) {
                        let _ = edge_id;
                        // Only draw if both nodes are in viewport
                        if from.1 >= area.top()
                            && from.1 < area.bottom()
                            && to.1 >= area.top()
                            && to.1 < area.bottom()
                        {
                            let from_y = from.1.saturating_sub(area.top()) as usize;
                            let to_y = to.1.saturating_sub(area.top()) as usize;
                            let from_x = from.0.saturating_sub(area.left()) as usize;
                            let to_x = to.0.saturating_sub(area.left()) as usize;

                            // Extend lines array to fit
                            while lines.len() <= from_y.max(to_y) {
                                let line_chars: Vec<char> =
                                    std::iter::repeat(' ').take(graph_width).collect();
                                let line_str: String = line_chars.into_iter().collect();
                                lines.push(Line::from(line_str));
                            }
                            // Draw vertical line
                            let mid_x = from_x.min(to_x) + from_x.abs_diff(to_x) / 2;
                            let min_y = from_y.min(to_y);
                            let max_y = from_y.max(to_y);
                            for y in min_y..=max_y {
                                if y < lines.len() {
                                    let line_str = lines[y].to_string();
                                    let mut chars: Vec<char> = line_str.chars().collect();
                                    if mid_x < chars.len() {
                                        chars[mid_x] = '│';
                                    }
                                    lines[y] = Line::from(chars.into_iter().collect::<String>());
                                }
                            }
                            // Draw horizontal line
                            let y = to_y;
                            if y < lines.len() {
                                let line_str = lines[y].to_string();
                                let mut chars: Vec<char> = line_str.chars().collect();
                                for x in from_x.min(to_x)..=from_x.max(to_x) {
                                    if x < chars.len() {
                                        if x == from_x.min(to_x) {
                                            chars[x] = '├';
                                        } else if x == from_x.max(to_x) {
                                            chars[x] = '┤';
                                        } else {
                                            chars[x] = '─';
                                        }
                                    }
                                }
                                lines[y] = Line::from(chars.into_iter().collect::<String>());
                            }
                        }
                    }
                }

                // Render nodes as boxes
                for (node_id, node) in &graph.nodes {
                    if let Some(pos) = self.layout.position_of(node_id) {
                        let screen_x = pos.0.saturating_sub(area.left()) as usize;
                        let screen_y = pos.1.saturating_sub(area.top()) as usize;

                        let is_selected = self.state.active_node.as_deref() == Some(node_id);
                        let color = node_status_color(&node.status);

                        let _border_color = if is_selected { Color::White } else { color };

                        let label_short = if node.label.len() > 10 {
                            format!("{}…", &node.label[..9])
                        } else {
                            node.label.clone()
                        };

                        let pad = "─".repeat(12);
                        let top_line = format!("┌{}┐", pad);
                        let mid_line = format!("│ {:<10} │", label_short);
                        let bot_line = format!("└{}┘", pad);

                        // Extend lines if needed
                        while lines.len() <= screen_y + 2 {
                            let empty: String = std::iter::repeat(' ').take(graph_width).collect();
                            lines.push(Line::from(empty));
                        }

                        // Write three lines for the node box
                        if screen_y < lines.len() {
                            let line_str = lines[screen_y].to_string();
                            let mut chars: Vec<char> = line_str.chars().collect();
                            for (i, c) in top_line.chars().enumerate() {
                                let x = screen_x + i;
                                if x < chars.len() {
                                    chars[x] = c;
                                }
                            }
                            lines[screen_y] = Line::from(chars.into_iter().collect::<String>());
                        }

                        if screen_y + 1 < lines.len() {
                            let line_str = lines[screen_y + 1].to_string();
                            let mut chars: Vec<char> = line_str.chars().collect();
                            for (i, c) in mid_line.chars().enumerate() {
                                let x = screen_x + i;
                                if x < chars.len() {
                                    chars[x] = c;
                                }
                            }
                            lines[screen_y + 1] = Line::from(chars.into_iter().collect::<String>());
                        }

                        if screen_y + 2 < lines.len() {
                            let line_str = lines[screen_y + 2].to_string();
                            let mut chars: Vec<char> = line_str.chars().collect();
                            for (i, c) in bot_line.chars().enumerate() {
                                let x = screen_x + i;
                                if x < chars.len() {
                                    chars[x] = c;
                                }
                            }
                            lines[screen_y + 2] = Line::from(chars.into_iter().collect::<String>());
                        }
                    }
                }
            }
        } else {
            lines.push(Line::from(Span::styled(
                " (no graph loaded)",
                Style::default().fg(Color::DarkGray),
            )));
        }

        if lines.is_empty() {
            lines.push(Line::from(Span::styled(
                " (no data)",
                Style::default().fg(Color::DarkGray),
            )));
        }

        let para = Paragraph::new(Text::from(lines)).block(
            Block::default()
                .borders(Borders::ALL)
                .border_style(border_style)
                .title(" Canvas "),
        );
        frame.render_widget(para, area);
    }

    // ── Inspector (right panel) ──

    fn render_inspector(&self, frame: &mut Frame, area: Rect) {
        let has_focus = self.state.focus_panel == PanelFocus::Inspector;
        let border_style = if has_focus {
            Style::default().fg(Color::Cyan)
        } else {
            Style::default()
        };

        let lines = if let Some(ref active_id) = self.state.active_node {
            if let Some(ref graph) = self.state.graph {
                if let Some(node) = graph.get_node(active_id) {
                    let icon = node_status_icon(&node.status);
                    let color = node_status_color(&node.status);

                    vec![
                        Line::from(Span::styled(
                            format!(" {icon} {} [{}]", node.label, node.id),
                            Style::default().fg(color).add_modifier(Modifier::BOLD),
                        )),
                        Line::from(""),
                        Line::from(Span::styled(
                            format!(" Kind:     {:?}", node.kind),
                            Style::default().fg(Color::White),
                        )),
                        Line::from(Span::styled(
                            format!(" Status:   {:?}", node.status),
                            Style::default().fg(color),
                        )),
                        Line::from(Span::styled(
                            format!(" Hash:     {}", &node.hash[..node.hash.len().min(16)]),
                            Style::default().fg(Color::Cyan),
                        )),
                        Line::from(Span::styled(
                            format!(" Depth:    {}", node.depth),
                            Style::default().fg(Color::White),
                        )),
                        Line::from(""),
                        Line::from(Span::styled(
                            format!(" Parents:  {}", node.parents.join(", ")),
                            Style::default().fg(Color::Yellow),
                        )),
                        Line::from(Span::styled(
                            format!(" Children: {}", node.children.join(", ")),
                            Style::default().fg(Color::Green),
                        )),
                        Line::from(""),
                        Line::from(Span::styled(
                            format!(" Created:  {}", node.created_at.format("%H:%M:%S")),
                            Style::default().fg(Color::DarkGray),
                        )),
                        Line::from(Span::styled(
                            format!(" Updated:  {}", node.updated_at.format("%H:%M:%S")),
                            Style::default().fg(Color::DarkGray),
                        )),
                        Line::from(""),
                        Line::from(Span::styled(
                            " Description:",
                            Style::default()
                                .fg(Color::White)
                                .add_modifier(Modifier::UNDERLINED),
                        )),
                        Line::from(Span::styled(
                            &node.description,
                            Style::default().fg(Color::Gray),
                        )),
                    ]
                } else {
                    vec![Line::from(Span::styled(
                        " (node not found)",
                        Style::default().fg(Color::DarkGray),
                    ))]
                }
            } else {
                vec![Line::from(Span::styled(
                    " (no graph loaded)",
                    Style::default().fg(Color::DarkGray),
                ))]
            }
        } else {
            vec![
                Line::from(Span::styled(
                    " No node selected",
                    Style::default().fg(Color::DarkGray),
                )),
                Line::from(""),
                Line::from(Span::styled(
                    " Select a node in the",
                    Style::default().fg(Color::DarkGray),
                )),
                Line::from(Span::styled(
                    " tree or canvas to",
                    Style::default().fg(Color::DarkGray),
                )),
                Line::from(Span::styled(
                    " view its details here.",
                    Style::default().fg(Color::DarkGray),
                )),
            ]
        };

        let para = Paragraph::new(Text::from(lines))
            .block(
                Block::default()
                    .borders(Borders::ALL)
                    .border_style(border_style)
                    .title(" Inspector "),
            )
            .wrap(Wrap { trim: false });
        frame.render_widget(para, area);
    }

    // ── Timeline / Event log (bottom panel) ──

    fn render_timeline(&self, frame: &mut Frame, area: Rect) {
        let has_focus = self.state.focus_panel == PanelFocus::Timeline;
        let border_style = if has_focus {
            Style::default().fg(Color::Cyan)
        } else {
            Style::default()
        };

        let max_visible = (area.height as usize).saturating_sub(2); // account for borders
        let events: Vec<ListItem> = self
            .state
            .event_log
            .iter()
            .rev()
            .take(max_visible)
            .map(|event| {
                let color = severity_color(&event.severity);
                let line = format_event_line(event);
                ListItem::new(line).style(Style::default().fg(color))
            })
            .collect();

        let list = List::new(events).block(
            Block::default()
                .borders(Borders::ALL)
                .border_style(border_style)
                .title(" Timeline "),
        );
        frame.render_widget(list, area);
    }
}
