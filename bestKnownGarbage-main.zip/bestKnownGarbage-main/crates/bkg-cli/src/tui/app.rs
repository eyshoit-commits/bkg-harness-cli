//! TUI Application — terminal dashboard for chain execution.
//!
//! Uses ratatui with crossterm backend. Three tabs:
//! 1. Chat — prompt input and response
//! 2. Chain — link-by-link progress with truth gates
//! 3. Config — model routing per agent role

use std::io;
use std::sync::Arc;

use crossterm::{
    ExecutableCommand,
    event::{self, Event, KeyCode, KeyEventKind},
    terminal::{EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode, enable_raw_mode},
};
use ratatui::{
    Frame, Terminal,
    backend::{Backend, CrosstermBackend},
    layout::{Constraint, Direction, Layout, Rect},
    style::{Modifier, Style},
    text::{Line, Span, Text},
    widgets::{Block, Borders, List, ListItem, Paragraph, Tabs},
};

use super::status::{
    AgentEvent, CapsuleEventKind, SwdEventKind, TrustEventKind, StatusBus
};
use super::atlantean::{colors, styles, symbols, atlantean_title, progress_indicator};
use crate::agent::Coordinator;
use crate::chain::CliLinkExecutor;
use crate::router::ChainBuilder;
use crate::model_router::ModelRouter;
use bkg_core::chain::{Chain, LinkStatus};
use bkg_provider::registry::ProviderRegistry;

/// Application state for the TUI.
pub struct TuiApp {
    /// Coordinator for running prompts.
    coordinator: Option<Arc<Coordinator>>,
    /// Status bus for agent events.
    status_bus: StatusBus,
    /// Default model used to build chains.
    default_model: Option<String>,
    /// Current chain being executed.
    chain: Option<Chain>,
    /// Chat input buffer.
    chat_input: String,
    /// Chat message history.
    chat_history: Vec<String>,
    /// Active tab index.
    active_tab: usize,
    /// Should quit.
    should_quit: bool,
    /// Error message to display.
    error: Option<String>,
    /// Tab names.
    tab_titles: Vec<&'static str>,
    /// Agent event log (for the agent activity view).
    agent_log: Vec<(String, AgentEvent)>,
    /// Streaming response buffer.
    streaming_buffer: String,
    /// Whether we're currently streaming.
    is_streaming: bool,
    // ── System State for Config Tab ──
    /// Provider registry for dynamic model listing
    provider_registry: Option<ProviderRegistry>,
    /// ModelRouter for dynamic routing display
    model_router: Option<ModelRouter>,
    /// Capsule health state
    capsule_state: String,
    /// Trust layer state
    trust_state: String,
    /// Healing state
    healing_state: String,
    /// SWD state
    swd_state: String,
    /// Route assignments (role -> model)
    route_assignments: std::collections::HashMap<String, String>,
    /// Number of healing cycles completed
    healing_cycles: u32,
    /// Whether healing is active
    healing_active: bool,
    /// Capsule event count per kind
    capsule_event_counts: std::collections::HashMap<String, u32>,
    /// Trust event count per kind
    trust_event_counts: std::collections::HashMap<String, u32>,
    /// SWD event count
    swd_event_count: u32,
    /// Healing event count
    heal_event_count: u32,
}

impl TuiApp {
    pub fn new(status_bus: StatusBus, default_model: Option<String>) -> Self {
        let mut route_assignments = std::collections::HashMap::new();
        route_assignments.insert("planner".to_string(), "auto-route".to_string());
        route_assignments.insert("coder".to_string(), "auto-route".to_string());
        route_assignments.insert("reviewer".to_string(), "auto-route".to_string());
        route_assignments.insert("docs".to_string(), "auto-route".to_string());
        route_assignments.insert("overseer".to_string(), "auto-route".to_string());
        let mut capsule_counts = std::collections::HashMap::new();
        capsule_counts.insert("Healthy".to_string(), 0u32);
        capsule_counts.insert("Degraded".to_string(), 0u32);
        capsule_counts.insert("Missing".to_string(), 0u32);
        capsule_counts.insert("Repaired".to_string(), 0u32);
        capsule_counts.insert("Rehydrated".to_string(), 0u32);
        let mut trust_counts = std::collections::HashMap::new();
        trust_counts.insert("DriftDetected".to_string(), 0u32);
        trust_counts.insert("DriftResolved".to_string(), 0u32);
        trust_counts.insert("TruthVerified".to_string(), 0u32);
        trust_counts.insert("Divergence".to_string(), 0u32);
        Self {
            coordinator: None,
            status_bus,
            default_model,
            chain: None,
            chat_input: String::new(),
            chat_history: Vec::new(),
            active_tab: 0,
            should_quit: false,
            error: None,
            tab_titles: vec!["Chat", "Chain", "Agents", "Config"],
            agent_log: Vec::new(),
            streaming_buffer: String::new(),
            is_streaming: false,
            provider_registry: None,
            model_router: None,
            capsule_state: "initializing".to_string(),
            trust_state: "monitoring".to_string(),
            healing_state: "standby".to_string(),
            swd_state: "active".to_string(),
            route_assignments,
            healing_cycles: 0,
            healing_active: false,
            capsule_event_counts: capsule_counts,
            trust_event_counts: trust_counts,
            swd_event_count: 0,
            heal_event_count: 0,
        }
    }

    /// Set the coordinator.
    pub fn set_coordinator(&mut self, coordinator: Arc<Coordinator>) {
        self.coordinator = Some(coordinator);
    }

    /// Set the provider registry for dynamic config display.
    pub fn set_provider_registry(&mut self, registry: ProviderRegistry) {
        self.provider_registry = Some(registry);
    }

    /// Set the model router for dynamic config display.
    pub fn set_model_router(&mut self, router: ModelRouter) {
        let task_types = ["planner", "coder", "reviewer", "docs", "overseer"];
        for role in task_types {
            self.route_assignments.insert(role.to_string(), "routing…".to_string());
        }
        self.model_router = Some(router);
    }

    /// Set the chain.
    pub fn set_chain(&mut self, chain: Chain) {
        self.chain = Some(chain);
    }

    /// Add a chat message to history.
    pub fn add_chat(&mut self, text: String) {
        self.chat_history.push(text);
    }

    /// Log an agent event.
    pub fn log_event(&mut self, agent_id: String, event: AgentEvent) {
        self.agent_log.push((agent_id, event));
        // Keep last 1000 events
        if self.agent_log.len() > 1000 {
            self.agent_log.remove(0);
        }
    }

    /// Drain status bus events.
    pub fn drain_events(&mut self) {
        let mut rx = self.status_bus.subscribe();
        while let Ok((agent_id, event)) = rx.try_recv() {
            // Track system state from events
            match &event {
                AgentEvent::CapsuleEvent { state, .. } => {
                    let key = format!("{:?}", state);
                    *self.capsule_event_counts.entry(key.clone()).or_insert(0) += 1;
                    self.capsule_state = match state {
                        CapsuleEventKind::Healthy => "healthy".to_string(),
                        CapsuleEventKind::Degraded => "degraded".to_string(),
                        CapsuleEventKind::Missing => "missing".to_string(),
                        CapsuleEventKind::Repaired => "repaired".to_string(),
                        CapsuleEventKind::Rehydrated => "rehydrated".to_string(),
                    };
                }
                AgentEvent::TrustEvent { kind, .. } => {
                    let key = match kind {
                        TrustEventKind::TruthVerified => "TruthVerified",
                        TrustEventKind::DriftDetected => "DriftDetected",
                        TrustEventKind::DriftResolved => "DriftResolved",
                        TrustEventKind::Divergence { .. } => "Divergence",
                    };
                    *self.trust_event_counts.entry(key.to_string()).or_insert(0) += 1;
                    self.trust_state = match kind {
                        TrustEventKind::TruthVerified => "verified".to_string(),
                        TrustEventKind::DriftDetected => "drift!".to_string(),
                        TrustEventKind::DriftResolved => "resolved".to_string(),
                        TrustEventKind::Divergence { .. } => "divergence".to_string(),
                    };
                }
                AgentEvent::SwdEvent { .. } => {
                    self.swd_event_count += 1;
                }
                AgentEvent::HealEvent { .. } => {
                    self.heal_event_count += 1;
                    self.healing_cycles += 1;
                    self.healing_active = true;
                    self.healing_state = "active".to_string();
                }
                AgentEvent::RouteEvent { role, model, .. } => {
                    self.route_assignments.insert(role.clone(), model.clone());
                }
                _ => {}
            }
            self.log_event(agent_id, event);
        }
    }

    /// Set error message.
    pub fn set_error(&mut self, error: String) {
        self.error = Some(error);
    }

    /// Start streaming response.
    pub fn start_streaming(&mut self) {
        self.is_streaming = true;
        self.streaming_buffer.clear();
    }

    /// Append to streaming buffer.
    pub fn append_stream(&mut self, chunk: &str) {
        self.streaming_buffer.push_str(chunk);
    }

    /// Finish streaming and add to history.
    pub fn finish_stream(&mut self) {
        if !self.streaming_buffer.is_empty() {
            self.chat_history
                .push(format!("AI: {}", self.streaming_buffer.trim()));
            self.streaming_buffer.clear();
        }
        self.is_streaming = false;
    }
}

/// Run the TUI event loop.
pub async fn run_tui(status_bus: StatusBus, coordinator: Coordinator, default_model: Option<String>, registry: Option<ProviderRegistry>, model_router: Option<ModelRouter>) -> io::Result<()> {
    enable_raw_mode()?;
    let mut stdout = io::stdout();
    stdout.execute(EnterAlternateScreen)?;

    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend)?;

    let mut app = TuiApp::new(status_bus, default_model);
    app.set_coordinator(Arc::new(coordinator));
    if let Some(reg) = registry {
        app.set_provider_registry(reg);
    }
    if let Some(router) = model_router {
        app.set_model_router(router);
    }
    let res = run_app(&mut terminal, &mut app).await;

    disable_raw_mode()?;
    terminal.backend_mut().execute(LeaveAlternateScreen)?;
    terminal.show_cursor()?;

    res
}

async fn run_app<B: Backend>(terminal: &mut Terminal<B>, app: &mut TuiApp) -> io::Result<()> {
    while !app.should_quit {
        app.drain_events();

        terminal.draw(|f| ui(f, app))?;

        if event::poll(std::time::Duration::from_millis(200))? {
            if let Event::Key(key) = event::read()? {
                if key.kind == KeyEventKind::Press {
                    handle_key(app, key).await;
                }
            }
        }
    }
    Ok(())
}

async fn handle_key(app: &mut TuiApp, key: crossterm::event::KeyEvent) {
    match key.code {
        KeyCode::Char('q') if app.active_tab != 0 => {
            // Only quit from chat tab
        }
        KeyCode::Char('Q') | KeyCode::Esc => {
            app.should_quit = true;
        }
        KeyCode::Char('1') => app.active_tab = 0,
        KeyCode::Char('2') => app.active_tab = 1,
        KeyCode::Char('3') => app.active_tab = 2,
        KeyCode::Char('4') => app.active_tab = 3,
        KeyCode::Tab => {
            app.active_tab = (app.active_tab + 1) % app.tab_titles.len();
        }
        KeyCode::BackTab => {
            app.active_tab = if app.active_tab == 0 {
                app.tab_titles.len() - 1
            } else {
                app.active_tab - 1
            };
        }
        KeyCode::Enter if app.active_tab == 0 => {
            let input = app.chat_input.trim().to_string();
            if input.is_empty() {
                return;
            }

            app.chat_history.push(format!("> {}", input));
            app.chat_input.clear();
            app.error = None;

            let coordinator = match app.coordinator.clone() {
                Some(coord) => coord,
                None => {
                    app.set_error("No coordinator attached to TUI".to_string());
                    return;
                }
            };

            let default_model = app
                .default_model
                .clone()
                .unwrap_or_else(|| "mistral-7b".to_string());

            let status_bus = app.status_bus.clone();
            let mut builder = ChainBuilder::new()
                .with_status_bus(status_bus.clone())
                .with_default_model(&default_model);
            let mut chain = builder.build(&input);
            let executor = CliLinkExecutor::new_with_coordinator(coordinator.clone(), chain.id.clone())
                .with_status_bus(status_bus.clone());

            match builder.run(&mut chain, &executor).await {
                Ok(_report) => {
                    if let Some(last_link) = chain.links.last() {
                        if let Some(result) = &last_link.result {
                            app.chat_history.push(format!("AI: {}", result.output.trim()));
                        }
                    }
                    app.set_chain(chain);
                }
                Err(err) => {
                    app.set_error(err.to_string());
                }
            }
        }
        KeyCode::Char(c) if app.active_tab == 0 => {
            app.chat_input.push(c);
        }
        KeyCode::Backspace if app.active_tab == 0 => {
            app.chat_input.pop();
        }
        _ => {}
    }
}

fn ui(frame: &mut Frame, app: &TuiApp) {
    let area = frame.area();

    // Atlantean Tab bar - Gold on Void
    let tab_items: Vec<_> = app.tab_titles
        .iter()
        .enumerate()
        .map(|(i, title)| {
            let style = if i == app.active_tab {
                styles::active()
            } else {
                styles::inactive()
            };
            Line::from(Span::styled(
                format!(" {} {} ", symbols::THALASSA, title),
                style,
            ))
        })
        .collect();

    let divider_str = format!(" {} ", symbols::STYX);
    let tabs = Tabs::new(tab_items)
        .block(
            Block::default()
                .borders(Borders::ALL)
                .border_style(styles::title())
                .title(atlantean_title("nucleus", "BKG Interface")),
        )
        .divider(&divider_str)
        .padding(" ", " ");

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(3), Constraint::Min(0)])
        .split(area);

    frame.render_widget(tabs, chunks[0]);

    match app.active_tab {
        0 => render_chat(frame, chunks[1], app),
        1 => render_chain(frame, chunks[1], app),
        2 => render_agents(frame, chunks[1], app),
        3 => render_config(frame, chunks[1], app),
        _ => {}
    }

    // Atlantean status bar
    let status_text = match &app.error {
        Some(e) => format!(" {} DIVERGENCE: {} ", symbols::DIVERGENCE, e),
        None => format!(
            " {} BKG {} | Tab 1-4 | Q: quit | Tab: next | {}",
            symbols::ARCHE,
            symbols::THALASSA,
            if app.chain.is_some() {
                format!("{} Chain active", symbols::VERIFIED)
            } else {
                format!("{} No chain", symbols::STOPPED)
            }
        ),
    };
    let status_style = if app.error.is_some() {
        styles::divergence()
    } else {
        Style::default().fg(colors::NUCLEUS).bg(colors::VOID)
    };
    let status_bar = Paragraph::new(Text::from(status_text)).style(status_style);
    frame.render_widget(status_bar, Rect::new(0, area.height - 1, area.width, 1));
}

fn render_chat(frame: &mut Frame, area: Rect, app: &TuiApp) {
    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Min(0), Constraint::Length(3)])
        .split(area);

    // Chat history with streaming buffer
    let mut display_messages: Vec<String> = app.chat_history.clone();
    if app.is_streaming && !app.streaming_buffer.is_empty() {
        display_messages.push(format!("{} {}", symbols::STREAMING, app.streaming_buffer.trim()));
    }

    let messages: Vec<ListItem> = display_messages
        .iter()
        .map(|msg| {
            let style = if msg.starts_with(">") {
                styles::accent()
            } else if msg.starts_with("AI:") {
                styles::verified()
            } else {
                Style::default().fg(colors::NUCLEUS)
            };
            ListItem::new(msg.as_str()).style(style)
        })
        .collect();

    let chat_title = if app.is_streaming {
        atlantean_title("thalassa", "Oracle Portal (streaming)")
    } else {
        atlantean_title("thalassa", "Oracle Portal")
    };

    let chat_block = Block::default()
        .borders(Borders::ALL)
        .title(chat_title)
        .border_style(if app.is_streaming {
            styles::streaming()
        } else {
            styles::header()
        });

    let chat_list = List::new(messages).block(chat_block);
    frame.render_widget(chat_list, chunks[0]);

    // Input portal
    let input = Paragraph::new(app.chat_input.as_str())
        .block(
            Block::default()
                .borders(Borders::ALL)
                .title(atlantean_title("arche", "Input Portal"))
                .border_style(styles::accent()),
        )
        .style(styles::accent());
    frame.render_widget(input, chunks[1]);
}

fn render_chain(frame: &mut Frame, area: Rect, app: &TuiApp) {
    let chain = match &app.chain {
        Some(c) => c,
        None => {
            let msg = Paragraph::new(format!(
                "{} No chain. Run a command with 'bkg chat \"prompt\"'",
                symbols::DIVERGENCE
            ))
            .block(
                Block::default()
                    .borders(Borders::ALL)
                    .title(atlantean_title("styx", "Tapestry of Causality"))
                    .border_style(styles::muted()),
            )
            .style(styles::muted());
            frame.render_widget(msg, area);
            return;
        }
    };

    let chunks = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Length(3), Constraint::Min(0)])
        .split(area);

    // Chain header with Atlantean symbols
    let (pending, running, passed, failed) = chain.counts();
    let header = format!(
        " {} Chain: {} | Links: {} total | {} pending | {} running | {} {} | {} {}",
        symbols::STYX,
        chain.id,
        chain.links.len(),
        pending,
        running,
        symbols::VERIFIED, passed,
        symbols::DIVERGENCE, failed
    );
    let header_para = Paragraph::new(header)
        .block(
            Block::default()
                .borders(Borders::ALL)
                .border_style(styles::header()),
        )
        .style(styles::header());
    frame.render_widget(header_para, chunks[0]);

    // Link list with Atlantean status indicators
    let mut items: Vec<ListItem> = Vec::new();
    for (i, link) in chain.links.iter().enumerate() {
        let status_icon = match &link.status {
            LinkStatus::Pending => symbols::STOPPED,
            LinkStatus::Running => symbols::RUNNING,
            LinkStatus::Passed => symbols::VERIFIED,
            LinkStatus::Failed(_) => symbols::DIVERGENCE,
            LinkStatus::Skipped => "○",
        };
        let role = &link.context.agent_role;
        let _model = &link.context.model;
        let desc = &link.description;
        let desc_short = if desc.len() > 40 {
            format!("{}…", &desc[..37])
        } else {
            desc.clone()
        };

        let style = match &link.status {
            LinkStatus::Passed => styles::verified(),
            LinkStatus::Failed(_) => styles::divergence(),
            LinkStatus::Running => styles::streaming(),
            _ => styles::muted(),
        };

        let line = format!(
            " {} Link {} [{}{}{}] {}",
            status_icon,
            i + 1,
            symbols::THALASSA,
            role,
            symbols::THALASSA,
            desc_short
        );
        items.push(ListItem::new(line).style(style));
    }

    let link_list = List::new(items).block(
        Block::default()
            .borders(Borders::ALL)
            .title(atlantean_title("styx", "Causal Links"))
            .border_style(styles::header()),
    );
    frame.render_widget(link_list, chunks[1]);
}

fn render_agents(frame: &mut Frame, area: Rect, app: &TuiApp) {
    let events: Vec<ListItem> = app
        .agent_log
        .iter()
        .rev()
        .take(area.height as usize - 2)
        .map(|(agent_id, event)| {
            let (symbol, style) = match event {
                AgentEvent::Done { .. } => (symbols::VERIFIED, styles::verified()),
                AgentEvent::Error { .. } => (symbols::DIVERGENCE, styles::divergence()),
                AgentEvent::ToolCall { .. } => (symbols::STYX, Style::default().fg(colors::STYX)),
                AgentEvent::ToolResult { .. } => (symbols::THALASSA, styles::accent()),
                AgentEvent::Response { .. } => (symbols::NUCLEUS, Style::default().fg(colors::NUCLEUS)),
                AgentEvent::Thinking => (symbols::STREAMING, styles::muted()),
                AgentEvent::CapsuleEvent { state, .. } => {
                    let color = match state {
                        CapsuleEventKind::Healthy => colors::VERIFIED,
                        CapsuleEventKind::Degraded => colors::STYX,
                        CapsuleEventKind::Missing => colors::DIVERGENCE,
                        CapsuleEventKind::Repaired => colors::ANAMNESIS,
                        CapsuleEventKind::Rehydrated => colors::THALASSA,
                    };
                    (symbols::ARCHE, Style::default().fg(color))
                }
                AgentEvent::TrustEvent { kind, .. } => {
                    match kind {
                        TrustEventKind::DriftDetected => (symbols::DIVERGENCE, styles::divergence()),
                        TrustEventKind::DriftResolved => (symbols::VERIFIED, styles::verified()),
                        TrustEventKind::TruthVerified => (symbols::KATOPTRON, Style::default().fg(colors::KATOPTRON)),
                        TrustEventKind::Divergence { .. } => (symbols::DIVERGENCE, Style::default().fg(colors::DIVERGENCE)),
                    }
                }
                AgentEvent::SwdEvent { kind, .. } => {
                    let color = match kind {
                        SwdEventKind::WriteBlocked => colors::DIVERGENCE,
                        SwdEventKind::WriteAllowed => colors::VERIFIED,
                        SwdEventKind::IntegrityCheck => colors::KATOPTRON,
                        SwdEventKind::SnapshotCreated => colors::ANAMNESIS,
                    };
                    (symbols::STYX, Style::default().fg(color))
                }
                AgentEvent::HealEvent { .. } => (symbols::ANAMNESIS, Style::default().fg(colors::ANAMNESIS).add_modifier(Modifier::BOLD)),
                AgentEvent::RouteEvent { .. } => (symbols::MNEMOS, Style::default().fg(colors::MNEMOS)),
            };
            let line = format!(" {} [{}] {}", symbol, agent_id, event);
            ListItem::new(line).style(style)
        })
        .collect();

    let event_list = List::new(events).block(
        Block::default()
            .borders(Borders::ALL)
            .title(atlantean_title("anamnesis", "Scroll of Ages"))
            .border_style(styles::header()),
    );
    frame.render_widget(event_list, area);
}

fn render_config(frame: &mut Frame, area: Rect, app: &TuiApp) {
    // Build dynamic config display with real system state

    // ── Provider info ──
    let provider_info = match &app.provider_registry {
        Some(reg) => {
            let names = reg.list();
            if names.is_empty() {
                "none configured".to_string()
            } else {
                format!("{} provider(s): {}", names.len(), names.join(", "))
            }
        }
        None => "not connected".to_string(),
    };

    // ── Route assignments ──
    let mut route_lines: Vec<String> = Vec::new();
    let roles = ["planner", "coder", "reviewer", "docs", "overseer"];
    for role in &roles {
        let model = app.route_assignments.get(*role).map(|s| s.as_str()).unwrap_or("?");
        route_lines.push(format!(
            " {} {:<12} {} {}",
            symbols::STYX, role, symbols::ARROW_RIGHT, model
        ));
    }

    // ── Capsule status indicators ──
    let capsule_healthy = *app.capsule_event_counts.get("Healthy").unwrap_or(&0);
    let capsule_degraded = *app.capsule_event_counts.get("Degraded").unwrap_or(&0);
    let capsule_missing = *app.capsule_event_counts.get("Missing").unwrap_or(&0);
    let capsule_repaired = *app.capsule_event_counts.get("Repaired").unwrap_or(&0);
    let capsule_rehydrated = *app.capsule_event_counts.get("Rehydrated").unwrap_or(&0);
    let capsule_total = capsule_healthy + capsule_degraded + capsule_missing + capsule_repaired + capsule_rehydrated;
    let capsule_health_pct = if capsule_total > 0 {
        (capsule_healthy as f64 / capsule_total as f64) * 100.0
    } else {
        100.0
    };

    // ── Trust indicators ──
    let trust_verified = *app.trust_event_counts.get("TruthVerified").unwrap_or(&0);
    let trust_drift = *app.trust_event_counts.get("DriftDetected").unwrap_or(&0);
    let trust_divergence = *app.trust_event_counts.get("Divergence").unwrap_or(&0);
    let trust_total = trust_verified + trust_drift + trust_divergence;
    let trust_score = if trust_total > 0 {
        (trust_verified as f64 / trust_total as f64) * 100.0
    } else {
        100.0
    };

    // ── Build lines ──
    let model_line = format!(
        " {} Provider: {} | Default model: {}",
        symbols::ARCHE,
        provider_info,
        app.default_model.as_deref().unwrap_or("none"),
    );

    let _sep = format!(" {} {}", symbols::STYX, "─".repeat(area.width.saturating_sub(4) as usize));

    let _config_lines = vec![
        format!(" {} MODEL ROUTING PER ROLE", symbols::KATOPTRON),
        format!(" {:<80}", "━".to_string()),
    ];

    let mut text = Text::default();

    // Title
    text.push_line(Line::styled(
        format!(" {} {} ", symbols::MNEMOS, "CODEX OF LAWS — SYSTEM CONFIGURATION"),
        Style::default().fg(colors::MNEMOS).add_modifier(Modifier::BOLD),
    ));
    text.push_line(Line::styled("", Style::default()));
    text.push_line(Line::styled(&model_line, Style::default().fg(colors::ARCHE).add_modifier(Modifier::BOLD)));
    text.push_line(Line::styled("", Style::default()));

    // ── ROUTING TABLE ──
    text.push_line(Line::styled(
        format!(" {} ROUTING TABLE", symbols::THALASSA),
        Style::default().fg(colors::THALASSA).add_modifier(Modifier::BOLD),
    ));
    text.push_line(Line::styled(
        format!(" {} {:<14} │ {:<30}", symbols::KATOPTRON, "ROLE", "ASSIGNED MODEL"),
        styles::muted(),
    ));
    text.push_line(Line::styled(
        format!(" {} {}", symbols::STYX, "─".repeat(48)),
        styles::muted(),
    ));
    for role in &roles {
        let model = app.route_assignments.get(*role).map(|s| s.as_str()).unwrap_or("auto-route");
        let color = if model.contains("70b") || model.contains("32b") {
            colors::ARCHE
        } else if model.contains("coder") {
            colors::ANAMNESIS
        } else if model == "auto-route" || model == "routing…" {
            colors::KATOPTRON
        } else {
            colors::NUCLEUS
        };
        text.push_line(Line::styled(
            format!(" {} {:<14} │ {}", symbols::MNEMOS, role, model),
            Style::default().fg(color),
        ));
    }
    text.push_line(Line::styled("", Style::default()));

    // ── SYSTEM STATUS ──
    text.push_line(Line::styled(
        format!(" {} SYSTEM STATUS", symbols::NUCLEUS),
        Style::default().fg(colors::NUCLEUS).add_modifier(Modifier::BOLD),
    ));
    text.push_line(Line::styled(
        format!(" {} {}", symbols::STYX, "─".repeat(60)),
        styles::muted(),
    ));

    // Capsule state (healthy/degraded/missing count)
    let capsule_sym = if capsule_health_pct >= 90.0 {
        symbols::VERIFIED
    } else if capsule_health_pct >= 50.0 {
        symbols::STOPPED
    } else {
        symbols::DIVERGENCE
    };
    let capsule_color = if capsule_health_pct >= 90.0 {
        colors::VERIFIED
    } else if capsule_health_pct >= 50.0 {
        colors::STYX
    } else {
        colors::DIVERGENCE
    };
    text.push_line(Line::styled(
        format!(" {} Capsule:  {} ({} total — {}✓ {}⚠ {}✗ {}🔧 {}💧 | health: {:.0}%)",
            capsule_sym, app.capsule_state, capsule_total,
            capsule_healthy, capsule_degraded, capsule_missing, capsule_repaired, capsule_rehydrated,
            capsule_health_pct,
        ),
        Style::default().fg(capsule_color),
    ));

    // Trust state
    let trust_sym = if trust_score >= 90.0 { symbols::VERIFIED }
                    else if trust_score >= 50.0 { symbols::STOPPED }
                    else { symbols::DIVERGENCE };
    let trust_color = if trust_score >= 90.0 { colors::VERIFIED }
                      else if trust_score >= 50.0 { colors::STYX }
                      else { colors::DIVERGENCE };
    text.push_line(Line::styled(
        format!(" {} Trust:    {} (score: {:.0}% — {}✓ drift: {} divergence: {})",
            trust_sym, app.trust_state, trust_score, trust_verified, trust_drift, trust_divergence,
        ),
        Style::default().fg(trust_color),
    ));

    // SWD state
    let swd_sym = if app.swd_event_count > 0 { symbols::VERIFIED } else { symbols::STOPPED };
    text.push_line(Line::styled(
        format!(" {} SWD:      {} ({} operations monitored)",
            swd_sym, app.swd_state, app.swd_event_count,
        ),
        Style::default().fg(colors::STYX),
    ));

    // Healing state
    let heal_sym = if app.healing_active { symbols::RUNNING } else { symbols::STOPPED };
    let heal_color = if app.healing_active { colors::ANAMNESIS } else { colors::KATOPTRON };
    text.push_line(Line::styled(
        format!(" {} Healing:  {} (cycles: {}, status: {})",
            heal_sym, app.healing_state, app.healing_cycles,
            if app.healing_active { "active 🔄" } else { "standby" },
        ),
        Style::default().fg(heal_color),
    ));

    // ── PROGRESS BAR ──
    text.push_line(Line::styled("", Style::default()));
    let chain_indicator = match &app.chain {
        Some(chain) => {
            let (pending, running, passed, failed) = chain.counts();
            let total = chain.links.len();
            let done = passed;
            format!(
                " {} Chain progress: {}  | {} pending, {} running, {} passed, {} failed",
                progress_indicator(done, total),
                chain.id, pending, running, passed, failed,
            )
        }
        None => format!(" {} No active chain", symbols::STOPPED),
    };
    text.push_line(Line::styled(
        &chain_indicator,
        Style::default().fg(colors::THALASSA),
    ));

    // ── COMMANDS ──
    text.push_line(Line::styled("", Style::default()));
    text.push_line(Line::styled(
        format!(" {} COMMANDS: 1-4=Switch Tabs | Tab=Next | Q=Quit | Enter=Send", symbols::NUCLEUS),
        Style::default().fg(colors::KATOPTRON),
    ));

    let config_para = Paragraph::new(text)
        .block(
            Block::default()
                .borders(Borders::ALL)
                .title(atlantean_title("mnemos", "Codex of Laws"))
                .border_style(
                    Style::default()
                        .fg(colors::MNEMOS)
                        .add_modifier(Modifier::BOLD),
                ),
        );
    frame.render_widget(config_para, area);
}
