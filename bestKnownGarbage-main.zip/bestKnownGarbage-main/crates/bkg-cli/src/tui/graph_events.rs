//! Graph event adapters — convert core events to UI-friendly formats.
//!
//! These functions translate `GraphEvent` and `GraphEventKind` into
//! displayable strings, colors, and icons for the TUI.

use bkg_core::capsule::{GraphEvent, GraphEventKind, GraphSeverity};

/// The severity determines the terminal color for rendering.
pub fn severity_color(severity: &GraphSeverity) -> ratatui::style::Color {
    match severity {
        GraphSeverity::Info => ratatui::style::Color::Cyan,
        GraphSeverity::Warn => ratatui::style::Color::Yellow,
        GraphSeverity::Error => ratatui::style::Color::Red,
        GraphSeverity::Critical => ratatui::style::Color::LightRed,
    }
}

/// A display-friendly summary of a graph event kind.
pub fn event_kind_label(kind: &GraphEventKind) -> &'static str {
    match kind {
        GraphEventKind::CapsuleLoaded => "Loaded",
        GraphEventKind::CapsuleRehydrated => "Rehydrated",
        GraphEventKind::CapsuleRepaired => "Repaired",
        GraphEventKind::CapsuleArchived => "Archived",
        GraphEventKind::NodeAdded => "Node+",
        GraphEventKind::NodeUpdated => "Node~",
        GraphEventKind::NodeRemoved => "Node-",
        GraphEventKind::NodeVerified => "Node✓",
        GraphEventKind::NodeStale => "Node⚠",
        GraphEventKind::NodeDivergent => "Node✗",
        GraphEventKind::NodeRepaired => "Node↺",
        GraphEventKind::EdgeAdded => "Edge+",
        GraphEventKind::EdgeUpdated => "Edge~",
        GraphEventKind::EdgeRemoved => "Edge-",
        GraphEventKind::ReplayStarted => "Replay▶",
        GraphEventKind::ReplayStep => "Replay→",
        GraphEventKind::ReplayFinished => "Replay■",
        GraphEventKind::DriftDetected => "Drift!",
        GraphEventKind::DriftResolved => "Drift✓",
        GraphEventKind::LayoutUpdated => "Layout↻",
        GraphEventKind::ProjectionChanged => "Project↻",
        GraphEventKind::SnapshotAttached => "Snap+",
        GraphEventKind::ReceiptAttached => "Receipt+",
    }
}

/// Icon for a node status, used in the node tree panel.
pub fn node_status_icon(status: &bkg_core::capsule::node::NodeStatus) -> &'static str {
    use bkg_core::capsule::node::NodeStatus;
    match status {
        NodeStatus::Pending => "○",
        NodeStatus::Running => "▶",
        NodeStatus::Verified => "✓",
        NodeStatus::Stale => "⚠",
        NodeStatus::Divergent { .. } => "✗",
        NodeStatus::Repaired => "↺",
        NodeStatus::Failed(_) => "☠",
        NodeStatus::Archived => "◼",
    }
}

/// Color for a node status, used in the node tree and graph canvas.
pub fn node_status_color(status: &bkg_core::capsule::node::NodeStatus) -> ratatui::style::Color {
    use bkg_core::capsule::node::NodeStatus;
    match status {
        NodeStatus::Pending => ratatui::style::Color::DarkGray,
        NodeStatus::Running => ratatui::style::Color::Cyan,
        NodeStatus::Verified => ratatui::style::Color::Green,
        NodeStatus::Stale => ratatui::style::Color::Yellow,
        NodeStatus::Divergent { .. } => ratatui::style::Color::Red,
        NodeStatus::Repaired => ratatui::style::Color::Magenta,
        NodeStatus::Failed(_) => ratatui::style::Color::LightRed,
        NodeStatus::Archived => ratatui::style::Color::Gray,
    }
}

/// Format a timeline event for display.
pub fn format_event_line(event: &GraphEvent) -> String {
    let time = event.created_at.format("%H:%M:%S").to_string();
    let kind = event_kind_label(&event.kind);
    let node = event
        .node_id
        .as_deref()
        .map(|n| format!(" [{n}]"))
        .unwrap_or_default();
    let edge = event
        .edge_id
        .as_deref()
        .map(|e| format!(" <{e}>"))
        .unwrap_or_default();
    format!("{time} {kind}{node}{edge}")
}
