use crate::Result;
use bkg_verify::{FindingSeverity, IntegrityGate, VerifyEngine, VerifyReport};
use clap::{Args, Subcommand};
use std::path::PathBuf;

/// CI verification commands
#[derive(Debug, Subcommand)]
pub enum VerifyCommand {
    /// Run verification checks
    Run(RunArgs),
    /// Show last verification status
    Last,
    /// Check memory files integrity
    CheckMemory,
    /// Initialize verification configuration
    Init,
}

#[derive(Debug, Args)]
pub struct RunArgs {
    /// Strict mode (findings become failures)
    #[arg(long)]
    strict: bool,
    /// JSON output
    #[arg(long)]
    json: bool,
}

pub async fn handle_verify(command: VerifyCommand) -> Result<()> {
    match command {
        VerifyCommand::Run(args) => run_verification(args).await?,
        VerifyCommand::Last => show_last().await?,
        VerifyCommand::CheckMemory => check_memory().await?,
        VerifyCommand::Init => init_config().await?,
    }
    Ok(())
}

async fn run_verification(args: RunArgs) -> Result<()> {
    let engine = VerifyEngine::new(PathBuf::from("."));
    let report = engine.verify(args.strict, args.json);

    print_report(&report, args.json);

    if args.strict && report.strict_fail {
        std::process::exit(1);
    }

    Ok(())
}

async fn show_last() -> Result<()> {
    println!("Run 'bkg verify run' to perform verification");
    println!("No previous results cached");
    Ok(())
}

async fn check_memory() -> Result<()> {
    let gate = IntegrityGate::new(PathBuf::from("."));
    let findings = gate.check_memory_files();

    if findings.is_empty() {
        println!("✅ Memory files integrity check passed");
    } else {
        println!("❌ Memory files integrity check failed:");
        for finding in &findings {
            println!(
                "  {}: {} (severity: {:?})",
                finding.category, finding.message, finding.severity
            );
        }
        std::process::exit(1);
    }

    Ok(())
}

/// Verify a chain link's output (stage 9/9).
/// Runs the VerifyEngine and checks the link's output for quality.
pub async fn verify_chain_link(
    chain_id: &str,
    link_id: &str,
    output: &str,
    files_changed: &[String],
) -> Result<bool> {
    // Run the VerifyEngine on the workspace
    let engine = VerifyEngine::new(PathBuf::from("."));
    let report = engine.verify(false, false);

    if !report.passed {
        eprintln!("Verify chain {chain_id}/{link_id}: checks failed");
        return Ok(false);
    }

    // Check that the output is non-empty
    if output.trim().is_empty() {
        eprintln!("Verify chain {chain_id}/{link_id}: empty output");
        return Ok(false);
    }

    // Check that changed files actually exist
    for file in files_changed {
        if !std::path::Path::new(file).exists() {
            eprintln!("Verify chain {chain_id}/{link_id}: file '{file}' does not exist");
            return Ok(false);
        }
    }

    Ok(true)
}

async fn init_config() -> Result<()> {
    let _engine = VerifyEngine::new(PathBuf::from("."));
    println!("Verification engine initialized (working dir: .)");
    println!("Run 'bkg verify run' to execute");
    Ok(())
}

fn print_report(report: &VerifyReport, json_output: bool) {
    if json_output {
        let json = serde_json::to_string_pretty(report).unwrap_or_default();
        println!("{json}");
        return;
    }

    if report.passed {
        println!("✅ All checks passed");
    } else {
        println!("❌ Verification failed");
    }

    println!("{}", report.summary);

    if !report.findings.is_empty() {
        println!("\nFindings:");
        for finding in &report.findings {
            let marker = match finding.severity {
                FindingSeverity::High => "❌",
                FindingSeverity::Medium => "⚠️",
                FindingSeverity::Low => "⚠️",
                FindingSeverity::Info => "ℹ️",
            };
            let file_info = finding
                .file
                .as_deref()
                .map(|f| format!(" in {f}"))
                .unwrap_or_default();
            println!(
                "  {marker} {}: {}{file_info}",
                finding.category, finding.message
            );
        }
    }

    if report.strict_fail {
        println!("\n⚠️  Strict mode: findings exceeded thresholds");
    }
}
