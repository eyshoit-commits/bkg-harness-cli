//! **ModelRouter** — Intelligent task-to-model routing for the BKG agent system.
//!
//! Routes each agent role to the best available model on the configured provider.
//! Supports dynamic model discovery (Ollama) and tier-based selection.
//!
//! # Routing Logic
//!
//! | Task Type | Model Tier | Reasoning |
//! |-----------|-----------|-----------|
//! | `planner` | Largest available | Complex reasoning tasks |
//! | `coder` | Medium coding-specialized | Implementation work |
//! | `reviewer` | Medium | Code review, verification |
//! | `docs` | Smallest | Simple documentation |
//! | `overseer` | Large | Meta-cognition, orchestration |

use bkg_provider::ModelInfo;
use bkg_provider::registry::ProviderRegistry;

/// Task types that map to model tiers.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaskType {
    Planner, Coder, Reviewer, Docs, Overseer, General,
}

impl TaskType {
    pub fn from_role(role: &str) -> Self {
        match role.to_lowercase().as_str() {
            "planner" | "architect" => TaskType::Planner,
            "coder" | "writer" | "implementer" => TaskType::Coder,
            "reviewer" | "verifier" | "critic" | "tester" => TaskType::Reviewer,
            "docs" | "documenter" | "scribe" => TaskType::Docs,
            "overseer" | "manager" | "coordinator" => TaskType::Overseer,
            _ => TaskType::General,
        }
    }

    pub fn label(&self) -> &'static str {
        match self {
            TaskType::Planner => "Planner",
            TaskType::Coder => "Coder",
            TaskType::Reviewer => "Reviewer",
            TaskType::Docs => "Docs",
            TaskType::Overseer => "Overseer",
            TaskType::General => "General",
        }
    }

    pub fn complexity(&self) -> u8 {
        match self {
            TaskType::Planner => 5,
            TaskType::Overseer => 4,
            TaskType::Coder => 3,
            TaskType::Reviewer => 2,
            TaskType::Docs => 1,
            TaskType::General => 3,
        }
    }

    pub fn from_prompt(prompt: &str) -> Self {
        let lower = prompt.to_lowercase();
        if lower.contains("architecture") || lower.contains("design") || lower.contains("plan")
            || lower.contains("architect") || lower.starts_with("implement ")
            || lower.starts_with("create ")
        {
            TaskType::Planner
        } else if lower.contains("write") || lower.contains("implement") || lower.contains("code")
            || lower.contains("function") || lower.contains("class")
        {
            TaskType::Coder
        } else if lower.contains("review") || lower.contains("verify") || lower.contains("check")
            || lower.contains("audit") || lower.contains("lint") || lower.contains("test")
        {
            TaskType::Reviewer
        } else if lower.contains("doc") || lower.contains("document") || lower.contains("readme")
            || lower.contains("comment") || lower.contains("explain")
        {
            TaskType::Docs
        } else if lower.contains("summarize") || lower.contains("overview") || lower.contains("status")
        {
            TaskType::Overseer
        } else {
            TaskType::General
        }
    }
}

/// Result of a route lookup.
#[derive(Debug, Clone)]
pub struct RouteResult {
    pub model: String,
    pub provider: String,
}

/// The ModelRouter — resolves task types to concrete (provider, model) pairs.
pub struct ModelRouter {
    registry: ProviderRegistry,
}

impl ModelRouter {
    pub fn new(registry: ProviderRegistry) -> Self {
        Self { registry }
    }

    /// Route a task type to the best available (provider, model) pair.
    pub async fn route(&self, task_type: TaskType) -> RouteResult {
        let providers = self.registry.list();
        let complexity = task_type.complexity();

        // Score each provider's models and pick the best match
        for name in &providers {
            if let Some(provider) = self.registry.get(name) {
                if let Ok(models) = provider.list_models().await {
                    if models.is_empty() {
                        continue;
                    }
                    let mut scored: Vec<(f32, &ModelInfo)> = models
                        .iter()
                        .map(|m| (score_model(m, complexity), m))
                        .collect();
                    scored.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
                    if let Some((_, best)) = scored.first() {
                        return RouteResult {
                            model: best.id.clone(),
                            provider: name.clone(),
                        };
                    }
                }
            }
        }

        RouteResult {
            model: "llama3.2:3b".to_string(),
            provider: "ollama".to_string(),
        }
    }

    /// Route for a specific role name.
    pub async fn route_for_role(&self, role: &str) -> RouteResult {
        self.route(TaskType::from_role(role)).await
    }

    /// Route based on prompt content analysis.
    pub async fn route_for_prompt(&self, prompt: &str) -> RouteResult {
        self.route(TaskType::from_prompt(prompt)).await
    }
}

/// Score how well a model matches a complexity level.
fn score_model(model: &ModelInfo, complexity: u8) -> f32 {
    let mut score = 0.0f32;
    let id = model.id.to_lowercase();

    // Context window: larger is better for complex tasks
    score += (model.context_length as f32 / 128000.0).min(1.0) * 3.0;

    // Large model bonus for complex tasks
    if complexity >= 4 {
        if id.contains("70b") || id.contains("405b") || id.contains("32b") {
            score += 3.0;
        } else if id.contains("13b") || id.contains("30b") || id.contains("24b") {
            score += 2.0;
        }
    }

    // Coding model bonus for coder/reviewer tasks
    if complexity == 3 || complexity == 2 {
        if id.contains("coder") || id.contains("deepseek") {
            score += 2.0;
        }
    }

    // Small model bonus for simple tasks
    if complexity <= 2 {
        if id.contains("3b") || id.contains("2b") || id.contains("270m") {
            score += 1.0;
        }
    }

    // Prefer free/local models
    if model.pricing.is_none() || model.pricing.as_ref().map_or(true, |p| p.prompt_per_1k == 0.0) {
        score += 1.0;
    }

    score
}