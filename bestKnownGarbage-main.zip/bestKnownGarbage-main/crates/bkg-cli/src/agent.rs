//! Agent coordinator for BKG — tool-using LLM conversation loop.

use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use tokio::sync::RwLock;

use crate::tui::status::StatusBus;
use crate::{BkgError, Config, Message, Result, Session};
use async_trait::async_trait;
use bkg_provider::{ChatMessage, LLMProvider, ProviderOptions, ToolDefinition};
use bkg_tools::{Tool, ToolCall, ToolRegistry, ToolResponse};

/// Maximum number of tool call iterations before forcing a response.
const MAX_TOOL_ITERATIONS: u32 = 25;

/// Agent trait for running conversations.
#[async_trait]
pub trait Agent: Send + Sync {
    /// Run a conversation turn.
    async fn run(&self, prompt: &str) -> Result<Message>;

    /// Cancel the current operation.
    async fn cancel(&self);
}

/// Coordinator for managing agents.
pub struct Coordinator {
    /// Configuration.
    config: Arc<RwLock<Config>>,
    /// Tool registry.
    tools: Arc<RwLock<ToolRegistry>>,
    /// Current session.
    session: Arc<RwLock<Option<Session>>>,
    /// LLM provider.
    provider: Arc<dyn LLMProvider + Send + Sync>,
    /// Cancellation flag for the current operation.
    cancelled: Arc<AtomicBool>,
    /// Status bus for live UI reporting (optional).
    status_bus: Option<StatusBus>,
}

impl Coordinator {
    /// Create a new coordinator.
    pub fn new(config: Config, provider: Arc<dyn LLMProvider + Send + Sync>) -> Self {
        let mut tools = ToolRegistry::new();
        tools.register_builtin(None);
        Self {
            config: Arc::new(RwLock::new(config)),
            tools: Arc::new(RwLock::new(tools)),
            session: Arc::new(RwLock::new(None)),
            provider,
            cancelled: Arc::new(AtomicBool::new(false)),
            status_bus: None,
        }
    }

    /// Attach a status bus for live UI reporting.
    pub fn with_status_bus(mut self, bus: StatusBus) -> Self {
        self.status_bus = Some(bus);
        self
    }

    /// Get a reference to the LLM provider.
    pub async fn provider(&self) -> Arc<dyn LLMProvider + Send + Sync> {
        self.provider.clone()
    }

    /// Get the tool registry's info list.
    pub async fn tools(&self) -> Vec<bkg_tools::ToolInfo> {
        self.tools.read().await.infos()
    }

    /// Get the current session.
    pub async fn session(&self) -> Option<Session> {
        self.session.read().await.clone()
    }

    /// Start a new session.
    pub async fn new_session(&self) -> Session {
        let session = Session::new();
        *self.session.write().await = Some(session.clone());
        session
    }

    /// Run a prompt in the session with full tool-using loop.
    pub async fn run(&self, prompt: &str) -> Result<Message> {
        if self.cancelled.swap(false, Ordering::SeqCst) {
            return Err(BkgError::Cancelled);
        }

        let cfg_guard = self.config.read().await;
        let system_prompt = cfg_guard
            .agents
            .values()
            .next()
            .and_then(|a| a.system_prompt.as_deref())
            .unwrap_or("You are BKG, a helpful AI coding assistant.");

        let mut messages: Vec<ChatMessage> = Vec::new();
        messages.push(ChatMessage::system(system_prompt));
        messages.push(ChatMessage::user(prompt));

        let tools = self.tools.read().await;
        let tool_defs: Vec<ToolDefinition> = tools
            .infos()
            .into_iter()
            .map(|info| ToolDefinition {
                name: info.name,
                description: info.description,
                input_schema: info.input_schema,
            })
            .collect();
        drop(tools);
        drop(cfg_guard);

        let mut options = ProviderOptions::default();
        options.tools = tool_defs;
        {
            let cfg_guard = self.config.read().await;
            if let Some(agent_cfg) = cfg_guard.agents.values().next() {
                if let Some(selected) = &agent_cfg.model {
                    options.model = selected.model.clone();
                }
            }
        }
        if options.model.is_empty() {
            options.model =
                std::env::var("BKG_DEFAULT_MODEL").unwrap_or_else(|_| "gpt-4o".to_string());
        }

        for _iteration in 0..MAX_TOOL_ITERATIONS {
            if self.cancelled.load(Ordering::SeqCst) {
                return Err(BkgError::Cancelled);
            }

            let response = self
                .provider
                .chat(&messages, options.clone())
                .await
                .map_err(|e| BkgError::Provider(e.to_string()))?;

            if !response.content.is_empty() {
                messages.push(ChatMessage {
                    role: bkg_provider::MessageRole::Assistant,
                    content: Some(response.content.clone()),
                    tool_calls: None,
                    tool_call_id: None,
                });
                if let Some(ref bus) = self.status_bus {
                    bus.publish("agent", crate::tui::status::AgentEvent::Response {
                        text: response.content.clone(),
                    });
                }
            }

            if !response.tool_calls.is_empty() {
                let tc_msg = ChatMessage::tool_call(response.tool_calls.clone());
                messages.push(tc_msg);

                if let Some(ref bus) = self.status_bus {
                    bus.publish("agent", crate::tui::status::AgentEvent::Thinking);
                }

                for tc in &response.tool_calls {
                    if let Some(ref bus) = self.status_bus {
                        let args = serde_json::from_str(&tc.arguments).unwrap_or(serde_json::Value::Null);
                        bus.publish("agent", crate::tui::status::AgentEvent::ToolCall {
                            tool: tc.name.clone(),
                            arguments: args,
                        });
                    }

                    let tool_call = ToolCall::new(
                        &tc.id,
                        &tc.name,
                        serde_json::from_str(&tc.arguments).unwrap_or(serde_json::Value::Null),
                    );

                    let result = match self.execute_tool(tool_call).await {
                        Ok(r) => r,
                        Err(e) => ToolResponse::error(format!("Tool execution error: {}", e)),
                    };

                    if let Some(ref bus) = self.status_bus {
                        bus.publish("agent", crate::tui::status::AgentEvent::ToolResult {
                            tool: tc.name.clone(),
                            summary: if result.content.len() > 120 {
                                format!("{}…", &result.content[..117])
                            } else {
                                result.content.clone()
                            },
                        });
                    }

                    messages.push(ChatMessage::tool_result(&tc.id, &result.content));
                }
                continue;
            }

            if !response.content.is_empty() {
                messages.push(ChatMessage::assistant(&response.content));
            }

            let mut msg = Message::assistant("", &response.content);
            if let Some(usage) = &response.usage {
                msg.prompt_tokens = usage.prompt_tokens as i64;
                msg.completion_tokens = usage.completion_tokens as i64;
            }
            if let Some(reason) = &response.finish_reason {
                use bkg_core::message::FinishReason;
                let fr = match reason.as_str() {
                    "stop" => FinishReason::EndTurn,
                    "length" => FinishReason::MaxTokens,
                    "tool_calls" => FinishReason::ToolUse,
                    _ => FinishReason::Unknown,
                };
                msg.finish(fr);
            }

            if let Some(ref bus) = self.status_bus {
                let summary = if msg.text().len() > 80 {
                    format!("{}…", &msg.text()[..77])
                } else {
                    msg.text()
                };
                bus.publish("agent", crate::tui::status::AgentEvent::Done { summary });
            }

            return Ok(msg);
        }

        if let Some(ref bus) = self.status_bus {
            bus.publish("agent", crate::tui::status::AgentEvent::Error {
                message: "Max iterations reached".to_string(),
            });
        }

        Err(BkgError::Cancelled)
    }

    /// Register a tool.
    pub async fn register_tool(&self, tool: Box<dyn Tool>) {
        self.tools.write().await.register(tool);
    }

    /// Execute a tool.
    pub async fn execute_tool(&self, call: ToolCall) -> bkg_tools::AgentResult<ToolResponse> {
        let tools = self.tools.read().await;
        if let Some(tool) = tools.get(&call.name) {
            tool.run(call).await
        } else {
            Ok(ToolResponse::error(format!("Unknown tool: {}", call.name)))
        }
    }

    /// Cancel the current operation.
    pub async fn cancel(&self) {
        self.cancelled.store(true, Ordering::SeqCst);
    }

    /// Get a handle to the config for reading/writing.
    pub async fn config_handle(&self) -> Arc<RwLock<Config>> {
        self.config.clone()
    }
}

#[async_trait]
impl Agent for Coordinator {
    async fn run(&self, prompt: &str) -> Result<Message> {
        self.run(prompt).await
    }

    async fn cancel(&self) {
        self.cancel().await
    }
}
