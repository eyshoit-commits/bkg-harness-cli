//! UCC-4 Work Commands — execute, verify, replay, and monitor work.
//!
//! Exposes the UCC-4 kernel pipeline through CLI subcommands:
//!   - `bkg work run <task>`      — Execute through evolution → execution → truth
//!   - `bkg work status`           — System health, convergence, evolution status
//!   - `bkg work replay <capsule>` — Deterministic re-execution from snapshots
//!   - `bkg work drift`            — Drift detection and convergence analysis

use crate::{agent::Coordinator, chain::CliLinkExecutor, router::ChainBuilder, Config, Result};
use bkg_provider::registry::ProviderRegistry;
use clap::{Args, Subcommand};

use bkg_core::BkgError;
use bkg_kernel::convergence::ConvergenceMetrics;
use bkg_kernel::evolution::MotherbrainEvolutionLoop;
use bkg_kernel::policy::{PolicyAction, PolicyContext, PolicyEngine};
use bkg_kernel::replay::ReplayEngine;
use crate::tui::StatusBus;

/// UCC-4 work pipeline commands
#[derive(Debug, Subcommand)]
pub enum WorkCommand {
    /// Run a task through the UCC-4 pipeline (evolution → execution → truth)
    Run(RunArgs),

    /// Show system health, convergence metrics, and evolution status
    Status,

    /// Deterministic replay of a past execution from snapshots
    Replay(ReplayArgs),

    /// Drift detection and convergence analysis
    Drift(DriftArgs),
}

#[derive(Debug, Args)]
pub struct RunArgs {
    /// Task description to execute
    task: String,

    /// Determinism threshold (0.0–1.0) for truth verification
    #[arg(long, default_value_t = 0.95)]
    threshold: f32,

    /// Enable verbose pipeline output
    #[arg(long)]
    verbose: bool,
}

#[derive(Debug, Args)]
pub struct ReplayArgs {
    /// Capsule or snapshot ID to replay
    id: String,

    /// Show detailed per-snapshot results
    #[arg(long)]
    verbose: bool,
}

#[derive(Debug, Args)]
pub struct DriftArgs {
    /// Window size for convergence estimation (default: 5)
    #[arg(long, default_value_t = 5usize)]
    window: usize,

    /// Drift threshold for alerting (default: 0.15)
    #[arg(long, default_value_t = 0.15)]
    threshold: f32,

    /// History of trust values (comma-separated floats)
    #[arg(
        long,
        default_value = "0.9,0.85,0.92,0.88,0.91,0.87,0.93,0.89,0.86,0.94"
    )]
    history: String,
}

/// Handle `work` subcommands.
pub async fn handle_work(command: WorkCommand) -> Result<()> {
    match command {
        WorkCommand::Run(args) => run_pipeline(args).await?,
        WorkCommand::Status => show_status().await?,
        WorkCommand::Replay(args) => replay_execution(args).await?,
        WorkCommand::Drift(args) => analyze_drift(args).await?,
    }
    Ok(())
}

// ── work run ──────────────────────────────────────

/// Run a task through the UCC-4 pipeline.
///
/// Pipeline stages:
///   1. Evolution — validate trust rules
///   2. Execution — run the task
///   3. Truth — verify output against trust vector
///   4. Policy — evaluate governance rules
///   5. Snapshot — store for replay
async fn run_pipeline(args: RunArgs) -> Result<()> {
    println!("┌─ UCC-4 Pipeline ──────────────────────────────────");
    println!("│ Task: {}", args.task);
    println!("│ Threshold: {:.2}", args.threshold);
    println!("├──────────────────────────────────────────────────────");

    // ── Stage 1: Evolution ──
    println!("│");
    println!("│ Stage 1/5: Evolution");
    let evolution = MotherbrainEvolutionLoop::new();
    println!(
        "│   Active rule: {} (epoch {})",
        evolution.active_rule.rule_id, evolution.epoch
    );
    println!(
        "│   Weights: repro={:.2}, causal={:.2}, cross={:.2}, entropy={:.2}",
        evolution.active_rule.w_reproducibility,
        evolution.active_rule.w_causality,
        evolution.active_rule.w_cross_node,
        evolution.active_rule.w_entropy_penalty,
    );
    println!(
        "│   Proposals pending: {}",
        evolution.pending_proposals.len()
    );

    // ── Stage 2: Execution ──
    println!("│");
    println!("│ Stage 2/5: Execution");
    let mut registry = ProviderRegistry::new();
    registry.register_defaults();
    let provider = registry.get_default().ok_or_else(|| {
        BkgError::Provider(
            "No provider configured. Set an API key or run Ollama locally.".to_string(),
        )
    })?;

    let config = Config::default();
    let coordinator = Coordinator::new(config, provider.clone());
    let default_model = std::env::var("BKG_DEFAULT_MODEL").unwrap_or_else(|_| "gpt-4o".to_string());

    let status_bus = StatusBus::new();
    let mut builder = ChainBuilder::new()
        .with_status_bus(status_bus.clone())
        .with_default_model(&default_model);
    let mut chain = builder.build(&args.task);

    let executor = CliLinkExecutor::new(coordinator, chain.id.clone())
        .with_status_bus(status_bus.clone());

    if args.verbose {
        println!("│   Built chain {} with {} links", chain.id, chain.links.len());
        println!("│   Using default model: {}", default_model);
    }

    let report = builder.run(&mut chain, &executor).await?;

    println!("│");
    println!("│ Stage 3/5: Policy Evaluation");
    let policy_engine = PolicyEngine::with_defaults();
    let context = PolicyContext::new().with_trust(args.threshold).with_entropy(1.0 - args.threshold);
    let actions = policy_engine.evaluate_actions(&context);

    if actions.is_empty() {
        println!("│   ✅ No policy actions triggered");
    } else {
        for action in &actions {
            let label = match action {
                PolicyAction::EscalateToMotherbrain => "Escalate to Motherbrain",
                PolicyAction::TriggerReplay => "Trigger replay",
                PolicyAction::QuarantineNode => "Quarantine node",
                PolicyAction::ForceGC => "Force garbage collection",
                PolicyAction::EmergencyRollback => "Emergency rollback",
                PolicyAction::LogWarning(msg) => {
                    println!("│   ⚠️  LogWarning: {msg}");
                    continue;
                }
            };
            println!("│   ⚠️  {label}");
        }
    }

    println!("│");
    println!("│ Stage 4/5: Snapshot");
    let replay_engine = ReplayEngine::new();
    println!(
        "│   Replay engine ready ({} snapshots stored)",
        replay_engine.snapshots.len()
    );

    println!("│");
    println!("│ Stage 5/5: Truth Report");
    println!("│   Chain ID: {}", chain.id);
    println!("│   Links: {}", chain.links.len());
    println!("│   Result: {}", if report.chain_passed { "PASS" } else { "FAIL" });
    println!("│");
    println!("{}", report);

    println!("└──────────────────────────────────────────────────────");
    Ok(())
}

// ── work status ────────────────────────────────────

/// Show kernel health, convergence, and evolution status.
async fn show_status() -> Result<()> {
    println!("┌─ UCC-4 Kernel Status ──────────────────────────────");

    // ── Evolution Status ──
    println!("│");
    println!("├─ Evolution ─────────────────────────────────────────");
    let evolution = MotherbrainEvolutionLoop::new();
    println!("│ Active rule:     {}", evolution.active_rule.rule_id);
    println!("│ Epoch:           {}", evolution.epoch);
    println!("│ Pending props:   {}", evolution.pending_proposals.len());
    println!("│ Rejected props:  {}", evolution.rejected_proposals.len());
    println!("│ History depth:   {}", evolution.history().len());
    println!("│ Weights:");

    print_weight_bar("reproducibility ", evolution.active_rule.w_reproducibility);
    print_weight_bar("causality       ", evolution.active_rule.w_causality);
    print_weight_bar("cross-node      ", evolution.active_rule.w_cross_node);
    print_weight_bar("entropy penalty ", evolution.active_rule.w_entropy_penalty);

    // ── Policy Engine ──
    println!("│");
    println!("├─ Policies ──────────────────────────────────────────");
    let policy_engine = PolicyEngine::with_defaults();
    println!("│ Registered rules: {}", policy_engine.rule_count());

    // ── Replay Engine ──
    println!("│");
    println!("├─ Replay ────────────────────────────────────────────");
    let replay_engine = ReplayEngine::new();
    println!("│ Snapshots stored: {}", replay_engine.snapshots.len());
    println!("│ Total replays:    {}", replay_engine.stats.total_replays);
    println!(
        "│ Success rate:     {:.1}%",
        replay_engine.success_rate() * 100.0
    );

    // ── Convergence ──
    println!("│");
    println!("├─ Convergence ───────────────────────────────────────");
    let trust_history = vec![0.90, 0.85, 0.92, 0.88, 0.91, 0.87, 0.93, 0.89, 0.86, 0.94];
    let variance = ConvergenceMetrics::variance(&trust_history);
    let drift = ConvergenceMetrics::drift_rate(&trust_history);
    let converging = ConvergenceMetrics::is_converging(&trust_history, 5);
    let (health, info) = ConvergenceMetrics::system_health(&trust_history, 5);

    println!("│ Trust samples:    {}", trust_history.len());
    println!("│ Variance:         {:.4}", variance);
    println!(
        "│ Std deviation:    {:.4}",
        ConvergenceMetrics::std_dev(&trust_history)
    );
    println!("│ Drift rate:       {:.4}", drift);
    println!(
        "│ Converging:       {}",
        if converging { "✅ yes" } else { "⚠️  no" }
    );
    println!("│ System health:    {:.2}%", health * 100.0);
    println!("│   Variance penalty:  {:.2}", info.variance_penalty);
    println!("│   Drift penalty:     {:.2}", info.drift_penalty);
    println!("│   Convergence bonus: {:.2}", info.convergence_bonus);

    println!("│");
    println!("└──────────────────────────────────────────────────────");

    Ok(())
}

// ── work replay ────────────────────────────────────

/// Deterministic replay of a past execution from stored snapshots.
async fn replay_execution(args: ReplayArgs) -> Result<()> {
    println!("┌─ Deterministic Replay ─────────────────────────────");
    println!("│ Capsule: {}", args.id);
    println!("├──────────────────────────────────────────────────────");

    let mut replay_engine = ReplayEngine::new();

    if replay_engine.snapshots.is_empty() {
        println!("│ ⚠️  No snapshots found for capsule '{}'", args.id);
        println!("│    Snapshots are created automatically during `bkg work run`.");
        println!("│    To create a test snapshot, use `bkg work run` first.");
    } else {
        println!("│ Snapshots loaded: {}", replay_engine.snapshots.len());
        println!("│ Starting deterministic replay...");

        let results = replay_engine.replay_all();

        if results.is_empty() {
            println!("│ ⚠️  No replay results available.");
        } else {
            let total = results.len();
            let passed = results.iter().filter(|(_, r)| r.success).count();
            let failed = total - passed;

            println!("│");
            for (i, (snap_id, result)) in results.iter().enumerate() {
                let status = if result.success { "✅" } else { "❌" };
                println!(
                    "│   {status} [{}/{}] {} — div: {:.4}, time: {}ms",
                    i + 1,
                    total,
                    snap_id,
                    result.divergence,
                    result.replay_time_ms
                );

                if args.verbose {
                    println!("│         original hash: {}", result.original_hash);
                    println!("│         replayed hash: {}", result.replayed_hash);
                    println!("│         exact match:   {}", result.match_exact);
                }
            }

            println!("│");
            println!("├─ Replay Summary ────────────────────────────────────");
            println!("│ Total:   {total}");
            println!("│ Passed:  {passed}");
            println!("│ Failed:  {failed}");
            println!("│ Rate:    {:.1}%", replay_engine.success_rate() * 100.0);
        }
    }

    println!("└──────────────────────────────────────────────────────");

    Ok(())
}

// ── work drift ─────────────────────────────────────

/// Analyze drift and convergence metrics from trust history.
async fn analyze_drift(args: DriftArgs) -> Result<()> {
    let trust_history: Vec<f32> = args
        .history
        .split(',')
        .filter_map(|s| s.trim().parse::<f32>().ok())
        .collect();

    if trust_history.len() < 4 {
        eprintln!("Error: need at least 4 trust values for drift analysis");
        println!("Provide --history with comma-separated floats, e.g.:");
        println!("  --history \"0.9,0.85,0.92,0.88,0.91\"");
        return Ok(());
    }

    println!("┌─ Drift & Convergence Analysis ────────────────────");
    println!("│ Trust history: {} samples", trust_history.len());
    println!("│ Window:        {}", args.window);
    println!("│ Alert at:      drift > {:.2}", args.threshold);

    // Raw data
    println!("│");
    let formatted: Vec<String> = trust_history.iter().map(|v| format!("{:.3}", v)).collect();
    println!("│ Data: [{}]", formatted.join(", "));

    // Statistics
    let variance = ConvergenceMetrics::variance(&trust_history);
    let std_dev = ConvergenceMetrics::std_dev(&trust_history);
    let drift = ConvergenceMetrics::drift_rate(&trust_history);
    let converging = ConvergenceMetrics::is_converging(&trust_history, args.window);
    let entropy = ConvergenceMetrics::trust_entropy(&trust_history);
    let convergence_est = ConvergenceMetrics::convergence_estimate(&trust_history, args.window);
    let (health, info) = ConvergenceMetrics::system_health(&trust_history, args.window);

    println!("│");
    println!("├─ Metrics ───────────────────────────────────────────");
    println!("│ Variance:          {:.6}", variance);
    println!("│ Std deviation:     {:.4}", std_dev);
    println!("│ Drift rate:        {:.4}", drift);
    println!("│ Trust entropy:     {:.4}", entropy);
    println!("│ Convergence est:   {:.4}", convergence_est);
    println!("│ System health:     {:.2}%", health * 100.0);
    println!(
        "│ Converging:        {}",
        if converging { "✅ yes" } else { "⚠️  no" }
    );

    if drift > args.threshold {
        println!(
            "│ ⚠️  HIGH DRIFT: {:.4} exceeds threshold {:.2}",
            drift, args.threshold
        );
        println!("│    Recommendation: Run `bkg work replay <capsule>` to check for divergence");
    } else {
        println!(
            "│ ✅ Drift within normal range ({:.4} < {:.2})",
            drift, args.threshold
        );
    }

    if !converging {
        println!("│ ⚠️  System is not converging — consider policy review");
        println!("│    Run `bkg work status` for detailed system health");
    }

    println!("│");
    println!("├─ Health Breakdown ──────────────────────────────────");
    println!("│ Base:             100.00%");
    println!("│ Variance penalty: -{:.2}%", info.variance_penalty * 100.0);
    println!("│ Drift penalty:    -{:.2}%", info.drift_penalty * 100.0);
    println!(
        "│ Convergence bonus: +{:.2}%",
        info.convergence_bonus * 100.0
    );
    println!("│ Final health:     {:.2}%", health * 100.0);

    println!("│");
    if entropy > 1.5 {
        println!(
            "│ ⚠️  High trust entropy ({:.4}) — trust values are widely dispersed",
            entropy
        );
        println!("│    This may indicate conflicting execution environments.");
    } else {
        println!(
            "│ ✅ Trust entropy is low ({:.4}) — good consensus across nodes",
            entropy
        );
    }

    println!("└──────────────────────────────────────────────────────");

    Ok(())
}

// ── Helpers ─────────────────────────────────────────

/// Print a weight bar for visual display.
fn print_weight_bar(label: &str, weight: f32) {
    let bar_width = 20;
    let filled = (weight * bar_width as f32).round() as usize;
    let filled = filled.min(bar_width);
    let empty = bar_width - filled;
    let bar = format!("{}{}", "█".repeat(filled), "░".repeat(empty));
    println!("│     {label} [{bar}] {:.2}", weight);
}
