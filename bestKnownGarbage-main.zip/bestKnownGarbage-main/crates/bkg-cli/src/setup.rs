//! Interactive Setup Wizard.
//!
//! Launched automatically on first run when `BootstrapReport::needs_setup` is true.
//! Walks the user through:
//! 1. Creating ~/.bkg/config.toml
//! 2. Setting up an AI provider (API key or local Ollama)
//! 3. Creating the capsules directory
//! 4. Optional: running a quick health check

use dialoguer::{Confirm, Password, Select, theme::ColorfulTheme};
use std::path::PathBuf;

/// Result of the setup wizard.
#[derive(Debug)]
pub struct SetupResult {
    pub config_created: bool,
    pub provider_configured: bool,
    pub capsules_dir_created: bool,
    pub ran_health_check: bool,
}

/// Run the interactive setup wizard.
/// Returns a SetupResult indicating what was accomplished.
pub async fn run_setup_wizard() -> SetupResult {
    let theme = ColorfulTheme::default();

    println!();
    println!("╔══════════════════════════════════════════════════╗");
    println!("║     BKG First-Time Setup Wizard                  ║");
    println!("╠══════════════════════════════════════════════════╣");
    println!("║ Let's get you configured in a few steps.         ║");
    println!("╚══════════════════════════════════════════════════╝");
    println!();

    let config_dir = get_config_dir();

    // ── Step 1: Config directory ──
    let config_created = ensure_config_dir(&config_dir);

    // ── Step 2: Provider setup ──
    let provider_configured = configure_provider(&theme, &config_dir).await;

    // ── Step 3: Capsules directory ──
    let capsules_dir_created = ensure_capsules_dir(&config_dir);

    // ── Step 4: Health check ──
    let ran_health_check = run_health_check(&theme).await;

    // ── Summary ──
    println!();
    println!("╔══════════════════════════════════════════════════╗");
    println!("║     Setup Complete                               ║");
    println!("╠══════════════════════════════════════════════════╣");

    if config_created {
        println!("║   ✓ Config directory created                      ║");
    }
    if provider_configured {
        println!("║   ✓ Provider configured                           ║");
    }
    if capsules_dir_created {
        println!("║   ✓ Capsules directory created                    ║");
    }
    if ran_health_check {
        println!("║   ✓ Health check completed                        ║");
    }

    println!("║                                                    ║");
    println!("║   Type 'bkg status' to view system state.          ║");
    println!("║   Type 'bkg chat \"hello\"' to start a chat.         ║");
    println!("╚══════════════════════════════════════════════════╝");
    println!();

    SetupResult {
        config_created,
        provider_configured,
        capsules_dir_created,
        ran_health_check,
    }
}

fn get_config_dir() -> PathBuf {
    dirs::home_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join(".bkg")
}

fn ensure_config_dir(config_dir: &PathBuf) -> bool {
    if config_dir.exists() {
        return true;
    }
    match std::fs::create_dir_all(config_dir) {
        Ok(_) => {
            println!("  ✓ Created config directory: {}", config_dir.display());
            true
        }
        Err(e) => {
            eprintln!("  ✗ Failed to create config directory: {e}");
            false
        }
    }
}

async fn configure_provider(theme: &ColorfulTheme, config_dir: &PathBuf) -> bool {
    let provider_options = &[
        "NVIDIA NIM (recommended)",
        "OpenAI",
        "Anthropic Claude",
        "Google Gemini",
        "Groq",
        "Ollama (local, no API key needed)",
        "Skip — I'll configure later",
    ];

    let selection = Select::with_theme(theme)
        .with_prompt("Choose an AI provider")
        .items(provider_options)
        .default(0)
        .interact()
        .unwrap_or(6);

    match selection {
        0 => configure_api_key("NVIDIA", "NVIDIA_API_KEY", config_dir),
        1 => configure_api_key("OpenAI", "OPENAI_API_KEY", config_dir),
        2 => configure_api_key("Anthropic", "ANTHROPIC_API_KEY", config_dir),
        3 => configure_api_key("Gemini", "GEMINI_API_KEY", config_dir),
        4 => configure_api_key("Groq", "GROQ_API_KEY", config_dir),
        5 => {
            println!("  ℹ  Using Ollama — ensure it's running on http://localhost:11434");
            write_env_file(config_dir, "OLLAMA_BASE_URL", "http://localhost:11434");
            write_config_file(config_dir, "ollama");
            true
        }
        _ => {
            println!(
                "  ℹ  Skipping provider setup. Set an API key later with: bkg login <provider>"
            );
            false
        }
    }
}

fn configure_api_key(name: &str, env_var: &str, config_dir: &PathBuf) -> bool {
    let theme = ColorfulTheme::default();

    let api_key: String = Password::with_theme(&theme)
        .with_prompt(format!("Enter your {name} API key"))
        .with_confirmation("Confirm API key", "Keys do not match")
        .interact()
        .unwrap_or_default();

    if api_key.is_empty() {
        println!(
            "  ℹ  No key entered. You can configure later with: bkg login {}",
            name.to_lowercase()
        );
        return false;
    }

    write_env_file(config_dir, env_var, &api_key);
    write_config_file(config_dir, &name.to_lowercase());
    println!(
        "  ✓ {name} API key saved to {}",
        config_dir.join(".env").display()
    );
    true
}

fn write_env_file(config_dir: &PathBuf, key: &str, value: &str) {
    let env_path = config_dir.join(".env");
    let line = format!("export {}={}\n", key, value);
    // Append if exists, create if not
    let mut content = String::new();
    if env_path.exists() {
        content = std::fs::read_to_string(&env_path).unwrap_or_default();
    }
    // Don't duplicate
    if !content.contains(&format!("export {}=", key)) {
        content.push_str(&line);
    }
    std::fs::write(&env_path, content).ok();
}

fn write_config_file(config_dir: &PathBuf, provider: &str) {
    let config_path = config_dir.join("config.toml");
    if config_path.exists() {
        return; // Don't overwrite existing config
    }

    let config_content = format!(
        r#"# BKG Configuration
# Generated by setup wizard

[defaults]
provider = "{}"

[providers.{}]
api_key_env = "{}_API_KEY"

[session]
default_budget = 1000000
isolation_level = "session"

[verify]
on_write = true
auto_fix = false
"#,
        provider,
        provider,
        provider.to_uppercase(),
    );

    std::fs::write(&config_path, config_content).ok();
}

fn ensure_capsules_dir(config_dir: &PathBuf) -> bool {
    let capsules_dir = config_dir.join("capsules");
    if capsules_dir.exists() {
        return true;
    }
    match std::fs::create_dir_all(&capsules_dir) {
        Ok(_) => {
            println!("  ✓ Created capsules directory: {}", capsules_dir.display());
            true
        }
        Err(e) => {
            eprintln!("  ✗ Failed to create capsules directory: {e}");
            false
        }
    }
}

async fn run_health_check(theme: &ColorfulTheme) -> bool {
    let run = Confirm::with_theme(theme)
        .with_prompt("Run a quick health check?")
        .default(true)
        .interact()
        .unwrap_or(false);

    if !run {
        return false;
    }

    println!("  🔍 Running health check...");

    // Check Ollama
    let ollama_ok = super::bootstrap::probe_ollama().await;
    if ollama_ok {
        println!("  ✓ Ollama is running on localhost:11434");
    } else {
        println!("  ℹ  Ollama not detected (optional — only needed for local models)");
    }

    // Verify config dir
    let config_dir = get_config_dir();
    let has_config = config_dir.join("config.toml").exists();
    let has_env = config_dir.join(".env").exists();
    if has_config || has_env {
        println!("  ✓ Configuration files present");
    }

    // Check capsules
    let has_capsules = config_dir.join("capsules").exists();
    if has_capsules {
        println!("  ✓ Capsules directory present");
    }

    true
}
