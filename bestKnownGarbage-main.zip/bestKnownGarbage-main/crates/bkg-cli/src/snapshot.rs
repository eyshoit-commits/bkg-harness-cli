use crate::{BkgError, Result};
use bkg_swd::{
    ActionIntent, FileAction, FileOperation, SwdEngine, SwdOptions, SwdRunResult,
    VerificationStatus,
};
use clap::{Args, Subcommand};
use std::path::PathBuf;

fn swd_to_err(e: bkg_swd::SwdError) -> BkgError {
    BkgError::Provider(format!("SWD error: {e}"))
}

/// SWD (Strict Write Discipline) commands
#[derive(Debug, Subcommand)]
pub enum SnapshotCommand {
    /// Run SWD verification on pending file actions
    Run(RunArgs),
    /// Parse and check actions from input
    Check(CheckArgs),
    /// Show last run result
    Last,
    /// Show SWD discipline rules and examples
    Docs,
}

#[derive(Debug, Args)]
pub struct RunArgs {
    /// File action description (format: "CREATE|MODIFY|DELETE path/to/file")
    action: String,
    /// Content to write (for CREATE actions)
    #[arg(long)]
    content: Option<String>,
    /// Dry-run mode (preview only)
    #[arg(long)]
    dry_run: bool,
    /// Enable automatic rollback on failure
    #[arg(long)]
    rollback: bool,
}

#[derive(Debug, Args)]
pub struct CheckArgs {
    /// Path to file containing actions
    path: Option<PathBuf>,
    /// Parse from stdin
    #[arg(long)]
    stdin: bool,
}

pub async fn handle_snapshot(command: SnapshotCommand) -> Result<()> {
    match command {
        SnapshotCommand::Run(args) => run_actions(args)?,
        SnapshotCommand::Check(args) => check_actions(args)?,
        SnapshotCommand::Last => show_last_result()?,
        SnapshotCommand::Docs => show_help()?,
    }
    Ok(())
}

fn run_actions(args: RunArgs) -> Result<()> {
    let options = SwdOptions {
        dry_run: args.dry_run,
        strict: true,
        enable_rollback: args.rollback,
        working_dir: PathBuf::from("."),
    };
    let engine = SwdEngine::new(options);

    // Parse action from CLI arg format: "CREATE|MODIFY|DELETE <path>"
    let parts: Vec<&str> = args.action.splitn(2, ' ').collect();
    if parts.len() < 2 {
        eprintln!("Usage: CREATE|MODIFY|DELETE <path>");
        eprintln!("Examples:");
        eprintln!("  CREATE src/hello.rs");
        eprintln!("  MODIFY src/main.rs");
        eprintln!("  DELETE tmp/cache");
        std::process::exit(1);
    }

    let operation = match parts[0].to_uppercase().as_str() {
        "CREATE" => FileOperation::Create,
        "MODIFY" => FileOperation::Modify,
        "DELETE" => FileOperation::Delete,
        other => {
            eprintln!("Unknown operation: {other} (use CREATE, MODIFY, or DELETE)");
            std::process::exit(1);
        }
    };

    let action = FileAction {
        path: parts[1].to_string(),
        operation,
        intent: ActionIntent::Mutate,
        content: args.content,
        content_hash: None,
        description: None,
    };

    let result = engine.run(vec![action]).map_err(swd_to_err)?;
    print_result(&result);

    if !result.success {
        std::process::exit(1);
    }

    Ok(())
}

fn check_actions(args: CheckArgs) -> Result<()> {
    let input: String = if let Some(path) = args.path {
        std::fs::read_to_string(&path).map_err(|e| BkgError::Io(e))?
    } else {
        let mut buffer = String::new();
        std::io::Read::read_to_string(&mut std::io::stdin(), &mut buffer)?;
        buffer
    };

    let actions = bkg_swd::parse_actions(&input);
    if actions.is_empty() {
        println!("No actions found in input");
        return Ok(());
    }

    println!("Parsed {} actions:", actions.len());
    for (i, action) in actions.iter().enumerate() {
        println!("  {}. {:?} {}", i + 1, action.operation, action.path);
    }

    Ok(())
}

fn show_last_result() -> Result<()> {
    let options = SwdOptions {
        dry_run: true,
        strict: false,
        enable_rollback: false,
        working_dir: PathBuf::from("."),
    };
    let engine = SwdEngine::new(options);
    // Run with empty actions to just check engine state
    let result = engine.run(vec![]).map_err(swd_to_err)?;
    print_result(&result);
    Ok(())
}

fn status_symbol(status: &VerificationStatus) -> &'static str {
    match status {
        VerificationStatus::Verified => "✅",
        VerificationStatus::Noop => "➖",
        VerificationStatus::Failed => "❌",
        VerificationStatus::Drift => "⚠️",
    }
}

fn print_result(result: &SwdRunResult) {
    if result.success {
        println!("✅ SWD run succeeded");
    } else {
        println!("❌ SWD run failed");
    }

    if !result.results.is_empty() {
        println!("\nResults:");
        for action_result in &result.results {
            println!(
                "  {} {} {}",
                status_symbol(&action_result.status),
                action_result.detail,
                action_result.action.path
            );
        }
    }

    if !result.errors.is_empty() {
        println!("\nErrors:");
        for error in &result.errors {
            println!("  ❌ {error}");
        }
    }

    if result.rolled_back {
        println!("\n↩️ Actions were rolled back");
    }
    if !result.rollback_errors.is_empty() {
        println!("\nRollback errors:");
        for error in &result.rollback_errors {
            println!("  ❌ {error}");
        }
    }
}

/// Take a SWD snapshot for a chain link (stage 7/9).
/// Returns a snapshot label if snapshot was taken, None if unavailable.
pub async fn take_snapshot(link_session_id: &str) -> Option<String> {
    let options = SwdOptions {
        dry_run: false,
        strict: false,
        enable_rollback: false,
        working_dir: PathBuf::from("."),
    };
    let engine = SwdEngine::new(options);

    let action = FileAction {
        path: ".bkg-trigger".to_string(),
        operation: FileOperation::Read,
        intent: ActionIntent::Noop,
        content: Some(link_session_id.to_string()),
        content_hash: None,
        description: Some(format!("Chain snapshot for {link_session_id}")),
    };

    match engine.run(vec![action]) {
        Ok(_result) => Some(format!("snap-{}", &link_session_id.replace('/', "-"))),
        Err(e) => {
            eprintln!("SWD snapshot warn: {e}");
            None
        }
    }
}

fn show_help() -> Result<()> {
    println!("SWD (Strict Write Discipline) — deterministic file operation enforcement");
    println!();
    println!("The SWD engine validates every CREATE/MODIFY/DELETE action against:");
    println!(
        "  - Size limits (max {} bytes per file)",
        bkg_swd::MAX_WRITE_BYTES
    );
    println!("  - File path validation (no path traversal)");
    println!("  - Operation ordering (can't modify a deleted file)");
    println!();
    println!("Commands:");
    println!("  bkg snapshot run \"CREATE path/to/file\"");
    println!("  bkg snapshot run \"MODIFY path/to/file\"");
    println!("  bkg snapshot run \"DELETE path/to/file\"");
    println!("  bkg snapshot check <file>     — Parse actions from a file");
    println!("  bkg snapshot check --stdin    — Parse actions from stdin");
    println!("  bkg snapshot last             — Show last run result");
    println!("  bkg snapshot docs             — Show SWD rules and examples");
    println!();
    println!("Flags:");
    println!("  --dry-run    Preview without making changes");
    println!("  --rollback   Auto-rollback on failure");
    println!("  --content    Content to write (for CREATE actions)");
    Ok(())
}
