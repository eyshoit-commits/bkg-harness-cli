//! BKG — Deterministic AI Coding Assistant
//!
//! A deterministic, verifiable AI-powered coding tool with
//! session management, strict write discipline, built-in
//! verification, budget tracking, and skill injection.
//!
//! Usage:
//!   bkg chat "add dark mode"           — One-shot prompt
//!   bkg session start "refactor auth"  — Start a coding session
//!   bkg status                          — System dashboard
//!   bkg providers                       — List AI providers
//!   bkg help                            — This help

use clap::{Parser, Subcommand};
use std::sync::Arc;

use bkg_cli::agent::Coordinator;
use bkg_cli::chain::CliLinkExecutor;
use bkg_cli::model_router::ModelRouter;
use bkg_cli::router::ChainBuilder;
use bkg_cli::tui::{run_tui, StatusBus};
use bkg_cli::{BkgError, Config};
use bkg_kernel::gc::GarbageCollector;
use bkg_kernel::mesh::{EntropyRegion, MeshNode};
use bkg_kernel::trust_field_kernel::TrustVector;
use bkg_provider::registry::ProviderRegistry;
use tokio::time::{Duration, sleep};

/// BKG — Deterministic AI Coding Assistant
///
/// A coding AI with session management, strict write discipline,
/// built-in verification, budget tracking, and skill injection.
///
/// Examples:
///   bkg chat "write a fibonacci function in Rust"
///   bkg session start "refactor auth module"
///   bkg memory search "dependency injection"
///   bkg budget status
///   bkg skills list
///   bkg verify run
#[derive(Parser, Debug)]
#[command(name = "bkg", version)]
struct Cli {
    /// Subcommand to run
    #[command(subcommand)]
    command: Commands,

    /// Verbose logging
    #[arg(short, long, global = true)]
    verbose: bool,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Run interactive chat with an AI provider
    Chat {
        /// The prompt to send
        prompt: Option<String>,

        /// Model to use
        #[arg(short, long)]
        model: Option<String>,

        /// Provider to use (e.g., openai, anthropic, nvidia, groq, ollama)
        #[arg(short = 'P', long)]
        provider: Option<String>,

        /// List all available models for a provider
        #[arg(long)]
        list_models: Option<String>,
    },

    /// Launch the interactive terminal UI
    Tui {
        /// Model to use for the terminal UI chain executor
        #[arg(short, long)]
        model: Option<String>,

        /// Provider to use for terminal UI
        #[arg(short = 'P', long)]
        provider: Option<String>,
    },

    /// List available providers and their status
    Providers {
        /// Show detailed model info for a specific provider
        #[arg(long)]
        models: Option<String>,
    },

    /// Log in to a provider (set API key interactively)
    Login {
        /// Provider name (e.g., nvidia, openai, anthropic)
        provider: String,
        #[arg(short, long)]
        key: Option<String>,
    },

    /// Log out from a provider (remove API key)
    Logout { provider: String },

    /// Update provider definitions from remote source
    UpdateProviders {
        #[arg(default_value = "embedded")]
        source: String,
    },

    /// Run Mesh + Garbage Collector observation demo
    DemoMeshGc,

    /// Show system status
    Status,

    /// Show version
    Version,

    /// Skills management commands
    #[command(subcommand)]
    Skills(bkg_cli::skills::SkillsCommand),

    /// Session management commands
    #[command(subcommand)]
    Session(bkg_cli::session::SessionCommand),

    /// Budget tracking commands
    #[command(subcommand)]
    Budget(bkg_cli::budget::BudgetCommand),

    /// Memory management commands
    #[command(subcommand)]
    Memory(bkg_cli::memory::MemoryCommand),

    /// CI verification commands
    #[command(subcommand)]
    Verify(bkg_cli::verify::VerifyCommand),

    /// SWD (Strict Write Discipline) commands
    #[command(subcommand)]
    Snapshot(bkg_cli::snapshot::SnapshotCommand),

    /// Capsule management commands
    #[command(subcommand)]
    Capsule(bkg_cli::capsule::CapsuleCommand),

    /// Managed Agent system commands
    #[command(subcommand)]
    Managed(ManagedCommands),

    /// UCC-4 work pipeline commands
    #[command(subcommand)]
    Work(bkg_cli::work::WorkCommand),
}

#[derive(Subcommand, Debug)]
enum ManagedCommands {
    /// Show managed agent system status and budget breakdown
    Status,

    /// List or show details for a managed agent preset
    Preset {
        /// Optional preset name to show details for
        name: Option<String>,
    },

    /// Run a managed agent session with a preset
    Run {
        /// Preset to use (balanced, budget, executor-heavy, etc.)
        preset: String,

        /// The task prompt for the manager agent
        task: String,
    },

    /// Validate all presets
    Validate,
}

#[tokio::main]
async fn main() -> std::result::Result<(), BkgError> {
    let cli = Cli::parse();

    if cli.verbose {
        tracing_subscriber::fmt::init();
    }

    // ── Bootstrap: run system health check ──
    let bootstrap_report = bkg_cli::bootstrap::run_bootstrap().await;

    // ── Setup wizard: launch if first run or failed phases ──
    if bkg_cli::bootstrap::requires_setup(&bootstrap_report) {
        println!("\n⚠  System needs initial setup — launching wizard...\n");
        let _result = bkg_cli::setup::run_setup_wizard().await;
        println!();
    }

    let mut registry = ProviderRegistry::new();
    registry.register_defaults();

    match cli.command {
        Commands::Providers { models } => {
            println!("Available providers:");
            println!();

            if let Some(provider_name) = models {
                let provider = registry.get(&provider_name).ok_or_else(|| {
                    BkgError::Provider(format!(
                        "Provider '{provider_name}' not found. Available: {}",
                        registry.list().join(", ")
                    ))
                })?;
                let model_list = provider
                    .list_models()
                    .await
                    .map_err(|e| BkgError::Provider(e.to_string()))?;
                println!("Models from '{provider_name}':");
                for m in &model_list {
                    let pricing = m
                        .pricing
                        .as_ref()
                        .map(|p| {
                            format!(
                                "${:.4}/1K in, ${:.4}/1K out",
                                p.prompt_per_1k, p.completion_per_1k
                            )
                        })
                        .unwrap_or_else(|| "free/local".to_string());
                    println!(
                        "  {} — {} (ctx: {}, {})",
                        m.id, m.name, m.context_length, pricing
                    );
                }
                return Ok(());
            }

            let names = registry.list();
            if names.is_empty() {
                println!("  No providers configured.");
                println!("  Set an API key environment variable:");
                println!("    NVIDIA_API_KEY   — NVIDIA NIM (main provider)");
                println!("    OPENAI_API_KEY   — OpenAI");
                println!("    ANTHROPIC_API_KEY — Anthropic Claude");
                println!("    GEMINI_API_KEY   — Google Gemini");
                println!("    GROQ_API_KEY     — Groq");
                println!("    OPENROUTER_API_KEY — OpenRouter");
                println!("  Or use Ollama locally as routing proxy:");
                println!("    OLLAMA_URL (default: http://localhost:11434)");
                return Ok(());
            }

            for name in names.iter() {
                let provider = registry.get(name).unwrap();
                let status = match provider.health_check().await {
                    Ok(_) => "✓",
                    Err(_) => "✗",
                };
                println!(
                    "  {} {} (models: {} listed)",
                    status,
                    name,
                    provider.list_models().await.map(|m| m.len()).unwrap_or(0)
                );
            }

            if registry.get_default().is_some() {
                let names = registry.list();
                let default_name = names.first().map(|s| s.as_str()).unwrap_or("?");
                println!();
                println!("Default provider: {default_name}");
                println!("(Set BKG_DEFAULT_PROVIDER to override)");
            }
        }

        Commands::Login { provider, key } => {
            let env_var = format!("{}_API_KEY", provider.to_uppercase());
            let api_key = match key {
                Some(k) => k,
                None => {
                    eprint!("Enter API key for {provider}: ");
                    use std::io::BufRead;
                    let mut input = String::new();
                    std::io::stdin()
                        .lock()
                        .read_line(&mut input)
                        .map_err(|e| BkgError::Io(e))?;
                    input.trim().to_string()
                }
            };

            if api_key.is_empty() {
                eprintln!("API key cannot be empty.");
                std::process::exit(1);
            }

            let config_dir = dirs::config_dir()
                .unwrap_or_else(|| std::path::PathBuf::from("."))
                .join("bkg");
            std::fs::create_dir_all(&config_dir).map_err(|e| BkgError::Io(e))?;
            let env_path = config_dir.join(".env");

            let new_line = format!("export {}={}", env_var, api_key);
            std::fs::write(&env_path, &new_line).map_err(|e| BkgError::Io(e))?;
            println!("✓ Saved API key for '{provider}' to {}", env_path.display());
            println!(
                "  Source this file in your shell: source {}",
                env_path.display()
            );
        }

        Commands::Logout { provider } => {
            println!(
                "To log out from '{provider}', unset the {} environment variable:",
                provider.to_uppercase()
            );
            println!("  unset {}_API_KEY", provider.to_uppercase());
        }

        Commands::UpdateProviders { source } => {
            println!("Updating provider definitions from: {source}");
            println!("(Embedded provider definitions are bundled at build time.)");
        }

        Commands::Chat {
            prompt,
            model,
            provider: provider_name,
            list_models,
        } => {
            if let Some(provider_name) = list_models {
                let provider = registry.get(&provider_name)
                    .ok_or_else(|| BkgError::Provider(format!("Provider '{provider_name}' not found. Set {}_API_KEY or use a configured provider.", provider_name.to_uppercase())))?;
                let models = provider
                    .list_models()
                    .await
                    .map_err(|e| BkgError::Provider(e.to_string()))?;
                println!("Models available from '{provider_name}':");
                for m in &models {
                    let pricing = m
                        .pricing
                        .as_ref()
                        .map(|p| {
                            format!(
                                "${:.4}/1K in, ${:.4}/1K out",
                                p.prompt_per_1k, p.completion_per_1k
                            )
                        })
                        .unwrap_or_else(|| "free/local".to_string());
                    println!(
                        "  {} — {} (ctx: {}, {})",
                        m.id, m.name, m.context_length, pricing
                    );
                }
                return Ok(());
            }

            // Save provider name for model selection before it gets moved
            let selected_provider = provider_name.clone();

            // Resolve provider
            let provider_arc: Arc<dyn bkg_provider::LLMProvider + Send + Sync> = if let Some(name) =
                provider_name
            {
                registry
                    .get(&name)
                    .ok_or_else(|| {
                        BkgError::Provider(format!(
                            "Provider '{name}' not found. Available: {}",
                            registry.list().join(", ")
                        ))
                    })?
                    .clone()
            } else if let Some(default) = registry.get_default() {
                let names = registry.list();
                let default_name = names.first().map(|s| s.as_str()).unwrap_or("default");
                eprintln!("Using provider: {default_name}");
                default.clone()
            } else {
                eprintln!(
                    "No providers configured. Set NVIDIA_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, or run Ollama locally."
                );
                std::process::exit(1);
            };

            let config = Config::default();
            let coordinator = Coordinator::new(config, provider_arc);

            // Provider-aware default model (avoids 404 on providers that don't have gpt-4o)
            let default_model = model
                .or_else(|| std::env::var("BKG_DEFAULT_MODEL").ok())
                .unwrap_or_else(|| {
                    match selected_provider.as_deref() {
                        Some("nvidia") => "meta/llama-3.3-70b-instruct",
                        Some("ollama") => "mistral-7b",
                        _ => "gpt-4o",
                    }
                    .to_string()
                });

            if let Some(prompt_text) = prompt {
                // Run prompt through chain executor with truth-gated links
                let status_bus = StatusBus::new();
                let model_router = ModelRouter::new(registry.clone());
                let mut builder = ChainBuilder::new()
                    .with_status_bus(status_bus.clone())
                    .with_default_model(&default_model)
                    .with_model_router(model_router);
                let mut chain = builder.build(&prompt_text);

                let executor = CliLinkExecutor::new(coordinator, chain.id.to_string());
                let _report = builder.run(&mut chain, &executor).await?;

                println!("{}", chain.summary());
            } else {
                // Launch interactive chat loop.
                run_interactive(coordinator, &default_model).await?;
            }
        }

        Commands::Tui { provider, model } => {
            let provider_arc: Arc<dyn bkg_provider::LLMProvider + Send + Sync> = if let Some(name) = provider {
                registry
                    .get(&name)
                    .ok_or_else(|| {
                        BkgError::Provider(format!(
                            "Provider '{name}' not found. Available: {}",
                            registry.list().join(", ")
                        ))
                    })?
                    .clone()
            } else if let Some(default) = registry.get_default() {
                default.clone()
            } else {
                eprintln!(
                    "No providers configured. Set NVIDIA_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY, or run Ollama locally."
                );
                std::process::exit(1);
            };

            let config = Config::default();
            let coordinator = Coordinator::new(config, provider_arc);
            let status_bus = StatusBus::new();
            let default_model = model.or_else(|| std::env::var("BKG_DEFAULT_MODEL").ok());

            // Build ModelRouter from registry for dynamic routing
            let model_router = ModelRouter::new(registry.clone());

            // Start healing daemon in background
            let heal_bus = status_bus.clone();
            tokio::spawn(async move {
                start_healing_daemon(heal_bus).await;
            });

            run_tui(status_bus, coordinator, default_model, Some(registry), Some(model_router)).await?;
        }

        Commands::DemoMeshGc => {
            run_demo_mesh_gc().await?;
        }

        Commands::Status => {
            // ── System Status ──
            let version = env!("CARGO_PKG_VERSION");
            println!("┌─ BKG System Status ──────────────────────────────");
            println!("│ Version: {version}");
            println!("├─ Providers ──────────────────────────────────────");

            let providers = registry.list();
            let default_name = providers.first().map(|s| s.as_str()).unwrap_or("none");

            if providers.is_empty() {
                println!("│ ⚠️  No providers configured");
                println!("│    Set an API key: bkg login <provider>");
            } else {
                for name in providers.iter() {
                    let provider = registry.get(name).unwrap();
                    let status = match provider.health_check().await {
                        Ok(_) => "✓",
                        Err(_) => "✗",
                    };
                    println!("│   {status} {name}");
                }
                println!("│   Default: {default_name}");
            }

            // ── Budget ──
            println!("├─ Budget ─────────────────────────────────────────");
            let budget_path = dirs::config_dir()
                .unwrap_or_else(|| std::path::PathBuf::from("."))
                .join("bkg")
                .join("budget.json");
            if budget_path.exists() {
                let store = bkg_budget::MetricsStore::load(&budget_path);
                let (input_tokens, output_tokens) = store.total_tokens();
                let total_cost = store.total_cost();
                println!("│   Tokens: {} in / {} out", input_tokens, output_tokens);
                println!("│   Cost:   ${:.4}", total_cost);
            } else {
                println!("│   No budget data yet");
            }

            // ── Memory ──
            println!("├─ Memory ────────────────────────────────────────");
            let memory_path = std::path::Path::new("MEMORY.md");
            if memory_path.exists() {
                if let Ok(content) = std::fs::read_to_string(memory_path) {
                    let lines = content.lines().count();
                    println!("│   MEMORY.md: {lines} lines, {} bytes", content.len());
                }
            } else {
                println!("│   No MEMORY.md found");
            }

            // ── Skills ──
            println!("├─ Skills ────────────────────────────────────────");
            let skill_mgr = bkg_cli::skills_sys::SkillsManager::new();
            let available = skill_mgr.list_available();
            if available.is_empty() {
                println!("│   No skills available (use 'bkg skills install')");
            } else {
                println!("│   {} skills available", available.len());
            }

            println!("├─ Help ──────────────────────────────────────────");
            println!("│   bkg chat \"prompt\"     One-shot AI prompt");
            println!("│   bkg session start     Start coding session");
            println!("│   bkg skills list       List available skills");
            println!("│   bkg snapshot run      Run SWD verification");
            println!("│   bkg verify run        Run CI checks");
            println!("└──────────────────────────────────────────────────");
        }

        Commands::Version => {
            println!("bkg {}", env!("CARGO_PKG_VERSION"));
        }

        Commands::Managed(sub) => match sub {
            ManagedCommands::Status => {
                bkg_cli::managed::show_status();
            }
            ManagedCommands::Preset { name } => match name {
                Some(name) => bkg_cli::managed::show_preset(&name),
                None => bkg_cli::managed::list_presets(),
            },
            ManagedCommands::Run { preset, task } => {
                bkg_cli::managed::run_session(&preset, &task)
                    .await
                    .unwrap_or_else(|e| eprintln!("Error: {e}"));
            }
            ManagedCommands::Validate => {
                bkg_cli::managed::validate_presets();
            }
        },
        Commands::Skills(command) => {
            bkg_cli::skills::handle_skills(command).await?;
        }
        Commands::Session(command) => {
            bkg_cli::session::handle_session(command).await?;
        }
        Commands::Budget(command) => {
            bkg_cli::budget::handle_budget(command).await?;
        }
        Commands::Memory(command) => {
            bkg_cli::memory::handle_memory(command).await?;
        }
        Commands::Verify(command) => {
            bkg_cli::verify::handle_verify(command).await?;
        }
        Commands::Snapshot(command) => {
            bkg_cli::snapshot::handle_snapshot(command).await?;
        }
        Commands::Capsule(command) => {
            bkg_cli::capsule::handle_capsule_command(command).await?;
        }

        Commands::Work(command) => {
            bkg_cli::work::handle_work(command).await?;
        }
    }

    Ok(())
}

/// Interactive REPL chat loop.
#[allow(dead_code)]
async fn run_interactive(
    coordinator: Coordinator,
    model_name: &str,
) -> std::result::Result<(), BkgError> {
    use std::io::BufRead;

    println!("┌─ BKG Interactive Chat ───────────────────────────────");
    println!("│ Type your prompts or special commands:");
    println!("│   /help     Show available commands");
    println!("│   /exit     End the session");
    println!("│   /clear    Clear conversation history");
    println!("│   /model    Show current model");
    println!("│   /version  Show bkg version");
    println!("│");
    println!("│ Press Ctrl+C to exit at any time.");
    println!("└──────────────────────────────────────────────────────");
    println!();

    let mut history: Vec<String> = Vec::new();

    loop {
        print!("> ");
        std::io::Write::flush(&mut std::io::stdout()).ok();

        let mut input = String::new();
        if std::io::stdin().lock().read_line(&mut input).is_err() || input.trim().is_empty() {
            if input.trim().is_empty() {
                continue;
            }
            // EOF or error
            println!("\nBye!");
            break;
        }

        let input = input.trim().to_string();

        // Handle slash commands
        if input.starts_with('/') {
            let handled = match input.as_str() {
                "/exit" | "/quit" | "/q" => {
                    println!("Exiting interactive mode.");
                    return Ok(());
                }
                "/help" | "/h" | "/?" => {
                    println!("Commands:");
                    println!("  /exit    End the session");
                    println!("  /clear   Clear conversation history");
                    println!("  /model   Show current model");
                    println!("  /version Show bkg version");
                    println!("  /help    Show this help");
                    true
                }
                "/clear" | "/c" => {
                    history.clear();
                    println!("Conversation history cleared.");
                    true
                }
                "/model" | "/m" => {
                    println!("Current model: {model_name}");
                    if let Some(cfg) = coordinator
                        .config_handle()
                        .await
                        .read()
                        .await
                        .agents
                        .get("default")
                    {
                        if let Some(sel) = &cfg.model {
                            println!("  Provider: {}", sel.provider);
                            if let Some(maxt) = sel.max_tokens {
                                println!("  Max tokens: {maxt}");
                            }
                            if let Some(temp) = sel.temperature {
                                println!("  Temperature: {temp}");
                            }
                        }
                    }
                    println!("  History entries: {}", history.len());
                    true
                }
                "/version" | "/v" => {
                    println!("bkg {}", env!("CARGO_PKG_VERSION"));
                    true
                }
                _ => {
                    println!("Unknown command: {input}. Type /help for commands.");
                    true
                }
            };
            if handled {
                continue;
            }
        }

        // Send to the agent
        history.push(input.clone());
        match coordinator.run(&input).await {
            Ok(response) => {
                let text = response.text();
                println!("{text}");
                println!();
            }
            Err(e) => {
                eprintln!("Error: {e}");
                println!();
            }
        }
    }

    Ok(())
}

async fn start_healing_daemon(bus: StatusBus) {
    use bkg_cli::tui::status::{AgentEvent, CapsuleEventKind};
    loop {
        sleep(Duration::from_secs(30)).await;

        // Probe capsule store health
        let store = bkg_cli::capsule::CapsuleStore::new();
        let capsules = match store.list_capsules() {
            Ok(caps) => caps,
            Err(_) => continue,
        };

        let healthy = capsules.iter().filter(|c| c.healthy).count();
        let degraded = capsules.iter().filter(|c| !c.healthy && c.state != "Unknown").count();
        let missing = capsules.iter().filter(|c| c.state == "Unknown").count();

        if healthy > 0 || degraded > 0 || missing > 0 {
            bus.publish("healer", AgentEvent::CapsuleEvent {
                state: if degraded > 0 || missing > 0 {
                    CapsuleEventKind::Degraded
                } else {
                    CapsuleEventKind::Healthy
                },
                message: format!("{} healthy, {} degraded, {} missing", healthy, degraded, missing),
            });
        }

        // Auto-repair degraded capsules
        for cap in &capsules {
            if !cap.healthy {
                let _ = store.repair_capsule(&cap.capsule_id);
                bus.publish_heal("capsule-repair", &format!("repaired {}", cap.capsule_id));
            }
        }
    }
}

/// Mesh + GC demo.
async fn run_demo_mesh_gc() -> std::result::Result<(), BkgError> {
    println!("=== Mesh + Garbage Collector Observation Demo ===");

    let node_id = "demo-node".to_string();
    let initial_trust = TrustVector::new(0.0, 0.0, 0.0, 0.0, 0.0);
    let mesh = MeshNode::new(node_id.clone(), initial_trust);
    // mesh is already Arc<MeshNode> from MeshNode::new()
    let gc = Arc::new(GarbageCollector::new(None));
    gc.clone()
        .start_observing(mesh.clone(), Duration::from_secs(2));
    println!("GC started observing mesh node...");

    let mesh_clone = mesh.clone();
    tokio::spawn(async move {
        let mut count = 0;
        loop {
            sleep(Duration::from_secs(3)).await;
            let subnet = format!("subnet-{}", (count % 3));
            let region = EntropyRegion::new(
                subnet.clone(),
                0.3 + (count as f32 * 0.05) % 0.6,
                0.1,
                0.05 + (count as f32 * 0.02) % 0.2,
            );
            mesh_clone.add_entropy_region(region).await;
            count += 1;
        }
    });

    loop {
        sleep(Duration::from_secs(5)).await;
        let health = gc.global_health().await;
        let topology = gc.topology();
        let subnet_count = topology.subnet_count().await;
        let avg_variance = topology.average_trust_variance().await;
        println!(
            "[Demo] GC health: {:.3} | subnets: {} | avg trust variance: {:.3}",
            health, subnet_count, avg_variance
        );
    }
}
