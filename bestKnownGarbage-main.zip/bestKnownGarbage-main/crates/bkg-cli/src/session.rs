use crate::Result;
use bkg_session::{SessionConfig, SessionError, SessionManager};
use clap::{Args, Subcommand};

/// Session management commands
#[derive(Debug, Subcommand)]
pub enum SessionCommand {
    /// Start a new session
    Start(StartArgs),
    /// Resume the latest session
    ResumeLatest,
    /// Resume a specific session by ID
    Resume(ResumeArgs),
    /// List all sessions
    List,
    /// End the current session
    End(EndArgs),
    /// Show current session state
    Show,
    /// Create a branch from a session
    Branch(BranchArgs),
    /// Commit current session
    Commit(CommitArgs),
}

#[derive(Debug, Args)]
pub struct StartArgs {
    /// Initial summary for the session
    summary: String,
    /// Session ID (optional, auto-generated if not provided)
    #[arg(long)]
    id: Option<String>,
}

#[derive(Debug, Args)]
pub struct ResumeArgs {
    /// Session ID to resume
    id: String,
}

#[derive(Debug, Args)]
pub struct EndArgs {
    /// Commit message (optional)
    #[arg(long)]
    message: Option<String>,
}

#[derive(Debug, Args)]
pub struct BranchArgs {
    /// Source session ID
    source: String,
    /// New session ID for the branch
    #[arg(long)]
    id: Option<String>,
}

#[derive(Debug, Args)]
pub struct CommitArgs {
    /// Commit message
    message: String,
}

pub async fn handle_session(command: SessionCommand) -> Result<()> {
    let mut manager = SessionManager::new(SessionConfig::default());

    match command {
        SessionCommand::Start(args) => start_session(&mut manager, args).await?,
        SessionCommand::ResumeLatest => resume_latest(&mut manager).await?,
        SessionCommand::Resume(args) => resume_session(&mut manager, args).await?,
        SessionCommand::List => list_sessions(&manager).await?,
        SessionCommand::End(args) => end_session(&mut manager, args).await?,
        SessionCommand::Show => show_session(&manager).await?,
        SessionCommand::Branch(args) => create_branch(&mut manager, args).await?,
        SessionCommand::Commit(args) => commit_session(&mut manager, args).await?,
    }

    Ok(())
}

fn to_bkg_err(e: SessionError) -> crate::BkgError {
    crate::BkgError::Provider(format!("Session error: {e}"))
}

async fn start_session(manager: &mut SessionManager, args: StartArgs) -> Result<()> {
    let state = manager.start(&args.summary).map_err(to_bkg_err)?;
    println!("Started session: {}", state.id);
    Ok(())
}

async fn resume_latest(manager: &mut SessionManager) -> Result<()> {
    match manager.resume_latest() {
        Ok(state) => {
            println!("Resumed session: {}", state.id);
            println!("Summary: {}", state.summary);
        }
        Err(SessionError::NotFound(_)) => {
            println!("No sessions found");
        }
        Err(e) => {
            eprintln!("Failed to resume session: {}", e);
            std::process::exit(1);
        }
    }
    Ok(())
}

async fn resume_session(manager: &mut SessionManager, args: ResumeArgs) -> Result<()> {
    match manager.resume(&args.id) {
        Ok(state) => {
            println!("Resumed session: {}", state.id);
            println!("Summary: {}", state.summary);
        }
        Err(SessionError::NotFound(_)) => {
            eprintln!("Session not found: {}", args.id);
            std::process::exit(1);
        }
        Err(e) => {
            eprintln!("Failed to resume session: {}", e);
            std::process::exit(1);
        }
    }
    Ok(())
}

async fn list_sessions(manager: &SessionManager) -> Result<()> {
    let sessions = manager.list_sessions().map_err(to_bkg_err)?;
    if sessions.is_empty() {
        println!("No sessions found");
    } else {
        println!("Sessions:");
        for session in sessions.iter() {
            println!("  {} - {}", session.id, session.summary);
        }
    }
    Ok(())
}

async fn end_session(manager: &mut SessionManager, args: EndArgs) -> Result<()> {
    manager.end(args.message.as_deref()).map_err(to_bkg_err)?;
    println!("Session ended");
    Ok(())
}

async fn show_session(manager: &SessionManager) -> Result<()> {
    if let Some(state) = manager.state() {
        println!("Current session: {}", state.id);
        println!("Summary: {}", state.summary);
        println!("Created: {}", state.created_at);
        println!("Updated: {}", state.updated_at);
    } else {
        println!("No active session");
    }
    Ok(())
}

async fn create_branch(manager: &mut SessionManager, args: BranchArgs) -> Result<()> {
    let branch_id = manager
        .create_session_branch(&args.source)
        .map_err(to_bkg_err)?;
    println!("Created branch: {}", branch_id);
    Ok(())
}

async fn commit_session(manager: &mut SessionManager, args: CommitArgs) -> Result<()> {
    manager.commit_session(&args.message).map_err(to_bkg_err)?;
    println!("Session committed");
    Ok(())
}
