//! Router — decomposes prompts into chains and manages execution.
//!
//! "implement auth + tests + docs"
//!   → ChainBuilder::from_prompt(prompt)
//!     → Link 1: coder/llama-3.3 "implement auth"
//!     → Link 2: coder/llama-3.3 "add tests"
//!     → Link 3: docs/mistral "update docs"
//!   → ChainExecutor::run(chain)
//!     → Link 1 → Truth Gate → Link 2 → Truth Gate → Link 3 → Truth Gate

use bkg_core::BkgError;
use bkg_core::chain::{
    Chain, ChainStatus, Link, LinkContext, LinkExecutor, LinkStatus, TruthReport,
};
use chrono::Utc;

use crate::chain::CliLinkExecutor;
use crate::model_router::{ModelRouter, TaskType};
use crate::tui::status::StatusBus;

/// Builds chains from user prompts.
pub struct ChainBuilder {
    status_bus: Option<StatusBus>,
    next_id: u64,
    /// Model overrides per role
    model_overrides: std::collections::HashMap<String, String>,
    /// Fallback default model (overrides role defaults but not per-role overrides)
    default_model: Option<String>,
    /// Optional ModelRouter for dynamic model routing
    model_router: Option<ModelRouter>,
}

impl ChainBuilder {
    pub fn new() -> Self {
        Self {
            status_bus: None,
            next_id: 1,
            model_overrides: std::collections::HashMap::new(),
            default_model: None,
            model_router: None,
        }
    }

    /// Attach a ModelRouter for dynamic model selection.
    pub fn with_model_router(mut self, router: ModelRouter) -> Self {
        self.model_router = Some(router);
        self
    }

    /// Attach a status bus for TUI reporting.
    pub fn with_status_bus(mut self, bus: StatusBus) -> Self {
        self.status_bus = Some(bus);
        self
    }

    /// Set a model override for a role.
    pub fn set_model(&mut self, role: &str, model: &str) {
        self.model_overrides
            .insert(role.to_string(), model.to_string());
    }

    /// Set a default model that applies when no role-specific override exists.
    pub fn with_default_model(mut self, model: &str) -> Self {
        self.default_model = Some(model.to_string());
        self
    }

    /// Get the model for a role, respecting overrides and dynamic routing.
    fn get_model(&self, role: &str) -> String {
        // Priority: role override > dynamic router > default model > fallback
        if let Some(model) = self.model_overrides.get(role) {
            return model.clone();
        }
        if let Some(ref router) = self.model_router {
            let task = TaskType::from_role(role);
            let rt = tokio::runtime::Handle::try_current();
            if let Ok(handle) = rt {
                let result = handle.block_on(router.route(task));
                return result.model;
            }
        }
        if let Some(model) = &self.default_model {
            return model.clone();
        }
        // Fallback: use basic role defaults
        match role {
            "planner" => "mistral-7b".to_string(),
            "coder" => "meta/llama-3.3-70b-instruct".to_string(),
            "reviewer" => "mistral-7b".to_string(),
            "docs" => "mistral-7b".to_string(),
            "overseer" => "mistral-7b".to_string(),
            _ => "mistral-7b".to_string(),
        }
    }

    /// Decompose a prompt and build a Chain.
    ///
    /// Detects multi-part prompts (separated by +, newlines, numbered lists)
    /// and creates one Link per part.
    pub fn build(&mut self, prompt: &str) -> Chain {
        let chain_id = format!("ch-{}", self.next_id);
        self.next_id += 1;

        let mut chain = Chain::new(chain_id.clone(), prompt.to_string());
        let parts = self.decompose(prompt);

        let mut prev_context: Option<LinkContext> = None;
        let prev_output = String::new();

        for (i, (description, role)) in parts.iter().enumerate() {
            let link_id = format!("link-{}", i + 1);
            let model = self.get_model(role);

            let context = if let Some(ref prev) = prev_context {
                let mut ctx = LinkContext::next(prev, &prev_output, role, &model);
                ctx.skills = self.role_skills(role);
                ctx
            } else {
                let mut ctx = LinkContext::first(role, &model);
                ctx.skills = self.role_skills(role);
                ctx
            };

            let link = Link::new(link_id, description.clone(), context);
            chain.add_link(link);

            // Publish route event for TUI
            if let Some(ref bus) = self.status_bus {
                let model = self.get_model(role);
                bus.publish_route(role, &model, "dynamic");
            }

            // For sequential building, store context for next iteration
            prev_context = chain.links.last().map(|l| l.context.clone());
        }

        // Add an overseer link at the end
        let overseer_id = format!("link-{}", parts.len() + 1);
        let overseer_model = self.get_model("overseer");
        let overseer_desc = "Final review of all work".to_string();
        if let Some(ref prev) = prev_context {
            let mut overseer_ctx =
                LinkContext::next(prev, &prev_output, "overseer", &overseer_model);
            overseer_ctx.skills = vec!["review".to_string()];
            let overseer = Link::new(overseer_id, overseer_desc, overseer_ctx);
            chain.add_link(overseer);
        }

        chain
    }

    /// Run a chain through the executor, link by link.
    pub async fn run(
        &self,
        chain: &mut Chain,
        executor: &CliLinkExecutor,
    ) -> std::result::Result<TruthReport, BkgError> {
        let chain_id = chain.id.clone();

        chain.status = ChainStatus::Running;
        let mut report = TruthReport::new(chain_id.clone());

        let num_links = chain.links.len();
        for i in 0..num_links {
            // Get the link (can't borrow chain mutably while also reading)
            let link_clone = {
                let link = &chain.links[i];
                if link.status != LinkStatus::Pending {
                    continue;
                }
                link.clone()
            };

            // Mark as running
            chain.links[i].status = LinkStatus::Running;
            chain.links[i].started_at = Some(Utc::now());

            // Execute
            let (result, truth) = executor.execute(&link_clone, &chain_id).await?;

            // Store result
            chain.links[i].result = Some(result.clone());
            chain.links[i].completed_at = Some(Utc::now());

            if truth.passed {
                chain.links[i].status = LinkStatus::Passed;
            } else {
                let fail_reason = truth
                    .failure_reason
                    .clone()
                    .unwrap_or_else(|| "Truth check failed".to_string());
                chain.links[i].status = LinkStatus::Failed(fail_reason.clone());
                chain.status = ChainStatus::Failed(fail_reason.clone());
                report.add_verdict(truth);
                // Chain stops on first failure
                break;
            }

            report.add_verdict(truth);

            // Propagate output to next link's context
            if i + 1 < num_links {
                let output = result.output.clone();
                if let Some(next_ctx) = chain.links.get_mut(i + 1) {
                    next_ctx.context.previous_output = output;
                }
            }
        }

        // Update chain status
        if chain.status == ChainStatus::Running {
            chain.status = ChainStatus::Completed;
        }
        let completed = Utc::now();
        chain.completed_at = Some(completed);
        let duration = completed
            .signed_duration_since(chain.created_at)
            .to_std()
            .unwrap_or_default();
        report.set_duration(duration);
        chain.truth_report = Some(report.clone());

        Ok(report)
    }

    /// Decompose a prompt into (description, role) pairs.
    fn decompose(&self, prompt: &str) -> Vec<(String, String)> {
        let prompt = prompt.trim();
        if prompt.is_empty() {
            return vec![("empty task".to_string(), "coder".to_string())];
        }

        // Split on +, newlines, or numbered items
        let raw_parts: Vec<&str> = prompt
            .split(|c: char| c == '+' || c == ',')
            .flat_map(|s| s.split('\n'))
            .map(|s| s.trim())
            .filter(|s| !s.is_empty())
            .collect();

        // Strip leading numbers like "1. " or "1) "
        let clean_parts: Vec<String> = raw_parts
            .iter()
            .map(|s| {
                let s = s.trim();
                let s = s.strip_prefix(|c: char| c.is_ascii_digit()).unwrap_or(s);
                let s = s
                    .strip_prefix(|c: char| c == '.' || c == ')' || c == ':')
                    .unwrap_or(s);
                s.trim().to_string()
            })
            .filter(|s| !s.is_empty())
            .collect();

        if clean_parts.len() <= 1 {
            // Single task — determine role from keywords
            let role = self.detect_role(prompt);
            return vec![(prompt.to_string(), role)];
        }

        // Multiple tasks — assign roles based on keywords per part
        clean_parts
            .into_iter()
            .map(|part| {
                let role = self.detect_role(&part);
                (part, role)
            })
            .collect()
    }

    /// Detect the agent role from keywords in the task description.
    fn detect_role(&self, task: &str) -> String {
        let lower = task.to_lowercase();
        if lower.contains("test") || lower.contains("verify") || lower.contains("check") {
            "reviewer".to_string()
        } else if lower.contains("doc") || lower.contains("readme") || lower.contains("comment") {
            "docs".to_string()
        } else if lower.contains("plan") || lower.contains("design") || lower.contains("architect")
        {
            "planner".to_string()
        } else if lower.contains("review") || lower.contains("audit") || lower.contains("inspect") {
            "reviewer".to_string()
        } else {
            "coder".to_string()
        }
    }

    /// Get the skills to inject for a given role.
    fn role_skills(&self, role: &str) -> Vec<String> {
        match role {
            "coder" => vec!["rust".to_string()],
            "reviewer" => vec!["review".to_string()],
            "docs" => vec!["documentation".to_string()],
            "planner" => vec!["planning".to_string()],
            _ => vec![],
        }
    }
}
