//! Strict Write Discipline (SWD) — filesystem verification engine.
//!
//! Lifecycle: Plan → Snapshot_Before → Execute → Snapshot_After → Verify → Commit/Rollback
//!
//! **Workspace Reversibility:** SWD snapshots and rollbacks apply ONLY to the active workspace
//! filesystem (working directory). The execution history (timeline.jsonl) and receipts remain
//! **strictly immutable** and append-only. SWD does NOT roll back causal history.
//!
//! **Timeline Anchor:** Each completed SWD run MUST emit a `TimelineEvent` with type
//! `FileCommit` and the SHA-256 state hashes to the append-only timeline.jsonl. This couples
//! workspace mutations to the deterministic replay log.
//!
//! Ported from mythos-router TypeScript. See `/home/bkg/workspace/mythos-router/src/swd.ts`

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, HashMap};
use std::fs;
use std::path::{Path, PathBuf};

/// Action intent classification.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ActionIntent {
    /// Intended to mutate filesystem
    Mutate,
    /// Intended as no-change
    Noop,
    /// Intent unknown
    Unknown,
}

/// Types of file operations (action classifier — used by the SWD engine).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum FileOperation {
    Create,
    Modify,
    Delete,
    Read,
}

/// A recorded file operation with SHA-256 hashes (used for timeline anchoring).
///
/// **Contract binding (UCC-4 v1.1):** This is the structured operation record
/// embedded in `FileSnapshot.operations`. Each variant carries the cryptographic
/// hashes needed for deterministic replay and causality verification.
///
/// Unlike `FileOperation` (which is an action classifier for the SWD engine),
/// this type is a **record** — it captures what happened, with proof.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum RecordedFileOperation {
    /// A new file was created.
    Create {
        /// Path relative to workspace root.
        path: String,
        /// SHA-256 hash of the written content.
        sha256: String,
    },
    /// An existing file was modified.
    Modify {
        /// Path relative to workspace root.
        path: String,
        /// SHA-256 hash of the content BEFORE the modification.
        before_sha256: String,
        /// SHA-256 hash of the content AFTER the modification.
        after_sha256: String,
    },
    /// A file was deleted.
    Delete {
        /// Path relative to workspace root.
        path: String,
        /// SHA-256 hash of the content that was deleted.
        last_sha256: String,
    },
}

/// A single file action plan.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileAction {
    /// Path relative to CWD
    pub path: String,
    /// Operation type
    pub operation: FileOperation,
    /// Whether this action intends mutation
    pub intent: ActionIntent,
    /// Content to write (for Create/Modify)
    pub content: Option<String>,
    /// Expected content hash
    pub content_hash: Option<String>,
    /// Human-readable description
    pub description: Option<String>,
}

/// Verification result status.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum VerificationStatus {
    Verified,
    Noop,
    Failed,
    Drift,
}

/// Snapshot of a file at a point in time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileSnapshot {
    pub path: PathBuf,
    pub exists: bool,
    pub size: u64,
    pub modified: u64,
    pub hash: String,
    /// Raw bytes (kept for rollback)
    #[serde(skip)]
    pub content: Option<Vec<u8>>,
}

/// Summary view of a snapshot (no content bytes).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileSnapshotSummary {
    pub path: String,
    pub exists: bool,
    pub size: u64,
    pub modified: u64,
    pub hash: String,
}

/// Result of verifying one action.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ActionResult {
    pub action: FileAction,
    pub status: VerificationStatus,
    pub detail: String,
    pub before: Option<FileSnapshotSummary>,
    pub after: Option<FileSnapshotSummary>,
}

/// Overall SWD run result.
///
/// Includes the aggregated before/after state hashes for timeline anchoring.
/// Consumers MUST emit a `TimelineEvent::FileCommit` with these hashes
/// to the append-only timeline.jsonl for deterministic replay.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SwdRunResult {
    pub success: bool,
    pub results: Vec<ActionResult>,
    pub rolled_back: bool,
    pub rollback_errors: Vec<String>,
    pub errors: Vec<String>,
    /// SHA-256 hashes of all files BEFORE the run (path → hash).
    /// Used for timeline anchoring and capsule snapshot diffing.
    pub before_state: BTreeMap<String, String>,
    /// SHA-256 hashes of all files AFTER the run (path → hash).
    pub after_state: BTreeMap<String, String>,
}

/// SWD engine configuration.
#[derive(Debug, Clone)]
pub struct SwdOptions {
    /// Dry-run mode (preview only, no mutations)
    pub dry_run: bool,
    /// Strict mode (drift = failure)
    pub strict: bool,
    /// Enable automatic rollback on failure
    pub enable_rollback: bool,
    /// Working directory root
    pub working_dir: PathBuf,
}

impl Default for SwdOptions {
    fn default() -> Self {
        Self {
            dry_run: false,
            strict: true,
            enable_rollback: true,
            working_dir: PathBuf::from("."),
        }
    }
}

/// Maximum content size for a single write action.
pub const MAX_WRITE_BYTES: u64 = 200_000;

/// Errors from SWD operations.
#[derive(Debug, thiserror::Error)]
pub enum SwdError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Path traversal detected: {0}")]
    PathTraversal(String),
    #[error("Large write blocked: {0} bytes exceeds {MAX_WRITE_BYTES}")]
    LargeWrite(u64),
    #[error("Verification failed: {0}")]
    Verification(String),
    #[error("Rollback failed: {0}")]
    Rollback(String),
}

type Result<T> = std::result::Result<T, SwdError>;

/// Create a SHA-256 hex digest of bytes.
fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    format!("{:x}", hasher.finalize())
}

/// Resolve a path safely, preventing traversal outside the working directory.
fn resolve_safe_path(working_dir: &Path, unsafe_path: &str) -> Result<PathBuf> {
    let cwd = working_dir.canonicalize().map_err(|_| {
        SwdError::PathTraversal(format!(
            "Cannot canonicalize working dir: {:?}",
            working_dir
        ))
    })?;
    let target = PathBuf::from(unsafe_path);
    let abs = if target.is_absolute() {
        target
    } else {
        cwd.join(&target)
    };
    let canonical = abs.canonicalize().unwrap_or_else(|_| abs.clone());

    // Verify it's under working directory
    if !canonical.starts_with(&cwd) {
        return Err(SwdError::PathTraversal(format!(
            "Path '{}' escapes working directory",
            unsafe_path
        )));
    }
    Ok(canonical)
}

/// Take a snapshot of a file.
fn snapshot_file(path: &Path) -> FileSnapshot {
    match fs::metadata(path) {
        Ok(meta) if meta.is_file() => match fs::read(path) {
            Ok(content) => {
                let hash = sha256_hex(&content);
                FileSnapshot {
                    path: path.to_path_buf(),
                    exists: true,
                    size: meta.len(),
                    modified: meta
                        .modified()
                        .map(|t| {
                            t.duration_since(std::time::UNIX_EPOCH)
                                .unwrap_or_default()
                                .as_secs()
                        })
                        .unwrap_or(0),
                    hash,
                    content: Some(content),
                }
            }
            Err(_) => FileSnapshot {
                path: path.to_path_buf(),
                exists: false,
                size: 0,
                modified: 0,
                hash: String::new(),
                content: None,
            },
        },
        _ => FileSnapshot {
            path: path.to_path_buf(),
            exists: false,
            size: 0,
            modified: 0,
            hash: String::new(),
            content: None,
        },
    }
}

fn summarize(snap: &FileSnapshot) -> FileSnapshotSummary {
    FileSnapshotSummary {
        path: snap.path.to_string_lossy().to_string(),
        exists: snap.exists,
        size: snap.size,
        modified: snap.modified,
        hash: snap.hash.clone(),
    }
}

fn make_summary(snap: &Option<FileSnapshot>) -> Option<FileSnapshotSummary> {
    snap.as_ref().map(summarize)
}

/// Internal session context for tracking snapshots and rollback state.
struct SessionContext {
    snapshots_before: HashMap<PathBuf, FileSnapshot>,
    snapshots_after: HashMap<PathBuf, FileSnapshot>,
    execution_order: Vec<FileAction>,
    rollback_map: HashMap<PathBuf, FileSnapshot>,
    root: PathBuf,
}

impl SessionContext {
    fn new(root: PathBuf) -> Self {
        Self {
            snapshots_before: HashMap::new(),
            snapshots_after: HashMap::new(),
            execution_order: Vec::new(),
            rollback_map: HashMap::new(),
            root,
        }
    }

    fn get_before(&mut self, action: &FileAction) -> Result<FileSnapshot> {
        let abs = resolve_safe_path(&self.root, &action.path)?;
        if let Some(snap) = self.snapshots_before.get(&abs) {
            return Ok(snap.clone());
        }
        let snap = snapshot_file(&abs);
        if !self.rollback_map.contains_key(&abs) {
            self.rollback_map.insert(abs.clone(), snap.clone());
        }
        self.snapshots_before.insert(abs, snap.clone());
        Ok(snap)
    }

    fn get_after(&mut self, action: &FileAction) -> Result<FileSnapshot> {
        let abs = resolve_safe_path(&self.root, &action.path)?;
        let snap = snapshot_file(&abs);
        self.snapshots_after.insert(abs, snap.clone());
        Ok(snap)
    }

    fn log_execution(&mut self, action: &FileAction) {
        self.execution_order.push(action.clone());
    }

    /// Aggregate before-state hashes into a sorted map for timeline anchoring.
    fn aggregate_before_hashes(&self) -> BTreeMap<String, String> {
        let mut map = BTreeMap::new();
        for (path, snap) in &self.snapshots_before {
            let path_str = path.to_string_lossy().to_string();
            if !snap.hash.is_empty() {
                map.insert(path_str, snap.hash.clone());
            }
        }
        map
    }

    /// Aggregate after-state hashes into a sorted map for timeline anchoring.
    fn aggregate_after_hashes(&self) -> BTreeMap<String, String> {
        let mut map = BTreeMap::new();
        for (path, snap) in &self.snapshots_after {
            let path_str = path.to_string_lossy().to_string();
            if !snap.hash.is_empty() {
                map.insert(path_str, snap.hash.clone());
            }
        }
        map
    }
}

/// The SWD engine — filesystem verification kernel.
pub struct SwdEngine {
    options: SwdOptions,
}

impl SwdEngine {
    pub fn new(options: SwdOptions) -> Self {
        Self { options }
    }

    /// Run a set of file actions through the SWD lifecycle.
    pub fn run(&self, actions: Vec<FileAction>) -> Result<SwdRunResult> {
        if actions.is_empty() {
            return Ok(SwdRunResult {
                success: true,
                results: vec![],
                rolled_back: false,
                rollback_errors: vec![],
                errors: vec![],
                before_state: BTreeMap::new(),
                after_state: BTreeMap::new(),
            });
        }

        // Pre-check: large writes
        for action in &actions {
            if let Some(ref content) = action.content {
                if content.len() as u64 > MAX_WRITE_BYTES {
                    return Ok(SwdRunResult {
                        success: false,
                        results: vec![],
                        rolled_back: false,
                        rollback_errors: vec![],
                        errors: vec![format!(
                            "Large write blocked: {} bytes exceeds {}",
                            content.len(),
                            MAX_WRITE_BYTES
                        )],
                        before_state: BTreeMap::new(),
                        after_state: BTreeMap::new(),
                    });
                }
            }
        }

        let mut ctx = SessionContext::new(self.options.working_dir.clone());
        let mut results = Vec::new();
        let mut overall_success = true;
        let mut rollback_errors = Vec::new();

        // 1. Snapshot Before
        for action in &actions {
            ctx.get_before(action)?;
        }

        // 2. Execute
        if !self.options.dry_run {
            for action in &actions {
                self.execute_action(action)?;
                ctx.log_execution(action);
            }
        }

        // 3. Snapshot After + Verify
        for action in &actions {
            if self.options.dry_run {
                results.push(ActionResult {
                    action: action.clone(),
                    status: VerificationStatus::Verified,
                    detail: format!(
                        "Dry-run: planned {} {} (not applied)",
                        action_name(&action.operation),
                        action.path
                    ),
                    before: make_summary(
                        &ctx.snapshots_before
                            .get(&resolve_safe_path(&self.options.working_dir, &action.path)?)
                            .cloned(),
                    ),
                    after: None,
                });
                continue;
            }

            let before = ctx.get_before(action)?;
            let after = ctx.get_after(action)?;
            let verification = self.verify(&action, &before, &after);

            if verification.status == VerificationStatus::Failed
                || (self.options.strict && verification.status == VerificationStatus::Drift)
            {
                overall_success = false;
            }

            results.push(verification);
        }

        // 4. Rollback on failure
        let mut rolled_back = false;
        if !overall_success && self.options.enable_rollback && !self.options.dry_run {
            let rb = self.rollback(&mut ctx, &results);
            rolled_back = rb.0;
            rollback_errors = rb.1;
        }

        let errors: Vec<String> = results
            .iter()
            .filter(|r| {
                matches!(
                    r.status,
                    VerificationStatus::Failed | VerificationStatus::Drift
                )
            })
            .map(|r| r.detail.clone())
            .collect();

        let before_state = ctx.aggregate_before_hashes();
        let after_state = ctx.aggregate_after_hashes();

        Ok(SwdRunResult {
            success: overall_success,
            results,
            rolled_back,
            rollback_errors,
            errors,
            before_state,
            after_state,
        })
    }

    fn execute_action(&self, action: &FileAction) -> Result<()> {
        let abs = resolve_safe_path(&self.options.working_dir, &action.path)?;

        match action.operation {
            FileOperation::Create => {
                if abs.exists() {
                    return Err(SwdError::Verification(format!(
                        "CREATE failed: file already exists at {}",
                        action.path
                    )));
                }
                if let Some(ref content) = action.content {
                    if let Some(parent) = abs.parent() {
                        fs::create_dir_all(parent)?;
                    }
                    fs::write(&abs, content)?;
                }
            }
            FileOperation::Modify => {
                if !abs.exists() {
                    return Err(SwdError::Verification(format!(
                        "MODIFY failed: file does not exist at {}",
                        action.path
                    )));
                }
                if let Some(ref content) = action.content {
                    fs::write(&abs, content)?;
                }
            }
            FileOperation::Delete => {
                if abs.exists() {
                    fs::remove_file(&abs)?;
                }
            }
            FileOperation::Read => {}
        }
        Ok(())
    }

    fn verify(
        &self,
        action: &FileAction,
        before: &FileSnapshot,
        after: &FileSnapshot,
    ) -> ActionResult {
        let make_res = |status: VerificationStatus, detail: String| ActionResult {
            action: action.clone(),
            status,
            detail,
            before: Some(summarize(before)),
            after: Some(summarize(after)),
        };

        match action.operation {
            FileOperation::Create => {
                if !after.exists {
                    return make_res(
                        VerificationStatus::Failed,
                        format!("File was not created: {}", action.path),
                    );
                }
                if before.exists {
                    return make_res(
                        VerificationStatus::Drift,
                        format!("File already existed before CREATE: {}", action.path),
                    );
                }
            }
            FileOperation::Modify => {
                if !after.exists {
                    return make_res(
                        VerificationStatus::Failed,
                        format!("File missing after MODIFY: {}", action.path),
                    );
                }
            }
            FileOperation::Delete => {
                if !before.exists {
                    return make_res(
                        VerificationStatus::Drift,
                        format!("DELETE on non-existent file: {}", action.path),
                    );
                }
                if after.exists {
                    return make_res(
                        VerificationStatus::Failed,
                        format!("File still exists after DELETE: {}", action.path),
                    );
                }
            }
            FileOperation::Read => {}
        }

        // Check content hash if specified
        if let Some(ref expected_hash) = action.content_hash {
            if after.hash != *expected_hash {
                return make_res(
                    VerificationStatus::Drift,
                    format!(
                        "Hash mismatch on {}: expected {}, got {}",
                        action.path,
                        &expected_hash[..12.min(expected_hash.len())],
                        &after.hash[..12.min(after.hash.len())]
                    ),
                );
            }
        }

        // Check written content matches intended content
        if let Some(ref content) = action.content {
            if matches!(
                action.operation,
                FileOperation::Create | FileOperation::Modify
            ) {
                let expected_hash = sha256_hex(content.as_bytes());
                if after.hash != expected_hash {
                    return make_res(
                        VerificationStatus::Drift,
                        format!(
                            "Written content does not match intended content for {}",
                            action.path
                        ),
                    );
                }
            }
        }

        let changed = after.hash != before.hash;
        make_res(
            if changed {
                VerificationStatus::Verified
            } else {
                VerificationStatus::Noop
            },
            if changed {
                format!(
                    "Verified: {} {}",
                    action_name(&action.operation),
                    action.path
                )
            } else {
                format!("No-op: {} remains identical", action.path)
            },
        )
    }

    fn rollback(&self, ctx: &mut SessionContext, _results: &[ActionResult]) -> (bool, Vec<String>) {
        let mut errors = Vec::new();
        let mut any_rolled_back = false;
        let mut seen = std::collections::HashSet::new();

        // Process in reverse order
        for action in ctx.execution_order.iter().rev() {
            let abs = match resolve_safe_path(&self.options.working_dir, &action.path) {
                Ok(p) => p,
                Err(e) => {
                    errors.push(format!("Rollback path resolution failed: {}", e));
                    continue;
                }
            };

            if seen.contains(&action.path) {
                continue;
            }
            seen.insert(action.path.clone());

            let original = match ctx.rollback_map.get(&abs) {
                Some(o) => o.clone(),
                None => continue,
            };

            let current = snapshot_file(&abs);

            // Only rollback if nothing else changed the file after our action
            if current.hash
                == ctx
                    .snapshots_after
                    .get(&abs)
                    .map(|s| s.hash.as_str())
                    .unwrap_or("")
            {
                match action.operation {
                    FileOperation::Create | FileOperation::Modify => {
                        if let Some(ref content) = original.content {
                            if let Err(e) = fs::write(&abs, content) {
                                errors.push(format!(
                                    "Rollback write failed for {}: {}",
                                    action.path, e
                                ));
                                continue;
                            }
                        }
                    }
                    FileOperation::Delete => {
                        if original.exists {
                            if let Some(ref content) = original.content {
                                if let Err(e) = fs::write(&abs, content) {
                                    errors.push(format!(
                                        "Rollback write failed for {}: {}",
                                        action.path, e
                                    ));
                                    continue;
                                }
                            }
                        }
                    }
                    FileOperation::Read => {}
                }
                any_rolled_back = true;
            } else {
                errors.push(format!(
                    "Concurrency drift: skipping rollback for {}",
                    action.path
                ));
            }
        }

        (any_rolled_back, errors)
    }
}

fn action_name(op: &FileOperation) -> &'static str {
    match op {
        FileOperation::Create => "CREATE",
        FileOperation::Modify => "MODIFY",
        FileOperation::Delete => "DELETE",
        FileOperation::Read => "READ",
    }
}

// ── Parsing ──────────────────────────────────────────────────

/// Parse [FILE_ACTION] blocks from model output.
pub fn parse_actions(output: &str) -> Vec<FileAction> {
    let mut actions = Vec::new();
    let start_tag = "[FILE_ACTION:";
    let end_tag = "[/FILE_ACTION]";
    let mut cursor = 0;

    while let Some(start_idx) = output[cursor..].find(start_tag) {
        let real_start = cursor + start_idx;
        let remaining = &output[real_start..];
        let end_idx = remaining.find(end_tag);

        if end_idx.is_none() {
            break;
        }
        let real_end = real_start + end_idx.unwrap() + end_tag.len();

        // Extract path from start tag
        let first_line_end = output[real_start..]
            .find('\n')
            .unwrap_or(output[real_start..].len());
        let first_line = &output[real_start..real_start + first_line_end];
        let path_start = start_tag.len();
        let path_end = first_line.rfind(']').unwrap_or(first_line.len());
        let path = first_line[path_start..path_end].trim().to_string();

        if path.is_empty()
            || path.len() > 500
            || path.contains('\0')
            || path.contains("..")
            || path.starts_with('/')
        {
            cursor = real_end;
            continue;
        }

        let block = &output[real_start..real_end];
        let operation = extract_field(block, "OPERATION:");
        let intent = extract_field(block, "INTENT:");
        let content_hash = extract_field(block, "CONTENT_HASH:");
        let description = extract_field(block, "DESCRIPTION:");
        let content = extract_multiline_content(block);

        let Some(op) = operation else {
            cursor = real_end;
            continue;
        };
        let Some(desc) = description else {
            cursor = real_end;
            continue;
        };

        let op_upper = op.to_uppercase();
        let op_kind = match op_upper.as_str() {
            "CREATE" => FileOperation::Create,
            "MODIFY" => FileOperation::Modify,
            "DELETE" => FileOperation::Delete,
            "READ" => FileOperation::Read,
            _ => {
                cursor = real_end;
                continue;
            }
        };

        let action_intent = match intent.as_deref() {
            Some("NOOP") => ActionIntent::Noop,
            Some("UNKNOWN") => ActionIntent::Unknown,
            _ => ActionIntent::Mutate,
        };

        actions.push(FileAction {
            path,
            operation: op_kind,
            intent: action_intent,
            content_hash,
            description: Some(desc),
            content,
        });

        cursor = real_end;
    }

    actions
}

fn extract_field(block: &str, prefix: &str) -> Option<String> {
    for line in block.lines() {
        let trimmed = line.trim();
        if trimmed.to_uppercase().starts_with(&prefix.to_uppercase()) {
            return Some(trimmed[prefix.len()..].trim().to_string());
        }
    }
    None
}

fn extract_multiline_content(block: &str) -> Option<String> {
    let marker = "CONTENT:";
    let end_tag = "[/FILE_ACTION]";
    let content_start = block.find(marker)?;
    let content_end = block.rfind(end_tag)?;
    let raw = &block[content_start + marker.len()..content_end];
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        None
    } else {
        Some(trimmed.to_string())
    }
}

/// Build a summary string from parseable actions.
pub fn summarize_actions(output: &str, user_input: &str) -> String {
    let actions = parse_actions(output);
    if actions.is_empty() {
        format!("chat: {}", &user_input[..80.min(user_input.len())])
    } else {
        actions
            .iter()
            .map(|a| format!("{}: {}", action_name(&a.operation), a.path))
            .collect::<Vec<_>>()
            .join("; ")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_actions() {
        let output = r#"[FILE_ACTION: src/test.ts]
OPERATION: CREATE
INTENT: MUTATE
DESCRIPTION: Create test file
CONTENT:
console.log("hello");
[/FILE_ACTION]"#;

        let actions = parse_actions(output);
        assert_eq!(actions.len(), 1);
        assert_eq!(actions[0].path, "src/test.ts");
        assert_eq!(actions[0].operation, FileOperation::Create);
        assert!(actions[0].content.is_some());
    }

    #[test]
    fn test_swd_engine_create() {
        let dir = std::env::temp_dir().join("swd-test-create");
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();

        let engine = SwdEngine::new(SwdOptions {
            working_dir: dir.clone(),
            ..Default::default()
        });

        let actions = vec![FileAction {
            path: "test.txt".to_string(),
            operation: FileOperation::Create,
            intent: ActionIntent::Mutate,
            content: Some("hello world".to_string()),
            content_hash: None,
            description: Some("Create test".to_string()),
        }];

        let result = engine.run(actions).unwrap();
        assert!(result.success, "Create should succeed: {:?}", result.errors);
        assert!(dir.join("test.txt").exists());

        let _ = fs::remove_dir_all(&dir);
    }

    #[test]
    fn test_swd_engine_dry_run() {
        let engine = SwdEngine::new(SwdOptions {
            dry_run: true,
            ..Default::default()
        });

        let actions = vec![FileAction {
            path: "nonexistent.txt".to_string(),
            operation: FileOperation::Create,
            intent: ActionIntent::Mutate,
            content: Some("test".to_string()),
            content_hash: None,
            description: Some("Dry run test".to_string()),
        }];

        let result = engine.run(actions).unwrap();
        assert!(result.success);
        assert!(!std::path::Path::new("nonexistent.txt").exists());
    }
}
