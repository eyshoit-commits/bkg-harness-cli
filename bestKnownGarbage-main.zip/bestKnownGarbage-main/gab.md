Gap Analysis Summary
1. Atlantean TUI in Config tab
The Config tab in app.rs already uses many Atlantean elements (symbols, colors, styles, atlantean_title)
It references the CONFIG component as "CODEX_OF_LAWS"
It displays routing information, system status, etc. with Atlantean styling
Need to understand what specific Atlantean UI components or visual enhancements are missing
2. Ollama orchestrator
ollama.rs appears to be a complete implementation that:
Discovers installed models via /api/tags
Creates model catalogs sorted by capacity
Routes tasks to appropriate models based on task type
Handles model pulling and ensuring models are available
Implements LLMProvider trait but explicitly states it's a "reiner Orchestrator" (chat execution fails intentionally)
Need to understand if this is complete or if specific orchestrator functionality is missing
3. CapsuleState in TUI
Capsule state is tracked in TuiApp struct
Capsule events are processed in drain_events()
Capsule status summary is displayed in Config tab (counts and health percentage)
Capsule events appear in Agents tab
Need to understand if a dedicated capsule tab/view is missing or if specific capsule details/visualizations are needed
4. Trust Layer in agent system
Trust events are tracked in TuiApp, processed in drain_events(), displayed in Config/Agents tabs
Trust kernel exists in bkg-kernel/src/trust/kernel.rs
Looking at agent.rs (Coordinator::run), the agent processes messages, uses tools, publishes events but doesn't explicitly consult/update trust vectors
Need to understand if the agent should actively use trust layer to evaluate its own actions/decisions
5. SWD integration
bkg-swd crate exists with complete implementation
Looking at agent.rs, Coordinator executes tools directly without apparent SWD integration
Need to understand if file operations performed by tools should go through SWD system to ensure they are recorded, verified, reversible
6. Auto-heal in CLI
Healing daemon is started in main.rs when Tui command is run (calls start_healing_daemon)
start_healing_daemon probes capsule store health, publishes events, auto-repairs degraded capsules
Need to understand if this should be active across all BKG operations (not just TUI) or if specific healing capabilities are missing
7. Dynamic model routing
ModelRouter exists in model_router.rs
ChainBuilder in router.rs uses ModelRouter for dynamic model selection when available
RouteEvent is published for TUI display
Need to understand if there are specific aspects of dynamic model routing that are missing or incomplete Now I'll formulate specific questions for each gap area to understand what exactly needs to be implemented.